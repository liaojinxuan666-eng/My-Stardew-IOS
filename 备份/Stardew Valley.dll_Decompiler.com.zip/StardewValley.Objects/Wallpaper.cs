using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.GameData;
using StardewValley.Locations;

namespace StardewValley.Objects;

public class Wallpaper : Object
{
	[XmlElement("sourceRect")]
	public readonly NetRectangle sourceRect = new NetRectangle();

	[XmlElement("isFloor")]
	public readonly NetBool isFloor = new NetBool(value: false);

	[XmlElement("sourceTexture")]
	public readonly NetString setId = new NetString(null);

	protected ModWallpaperOrFlooring setData;

	private static readonly Rectangle wallpaperContainerRect = new Rectangle(39, 31, 16, 16);

	private static readonly Rectangle floorContainerRect = new Rectangle(55, 31, 16, 16);

	public override string TypeDefinitionId
	{
		get
		{
			if (!isFloor.Value)
			{
				return "(WP)";
			}
			return "(FL)";
		}
	}

	[XmlIgnore]
	public override string Name => base.name;

	public Wallpaper()
	{
	}

	public Wallpaper(int which, bool isFloor = false)
		: this()
	{
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		base.ItemId = which.ToString();
		this.isFloor.Value = isFloor;
		base.ParentSheetIndex = which;
		base.name = (isFloor ? "Flooring" : "Wallpaper");
		sourceRect.Value = (isFloor ? new Rectangle(which % 8 * 32, 336 + which / 8 * 32, 28, 26) : new Rectangle(which % 16 * 16, which / 16 * 48 + 8, 16, 28));
		price.Value = 100;
	}

	public Wallpaper(string setId, int which)
		: this()
	{
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		base.ItemId = $"{setId}:{which}";
		this.setId.Value = setId;
		base.ParentSheetIndex = which;
		ModWallpaperOrFlooring val = GetSetData();
		if (val == null)
		{
			this.setId.Value = null;
		}
		isFloor.Value = val?.IsFlooring ?? false;
		sourceRect.Value = (isFloor.Value ? new Rectangle(which % 8 * 32, 336 + which / 8 * 32, 28, 26) : new Rectangle(which % 16 * 16, which / 16 * 48 + 8, 16, 28));
		if (val != null && isFloor.Value)
		{
			sourceRect.Y = which / 8 * 32;
		}
		base.name = (isFloor.Value ? "Flooring" : "Wallpaper");
		price.Value = 100;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(sourceRect, "sourceRect").AddField(isFloor, "isFloor").AddField(setId, "setId");
	}

	public virtual ModWallpaperOrFlooring GetSetData()
	{
		if (setId.Value == null)
		{
			return null;
		}
		if (setData != null)
		{
			return setData;
		}
		foreach (ModWallpaperOrFlooring item in DataLoader.AdditionalWallpaperFlooring(Game1.content))
		{
			if (item.Id == setId.Value)
			{
				setData = item;
				return item;
			}
		}
		return null;
	}

	protected override string loadDisplayName()
	{
		if (!isFloor.Value)
		{
			return Game1.content.LoadString("Strings\\StringsFromCSFiles:Wallpaper.cs.13204");
		}
		return Game1.content.LoadString("Strings\\StringsFromCSFiles:Wallpaper.cs.13203");
	}

	public override string getDescription()
	{
		if (!isFloor.Value)
		{
			return Game1.content.LoadString("Strings\\StringsFromCSFiles:Wallpaper.cs.13206");
		}
		return Game1.content.LoadString("Strings\\StringsFromCSFiles:Wallpaper.cs.13205");
	}

	public override bool performDropDownAction(Farmer who)
	{
		return true;
	}

	public override bool performObjectDropInAction(Item dropInItem, bool probe, Farmer who, bool returnFalseIfItemConsumed = false)
	{
		return false;
	}

	public override bool canBePlacedHere(GameLocation l, Vector2 tile, CollisionMask collisionMask = CollisionMask.All, bool showError = false)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = tile * 64f;
		val.X += 32f;
		val.Y += 32f;
		foreach (Furniture item in l.furniture)
		{
			if (item.furniture_type.Value != 12)
			{
				Rectangle val2 = item.GetBoundingBox();
				if (((Rectangle)(ref val2)).Contains((int)val.X, (int)val.Y))
				{
					return false;
				}
			}
		}
		return true;
	}

	public override bool placementAction(GameLocation location, int x, int y, Farmer who = null)
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (who == null)
		{
			who = Game1.player;
		}
		if (location is DecoratableLocation decoratableLocation)
		{
			Point val = default(Point);
			((Point)(ref val))._002Ector(x / 64, y / 64);
			if (isFloor.Value)
			{
				string floorID = decoratableLocation.GetFloorID(val.X, val.Y);
				if (floorID != null)
				{
					if (GetSetData() != null)
					{
						decoratableLocation.SetFloor(GetSetData().Id + ":" + parentSheetIndex.Value, floorID);
					}
					else
					{
						decoratableLocation.SetFloor(parentSheetIndex.Value.ToString(), floorID);
					}
					location.playSound("coin");
					return true;
				}
			}
			else
			{
				string wallpaperID = decoratableLocation.GetWallpaperID(val.X, val.Y);
				if (wallpaperID != null)
				{
					if (GetSetData() != null)
					{
						decoratableLocation.SetWallpaper(GetSetData().Id + ":" + parentSheetIndex.Value, wallpaperID);
					}
					else
					{
						decoratableLocation.SetWallpaper(parentSheetIndex.Value.ToString(), wallpaperID);
					}
					location.playSound("coin");
					return true;
				}
			}
		}
		return false;
	}

	public override bool isPlaceable()
	{
		return true;
	}

	public override int salePrice(bool ignoreProfitMargins = false)
	{
		return price.Value;
	}

	public override int maximumStackSize()
	{
		return 1;
	}

	public override void drawWhenHeld(SpriteBatch spriteBatch, Vector2 objectPosition, Farmer f)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		drawInMenu(spriteBatch, objectPosition, 1f);
	}

	public override void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		AdjustMenuDrawForRecipes(ref transparency, ref scaleSize);
		Texture2D val;
		if (GetSetData() != null)
		{
			try
			{
				val = Game1.content.Load<Texture2D>(GetSetData().Texture);
			}
			catch (Exception)
			{
				val = Game1.content.Load<Texture2D>("Maps\\walls_and_floors");
			}
		}
		else
		{
			val = Game1.content.Load<Texture2D>("Maps\\walls_and_floors");
		}
		if (isFloor.Value)
		{
			spriteBatch.Draw(Game1.mouseCursors2, location + new Vector2(32f, 32f), (Rectangle?)floorContainerRect, color * transparency, 0f, new Vector2(8f, 8f), 4f * scaleSize, (SpriteEffects)0, layerDepth);
			spriteBatch.Draw(val, location + new Vector2(32f, 30f), (Rectangle?)sourceRect.Value, color * transparency, 0f, new Vector2(14f, 13f), 2f * scaleSize, (SpriteEffects)0, layerDepth + 0.001f);
		}
		else
		{
			spriteBatch.Draw(Game1.mouseCursors2, location + new Vector2(32f, 32f), (Rectangle?)wallpaperContainerRect, color * transparency, 0f, new Vector2(8f, 8f), 4f * scaleSize, (SpriteEffects)0, layerDepth);
			spriteBatch.Draw(val, location + new Vector2(32f, 32f), (Rectangle?)sourceRect.Value, color * transparency, 0f, new Vector2(8f, 14f), 2f * scaleSize, (SpriteEffects)0, layerDepth + 0.001f);
		}
		DrawMenuIcons(spriteBatch, location, scaleSize, transparency, layerDepth, drawStackNumber, color);
	}

	protected override Item GetOneNew()
	{
		ModWallpaperOrFlooring val = GetSetData();
		if (val == null)
		{
			return new Wallpaper(parentSheetIndex.Value, isFloor.Value);
		}
		return new Wallpaper(val.Id, parentSheetIndex.Value);
	}
}
