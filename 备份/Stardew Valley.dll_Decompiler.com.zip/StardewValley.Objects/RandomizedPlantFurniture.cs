using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;

namespace StardewValley.Objects;

public class RandomizedPlantFurniture : Furniture
{
	public NetInt topIndex = new NetInt();

	public NetInt middleIndex = new NetInt();

	public NetInt bottomIndex = new NetInt();

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(topIndex, "topIndex").AddField(middleIndex, "middleIndex").AddField(bottomIndex, "bottomIndex");
	}

	protected override Item GetOneNew()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		return new RandomizedPlantFurniture(base.ItemId, tileLocation.Value);
	}

	protected override void GetOneCopyFrom(Item source)
	{
		base.GetOneCopyFrom(source);
		if (source is RandomizedPlantFurniture randomizedPlantFurniture)
		{
			topIndex.Value = randomizedPlantFurniture.topIndex.Value;
			middleIndex.Value = randomizedPlantFurniture.middleIndex.Value;
			bottomIndex.Value = randomizedPlantFurniture.bottomIndex.Value;
		}
	}

	public RandomizedPlantFurniture(string which, Vector2 tile)
		: this(which, tile, Game1.random.Next())
	{
	}//IL_0002: Unknown result type (might be due to invalid IL or missing references)


	public RandomizedPlantFurniture(string which, Vector2 tile, int random_seed)
		: base(which, tile)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		Random random = Utility.CreateRandom(random_seed);
		topIndex.Value = random.Next(24);
		middleIndex.Value = random.Next(24);
		bottomIndex.Value = random.Next(16);
	}

	public RandomizedPlantFurniture()
	{
	}

	protected override float getScaleSize()
	{
		return 1.5f;
	}

	public override void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		location += new Vector2(32f, 32f);
		DrawFurniture(spriteBatch, location, transparency, new Vector2(8f, 0f), getScaleSize() * scaleSize, layerDepth);
		if (((drawStackNumber == StackDrawType.Draw && maximumStackSize() > 1 && Stack > 1) || drawStackNumber == StackDrawType.Draw_OneInclusive) && (double)scaleSize > 0.3 && Stack != int.MaxValue)
		{
			Utility.drawTinyDigits(stack.Value, spriteBatch, location + new Vector2((float)(64 - Utility.getWidthOfTinyDigitString(stack.Value, 3f * scaleSize)) + 3f * scaleSize, 64f - 18f * scaleSize + 2f), 3f * scaleSize, 1f, color);
		}
	}

	public override bool IsHeldOverHead()
	{
		return true;
	}

	public override void drawWhenHeld(SpriteBatch spriteBatch, Vector2 objectPosition, Farmer f)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		DrawFurniture(spriteBatch, objectPosition, 4f, Vector2.Zero, 4f, (float)(f.StandingPixel.Y + 3) / 10000f);
	}

	public override void draw(SpriteBatch spriteBatch, int x, int y, float alpha = 1f)
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		if (!isTemporarilyInvisible)
		{
			if (Furniture.isDrawingLocationFurniture)
			{
				x = (int)drawPosition.X;
				y = (int)drawPosition.Y;
			}
			else
			{
				x *= 64;
				y *= 64;
			}
			if (shakeTimer > 0)
			{
				x += Game1.random.Next(-1, 2);
				y += Game1.random.Next(-1, 2);
			}
			Vector2 location = Game1.GlobalToLocal(new Vector2((float)x, (float)y));
			Vector2 zero = Vector2.Zero;
			Rectangle value = boundingBox.Value;
			DrawFurniture(spriteBatch, location, alpha, zero, 4f, (float)(((Rectangle)(ref value)).Bottom - 8) / 10000f);
		}
	}

	public override void drawAtNonTileSpot(SpriteBatch spriteBatch, Vector2 location, float layerDepth, float alpha = 1f)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		DrawFurniture(spriteBatch, location, 1f, Vector2.Zero, 4f, layerDepth);
	}

	public virtual void DrawFurniture(SpriteBatch sb, Vector2 location, float alpha, Vector2 origin, float scale, float base_sort_y)
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		Texture2D texture = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId).GetTexture();
		Rectangle value = default(Rectangle);
		((Rectangle)(ref value))._002Ector(0, 96, 16, 16);
		value.X += bottomIndex.Value % 8 * 16;
		value.Y += bottomIndex.Value / 8 * 16;
		sb.Draw(texture, location, (Rectangle?)value, Color.White * alpha, 0f, origin, scale, (SpriteEffects)(flipped.Value ? 1 : 0), base_sort_y);
		float num = -1f * scale;
		((Rectangle)(ref value))._002Ector(0, 48, 16, 16);
		value.X += middleIndex.Value % 8 * 16;
		value.Y += middleIndex.Value / 8 * 16;
		sb.Draw(texture, location + new Vector2(num, -8f * scale), (Rectangle?)value, Color.White * alpha, 0f, origin, scale, (SpriteEffects)(flipped.Value ? 1 : 0), base_sort_y + 1E-05f);
		((Rectangle)(ref value))._002Ector(0, 0, 16, 16);
		value.X += topIndex.Value % 8 * 16;
		value.Y += topIndex.Value / 8 * 16;
		sb.Draw(texture, location + new Vector2(num, -24f * scale), (Rectangle?)value, Color.White * alpha, 0f, origin, scale, (SpriteEffects)(flipped.Value ? 1 : 0), base_sort_y + 1E-05f);
	}
}
