using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.BellsAndWhistles;
using StardewValley.Extensions;
using StardewValley.GameData;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Locations;
using StardewValley.Menus;
using StardewValley.Network;
using StardewValley.TerrainFeatures;

namespace StardewValley.Objects;

[XmlInclude(typeof(BedFurniture))]
[XmlInclude(typeof(RandomizedPlantFurniture))]
[XmlInclude(typeof(StorageFurniture))]
[XmlInclude(typeof(TV))]
public class Furniture : Object, ISittable
{
	public const int chair = 0;

	public const int bench = 1;

	public const int couch = 2;

	public const int armchair = 3;

	public const int dresser = 4;

	public const int longTable = 5;

	public const int painting = 6;

	public const int lamp = 7;

	public const int decor = 8;

	public const int other = 9;

	public const int bookcase = 10;

	public const int table = 11;

	public const int rug = 12;

	public const int window = 13;

	public const int fireplace = 14;

	public const int bed = 15;

	public const int torch = 16;

	public const int sconce = 17;

	public const string furnitureTextureName = "TileSheets\\furniture";

	[XmlElement("furniture_type")]
	public readonly NetInt furniture_type = new NetInt();

	[XmlElement("rotations")]
	public readonly NetInt rotations = new NetInt();

	[XmlElement("currentRotation")]
	public readonly NetInt currentRotation = new NetInt();

	[XmlElement("sourceIndexOffset")]
	private readonly NetInt sourceIndexOffset = new NetInt();

	[XmlElement("drawPosition")]
	protected readonly NetVector2 drawPosition = new NetVector2();

	[XmlElement("sourceRect")]
	public readonly NetRectangle sourceRect = new NetRectangle();

	[XmlElement("defaultSourceRect")]
	public readonly NetRectangle defaultSourceRect = new NetRectangle();

	[XmlElement("defaultBoundingBox")]
	public readonly NetRectangle defaultBoundingBox = new NetRectangle();

	[XmlElement("drawHeldObjectLow")]
	public readonly NetBool drawHeldObjectLow = new NetBool();

	[XmlIgnore]
	public NetLongDictionary<int, NetInt> sittingFarmers = new NetLongDictionary<int, NetInt>();

	[XmlIgnore]
	public Vector2? lightGlowPosition;

	[XmlIgnore]
	public bool AllowLocalRemoval = true;

	public static bool isDrawingLocationFurniture;

	protected static Dictionary<string, string> _frontTextureName;

	[XmlIgnore]
	private int _placementRestriction = -1;

	[XmlIgnore]
	private string _description;

	[XmlIgnore]
	public int placementRestriction
	{
		get
		{
			if (_placementRestriction < 0)
			{
				bool flag = true;
				string[] data = getData();
				if (data != null && data.Length > 6 && int.TryParse(data[6], out _placementRestriction) && _placementRestriction >= 0)
				{
					flag = false;
				}
				if (flag)
				{
					if (base.name.Contains("TV"))
					{
						_placementRestriction = 0;
					}
					else if (IsTable() || furniture_type.Value == 1 || furniture_type.Value == 0 || furniture_type.Value == 8 || furniture_type.Value == 16)
					{
						_placementRestriction = 2;
					}
					else
					{
						_placementRestriction = 0;
					}
				}
			}
			return _placementRestriction;
		}
	}

	[XmlIgnore]
	public string description
	{
		get
		{
			if (_description == null)
			{
				_description = loadDescription();
			}
			return _description;
		}
	}

	public override string TypeDefinitionId { get; } = "(F)";

	public override string Name => base.name;

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(furniture_type, "furniture_type").AddField(rotations, "rotations").AddField(currentRotation, "currentRotation")
			.AddField(sourceIndexOffset, "sourceIndexOffset")
			.AddField(drawPosition, "drawPosition")
			.AddField(sourceRect, "sourceRect")
			.AddField(defaultSourceRect, "defaultSourceRect")
			.AddField(defaultBoundingBox, "defaultBoundingBox")
			.AddField(drawHeldObjectLow, "drawHeldObjectLow")
			.AddField(sittingFarmers, "sittingFarmers");
	}

	public Furniture()
	{
		updateDrawPosition();
		isOn.Value = false;
	}

	public Furniture(string itemId, Vector2 tile, int initialRotations)
		: this(itemId, tile)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < initialRotations; i++)
		{
			rotate();
		}
		isOn.Value = false;
	}

	public virtual void OnAdded(GameLocation loc, Vector2 tilePos)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		if (IntersectsForCollision(Game1.player.GetBoundingBox()))
		{
			Game1.player.TemporaryPassableTiles.Add(GetBoundingBoxAt((int)tilePos.X, (int)tilePos.Y));
		}
		if (furniture_type.Value == 13)
		{
			if (loc != null && loc.IsRainingHere())
			{
				sourceRect.Value = defaultSourceRect.Value;
				sourceIndexOffset.Value = 1;
			}
			else
			{
				sourceRect.Value = defaultSourceRect.Value;
				sourceIndexOffset.Value = 0;
				AddLightGlow();
			}
		}
		minutesElapsed(1);
	}

	public void OnRemoved(GameLocation loc, Vector2 tilePos)
	{
		RemoveLightGlow();
	}

	public override bool IsHeldOverHead()
	{
		return false;
	}

	public virtual bool IsTable()
	{
		int value = furniture_type.Value;
		if (value != 11)
		{
			return value == 5;
		}
		return true;
	}

	public static Rectangle GetDefaultSourceRect(string itemId, Texture2D texture = null)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem("(F)" + itemId);
		string[] data = getData(itemId);
		if (data == null)
		{
			return dataOrErrorItem.GetSourceRect();
		}
		if (data[2].Equals("-1"))
		{
			return getDefaultSourceRectForType(dataOrErrorItem, getTypeNumberFromName(data[1]), texture);
		}
		string[] array = ArgUtility.SplitBySpace(data[2]);
		int spriteWidth = Convert.ToInt32(array[0]);
		int spriteHeight = Convert.ToInt32(array[1]);
		return getDefaultSourceRect(dataOrErrorItem, spriteWidth, spriteHeight, texture);
	}

	public Furniture SetPlacement(int x, int y, int rotations = 0)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		return this.SetPlacement(new Vector2((float)x, (float)y), rotations);
	}

	public Furniture SetPlacement(Point tile, int rotations = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		return SetPlacement(Utility.PointToVector2(tile), rotations);
	}

	public Furniture SetPlacement(Vector2 tile, int rotations = 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		InitializeAtTile(tile);
		for (int i = 0; i < rotations; i++)
		{
			rotate();
		}
		return this;
	}

	public Furniture SetHeldObject(Object obj)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		heldObject.Value = obj;
		if (obj != null)
		{
			if (obj is Furniture furniture)
			{
				furniture.InitializeAtTile(TileLocation);
			}
			else
			{
				obj.TileLocation = TileLocation;
			}
		}
		return this;
	}

	public void InitializeAtTile(Vector2 tile)
	{
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		Texture2D texture = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId).GetTexture();
		string[] data = getData();
		if (data != null)
		{
			furniture_type.Value = getTypeNumberFromName(data[1]);
			defaultSourceRect.Value = new Rectangle(base.ParentSheetIndex * 16 % texture.Width, base.ParentSheetIndex * 16 / texture.Width * 16, 1, 1);
			drawHeldObjectLow.Value = Name.ContainsIgnoreCase("tea");
			sourceRect.Value = GetDefaultSourceRect(base.ItemId);
			defaultSourceRect.Value = sourceRect.Value;
			rotations.Value = Convert.ToInt32(data[4]);
			price.Value = Convert.ToInt32(data[5]);
		}
		else
		{
			defaultSourceRect.Value = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId).GetSourceRect();
		}
		if (tile != TileLocation)
		{
			TileLocation = tile;
		}
		else
		{
			RecalculateBoundingBox(data);
		}
	}

	public Furniture(string itemId, Vector2 tile)
	{
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		isOn.Value = false;
		base.ItemId = itemId;
		ResetParentSheetIndex();
		base.name = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId).InternalName;
		InitializeAtTile(tile);
	}

	public override void RecalculateBoundingBox()
	{
		RecalculateBoundingBox(getData());
	}

	private void RecalculateBoundingBox(string[] data)
	{
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		string text = ArgUtility.Get(data, 3);
		Rectangle defaultBoundingBoxForType = default(Rectangle);
		if (text != null)
		{
			if (text == "-1")
			{
				defaultBoundingBoxForType = getDefaultBoundingBoxForType(furniture_type.Value);
			}
			else
			{
				string[] array = ArgUtility.SplitBySpace(data[3]);
				((Rectangle)(ref defaultBoundingBoxForType))._002Ector((int)tileLocation.X * 64, (int)tileLocation.Y * 64, Convert.ToInt32(array[0]) * 64, Convert.ToInt32(array[1]) * 64);
			}
		}
		else
		{
			((Rectangle)(ref defaultBoundingBoxForType))._002Ector((int)tileLocation.X * 64, (int)tileLocation.Y * 64, 64, 64);
		}
		defaultBoundingBox.Value = defaultBoundingBoxForType;
		boundingBox.Value = defaultBoundingBoxForType;
		updateRotation();
	}

	protected string[] getData()
	{
		return getData(base.ItemId);
	}

	protected static string[] getData(string itemId)
	{
		if (!DataLoader.Furniture(Game1.content).TryGetValue(itemId, out var value))
		{
			return null;
		}
		return value.Split('/');
	}

	protected override string loadDisplayName()
	{
		return ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId).DisplayName;
	}

	protected virtual string loadDescription()
	{
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
		if (dataOrErrorItem.IsErrorItem)
		{
			return dataOrErrorItem.Description;
		}
		return base.QualifiedItemId switch
		{
			"(F)TrashCatalogue" => Game1.content.LoadString("Strings\\1_6_Strings:TrashCatalogueDescription"), 
			"(F)RetroCatalogue" => Game1.content.LoadString("Strings\\1_6_Strings:RetroCatalogueDescription"), 
			"(F)JunimoCatalogue" => Game1.content.LoadString("Strings\\1_6_Strings:JunimoCatalogueDescription"), 
			"(F)WizardCatalogue" => Game1.content.LoadString("Strings\\1_6_Strings:WizardCatalogueDescription"), 
			"(F)JojaCatalogue" => Game1.content.LoadString("Strings\\1_6_Strings:JojaCatalogueDescription"), 
			"(F)1308" => Game1.parseText(Game1.content.LoadString("Strings\\Objects:CatalogueDescription"), Game1.smallFont, 320), 
			"(F)1226" => Game1.parseText(Game1.content.LoadString("Strings\\Objects:FurnitureCatalogueDescription"), Game1.smallFont, 320), 
			_ => placementRestriction switch
			{
				0 => Game1.content.LoadString("Strings\\StringsFromCSFiles:Furniture_NotOutdoors"), 
				1 => Game1.content.LoadString("Strings\\StringsFromCSFiles:Furniture_Outdoors_Description"), 
				2 => Game1.content.LoadString("Strings\\StringsFromCSFiles:Furniture_Decoration_Description"), 
				_ => Game1.content.LoadString("Strings\\StringsFromCSFiles:Furniture.cs.12623"), 
			}, 
		};
	}

	public override string getDescription()
	{
		return Game1.parseText(description, Game1.smallFont, getDescriptionWidth());
	}

	public override Color getCategoryColor()
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		return new Color(100, 25, 190);
	}

	public override bool performDropDownAction(Farmer who)
	{
		actionOnPlayerEntryOrPlacement(Location, dropDown: true);
		return false;
	}

	public override void hoverAction()
	{
		base.hoverAction();
		if (!Game1.player.isInventoryFull())
		{
			Game1.mouseCursor = Game1.cursor_grab;
		}
	}

	public override bool checkForAction(Farmer who, bool justCheckingForActivity = false)
	{
		//IL_04d3: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return false;
		}
		if (justCheckingForActivity)
		{
			return true;
		}
		switch (base.QualifiedItemId)
		{
		case "(F)Cauldron":
			base.IsOn = !base.IsOn;
			base.SpecialVariable = (base.IsOn ? 388859 : 0);
			if (base.IsOn)
			{
				location.playSound("fireball");
				location.playSound("bubbles");
				for (int i = 0; i < 13; i++)
				{
					addCauldronBubbles(-0.5f - (float)i * 0.2f);
				}
			}
			break;
		case "(F)1402":
			Game1.activeClickableMenu = new Billboard();
			return true;
		case "(F)RetroCatalogue":
			Utility.TryOpenShopMenu("RetroFurnitureCatalogue", location);
			break;
		case "(F)TrashCatalogue":
			Utility.TryOpenShopMenu("TrashFurnitureCatalogue", location);
			break;
		case "(F)JunimoCatalogue":
			Utility.TryOpenShopMenu("JunimoFurnitureCatalogue", location);
			break;
		case "(F)WizardCatalogue":
			if (!Game1.player.mailReceived.Contains("WizardCatalogue"))
			{
				Game1.player.mailReceived.Add("WizardCatalogue");
				Game1.activeClickableMenu = new LetterViewerMenu(Game1.content.LoadString("Strings\\1_6_Strings:WizardCatalogueLetter"))
				{
					whichBG = 2
				};
			}
			else
			{
				Utility.TryOpenShopMenu("WizardFurnitureCatalogue", location);
			}
			return true;
		case "(F)JojaCatalogue":
			if (!Game1.player.mailReceived.Contains("JojaThriveTerms"))
			{
				Game1.player.mailReceived.Add("JojaThriveTerms");
				Game1.activeClickableMenu = new LetterViewerMenu(Game1.content.LoadString("Strings\\1_6_Strings:JojaCatalogueDescriptionTerms"))
				{
					whichBG = 4
				};
			}
			else
			{
				Utility.TryOpenShopMenu("JojaFurnitureCatalogue", location);
			}
			return true;
		case "(F)1308":
			Utility.TryOpenShopMenu("Catalogue", location);
			return true;
		case "(F)1226":
			Utility.TryOpenShopMenu("Furniture Catalogue", location);
			return true;
		case "(F)1309":
			Game1.playSound("openBox");
			shakeTimer = 500;
			if (Game1.getMusicTrackName((MusicContext)0).Equals("sam_acoustic1"))
			{
				Game1.changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
			}
			else
			{
				Game1.changeMusicTrack("sam_acoustic1", track_interruptable: false, (MusicContext)0);
			}
			return true;
		}
		if (furniture_type.Value == 14 || furniture_type.Value == 16)
		{
			isOn.Value = !isOn.Value;
			initializeLightSource(tileLocation.Value);
			setFireplace(playSound: true, broadcast: true);
			return true;
		}
		if (GetSeatCapacity() > 0)
		{
			who.BeginSitting(this);
			return true;
		}
		return clicked(who);
	}

	public virtual void setFireplace(bool playSound = true, bool broadcast = false)
	{
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return;
		}
		if (isOn.Value)
		{
			if (base.lightSource == null)
			{
				initializeLightSource(tileLocation.Value);
			}
			if (base.lightSource != null && isOn.Value && !location.hasLightSource(base.lightSource.Id))
			{
				location.sharedLights.AddLight(base.lightSource.Clone());
			}
			if (playSound)
			{
				location.localSound("fireball");
			}
			AmbientLocationSounds.addSound(new Vector2(tileLocation.X, tileLocation.Y), 1);
		}
		else
		{
			if (playSound)
			{
				location.localSound("fireball");
			}
			base.performRemoveAction();
			AmbientLocationSounds.removeSound(new Vector2(tileLocation.X, tileLocation.Y));
		}
	}

	public virtual void AttemptRemoval(Action<Furniture> removal_action)
	{
		removal_action?.Invoke(this);
	}

	public virtual bool canBeRemoved(Farmer who)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		if (!AllowLocalRemoval)
		{
			return false;
		}
		GameLocation location = Location;
		if (location == null)
		{
			return false;
		}
		if (HasSittingFarmers())
		{
			return false;
		}
		if (heldObject.Value != null)
		{
			return false;
		}
		Rectangle val = GetBoundingBox();
		if (isPassable())
		{
			for (int i = ((Rectangle)(ref val)).Left / 64; i < ((Rectangle)(ref val)).Right / 64; i++)
			{
				for (int j = ((Rectangle)(ref val)).Top / 64; j < ((Rectangle)(ref val)).Bottom / 64; j++)
				{
					Furniture furnitureAt = location.GetFurnitureAt(new Vector2((float)i, (float)j));
					if (furnitureAt != null && furnitureAt != this)
					{
						return false;
					}
					if (location.objects.ContainsKey(new Vector2((float)i, (float)j)))
					{
						return false;
					}
				}
			}
		}
		return true;
	}

	public override bool clicked(Farmer who)
	{
		Game1.haltAfterCheck = false;
		if (furniture_type.Value == 11 && who.ActiveObject != null && heldObject.Value == null)
		{
			return false;
		}
		if (heldObject.Value != null)
		{
			Object value = heldObject.Value;
			heldObject.Value = null;
			if (who.addItemToInventoryBool(value))
			{
				value.performRemoveAction();
				Game1.playSound("coin");
				return true;
			}
			heldObject.Value = value;
		}
		return false;
	}

	public virtual int GetSeatCapacity()
	{
		if (base.QualifiedItemId.Equals("(F)UprightPiano") || base.QualifiedItemId.Equals("(F)DarkPiano"))
		{
			return 1;
		}
		return furniture_type.Value switch
		{
			0 => 1, 
			1 => 2, 
			2 => defaultBoundingBox.Width / 64 - 1, 
			3 => 1, 
			_ => 0, 
		};
	}

	public virtual bool IsSeatHere(GameLocation location)
	{
		return location.furniture.Contains(this);
	}

	public virtual bool IsSittingHere(Farmer who)
	{
		return sittingFarmers.ContainsKey(who.UniqueMultiplayerID);
	}

	public virtual Vector2? GetSittingPosition(Farmer who, bool ignore_offsets = false)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if (sittingFarmers.TryGetValue(who.UniqueMultiplayerID, out var value))
		{
			return GetSeatPositions(ignore_offsets)[value];
		}
		return null;
	}

	public virtual bool HasSittingFarmers()
	{
		return sittingFarmers.Length > 0;
	}

	public virtual void RemoveSittingFarmer(Farmer farmer)
	{
		sittingFarmers.Remove(farmer.UniqueMultiplayerID);
	}

	public virtual int GetSittingFarmerCount()
	{
		return sittingFarmers.Length;
	}

	public virtual Rectangle GetSeatBounds()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		Rectangle val = GetBoundingBox();
		return new Rectangle(val.X / 64, val.Y / 64, val.Width / 64, val.Height / 64);
	}

	public virtual int GetSittingDirection()
	{
		if (Name.Contains("Stool"))
		{
			return Game1.player.FacingDirection;
		}
		if (base.QualifiedItemId.Equals("(F)UprightPiano") || base.QualifiedItemId.Equals("(F)DarkPiano"))
		{
			return 0;
		}
		return currentRotation.Value switch
		{
			0 => 2, 
			1 => 1, 
			2 => 0, 
			3 => 3, 
			_ => 2, 
		};
	}

	public virtual Vector2? AddSittingFarmer(Farmer who)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		List<Vector2> seatPositions = GetSeatPositions();
		int value = -1;
		Vector2? result = null;
		float num = 96f;
		Vector2 standingPosition = who.getStandingPosition();
		for (int i = 0; i < seatPositions.Count; i++)
		{
			if (!sittingFarmers.Values.Contains(i))
			{
				Vector2 val = (seatPositions[i] + new Vector2(0.5f, 0.5f)) * 64f - standingPosition;
				float num2 = ((Vector2)(ref val)).Length();
				if (num2 < num)
				{
					num = num2;
					result = seatPositions[i];
					value = i;
				}
			}
		}
		if (result.HasValue)
		{
			sittingFarmers[who.UniqueMultiplayerID] = value;
		}
		return result;
	}

	public virtual List<Vector2> GetSeatPositions(bool ignore_offsets = false)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		List<Vector2> list = new List<Vector2>();
		if (base.QualifiedItemId.Equals("(F)UprightPiano") || base.QualifiedItemId.Equals("(F)DarkPiano"))
		{
			list.Add(TileLocation + new Vector2(1.5f, 0f));
		}
		switch (furniture_type.Value)
		{
		case 0:
			list.Add(TileLocation);
			break;
		case 1:
		{
			for (int l = 0; l < getTilesWide(); l++)
			{
				for (int m = 0; m < getTilesHigh(); m++)
				{
					list.Add(TileLocation + new Vector2((float)l, (float)m));
				}
			}
			break;
		}
		case 2:
		{
			int num = defaultBoundingBox.Width / 64 - 1;
			switch (currentRotation.Value)
			{
			case 0:
			case 2:
			{
				list.Add(TileLocation + new Vector2(0.5f, 0f));
				for (int j = 1; j < num - 1; j++)
				{
					list.Add(TileLocation + new Vector2((float)j + 0.5f, 0f));
				}
				list.Add(TileLocation + new Vector2((float)(num - 1) + 0.5f, 0f));
				break;
			}
			case 1:
			{
				for (int k = 0; k < num; k++)
				{
					list.Add(TileLocation + new Vector2(1f, (float)k));
				}
				break;
			}
			default:
			{
				for (int i = 0; i < num; i++)
				{
					list.Add(TileLocation + new Vector2(0f, (float)i));
				}
				break;
			}
			}
			break;
		}
		case 3:
			if (currentRotation.Value == 0 || currentRotation.Value == 2)
			{
				list.Add(TileLocation + new Vector2(0.5f, 0f));
			}
			else if (currentRotation.Value == 1)
			{
				list.Add(TileLocation + new Vector2(1f, 0f));
			}
			else
			{
				list.Add(TileLocation + new Vector2(0f, 0f));
			}
			break;
		}
		return list;
	}

	public bool timeToTurnOnLights()
	{
		if (Location != null)
		{
			if (!Location.IsRainingHere())
			{
				return Game1.timeOfDay >= Game1.getTrulyDarkTime(Location) - 100;
			}
			return true;
		}
		return false;
	}

	public override void DayUpdate()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Invalid comparison between Unknown and I4
		base.DayUpdate();
		sittingFarmers.Clear();
		if (Location.IsRainingHere())
		{
			addLights();
		}
		else if (!timeToTurnOnLights() || Game1.newDay)
		{
			removeLights();
		}
		else
		{
			addLights();
		}
		RemoveLightGlow();
		if (Game1.IsMasterGame && (int)Game1.season == 3 && Game1.dayOfMonth == 25 && (furniture_type.Value == 11 || furniture_type.Value == 5) && heldObject.Value != null)
		{
			if (heldObject.Value.QualifiedItemId == "(O)223" && !Game1.player.mailReceived.Contains("CookiePresent_year" + Game1.year))
			{
				heldObject.Value = ItemRegistry.Create<Object>("(O)MysteryBox");
				Game1.player.mailReceived.Add("CookiePresent_year" + Game1.year);
			}
			else if (heldObject.Value.Category == -6 && !Game1.player.mailReceived.Contains("MilkPresent_year" + Game1.year))
			{
				heldObject.Value = ItemRegistry.Create<Object>("(O)MysteryBox");
				Game1.player.mailReceived.Add("MilkPresent_year" + Game1.year);
			}
		}
	}

	public virtual void AddLightGlow()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location != null && !lightGlowPosition.HasValue)
		{
			Vector2 val = default(Vector2);
			((Vector2)(ref val))._002Ector((float)(boundingBox.X + 32), (float)(boundingBox.Y + 64));
			if (!location.lightGlows.Contains(val))
			{
				lightGlowPosition = val;
				location.lightGlows.Add(val);
			}
		}
	}

	public virtual void RemoveLightGlow()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location != null)
		{
			if (lightGlowPosition.HasValue && location.lightGlows.Contains(lightGlowPosition.Value))
			{
				location.lightGlows.Remove(lightGlowPosition.Value);
			}
			location.lightGlowLayerCache.Clear();
			lightGlowPosition = null;
		}
	}

	public override void actionOnPlayerEntry()
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Invalid comparison between Unknown and I4
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Invalid comparison between Unknown and I4
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		base.actionOnPlayerEntry();
		actionOnPlayerEntryOrPlacement(Location, dropDown: false);
		if (Location == null || !base.QualifiedItemId.Equals("(F)BirdHouse") || !Location.isOutdoors.Value || Game1.isRaining || Game1.timeOfDay >= Game1.getStartingToGetDarkTime(Location))
		{
			return;
		}
		Random random = Utility.CreateDaySaveRandom(TileLocation.X * 74797f, TileLocation.Y * 77f, Game1.timeOfDay * 99);
		int num = (int)Game1.stats.Get("childrenTurnedToDoves");
		if (random.NextDouble() < 0.06)
		{
			Location.instantiateCrittersList();
			int num2 = (((int)Game1.season == 2) ? 45 : 25);
			int num3 = 0;
			if (Game1.random.NextBool() && Game1.MasterPlayer.mailReceived.Contains("Farm_Eternal"))
			{
				num2 = (((int)Game1.season == 2) ? 135 : 125);
			}
			if (num2 == 25 && Game1.random.NextDouble() < 0.05)
			{
				num2 = 165;
			}
			if (random.NextDouble() < (double)num * 0.08)
			{
				num2 = 175;
				num3 = 12;
			}
			Location.critters.Add(new Birdie(TileLocation * 64f + new Vector2(32f, (float)(64 + Game1.random.Next(3) * 4 + num3)), -160f, num2, stationary: true));
		}
	}

	public virtual void actionOnPlayerEntryOrPlacement(GameLocation environment, bool dropDown)
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (Location == null)
		{
			Location = environment;
		}
		RemoveLightGlow();
		removeLights();
		if (furniture_type.Value == 14 || furniture_type.Value == 16)
		{
			setFireplace(playSound: false);
		}
		if (timeToTurnOnLights())
		{
			addLights();
			if (heldObject.Value is Furniture furniture)
			{
				furniture.addLights();
			}
		}
		if (base.QualifiedItemId == "(F)1971" && !dropDown)
		{
			environment.instantiateCrittersList();
			environment.addCritter(new Butterfly(environment, environment.getRandomTile()).setStayInbounds(stayInbounds: true));
			while (Game1.random.NextBool())
			{
				environment.addCritter(new Butterfly(environment, environment.getRandomTile()).setStayInbounds(stayInbounds: true));
			}
		}
	}

	public override bool performObjectDropInAction(Item dropInItem, bool probe, Farmer who, bool returnFalseIfItemConsumed = false)
	{
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return false;
		}
		if (!(dropInItem is Object obj))
		{
			return false;
		}
		if (IsTable() && heldObject.Value == null && !obj.bigCraftable.Value && !(obj is Wallpaper) && (!(obj is Furniture furniture) || (furniture.getTilesWide() == 1 && furniture.getTilesHigh() == 1)))
		{
			if (!probe)
			{
				heldObject.Value = (Object)obj.getOne();
				heldObject.Value.Location = Location;
				heldObject.Value.TileLocation = tileLocation.Value;
				heldObject.Value.boundingBox.X = boundingBox.X;
				heldObject.Value.boundingBox.Y = boundingBox.Y;
				heldObject.Value.performDropDownAction(who);
				location.playSound("woodyStep");
				if (who != null)
				{
					who.reduceActiveItemByOne();
					if (returnFalseIfItemConsumed)
					{
						return false;
					}
				}
			}
			return true;
		}
		return false;
	}

	protected virtual string GenerateLightSourceId()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return base.GenerateLightSourceId(tileLocation.Value);
	}

	private bool isLampStyleLightSource()
	{
		if (furniture_type.Value != 7 && furniture_type.Value != 17)
		{
			return base.QualifiedItemId == "(F)1369";
		}
		return true;
	}

	public virtual void addLights()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return;
		}
		if (heldObject.Value is Furniture furniture)
		{
			heldObject.Value.Location = Location;
			furniture.addLights();
		}
		if (isLampStyleLightSource())
		{
			sourceRect.Value = defaultSourceRect.Value;
			sourceIndexOffset.Value = 1;
			if (base.lightSource == null)
			{
				base.lightSource = new LightSource(GenerateLightSourceId(), 4, new Vector2((float)(boundingBox.X + 32), (float)(boundingBox.Y + ((furniture_type.Value == 7) ? (-64) : 64))), (furniture_type.Value == 7) ? 2f : 1f, (base.QualifiedItemId == "(F)1369") ? (Color.RoyalBlue * 0.7f) : Color.Black, LightSource.LightContext.None, 0L, location.NameOrUniqueName);
				location.sharedLights.AddLight(base.lightSource.Clone());
			}
		}
		else if (base.QualifiedItemId == "(F)1440")
		{
			base.lightSource = new LightSource(GenerateLightSourceId(), 4, new Vector2((float)(boundingBox.X + 96), (float)boundingBox.Y - 32f), 1.5f, Color.Black, LightSource.LightContext.None, 0L, location.NameOrUniqueName);
			location.sharedLights.AddLight(base.lightSource.Clone());
		}
		else if (furniture_type.Value == 13)
		{
			sourceRect.Value = defaultSourceRect.Value;
			sourceIndexOffset.Value = 1;
			RemoveLightGlow();
		}
		else if (this is FishTankFurniture && base.lightSource == null)
		{
			string value = GenerateLightSourceId();
			Vector2 position = default(Vector2);
			((Vector2)(ref position))._002Ector(tileLocation.X * 64f + 32f + 2f, tileLocation.Y * 64f + 12f);
			for (int i = 0; i < getTilesWide(); i++)
			{
				base.lightSource = new LightSource($"{value}_tile{i}", 8, position, 2f, Color.Black, LightSource.LightContext.None, 0L, location.NameOrUniqueName);
				location.sharedLights.AddLight(base.lightSource.Clone());
				position.X += 64f;
			}
		}
	}

	public virtual void removeLights()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (heldObject.Value is Furniture furniture)
		{
			furniture.removeLights();
		}
		if (isLampStyleLightSource() || base.QualifiedItemId == "(F)1440")
		{
			sourceRect.Value = defaultSourceRect.Value;
			sourceIndexOffset.Value = 0;
			location?.removeLightSource(GenerateLightSourceId());
			base.lightSource = null;
		}
		else if (furniture_type.Value == 13)
		{
			if (location != null && location.IsRainingHere())
			{
				sourceRect.Value = defaultSourceRect.Value;
				sourceIndexOffset.Value = 1;
			}
			else
			{
				sourceRect.Value = defaultSourceRect.Value;
				sourceIndexOffset.Value = 0;
				AddLightGlow();
			}
		}
		else if (this is FishTankFurniture)
		{
			string value = GenerateLightSourceId();
			for (int i = 0; i < getTilesWide(); i++)
			{
				location?.removeLightSource($"{value}_tile{i}");
			}
			base.lightSource = null;
		}
	}

	public override bool minutesElapsed(int minutes)
	{
		if (Location == null)
		{
			return false;
		}
		if (timeToTurnOnLights())
		{
			addLights();
		}
		else
		{
			removeLights();
		}
		return false;
	}

	public override void performRemoveAction()
	{
		removeLights();
		if (Location != null)
		{
			if (furniture_type.Value == 14 || furniture_type.Value == 16)
			{
				isOn.Value = false;
				setFireplace(playSound: false);
			}
			RemoveLightGlow();
			base.performRemoveAction();
			if (furniture_type.Value == 14 || furniture_type.Value == 16)
			{
				base.lightSource = null;
			}
			if (base.QualifiedItemId == "(F)1309" && Game1.getMusicTrackName((MusicContext)0).Equals("sam_acoustic1"))
			{
				Game1.changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
			}
			sittingFarmers.Clear();
		}
	}

	public virtual void rotate()
	{
		if (rotations.Value >= 2)
		{
			int num = ((rotations.Value == 4) ? 1 : 2);
			currentRotation.Value += num;
			currentRotation.Value %= 4;
			updateRotation();
		}
	}

	public virtual void updateRotation()
	{
		//IL_0491: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0366: Unknown result type (might be due to invalid IL or missing references)
		//IL_045c: Unknown result type (might be due to invalid IL or missing references)
		flipped.Value = false;
		if (currentRotation.Value > 0)
		{
			Point zero = default(Point);
			switch (furniture_type.Value)
			{
			case 2:
				((Point)(ref zero))._002Ector(-1, 1);
				break;
			case 5:
				((Point)(ref zero))._002Ector(-1, 0);
				break;
			case 3:
				((Point)(ref zero))._002Ector(-1, 1);
				break;
			default:
				zero = Point.Zero;
				break;
			}
			bool flag = (IsTable() || furniture_type.Value == 12 || base.QualifiedItemId == "(F)724" || base.QualifiedItemId == "(F)727") && !base.name.Contains("End Table") && !base.name.Contains("EndTable");
			bool flag2 = defaultBoundingBox.Width != defaultBoundingBox.Height;
			if (flag && currentRotation.Value == 2)
			{
				currentRotation.Value = 1;
			}
			if (flag2)
			{
				int height = boundingBox.Height;
				switch (currentRotation.Value)
				{
				case 0:
				case 2:
					boundingBox.Height = defaultBoundingBox.Height;
					boundingBox.Width = defaultBoundingBox.Width;
					break;
				case 1:
				case 3:
					boundingBox.Height = boundingBox.Width + zero.X * 64;
					boundingBox.Width = height + zero.Y * 64;
					break;
				}
			}
			Point val = (Point)((furniture_type.Value == 12) ? new Point(1, -1) : Point.Zero);
			if (flag2)
			{
				switch (currentRotation.Value)
				{
				case 0:
					sourceRect.Value = defaultSourceRect.Value;
					break;
				case 1:
					sourceRect.Value = new Rectangle(defaultSourceRect.X + defaultSourceRect.Width, defaultSourceRect.Y, defaultSourceRect.Height - 16 + zero.Y * 16 + val.X * 16, defaultSourceRect.Width + 16 + zero.X * 16 + val.Y * 16);
					break;
				case 2:
					sourceRect.Value = new Rectangle(defaultSourceRect.X + defaultSourceRect.Width + defaultSourceRect.Height - 16 + zero.Y * 16 + val.X * 16, defaultSourceRect.Y, defaultSourceRect.Width, defaultSourceRect.Height);
					break;
				case 3:
					sourceRect.Value = new Rectangle(defaultSourceRect.X + defaultSourceRect.Width, defaultSourceRect.Y, defaultSourceRect.Height - 16 + zero.Y * 16 + val.X * 16, defaultSourceRect.Width + 16 + zero.X * 16 + val.Y * 16);
					flipped.Value = true;
					break;
				}
			}
			else
			{
				flipped.Value = currentRotation.Value == 3;
				if (rotations.Value == 2)
				{
					sourceRect.Value = new Rectangle(defaultSourceRect.X + ((currentRotation.Value == 2) ? 1 : 0) * defaultSourceRect.Width, defaultSourceRect.Y, defaultSourceRect.Width, defaultSourceRect.Height);
				}
				else
				{
					sourceRect.Value = new Rectangle(defaultSourceRect.X + ((currentRotation.Value == 3) ? 1 : currentRotation.Value) * defaultSourceRect.Width, defaultSourceRect.Y, defaultSourceRect.Width, defaultSourceRect.Height);
				}
			}
			if (flag && currentRotation.Value == 1)
			{
				currentRotation.Value = 2;
			}
		}
		else
		{
			sourceRect.Value = defaultSourceRect.Value;
			boundingBox.Value = defaultBoundingBox.Value;
		}
		updateDrawPosition();
	}

	public virtual bool isGroundFurniture()
	{
		if (furniture_type.Value != 13 && furniture_type.Value != 6 && furniture_type.Value != 17)
		{
			return furniture_type.Value != 13;
		}
		return false;
	}

	public override bool canBeGivenAsGift()
	{
		return false;
	}

	public static Furniture GetFurnitureInstance(string itemId, Vector2? position = null)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		if (!position.HasValue)
		{
			position = Vector2.Zero;
		}
		switch (itemId)
		{
		case "1466":
		case "1468":
		case "1680":
		case "2326":
		case "RetroTV":
			return new TV(itemId, position.Value);
		default:
		{
			string text = ArgUtility.Get(getData(itemId), 1);
			switch (text)
			{
			case "fishtank":
				return new FishTankFurniture(itemId, position.Value);
			case "dresser":
				return new StorageFurniture(itemId, position.Value);
			case "randomized_plant":
				return new RandomizedPlantFurniture(itemId, position.Value);
			default:
				if (text?.StartsWith("bed") ?? false)
				{
					return new BedFurniture(itemId, position.Value);
				}
				return new Furniture(itemId, position.Value);
			}
		}
		}
	}

	public virtual bool IsCloseEnoughToFarmer(Farmer f, int? override_tile_x = null, int? override_tile_y = null)
	{
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		Rectangle val = default(Rectangle);
		((Rectangle)(ref val))._002Ector((int)tileLocation.X * 64, (int)tileLocation.Y * 64, getTilesWide() * 64, getTilesHigh() * 64);
		if (override_tile_x.HasValue)
		{
			val.X = override_tile_x.Value * 64;
		}
		if (override_tile_y.HasValue)
		{
			val.Y = override_tile_y.Value * 64;
		}
		((Rectangle)(ref val)).Inflate(96, 96);
		return ((Rectangle)(ref val)).Contains(Game1.player.StandingPixel);
	}

	public virtual int GetModifiedWallTilePosition(GameLocation l, int tile_x, int tile_y)
	{
		if (isGroundFurniture())
		{
			return tile_y;
		}
		if (l != null)
		{
			if (l is DecoratableLocation decoratableLocation)
			{
				int wallTopY = decoratableLocation.GetWallTopY(tile_x, tile_y);
				if (wallTopY != -1)
				{
					return wallTopY;
				}
			}
			return tile_y;
		}
		return tile_y;
	}

	public override bool canBePlacedHere(GameLocation l, Vector2 tile, CollisionMask collisionMask = CollisionMask.All, bool showError = false)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		if (!l.CanPlaceThisFurnitureHere(this))
		{
			return false;
		}
		if (!isGroundFurniture())
		{
			tile.Y = GetModifiedWallTilePosition(l, (int)tile.X, (int)tile.Y);
		}
		CollisionMask collisionMask2 = CollisionMask.Buildings | CollisionMask.Flooring | CollisionMask.TerrainFeatures;
		bool flag = isPassable();
		if (flag)
		{
			collisionMask2 |= CollisionMask.Characters | CollisionMask.Farmers;
		}
		collisionMask &= ~(CollisionMask.Furniture | CollisionMask.Objects);
		int tilesWide = getTilesWide();
		int tilesHigh = getTilesHigh();
		Vector2 val = default(Vector2);
		for (int i = 0; i < tilesWide; i++)
		{
			for (int j = 0; j < tilesHigh; j++)
			{
				((Vector2)(ref val))._002Ector(tile.X + (float)i, tile.Y + (float)j);
				Vector2 val2 = new Vector2(val.X + 0.5f, val.Y + 0.5f) * 64f;
				if (!l.isTilePlaceable(val, flag))
				{
					return false;
				}
				foreach (Furniture item in l.furniture)
				{
					Rectangle val3;
					if (item.furniture_type.Value == 11)
					{
						val3 = item.GetBoundingBox();
						if (((Rectangle)(ref val3)).Contains((int)val2.X, (int)val2.Y) && item.heldObject.Value == null && tilesWide == 1 && tilesHigh == 1)
						{
							return true;
						}
					}
					if (item.furniture_type.Value != 12 || furniture_type.Value == 12)
					{
						val3 = item.GetBoundingBox();
						if (((Rectangle)(ref val3)).Contains((int)val2.X, (int)val2.Y) && !item.AllowPlacementOnThisTile((int)tile.X + i, (int)tile.Y + j))
						{
							return false;
						}
					}
				}
				if (l.objects.TryGetValue(val, out var value) && (!value.isPassable() || !isPassable()))
				{
					return false;
				}
				if (!isGroundFurniture())
				{
					if (l.IsTileOccupiedBy(val, collisionMask, collisionMask2))
					{
						return false;
					}
					continue;
				}
				if (furniture_type.Value == 15 && j == 0)
				{
					if (l.IsTileOccupiedBy(val, collisionMask, collisionMask2))
					{
						return false;
					}
					continue;
				}
				if (l.IsTileBlockedBy(val, collisionMask, collisionMask2))
				{
					return false;
				}
				if (l.terrainFeatures.GetValueOrDefault(val) is HoeDirt { crop: not null })
				{
					return false;
				}
			}
		}
		if (GetAdditionalFurniturePlacementStatus(l, (int)tile.X * 64, (int)tile.Y * 64) != 0)
		{
			return false;
		}
		return true;
	}

	public virtual void updateDrawPosition()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		drawPosition.Value = new Vector2((float)boundingBox.X, (float)(boundingBox.Y - (sourceRect.Height * 4 - boundingBox.Height)));
	}

	public virtual int getTilesWide()
	{
		return boundingBox.Width / 64;
	}

	public virtual int getTilesHigh()
	{
		return boundingBox.Height / 64;
	}

	public override bool placementAction(GameLocation location, int x, int y, Farmer who = null)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		if (!isGroundFurniture())
		{
			y = GetModifiedWallTilePosition(location, x / 64, y / 64) * 64;
		}
		if (GetAdditionalFurniturePlacementStatus(location, x, y, who) != 0)
		{
			return false;
		}
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(x / 64), (float)(y / 64));
		if (TileLocation != val)
		{
			TileLocation = val;
		}
		else
		{
			RecalculateBoundingBox();
		}
		foreach (Furniture item in location.furniture)
		{
			if (item.furniture_type.Value == 11 && item.heldObject.Value == null)
			{
				Rectangle val2 = item.GetBoundingBox();
				if (((Rectangle)(ref val2)).Intersects(boundingBox.Value))
				{
					item.performObjectDropInAction(this, probe: false, who ?? Game1.player);
					return true;
				}
			}
		}
		return base.placementAction(location, x, y, who);
	}

	public virtual int GetAdditionalFurniturePlacementStatus(GameLocation location, int x, int y, Farmer who = null)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		if (location.CanPlaceThisFurnitureHere(this))
		{
			Point val = default(Point);
			((Point)(ref val))._002Ector(x / 64, y / 64);
			tileLocation.Value = new Vector2((float)val.X, (float)val.Y);
			bool flag = false;
			if (furniture_type.Value == 6 || furniture_type.Value == 17 || furniture_type.Value == 13 || base.QualifiedItemId == "(F)1293")
			{
				int num = ((base.QualifiedItemId == "(F)1293") ? 3 : 0);
				bool flag2 = false;
				if (location is DecoratableLocation decoratableLocation)
				{
					if ((furniture_type.Value == 6 || furniture_type.Value == 17 || furniture_type.Value == 13 || num != 0) && decoratableLocation.isTileOnWall(val.X, val.Y - num) && decoratableLocation.GetWallTopY(val.X, val.Y - num) + num == val.Y)
					{
						flag2 = true;
					}
					else if (!isGroundFurniture() && decoratableLocation.isTileOnWall(val.X, val.Y - 1) && decoratableLocation.GetWallTopY(val.X, val.Y) + 1 == val.Y)
					{
						flag2 = true;
					}
				}
				if (!flag2)
				{
					return 1;
				}
				flag = true;
			}
			int num2 = getTilesHigh();
			if (furniture_type.Value == 6 && num2 > 2)
			{
				num2 = 2;
			}
			for (int i = val.X; i < val.X + getTilesWide(); i++)
			{
				for (int j = val.Y; j < val.Y + num2; j++)
				{
					if (location.doesTileHaveProperty(i, j, "NoFurniture", "Back") != null)
					{
						return 2;
					}
					if (!flag && location is DecoratableLocation decoratableLocation2 && decoratableLocation2.isTileOnWall(i, j))
					{
						if (!(this is BedFurniture) || j != val.Y)
						{
							return 3;
						}
						continue;
					}
					int tileIndexAt = location.getTileIndexAt(i, j, "Buildings");
					if (tileIndexAt != -1 && (!(location is IslandFarmHouse) || tileIndexAt < 192 || tileIndexAt > 194 || !(location.getTileSheetIDAt(i, j, "Buildings") == "untitled tile sheet")))
					{
						return -1;
					}
				}
			}
			return 0;
		}
		return 4;
	}

	public override bool isPassable()
	{
		if (furniture_type.Value == 12)
		{
			return true;
		}
		return base.isPassable();
	}

	public override bool isPlaceable()
	{
		return true;
	}

	public virtual bool AllowPlacementOnThisTile(int tile_x, int tile_y)
	{
		return false;
	}

	public override Rectangle GetBoundingBoxAt(int x, int y)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		if (isTemporarilyInvisible)
		{
			return Rectangle.Empty;
		}
		return boundingBox.Value;
	}

	protected static Rectangle getDefaultSourceRectForType(ParsedItemData itemData, int type, Texture2D texture = null)
	{
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		int spriteWidth;
		int spriteHeight;
		switch (type)
		{
		case 0:
			spriteWidth = 1;
			spriteHeight = 2;
			break;
		case 1:
			spriteWidth = 2;
			spriteHeight = 2;
			break;
		case 2:
			spriteWidth = 3;
			spriteHeight = 2;
			break;
		case 3:
			spriteWidth = 2;
			spriteHeight = 2;
			break;
		case 4:
			spriteWidth = 2;
			spriteHeight = 2;
			break;
		case 5:
			spriteWidth = 5;
			spriteHeight = 3;
			break;
		case 6:
			spriteWidth = 2;
			spriteHeight = 2;
			break;
		case 17:
			spriteWidth = 1;
			spriteHeight = 2;
			break;
		case 7:
			spriteWidth = 1;
			spriteHeight = 3;
			break;
		case 8:
			spriteWidth = 1;
			spriteHeight = 2;
			break;
		case 10:
			spriteWidth = 2;
			spriteHeight = 3;
			break;
		case 11:
			spriteWidth = 2;
			spriteHeight = 3;
			break;
		case 12:
			spriteWidth = 3;
			spriteHeight = 2;
			break;
		case 13:
			spriteWidth = 1;
			spriteHeight = 2;
			break;
		case 14:
			spriteWidth = 2;
			spriteHeight = 5;
			break;
		case 16:
			spriteWidth = 1;
			spriteHeight = 2;
			break;
		default:
			spriteWidth = 1;
			spriteHeight = 2;
			break;
		}
		return getDefaultSourceRect(itemData, spriteWidth, spriteHeight, texture);
	}

	protected static Rectangle getDefaultSourceRect(ParsedItemData itemData, int spriteWidth, int spriteHeight, Texture2D texture = null)
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		texture = texture ?? itemData.GetTexture();
		return new Rectangle(itemData.SpriteIndex * 16 % texture.Width, itemData.SpriteIndex * 16 / texture.Width * 16, spriteWidth * 16, spriteHeight * 16);
	}

	protected virtual Rectangle getDefaultBoundingBoxForType(int type)
	{
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		int num;
		int num2;
		switch (type)
		{
		case 0:
			num = 1;
			num2 = 1;
			break;
		case 1:
			num = 2;
			num2 = 1;
			break;
		case 2:
			num = 3;
			num2 = 1;
			break;
		case 3:
			num = 2;
			num2 = 1;
			break;
		case 4:
			num = 2;
			num2 = 1;
			break;
		case 5:
			num = 5;
			num2 = 2;
			break;
		case 6:
			num = 2;
			num2 = 2;
			break;
		case 17:
			num = 1;
			num2 = 2;
			break;
		case 7:
			num = 1;
			num2 = 1;
			break;
		case 8:
			num = 1;
			num2 = 1;
			break;
		case 10:
			num = 2;
			num2 = 1;
			break;
		case 11:
			num = 2;
			num2 = 2;
			break;
		case 12:
			num = 3;
			num2 = 2;
			break;
		case 13:
			num = 1;
			num2 = 2;
			break;
		case 14:
			num = 2;
			num2 = 1;
			break;
		case 16:
			num = 1;
			num2 = 1;
			break;
		default:
			num = 1;
			num2 = 1;
			break;
		}
		return new Rectangle((int)tileLocation.X * 64, (int)tileLocation.Y * 64, num * 64, num2 * 64);
	}

	public static int getTypeNumberFromName(string typeName)
	{
		if (typeName.StartsWithIgnoreCase("bed"))
		{
			return 15;
		}
		return typeName.ToLower() switch
		{
			"chair" => 0, 
			"bench" => 1, 
			"couch" => 2, 
			"armchair" => 3, 
			"dresser" => 4, 
			"long table" => 5, 
			"painting" => 6, 
			"lamp" => 7, 
			"decor" => 8, 
			"bookcase" => 10, 
			"table" => 11, 
			"rug" => 12, 
			"window" => 13, 
			"fireplace" => 14, 
			"torch" => 16, 
			"sconce" => 17, 
			_ => 9, 
		};
	}

	public override int salePrice(bool ignoreProfitMargins = false)
	{
		return price.Value;
	}

	public override int maximumStackSize()
	{
		return 1;
	}

	protected virtual float getScaleSize()
	{
		int num = defaultSourceRect.Width / 16;
		int num2 = defaultSourceRect.Height / 16;
		if (num >= 7)
		{
			return 0.5f;
		}
		if (num >= 6)
		{
			return 0.66f;
		}
		if (num >= 5)
		{
			return 0.75f;
		}
		if (num2 >= 5)
		{
			return 0.8f;
		}
		if (num2 >= 3)
		{
			return 1f;
		}
		if (num <= 2)
		{
			return 2f;
		}
		if (num <= 4)
		{
			return 1f;
		}
		return 0.1f;
	}

	public override void updateWhenCurrentLocation(GameTime time)
	{
		if (Location == null)
		{
			return;
		}
		if (Game1.IsMasterGame && sittingFarmers.Length > 0)
		{
			List<long> list = null;
			foreach (long key in sittingFarmers.Keys)
			{
				if (!Game1.player.team.playerIsOnline(key))
				{
					if (list == null)
					{
						list = new List<long>();
					}
					list.Add(key);
				}
			}
			if (list != null)
			{
				foreach (long item in list)
				{
					sittingFarmers.Remove(item);
				}
			}
		}
		if (shakeTimer > 0)
		{
			shakeTimer -= time.ElapsedGameTime.Milliseconds;
		}
		if (base.IsOn && base.SpecialVariable == 388859)
		{
			lastNoteBlockSoundTime += (int)time.ElapsedGameTime.TotalMilliseconds;
			if (lastNoteBlockSoundTime > 500)
			{
				lastNoteBlockSoundTime = 0;
				addCauldronBubbles();
			}
		}
	}

	private void addCauldronBubbles(float speed = -0.5f)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		Location.temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(372, 1956, 10, 10), TileLocation * 64f + new Vector2(41.6f, -21f) + new Vector2((float)Game1.random.Next(-12, 21), (float)Game1.random.Next(16)), flipped: false, 0.002f, Color.Lime)
		{
			alphaFade = 0.001f - speed / 300f,
			alpha = 0.75f,
			motion = new Vector2(0f, speed),
			acceleration = new Vector2(0f, 0f),
			interval = 99999f,
			layerDepth = (float)(boundingBox.Bottom - 3 - Game1.random.Next(5)) / 10000f,
			scale = 3f,
			scaleChange = 0.01f,
			rotationChange = (float)Game1.random.Next(-5, 6) * (float)Math.PI / 256f
		});
	}

	public override void drawWhenHeld(SpriteBatch spriteBatch, Vector2 objectPosition, Farmer f)
	{
	}

	public override void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		AdjustMenuDrawForRecipes(ref transparency, ref scaleSize);
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
		Rectangle val = dataOrErrorItem.GetSourceRect();
		spriteBatch.Draw(dataOrErrorItem.GetTexture(), location + new Vector2(32f, 32f), (Rectangle?)dataOrErrorItem.GetSourceRect(), color * transparency, 0f, new Vector2((float)(val.Width / 2), (float)(val.Height / 2)), 1f * getScaleSize() * scaleSize, (SpriteEffects)0, layerDepth);
		DrawMenuIcons(spriteBatch, location, scaleSize, transparency, layerDepth, drawStackNumber, color);
	}

	public override void draw(SpriteBatch spriteBatch, int x, int y, float alpha = 1f)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_0378: Unknown result type (might be due to invalid IL or missing references)
		//IL_037d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_038a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0505: Unknown result type (might be due to invalid IL or missing references)
		//IL_0452: Unknown result type (might be due to invalid IL or missing references)
		//IL_045d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0471: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_070f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0714: Unknown result type (might be due to invalid IL or missing references)
		//IL_071c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0727: Unknown result type (might be due to invalid IL or missing references)
		//IL_073b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0749: Unknown result type (might be due to invalid IL or missing references)
		//IL_074e: Unknown result type (might be due to invalid IL or missing references)
		//IL_079c: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0805: Unknown result type (might be due to invalid IL or missing references)
		//IL_080a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0858: Unknown result type (might be due to invalid IL or missing references)
		//IL_0862: Unknown result type (might be due to invalid IL or missing references)
		//IL_086c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_098d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0998: Unknown result type (might be due to invalid IL or missing references)
		//IL_099d: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0946: Unknown result type (might be due to invalid IL or missing references)
		//IL_0950: Unknown result type (might be due to invalid IL or missing references)
		//IL_095a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Unknown result type (might be due to invalid IL or missing references)
		//IL_0529: Unknown result type (might be due to invalid IL or missing references)
		//IL_0538: Unknown result type (might be due to invalid IL or missing references)
		//IL_053d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0547: Unknown result type (might be due to invalid IL or missing references)
		//IL_0551: Unknown result type (might be due to invalid IL or missing references)
		//IL_0558: Unknown result type (might be due to invalid IL or missing references)
		//IL_0567: Unknown result type (might be due to invalid IL or missing references)
		//IL_056c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0570: Unknown result type (might be due to invalid IL or missing references)
		//IL_0580: Unknown result type (might be due to invalid IL or missing references)
		//IL_0585: Unknown result type (might be due to invalid IL or missing references)
		//IL_0589: Unknown result type (might be due to invalid IL or missing references)
		//IL_0594: Unknown result type (might be due to invalid IL or missing references)
		//IL_049f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0656: Unknown result type (might be due to invalid IL or missing references)
		//IL_0661: Unknown result type (might be due to invalid IL or missing references)
		//IL_0675: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0694: Unknown result type (might be due to invalid IL or missing references)
		//IL_0699: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0615: Unknown result type (might be due to invalid IL or missing references)
		//IL_061a: Unknown result type (might be due to invalid IL or missing references)
		//IL_063e: Unknown result type (might be due to invalid IL or missing references)
		if (isTemporarilyInvisible)
		{
			return;
		}
		Rectangle value = sourceRect.Value;
		value.X += value.Width * sourceIndexOffset.Value;
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
		Texture2D texture = dataOrErrorItem.GetTexture();
		string textureName = dataOrErrorItem.TextureName;
		if (dataOrErrorItem.IsErrorItem)
		{
			value = dataOrErrorItem.GetSourceRect();
		}
		if (_frontTextureName == null)
		{
			_frontTextureName = new Dictionary<string, string>();
		}
		Rectangle val6;
		if (isDrawingLocationFurniture)
		{
			if (!_frontTextureName.TryGetValue(textureName, out var value2))
			{
				value2 = textureName + "Front";
				_frontTextureName[textureName] = value2;
			}
			Texture2D val = null;
			if (HasSittingFarmers() || base.SpecialVariable == 388859)
			{
				try
				{
					val = Game1.content.Load<Texture2D>(value2);
				}
				catch
				{
					val = null;
				}
			}
			Vector2 val2 = Game1.GlobalToLocal(Game1.viewport, drawPosition.Value + (Vector2)((shakeTimer > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero));
			SpriteEffects val3 = (SpriteEffects)(flipped.Value ? 1 : 0);
			Color val4 = Color.White * alpha;
			if (HasSittingFarmers())
			{
				Rectangle? val5 = value;
				Vector2 zero = Vector2.Zero;
				val6 = boundingBox.Value;
				spriteBatch.Draw(texture, val2, val5, val4, 0f, zero, 4f, val3, (float)(((Rectangle)(ref val6)).Top + 16) / 10000f);
				if (val != null && ((Rectangle)(ref value)).Right <= val.Width && ((Rectangle)(ref value)).Bottom <= val.Height)
				{
					Texture2D obj2 = val;
					Rectangle? val7 = value;
					Vector2 zero2 = Vector2.Zero;
					val6 = boundingBox.Value;
					spriteBatch.Draw(obj2, val2, val7, val4, 0f, zero2, 4f, val3, (float)(((Rectangle)(ref val6)).Bottom - 8) / 10000f);
				}
			}
			else
			{
				Rectangle? val8 = value;
				Vector2 zero3 = Vector2.Zero;
				float num;
				if (furniture_type.Value != 12)
				{
					val6 = boundingBox.Value;
					num = (float)(((Rectangle)(ref val6)).Bottom - ((furniture_type.Value == 6 || furniture_type.Value == 17 || furniture_type.Value == 13) ? 48 : 8)) / 10000f;
				}
				else
				{
					num = 2E-09f + tileLocation.Y / 100000f;
				}
				spriteBatch.Draw(texture, val2, val8, val4, 0f, zero3, 4f, val3, num);
				if (base.SpecialVariable == 388859 && val != null && ((Rectangle)(ref value)).Right <= val.Width && ((Rectangle)(ref value)).Bottom <= val.Height)
				{
					Texture2D obj3 = val;
					Rectangle? val9 = value;
					Vector2 zero4 = Vector2.Zero;
					val6 = boundingBox.Value;
					spriteBatch.Draw(obj3, val2, val9, val4, 0f, zero4, 4f, val3, (float)(((Rectangle)(ref val6)).Bottom - 2) / 10000f);
				}
			}
		}
		else
		{
			Vector2 val10 = Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0)), (float)(y * 64 - (value.Height * 4 - boundingBox.Height) + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0))));
			Rectangle? val11 = value;
			Color val12 = Color.White * alpha;
			Vector2 zero5 = Vector2.Zero;
			int num2 = (flipped.Value ? 1 : 0);
			float num3;
			if (furniture_type.Value != 12)
			{
				val6 = boundingBox.Value;
				num3 = (float)(((Rectangle)(ref val6)).Bottom - ((furniture_type.Value == 6 || furniture_type.Value == 17 || furniture_type.Value == 13) ? 48 : 8)) / 10000f;
			}
			else
			{
				num3 = 2E-09f + tileLocation.Y / 100000f;
			}
			spriteBatch.Draw(texture, val10, val11, val12, 0f, zero5, 4f, (SpriteEffects)num2, num3);
		}
		if (heldObject.Value != null)
		{
			if (heldObject.Value is Furniture furniture)
			{
				furniture.drawAtNonTileSpot(spriteBatch, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(boundingBox.Center.X - 32), (float)(boundingBox.Center.Y - furniture.sourceRect.Height * 4 - (drawHeldObjectLow.Value ? (-16) : 16)))), (float)(boundingBox.Bottom - 7) / 10000f, alpha);
			}
			else
			{
				ParsedItemData dataOrErrorItem2 = ItemRegistry.GetDataOrErrorItem(heldObject.Value.QualifiedItemId);
				Texture2D shadowTexture = Game1.shadowTexture;
				Vector2 val13 = Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(boundingBox.Center.X - 32), (float)(boundingBox.Center.Y - (drawHeldObjectLow.Value ? 32 : 85)))) + new Vector2(32f, 53f);
				Rectangle? val14 = Game1.shadowTexture.Bounds;
				Color val15 = Color.White * alpha;
				val6 = Game1.shadowTexture.Bounds;
				float num4 = ((Rectangle)(ref val6)).Center.X;
				val6 = Game1.shadowTexture.Bounds;
				spriteBatch.Draw(shadowTexture, val13, val14, val15, 0f, new Vector2(num4, (float)((Rectangle)(ref val6)).Center.Y), 4f, (SpriteEffects)0, (float)boundingBox.Bottom / 10000f);
				if (heldObject.Value is ColoredObject)
				{
					heldObject.Value.drawInMenu(spriteBatch, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(boundingBox.Center.X - 32), (float)(boundingBox.Center.Y - (drawHeldObjectLow.Value ? 32 : 85)))), 1f, 1f, (float)(boundingBox.Bottom + 1) / 10000f, StackDrawType.Hide, Color.White, drawShadow: false);
				}
				else
				{
					spriteBatch.Draw(dataOrErrorItem2.GetTexture(), Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(boundingBox.Center.X - 32), (float)(boundingBox.Center.Y - (drawHeldObjectLow.Value ? 32 : 85)))), (Rectangle?)dataOrErrorItem2.GetSourceRect(), Color.White * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(boundingBox.Bottom + 1) / 10000f);
				}
			}
		}
		if (isOn.Value && furniture_type.Value == 14)
		{
			Rectangle boundingBoxAt = GetBoundingBoxAt(x, y);
			spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(boundingBox.Center.X - 12), (float)(boundingBox.Center.Y - 64))), (Rectangle?)new Rectangle(276 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 3047) + (double)(y * 88)) % 400.0 / 100.0) * 12, 1985, 12, 11), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(((Rectangle)(ref boundingBoxAt)).Bottom - 2) / 10000f);
			spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(boundingBox.Center.X - 32 - 4), (float)(boundingBox.Center.Y - 64))), (Rectangle?)new Rectangle(276 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 2047) + (double)(y * 98)) % 400.0 / 100.0) * 12, 1985, 12, 11), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(((Rectangle)(ref boundingBoxAt)).Bottom - 1) / 10000f);
		}
		else if (isOn.Value && furniture_type.Value == 16)
		{
			Rectangle boundingBoxAt2 = GetBoundingBoxAt(x, y);
			spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(boundingBox.Center.X - 20), (float)boundingBox.Center.Y - 105.6f)), (Rectangle?)new Rectangle(276 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 3047) + (double)(y * 88)) % 400.0 / 100.0) * 12, 1985, 12, 11), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(((Rectangle)(ref boundingBoxAt2)).Bottom - 2) / 10000f);
		}
		if (Game1.debugMode)
		{
			spriteBatch.DrawString(Game1.smallFont, base.QualifiedItemId, Game1.GlobalToLocal(Game1.viewport, drawPosition.Value), Color.Yellow, 0f, Vector2.Zero, 1f, (SpriteEffects)0, 1f);
		}
	}

	public virtual void drawAtNonTileSpot(SpriteBatch spriteBatch, Vector2 location, float layerDepth, float alpha = 1f)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
		Rectangle value = sourceRect.Value;
		value.X += value.Width * sourceIndexOffset.Value;
		if (dataOrErrorItem.IsErrorItem)
		{
			value = dataOrErrorItem.GetSourceRect();
		}
		spriteBatch.Draw(dataOrErrorItem.GetTexture(), location, (Rectangle?)value, Color.White * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)(flipped.Value ? 1 : 0), layerDepth);
	}

	public virtual int GetAdditionalTilePropertyRadius()
	{
		return 0;
	}

	public virtual bool DoesTileHaveProperty(int tile_x, int tile_y, string property_name, string layer_name, ref string property_value)
	{
		return false;
	}

	public virtual bool IntersectsForCollision(Rectangle rect)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		Rectangle val = GetBoundingBox();
		return ((Rectangle)(ref val)).Intersects(rect);
	}

	protected override Item GetOneNew()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		return new Furniture(base.ItemId, tileLocation.Value);
	}

	protected override void GetOneCopyFrom(Item source)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		base.GetOneCopyFrom(source);
		if (source is Furniture furniture)
		{
			drawPosition.Value = furniture.drawPosition.Value;
			defaultBoundingBox.Value = furniture.defaultBoundingBox.Value;
			boundingBox.Value = furniture.boundingBox.Value;
			isOn.Value = false;
			rotations.Value = furniture.rotations.Value;
			currentRotation.Value = furniture.currentRotation.Value - ((rotations.Value == 4) ? 1 : 2);
			rotate();
		}
	}
}
