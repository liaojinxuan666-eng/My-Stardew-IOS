using System;
using System.Text;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Buffs;
using StardewValley.Extensions;
using StardewValley.GameData.Objects;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Locations;
using StardewValley.Monsters;

namespace StardewValley.Objects;

[XmlInclude(typeof(CombinedRing))]
public class Ring : Item
{
	public const string SmallGlowRingId = "516";

	public const string GlowRingId = "517";

	public const string SmallMagnetRingId = "518";

	public const string MagnetRingId = "519";

	public const string SlimeCharmerRingId = "520";

	public const string WarriorRingId = "521";

	public const string VampireRingId = "522";

	public const string SavageRingId = "523";

	public const string YobaRingId = "524";

	public const string SturdyRingId = "525";

	public const string BurglarsRingId = "526";

	public const string IridiumBandId = "527";

	public const string AmethystRingId = "529";

	public const string TopazRingId = "530";

	public const string AquamarineRingId = "531";

	public const string JadeRingId = "532";

	public const string EmeraldRingId = "533";

	public const string RubyRingId = "534";

	public const string WeddingRingId = "801";

	public const string CrabshellRingId = "810";

	public const string NapalmRingId = "811";

	public const string ThornsRingId = "839";

	public const string LuckyRingId = "859";

	public const string HotJavaRingId = "860";

	public const string ProtectiveRingId = "861";

	public const string SoulSapperRingId = "862";

	public const string PhoenixRingId = "863";

	public const string CombinedRingId = "880";

	public const string ImmunityBandId = "887";

	public const string GlowstoneRingId = "888";

	[XmlElement("price")]
	public readonly NetInt price = new NetInt();

	[XmlElement("indexInTileSheet")]
	public int? obsolete_indexInTileSheet;

	[XmlIgnore]
	public string description;

	[XmlIgnore]
	public string displayName;

	[XmlIgnore]
	public string lightSourceId;

	public override string TypeDefinitionId { get; } = "(O)";

	[XmlIgnore]
	public override string DisplayName
	{
		get
		{
			if (displayName == null)
			{
				loadDisplayFields();
			}
			return displayName;
		}
	}

	protected override void MigrateLegacyItemId()
	{
		itemId.Value = obsolete_indexInTileSheet?.ToString() ?? base.ParentSheetIndex.ToString();
		obsolete_indexInTileSheet = null;
	}

	public Ring()
	{
	}

	public Ring(string itemId)
		: this()
	{
		itemId = ValidateUnqualifiedItemId(itemId);
		ObjectData val = Game1.objectData[itemId];
		base.ItemId = itemId;
		base.Category = -96;
		Name = val.Name ?? ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId).InternalName;
		price.Value = val.Price;
		ResetParentSheetIndex();
		loadDisplayFields();
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(price, "price");
	}

	public override bool CanBeLostOnDeath()
	{
		return false;
	}

	public override void onEquip(Farmer who)
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		base.onEquip(who);
		GameLocation currentLocation = who.currentLocation;
		currentLocation.removeLightSource(lightSourceId);
		lightSourceId = null;
		switch (base.ItemId)
		{
		case "516":
			lightSourceId = GenerateLightSourceId(who);
			currentLocation.sharedLights.AddLight(new LightSource(lightSourceId, 1, new Vector2(who.Position.X + 21f, who.Position.Y + 64f), 5f, new Color(0, 50, 170), LightSource.LightContext.None, who.UniqueMultiplayerID));
			break;
		case "517":
			lightSourceId = GenerateLightSourceId(who);
			currentLocation.sharedLights.AddLight(new LightSource(lightSourceId, 1, new Vector2(who.Position.X + 21f, who.Position.Y + 64f), 10f, new Color(0, 30, 150), LightSource.LightContext.None, who.UniqueMultiplayerID));
			break;
		case "888":
		case "527":
			lightSourceId = GenerateLightSourceId(who);
			currentLocation.sharedLights.AddLight(new LightSource(lightSourceId, 1, new Vector2(who.Position.X + 21f, who.Position.Y + 64f), 10f, new Color(0, 80, 0), LightSource.LightContext.None, who.UniqueMultiplayerID));
			break;
		}
	}

	public override void onUnequip(Farmer who)
	{
		base.onUnequip(who);
		switch (base.ItemId)
		{
		case "516":
		case "517":
		case "888":
		case "527":
			who.currentLocation.removeLightSource(lightSourceId);
			lightSourceId = null;
			break;
		}
	}

	public override void AddEquipmentEffects(BuffEffects effects)
	{
		base.AddEquipmentEffects(effects);
		string text = base.ItemId;
		if (text == null)
		{
			return;
		}
		int length = text.Length;
		if (length != 3)
		{
			return;
		}
		switch (text[2])
		{
		case '8':
			if (!(text == "518"))
			{
				if (text == "888")
				{
					effects.MagneticRadius.Value += 128f;
				}
			}
			else
			{
				effects.MagneticRadius.Value += 64f;
			}
			break;
		case '9':
			switch (text)
			{
			case "519":
				effects.MagneticRadius.Value += 128f;
				break;
			case "529":
				effects.KnockbackMultiplier.Value += 0.1f;
				break;
			case "859":
				effects.LuckLevel.Value += 1f;
				break;
			}
			break;
		case '7':
			if (!(text == "527"))
			{
				if (text == "887")
				{
					effects.Immunity.Value += 4f;
				}
			}
			else
			{
				effects.MagneticRadius.Value += 128f;
				effects.AttackMultiplier.Value += 0.1f;
			}
			break;
		case '0':
			if (!(text == "530"))
			{
				if (text == "810")
				{
					effects.Defense.Value += 5f;
				}
			}
			else
			{
				effects.Defense.Value += 1f;
			}
			break;
		case '1':
			if (text == "531")
			{
				effects.CriticalChanceMultiplier.Value += 0.1f;
			}
			break;
		case '2':
			if (text == "532")
			{
				effects.CriticalPowerMultiplier.Value += 0.1f;
			}
			break;
		case '3':
			if (text == "533")
			{
				effects.WeaponSpeedMultiplier.Value += 0.1f;
			}
			break;
		case '4':
			if (text == "534")
			{
				effects.AttackMultiplier.Value += 0.1f;
			}
			break;
		case '5':
		case '6':
			break;
		}
	}

	public override string getCategoryName()
	{
		return Object.GetCategoryDisplayName(-96);
	}

	public virtual void onNewLocation(Farmer who, GameLocation environment)
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		environment.removeLightSource(lightSourceId);
		lightSourceId = null;
		switch (base.ItemId)
		{
		case "516":
		case "517":
		{
			GameLocation currentLocation = who.currentLocation;
			who.currentLocation = environment;
			onEquip(who);
			who.currentLocation = currentLocation;
			break;
		}
		case "888":
		case "527":
			lightSourceId = GenerateLightSourceId(who);
			environment.sharedLights.AddLight(new LightSource(lightSourceId, 1, new Vector2(who.Position.X + 21f, who.Position.Y + 64f), 10f, new Color(0, 30, 150), LightSource.LightContext.None, who.UniqueMultiplayerID));
			break;
		}
	}

	public virtual void onLeaveLocation(Farmer who, GameLocation environment)
	{
		switch (base.ItemId)
		{
		case "516":
		case "517":
		case "527":
		case "888":
			environment.removeLightSource(lightSourceId);
			lightSourceId = null;
			break;
		}
	}

	public override int salePrice(bool ignoreProfitMargins = false)
	{
		return price.Value;
	}

	public virtual void onMonsterSlay(Monster monster, GameLocation location, Farmer who)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		string text = base.ItemId;
		if (!(text == "811"))
		{
			if (text == "860")
			{
				if (Game1.random.NextBool(0.25))
				{
					monster?.objectsToDrop.Add("395");
				}
				else if (Game1.random.NextBool(0.1))
				{
					monster?.objectsToDrop.Add("253");
				}
			}
		}
		else if (monster != null)
		{
			location?.explode(monster.Tile, 2, who, damageFarmers: false, -1, !(location is Farm) && !(location is SlimeHutch));
		}
		if (!who.IsLocalPlayer)
		{
			return;
		}
		switch (base.ItemId)
		{
		case "521":
			if (Game1.random.NextBool(0.1 + (double)((float)who.LuckLevel / 100f)))
			{
				who.applyBuff("20");
				Game1.playSound("warrior");
			}
			break;
		case "522":
			who.health = Math.Min(who.maxHealth, who.health + 2);
			break;
		case "523":
			who.applyBuff("22");
			break;
		case "862":
			who.Stamina = Math.Min(who.MaxStamina, who.Stamina + 4f);
			break;
		}
	}

	public override void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		AdjustMenuDrawForRecipes(ref transparency, ref scaleSize);
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
		spriteBatch.Draw(dataOrErrorItem.GetTexture(), location + new Vector2(32f, 32f) * scaleSize, (Rectangle?)dataOrErrorItem.GetSourceRect(), color * transparency, 0f, new Vector2(8f, 8f) * scaleSize, scaleSize * 4f, (SpriteEffects)0, layerDepth);
		DrawMenuIcons(spriteBatch, location, scaleSize, transparency, layerDepth, drawStackNumber, color);
	}

	public virtual void update(GameTime time, GameLocation environment, Farmer who)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (lightSourceId == null)
		{
			return;
		}
		Vector2 val = Vector2.Zero;
		if (who.shouldShadowBeOffset)
		{
			val += who.drawOffset;
		}
		environment.repositionLightSource(lightSourceId, new Vector2(who.Position.X + 21f, who.Position.Y) + val);
		if (!environment.isOutdoors.Value && !(environment is MineShaft) && !(environment is VolcanoDungeon))
		{
			LightSource lightSource = environment.getLightSource(lightSourceId);
			if (lightSource != null)
			{
				lightSource.radius.Value = 3f;
			}
		}
	}

	public override int maximumStackSize()
	{
		return 1;
	}

	public override Point getExtraSpaceNeededForTooltipSpecialIcons(SpriteFont font, int minWidth, int horizontalBuffer, int startingHeight, StringBuilder descriptionText, string boldTitleText, int moneyAmountToDisplayAtBottom)
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		Point result = default(Point);
		((Point)(ref result))._002Ector(0, startingHeight);
		int num = 0;
		if (GetsEffectOfRing("810"))
		{
			num++;
		}
		if (GetsEffectOfRing("887") || GetsEffectOfRing("530"))
		{
			num++;
		}
		if (GetsEffectOfRing("859"))
		{
			num++;
		}
		result.X = (int)Math.Max(minWidth, font.MeasureString(Game1.content.LoadString("Strings\\UI:ItemHover_DefenseBonus", 9999)).X + (float)horizontalBuffer);
		result.Y += num * Math.Max((int)font.MeasureString("TT").Y, 48);
		return result;
	}

	public virtual bool GetsEffectOfRing(string ringId)
	{
		return base.ItemId == ringId;
	}

	public virtual int GetEffectsOfRingMultiplier(string ringId)
	{
		if (GetsEffectOfRing(ringId))
		{
			return 1;
		}
		return 0;
	}

	public override void drawTooltip(SpriteBatch spriteBatch, ref int x, ref int y, SpriteFont font, float alpha, StringBuilder overrideText)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0321: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0332: Unknown result type (might be due to invalid IL or missing references)
		//IL_0358: Unknown result type (might be due to invalid IL or missing references)
		if (description == null)
		{
			loadDisplayFields();
		}
		Utility.drawTextWithShadow(spriteBatch, Game1.parseText(description, Game1.smallFont, getDescriptionWidth()), font, new Vector2((float)(x + 16), (float)(y + 16 + 4)), Game1.textColor);
		y += (int)font.MeasureString(Game1.parseText(description, Game1.smallFont, getDescriptionWidth())).Y;
		if (GetsEffectOfRing("810") || GetsEffectOfRing("530"))
		{
			Utility.drawWithShadow(spriteBatch, Game1.mouseCursors, new Vector2((float)(x + 16 + 4), (float)(y + 16 + 4)), new Rectangle(110, 428, 10, 10), Color.White, 0f, Vector2.Zero, 4f, flipped: false, 1f);
			Utility.drawTextWithShadow(spriteBatch, Game1.content.LoadString("Strings\\UI:ItemHover_DefenseBonus", GetsEffectOfRing("810") ? (5 * GetEffectsOfRingMultiplier("810")) : GetEffectsOfRingMultiplier("530")), font, new Vector2((float)(x + 16 + 52), (float)(y + 16 + 12)), Game1.textColor * 0.9f * alpha);
			y += (int)Math.Max(font.MeasureString("TT").Y, 48f);
		}
		if (GetsEffectOfRing("887"))
		{
			Utility.drawWithShadow(spriteBatch, Game1.mouseCursors, new Vector2((float)(x + 16 + 4), (float)(y + 16 + 4)), new Rectangle(150, 428, 10, 10), Color.White, 0f, Vector2.Zero, 4f, flipped: false, 1f);
			Utility.drawTextWithShadow(spriteBatch, Game1.content.LoadString("Strings\\UI:ItemHover_ImmunityBonus", 4 * GetEffectsOfRingMultiplier("887")), font, new Vector2((float)(x + 16 + 52), (float)(y + 16 + 12)), Game1.textColor * 0.9f * alpha);
			y += (int)Math.Max(font.MeasureString("TT").Y, 48f);
		}
		if (GetsEffectOfRing("859"))
		{
			Utility.drawWithShadow(spriteBatch, Game1.mouseCursors, new Vector2((float)(x + 16 + 4), (float)(y + 16 + 4)), new Rectangle(50, 428, 10, 10), Color.White, 0f, Vector2.Zero, 4f, flipped: false, 1f);
			Utility.drawTextWithShadow(spriteBatch, "+" + Game1.content.LoadString("Strings\\UI:ItemHover_Buff4", GetEffectsOfRingMultiplier("859")), font, new Vector2((float)(x + 16 + 52), (float)(y + 16 + 12)), Game1.textColor * 0.9f * alpha);
			y += (int)Math.Max(font.MeasureString("TT").Y, 48f);
		}
	}

	public override string getDescription()
	{
		if (description == null)
		{
			loadDisplayFields();
		}
		return Game1.parseText(description, Game1.smallFont, getDescriptionWidth());
	}

	public override bool isPlaceable()
	{
		return false;
	}

	protected override Item GetOneNew()
	{
		return new Ring(base.ItemId);
	}

	protected virtual bool loadDisplayFields()
	{
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
		displayName = dataOrErrorItem.DisplayName;
		description = dataOrErrorItem.Description;
		return true;
	}

	public virtual bool CanCombine(Ring ring)
	{
		if (ring is CombinedRing || this is CombinedRing)
		{
			return false;
		}
		if (base.QualifiedItemId == ring.QualifiedItemId)
		{
			return false;
		}
		return true;
	}

	public Ring Combine(Ring ring)
	{
		return new CombinedRing
		{
			combinedRings = 
			{
				getOne() as Ring,
				ring.getOne() as Ring
			}
		};
	}
}
