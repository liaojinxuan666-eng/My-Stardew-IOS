using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.GameData.Machines;
using StardewValley.Locations;
using StardewValley.Tools;

namespace StardewValley.Objects;

public class Cask : Object
{
	public const int defaultDaysToMature = 56;

	[XmlElement("agingRate")]
	public readonly NetFloat agingRate = new NetFloat();

	[XmlElement("daysToMature")]
	public readonly NetFloat daysToMature = new NetFloat();

	public override string TypeDefinitionId => "(BC)";

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(agingRate, "agingRate").AddField(daysToMature, "daysToMature");
	}

	public Cask()
	{
	}

	public Cask(Vector2 v)
		: base(v, "163")
	{
	}//IL_0017: Unknown result type (might be due to invalid IL or missing references)


	public override bool performToolAction(Tool t)
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		if (t != null && t.isHeavyHitter() && !(t is MeleeWeapon))
		{
			if (heldObject.Value != null)
			{
				Game1.createItemDebris(heldObject.Value, tileLocation.Value * 64f, -1);
			}
			playNearbySoundAll("woodWhack");
			if (heldObject.Value == null)
			{
				return true;
			}
			heldObject.Value = null;
			readyForHarvest.Value = false;
			minutesUntilReady.Value = -1;
			return false;
		}
		return base.performToolAction(t);
	}

	public virtual bool IsValidCaskLocation()
	{
		GameLocation location = Location;
		if (location == null)
		{
			return false;
		}
		if (!(location is Cellar))
		{
			return location.HasMapPropertyWithValue("CanCaskHere");
		}
		return true;
	}

	public static Item OutputCask(Object machine, Item inputItem, bool probe, MachineItemOutput outputData, Farmer player, out int? overrideMinutesUntilReady)
	{
		overrideMinutesUntilReady = null;
		if (!(machine is Cask cask))
		{
			return null;
		}
		if (!cask.IsValidCaskLocation())
		{
			if (Object.autoLoadFrom == null && !probe)
			{
				Game1.showRedMessageUsingLoadString("Strings\\Objects:CaskNoCellar");
			}
			return null;
		}
		if (cask.quality.Value >= 4)
		{
			return null;
		}
		if (inputItem.Quality >= 4)
		{
			return null;
		}
		float result = 1f;
		if (outputData?.CustomData != null && outputData.CustomData.TryGetValue("AgingMultiplier", out var value) && (!float.TryParse(value, out result) || result <= 0f))
		{
			Game1.log.Error("Failed to parse cask aging multiplier '" + value + "' for trigger rule. This must be a positive float value.");
			return null;
		}
		if (result > 0f)
		{
			Object obj = (Object)inputItem.getOne();
			if (!probe)
			{
				cask.agingRate.Value = result;
				cask.daysToMature.Value = cask.GetDaysForQuality(obj.Quality);
				overrideMinutesUntilReady = ((obj.Quality >= 4) ? 1 : 999999);
				return obj;
			}
			return obj;
		}
		return null;
	}

	public override bool TryApplyFairyDust(bool probe = false)
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		if (heldObject.Value == null)
		{
			return false;
		}
		if (heldObject.Value.Quality == 4)
		{
			return false;
		}
		if (!probe)
		{
			Utility.addSprinklesToLocation(Location, (int)tileLocation.X, (int)tileLocation.Y, 1, 2, 400, 40, Color.White);
			Game1.playSound("yoba");
			daysToMature.Value = GetDaysForQuality(GetNextQuality(heldObject.Value.Quality));
			checkForMaturity();
		}
		return true;
	}

	public override void DayUpdate()
	{
		base.DayUpdate();
		if (heldObject.Value != null)
		{
			minutesUntilReady.Value = 999999;
			daysToMature.Value -= agingRate.Value;
			checkForMaturity();
		}
	}

	public float GetDaysForQuality(int quality)
	{
		return quality switch
		{
			4 => 0f, 
			2 => 28f, 
			1 => 42f, 
			_ => 56f, 
		};
	}

	public int GetNextQuality(int quality)
	{
		switch (quality)
		{
		case 2:
		case 4:
			return 4;
		case 1:
			return 2;
		default:
			return 1;
		}
	}

	public void checkForMaturity()
	{
		if (daysToMature.Value <= GetDaysForQuality(GetNextQuality(heldObject.Value.quality.Value)))
		{
			heldObject.Value.quality.Value = GetNextQuality(heldObject.Value.quality.Value);
			if (heldObject.Value.Quality == 4)
			{
				minutesUntilReady.Value = 1;
			}
		}
	}

	public override void draw(SpriteBatch spriteBatch, int x, int y, float alpha = 1f)
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		base.draw(spriteBatch, x, y, alpha);
		Object value = heldObject.Value;
		if (value != null && value.quality.Value > 0)
		{
			Vector2 val = (Vector2)((base.MinutesUntilReady > 0) ? new Vector2(Math.Abs(scale.X - 5f), Math.Abs(scale.Y - 5f)) : Vector2.Zero);
			val *= 4f;
			Vector2 val2 = Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)(y * 64 - 64)));
			Rectangle val3 = default(Rectangle);
			((Rectangle)(ref val3))._002Ector((int)(val2.X + 32f - 8f - val.X / 2f) + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0), (int)(val2.Y + 64f + 8f - val.Y / 2f) + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0), (int)(16f + val.X), (int)(16f + val.Y / 2f));
			spriteBatch.Draw(Game1.mouseCursors, val3, (Rectangle?)((heldObject.Value.quality.Value < 4) ? new Rectangle(338 + (heldObject.Value.quality.Value - 1) * 8, 400, 8, 8) : new Rectangle(346, 392, 8, 8)), Color.White * 0.95f, 0f, Vector2.Zero, (SpriteEffects)0, (float)((y + 1) * 64) / 10000f);
		}
	}
}
