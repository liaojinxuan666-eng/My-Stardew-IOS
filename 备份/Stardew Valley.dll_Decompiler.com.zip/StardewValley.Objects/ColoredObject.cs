using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.ItemTypeDefinitions;

namespace StardewValley.Objects;

public class ColoredObject : Object
{
	[XmlElement("color")]
	public readonly NetColor color = new NetColor();

	[XmlElement("colorSameIndexAsParentSheetIndex")]
	public readonly NetBool colorSameIndexAsParentSheetIndex = new NetBool();

	public bool ColorSameIndexAsParentSheetIndex
	{
		get
		{
			return colorSameIndexAsParentSheetIndex.Value;
		}
		set
		{
			colorSameIndexAsParentSheetIndex.Value = value;
		}
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(color, "color").AddField(colorSameIndexAsParentSheetIndex, "colorSameIndexAsParentSheetIndex");
	}

	public ColoredObject()
	{
	}

	public ColoredObject(string itemId, int stack, Color color)
		: base(itemId, stack)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		this.color.Value = color;
		if (Game1.objectData.TryGetValue(base.ItemId, out var value))
		{
			ColorSameIndexAsParentSheetIndex = !value.ColorOverlayFromNextIndex;
		}
	}

	public override void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color colorOverride, bool drawShadow)
	{
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		AdjustMenuDrawForRecipes(ref transparency, ref scaleSize);
		if (drawShadow && !bigCraftable.Value && base.QualifiedItemId != "(O)590" && base.QualifiedItemId != "(O)SeedSpot")
		{
			DrawShadow(spriteBatch, location, colorOverride, layerDepth);
		}
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.ItemId);
		Texture2D texture = dataOrErrorItem.GetTexture();
		Vector2 val = (bigCraftable.Value ? new Vector2(32f, 64f) : new Vector2(8f, 8f));
		float num = ((!bigCraftable.Value) ? (4f * scaleSize) : ((scaleSize < 0.2f) ? scaleSize : (scaleSize / 2f)));
		if (base.ItemId == "SmokedFish")
		{
			drawSmokedFish(spriteBatch, location, scaleSize, layerDepth, (transparency == 1f && ((Color)(ref colorOverride)).A < byte.MaxValue) ? ((float)(int)((Color)(ref colorOverride)).A / 255f) : transparency);
		}
		else if (!ColorSameIndexAsParentSheetIndex)
		{
			Rectangle sourceRect = dataOrErrorItem.GetSourceRect(1, base.ParentSheetIndex);
			transparency = ((transparency == 1f && ((Color)(ref colorOverride)).A < byte.MaxValue) ? ((float)(int)((Color)(ref colorOverride)).A / 255f) : transparency);
			spriteBatch.Draw(texture, location + new Vector2(32f, 32f) * scaleSize, (Rectangle?)dataOrErrorItem.GetSourceRect(0, base.ParentSheetIndex), Color.White * transparency, 0f, val * scaleSize, num, (SpriteEffects)0, layerDepth);
			spriteBatch.Draw(texture, location + new Vector2(32f, 32f) * scaleSize, (Rectangle?)sourceRect, color.Value * transparency, 0f, val * scaleSize, num, (SpriteEffects)0, Math.Min(1f, layerDepth + 2E-05f));
		}
		else
		{
			spriteBatch.Draw(texture, location + new Vector2(32f, 32f) * scaleSize, (Rectangle?)dataOrErrorItem.GetSourceRect(0, base.ParentSheetIndex), color.Value * transparency, 0f, val * scaleSize, num, (SpriteEffects)0, Math.Min(1f, layerDepth + 2E-05f));
		}
		DrawMenuIcons(spriteBatch, location, scaleSize, transparency, layerDepth + 3E-05f, drawStackNumber, colorOverride);
	}

	private void drawSmokedFish(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float layerDepth, float transparency = 1f)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_0333: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_0349: Unknown result type (might be due to invalid IL or missing references)
		//IL_037e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_041c: Unknown result type (might be due to invalid IL or missing references)
		//IL_041e: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(8f, 8f);
		float num = 4f * scaleSize;
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(preservedParentSheetIndex.Value);
		Texture2D texture = dataOrErrorItem.GetTexture();
		Rectangle sourceRect = dataOrErrorItem.GetSourceRect();
		spriteBatch.Draw(texture, location + new Vector2(32f, 32f) * scaleSize, (Rectangle?)sourceRect, Color.White * transparency, 0f, val * scaleSize, num, (SpriteEffects)0, Math.Min(1f, layerDepth + 1E-05f));
		spriteBatch.Draw(texture, location + new Vector2(32f, 32f) * scaleSize, (Rectangle?)sourceRect, new Color(80, 30, 10) * 0.6f * transparency, 0f, val * scaleSize, num, (SpriteEffects)0, Math.Min(1f, layerDepth + 1.5E-05f));
		int num2 = 700 + (price.Value + 17) * 7777 % 200;
		spriteBatch.Draw(Game1.mouseCursors, location + new Vector2(32f, 32f) * scaleSize + new Vector2(0f, (float)((0.0 - Game1.currentGameTime.TotalGameTime.TotalMilliseconds) % 2000.0) * 0.03f), (Rectangle?)new Rectangle(372, 1956, 10, 10), new Color(80, 80, 80) * transparency * 0.53f * (1f - (float)(Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 2000.0) / 2000f), (float)((0.0 - Game1.currentGameTime.TotalGameTime.TotalMilliseconds) % 2000.0) * 0.001f, val * scaleSize, num / 2f, (SpriteEffects)0, Math.Min(1f, layerDepth + 2E-05f));
		spriteBatch.Draw(Game1.mouseCursors, location + new Vector2(24f, 40f) * scaleSize + new Vector2(0f, (float)((0.0 - (Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)num2)) % 2000.0) * 0.03f), (Rectangle?)new Rectangle(372, 1956, 10, 10), new Color(80, 80, 80) * transparency * 0.53f * (1f - (float)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)num2) % 2000.0) / 2000f), (float)((0.0 - (Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)num2)) % 2000.0) * 0.001f, val * scaleSize, num / 2f, (SpriteEffects)0, Math.Min(1f, layerDepth + 2E-05f));
		spriteBatch.Draw(Game1.mouseCursors, location + new Vector2(48f, 21f) * scaleSize + new Vector2(0f, (float)((0.0 - (Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(num2 * 2))) % 2000.0) * 0.03f), (Rectangle?)new Rectangle(372, 1956, 10, 10), new Color(80, 80, 80) * transparency * 0.53f * (1f - (float)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(num2 * 2)) % 2000.0) / 2000f), (float)((0.0 - (Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(num2 * 2))) % 2000.0) * 0.001f, val * scaleSize, num / 2f, (SpriteEffects)0, Math.Min(1f, layerDepth + 2E-05f));
	}

	public override void drawWhenHeld(SpriteBatch spriteBatch, Vector2 objectPosition, Farmer f)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		if (base.ItemId == "SmokedFish")
		{
			drawSmokedFish(spriteBatch, objectPosition, 1f, f.getDrawLayer() + 1E-05f);
		}
		else if (!ColorSameIndexAsParentSheetIndex)
		{
			base.drawWhenHeld(spriteBatch, objectPosition, f);
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
			spriteBatch.Draw(dataOrErrorItem.GetTexture(), objectPosition, (Rectangle?)dataOrErrorItem.GetSourceRect(1, base.ParentSheetIndex), color.Value, 0f, Vector2.Zero, 4f, (SpriteEffects)0, Math.Max(0f, (float)(f.StandingPixel.Y + 4) / 10000f));
		}
		else
		{
			ParsedItemData dataOrErrorItem2 = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
			spriteBatch.Draw(dataOrErrorItem2.GetTexture(), objectPosition, (Rectangle?)dataOrErrorItem2.GetSourceRect(0, base.ParentSheetIndex), color.Value, 0f, Vector2.Zero, 4f, (SpriteEffects)0, Math.Max(0f, (float)(f.StandingPixel.Y + 4) / 10000f));
		}
	}

	public double GetHue()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		Color value = color.Value;
		Utility.RGBtoHSL(((Color)(ref value)).R, ((Color)(ref value)).G, ((Color)(ref value)).B, out var h, out var _, out var _);
		return h;
	}

	protected override Item GetOneNew()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		return new ColoredObject(base.ItemId, 1, color.Value);
	}

	protected override void GetOneCopyFrom(Item source)
	{
		base.GetOneCopyFrom(source);
		if (source is ColoredObject coloredObject)
		{
			preserve.Value = coloredObject.preserve.Value;
			preservedParentSheetIndex.Value = coloredObject.preservedParentSheetIndex.Value;
			Name = coloredObject.Name;
			colorSameIndexAsParentSheetIndex.Value = coloredObject.colorSameIndexAsParentSheetIndex.Value;
		}
	}

	public override void draw(SpriteBatch spriteBatch, int x, int y, float alpha = 1f)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_049b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0333: Unknown result type (might be due to invalid IL or missing references)
		//IL_0338: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_0357: Unknown result type (might be due to invalid IL or missing references)
		//IL_036a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_0388: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_050a: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_053d: Unknown result type (might be due to invalid IL or missing references)
		//IL_041f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0424: Unknown result type (might be due to invalid IL or missing references)
		//IL_0429: Unknown result type (might be due to invalid IL or missing references)
		//IL_0436: Unknown result type (might be due to invalid IL or missing references)
		//IL_044a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0469: Unknown result type (might be due to invalid IL or missing references)
		if (bigCraftable.Value)
		{
			Vector2 val = getScale();
			Vector2 val2 = Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)(y * 64 - 64)));
			Rectangle val3 = default(Rectangle);
			((Rectangle)(ref val3))._002Ector((int)(val2.X - val.X / 2f), (int)(val2.Y - val.Y / 2f), (int)(64f + val.X), (int)(128f + val.Y / 2f));
			int num = 0;
			if (showNextIndex.Value)
			{
				num = 1;
			}
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
			Texture2D texture = dataOrErrorItem.GetTexture();
			if (!ColorSameIndexAsParentSheetIndex)
			{
				Rectangle sourceRect = dataOrErrorItem.GetSourceRect(num + 1, base.ParentSheetIndex);
				spriteBatch.Draw(texture, val3, (Rectangle?)dataOrErrorItem.GetSourceRect(num, base.ParentSheetIndex), Color.White, 0f, Vector2.Zero, (SpriteEffects)0, Math.Max(0f, (float)((y + 1) * 64 - 1) / 10000f));
				spriteBatch.Draw(texture, val3, (Rectangle?)sourceRect, color.Value, 0f, Vector2.Zero, (SpriteEffects)0, Math.Max(0f, (float)((y + 1) * 64 - 1) / 10000f));
			}
			else
			{
				spriteBatch.Draw(texture, val3, (Rectangle?)dataOrErrorItem.GetSourceRect(0, base.ParentSheetIndex), color.Value, 0f, Vector2.Zero, (SpriteEffects)0, Math.Max(0f, (float)((y + 1) * 64 - 1) / 10000f));
			}
			if (base.QualifiedItemId == "(BC)17" && base.MinutesUntilReady > 0)
			{
				spriteBatch.Draw(Game1.objectSpriteSheet, getLocalPosition(Game1.viewport) + new Vector2(32f, 0f), (Rectangle?)Game1.getSourceRectForStandardTileSheet(Game1.objectSpriteSheet, 435, 16, 16), Color.White, scale.X, new Vector2(32f, 32f), 1f, (SpriteEffects)0, Math.Max(0f, (float)((y + 1) * 64 - 1) / 10000f));
			}
		}
		else if (!Game1.eventUp || Location.IsFarm)
		{
			if (base.QualifiedItemId != "(O)590")
			{
				Texture2D shadowTexture = Game1.shadowTexture;
				Vector2 val4 = getLocalPosition(Game1.viewport) + new Vector2(32f, 53f);
				Rectangle? val5 = Game1.shadowTexture.Bounds;
				Color white = Color.White;
				Rectangle bounds = Game1.shadowTexture.Bounds;
				float num2 = ((Rectangle)(ref bounds)).Center.X;
				bounds = Game1.shadowTexture.Bounds;
				spriteBatch.Draw(shadowTexture, val4, val5, white, 0f, new Vector2(num2, (float)((Rectangle)(ref bounds)).Center.Y), 4f, (SpriteEffects)0, 1E-07f);
			}
			ParsedItemData dataOrErrorItem2 = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
			Texture2D texture2 = dataOrErrorItem2.GetTexture();
			Rectangle boundingBoxAt = GetBoundingBoxAt(x, y);
			if (!ColorSameIndexAsParentSheetIndex)
			{
				Rectangle sourceRect2 = dataOrErrorItem2.GetSourceRect(1, base.ParentSheetIndex);
				spriteBatch.Draw(texture2, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + 32), (float)(y * 64 + 32))), (Rectangle?)dataOrErrorItem2.GetSourceRect(0, base.ParentSheetIndex), Color.White, 0f, new Vector2(8f, 8f), (scale.Y > 1f) ? getScale().Y : 4f, (SpriteEffects)(flipped.Value ? 1 : 0), (float)((Rectangle)(ref boundingBoxAt)).Bottom / 10000f);
				spriteBatch.Draw(texture2, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + 32 + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0)), (float)(y * 64 + 32 + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0)))), (Rectangle?)sourceRect2, color.Value, 0f, new Vector2(8f, 8f), (scale.Y > 1f) ? getScale().Y : 4f, (SpriteEffects)(flipped.Value ? 1 : 0), (float)((Rectangle)(ref boundingBoxAt)).Bottom / 10000f);
			}
			else
			{
				spriteBatch.Draw(texture2, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + 32 + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0)), (float)(y * 64 + 32 + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0)))), (Rectangle?)dataOrErrorItem2.GetSourceRect(0, base.ParentSheetIndex), color.Value, 0f, new Vector2(8f, 8f), (scale.Y > 1f) ? getScale().Y : 4f, (SpriteEffects)(flipped.Value ? 1 : 0), (float)((Rectangle)(ref boundingBoxAt)).Bottom / 10000f);
			}
		}
	}

	public static bool TrySetColor(Item input, Color color, out ColoredObject coloredItem)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		if (input == null)
		{
			coloredItem = null;
			return false;
		}
		coloredItem = input as ColoredObject;
		if (coloredItem != null)
		{
			coloredItem.color.Value = color;
			return true;
		}
		if (input.HasTypeObject())
		{
			coloredItem = new ColoredObject(input.ItemId, input.Stack, color);
			coloredItem.CopyFieldsFrom(input);
			coloredItem.color.Value = color;
			return true;
		}
		coloredItem = null;
		return false;
	}
}
