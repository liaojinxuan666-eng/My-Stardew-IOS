using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Buffs;
using StardewValley.Extensions;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Menus;
using StardewValley.Monsters;

namespace StardewValley.Objects;

public class CombinedRing : Ring
{
	public NetList<Ring, NetRef<Ring>> combinedRings = new NetList<Ring, NetRef<Ring>>();

	public CombinedRing()
		: base("880")
	{
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(combinedRings, "combinedRings");
		combinedRings.OnElementChanged += delegate
		{
			OnCombinedRingsChanged();
		};
		combinedRings.OnArrayReplaced += delegate
		{
			OnCombinedRingsChanged();
		};
	}

	protected override bool loadDisplayFields()
	{
		base.loadDisplayFields();
		description = "";
		foreach (Ring combinedRing in combinedRings)
		{
			combinedRing.getDescription();
			description = description + combinedRing.description + "\n\n";
		}
		description = description.Trim();
		return true;
	}

	public override bool GetsEffectOfRing(string ringId)
	{
		foreach (Ring combinedRing in combinedRings)
		{
			if (combinedRing.GetsEffectOfRing(ringId))
			{
				return true;
			}
		}
		return base.GetsEffectOfRing(ringId);
	}

	protected override Item GetOneNew()
	{
		return new CombinedRing();
	}

	protected override void GetOneCopyFrom(Item source)
	{
		base.GetOneCopyFrom(source);
		if (!(source is CombinedRing combinedRing))
		{
			return;
		}
		combinedRings.Clear();
		foreach (Ring combinedRing2 in combinedRing.combinedRings)
		{
			Ring item = (Ring)combinedRing2.getOne();
			combinedRings.Add(item);
		}
	}

	public override int GetEffectsOfRingMultiplier(string ringId)
	{
		int num = 0;
		foreach (Ring combinedRing in combinedRings)
		{
			num += combinedRing.GetEffectsOfRingMultiplier(ringId);
		}
		return num;
	}

	public override void onEquip(Farmer who)
	{
		foreach (Ring combinedRing in combinedRings)
		{
			combinedRing.onEquip(who);
		}
		base.onEquip(who);
	}

	public override void onUnequip(Farmer who)
	{
		foreach (Ring combinedRing in combinedRings)
		{
			combinedRing.onUnequip(who);
		}
		base.onUnequip(who);
	}

	public override void AddEquipmentEffects(BuffEffects effects)
	{
		base.AddEquipmentEffects(effects);
		foreach (Ring combinedRing in combinedRings)
		{
			combinedRing.AddEquipmentEffects(effects);
		}
	}

	public override void onLeaveLocation(Farmer who, GameLocation environment)
	{
		foreach (Ring combinedRing in combinedRings)
		{
			combinedRing.onLeaveLocation(who, environment);
		}
		base.onLeaveLocation(who, environment);
	}

	public override void onMonsterSlay(Monster m, GameLocation location, Farmer who)
	{
		foreach (Ring combinedRing in combinedRings)
		{
			combinedRing.onMonsterSlay(m, location, who);
		}
		base.onMonsterSlay(m, location, who);
	}

	public override void onNewLocation(Farmer who, GameLocation environment)
	{
		foreach (Ring combinedRing in combinedRings)
		{
			combinedRing.onNewLocation(who, environment);
		}
		base.onNewLocation(who, environment);
	}

	public override void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_0530: Unknown result type (might be due to invalid IL or missing references)
		//IL_0538: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_0347: Unknown result type (might be due to invalid IL or missing references)
		//IL_034c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_035e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_037f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_0390: Unknown result type (might be due to invalid IL or missing references)
		//IL_0392: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_040c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0412: Unknown result type (might be due to invalid IL or missing references)
		//IL_042c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0437: Unknown result type (might be due to invalid IL or missing references)
		//IL_043d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0442: Unknown result type (might be due to invalid IL or missing references)
		//IL_0453: Unknown result type (might be due to invalid IL or missing references)
		//IL_045d: Unknown result type (might be due to invalid IL or missing references)
		//IL_045f: Unknown result type (might be due to invalid IL or missing references)
		//IL_046c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0473: Unknown result type (might be due to invalid IL or missing references)
		//IL_0487: Unknown result type (might be due to invalid IL or missing references)
		//IL_048d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04da: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0502: Unknown result type (might be due to invalid IL or missing references)
		//IL_0508: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0526: Unknown result type (might be due to invalid IL or missing references)
		//IL_036b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0370: Unknown result type (might be due to invalid IL or missing references)
		if (combinedRings.Count >= 2)
		{
			AdjustMenuDrawForRecipes(ref transparency, ref scaleSize);
			float num = scaleSize;
			scaleSize = 1f;
			location.Y -= (num - 1f) * 32f;
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(combinedRings[0].QualifiedItemId);
			Texture2D texture = dataOrErrorItem.GetTexture();
			Rectangle value = dataOrErrorItem.GetSourceRect().Clone();
			value.X += 5;
			value.Y += 7;
			value.Width = 4;
			value.Height = 6;
			spriteBatch.Draw(texture, location + new Vector2(51f, 51f) * scaleSize + new Vector2(-12f, 8f) * scaleSize, (Rectangle?)value, color * transparency, 0f, new Vector2(1.5f, 2f) * 4f * scaleSize, scaleSize * 4f, (SpriteEffects)0, layerDepth);
			value.X++;
			value.Y += 4;
			value.Width = 3;
			value.Height = 1;
			spriteBatch.Draw(texture, location + new Vector2(51f, 51f) * scaleSize + new Vector2(-8f, 4f) * scaleSize, (Rectangle?)value, color * transparency, 0f, new Vector2(1.5f, 2f) * 4f * scaleSize, scaleSize * 4f, (SpriteEffects)0, layerDepth);
			ParsedItemData dataOrErrorItem2 = ItemRegistry.GetDataOrErrorItem(combinedRings[1].QualifiedItemId);
			texture = dataOrErrorItem2.GetTexture();
			value = dataOrErrorItem2.GetSourceRect().Clone();
			value.X += 9;
			value.Y += 7;
			value.Width = 4;
			value.Height = 6;
			spriteBatch.Draw(texture, location + new Vector2(51f, 51f) * scaleSize + new Vector2(4f, 8f) * scaleSize, (Rectangle?)value, color * transparency, 0f, new Vector2(1.5f, 2f) * 4f * scaleSize, scaleSize * 4f, (SpriteEffects)0, layerDepth);
			value.Y += 4;
			value.Width = 3;
			value.Height = 1;
			spriteBatch.Draw(texture, location + new Vector2(51f, 51f) * scaleSize + new Vector2(4f, 4f) * scaleSize, (Rectangle?)value, color * transparency, 0f, new Vector2(1.5f, 2f) * 4f * scaleSize, scaleSize * 4f, (SpriteEffects)0, layerDepth);
			Color? dyeColor = TailoringMenu.GetDyeColor(combinedRings[0]);
			Color? dyeColor2 = TailoringMenu.GetDyeColor(combinedRings[1]);
			Color color2 = Color.Red;
			Color color3 = Color.Blue;
			if (dyeColor.HasValue)
			{
				color2 = dyeColor.Value;
			}
			if (dyeColor2.HasValue)
			{
				color3 = dyeColor2.Value;
			}
			base.drawInMenu(spriteBatch, location + new Vector2(-5f, -1f), scaleSize, transparency, layerDepth, drawStackNumber, Utility.Get2PhaseColor(color2, color3), drawShadow);
			spriteBatch.Draw(Game1.objectSpriteSheet, location + new Vector2(13f, 35f) * scaleSize, (Rectangle?)new Rectangle(263, 579, 4, 2), Utility.Get2PhaseColor(color2, color3, 0, 1f, 1125f) * transparency, -(float)Math.PI / 2f, new Vector2(2f, 1.5f) * scaleSize, scaleSize * 4f, (SpriteEffects)0, layerDepth);
			spriteBatch.Draw(Game1.objectSpriteSheet, location + new Vector2(49f, 35f) * scaleSize, (Rectangle?)new Rectangle(263, 579, 4, 2), Utility.Get2PhaseColor(color2, color3, 0, 1f, 375f) * transparency, (float)Math.PI / 2f, new Vector2(2f, 1.5f) * scaleSize, scaleSize * 4f, (SpriteEffects)0, layerDepth);
			spriteBatch.Draw(Game1.objectSpriteSheet, location + new Vector2(31f, 53f) * scaleSize, (Rectangle?)new Rectangle(263, 579, 4, 2), Utility.Get2PhaseColor(color2, color3, 0, 1f, 750f) * transparency, (float)Math.PI, new Vector2(2f, 1.5f) * scaleSize, scaleSize * 4f, (SpriteEffects)0, layerDepth);
			DrawMenuIcons(spriteBatch, location, scaleSize, transparency, layerDepth, drawStackNumber, color);
		}
		else
		{
			base.drawInMenu(spriteBatch, location, scaleSize, transparency, layerDepth, drawStackNumber, color, drawShadow);
		}
	}

	public override void update(GameTime time, GameLocation environment, Farmer who)
	{
		foreach (Ring combinedRing in combinedRings)
		{
			combinedRing.update(time, environment, who);
		}
		base.update(time, environment, who);
	}

	protected virtual void OnCombinedRingsChanged()
	{
		description = null;
	}
}
