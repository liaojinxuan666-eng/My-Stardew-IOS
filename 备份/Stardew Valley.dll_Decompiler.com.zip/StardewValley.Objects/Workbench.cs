using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using StardewValley.Inventories;
using StardewValley.Menus;
using StardewValley.Network;

namespace StardewValley.Objects;

public class Workbench : Object
{
	[XmlIgnore]
	public readonly NetMutex mutex = new NetMutex();

	public override string TypeDefinitionId => "(BC)";

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(mutex.NetFields, "mutex.NetFields");
	}

	public Workbench()
	{
	}

	public Workbench(Vector2 position)
		: base(position, "208")
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		Name = "Workbench";
		type.Value = "Crafting";
		bigCraftable.Value = true;
		canBeSetDown.Value = true;
	}

	public override bool checkForAction(Farmer who, bool justCheckingForActivity = false)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return false;
		}
		if (justCheckingForActivity)
		{
			return true;
		}
		List<Chest> list = new List<Chest>();
		Point? fridgePosition = location.GetFridgePosition();
		Vector2[] array = (Vector2[])(object)new Vector2[8]
		{
			new Vector2(-1f, 1f),
			new Vector2(0f, 1f),
			new Vector2(1f, 1f),
			new Vector2(-1f, 0f),
			new Vector2(1f, 0f),
			new Vector2(-1f, -1f),
			new Vector2(0f, -1f),
			new Vector2(1f, -1f)
		};
		Vector2 key = default(Vector2);
		for (int i = 0; i < array.Length; i++)
		{
			((Vector2)(ref key))._002Ector((float)(int)(tileLocation.X + array[i].X), (float)(int)(tileLocation.Y + array[i].Y));
			if ((int)tileLocation.X == fridgePosition?.X && (int)tileLocation.Y == fridgePosition.Value.Y)
			{
				Chest fridge = location.GetFridge();
				if (fridge != null)
				{
					list.Add(fridge);
				}
			}
			if (location.objects.TryGetValue(key, out var value) && value is Chest chest && (chest.SpecialChestType == Chest.SpecialChestTypes.None || chest.SpecialChestType == Chest.SpecialChestTypes.BigChest))
			{
				list.Add(chest);
			}
		}
		List<NetMutex> list2 = new List<NetMutex>();
		List<IInventory> inventories = new List<IInventory>();
		foreach (Chest item in list)
		{
			list2.Add(item.mutex);
			inventories.Add(item.Items);
		}
		if (!mutex.IsLocked())
		{
			new MultipleMutexRequest(list2, delegate(MultipleMutexRequest request)
			{
				mutex.RequestLock(delegate
				{
					//IL_001c: Unknown result type (might be due to invalid IL or missing references)
					//IL_0021: Unknown result type (might be due to invalid IL or missing references)
					//IL_0022: Unknown result type (might be due to invalid IL or missing references)
					//IL_0029: Unknown result type (might be due to invalid IL or missing references)
					Vector2 topLeftPositionForCenteringOnScreen = Utility.getTopLeftPositionForCenteringOnScreen(800 + IClickableMenu.borderWidth * 2, 600 + IClickableMenu.borderWidth * 2);
					Game1.activeClickableMenu = new CraftingPage((int)topLeftPositionForCenteringOnScreen.X, (int)topLeftPositionForCenteringOnScreen.Y, 800 + IClickableMenu.borderWidth * 2, 600 + IClickableMenu.borderWidth * 2, cooking: false, standaloneMenu: true, inventories);
					Game1.activeClickableMenu.exitFunction = delegate
					{
						mutex.ReleaseLock();
						request.ReleaseLocks();
					};
				}, request.ReleaseLocks);
			}, delegate
			{
				Game1.showRedMessage(Game1.content.LoadString("Strings\\UI:Workbench_Chest_Warning"));
			});
		}
		return true;
	}

	public override void updateWhenCurrentLocation(GameTime time)
	{
		GameLocation location = Location;
		if (location != null)
		{
			mutex.Update(location);
		}
		base.updateWhenCurrentLocation(time);
	}
}
