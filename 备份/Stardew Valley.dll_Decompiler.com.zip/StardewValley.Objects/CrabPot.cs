using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.Inventories;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Locations;

namespace StardewValley.Objects;

public class CrabPot : Object
{
	public const int lidFlapTimerInterval = 60;

	[XmlIgnore]
	public float yBob;

	[XmlElement("directionOffset")]
	public readonly NetVector2 directionOffset = new NetVector2();

	[XmlElement("bait")]
	public readonly NetRef<Object> bait = new NetRef<Object>();

	public int tileIndexToShow;

	[XmlIgnore]
	public bool lidFlapping;

	[XmlIgnore]
	public bool lidClosing;

	[XmlIgnore]
	public float lidFlapTimer;

	[XmlIgnore]
	public new float shakeTimer;

	[XmlIgnore]
	public Vector2 shake;

	[XmlIgnore]
	private int ignoreRemovalTimer;

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(directionOffset, "directionOffset").AddField(bait, "bait");
	}

	public CrabPot()
		: base("710", 1)
	{
		base.CanBeGrabbed = false;
		type.Value = "interactive";
		tileIndexToShow = base.ParentSheetIndex;
	}

	public bool NeedsBait(Farmer player)
	{
		if (bait.Value != null)
		{
			return false;
		}
		return !(Game1.GetPlayer(owner.Value) ?? player ?? Game1.player).professions.Contains(11);
	}

	public List<Vector2> getOverlayTiles()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		List<Vector2> list = new List<Vector2>();
		if (Location != null)
		{
			if (directionOffset.Y < 0f)
			{
				addOverlayTilesIfNecessary((int)TileLocation.X, (int)tileLocation.Y, list);
			}
			addOverlayTilesIfNecessary((int)TileLocation.X, (int)tileLocation.Y + 1, list);
			if (directionOffset.X < 0f)
			{
				addOverlayTilesIfNecessary((int)TileLocation.X - 1, (int)tileLocation.Y + 1, list);
			}
			if (directionOffset.X > 0f)
			{
				addOverlayTilesIfNecessary((int)TileLocation.X + 1, (int)tileLocation.Y + 1, list);
			}
		}
		return list;
	}

	protected void addOverlayTilesIfNecessary(int tile_x, int tile_y, List<Vector2> tiles)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location != null && location == Game1.currentLocation && location.hasTileAt(tile_x, tile_y, "Buildings") && !location.isWaterTile(tile_x, tile_y + 1))
		{
			tiles.Add(new Vector2((float)tile_x, (float)tile_y));
		}
	}

	public void addOverlayTiles()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null || location != Game1.currentLocation)
		{
			return;
		}
		foreach (Vector2 overlayTile in getOverlayTiles())
		{
			if (!Game1.crabPotOverlayTiles.TryGetValue(overlayTile, out var value))
			{
				value = (Game1.crabPotOverlayTiles[overlayTile] = 0);
			}
			Game1.crabPotOverlayTiles[overlayTile] = value + 1;
		}
	}

	public void removeOverlayTiles()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if (Location == null || Location != Game1.currentLocation)
		{
			return;
		}
		foreach (Vector2 overlayTile in getOverlayTiles())
		{
			if (Game1.crabPotOverlayTiles.TryGetValue(overlayTile, out var value))
			{
				value--;
				if (value <= 0)
				{
					Game1.crabPotOverlayTiles.Remove(overlayTile);
				}
				else
				{
					Game1.crabPotOverlayTiles[overlayTile] = value;
				}
			}
		}
	}

	public static bool IsValidCrabPotLocationTile(GameLocation location, int x, int y)
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		if (location is Caldera || location is VolcanoDungeon || location is MineShaft)
		{
			return false;
		}
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)x, (float)y);
		bool flag = (location.isWaterTile(x + 1, y) && location.isWaterTile(x - 1, y)) || (location.isWaterTile(x, y + 1) && location.isWaterTile(x, y - 1));
		if (location.objects.ContainsKey(val) || !flag || !location.isWaterTile((int)val.X, (int)val.Y) || location.doesTileHaveProperty((int)val.X, (int)val.Y, "Passable", "Buildings") != null)
		{
			return false;
		}
		return true;
	}

	public override void actionOnPlayerEntry()
	{
		updateOffset();
		addOverlayTiles();
		base.actionOnPlayerEntry();
	}

	public override bool placementAction(GameLocation location, int x, int y, Farmer who = null)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(x / 64), (float)(y / 64));
		if (who != null)
		{
			owner.Value = who.UniqueMultiplayerID;
		}
		if (!IsValidCrabPotLocationTile(location, (int)val.X, (int)val.Y))
		{
			return false;
		}
		TileLocation = val;
		location.objects.Add(tileLocation.Value, this);
		location.playSound("waterSlosh");
		DelayedAction.playSoundAfterDelay("slosh", 150);
		updateOffset();
		addOverlayTiles();
		return true;
	}

	public void updateOffset()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = Vector2.Zero;
		if (checkLocation(tileLocation.X - 1f, tileLocation.Y))
		{
			val += new Vector2(32f, 0f);
		}
		if (checkLocation(tileLocation.X + 1f, tileLocation.Y))
		{
			val += new Vector2(-32f, 0f);
		}
		if (val.X != 0f && checkLocation(tileLocation.X + (float)Math.Sign(val.X), tileLocation.Y + 1f))
		{
			val += new Vector2(0f, -42f);
		}
		if (checkLocation(tileLocation.X, tileLocation.Y - 1f))
		{
			val += new Vector2(0f, 32f);
		}
		if (checkLocation(tileLocation.X, tileLocation.Y + 1f))
		{
			val += new Vector2(0f, -42f);
		}
		directionOffset.Value = val;
	}

	protected bool checkLocation(float tile_x, float tile_y)
	{
		GameLocation location = Location;
		if (!location.isWaterTile((int)tile_x, (int)tile_y) || location.doesTileHaveProperty((int)tile_x, (int)tile_y, "Passable", "Buildings") != null)
		{
			return true;
		}
		return false;
	}

	protected override Item GetOneNew()
	{
		return new Object(base.ItemId, 1);
	}

	public override bool performObjectDropInAction(Item dropInItem, bool probe, Farmer who, bool returnFalseIfItemConsumed = false)
	{
		GameLocation location = Location;
		if (location == null)
		{
			return false;
		}
		if (dropInItem is Object { Category: -21 } obj && NeedsBait(who))
		{
			if (!probe)
			{
				if (who != null)
				{
					owner.Value = who.UniqueMultiplayerID;
				}
				bait.Value = obj.getOne() as Object;
				location.playSound("Ship");
				lidFlapping = true;
				lidFlapTimer = 60f;
			}
			return true;
		}
		return false;
	}

	public override bool AttemptAutoLoad(IInventory inventory, Farmer who)
	{
		Object value = bait.Value;
		if (base.AttemptAutoLoad(inventory, who) && value != bait.Value)
		{
			inventory.ReduceId(bait.Value.QualifiedItemId, bait.Value.Stack);
			return true;
		}
		return false;
	}

	public override bool checkForAction(Farmer who, bool justCheckingForActivity = false)
	{
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return false;
		}
		if (tileIndexToShow == 714)
		{
			if (justCheckingForActivity)
			{
				return true;
			}
			Object value = heldObject.Value;
			if (value != null)
			{
				int num = value.Stack;
				if (Utility.CreateDaySaveRandom(Game1.uniqueIDForThisGame, Game1.stats.DaysPlayed * 77, tileLocation.X * 777f + tileLocation.Y).NextDouble() < 0.25 && Game1.player.stats.Get("Book_Crabbing") != 0 && who.couldInventoryAcceptThisItem(value.QualifiedItemId, num * 2, value.Quality))
				{
					num *= 2;
				}
				value.Stack = num;
				heldObject.Value = null;
				if (who.IsLocalPlayer && !who.addItemToInventoryBool(value))
				{
					heldObject.Value = value;
					Game1.showRedMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:Crop.cs.588"));
					return false;
				}
				if (DataLoader.Fish(Game1.content).TryGetValue(value.ItemId, out var value2))
				{
					string[] array = value2.Split('/');
					int minValue = ((array.Length <= 5) ? 1 : Convert.ToInt32(array[5]));
					int num2 = ((array.Length > 5) ? Convert.ToInt32(array[6]) : 10);
					who.caughtFish(value.QualifiedItemId, Game1.random.Next(minValue, num2 + 1), from_fish_pond: false, num);
				}
				who.gainExperience(1, 5);
			}
			readyForHarvest.Value = false;
			tileIndexToShow = 710;
			lidFlapping = true;
			lidFlapTimer = 60f;
			bait.Value = null;
			who.animateOnce(279 + who.FacingDirection);
			location.playSound("fishingRodBend");
			DelayedAction.playSoundAfterDelay("coin", 500);
			shake = Vector2.Zero;
			shakeTimer = 0f;
			ignoreRemovalTimer = 750;
			return true;
		}
		if (bait.Value == null && ignoreRemovalTimer <= 0)
		{
			if (justCheckingForActivity)
			{
				return true;
			}
			if (Game1.didPlayerJustClickAtAll(ignoreNonMouseHeldInput: true))
			{
				if (Game1.player.addItemToInventoryBool(getOne()))
				{
					if (who.isMoving())
					{
						Game1.haltAfterCheck = false;
					}
					Game1.playSound("coin");
					location.objects.Remove(tileLocation.Value);
					return true;
				}
				Game1.showRedMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:Crop.cs.588"));
			}
		}
		return false;
	}

	public override void performRemoveAction()
	{
		removeOverlayTiles();
		base.performRemoveAction();
	}

	public override void DayUpdate()
	{
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		Farmer farmer = Game1.GetPlayer(owner.Value) ?? Game1.MasterPlayer;
		bool flag = farmer.professions.Contains(10);
		if (NeedsBait(farmer) || heldObject.Value != null)
		{
			return;
		}
		tileIndexToShow = 714;
		readyForHarvest.Value = true;
		Random random = Utility.CreateDaySaveRandom(tileLocation.X * 1000f, tileLocation.Y * 255f, directionOffset.X * 1000f + directionOffset.Y);
		List<string> list = new List<string>();
		if (!location.TryGetFishAreaForTile(tileLocation.Value, out var _, out var data))
		{
			data = null;
		}
		double num = (flag ? 0.0 : (((double?)((data != null) ? new float?(data.CrabPotJunkChance) : ((float?)null))) ?? 0.2));
		int amount = 1;
		int num2 = 0;
		string text = null;
		switch (bait.Value?.QualifiedItemId)
		{
		case "(O)DeluxeBait":
			num2 = 1;
			num /= 2.0;
			break;
		case "(O)774":
			num /= 2.0;
			if (random.NextBool(0.25))
			{
				amount = 2;
			}
			break;
		case "(O)SpecificBait":
			if (bait.Value.preservedParentSheetIndex.Value != null && bait.Value.preserve.Value.HasValue)
			{
				text = bait.Value.preservedParentSheetIndex.Value;
				num /= 2.0;
			}
			break;
		}
		if (!random.NextBool(num))
		{
			IList<string> crabPotFishForTile = location.GetCrabPotFishForTile(tileLocation.Value);
			foreach (KeyValuePair<string, string> item in DataLoader.Fish(Game1.content))
			{
				if (!item.Value.Contains("trap"))
				{
					continue;
				}
				string[] array = item.Value.Split('/');
				string[] array2 = ArgUtility.SplitBySpace(array[4]);
				bool flag2 = false;
				string[] array3 = array2;
				foreach (string text2 in array3)
				{
					foreach (string item2 in crabPotFishForTile)
					{
						if (text2 == item2)
						{
							flag2 = true;
							break;
						}
					}
				}
				if (!flag2)
				{
					continue;
				}
				if (flag)
				{
					list.Add(item.Key);
					continue;
				}
				double num3 = Convert.ToDouble(array[2]);
				if (text != null && text == item.Key)
				{
					num3 *= (double)((num3 < 0.1) ? 4 : ((num3 < 0.2) ? 3 : 2));
				}
				if (!(random.NextDouble() < num3))
				{
					continue;
				}
				heldObject.Value = ItemRegistry.Create<Object>("(O)" + item.Key, amount, num2);
				break;
			}
		}
		if (heldObject.Value == null)
		{
			if (flag && list.Count > 0)
			{
				heldObject.Value = ItemRegistry.Create<Object>("(O)" + random.ChooseFrom(list), amount, num2);
			}
			else
			{
				heldObject.Value = ItemRegistry.Create<Object>("(O)" + random.Next(168, 173));
			}
		}
	}

	public override void updateWhenCurrentLocation(GameTime time)
	{
		if (lidFlapping)
		{
			lidFlapTimer -= time.ElapsedGameTime.Milliseconds;
			if (lidFlapTimer <= 0f)
			{
				tileIndexToShow += ((!lidClosing) ? 1 : (-1));
				if (tileIndexToShow >= 713 && !lidClosing)
				{
					lidClosing = true;
					tileIndexToShow--;
				}
				else if (tileIndexToShow <= 709 && lidClosing)
				{
					lidClosing = false;
					tileIndexToShow++;
					lidFlapping = false;
					if (bait.Value != null)
					{
						tileIndexToShow = 713;
					}
				}
				lidFlapTimer = 60f;
			}
		}
		if (readyForHarvest.Value && heldObject.Value != null)
		{
			shakeTimer -= time.ElapsedGameTime.Milliseconds;
			if (shakeTimer < 0f)
			{
				shakeTimer = Game1.random.Next(2800, 3200);
			}
		}
		if (shakeTimer > 2000f)
		{
			shake.X = Game1.random.Next(-1, 2);
		}
		else
		{
			shake.X = 0f;
		}
		if (ignoreRemovalTimer > 0)
		{
			ignoreRemovalTimer -= (int)time.ElapsedGameTime.TotalMilliseconds;
		}
	}

	public override void draw(SpriteBatch spriteBatch, int x, int y, float alpha = 1f)
	{
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0404: Unknown result type (might be due to invalid IL or missing references)
		//IL_0409: Unknown result type (might be due to invalid IL or missing references)
		//IL_040e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0421: Unknown result type (might be due to invalid IL or missing references)
		//IL_042b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0435: Unknown result type (might be due to invalid IL or missing references)
		//IL_043f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0493: Unknown result type (might be due to invalid IL or missing references)
		//IL_049e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04de: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		//IL_032e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		//IL_0339: Unknown result type (might be due to invalid IL or missing references)
		//IL_0347: Unknown result type (might be due to invalid IL or missing references)
		//IL_034d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return;
		}
		if (heldObject.Value != null)
		{
			tileIndexToShow = 714;
		}
		else if (tileIndexToShow == 0)
		{
			tileIndexToShow = base.ParentSheetIndex;
		}
		yBob = (float)(Math.Sin(Game1.currentGameTime.TotalGameTime.TotalMilliseconds / 500.0 + (double)(x * 64)) * 8.0 + 8.0);
		if (yBob <= 0.001f)
		{
			location.temporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 0, 64, 64), 150f, 8, 0, directionOffset.Value + new Vector2((float)(x * 64 + 4), (float)(y * 64 + 32)), flicker: false, Game1.random.NextBool(), 0.001f, 0.01f, Color.White, 0.75f, 0.003f, 0f, 0f));
		}
		spriteBatch.Draw(Game1.objectSpriteSheet, Game1.GlobalToLocal(Game1.viewport, directionOffset.Value + new Vector2((float)(x * 64), (float)(y * 64 + (int)yBob))) + shake, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Game1.objectSpriteSheet, tileIndexToShow, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, ((float)(y * 64) + directionOffset.Y + (float)(x % 4)) / 10000f);
		if (location.waterTiles != null && x < location.waterTiles.waterTiles.GetLength(0) && y < location.waterTiles.waterTiles.GetLength(1) && location.waterTiles.waterTiles[x, y].isWater)
		{
			if (location.waterTiles.waterTiles[x, y].isVisible)
			{
				spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, directionOffset.Value + new Vector2((float)(x * 64 + 4), (float)(y * 64 + 48))) + shake, (Rectangle?)new Rectangle(location.waterAnimationIndex * 64, 2112 + (((x + y) % 2 != 0) ? ((!location.waterTileFlip) ? 128 : 0) : (location.waterTileFlip ? 128 : 0)), 56, 16 + (int)yBob), location.waterColor.Value, 0f, Vector2.Zero, 1f, (SpriteEffects)0, ((float)(y * 64) + directionOffset.Y + (float)(x % 4)) / 9999f);
			}
			else
			{
				Color val = default(Color);
				((Color)(ref val))._002Ector(135, 135, 135, 215);
				val = Utility.MultiplyColor(val, location.waterColor.Value);
				spriteBatch.Draw(Game1.staminaRect, Game1.GlobalToLocal(Game1.viewport, directionOffset.Value + new Vector2((float)(x * 64 + 4), (float)(y * 64 + 48))) + shake, (Rectangle?)null, val, 0f, Vector2.Zero, new Vector2(56f, (float)(16 + (int)yBob)), (SpriteEffects)0, ((float)(y * 64) + directionOffset.Y + (float)(x % 4)) / 9999f);
			}
		}
		if (readyForHarvest.Value && heldObject.Value != null)
		{
			float num = 4f * (float)Math.Round(Math.Sin(Game1.currentGameTime.TotalGameTime.TotalMilliseconds / 250.0), 2);
			spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, directionOffset.Value + new Vector2((float)(x * 64 - 8), (float)(y * 64 - 96 - 16) + num)), (Rectangle?)new Rectangle(141, 465, 20, 24), Color.White * 0.75f, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)((y + 1) * 64) / 10000f + 1E-06f + tileLocation.X / 10000f);
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(heldObject.Value.QualifiedItemId);
			spriteBatch.Draw(dataOrErrorItem.GetTexture(), Game1.GlobalToLocal(Game1.viewport, directionOffset.Value + new Vector2((float)(x * 64 + 32), (float)(y * 64 - 64 - 8) + num)), (Rectangle?)dataOrErrorItem.GetSourceRect(), Color.White * 0.75f, 0f, new Vector2(8f, 8f), 4f, (SpriteEffects)0, (float)((y + 1) * 64) / 10000f + 1E-05f + tileLocation.X / 10000f);
		}
	}
}
