using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Delegates;
using StardewValley.Internal;
using StardewValley.Inventories;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Locations;
using StardewValley.Menus;
using StardewValley.Network;
using StardewValley.Network.ChestHit;
using StardewValley.Tools;
using xTile.Dimensions;

namespace StardewValley.Objects;

public class Chest : Object
{
	public enum SpecialChestTypes
	{
		None,
		MiniShippingBin,
		JunimoChest,
		AutoLoader,
		Enricher,
		[Obsolete("This value is only used in mobile versions of the game.")]
		Mill,
		BigChest
	}

	public const int capacity = 36;

	internal ChestHitTimer hitTimerInstance;

	[XmlElement("currentLidFrame")]
	public readonly NetInt startingLidFrame = new NetInt(501);

	public readonly NetInt lidFrameCount = new NetInt(5);

	private int currentLidFrame;

	[XmlElement("frameCounter")]
	public readonly NetInt frameCounter = new NetInt(-1);

	[XmlElement("items")]
	public NetRef<Inventory> netItems = new NetRef<Inventory>(new Inventory());

	public readonly NetLongDictionary<Inventory, NetRef<Inventory>> separateWalletItems = new NetLongDictionary<Inventory, NetRef<Inventory>>();

	[XmlElement("tint")]
	public readonly NetColor tint = new NetColor(Color.White);

	[XmlElement("playerChoiceColor")]
	public readonly NetColor playerChoiceColor = new NetColor(Color.Black);

	[XmlElement("playerChest")]
	public readonly NetBool playerChest = new NetBool();

	[XmlElement("fridge")]
	public readonly NetBool fridge = new NetBool();

	[XmlElement("giftbox")]
	public readonly NetBool giftbox = new NetBool();

	[XmlElement("giftboxIndex")]
	public readonly NetInt giftboxIndex = new NetInt();

	public readonly NetBool giftboxIsStarterGift = new NetBool();

	[XmlElement("spriteIndexOverride")]
	public readonly NetInt bigCraftableSpriteIndex = new NetInt(-1);

	[XmlElement("dropContents")]
	public readonly NetBool dropContents = new NetBool(value: false);

	[XmlIgnore]
	public string mailToAddOnItemDump;

	[XmlElement("synchronized")]
	public readonly NetBool synchronized = new NetBool(value: false);

	[XmlIgnore]
	public int _shippingBinFrameCounter;

	[XmlIgnore]
	public bool _farmerNearby;

	[XmlIgnore]
	public NetVector2 kickStartTile = new NetVector2(new Vector2(-1000f, -1000f));

	[XmlIgnore]
	public Vector2? localKickStartTile;

	[XmlIgnore]
	public float kickProgress = -1f;

	[XmlIgnore]
	public readonly NetEvent0 openChestEvent = new NetEvent0();

	[XmlElement("specialChestType")]
	public readonly NetEnum<SpecialChestTypes> specialChestType = new NetEnum<SpecialChestTypes>();

	public readonly NetString globalInventoryId = new NetString();

	[XmlIgnore]
	public readonly NetMutex mutex = new NetMutex();

	private ChestHitTimer HitTimerInstance
	{
		get
		{
			//IL_0060: Unknown result type (might be due to invalid IL or missing references)
			//IL_006c: Unknown result type (might be due to invalid IL or missing references)
			if (hitTimerInstance != null)
			{
				return hitTimerInstance;
			}
			hitTimerInstance = new ChestHitTimer();
			if (Game1.IsMasterGame || Location == null)
			{
				return hitTimerInstance;
			}
			if (!Game1.player.team.chestHit.SavedTimers.TryGetValue(Location.NameOrUniqueName, out var value))
			{
				return hitTimerInstance;
			}
			ulong key = ChestHitSynchronizer.HashPosition((int)TileLocation.X, (int)TileLocation.Y);
			if (value.TryGetValue(key, out var value2))
			{
				hitTimerInstance = value2;
				value.Remove(key);
				if (value2.SavedTime >= 0 && Game1.currentGameTime != null)
				{
					value2.Milliseconds -= (int)Game1.currentGameTime.TotalGameTime.TotalMilliseconds - value2.SavedTime;
					value2.SavedTime = -1;
				}
			}
			return hitTimerInstance;
		}
	}

	[XmlIgnore]
	public SpecialChestTypes SpecialChestType
	{
		get
		{
			return specialChestType.Value;
		}
		set
		{
			specialChestType.Value = value;
		}
	}

	[XmlIgnore]
	public string GlobalInventoryId
	{
		get
		{
			return globalInventoryId.Value;
		}
		set
		{
			globalInventoryId.Value = value;
		}
	}

	[XmlIgnore]
	public Color Tint
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return tint.Value;
		}
		set
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			tint.Value = value;
		}
	}

	[XmlIgnore]
	public Inventory Items => netItems.Value;

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(startingLidFrame, "startingLidFrame").AddField(frameCounter, "frameCounter").AddField(netItems, "netItems")
			.AddField(tint, "tint")
			.AddField(playerChoiceColor, "playerChoiceColor")
			.AddField(playerChest, "playerChest")
			.AddField(fridge, "fridge")
			.AddField(giftbox, "giftbox")
			.AddField(giftboxIndex, "giftboxIndex")
			.AddField(giftboxIsStarterGift, "giftboxIsStarterGift")
			.AddField(mutex.NetFields, "mutex.NetFields")
			.AddField(lidFrameCount, "lidFrameCount")
			.AddField(bigCraftableSpriteIndex, "bigCraftableSpriteIndex")
			.AddField(dropContents, "dropContents")
			.AddField(openChestEvent.NetFields, "openChestEvent.NetFields")
			.AddField(synchronized, "synchronized")
			.AddField(specialChestType, "specialChestType")
			.AddField(kickStartTile, "kickStartTile")
			.AddField(separateWalletItems, "separateWalletItems")
			.AddField(globalInventoryId, "globalInventoryId");
		openChestEvent.onEvent += performOpenChest;
		kickStartTile.fieldChangeVisibleEvent += delegate(NetVector2 field, Vector2 old_value, Vector2 new_value)
		{
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			if (Game1.gameMode != 6 && new_value.X != -1000f && new_value.Y != -1000f)
			{
				localKickStartTile = kickStartTile.Value;
				kickProgress = 0f;
			}
		};
	}

	public Chest()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		Name = "Chest";
		type.Value = "interactive";
	}

	public Chest(bool playerChest, Vector2 tileLocation, string itemId = "130")
		: base(tileLocation, itemId)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		Name = "Chest";
		type.Value = "Crafting";
		if (playerChest)
		{
			this.playerChest.Value = playerChest;
			startingLidFrame.Value = base.ParentSheetIndex + 1;
			bigCraftable.Value = true;
			canBeSetDown.Value = true;
		}
		else
		{
			lidFrameCount.Value = 3;
		}
		SetSpecialChestType();
	}

	public Chest(bool playerChest, string itemId = "130")
		: base(Vector2.Zero, itemId)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		Name = "Chest";
		type.Value = "Crafting";
		if (playerChest)
		{
			this.playerChest.Value = playerChest;
			startingLidFrame.Value = base.ParentSheetIndex + 1;
			bigCraftable.Value = true;
			canBeSetDown.Value = true;
		}
		else
		{
			lidFrameCount.Value = 3;
		}
	}

	public Chest(string itemId, Vector2 tile_location, int starting_lid_frame, int lid_frame_count)
		: base(tile_location, itemId)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		playerChest.Value = true;
		startingLidFrame.Value = starting_lid_frame;
		lidFrameCount.Value = lid_frame_count;
		bigCraftable.Value = true;
		canBeSetDown.Value = true;
	}

	public Chest(List<Item> items, Vector2 location, bool giftbox = false, int giftboxIndex = 0, bool giftboxIsStarterGift = false)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		base.name = "Chest";
		type.Value = "interactive";
		this.giftbox.Value = giftbox;
		this.giftboxIndex.Value = giftboxIndex;
		this.giftboxIsStarterGift.Value = giftboxIsStarterGift;
		if (!this.giftbox.Value)
		{
			lidFrameCount.Value = 3;
		}
		if (items != null)
		{
			Items.OverwriteWith(items);
		}
		TileLocation = location;
	}

	public void resetLidFrame()
	{
		currentLidFrame = startingLidFrame.Value;
	}

	public void fixLidFrame()
	{
		if (currentLidFrame == 0)
		{
			currentLidFrame = startingLidFrame.Value;
		}
		if (SpecialChestType == SpecialChestTypes.MiniShippingBin)
		{
			return;
		}
		if (playerChest.Value)
		{
			if (GetMutex().IsLocked() && !GetMutex().IsLockHeld())
			{
				currentLidFrame = getLastLidFrame();
			}
			else if (!GetMutex().IsLocked())
			{
				currentLidFrame = startingLidFrame.Value;
			}
		}
		else if (currentLidFrame == startingLidFrame.Value && GetMutex().IsLocked() && !GetMutex().IsLockHeld())
		{
			currentLidFrame = getLastLidFrame();
		}
	}

	public int getLastLidFrame()
	{
		return startingLidFrame.Value + lidFrameCount.Value - 1;
	}

	public void HandleChestHit(ChestHitArgs args)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		if (!Game1.IsMasterGame)
		{
			Game1.log.Warn("Attempted to call Chest::HandleChestHit as a farmhand.");
			return;
		}
		if (TileLocation.X == 0f && TileLocation.Y == 0f)
		{
			TileLocation = Utility.PointToVector2(args.ChestTile);
		}
		GetMutex().RequestLock(delegate
		{
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			//IL_0133: Unknown result type (might be due to invalid IL or missing references)
			//IL_013e: Unknown result type (might be due to invalid IL or missing references)
			//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_015f: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0098: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
			clearNulls();
			if (isEmpty())
			{
				performRemoveAction();
				if (Location.Objects.Remove(Utility.PointToVector2(args.ChestTile)) && base.Type == "Crafting" && fragility.Value != 2)
				{
					Location.debris.Add(new Debris(base.QualifiedItemId, args.ToolPosition, Utility.PointToVector2(args.StandingPixel)));
				}
				Game1.player.team.chestHit.SignalDelete(Location, args.ChestTile.X, args.ChestTile.Y);
			}
			else if (args.ToolCanHit)
			{
				if (args.HoldDownClick || args.RecentlyHit)
				{
					if (kickStartTile.Value == TileLocation)
					{
						kickStartTile.Value = new Vector2(-1000f, -1000f);
					}
					TryMoveToSafePosition(args.Direction);
					Game1.player.team.chestHit.SignalMove(Location, args.ChestTile.X, args.ChestTile.Y, (int)TileLocation.X, (int)TileLocation.Y);
				}
				else
				{
					kickStartTile.Value = TileLocation;
				}
			}
			GetMutex().ReleaseLock();
		});
	}

	public override bool performToolAction(Tool t)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0470: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_032d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_034b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_0407: Unknown result type (might be due to invalid IL or missing references)
		//IL_0417: Unknown result type (might be due to invalid IL or missing references)
		//IL_041c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		if (t?.getLastFarmerToUse() != null && t.getLastFarmerToUse() != Game1.player)
		{
			return false;
		}
		if (playerChest.Value)
		{
			if (t == null)
			{
				return false;
			}
			if (t is MeleeWeapon || !t.isHeavyHitter())
			{
				return false;
			}
			if (base.performToolAction(t))
			{
				GameLocation location = Location;
				Farmer lastFarmerToUse = t.getLastFarmerToUse();
				if (lastFarmerToUse != null)
				{
					Vector2 val = TileLocation;
					if (val.X == 0f && val.Y == 0f)
					{
						bool flag = false;
						foreach (KeyValuePair<Vector2, Object> pair in location.objects.Pairs)
						{
							if (pair.Value == this)
							{
								val.X = (int)pair.Key.X;
								val.Y = (int)pair.Key.Y;
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							val = lastFarmerToUse.GetToolLocation() / 64f;
							val.X = (int)val.X;
							val.Y = (int)val.Y;
						}
					}
					if (!GetMutex().IsLocked())
					{
						ChestHitArgs chestHitArgs = new ChestHitArgs();
						chestHitArgs.Location = location;
						chestHitArgs.ChestTile = new Point((int)TileLocation.X, (int)TileLocation.Y);
						chestHitArgs.ToolPosition = lastFarmerToUse.GetToolLocation();
						chestHitArgs.StandingPixel = lastFarmerToUse.StandingPixel;
						chestHitArgs.Direction = lastFarmerToUse.FacingDirection;
						chestHitArgs.HoldDownClick = t != lastFarmerToUse.CurrentTool;
						chestHitArgs.ToolCanHit = t.isHeavyHitter() && !(t is MeleeWeapon);
						chestHitArgs.RecentlyHit = HitTimerInstance.Milliseconds > 0;
						if (chestHitArgs.ToolCanHit)
						{
							shakeTimer = 100;
							HitTimerInstance.Milliseconds = 10000;
						}
						if (chestHitArgs.ChestTile.X == 0 && chestHitArgs.ChestTile.Y == 0)
						{
							if (location.getObjectAtTile((int)val.X, (int)val.Y) != this)
							{
								return false;
							}
							chestHitArgs.ChestTile = new Point((int)val.X, (int)val.Y);
						}
						Game1.player.team.chestHit.Sync(chestHitArgs);
					}
				}
			}
			return false;
		}
		if (t is Pickaxe && currentLidFrame == getLastLidFrame() && frameCounter.Value == -1 && isEmpty())
		{
			Location.playSound("woodWhack");
			for (int i = 0; i < 8; i++)
			{
				Game1.multiplayer.broadcastSprites(Location, new TemporaryAnimatedSprite("LooseSprites\\Cursors", (Game1.random.NextDouble() < 0.5) ? new Rectangle(598, 1275, 13, 4) : new Rectangle(598, 1275, 13, 4), 999f, 1, 0, tileLocation.Value * 64f + new Vector2(32f, 64f), flicker: false, Game1.random.NextDouble() < 0.5, (tileLocation.Y * 64f + 64f) / 10000f, 0.01f, new Color(204, 132, 87), 4f, 0f, (float)Game1.random.Next(-5, 6) * (float)Math.PI / 8f, (float)Game1.random.Next(-5, 6) * (float)Math.PI / 64f)
				{
					motion = new Vector2((float)Game1.random.Next(-25, 26) / 10f, (float)Game1.random.Next(-11, -8)),
					acceleration = new Vector2(0f, 0.3f)
				});
			}
			Game1.createRadialDebris(Location, 12, (int)tileLocation.X, (int)tileLocation.Y, Game1.random.Next(4, 7), resource: false, -1, item: false, (Color?)new Color(204, 132, 87));
			return true;
		}
		return false;
	}

	public bool TryMoveToSafePosition(int? preferDirection = null)
	{
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		Vector2? prioritize_direction = preferDirection switch
		{
			1 => new Vector2(1f, 0f), 
			3 => new Vector2(-1f, 0f), 
			0 => new Vector2(0f, -1f), 
			_ => new Vector2(0f, 1f), 
		};
		return TryMoveRecursively(tileLocation.Value, 0, prioritize_direction);
		bool TryMoveRecursively(Vector2 tile_position, int depth, Vector2? prioritize_direction2)
		{
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0060: Unknown result type (might be due to invalid IL or missing references)
			//IL_0081: Unknown result type (might be due to invalid IL or missing references)
			//IL_0086: Unknown result type (might be due to invalid IL or missing references)
			//IL_0095: Unknown result type (might be due to invalid IL or missing references)
			//IL_009a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00db: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_011a: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
			//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_012f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0142: Unknown result type (might be due to invalid IL or missing references)
			//IL_014d: Unknown result type (might be due to invalid IL or missing references)
			//IL_015f: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
			//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0201: Unknown result type (might be due to invalid IL or missing references)
			//IL_020a: Unknown result type (might be due to invalid IL or missing references)
			//IL_021b: Unknown result type (might be due to invalid IL or missing references)
			//IL_022c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0231: Unknown result type (might be due to invalid IL or missing references)
			//IL_023e: Unknown result type (might be due to invalid IL or missing references)
			List<Vector2> list = new List<Vector2>();
			list.AddRange((IEnumerable<Vector2>)(object)new Vector2[4]
			{
				new Vector2(1f, 0f),
				new Vector2(-1f, 0f),
				new Vector2(0f, -1f),
				new Vector2(0f, 1f)
			});
			Utility.Shuffle(Game1.random, list);
			if (prioritize_direction2.HasValue)
			{
				list.Remove(-prioritize_direction2.Value);
				list.Insert(0, -prioritize_direction2.Value);
				list.Remove(prioritize_direction2.Value);
				list.Insert(0, prioritize_direction2.Value);
			}
			foreach (Vector2 item in list)
			{
				Vector2 val = tile_position + item;
				if (canBePlacedHere(location, val) && location.CanItemBePlacedHere(val))
				{
					if (!location.objects.ContainsKey(val) && location.objects.Remove(TileLocation))
					{
						kickStartTile.Value = TileLocation;
						TileLocation = val;
						location.objects[val] = this;
					}
					return true;
				}
			}
			Utility.Shuffle(Game1.random, list);
			if (prioritize_direction2.HasValue)
			{
				list.Remove(-prioritize_direction2.Value);
				list.Insert(0, -prioritize_direction2.Value);
				list.Remove(prioritize_direction2.Value);
				list.Insert(0, prioritize_direction2.Value);
			}
			if (depth < 3)
			{
				foreach (Vector2 item2 in list)
				{
					Vector2 val2 = tile_position + item2;
					if (location.isPointPassable(new Location((int)(val2.X + 0.5f) * 64, (int)(val2.Y + 0.5f) * 64), Game1.viewport) && TryMoveRecursively(val2, depth + 1, prioritize_direction2))
					{
						return true;
					}
				}
			}
			return false;
		}
	}

	public override bool placementAction(GameLocation location, int x, int y, Farmer who = null)
	{
		localKickStartTile = null;
		kickProgress = -1f;
		return base.placementAction(location, x, y, who);
	}

	public void SetSpecialChestType()
	{
		switch (base.QualifiedItemId)
		{
		case "(BC)BigChest":
		case "(BC)BigStoneChest":
			SpecialChestType = SpecialChestTypes.BigChest;
			break;
		case "(BC)248":
			SpecialChestType = SpecialChestTypes.MiniShippingBin;
			break;
		case "(BC)256":
			SpecialChestType = SpecialChestTypes.JunimoChest;
			break;
		case "(BC)275":
			SpecialChestType = SpecialChestTypes.AutoLoader;
			break;
		}
	}

	public void destroyAndDropContents(Vector2 pointToDropAt)
	{
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return;
		}
		List<Item> list = new List<Item>();
		list.AddRange(Items);
		if (SpecialChestType == SpecialChestTypes.MiniShippingBin)
		{
			foreach (Inventory value in separateWalletItems.Values)
			{
				list.AddRange(value);
			}
		}
		if (list.Count > 0)
		{
			location.playSound("throwDownITem");
		}
		foreach (Item item in list)
		{
			if (item != null)
			{
				Game1.createItemDebris(item, pointToDropAt, Game1.random.Next(4), location);
			}
		}
		Items.Clear();
		separateWalletItems.Clear();
		clearNulls();
	}

	public override bool performObjectDropInAction(Item dropInItem, bool probe, Farmer who, bool returnFalseIfItemConsumed = false)
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		if (dropInItem != null && dropInItem.QualifiedItemId != base.QualifiedItemId && dropInItem.HasContextTag("swappable_chest") && HasContextTag("swappable_chest") && Location != null)
		{
			if (!probe)
			{
				if (GetMutex().IsLocked())
				{
					return false;
				}
				Chest chest = new Chest(playerChest: true, TileLocation, dropInItem.ItemId);
				int actualCapacity = chest.GetActualCapacity();
				if (actualCapacity < GetActualCapacity() && actualCapacity < Items.CountItemStacks())
				{
					return false;
				}
				if (actualCapacity < Items.Count)
				{
					clearNulls();
				}
				chest.netItems.Value = netItems.Value;
				chest.playerChoiceColor.Value = playerChoiceColor.Value;
				chest.Tint = Tint;
				chest.modData.CopyFrom(base.modData);
				GameLocation location = Location;
				location.Objects.Remove(TileLocation);
				location.Objects.Add(TileLocation, chest);
				Game1.createMultipleItemDebris(ItemRegistry.Create(base.QualifiedItemId), TileLocation * 64f + new Vector2(32f), -1);
				Location.playSound("axchop");
			}
			return true;
		}
		return base.performObjectDropInAction(dropInItem, probe, who);
	}

	public void dumpContents()
	{
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_042b: Unknown result type (might be due to invalid IL or missing references)
		//IL_045b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return;
		}
		IInventory items = Items;
		if (synchronized.Value && (GetMutex().IsLocked() || !Game1.IsMasterGame) && !GetMutex().IsLockHeld())
		{
			return;
		}
		if (items.Count > 0 && (GetMutex().IsLockHeld() || !playerChest.Value))
		{
			if (giftbox.Value && giftboxIsStarterGift.Value && location is FarmHouse farmHouse)
			{
				if (!farmHouse.IsOwnedByCurrentPlayer)
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Objects:ParsnipSeedPackage_SomeoneElse"));
					return;
				}
				Game1.player.addQuest((Game1.GetFarmTypeID() == "MeadowlandsFarm") ? "132" : "6");
				Game1.dayTimeMoneyBox.PingQuestLog();
			}
			foreach (Item item in items)
			{
				if (item == null)
				{
					continue;
				}
				item.SetTempData("FromStarterGiftBox", value: true);
				if (item.QualifiedItemId == "(O)434")
				{
					if (Game1.player.mailReceived.Add((location is FarmHouse) ? "CF_Spouse" : "CF_Mines"))
					{
						Game1.player.eatObject(items[0] as Object, overrideFullness: true);
					}
				}
				else if (dropContents.Value)
				{
					Game1.createItemDebris(item, tileLocation.Value * 64f, -1, location);
					if (location is VolcanoDungeon)
					{
						switch (bigCraftableSpriteIndex.Value)
						{
						case 223:
							Game1.player.team.RequestLimitedNutDrops("VolcanoNormalChest", location, (int)tileLocation.Value.X * 64, (int)tileLocation.Value.Y * 64, 1);
							break;
						case 227:
							Game1.player.team.RequestLimitedNutDrops("VolcanoRareChest", location, (int)tileLocation.Value.X * 64, (int)tileLocation.Value.Y * 64, 1);
							break;
						}
					}
				}
				else if (!synchronized.Value || GetMutex().IsLockHeld())
				{
					item.onDetachedFromParent();
					if (Game1.activeClickableMenu is ItemGrabMenu itemGrabMenu)
					{
						itemGrabMenu.ItemsToGrabMenu.actualInventory.Add(item);
					}
					else
					{
						Game1.player.addItemByMenuIfNecessaryElseHoldUp(item);
					}
					if (mailToAddOnItemDump != null)
					{
						Game1.player.mailReceived.Add(mailToAddOnItemDump);
					}
					if (location is Caldera || Game1.player.currentLocation is Caldera)
					{
						Game1.player.mailReceived.Add("CalderaTreasure");
					}
				}
			}
			items.Clear();
			clearNulls();
			Game1.mine?.chestConsumed();
			IClickableMenu activeClickableMenu = Game1.activeClickableMenu;
			ItemGrabMenu grabMenu = activeClickableMenu as ItemGrabMenu;
			if (grabMenu != null)
			{
				ItemGrabMenu itemGrabMenu2 = grabMenu;
				itemGrabMenu2.behaviorBeforeCleanup = (Action<IClickableMenu>)Delegate.Combine(itemGrabMenu2.behaviorBeforeCleanup, (Action<IClickableMenu>)delegate
				{
					grabMenu.DropRemainingItems();
				});
			}
		}
		Game1.player.gainExperience(5, 25 + Game1.CurrentMineLevel);
		if (giftbox.Value)
		{
			TemporaryAnimatedSprite temporaryAnimatedSprite = new TemporaryAnimatedSprite("LooseSprites\\Giftbox", new Rectangle(0, giftboxIndex.Value * 32, 16, 32), 80f, 11, 1, tileLocation.Value * 64f - new Vector2(0f, 52f), flicker: false, flipped: false, tileLocation.Y / 10000f, 0f, Color.White, 4f, 0f, 0f, 0f)
			{
				destroyable = false,
				holdLastFrame = true
			};
			if (location.netObjects.TryGetValue(tileLocation.Value, out var value) && value == this)
			{
				Game1.multiplayer.broadcastSprites(location, temporaryAnimatedSprite);
				location.removeObject(tileLocation.Value, showDestroyedObject: false);
			}
			else
			{
				location.temporarySprites.Add(temporaryAnimatedSprite);
			}
		}
	}

	public NetMutex GetMutex()
	{
		if (GlobalInventoryId != null)
		{
			return Game1.player.team.GetOrCreateGlobalInventoryMutex(GlobalInventoryId);
		}
		if (specialChestType.Value == SpecialChestTypes.JunimoChest)
		{
			return Game1.player.team.GetOrCreateGlobalInventoryMutex("JunimoChests");
		}
		return mutex;
	}

	public override bool checkForAction(Farmer who, bool justCheckingForActivity = false)
	{
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		//IL_0358: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		if (justCheckingForActivity)
		{
			return true;
		}
		GameLocation location = Location;
		IInventory itemsForPlayer = GetItemsForPlayer();
		if (giftbox.Value)
		{
			Game1.player.Halt();
			Game1.player.freezePause = 1000;
			location.playSound("Ship");
			dumpContents();
		}
		else if (playerChest.Value)
		{
			if (!Game1.didPlayerJustRightClick(ignoreNonMouseHeldInput: true))
			{
				return false;
			}
			GetMutex().RequestLock(delegate
			{
				if (SpecialChestType == SpecialChestTypes.MiniShippingBin)
				{
					OpenMiniShippingMenu();
				}
				else
				{
					frameCounter.Value = 5;
					Game1.playSound(fridge.Value ? "doorCreak" : "openChest");
					Game1.player.Halt();
					Game1.player.freezePause = 1000;
				}
			});
		}
		else if (!playerChest.Value)
		{
			if (currentLidFrame == startingLidFrame.Value && frameCounter.Value <= -1)
			{
				location.playSound("openChest");
				if (synchronized.Value)
				{
					GetMutex().RequestLock(openChestEvent.Fire);
				}
				else
				{
					performOpenChest();
				}
			}
			else if (currentLidFrame == getLastLidFrame() && itemsForPlayer.Count > 0 && !synchronized.Value)
			{
				Item item = itemsForPlayer[0];
				itemsForPlayer.RemoveAt(0);
				if (Game1.mine != null)
				{
					Game1.mine.chestConsumed();
				}
				who.addItemByMenuIfNecessaryElseHoldUp(item);
				IClickableMenu activeClickableMenu = Game1.activeClickableMenu;
				ItemGrabMenu grab_menu = activeClickableMenu as ItemGrabMenu;
				if (grab_menu != null)
				{
					ItemGrabMenu itemGrabMenu = grab_menu;
					itemGrabMenu.behaviorBeforeCleanup = (Action<IClickableMenu>)Delegate.Combine(itemGrabMenu.behaviorBeforeCleanup, (Action<IClickableMenu>)delegate
					{
						grab_menu.DropRemainingItems();
					});
				}
			}
		}
		if (itemsForPlayer.Count == 0 && (!playerChest.Value || giftbox.Value))
		{
			location.removeObject(TileLocation, showDestroyedObject: false);
			location.playSound("woodWhack");
			for (int num = 0; num < 8; num++)
			{
				Game1.multiplayer.broadcastSprites(Location, new TemporaryAnimatedSprite("LooseSprites\\Cursors", (Game1.random.NextDouble() < 0.5) ? new Rectangle(598, 1275, 13, 4) : new Rectangle(598, 1275, 13, 4), 999f, 1, 0, tileLocation.Value * 64f + new Vector2(32f, 64f), flicker: false, Game1.random.NextDouble() < 0.5, (tileLocation.Y * 64f + 64f) / 10000f, 0.01f, new Color(204, 132, 87), 4f, 0f, (float)Game1.random.Next(-5, 6) * (float)Math.PI / 8f, (float)Game1.random.Next(-5, 6) * (float)Math.PI / 64f)
				{
					motion = new Vector2((float)Game1.random.Next(-25, 26) / 10f, (float)Game1.random.Next(-11, -8)),
					acceleration = new Vector2(0f, 0.3f)
				});
			}
			Game1.createRadialDebris(location, 12, (int)tileLocation.X, (int)tileLocation.Y, Game1.random.Next(4, 7), resource: false, -1, item: false, (Color?)new Color(204, 132, 87));
		}
		return true;
	}

	public virtual void OpenMiniShippingMenu()
	{
		Game1.playSound("shwip");
		ShowMenu();
	}

	public virtual void performOpenChest()
	{
		frameCounter.Value = 5;
	}

	public virtual void grabItemFromChest(Item item, Farmer who)
	{
		if (who.couldInventoryAcceptThisItem(item))
		{
			GetItemsForPlayer().Remove(item);
			clearNulls();
			ShowMenu();
		}
	}

	public virtual Item addItem(Item item)
	{
		item.resetState();
		clearNulls();
		IInventory itemsForPlayer = GetItemsForPlayer();
		for (int i = 0; i < itemsForPlayer.Count; i++)
		{
			if (itemsForPlayer[i] != null && itemsForPlayer[i].canStackWith(item))
			{
				int amount = item.Stack - itemsForPlayer[i].addToStack(item);
				if (item.ConsumeStack(amount) == null)
				{
					return null;
				}
			}
		}
		if (itemsForPlayer.Count < GetActualCapacity())
		{
			itemsForPlayer.Add(item);
			return null;
		}
		return item;
	}

	public virtual int GetActualCapacity()
	{
		switch (SpecialChestType)
		{
		case SpecialChestTypes.MiniShippingBin:
		case SpecialChestTypes.JunimoChest:
			return 9;
		case SpecialChestTypes.Enricher:
			return 1;
		case SpecialChestTypes.BigChest:
			return 70;
		default:
			return 36;
		}
	}

	public virtual void CheckAutoLoad(Farmer who)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		Vector2 val = TileLocation;
		if (location != null && location.objects.TryGetValue(new Vector2(val.X, val.Y + 1f), out var value))
		{
			value?.AttemptAutoLoad(who);
		}
	}

	public virtual void ShowMenu()
	{
		ItemGrabMenu itemGrabMenu = Game1.activeClickableMenu as ItemGrabMenu;
		switch (SpecialChestType)
		{
		case SpecialChestTypes.MiniShippingBin:
			Game1.activeClickableMenu = new ItemGrabMenu(GetItemsForPlayer(), reverseGrab: false, showReceivingMenu: true, Utility.highlightShippableObjects, grabItemFromInventory, null, grabItemFromChest, snapToBottom: false, canBeExitedWithKey: true, playRightClickSound: true, allowRightClick: true, showOrganizeButton: false, 1, this, -1, this);
			break;
		case SpecialChestTypes.JunimoChest:
			Game1.activeClickableMenu = new ItemGrabMenu(GetItemsForPlayer(), reverseGrab: false, showReceivingMenu: true, InventoryMenu.highlightAllItems, grabItemFromInventory, null, grabItemFromChest, snapToBottom: false, canBeExitedWithKey: true, playRightClickSound: true, allowRightClick: true, showOrganizeButton: true, 1, this, -1, this);
			break;
		case SpecialChestTypes.AutoLoader:
		{
			ItemGrabMenu itemGrabMenu2 = new ItemGrabMenu(GetItemsForPlayer(), reverseGrab: false, showReceivingMenu: true, InventoryMenu.highlightAllItems, grabItemFromInventory, null, grabItemFromChest, snapToBottom: false, canBeExitedWithKey: true, playRightClickSound: true, allowRightClick: true, showOrganizeButton: true, 1, this, -1, this);
			itemGrabMenu2.exitFunction = (IClickableMenu.onExit)Delegate.Combine(itemGrabMenu2.exitFunction, (IClickableMenu.onExit)delegate
			{
				CheckAutoLoad(Game1.player);
			});
			Game1.activeClickableMenu = itemGrabMenu2;
			break;
		}
		case SpecialChestTypes.Enricher:
			Game1.activeClickableMenu = new ItemGrabMenu(GetItemsForPlayer(), reverseGrab: false, showReceivingMenu: true, Object.HighlightFertilizers, grabItemFromInventory, null, grabItemFromChest, snapToBottom: false, canBeExitedWithKey: true, playRightClickSound: true, allowRightClick: true, showOrganizeButton: true, 1, this, -1, this);
			break;
		default:
			Game1.activeClickableMenu = new ItemGrabMenu(GetItemsForPlayer(), reverseGrab: false, showReceivingMenu: true, InventoryMenu.highlightAllItems, grabItemFromInventory, null, grabItemFromChest, snapToBottom: false, canBeExitedWithKey: true, playRightClickSound: true, allowRightClick: true, showOrganizeButton: true, 1, this, -1, this);
			break;
		}
		if (itemGrabMenu != null && Game1.activeClickableMenu is ItemGrabMenu itemGrabMenu3)
		{
			itemGrabMenu3.inventory.moveItemSound = itemGrabMenu.inventory.moveItemSound;
			itemGrabMenu3.inventory.highlightMethod = itemGrabMenu.inventory.highlightMethod;
		}
	}

	public virtual void grabItemFromInventory(Item item, Farmer who)
	{
		if (item.Stack == 0)
		{
			item.Stack = 1;
		}
		Item item2 = addItem(item);
		if (item2 == null)
		{
			who.removeItemFromInventory(item);
		}
		else
		{
			item2 = who.addItemToInventory(item2);
		}
		clearNulls();
		int num = ((Game1.activeClickableMenu.currentlySnappedComponent != null) ? Game1.activeClickableMenu.currentlySnappedComponent.myID : (-1));
		ShowMenu();
		(Game1.activeClickableMenu as ItemGrabMenu).heldItem = item2;
		if (num != -1)
		{
			Game1.activeClickableMenu.currentlySnappedComponent = Game1.activeClickableMenu.getComponentWithID(num);
			Game1.activeClickableMenu.snapCursorToCurrentSnappedComponent();
		}
	}

	public IInventory GetItemsForPlayer()
	{
		return GetItemsForPlayer(Game1.player.UniqueMultiplayerID);
	}

	public IInventory GetItemsForPlayer(long id)
	{
		if (GlobalInventoryId != null)
		{
			return Game1.player.team.GetOrCreateGlobalInventory(GlobalInventoryId);
		}
		switch (SpecialChestType)
		{
		case SpecialChestTypes.MiniShippingBin:
			if (Game1.player.team.useSeparateWallets.Value && SpecialChestType == SpecialChestTypes.MiniShippingBin && Game1.player.team.useSeparateWallets.Value)
			{
				if (!separateWalletItems.TryGetValue(id, out var value))
				{
					value = (separateWalletItems[id] = new Inventory());
				}
				return value;
			}
			break;
		case SpecialChestTypes.JunimoChest:
			return Game1.player.team.GetOrCreateGlobalInventory("JunimoChests");
		}
		return Items;
	}

	public virtual bool isEmpty()
	{
		if (SpecialChestType == SpecialChestTypes.MiniShippingBin && Game1.player.team.useSeparateWallets.Value)
		{
			foreach (Inventory value in separateWalletItems.Values)
			{
				if (value.HasAny())
				{
					return false;
				}
			}
			return true;
		}
		return !GetItemsForPlayer().HasAny();
	}

	public virtual void clearNulls()
	{
		GetItemsForPlayer().RemoveEmptySlots();
	}

	public override void updateWhenCurrentLocation(GameTime time)
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return;
		}
		if (synchronized.Value)
		{
			openChestEvent.Poll();
		}
		if (localKickStartTile.HasValue)
		{
			if (Game1.currentLocation == location)
			{
				if (kickProgress == 0f)
				{
					if (Utility.isOnScreen((localKickStartTile.Value + new Vector2(0.5f, 0.5f)) * 64f, 64))
					{
						Game1.playSound("clubhit");
					}
					shakeTimer = 100;
				}
			}
			else
			{
				localKickStartTile = null;
				kickProgress = -1f;
			}
			if (kickProgress >= 0f)
			{
				float num = 0.25f;
				kickProgress += (float)(time.ElapsedGameTime.TotalSeconds / (double)num);
				if (kickProgress >= 1f)
				{
					kickProgress = -1f;
					localKickStartTile = null;
				}
			}
		}
		else
		{
			kickProgress = -1f;
		}
		fixLidFrame();
		mutex.Update(location);
		if (shakeTimer > 0)
		{
			shakeTimer -= time.ElapsedGameTime.Milliseconds;
			if (shakeTimer <= 0)
			{
				health = 10;
			}
		}
		hitTimerInstance?.Update(time);
		if (playerChest.Value)
		{
			if (SpecialChestType == SpecialChestTypes.MiniShippingBin)
			{
				UpdateFarmerNearby();
				if (_shippingBinFrameCounter > -1)
				{
					_shippingBinFrameCounter--;
					if (_shippingBinFrameCounter <= 0)
					{
						_shippingBinFrameCounter = 5;
						if (_farmerNearby && currentLidFrame < getLastLidFrame())
						{
							currentLidFrame++;
						}
						else if (!_farmerNearby && currentLidFrame > startingLidFrame.Value)
						{
							currentLidFrame--;
						}
						else
						{
							_shippingBinFrameCounter = -1;
						}
					}
				}
				if (Game1.activeClickableMenu == null && GetMutex().IsLockHeld())
				{
					GetMutex().ReleaseLock();
				}
			}
			else if (frameCounter.Value > -1 && currentLidFrame < getLastLidFrame() + 1)
			{
				frameCounter.Value--;
				if (frameCounter.Value <= 0 && GetMutex().IsLockHeld())
				{
					if (currentLidFrame == getLastLidFrame())
					{
						ShowMenu();
						frameCounter.Value = -1;
					}
					else
					{
						frameCounter.Value = 5;
						currentLidFrame++;
					}
				}
			}
			else if (((frameCounter.Value == -1 && currentLidFrame > startingLidFrame.Value) || currentLidFrame >= getLastLidFrame()) && Game1.activeClickableMenu == null && GetMutex().IsLockHeld())
			{
				GetMutex().ReleaseLock();
				currentLidFrame = getLastLidFrame();
				frameCounter.Value = 2;
				location.localSound("doorCreakReverse");
			}
		}
		else
		{
			if (frameCounter.Value <= -1 || currentLidFrame > getLastLidFrame())
			{
				return;
			}
			frameCounter.Value--;
			if (frameCounter.Value > 0)
			{
				return;
			}
			if (currentLidFrame == getLastLidFrame())
			{
				dumpContents();
				frameCounter.Value = -1;
				return;
			}
			frameCounter.Value = 10;
			currentLidFrame++;
			if (currentLidFrame == getLastLidFrame())
			{
				frameCounter.Value += 5;
			}
		}
	}

	public virtual void UpdateFarmerNearby(bool animate = true)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		bool flag = false;
		Vector2 value = tileLocation.Value;
		foreach (Farmer farmer in location.farmers)
		{
			Point tilePoint = farmer.TilePoint;
			if (Math.Abs((float)tilePoint.X - value.X) <= 1f && Math.Abs((float)tilePoint.Y - value.Y) <= 1f)
			{
				flag = true;
				break;
			}
		}
		if (flag == _farmerNearby)
		{
			return;
		}
		_farmerNearby = flag;
		_shippingBinFrameCounter = 5;
		if (!animate)
		{
			_shippingBinFrameCounter = -1;
			if (_farmerNearby)
			{
				currentLidFrame = getLastLidFrame();
			}
			else
			{
				currentLidFrame = startingLidFrame.Value;
			}
		}
		else if (Game1.gameMode != 6)
		{
			if (_farmerNearby)
			{
				location.localSound("doorCreak");
			}
			else
			{
				location.localSound("doorCreakReverse");
			}
		}
	}

	public override void actionOnPlayerEntry()
	{
		base.actionOnPlayerEntry();
		fixLidFrame();
		if (specialChestType.Value == SpecialChestTypes.MiniShippingBin)
		{
			UpdateFarmerNearby(animate: false);
		}
		kickProgress = -1f;
		localKickStartTile = null;
		if (!playerChest.Value && GetItemsForPlayer().Count == 0)
		{
			currentLidFrame = getLastLidFrame();
		}
	}

	public virtual void SetBigCraftableSpriteIndex(int sprite_index, int starting_lid_frame = -1, int lid_frame_count = 3)
	{
		bigCraftableSpriteIndex.Value = sprite_index;
		if (starting_lid_frame >= 0)
		{
			startingLidFrame.Value = starting_lid_frame;
		}
		else
		{
			startingLidFrame.Value = sprite_index + 1;
		}
		lidFrameCount.Value = lid_frame_count;
	}

	public override void draw(SpriteBatch spriteBatch, int x, int y, float alpha = 1f)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_058b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0700: Unknown result type (might be due to invalid IL or missing references)
		//IL_0705: Unknown result type (might be due to invalid IL or missing references)
		//IL_0708: Unknown result type (might be due to invalid IL or missing references)
		//IL_0713: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_074f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05be: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_060a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0895: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08be: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0816: Unknown result type (might be due to invalid IL or missing references)
		//IL_081b: Unknown result type (might be due to invalid IL or missing references)
		//IL_082a: Unknown result type (might be due to invalid IL or missing references)
		//IL_082f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0839: Unknown result type (might be due to invalid IL or missing references)
		//IL_0843: Unknown result type (might be due to invalid IL or missing references)
		//IL_0852: Unknown result type (might be due to invalid IL or missing references)
		//IL_0857: Unknown result type (might be due to invalid IL or missing references)
		//IL_085a: Unknown result type (might be due to invalid IL or missing references)
		//IL_086a: Unknown result type (might be due to invalid IL or missing references)
		//IL_086f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0872: Unknown result type (might be due to invalid IL or missing references)
		//IL_087d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0377: Unknown result type (might be due to invalid IL or missing references)
		//IL_037c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0388: Unknown result type (might be due to invalid IL or missing references)
		//IL_038d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0399: Unknown result type (might be due to invalid IL or missing references)
		//IL_039e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_096a: Unknown result type (might be due to invalid IL or missing references)
		//IL_096f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0971: Unknown result type (might be due to invalid IL or missing references)
		//IL_0982: Unknown result type (might be due to invalid IL or missing references)
		//IL_0992: Unknown result type (might be due to invalid IL or missing references)
		//IL_099c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0782: Unknown result type (might be due to invalid IL or missing references)
		//IL_0787: Unknown result type (might be due to invalid IL or missing references)
		//IL_0793: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_063d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0642: Unknown result type (might be due to invalid IL or missing references)
		//IL_0655: Unknown result type (might be due to invalid IL or missing references)
		//IL_0665: Unknown result type (might be due to invalid IL or missing references)
		//IL_066c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0673: Unknown result type (might be due to invalid IL or missing references)
		//IL_067d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03db: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0412: Unknown result type (might be due to invalid IL or missing references)
		//IL_042b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0430: Unknown result type (might be due to invalid IL or missing references)
		//IL_0444: Unknown result type (might be due to invalid IL or missing references)
		//IL_044e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0455: Unknown result type (might be due to invalid IL or missing references)
		//IL_045f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0479: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_051b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0520: Unknown result type (might be due to invalid IL or missing references)
		//IL_0525: Unknown result type (might be due to invalid IL or missing references)
		//IL_0532: Unknown result type (might be due to invalid IL or missing references)
		//IL_0539: Unknown result type (might be due to invalid IL or missing references)
		//IL_0540: Unknown result type (might be due to invalid IL or missing references)
		//IL_054a: Unknown result type (might be due to invalid IL or missing references)
		float num = x;
		float num2 = y;
		if (localKickStartTile.HasValue)
		{
			num = Utility.Lerp(localKickStartTile.Value.X, num, kickProgress);
			num2 = Utility.Lerp(localKickStartTile.Value.Y, num2, kickProgress);
		}
		float num3 = Math.Max(0f, ((num2 + 1f) * 64f - 24f) / 10000f) + num * 1E-05f;
		Rectangle bounds;
		if (localKickStartTile.HasValue)
		{
			Texture2D shadowTexture = Game1.shadowTexture;
			Vector2 val = Game1.GlobalToLocal(Game1.viewport, new Vector2((num + 0.5f) * 64f, (num2 + 0.5f) * 64f));
			Rectangle? val2 = Game1.shadowTexture.Bounds;
			Color val3 = Color.Black * 0.5f;
			bounds = Game1.shadowTexture.Bounds;
			float num4 = ((Rectangle)(ref bounds)).Center.X;
			bounds = Game1.shadowTexture.Bounds;
			spriteBatch.Draw(shadowTexture, val, val2, val3, 0f, new Vector2(num4, (float)((Rectangle)(ref bounds)).Center.Y), 4f, (SpriteEffects)0, 0.0001f);
			num2 -= (float)Math.Sin((double)kickProgress * Math.PI) * 0.5f;
		}
		if (playerChest.Value && (base.QualifiedItemId == "(BC)130" || base.QualifiedItemId == "(BC)232" || base.QualifiedItemId.Equals("(BC)BigChest") || base.QualifiedItemId.Equals("(BC)BigStoneChest")))
		{
			Color value = playerChoiceColor.Value;
			if (((Color)(ref value)).Equals(Color.Black))
			{
				ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
				Texture2D texture = dataOrErrorItem.GetTexture();
				spriteBatch.Draw(texture, Game1.GlobalToLocal(Game1.viewport, new Vector2(num * 64f + (float)((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0), (num2 - 1f) * 64f)), (Rectangle?)dataOrErrorItem.GetSourceRect(), tint.Value * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
				spriteBatch.Draw(texture, Game1.GlobalToLocal(Game1.viewport, new Vector2(num * 64f + (float)((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0), (num2 - 1f) * 64f)), (Rectangle?)dataOrErrorItem.GetSourceRect(0, currentLidFrame), tint.Value * alpha * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3 + 1E-05f);
				return;
			}
			ParsedItemData dataOrErrorItem2 = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
			Texture2D texture2 = dataOrErrorItem2.GetTexture();
			int num5 = base.ParentSheetIndex;
			int value2 = currentLidFrame + 8;
			int value3 = currentLidFrame;
			string qualifiedItemId = base.QualifiedItemId;
			if (!(qualifiedItemId == "(BC)130"))
			{
				if (qualifiedItemId == "(BC)BigChest")
				{
					num5 = 312;
					value2 = currentLidFrame + 16;
					value3 = currentLidFrame + 8;
				}
			}
			else
			{
				num5 = 168;
				value2 = currentLidFrame + 46;
				value3 = currentLidFrame + 38;
			}
			Rectangle sourceRect = dataOrErrorItem2.GetSourceRect(0, num5);
			Rectangle sourceRect2 = dataOrErrorItem2.GetSourceRect(0, value2);
			Rectangle sourceRect3 = dataOrErrorItem2.GetSourceRect(0, value3);
			spriteBatch.Draw(texture2, Game1.GlobalToLocal(Game1.viewport, new Vector2(num * 64f, (num2 - 1f) * 64f + (float)((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0))), (Rectangle?)sourceRect, playerChoiceColor.Value * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
			spriteBatch.Draw(texture2, Game1.GlobalToLocal(Game1.viewport, new Vector2(num * 64f, num2 * 64f + 20f)), (Rectangle?)new Rectangle(0, num5 / 8 * 32 + 53, 16, 11), Color.White * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3 + 2E-05f);
			spriteBatch.Draw(texture2, Game1.GlobalToLocal(Game1.viewport, new Vector2(num * 64f, (num2 - 1f) * 64f + (float)((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0))), (Rectangle?)sourceRect2, Color.White * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3 + 2E-05f);
			spriteBatch.Draw(texture2, Game1.GlobalToLocal(Game1.viewport, new Vector2(num * 64f, (num2 - 1f) * 64f + (float)((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0))), (Rectangle?)sourceRect3, playerChoiceColor.Value * alpha * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3 + 1E-05f);
			return;
		}
		if (playerChest.Value)
		{
			ParsedItemData dataOrErrorItem3 = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
			Texture2D texture3 = dataOrErrorItem3.GetTexture();
			spriteBatch.Draw(texture3, Game1.GlobalToLocal(Game1.viewport, new Vector2(num * 64f + (float)((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0), (num2 - 1f) * 64f)), (Rectangle?)dataOrErrorItem3.GetSourceRect(), tint.Value * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
			spriteBatch.Draw(texture3, Game1.GlobalToLocal(Game1.viewport, new Vector2(num * 64f + (float)((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0), (num2 - 1f) * 64f)), (Rectangle?)dataOrErrorItem3.GetSourceRect(0, currentLidFrame), tint.Value * alpha * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3 + 1E-05f);
			return;
		}
		if (giftbox.Value)
		{
			Texture2D shadowTexture2 = Game1.shadowTexture;
			Vector2 val4 = getLocalPosition(Game1.viewport) + new Vector2(16f, 53f);
			Rectangle? val5 = Game1.shadowTexture.Bounds;
			Color white = Color.White;
			bounds = Game1.shadowTexture.Bounds;
			float num6 = ((Rectangle)(ref bounds)).Center.X;
			bounds = Game1.shadowTexture.Bounds;
			spriteBatch.Draw(shadowTexture2, val4, val5, white, 0f, new Vector2(num6, (float)((Rectangle)(ref bounds)).Center.Y), 5f, (SpriteEffects)0, 1E-07f);
			if (GetItemsForPlayer().Count > 0)
			{
				int num7 = giftboxIndex.Value * 32;
				spriteBatch.Draw(Game1.giftboxTexture, Game1.GlobalToLocal(Game1.viewport, new Vector2(num * 64f + (float)((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0), num2 * 64f - 52f)), (Rectangle?)new Rectangle(0, num7, 16, 32), tint.Value, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
			}
			return;
		}
		int tilePosition = 500;
		Texture2D val6 = Game1.objectSpriteSheet;
		int height = 16;
		int num8 = 0;
		if (bigCraftableSpriteIndex.Value >= 0)
		{
			tilePosition = bigCraftableSpriteIndex.Value;
			val6 = Game1.bigCraftableSpriteSheet;
			height = 32;
			num8 = -64;
		}
		if (bigCraftableSpriteIndex.Value < 0)
		{
			Texture2D shadowTexture3 = Game1.shadowTexture;
			Vector2 val7 = getLocalPosition(Game1.viewport) + new Vector2(16f, 53f);
			Rectangle? val8 = Game1.shadowTexture.Bounds;
			Color white2 = Color.White;
			bounds = Game1.shadowTexture.Bounds;
			float num9 = ((Rectangle)(ref bounds)).Center.X;
			bounds = Game1.shadowTexture.Bounds;
			spriteBatch.Draw(shadowTexture3, val7, val8, white2, 0f, new Vector2(num9, (float)((Rectangle)(ref bounds)).Center.Y), 5f, (SpriteEffects)0, 1E-07f);
		}
		spriteBatch.Draw(val6, Game1.GlobalToLocal(Game1.viewport, new Vector2(num * 64f, num2 * 64f + (float)num8)), (Rectangle?)Game1.getSourceRectForStandardTileSheet(val6, tilePosition, 16, height), tint.Value, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
		Vector2 globalPosition = default(Vector2);
		((Vector2)(ref globalPosition))._002Ector(num * 64f, num2 * 64f + (float)num8);
		if (bigCraftableSpriteIndex.Value < 0)
		{
			switch (currentLidFrame)
			{
			case 501:
				globalPosition.Y -= 32f;
				break;
			case 502:
				globalPosition.Y -= 40f;
				break;
			case 503:
				globalPosition.Y -= 60f;
				break;
			}
		}
		spriteBatch.Draw(val6, Game1.GlobalToLocal(Game1.viewport, globalPosition), (Rectangle?)Game1.getSourceRectForStandardTileSheet(val6, currentLidFrame, 16, height), tint.Value, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3 + 1E-05f);
	}

	public virtual void draw(SpriteBatch spriteBatch, int x, int y, float alpha = 1f, bool local = false)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_031a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0335: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0364: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03be: Unknown result type (might be due to invalid IL or missing references)
		//IL_038e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0393: Unknown result type (might be due to invalid IL or missing references)
		if (!playerChest.Value)
		{
			return;
		}
		if (playerChoiceColor.Equals(Color.Black))
		{
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
			spriteBatch.Draw(dataOrErrorItem.GetTexture(), (Vector2)(local ? new Vector2((float)x, (float)(y - 64)) : Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0)), (float)((y - 1) * 64)))), (Rectangle?)dataOrErrorItem.GetSourceRect(), tint.Value * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, local ? 0.89f : ((float)(y * 64 + 4) / 10000f));
			return;
		}
		ParsedItemData data = ItemRegistry.GetData(base.QualifiedItemId);
		if (data != null)
		{
			int num = base.ParentSheetIndex;
			int value = currentLidFrame + 8;
			int value2 = currentLidFrame;
			switch (base.QualifiedItemId)
			{
			case "(BC)130":
				num = 168;
				value = currentLidFrame + 46;
				value2 = currentLidFrame + 38;
				break;
			case "(BC)BigChest":
				num = 312;
				value = currentLidFrame + 16;
				value2 = currentLidFrame + 8;
				break;
			case "(BC)BigStoneChest":
				value = currentLidFrame + 8;
				value2 = currentLidFrame;
				break;
			}
			Rectangle sourceRect = data.GetSourceRect(0, num);
			Rectangle sourceRect2 = data.GetSourceRect(0, value);
			Rectangle sourceRect3 = data.GetSourceRect(0, value2);
			Texture2D texture = data.GetTexture();
			spriteBatch.Draw(texture, (Vector2)(local ? new Vector2((float)x, (float)(y - 64)) : Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)((y - 1) * 64 + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0))))), (Rectangle?)sourceRect, playerChoiceColor.Value * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, local ? 0.9f : ((float)(y * 64 + 4) / 10000f));
			spriteBatch.Draw(texture, (Vector2)(local ? new Vector2((float)x, (float)(y - 64)) : Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)((y - 1) * 64 + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0))))), (Rectangle?)sourceRect3, playerChoiceColor.Value * alpha * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, local ? 0.9f : ((float)(y * 64 + 5) / 10000f));
			spriteBatch.Draw(texture, (Vector2)(local ? new Vector2((float)x, (float)(y + 20)) : Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)(y * 64 + 20)))), (Rectangle?)new Rectangle(0, num / 8 * 32 + 53, 16, 11), Color.White * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, local ? 0.91f : ((float)(y * 64 + 6) / 10000f));
			spriteBatch.Draw(texture, (Vector2)(local ? new Vector2((float)x, (float)(y - 64)) : Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)((y - 1) * 64 + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0))))), (Rectangle?)sourceRect2, Color.White * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, local ? 0.91f : ((float)(y * 64 + 6) / 10000f));
		}
	}

	public override bool ForEachItem(ForEachItemDelegate handler, GetForEachItemPathDelegate getPath)
	{
		if (base.ForEachItem(handler, getPath))
		{
			return ForEachItemHelper.ApplyToList(Items, handler, getPath);
		}
		return false;
	}
}
