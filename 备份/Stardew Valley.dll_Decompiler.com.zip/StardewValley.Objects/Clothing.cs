using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.GameData.Shirts;
using StardewValley.ItemTypeDefinitions;
using StardewValley.TokenizableStrings;

namespace StardewValley.Objects;

public class Clothing : Item
{
	public enum ClothesType
	{
		SHIRT,
		PANTS
	}

	public const int SHIRT_SHEET_WIDTH = 128;

	public const string DefaultShirtSheetName = "Characters\\Farmer\\shirts";

	public const string DefaultPantsSheetName = "Characters\\Farmer\\pants";

	public const int MinShirtId = 1000;

	[XmlElement("price")]
	public readonly NetInt price = new NetInt();

	[XmlElement("indexInTileSheet")]
	public readonly NetInt indexInTileSheet = new NetInt();

	[XmlElement("indexInTileSheetFemale")]
	public int? obsolete_indexInTileSheetFemale;

	[XmlIgnore]
	public string description;

	[XmlIgnore]
	public string displayName;

	[XmlElement("clothesType")]
	public readonly NetEnum<ClothesType> clothesType = new NetEnum<ClothesType>();

	[XmlElement("dyeable")]
	public readonly NetBool dyeable = new NetBool(value: false);

	[XmlElement("clothesColor")]
	public readonly NetColor clothesColor = new NetColor(new Color(255, 255, 255));

	[XmlElement("isPrismatic")]
	public readonly NetBool isPrismatic = new NetBool(value: false);

	[XmlIgnore]
	protected bool _loadedData;

	public override string TypeDefinitionId
	{
		get
		{
			if (clothesType.Value != ClothesType.PANTS)
			{
				return "(S)";
			}
			return "(P)";
		}
	}

	public int Price
	{
		get
		{
			return price.Value;
		}
		set
		{
			price.Value = value;
		}
	}

	[XmlIgnore]
	public override string DisplayName
	{
		get
		{
			if (!_loadedData)
			{
				LoadData();
			}
			return displayName;
		}
	}

	public Clothing()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		base.Category = -100;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(price, "price").AddField(indexInTileSheet, "indexInTileSheet").AddField(clothesType, "clothesType")
			.AddField(dyeable, "dyeable")
			.AddField(clothesColor, "clothesColor")
			.AddField(isPrismatic, "isPrismatic");
	}

	public Clothing(string itemId)
		: this()
	{
		itemId = ValidateUnqualifiedItemId(itemId);
		Name = "Clothing";
		base.Category = -100;
		base.ItemId = itemId;
		LoadData(applyColor: true);
	}

	public virtual void LoadData(bool applyColor = false, bool forceReload = false)
	{
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		if (_loadedData && !forceReload)
		{
			return;
		}
		base.Category = -100;
		ShirtData value2;
		if (Game1.pantsData.TryGetValue(base.ItemId, out var value))
		{
			Name = value.Name;
			price.Value = value.Price;
			indexInTileSheet.Value = value.SpriteIndex;
			dyeable.Value = value.CanBeDyed;
			if (applyColor)
			{
				clothesColor.Value = (Color)(((_003F?)Utility.StringToColor(value.DefaultColor)) ?? Color.White);
			}
			else if (forceReload)
			{
				clothesColor.Value = Color.White;
			}
			displayName = TokenParser.ParseText(value.DisplayName);
			description = TokenParser.ParseText(value.Description);
			clothesType.Value = ClothesType.PANTS;
			isPrismatic.Value = value.IsPrismatic;
		}
		else if (Game1.shirtData.TryGetValue(base.ItemId, out value2))
		{
			Name = value2.Name;
			price.Value = value2.Price;
			indexInTileSheet.Value = value2.SpriteIndex;
			dyeable.Value = value2.CanBeDyed;
			if (applyColor)
			{
				clothesColor.Value = (Color)(((_003F?)Utility.StringToColor(value2.DefaultColor)) ?? Color.White);
			}
			else if (forceReload)
			{
				clothesColor.Value = Color.White;
			}
			displayName = TokenParser.ParseText(value2.DisplayName);
			description = TokenParser.ParseText(value2.Description);
			clothesType.Value = ClothesType.SHIRT;
			isPrismatic.Value = value2.IsPrismatic;
		}
		else
		{
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
			displayName = dataOrErrorItem.DisplayName;
			description = dataOrErrorItem.Description;
		}
		if (dyeable.Value)
		{
			description = description + Environment.NewLine + Environment.NewLine + Game1.content.LoadString("Strings\\UI:Clothes_Dyeable");
		}
		_loadedData = true;
	}

	public override string getCategoryName()
	{
		return Object.GetCategoryDisplayName(-100);
	}

	public override int salePrice(bool ignoreProfitMargins = false)
	{
		return price.Value;
	}

	public virtual void Dye(Color color, float strength = 0.5f)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		if (dyeable.Value)
		{
			Color value = clothesColor.Value;
			clothesColor.Value = new Color(Utility.MoveTowards((float)(int)((Color)(ref value)).R / 255f, (float)(int)((Color)(ref color)).R / 255f, strength), Utility.MoveTowards((float)(int)((Color)(ref value)).G / 255f, (float)(int)((Color)(ref color)).G / 255f, strength), Utility.MoveTowards((float)(int)((Color)(ref value)).B / 255f, (float)(int)((Color)(ref color)).B / 255f, strength), Utility.MoveTowards((float)(int)((Color)(ref value)).A / 255f, (float)(int)((Color)(ref color)).A / 255f, strength));
		}
	}

	public override void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		AdjustMenuDrawForRecipes(ref transparency, ref scaleSize);
		Color a = clothesColor.Value;
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
		Texture2D texture = dataOrErrorItem.GetTexture();
		Rectangle sourceRect = dataOrErrorItem.GetSourceRect();
		Rectangle empty = Rectangle.Empty;
		if (!dataOrErrorItem.IsErrorItem)
		{
			if (clothesType.Value == ClothesType.SHIRT)
			{
				((Rectangle)(ref empty))._002Ector(sourceRect.X + texture.Width / 2, sourceRect.Y, sourceRect.Width, sourceRect.Height);
			}
			if (isPrismatic.Value)
			{
				a = Utility.GetPrismaticColor();
			}
		}
		switch (clothesType.Value)
		{
		case ClothesType.SHIRT:
		{
			float num = 1E-07f;
			if (layerDepth >= 1f - num)
			{
				layerDepth = 1f - num;
			}
			Vector2 val = default(Vector2);
			((Vector2)(ref val))._002Ector(4f, 4f);
			if (dataOrErrorItem.IsErrorItem)
			{
				val.X = sourceRect.Width / 2;
				val.Y = sourceRect.Height / 2;
			}
			spriteBatch.Draw(texture, location + new Vector2(32f, 32f), (Rectangle?)sourceRect, color * transparency, 0f, val, scaleSize * 4f, (SpriteEffects)0, layerDepth);
			spriteBatch.Draw(texture, location + new Vector2(32f, 32f), (Rectangle?)empty, Utility.MultiplyColor(a, color) * transparency, 0f, val, scaleSize * 4f, (SpriteEffects)0, layerDepth + num);
			break;
		}
		case ClothesType.PANTS:
			spriteBatch.Draw(texture, location + new Vector2(32f, 32f), (Rectangle?)sourceRect, Utility.MultiplyColor(a, color) * transparency, 0f, new Vector2(8f, 8f), scaleSize * 4f, (SpriteEffects)0, layerDepth);
			break;
		}
		DrawMenuIcons(spriteBatch, location, scaleSize, transparency, layerDepth, drawStackNumber, color);
	}

	public override int maximumStackSize()
	{
		return 1;
	}

	public override string getDescription()
	{
		if (!_loadedData)
		{
			LoadData();
		}
		return Game1.parseText(description, Game1.smallFont, getDescriptionWidth());
	}

	public override bool isPlaceable()
	{
		return false;
	}

	protected override Item GetOneNew()
	{
		return new Clothing(base.ItemId);
	}

	protected override void GetOneCopyFrom(Item source)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		base.GetOneCopyFrom(source);
		if (source is Clothing clothing)
		{
			clothesColor.Value = clothing.clothesColor.Value;
		}
	}
}
