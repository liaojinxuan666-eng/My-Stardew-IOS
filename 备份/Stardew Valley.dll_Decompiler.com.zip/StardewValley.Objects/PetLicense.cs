using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Buildings;
using StardewValley.Characters;
using StardewValley.GameData.Pets;
using StardewValley.Locations;
using StardewValley.Menus;

namespace StardewValley.Objects;

public class PetLicense : Object
{
	public const char Delimiter = '|';

	public PetLicense()
		: base("PetLicense", 1)
	{
	}

	public override void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		AdjustMenuDrawForRecipes(ref transparency, ref scaleSize);
		if (drawShadow && !bigCraftable.Value && base.QualifiedItemId != "(O)590" && base.QualifiedItemId != "(O)SeedSpot")
		{
			Texture2D shadowTexture = Game1.shadowTexture;
			Vector2 val = location + new Vector2(32f, 48f);
			Rectangle? val2 = Game1.shadowTexture.Bounds;
			Color val3 = color * 0.5f;
			Rectangle bounds = Game1.shadowTexture.Bounds;
			float num = ((Rectangle)(ref bounds)).Center.X;
			bounds = Game1.shadowTexture.Bounds;
			spriteBatch.Draw(shadowTexture, val, val2, val3, 0f, new Vector2(num, (float)((Rectangle)(ref bounds)).Center.Y), 3f, (SpriteEffects)0, layerDepth - 0.0001f);
		}
		ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
		float num2 = scaleSize;
		if (bigCraftable.Value && num2 > 0.2f)
		{
			num2 /= 2f;
		}
		string[] array = Name.Split('|');
		if (Game1.petData.TryGetValue(array[0], out var value))
		{
			PetBreed breedById = value.GetBreedById(array[1], false);
			if (breedById != null)
			{
				Rectangle iconSourceRect = breedById.IconSourceRect;
				spriteBatch.Draw(Game1.content.Load<Texture2D>(breedById.IconTexture), location + new Vector2(32f, 32f), (Rectangle?)iconSourceRect, color * transparency, 0f, new Vector2((float)(iconSourceRect.Width / 2), (float)(iconSourceRect.Height / 2)), 4f * num2, (SpriteEffects)0, layerDepth);
			}
		}
		DrawMenuIcons(spriteBatch, location, scaleSize, transparency, layerDepth, drawStackNumber, color);
	}

	public override bool actionWhenPurchased(string shopId)
	{
		Game1.exitActiveMenu();
		string title = Game1.content.LoadString("Strings\\StringsFromCSFiles:Event.cs.1236");
		Game1.activeClickableMenu = new NamingMenu(namePet, title, Dialogue.randomName());
		Game1.playSound("purchaseClick");
		return true;
	}

	private void namePet(string name)
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		string[] array = Name.Split('|');
		FarmHouse homeOfFarmer = Utility.getHomeOfFarmer(Game1.player);
		Point val = default(Point);
		((Point)(ref val))._002Ector(3, 7);
		if (homeOfFarmer.upgradeLevel == 1)
		{
			((Point)(ref val))._002Ector(9, 7);
		}
		else if (homeOfFarmer.upgradeLevel >= 2)
		{
			((Point)(ref val))._002Ector(27, 26);
		}
		Pet pet = new Pet(val.X, val.Y, array[1], array[0]);
		pet.currentLocation = homeOfFarmer;
		homeOfFarmer.characters.Add(pet);
		pet.warpToFarmHouse(Game1.player);
		pet.Name = name;
		pet.displayName = pet.name.Value;
		foreach (Building building in Game1.getFarm().buildings)
		{
			if (building is PetBowl petBowl && !petBowl.HasPet())
			{
				petBowl.AssignPet(pet);
				break;
			}
		}
		foreach (Farmer allFarmer in Game1.getAllFarmers())
		{
			allFarmer.autoGenerateActiveDialogueEvent("gotPet");
		}
		Game1.exitActiveMenu();
		if (Game1.currentLocation.getCharacterFromName("Marnie") != null)
		{
			Game1.DrawDialogue(Game1.currentLocation.getCharacterFromName("Marnie"), "Strings\\1_6_Strings:AdoptedPet_Marnie", name);
		}
		else
		{
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\1_6_Strings:AdoptedPet", name));
		}
	}
}
