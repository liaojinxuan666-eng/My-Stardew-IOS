using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Objects.Trinkets;

namespace StardewValley.Objects;

public class TankFish
{
	public enum FishType
	{
		Normal,
		Eel,
		Cephalopod,
		Float,
		Ground,
		Crawl,
		Hop,
		Static
	}

	public const int field_spriteIndex = 0;

	public const int field_type = 1;

	public const int field_idleAnimations = 2;

	public const int field_dartStartFrames = 3;

	public const int field_dartHoldFrames = 4;

	public const int field_dartEndFrames = 5;

	public const int field_texture = 6;

	public const int field_hatOffset = 7;

	protected FishTankFurniture _tank;

	public Vector2 position;

	public float zPosition;

	public bool facingLeft;

	public Vector2 velocity = Vector2.Zero;

	protected Texture2D _texture;

	public float nextSwim;

	public string fishItemId = "";

	public int fishIndex;

	public int currentFrame;

	public Point? hatPosition;

	public int frogVariant;

	public int numberOfDarts;

	public FishType fishType;

	public float minimumVelocity;

	public float fishScale = 1f;

	public List<int> currentAnimation;

	public List<int> idleAnimation;

	public List<int> dartStartAnimation;

	public List<int> dartHoldAnimation;

	public List<int> dartEndAnimation;

	public int currentAnimationFrame;

	public float currentFrameTime;

	public float nextBubble;

	public bool isErrorFish;

	public TankFish(FishTankFurniture tank, Item item)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_055d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0562: Unknown result type (might be due to invalid IL or missing references)
		//IL_0546: Unknown result type (might be due to invalid IL or missing references)
		//IL_054b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0569: Unknown result type (might be due to invalid IL or missing references)
		//IL_0574: Unknown result type (might be due to invalid IL or missing references)
		//IL_0579: Unknown result type (might be due to invalid IL or missing references)
		_tank = tank;
		fishItemId = item.ItemId;
		if (!_tank.GetAquariumData().TryGetValue(item.ItemId, out var value))
		{
			value = "0/float";
			isErrorFish = true;
		}
		string[] array = value.Split('/');
		string text = ArgUtility.Get(array, 6, null, allowBlank: false);
		if (text != null)
		{
			try
			{
				_texture = Game1.content.Load<Texture2D>(text);
			}
			catch (Exception)
			{
				isErrorFish = true;
			}
		}
		if (_texture == null)
		{
			_texture = _tank.GetAquariumTexture();
		}
		string text2 = ArgUtility.Get(array, 7, null, allowBlank: false);
		if (text2 != null)
		{
			try
			{
				string[] array2 = ArgUtility.SplitBySpace(text2);
				hatPosition = new Point(int.Parse(array2[0]), int.Parse(array2[1]));
			}
			catch (Exception)
			{
				hatPosition = null;
			}
		}
		fishIndex = int.Parse(array[0]);
		currentFrame = fishIndex;
		zPosition = Utility.RandomFloat(4f, 10f);
		fishScale = 0.75f;
		if (DataLoader.Fish(Game1.content).TryGetValue(item.ItemId, out var value2))
		{
			string[] array3 = value2.Split('/');
			if (!(array3[1] == "trap"))
			{
				minimumVelocity = Utility.RandomFloat(0.25f, 0.35f);
				if (array3[2] == "smooth")
				{
					minimumVelocity = Utility.RandomFloat(0.5f, 0.6f);
				}
				if (array3[2] == "dart")
				{
					minimumVelocity = 0f;
				}
			}
		}
		switch (ArgUtility.Get(array, 1))
		{
		case "eel":
			fishType = FishType.Eel;
			minimumVelocity = Utility.Clamp(fishScale, 0.3f, 0.4f);
			break;
		case "cephalopod":
			fishType = FishType.Cephalopod;
			minimumVelocity = 0f;
			break;
		case "ground":
			fishType = FishType.Ground;
			zPosition = 4f;
			minimumVelocity = 0f;
			break;
		case "static":
			fishType = FishType.Static;
			break;
		case "crawl":
			fishType = FishType.Crawl;
			minimumVelocity = 0f;
			break;
		case "front_crawl":
			fishType = FishType.Crawl;
			zPosition = 3f;
			minimumVelocity = 0f;
			break;
		case "float":
			fishType = FishType.Float;
			break;
		}
		string text3 = ArgUtility.Get(array, 2, null, allowBlank: false);
		if (text3 != null)
		{
			string[] array4 = ArgUtility.SplitBySpace(text3);
			idleAnimation = new List<int>();
			string[] array5 = array4;
			foreach (string s in array5)
			{
				idleAnimation.Add(int.Parse(s));
			}
			SetAnimation(idleAnimation);
		}
		string text4 = ArgUtility.Get(array, 3, null, allowBlank: false);
		if (text4 != null)
		{
			string[] array6 = ArgUtility.SplitBySpace(text4);
			dartStartAnimation = new List<int>();
			string[] array5 = array6;
			foreach (string s2 in array5)
			{
				dartStartAnimation.Add(int.Parse(s2));
			}
		}
		string text5 = ArgUtility.Get(array, 4, null, allowBlank: false);
		if (text5 != null)
		{
			string[] array7 = ArgUtility.SplitBySpace(text5);
			dartHoldAnimation = new List<int>();
			string[] array5 = array7;
			foreach (string s3 in array5)
			{
				dartHoldAnimation.Add(int.Parse(s3));
			}
		}
		string text6 = ArgUtility.Get(array, 5, null, allowBlank: false);
		if (text6 != null)
		{
			string[] array8 = ArgUtility.SplitBySpace(text6);
			dartEndAnimation = new List<int>();
			string[] array5 = array8;
			foreach (string s4 in array5)
			{
				dartEndAnimation.Add(int.Parse(s4));
			}
		}
		Rectangle tankBounds = _tank.GetTankBounds();
		tankBounds.X = 0;
		tankBounds.Y = 0;
		position = Vector2.Zero;
		position = Utility.getRandomPositionInThisRectangle(tankBounds, Game1.random);
		nextSwim = Utility.RandomFloat(0.1f, 10f);
		nextBubble = Utility.RandomFloat(0.1f, 10f);
		facingLeft = Game1.random.Next(2) == 1;
		if (facingLeft)
		{
			velocity = new Vector2(-1f, 0f);
		}
		else
		{
			velocity = new Vector2(1f, 0f);
		}
		velocity *= minimumVelocity;
		if (item.QualifiedItemId == "(TR)FrogEgg")
		{
			fishType = FishType.Hop;
			_texture = Game1.content.Load<Texture2D>("TileSheets\\companions");
			frogVariant = ((item as Trinket).GetEffect() as CompanionTrinketEffect).Variant;
			isErrorFish = false;
		}
		if (fishType == FishType.Ground || fishType == FishType.Crawl || fishType == FishType.Hop || fishType == FishType.Static)
		{
			position.Y = 0f;
		}
		ConstrainToTank();
	}

	public void SetAnimation(List<int> frames)
	{
		if (fishType != FishType.Hop && currentAnimation != frames)
		{
			currentAnimation = frames;
			currentAnimationFrame = 0;
			currentFrameTime = 0f;
			List<int> list = currentAnimation;
			if (list != null && list.Count > 0)
			{
				currentFrame = frames[0];
			}
		}
	}

	public virtual void Draw(SpriteBatch b, float alpha, float draw_layer)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0369: Unknown result type (might be due to invalid IL or missing references)
		//IL_0375: Unknown result type (might be due to invalid IL or missing references)
		//IL_037f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0386: Unknown result type (might be due to invalid IL or missing references)
		//IL_038b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0390: Unknown result type (might be due to invalid IL or missing references)
		//IL_039d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_03be: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_057e: Unknown result type (might be due to invalid IL or missing references)
		//IL_058e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0593: Unknown result type (might be due to invalid IL or missing references)
		//IL_05aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_05af: Unknown result type (might be due to invalid IL or missing references)
		//IL_05be: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0604: Unknown result type (might be due to invalid IL or missing references)
		//IL_0610: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_032c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0339: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0502: Unknown result type (might be due to invalid IL or missing references)
		//IL_0507: Unknown result type (might be due to invalid IL or missing references)
		//IL_050c: Unknown result type (might be due to invalid IL or missing references)
		//IL_051d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0527: Unknown result type (might be due to invalid IL or missing references)
		//IL_052d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0541: Unknown result type (might be due to invalid IL or missing references)
		//IL_054e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0701: Unknown result type (might be due to invalid IL or missing references)
		//IL_0703: Unknown result type (might be due to invalid IL or missing references)
		//IL_0708: Unknown result type (might be due to invalid IL or missing references)
		//IL_0761: Unknown result type (might be due to invalid IL or missing references)
		//IL_076b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0770: Unknown result type (might be due to invalid IL or missing references)
		//IL_0773: Unknown result type (might be due to invalid IL or missing references)
		//IL_0778: Unknown result type (might be due to invalid IL or missing references)
		//IL_077a: Unknown result type (might be due to invalid IL or missing references)
		//IL_077f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0784: Unknown result type (might be due to invalid IL or missing references)
		//IL_072b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0735: Unknown result type (might be due to invalid IL or missing references)
		//IL_0747: Unknown result type (might be due to invalid IL or missing references)
		//IL_0751: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07de: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0807: Unknown result type (might be due to invalid IL or missing references)
		//IL_080e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0818: Unknown result type (might be due to invalid IL or missing references)
		//IL_081d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0822: Unknown result type (might be due to invalid IL or missing references)
		//IL_0827: Unknown result type (might be due to invalid IL or missing references)
		SpriteEffects val = (SpriteEffects)0;
		int num = -12;
		int num2 = 8;
		if (fishType == FishType.Eel)
		{
			num2 = 4;
		}
		int num3 = num2;
		if (facingLeft)
		{
			val = (SpriteEffects)1;
			num3 *= -1;
			num = -num - num2;
		}
		float num4 = (float)Math.Sin(Game1.currentGameTime.TotalGameTime.TotalSeconds * 1.25 + (double)(position.X / 32f)) * 2f;
		if (fishType == FishType.Crawl || fishType == FishType.Ground || fishType == FishType.Static)
		{
			num4 = 0f;
		}
		float scale = GetScale();
		int num5 = _texture.Width / 24;
		int num6 = currentFrame % num5 * 24;
		int num7 = currentFrame / num5 * 48;
		int num8 = 10;
		float num9 = 1f;
		if (fishType == FishType.Eel)
		{
			num8 = 20;
			num4 *= 0f;
		}
		float num10 = -12f;
		float num11 = 0f;
		if (isErrorFish)
		{
			num11 = 0f;
			IItemDataDefinition itemDataDefinition = ItemRegistry.RequireTypeDefinition("(F)");
			b.Draw(itemDataDefinition.GetErrorTexture(), Game1.GlobalToLocal(GetWorldPosition() + new Vector2(0f, num4) * 4f * scale), (Rectangle?)itemDataDefinition.GetErrorSourceRect(), Color.White * alpha, num11, new Vector2(12f, 12f), 4f * scale, val, draw_layer);
		}
		else
		{
			switch (fishType)
			{
			case FishType.Ground:
			case FishType.Crawl:
			case FishType.Static:
				num11 = 0f;
				b.Draw(_texture, Game1.GlobalToLocal(GetWorldPosition() + new Vector2(0f, num4) * 4f * scale), (Rectangle?)new Rectangle(num6, num7, 24, 24), Color.White * alpha, num11, new Vector2(12f, 12f), 4f * scale, val, draw_layer);
				break;
			case FishType.Hop:
			{
				int num16 = 0;
				if (position.Y > 0f)
				{
					num16 = ((!((double)velocity.Y > 0.2)) ? 3 : (((double)velocity.Y > 0.3) ? 1 : 2));
				}
				else if (nextSwim <= 3f)
				{
					num16 = ((Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 400.0 >= 200.0) ? 5 : 6);
				}
				Rectangle value2 = default(Rectangle);
				((Rectangle)(ref value2))._002Ector(num16 * 16, 16 + frogVariant * 16, 16, 16);
				Color val2 = Color.White;
				if (frogVariant == 7)
				{
					val2 = Utility.GetPrismaticColor();
				}
				b.Draw(_texture, Game1.GlobalToLocal(GetWorldPosition() + new Vector2(16f, -8f)), (Rectangle?)value2, val2 * alpha, num11, new Vector2(12f, 12f), 4f * scale, val, draw_layer);
				break;
			}
			case FishType.Cephalopod:
			case FishType.Float:
				num11 = Utility.Clamp(velocity.X, -0.5f, 0.5f);
				b.Draw(_texture, Game1.GlobalToLocal(GetWorldPosition() + new Vector2(0f, num4) * 4f * scale), (Rectangle?)new Rectangle(num6, num7, 24, 24), Color.White * alpha, num11, new Vector2(12f, 12f), 4f * scale, val, draw_layer);
				break;
			default:
			{
				for (int i = 0; i < 24 / num2; i++)
				{
					float num12 = (float)(i * num2) / (float)num8;
					num12 = 1f - num12;
					float value = ((Vector2)(ref velocity)).Length() / 1f;
					float num13 = 1f;
					float num14 = 0f;
					value = Utility.Clamp(value, 0.2f, 1f);
					num12 = Utility.Clamp(num12, 0f, 1f);
					if (fishType == FishType.Eel)
					{
						num12 = 1f;
						value = 1f;
						num13 = 0.1f;
						num14 = 4f;
					}
					if (facingLeft)
					{
						num14 *= -1f;
					}
					float num15 = (float)(Math.Sin((double)(i * 20) + Game1.currentGameTime.TotalGameTime.TotalSeconds * 25.0 * (double)num13 + (double)(num14 * position.X / 16f)) * (double)num9 * (double)num12 * (double)value);
					if (i == 24 / num2 - 1)
					{
						num10 = -12f + num15;
					}
					b.Draw(_texture, Game1.GlobalToLocal(GetWorldPosition() + new Vector2((float)(num + i * num3), num4 + num15) * 4f * scale), (Rectangle?)new Rectangle(num6 + i * num2, num7, num2, 24), Color.White * alpha, 0f, new Vector2(0f, 12f), 4f * scale, val, draw_layer);
				}
				break;
			}
			}
		}
		float num17 = (facingLeft ? 12 : (-12));
		Texture2D shadowTexture = Game1.shadowTexture;
		float x = GetWorldPosition().X;
		Rectangle tankBounds = _tank.GetTankBounds();
		b.Draw(shadowTexture, Game1.GlobalToLocal(new Vector2(x, (float)((Rectangle)(ref tankBounds)).Bottom - zPosition * 4f)), (Rectangle?)null, Color.White * alpha * 0.75f, 0f, new Vector2((float)(Game1.shadowTexture.Width / 2), (float)(Game1.shadowTexture.Height / 2)), new Vector2(4f * scale, 1f), (SpriteEffects)0, _tank.GetFishSortRegion().X - 1E-07f);
		int num18 = 0;
		foreach (TankFish item in _tank.tankFish)
		{
			if (item == this)
			{
				break;
			}
			if (item.CanWearHat())
			{
				num18++;
			}
		}
		if (!CanWearHat())
		{
			return;
		}
		int num19 = 0;
		Vector2 val3 = default(Vector2);
		foreach (Item heldItem in _tank.heldItems)
		{
			if (!(heldItem is Hat hat))
			{
				continue;
			}
			if (num19 == num18)
			{
				((Vector2)(ref val3))._002Ector((float)hatPosition.Value.X, (float)hatPosition.Value.Y);
				if (facingLeft)
				{
					val3.X *= -1f;
				}
				Vector2 val4 = new Vector2(num17, num10) + val3;
				if (num11 != 0f)
				{
					float num20 = (float)Math.Cos(num11);
					float num21 = (float)Math.Sin(num11);
					val4.X = val4.X * num20 - val4.Y * num21;
					val4.Y = val4.X * num21 + val4.Y * num20;
				}
				val4 *= 4f * scale;
				Vector2 val5 = Game1.GlobalToLocal(GetWorldPosition() + val4);
				val5.Y += num4;
				int direction = ((fishType == FishType.Cephalopod || fishType == FishType.Static) ? 2 : ((!facingLeft) ? 1 : 3));
				val5 -= new Vector2(10f, 10f);
				val5 += new Vector2(3f, 3f) * scale * 3f;
				val5 -= new Vector2(10f, 10f) * scale * 3f;
				hat.draw(b, val5, scale, 1f, draw_layer + 1E-08f, direction);
				num18++;
				break;
			}
			num19++;
		}
	}

	[MemberNotNullWhen(true, "hatPosition")]
	public bool CanWearHat()
	{
		return hatPosition.HasValue;
	}

	public Vector2 GetWorldPosition()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		float num = (float)_tank.GetTankBounds().X + position.X;
		Rectangle tankBounds = _tank.GetTankBounds();
		return new Vector2(num, (float)((Rectangle)(ref tankBounds)).Bottom - position.Y - zPosition * 4f);
	}

	public void ConstrainToTank()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		Rectangle tankBounds = _tank.GetTankBounds();
		Rectangle bounds = GetBounds();
		tankBounds.X = 0;
		tankBounds.Y = 0;
		if (bounds.X < tankBounds.X)
		{
			position.X += tankBounds.X - bounds.X;
			bounds = GetBounds();
		}
		if (bounds.Y < tankBounds.Y)
		{
			position.Y -= tankBounds.Y - bounds.Y;
			bounds = GetBounds();
		}
		if (((Rectangle)(ref bounds)).Right > ((Rectangle)(ref tankBounds)).Right)
		{
			position.X += ((Rectangle)(ref tankBounds)).Right - ((Rectangle)(ref bounds)).Right;
			bounds = GetBounds();
		}
		if (fishType == FishType.Crawl || fishType == FishType.Ground || fishType == FishType.Static || fishType == FishType.Hop)
		{
			if (position.Y > (float)((Rectangle)(ref tankBounds)).Bottom)
			{
				position.Y -= (float)((Rectangle)(ref tankBounds)).Bottom - position.Y;
			}
		}
		else if (((Rectangle)(ref bounds)).Bottom > ((Rectangle)(ref tankBounds)).Bottom)
		{
			position.Y -= ((Rectangle)(ref tankBounds)).Bottom - ((Rectangle)(ref bounds)).Bottom;
		}
	}

	public virtual float GetScale()
	{
		return fishScale;
	}

	public Rectangle GetBounds()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(24f, 18f);
		val *= 4f * GetScale();
		if (fishType == FishType.Crawl || fishType == FishType.Ground || fishType == FishType.Static || fishType == FishType.Hop)
		{
			return new Rectangle((int)(position.X - val.X / 2f), (int)((float)_tank.GetTankBounds().Height - position.Y - val.Y), (int)val.X, (int)val.Y);
		}
		return new Rectangle((int)(position.X - val.X / 2f), (int)((float)_tank.GetTankBounds().Height - position.Y - val.Y / 2f), (int)val.X, (int)val.Y);
	}

	public virtual void Update(GameTime time)
	{
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fb: Unknown result type (might be due to invalid IL or missing references)
		List<int> list = currentAnimation;
		if (list != null && list.Count > 0)
		{
			currentFrameTime += (float)time.ElapsedGameTime.TotalSeconds;
			float num = 0.125f;
			if (currentFrameTime > num)
			{
				currentAnimationFrame += (int)(currentFrameTime / num);
				currentFrameTime %= num;
				if (currentAnimationFrame >= currentAnimation.Count)
				{
					if (currentAnimation == idleAnimation)
					{
						currentAnimationFrame %= currentAnimation.Count;
						currentFrame = currentAnimation[currentAnimationFrame];
					}
					else if (currentAnimation == dartStartAnimation)
					{
						if (dartHoldAnimation != null)
						{
							SetAnimation(dartHoldAnimation);
						}
						else
						{
							SetAnimation(idleAnimation);
						}
					}
					else if (currentAnimation == dartHoldAnimation)
					{
						currentAnimationFrame %= currentAnimation.Count;
						currentFrame = currentAnimation[currentAnimationFrame];
					}
					else if (currentAnimation == dartEndAnimation)
					{
						SetAnimation(idleAnimation);
					}
				}
				else
				{
					currentFrame = currentAnimation[currentAnimationFrame];
				}
			}
		}
		if (fishType != FishType.Static)
		{
			Rectangle tankBounds = _tank.GetTankBounds();
			tankBounds.X = 0;
			tankBounds.Y = 0;
			float num2 = velocity.X;
			if (fishType == FishType.Crawl)
			{
				num2 = Utility.Clamp(num2, -0.5f, 0.5f);
			}
			position.X += num2;
			Rectangle bounds = GetBounds();
			if (((Rectangle)(ref bounds)).Left < ((Rectangle)(ref tankBounds)).Left || ((Rectangle)(ref bounds)).Right > ((Rectangle)(ref tankBounds)).Right)
			{
				ConstrainToTank();
				bounds = GetBounds();
				velocity.X *= -1f;
				facingLeft = !facingLeft;
			}
			position.Y += velocity.Y;
			bounds = GetBounds();
			if (((Rectangle)(ref bounds)).Top < ((Rectangle)(ref tankBounds)).Top || ((Rectangle)(ref bounds)).Bottom > ((Rectangle)(ref tankBounds)).Bottom)
			{
				ConstrainToTank();
				velocity.Y *= 0f;
			}
			float num3 = ((Vector2)(ref velocity)).Length();
			if (num3 > minimumVelocity)
			{
				float t = 0.015f;
				if (fishType == FishType.Crawl || fishType == FishType.Ground || fishType == FishType.Hop)
				{
					t = 0.03f;
				}
				num3 = Utility.Lerp(num3, minimumVelocity, t);
				if (num3 < 0.0001f)
				{
					num3 = 0f;
				}
				((Vector2)(ref velocity)).Normalize();
				velocity *= num3;
				if (currentAnimation == dartHoldAnimation && num3 <= minimumVelocity + 0.5f)
				{
					List<int> list2 = dartEndAnimation;
					if (list2 != null && list2.Count > 0)
					{
						SetAnimation(dartEndAnimation);
					}
					else
					{
						List<int> list3 = idleAnimation;
						if (list3 != null && list3.Count > 0)
						{
							SetAnimation(idleAnimation);
						}
					}
				}
			}
			nextSwim -= (float)time.ElapsedGameTime.TotalSeconds;
			if (nextSwim <= 0f)
			{
				if (numberOfDarts == 0)
				{
					numberOfDarts = Game1.random.Next(1, 4);
					nextSwim = Utility.RandomFloat(6f, 12f);
					switch (fishType)
					{
					case FishType.Cephalopod:
						nextSwim = Utility.RandomFloat(2f, 5f);
						break;
					case FishType.Hop:
						numberOfDarts = 0;
						break;
					}
					if (Game1.random.NextDouble() < 0.30000001192092896)
					{
						facingLeft = !facingLeft;
					}
				}
				else
				{
					nextSwim = Utility.RandomFloat(0.1f, 0.5f);
					numberOfDarts--;
					if (Game1.random.NextDouble() < 0.05000000074505806)
					{
						facingLeft = !facingLeft;
					}
				}
				List<int> list4 = dartStartAnimation;
				if (list4 != null && list4.Count > 0)
				{
					SetAnimation(dartStartAnimation);
				}
				else
				{
					List<int> list5 = dartHoldAnimation;
					if (list5 != null && list5.Count > 0)
					{
						SetAnimation(dartHoldAnimation);
					}
				}
				velocity.X = 1.5f;
				if (_tank.getTilesWide() <= 2)
				{
					velocity.X *= 0.5f;
				}
				if (facingLeft)
				{
					velocity.X *= -1f;
				}
				switch (fishType)
				{
				case FishType.Cephalopod:
					velocity.Y = Utility.RandomFloat(0.5f, 0.75f);
					break;
				case FishType.Ground:
					velocity.X *= 0.5f;
					velocity.Y = Utility.RandomFloat(0.5f, 0.25f);
					break;
				case FishType.Hop:
					velocity.Y = Utility.RandomFloat(0.35f, 0.65f);
					break;
				default:
					velocity.Y = Utility.RandomFloat(-0.5f, 0.5f);
					break;
				}
				if (fishType == FishType.Crawl)
				{
					velocity.Y = 0f;
				}
			}
		}
		if (fishType == FishType.Cephalopod || fishType == FishType.Ground || fishType == FishType.Crawl || fishType == FishType.Static || fishType == FishType.Hop)
		{
			float num4 = 0.2f;
			if (fishType == FishType.Static)
			{
				num4 = 0.6f;
			}
			if (position.Y > 0f)
			{
				position.Y -= num4;
			}
		}
		nextBubble -= (float)time.ElapsedGameTime.TotalSeconds;
		if (nextBubble <= 0f)
		{
			nextBubble = Utility.RandomFloat(1f, 10f);
			float num5 = 0f;
			if (fishType == FishType.Ground || fishType == FishType.Normal || fishType == FishType.Eel)
			{
				num5 = 32f;
			}
			if (facingLeft)
			{
				num5 *= -1f;
			}
			num5 *= fishScale;
			_tank.bubbles.Add(new Vector4(position.X + num5, position.Y + zPosition, zPosition, 0.25f));
		}
		ConstrainToTank();
	}
}
