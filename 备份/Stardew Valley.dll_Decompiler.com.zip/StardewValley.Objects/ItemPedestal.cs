using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Network;

namespace StardewValley.Objects;

public class ItemPedestal : Object
{
	[XmlIgnore]
	public NetMutex itemModifyMutex = new NetMutex();

	[XmlElement("requiredItem")]
	public NetRef<Object> requiredItem = new NetRef<Object>();

	[XmlElement("successColor")]
	public NetColor successColor = new NetColor();

	[XmlElement("lockOnSuccess")]
	public NetBool lockOnSuccess = new NetBool();

	[XmlElement("locked")]
	public NetBool locked = new NetBool();

	[XmlElement("match")]
	public NetBool match = new NetBool();

	[XmlElement("isIslandShrinePedestal")]
	public readonly NetBool isIslandShrinePedestal = new NetBool();

	[XmlIgnore]
	public Texture2D texture;

	public override string TypeDefinitionId => "(BC)";

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(itemModifyMutex.NetFields, "itemModifyMutex.NetFields").AddField(requiredItem, "requiredItem").AddField(successColor, "successColor")
			.AddField(lockOnSuccess, "lockOnSuccess")
			.AddField(locked, "locked")
			.AddField(match, "match")
			.AddField(isIslandShrinePedestal, "isIslandShrinePedestal");
		heldObject.InterpolationWait = false;
	}

	public ItemPedestal()
	{
	}

	public ItemPedestal(Vector2 tile, Object required_item, bool lock_on_success, Color success_color, string itemId = "221")
		: base(tile, itemId)
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		requiredItem.Value = required_item;
		lockOnSuccess.Value = lock_on_success;
		successColor.Value = success_color;
	}

	protected override Item GetOneNew()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		return new ItemPedestal(TileLocation, (Object)(requiredItem.Value?.getOne()), lockOnSuccess.Value, successColor.Value, base.ItemId);
	}

	protected override void GetOneCopyFrom(Item source)
	{
		base.GetOneCopyFrom(source);
		if (source is ItemPedestal itemPedestal)
		{
			isIslandShrinePedestal.Value = itemPedestal.isIslandShrinePedestal.Value;
		}
	}

	public override bool performObjectDropInAction(Item dropInItem, bool probe, Farmer who, bool returnFalseIfItemConsumed = false)
	{
		GameLocation location = Location;
		if (location == null)
		{
			return false;
		}
		if (locked.Value)
		{
			return false;
		}
		if (!dropInItem.canBeTrashed())
		{
			return false;
		}
		if (heldObject.Value != null && !probe)
		{
			DropObject(who);
			return false;
		}
		if (dropInItem.GetType() == typeof(Object))
		{
			if (!probe)
			{
				Object placed_object = dropInItem.getOne() as Object;
				itemModifyMutex.RequestLock(delegate
				{
					location.playSound("woodyStep");
					heldObject.Value = placed_object;
					UpdateItemMatch();
					itemModifyMutex.ReleaseLock();
				}, delegate
				{
					//IL_0024: Unknown result type (might be due to invalid IL or missing references)
					//IL_0033: Unknown result type (might be due to invalid IL or missing references)
					//IL_0038: Unknown result type (might be due to invalid IL or missing references)
					//IL_0042: Unknown result type (might be due to invalid IL or missing references)
					if (placed_object != heldObject.Value)
					{
						Game1.createItemDebris(placed_object, (TileLocation + new Vector2(0.5f, 0.5f)) * 64f, -1, location);
					}
				});
			}
			return true;
		}
		return false;
	}

	public virtual void UpdateItemMatch()
	{
		bool flag = false;
		if (heldObject.Value != null && requiredItem.Value != null && Utility.getStandardDescriptionFromItem(heldObject.Value, 1) == Utility.getStandardDescriptionFromItem(requiredItem.Value, 1))
		{
			flag = true;
		}
		if (flag != match.Value)
		{
			match.Value = flag;
			if (match.Value && lockOnSuccess.Value)
			{
				locked.Value = true;
			}
		}
	}

	public override bool checkForAction(Farmer who, bool checking_for_activity = false)
	{
		if (locked.Value)
		{
			return false;
		}
		if (checking_for_activity)
		{
			return true;
		}
		if (DropObject(who))
		{
			return true;
		}
		return false;
	}

	public bool DropObject(Farmer who)
	{
		if (heldObject.Value != null)
		{
			itemModifyMutex.RequestLock(delegate
			{
				Object value = heldObject.Value;
				heldObject.Value = null;
				if (who.addItemToInventoryBool(value))
				{
					value.performRemoveAction();
					Game1.playSound("coin");
				}
				else
				{
					heldObject.Value = value;
				}
				UpdateItemMatch();
				itemModifyMutex.ReleaseLock();
			});
			return true;
		}
		return false;
	}

	public override bool performToolAction(Tool t)
	{
		if (isIslandShrinePedestal.Value)
		{
			return false;
		}
		return base.performToolAction(t);
	}

	public override void updateWhenCurrentLocation(GameTime time)
	{
		GameLocation location = Location;
		if (location != null)
		{
			itemModifyMutex.Update(location);
		}
	}

	public override bool onExplosion(Farmer who)
	{
		if (isIslandShrinePedestal.Value)
		{
			return false;
		}
		return base.onExplosion(who);
	}

	public override void DayUpdate()
	{
		base.DayUpdate();
		itemModifyMutex.ReleaseLock();
	}

	public override void draw(SpriteBatch b, int x, int y, float alpha = 1f)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(x * 64), (float)(y * 64));
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
		b.Draw(Game1.bigCraftableSpriteSheet, Game1.GlobalToLocal(Game1.viewport, val), (Rectangle?)dataOrErrorItem.GetSourceRect(), Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, Math.Max(0f, (val.Y - 2f) / 10000f));
		if (match.Value)
		{
			b.Draw(Game1.bigCraftableSpriteSheet, Game1.GlobalToLocal(Game1.viewport, val), (Rectangle?)dataOrErrorItem.GetSourceRect(1), successColor.Value, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, Math.Max(0f, (val.Y - 1f) / 10000f));
		}
		if (heldObject.Value != null)
		{
			Vector2 val2 = default(Vector2);
			((Vector2)(ref val2))._002Ector((float)x, (float)y);
			if (heldObject.Value.bigCraftable.Value)
			{
				val2.Y -= 1f;
			}
			heldObject.Value.draw(b, (int)val2.X * 64, (int)((val2.Y - 0.2f) * 64f) - 64, val.Y / 10000f, 1f);
		}
	}
}
