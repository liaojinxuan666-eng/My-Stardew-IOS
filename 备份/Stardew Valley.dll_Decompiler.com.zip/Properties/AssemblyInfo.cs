using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: InternalsVisibleTo("StardewModdingAPI")]
[assembly: AssemblyCompany("ConcernedApe")]
[assembly: AssemblyConfiguration("GOGRelease")]
[assembly: AssemblyCopyright("Copyright © ConcernedApe 2013")]
[assembly: AssemblyFileVersion("1.6.15.24356")]
[assembly: AssemblyInformationalVersion("1.6.15, , 24356, ")]
[assembly: AssemblyProduct("Stardew Valley")]
[assembly: AssemblyTitle("Stardew Valley")]
[assembly: AssemblyVersion("1.6.15.24356")]
