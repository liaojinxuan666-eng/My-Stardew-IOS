using System;
using Galaxy.Api;

namespace StardewValley.SDKs.GogGalaxy.Listeners;

internal sealed class GalaxySpecificUserDataListener : ISpecificUserDataListener
{
	private readonly Action<GalaxyID> Callback;

	public GalaxySpecificUserDataListener(Action<GalaxyID> callback)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Callback = callback;
		GalaxyInstance.ListenerRegistrar().Register(GalaxyTypeAwareListenerSpecificUserData.GetListenerType(), (IGalaxyListener)(object)this);
	}

	public override void OnSpecificUserDataUpdated(GalaxyID userID)
	{
		Callback?.Invoke(userID);
	}

	public override void Dispose()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		GalaxyInstance.ListenerRegistrar().Unregister(GalaxyTypeAwareListenerSpecificUserData.GetListenerType(), (IGalaxyListener)(object)this);
		((ISpecificUserDataListener)this).Dispose();
	}
}
