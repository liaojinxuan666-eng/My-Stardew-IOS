using System;
using Galaxy.Api;

namespace StardewValley.SDKs.GogGalaxy.Listeners;

internal sealed class GalaxyLobbyMemberStateListener : ILobbyMemberStateListener
{
	private readonly Action<GalaxyID, GalaxyID, LobbyMemberStateChange> Callback;

	public GalaxyLobbyMemberStateListener(Action<GalaxyID, GalaxyID, LobbyMemberStateChange> callback)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Callback = callback;
		GalaxyInstance.ListenerRegistrar().Register(GalaxyTypeAwareListenerLobbyMemberState.GetListenerType(), (IGalaxyListener)(object)this);
	}

	public override void OnLobbyMemberStateChanged(GalaxyID lobbyID, GalaxyID memberID, LobbyMemberStateChange memberStateChange)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		Callback?.Invoke(lobbyID, memberID, memberStateChange);
	}

	public override void Dispose()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		GalaxyInstance.ListenerRegistrar().Unregister(GalaxyTypeAwareListenerLobbyMemberState.GetListenerType(), (IGalaxyListener)(object)this);
		((ILobbyMemberStateListener)this).Dispose();
	}
}
