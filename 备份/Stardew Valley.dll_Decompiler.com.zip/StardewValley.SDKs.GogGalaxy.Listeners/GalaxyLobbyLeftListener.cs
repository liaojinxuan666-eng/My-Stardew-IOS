using System;
using Galaxy.Api;

namespace StardewValley.SDKs.GogGalaxy.Listeners;

internal sealed class GalaxyLobbyLeftListener : ILobbyLeftListener
{
	private readonly Action<GalaxyID, LobbyLeaveReason> Callback;

	public GalaxyLobbyLeftListener(Action<GalaxyID, LobbyLeaveReason> callback)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Callback = callback;
		GalaxyInstance.ListenerRegistrar().Register(GalaxyTypeAwareListenerLobbyLeft.GetListenerType(), (IGalaxyListener)(object)this);
	}

	public override void OnLobbyLeft(GalaxyID lobbyID, LobbyLeaveReason leaveReason)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		Callback?.Invoke(lobbyID, leaveReason);
	}

	public override void Dispose()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		GalaxyInstance.ListenerRegistrar().Unregister(GalaxyTypeAwareListenerLobbyLeft.GetListenerType(), (IGalaxyListener)(object)this);
		((ILobbyLeftListener)this).Dispose();
	}
}
