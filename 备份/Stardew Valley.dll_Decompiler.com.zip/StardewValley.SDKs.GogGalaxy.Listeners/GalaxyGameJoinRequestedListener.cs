using System;
using Galaxy.Api;

namespace StardewValley.SDKs.GogGalaxy.Listeners;

internal sealed class GalaxyGameJoinRequestedListener : IGameJoinRequestedListener
{
	private readonly Action<GalaxyID, string> Callback;

	public GalaxyGameJoinRequestedListener(Action<GalaxyID, string> callback)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Callback = callback;
		GalaxyInstance.ListenerRegistrar().Register(GalaxyTypeAwareListenerGameJoinRequested.GetListenerType(), (IGalaxyListener)(object)this);
	}

	public override void OnGameJoinRequested(GalaxyID lobbyID, string result)
	{
		Callback?.Invoke(lobbyID, result);
	}

	public override void Dispose()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		GalaxyInstance.ListenerRegistrar().Unregister(GalaxyTypeAwareListenerGameJoinRequested.GetListenerType(), (IGalaxyListener)(object)this);
		((IGameJoinRequestedListener)this).Dispose();
	}
}
