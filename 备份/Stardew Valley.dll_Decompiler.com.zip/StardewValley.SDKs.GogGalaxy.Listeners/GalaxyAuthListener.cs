using System;
using Galaxy.Api;

namespace StardewValley.SDKs.GogGalaxy.Listeners;

internal sealed class GalaxyAuthListener : IAuthListener
{
	private readonly Action OnSuccess;

	private readonly Action<FailureReason> OnFailure;

	private readonly Action OnLost;

	public GalaxyAuthListener(Action success, Action<FailureReason> failure, Action lost)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		OnSuccess = success;
		OnFailure = failure;
		OnLost = lost;
		GalaxyInstance.ListenerRegistrar().Register(GalaxyTypeAwareListenerAuth.GetListenerType(), (IGalaxyListener)(object)this);
	}

	public override void OnAuthSuccess()
	{
		OnSuccess?.Invoke();
	}

	public override void OnAuthFailure(FailureReason reason)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		OnFailure?.Invoke(reason);
	}

	public override void OnAuthLost()
	{
		OnLost?.Invoke();
	}

	public override void Dispose()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		GalaxyInstance.ListenerRegistrar().Unregister(GalaxyTypeAwareListenerAuth.GetListenerType(), (IGalaxyListener)(object)this);
		((IAuthListener)this).Dispose();
	}
}
