using System;
using Galaxy.Api;

namespace StardewValley.SDKs.GogGalaxy.Listeners;

internal sealed class GalaxyLobbyEnteredListener : ILobbyEnteredListener
{
	private readonly Action<GalaxyID, LobbyEnterResult> Callback;

	public GalaxyLobbyEnteredListener(Action<GalaxyID, LobbyEnterResult> callback)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Callback = callback;
		GalaxyInstance.ListenerRegistrar().Register(GalaxyTypeAwareListenerLobbyEntered.GetListenerType(), (IGalaxyListener)(object)this);
	}

	public override void OnLobbyEntered(GalaxyID lobbyID, LobbyEnterResult result)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		Callback?.Invoke(lobbyID, result);
	}

	public override void Dispose()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		GalaxyInstance.ListenerRegistrar().Unregister(GalaxyTypeAwareListenerLobbyEntered.GetListenerType(), (IGalaxyListener)(object)this);
		((ILobbyEnteredListener)this).Dispose();
	}
}
