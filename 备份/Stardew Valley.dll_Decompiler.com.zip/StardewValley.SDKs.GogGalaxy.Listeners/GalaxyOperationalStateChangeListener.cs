using System;
using Galaxy.Api;

namespace StardewValley.SDKs.GogGalaxy.Listeners;

internal sealed class GalaxyOperationalStateChangeListener : IOperationalStateChangeListener
{
	private readonly Action<uint> Callback;

	public GalaxyOperationalStateChangeListener(Action<uint> callback)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Callback = callback;
		GalaxyInstance.ListenerRegistrar().Register(GalaxyTypeAwareListenerOperationalStateChange.GetListenerType(), (IGalaxyListener)(object)this);
	}

	public override void OnOperationalStateChanged(uint operationalState)
	{
		Callback?.Invoke(operationalState);
	}

	public override void Dispose()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		GalaxyInstance.ListenerRegistrar().Unregister(GalaxyTypeAwareListenerOperationalStateChange.GetListenerType(), (IGalaxyListener)(object)this);
		((IOperationalStateChangeListener)this).Dispose();
	}
}
