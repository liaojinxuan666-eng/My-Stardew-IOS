using System;
using Galaxy.Api;

namespace StardewValley.SDKs.GogGalaxy.Listeners;

internal sealed class GalaxyLobbyDataListener : ILobbyDataListener
{
	private readonly Action<GalaxyID, GalaxyID> Callback;

	public GalaxyLobbyDataListener(Action<GalaxyID, GalaxyID> callback)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Callback = callback;
		GalaxyInstance.ListenerRegistrar().Register(GalaxyTypeAwareListenerLobbyData.GetListenerType(), (IGalaxyListener)(object)this);
	}

	public override void OnLobbyDataUpdated(GalaxyID lobbyID, GalaxyID memberID)
	{
		Callback?.Invoke(lobbyID, memberID);
	}

	public override void Dispose()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		GalaxyInstance.ListenerRegistrar().Unregister(GalaxyTypeAwareListenerLobbyData.GetListenerType(), (IGalaxyListener)(object)this);
		((ILobbyDataListener)this).Dispose();
	}
}
