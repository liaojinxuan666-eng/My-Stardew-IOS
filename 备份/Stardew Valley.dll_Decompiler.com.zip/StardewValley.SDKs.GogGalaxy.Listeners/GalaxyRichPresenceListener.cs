using System;
using Galaxy.Api;

namespace StardewValley.SDKs.GogGalaxy.Listeners;

internal sealed class GalaxyRichPresenceListener : IRichPresenceListener
{
	private readonly Action<GalaxyID> Callback;

	public GalaxyRichPresenceListener(Action<GalaxyID> callback)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Callback = callback;
		GalaxyInstance.ListenerRegistrar().Register(GalaxyTypeAwareListenerRichPresence.GetListenerType(), (IGalaxyListener)(object)this);
	}

	public override void OnRichPresenceUpdated(GalaxyID userID)
	{
		Callback?.Invoke(userID);
	}

	public override void Dispose()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		GalaxyInstance.ListenerRegistrar().Unregister(GalaxyTypeAwareListenerRichPresence.GetListenerType(), (IGalaxyListener)(object)this);
		((IRichPresenceListener)this).Dispose();
	}
}
