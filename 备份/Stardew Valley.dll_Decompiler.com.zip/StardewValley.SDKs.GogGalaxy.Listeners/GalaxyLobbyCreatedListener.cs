using System;
using Galaxy.Api;

namespace StardewValley.SDKs.GogGalaxy.Listeners;

internal sealed class GalaxyLobbyCreatedListener : ILobbyCreatedListener
{
	private readonly Action<GalaxyID, LobbyCreateResult> Callback;

	public GalaxyLobbyCreatedListener(Action<GalaxyID, LobbyCreateResult> callback)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Callback = callback;
		GalaxyInstance.ListenerRegistrar().Register(GalaxyTypeAwareListenerLobbyCreated.GetListenerType(), (IGalaxyListener)(object)this);
	}

	public override void OnLobbyCreated(GalaxyID lobbyID, LobbyCreateResult result)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		Callback?.Invoke(lobbyID, result);
	}

	public override void Dispose()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		GalaxyInstance.ListenerRegistrar().Unregister(GalaxyTypeAwareListenerLobbyCreated.GetListenerType(), (IGalaxyListener)(object)this);
		((ILobbyCreatedListener)this).Dispose();
	}
}
