using Microsoft.Xna.Framework;
using StardewValley.Extensions;
using StardewValley.Locations;

namespace StardewValley.Tools;

public class Wand : Tool
{
	public Wand()
		: base("Return Scepter", 0, 2, 2, stackable: false)
	{
		base.InstantUse = true;
	}

	protected override void MigrateLegacyItemId()
	{
		base.ItemId = "ReturnScepter";
	}

	protected override Item GetOneNew()
	{
		return new Wand();
	}

	public override void DoFunction(GameLocation location, int x, int y, int power, Farmer who)
	{
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		if (!who.bathingClothes.Value && who.IsLocalPlayer && !who.onBridge.Value)
		{
			indexOfMenuItemView.Value = 2;
			base.CurrentParentTileIndex = 2;
			for (int i = 0; i < 12; i++)
			{
				Game1.multiplayer.broadcastSprites(who.currentLocation, new TemporaryAnimatedSprite(354, Game1.random.Next(25, 75), 6, 1, new Vector2((float)Game1.random.Next((int)who.position.X - 256, (int)who.position.X + 192), (float)Game1.random.Next((int)who.position.Y - 256, (int)who.position.Y + 192)), flicker: false, Game1.random.NextBool()));
			}
			if (PlayUseSounds)
			{
				who.playNearbySoundAll("wand");
			}
			Game1.displayFarmer = false;
			who.temporarilyInvincible = true;
			who.temporaryInvincibilityTimer = -2000;
			who.Halt();
			who.faceDirection(2);
			who.CanMove = false;
			who.freezePause = 2000;
			Game1.flashAlpha = 1f;
			DelayedAction.fadeAfterDelay(wandWarpForReal, 1000);
			Rectangle boundingBox = who.GetBoundingBox();
			Rectangle val = default(Rectangle);
			((Rectangle)(ref val))._002Ector(boundingBox.X, boundingBox.Y, 64, 64);
			((Rectangle)(ref val)).Inflate(192, 192);
			int num = 0;
			Point tilePoint = who.TilePoint;
			for (int num2 = tilePoint.X + 8; num2 >= tilePoint.X - 8; num2--)
			{
				Game1.multiplayer.broadcastSprites(who.currentLocation, new TemporaryAnimatedSprite(6, new Vector2((float)num2, (float)tilePoint.Y) * 64f, Color.White, 8, flipped: false, 50f)
				{
					layerDepth = 1f,
					delayBeforeAnimationStart = num * 25,
					motion = new Vector2(-0.25f, 0f)
				});
				num++;
			}
			base.CurrentParentTileIndex = base.IndexOfMenuItemView;
		}
	}

	public override bool actionWhenPurchased(string shopId)
	{
		Game1.player.mailReceived.Add("ReturnScepter");
		return base.actionWhenPurchased(shopId);
	}

	private void wandWarpForReal()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		FarmHouse homeOfFarmer = Utility.getHomeOfFarmer(Game1.player);
		if (homeOfFarmer != null)
		{
			Point frontDoorSpot = homeOfFarmer.getFrontDoorSpot();
			Game1.warpFarmer("Farm", frontDoorSpot.X, frontDoorSpot.Y, flip: false);
			Game1.fadeToBlackAlpha = 0.99f;
			Game1.screenGlow = false;
			lastUser.temporarilyInvincible = false;
			lastUser.temporaryInvincibilityTimer = 0;
			Game1.displayFarmer = true;
			lastUser.CanMove = true;
		}
	}
}
