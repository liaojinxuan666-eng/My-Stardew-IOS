using System.Collections.Generic;
using Microsoft.Xna.Framework;
using StardewValley.Extensions;
using StardewValley.Locations;
using xTile.Dimensions;

namespace StardewValley.Tools;

public class Hoe : Tool
{
	public Hoe()
		: base("Hoe", 0, 21, 47, stackable: false)
	{
	}

	protected override void MigrateLegacyItemId()
	{
		switch (base.UpgradeLevel)
		{
		case 0:
			base.ItemId = "Hoe";
			break;
		case 1:
			base.ItemId = "CopperHoe";
			break;
		case 2:
			base.ItemId = "SteelHoe";
			break;
		case 3:
			base.ItemId = "GoldHoe";
			break;
		case 4:
			base.ItemId = "IridiumHoe";
			break;
		default:
			base.ItemId = "Hoe";
			break;
		}
	}

	protected override Item GetOneNew()
	{
		return new Hoe();
	}

	public override void DoFunction(GameLocation location, int x, int y, int power, Farmer who)
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0382: Unknown result type (might be due to invalid IL or missing references)
		//IL_038f: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0265: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(x / 64), (float)(y / 64));
		base.DoFunction(location, x, y, power, who);
		if (MineShaft.IsGeneratedLevel(location))
		{
			power = 1;
		}
		if (!isEfficient.Value)
		{
			who.Stamina -= (float)(2 * power) - (float)who.FarmingLevel * 0.1f;
		}
		power = who.toolPower.Value;
		who.stopJittering();
		if (PlayUseSounds)
		{
			location.playSound("woodyHit", val);
		}
		List<Vector2> list = tilesAffected(val, power, who);
		foreach (Vector2 item in list)
		{
			if (location.terrainFeatures.TryGetValue(item, out var value))
			{
				if (value.performToolAction(this, 0, item))
				{
					location.terrainFeatures.Remove(item);
				}
				continue;
			}
			if (location.objects.TryGetValue(item, out var value2) && value2.performToolAction(this))
			{
				if (value2.Type == "Crafting" && value2.fragility.Value != 2)
				{
					location.debris.Add(new Debris(value2.QualifiedItemId, who.GetToolLocation(), Utility.PointToVector2(who.StandingPixel)));
				}
				value2.performRemoveAction();
				location.Objects.Remove(item);
			}
			if (location.doesTileHaveProperty((int)item.X, (int)item.Y, "Diggable", "Back") == null)
			{
				continue;
			}
			if (location is MineShaft && !location.IsTileOccupiedBy(item, CollisionMask.All, CollisionMask.None, useFarmerTile: true))
			{
				if (location.makeHoeDirt(item))
				{
					if (PlayUseSounds)
					{
						location.playSound("hoeHit", item);
					}
					location.checkForBuriedItem((int)item.X, (int)item.Y, explosion: false, detectOnly: false, who);
					Game1.multiplayer.broadcastSprites(location, new TemporaryAnimatedSprite(12, new Vector2(val.X * 64f, val.Y * 64f), Color.White, 8, Game1.random.NextBool(), 50f));
					if (list.Count > 2)
					{
						Game1.multiplayer.broadcastSprites(location, new TemporaryAnimatedSprite(6, new Vector2(item.X * 64f, item.Y * 64f), Color.White, 8, Game1.random.NextBool(), Vector2.Distance(val, item) * 30f));
					}
				}
			}
			else if (location.isTilePassable(new Location((int)item.X, (int)item.Y), Game1.viewport) && location.makeHoeDirt(item))
			{
				if (PlayUseSounds)
				{
					location.playSound("hoeHit", item);
				}
				Game1.multiplayer.broadcastSprites(location, new TemporaryAnimatedSprite(12, new Vector2(item.X * 64f, item.Y * 64f), Color.White, 8, Game1.random.NextBool(), 50f));
				if (list.Count > 2)
				{
					Game1.multiplayer.broadcastSprites(location, new TemporaryAnimatedSprite(6, new Vector2(item.X * 64f, item.Y * 64f), Color.White, 8, Game1.random.NextBool(), Vector2.Distance(val, item) * 30f));
				}
				location.checkForBuriedItem((int)item.X, (int)item.Y, explosion: false, detectOnly: false, who);
			}
			Game1.stats.DirtHoed++;
		}
	}
}
