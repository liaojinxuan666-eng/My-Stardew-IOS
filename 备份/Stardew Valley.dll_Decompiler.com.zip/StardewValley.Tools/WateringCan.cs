using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Netcode;
using StardewValley.Extensions;

namespace StardewValley.Tools;

public class WateringCan : Tool
{
	[XmlElement("isBottomless")]
	public readonly NetBool isBottomless = new NetBool();

	[XmlIgnore]
	protected bool _emptyCanPlayed;

	[XmlIgnore]
	public int waterCanMax = 40;

	private readonly NetInt waterLeft = new NetInt(40);

	public int WaterLeft
	{
		get
		{
			if (!IsBottomless)
			{
				return waterLeft.Value;
			}
			return waterCanMax;
		}
		set
		{
			waterLeft.Value = value;
		}
	}

	public bool IsBottomless
	{
		get
		{
			return isBottomless.Value;
		}
		set
		{
			isBottomless.Value = value;
		}
	}

	public WateringCan()
		: base("Watering Can", 0, 273, 296, stackable: false)
	{
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(isBottomless, "isBottomless").AddField(waterLeft, "waterLeft");
		upgradeLevel.fieldChangeVisibleEvent += delegate
		{
			OnUpgradeLevelChanged();
		};
	}

	protected override void MigrateLegacyItemId()
	{
		switch (base.UpgradeLevel)
		{
		case 0:
			base.ItemId = "WateringCan";
			break;
		case 1:
			base.ItemId = "CopperWateringCan";
			break;
		case 2:
			base.ItemId = "SteelWateringCan";
			break;
		case 3:
			base.ItemId = "GoldWateringCan";
			break;
		case 4:
			base.ItemId = "IridiumWateringCan";
			break;
		default:
			base.ItemId = "WateringCan";
			break;
		}
	}

	protected override Item GetOneNew()
	{
		return new WateringCan();
	}

	protected override void GetOneCopyFrom(Item source)
	{
		base.GetOneCopyFrom(source);
		if (source is WateringCan wateringCan)
		{
			WaterLeft = wateringCan.WaterLeft;
			IsBottomless = wateringCan.IsBottomless;
		}
	}

	protected virtual void OnUpgradeLevelChanged()
	{
		switch (upgradeLevel.Value)
		{
		case 0:
			waterCanMax = 40;
			break;
		case 1:
			waterCanMax = 55;
			break;
		case 2:
			waterCanMax = 70;
			break;
		case 3:
			waterCanMax = 85;
			break;
		default:
			waterCanMax = 100;
			break;
		}
		waterLeft.Value = waterCanMax;
	}

	public override void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		base.drawInMenu(spriteBatch, location + (Game1.player.hasWateringCanEnchantment ? new Vector2(0f, -4f) : new Vector2(0f, -12f)), scaleSize, transparency, layerDepth, drawStackNumber, color, drawShadow);
		if (drawStackNumber != StackDrawType.Hide && !Game1.player.hasWateringCanEnchantment)
		{
			spriteBatch.Draw(Game1.mouseCursors, location + new Vector2(4f, 44f), (Rectangle?)new Rectangle(297, 420, 14, 5), Color.White * transparency, 0f, Vector2.Zero, 4f, (SpriteEffects)0, layerDepth + 0.0001f);
			spriteBatch.Draw(Game1.staminaRect, new Rectangle((int)location.X + 8, (int)location.Y + 64 - 16, (int)((float)WaterLeft / (float)waterCanMax * 48f), 8), IsBottomless ? (Color.BlueViolet * 1f * transparency) : (Color.DodgerBlue * 0.7f * transparency));
		}
	}

	public override string getDescription()
	{
		return Game1.parseText(base.description + (Game1.player.hasWateringCanEnchantment ? (Environment.NewLine + Environment.NewLine + Game1.content.LoadString("Strings\\StringsFromCSFiles:WateringCan_enchant")) : ""), Game1.smallFont, getDescriptionWidth());
	}

	public override void DoFunction(GameLocation location, int x, int y, int power, Farmer who)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0380: Unknown result type (might be due to invalid IL or missing references)
		//IL_0385: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		base.DoFunction(location, x, y, power, who);
		power = who.toolPower.Value;
		who.stopJittering();
		List<Vector2> list = tilesAffected(new Vector2((float)(x / 64), (float)(y / 64)), power, who);
		if (Game1.currentLocation.CanRefillWateringCanOnTile(x / 64, y / 64))
		{
			who.jitterStrength = 0.5f;
			WaterLeft = waterCanMax;
			if (PlayUseSounds)
			{
				who.playNearbySoundAll("slosh");
				DelayedAction.playSoundAfterDelay("glug", 250, location, who.Tile);
			}
		}
		else if (WaterLeft > 0 || who.hasWateringCanEnchantment)
		{
			if (!isEfficient.Value)
			{
				who.Stamina -= (float)(2 * (power + 1)) - (float)who.FarmingLevel * 0.1f;
			}
			int num = 0;
			foreach (Vector2 item in list)
			{
				if (location.terrainFeatures.TryGetValue(item, out var value))
				{
					value.performToolAction(this, 0, item);
				}
				if (location.objects.TryGetValue(item, out var value2))
				{
					value2.performToolAction(this);
				}
				location.performToolAction(this, (int)item.X, (int)item.Y);
				Game1.multiplayer.broadcastSprites(location, new TemporaryAnimatedSprite(13, new Vector2(item.X * 64f, item.Y * 64f), Color.White, 10, Game1.random.NextBool(), 70f, 0, 64, (item.Y * 64f + 32f) / 10000f - 0.01f)
				{
					delayBeforeAnimationStart = 200 + num * 10
				});
				num++;
			}
			if (!IsBottomless)
			{
				WaterLeft -= power + 1;
			}
			Vector2 zero = default(Vector2);
			((Vector2)(ref zero))._002Ector(who.Position.X - 32f - 4f, who.Position.Y - 16f - 4f);
			switch (who.FacingDirection)
			{
			case 1:
				zero.X += 136f;
				break;
			case 2:
				zero.X += 72f;
				zero.Y += 44f;
				break;
			case 0:
				zero = Vector2.Zero;
				break;
			}
			if (!((Vector2)(ref zero)).Equals(Vector2.Zero))
			{
				Rectangle boundingBox = who.GetBoundingBox();
				for (int i = 0; i < 30; i++)
				{
					Game1.multiplayer.broadcastSprites(location, new TemporaryAnimatedSprite("", new Rectangle(0, 0, 1, 1), 999f, 1, 999, zero + new Vector2((float)(Game1.random.Next(-3, 0) * 4), (float)(Game1.random.Next(2) * 4)), flicker: false, flipped: false, (float)(((Rectangle)(ref boundingBox)).Bottom + 32) / 10000f, 0.04f, Game1.random.Choose<Color>(Color.DeepSkyBlue, Color.LightBlue), 4f, 0f, 0f, 0f)
					{
						delayBeforeAnimationStart = i * 15,
						motion = new Vector2((float)Game1.random.Next(-10, 11) / 100f, 0.5f),
						acceleration = new Vector2(0f, 0.1f)
					});
				}
			}
		}
		else if (!_emptyCanPlayed)
		{
			_emptyCanPlayed = true;
			who.doEmote(4);
			if (who == Game1.player)
			{
				Game1.showRedMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:WateringCan.cs.14335"));
			}
		}
	}

	public override bool CanUseOnStandingTile()
	{
		return true;
	}

	public override void tickUpdate(GameTime time, Farmer who)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		base.tickUpdate(time, who);
		if (who.IsLocalPlayer)
		{
			if (!Game1.areAllOfTheseKeysUp(Game1.input.GetKeyboardState(), Game1.options.useToolButton))
			{
				return;
			}
			MouseState mouseState = Game1.input.GetMouseState();
			if ((int)((MouseState)(ref mouseState)).LeftButton == 0)
			{
				GamePadState gamePadState = Game1.input.GetGamePadState();
				if (((GamePadState)(ref gamePadState)).IsButtonUp((Buttons)16384))
				{
					_emptyCanPlayed = false;
				}
			}
		}
		else
		{
			_emptyCanPlayed = false;
		}
	}
}
