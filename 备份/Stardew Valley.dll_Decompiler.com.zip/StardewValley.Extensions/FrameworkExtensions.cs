using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xTile;
using xTile.Dimensions;
using xTile.Layers;
using xTile.ObjectModel;
using xTile.Tiles;

namespace StardewValley.Extensions;

public static class FrameworkExtensions
{
	public static Rectangle GetTitleSafeArea(this Viewport viewport)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		return ((Viewport)(ref viewport)).Bounds;
	}

	public static IEnumerable<Point> GetPoints(this Rectangle rect)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		int right = ((Rectangle)(ref rect)).Right;
		int bottom = ((Rectangle)(ref rect)).Bottom;
		for (int y = rect.Y; y < bottom; y++)
		{
			for (int x = rect.X; x < right; x++)
			{
				yield return new Point(x, y);
			}
		}
	}

	public static IEnumerable<Vector2> GetVectors(this Rectangle rect)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		int right = ((Rectangle)(ref rect)).Right;
		int bottom = ((Rectangle)(ref rect)).Bottom;
		for (int y = rect.Y; y < bottom; y++)
		{
			for (int x = rect.X; x < right; x++)
			{
				yield return new Vector2((float)x, (float)y);
			}
		}
	}

	public static Rectangle Clone(this Rectangle rect)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		return new Rectangle(rect.X, rect.Y, rect.Width, rect.Height);
	}

	public static Vector2 Size(this Viewport vp)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2((float)((Viewport)(ref vp)).Width, (float)((Viewport)(ref vp)).Height);
	}

	public static int GetElementCount(this Texture2D texture)
	{
		return texture.ActualWidth * texture.ActualHeight;
	}

	public static int GetActualWidth(this Texture2D texture)
	{
		return texture.ActualWidth;
	}

	public static int GetActualHeight(this Texture2D texture)
	{
		return texture.ActualHeight;
	}

	public static void SetContentSize(this Texture2D texture, int width, int height)
	{
		texture.SetImageSize(width, height);
	}

	public static bool TryGetValue(this IPropertyCollection properties, string key, out string value)
	{
		if (!((IDictionary<string, PropertyValue>)properties).TryGetValue(key, out PropertyValue value2))
		{
			value = null;
			return false;
		}
		value = PropertyValue.op_Implicit(value2);
		return true;
	}

	public static bool TryAdd(this IPropertyCollection properties, string key, string value)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Expected O, but got Unknown
		if (((IDictionary<string, PropertyValue>)properties).ContainsKey(key))
		{
			return false;
		}
		((IDictionary<string, PropertyValue>)properties).Add(key, new PropertyValue(value));
		return true;
	}

	public static Layer RequireLayer(this Map map, string layerId)
	{
		return map.GetLayer(layerId) ?? throw new KeyNotFoundException($"The '{map.assetPath}' map doesn't have required layer '{layerId}'.");
	}

	public static TileSheet RequireTileSheet(this Map map, string tilesheetId)
	{
		return map.GetTileSheet(tilesheetId) ?? throw new KeyNotFoundException($"The '{map.assetPath}' map doesn't have required tile sheet '{tilesheetId}'.");
	}

	public static TileSheet RequireTileSheet(this Map map, int expectedIndex, string tilesheetId)
	{
		if (map.TileSheets.Count > expectedIndex)
		{
			TileSheet val = map.TileSheets[expectedIndex];
			if (((Component)val).Id == tilesheetId)
			{
				return val;
			}
		}
		return map.GetTileSheet(tilesheetId) ?? throw new KeyNotFoundException($"The '{map.assetPath}' map doesn't have required tile sheet '{tilesheetId}'.");
	}

	public static bool HasTileAt(this Map map, Location tile, string layerId, string tilesheetId = null)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		return ((map == null) ? ((bool?)null) : map.GetLayer(layerId)?.HasTileAt(tile.X, tile.Y, tilesheetId)) == true;
	}

	public static bool HasTileAt(this Map map, int x, int y, string layerId, string tilesheetId = null)
	{
		return ((map == null) ? ((bool?)null) : map.GetLayer(layerId)?.HasTileAt(x, y, tilesheetId)) == true;
	}

	public static int GetTileIndexAt(this Map map, int x, int y, string layerId, string tilesheetId = null)
	{
		return ((map == null) ? ((int?)null) : map.GetLayer(layerId)?.GetTileIndexAt(x, y, tilesheetId)) ?? (-1);
	}

	public static int GetTileIndexAt(this Map map, Location tile, string layerId, string tilesheetId = null)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		return ((map == null) ? ((int?)null) : map.GetLayer(layerId)?.GetTileIndexAt(tile.X, tile.Y, tilesheetId)) ?? (-1);
	}

	public static bool HasTileAt(this Layer layer, Location tile, string tilesheetId = null)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return layer.HasTileAt(tile.X, tile.Y, tilesheetId);
	}

	public static bool HasTileAt(this Layer layer, int x, int y, string tilesheetId = null)
	{
		return layer.GetTileIndexAt(x, y, tilesheetId) != -1;
	}

	public static int GetTileIndexAt(this Layer layer, Location tile, string tilesheetId = null)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		return layer?.GetTileIndexAt(tile.X, tile.Y, tilesheetId) ?? (-1);
	}

	public static int GetTileIndexAt(this Layer layer, int x, int y, string tilesheetId = null)
	{
		Tile val = ((layer != null) ? layer.Tiles[x, y] : null);
		if (val == null)
		{
			return -1;
		}
		if (tilesheetId != null)
		{
			TileSheet tileSheet = val.TileSheet;
			if (!((tileSheet != null) ? ((Component)tileSheet).Id : null).EqualsIgnoreCase(tilesheetId))
			{
				return -1;
			}
		}
		return val.TileIndex;
	}

	public static Rectangle ToXna(this Rectangle xrect)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		return new Rectangle(((Rectangle)(ref xrect)).X, ((Rectangle)(ref xrect)).Y, ((Rectangle)(ref xrect)).Width, ((Rectangle)(ref xrect)).Height);
	}
}
