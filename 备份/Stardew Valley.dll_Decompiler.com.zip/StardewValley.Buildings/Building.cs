using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using Netcode.Validation;
using StardewValley.Delegates;
using StardewValley.Extensions;
using StardewValley.GameData;
using StardewValley.GameData.Buildings;
using StardewValley.Internal;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Locations;
using StardewValley.Menus;
using StardewValley.Mods;
using StardewValley.Objects;
using StardewValley.TerrainFeatures;
using StardewValley.TokenizableStrings;
using StardewValley.Util;
using xTile.Dimensions;

namespace StardewValley.Buildings;

[XmlInclude(typeof(Barn))]
[XmlInclude(typeof(Coop))]
[XmlInclude(typeof(FishPond))]
[XmlInclude(typeof(GreenhouseBuilding))]
[XmlInclude(typeof(JunimoHut))]
[XmlInclude(typeof(Mill))]
[XmlInclude(typeof(PetBowl))]
[XmlInclude(typeof(ShippingBin))]
[XmlInclude(typeof(Stable))]
[NotImplicitNetField]
public class Building : INetObject<NetFields>, IHaveModData
{
	[XmlElement("id")]
	public readonly NetGuid id = new NetGuid();

	[XmlIgnore]
	public Lazy<Texture2D> texture;

	[XmlIgnore]
	public Texture2D paintedTexture;

	public NetString skinId = new NetString();

	[XmlElement("indoors")]
	public readonly NetRef<GameLocation> indoors = new NetRef<GameLocation>();

	public readonly NetString nonInstancedIndoorsName = new NetString();

	[XmlElement("tileX")]
	public readonly NetInt tileX = new NetInt();

	[XmlElement("tileY")]
	public readonly NetInt tileY = new NetInt();

	[XmlElement("tilesWide")]
	public readonly NetInt tilesWide = new NetInt();

	[XmlElement("tilesHigh")]
	public readonly NetInt tilesHigh = new NetInt();

	[XmlElement("maxOccupants")]
	public readonly NetInt maxOccupants = new NetInt();

	[XmlElement("currentOccupants")]
	public readonly NetInt currentOccupants = new NetInt();

	[XmlElement("daysOfConstructionLeft")]
	public readonly NetInt daysOfConstructionLeft = new NetInt();

	[XmlElement("daysUntilUpgrade")]
	public readonly NetInt daysUntilUpgrade = new NetInt();

	[XmlElement("upgradeName")]
	public readonly NetString upgradeName = new NetString();

	[XmlElement("buildingType")]
	public readonly NetString buildingType = new NetString();

	[XmlElement("buildingPaintColor")]
	public NetRef<BuildingPaintColor> netBuildingPaintColor = new NetRef<BuildingPaintColor>();

	[XmlElement("hayCapacity")]
	public NetInt hayCapacity = new NetInt();

	public NetList<Chest, NetRef<Chest>> buildingChests = new NetList<Chest, NetRef<Chest>>();

	[XmlIgnore]
	public NetString parentLocationName = new NetString();

	[XmlIgnore]
	public bool hasLoaded;

	[XmlIgnore]
	protected Dictionary<string, string> buildingMetadata = new Dictionary<string, string>();

	protected int lastHouseUpgradeLevel = -1;

	protected bool? hasChimney;

	protected Vector2 chimneyPosition = Vector2.Zero;

	protected int chimneyTimer = 500;

	[XmlElement("humanDoor")]
	public readonly NetPoint humanDoor = new NetPoint();

	[XmlElement("animalDoor")]
	public readonly NetPoint animalDoor = new NetPoint();

	[XmlIgnore]
	public Color color = Color.White;

	[XmlElement("animalDoorOpen")]
	public readonly NetBool animalDoorOpen = new NetBool();

	[XmlElement("animalDoorOpenAmount")]
	public readonly NetFloat animalDoorOpenAmount = new NetFloat
	{
		InterpolationWait = false
	};

	[XmlElement("magical")]
	public readonly NetBool magical = new NetBool();

	[XmlElement("fadeWhenPlayerIsBehind")]
	public readonly NetBool fadeWhenPlayerIsBehind = new NetBool(value: true);

	[XmlElement("owner")]
	public readonly NetLong owner = new NetLong();

	[XmlElement("newConstructionTimer")]
	protected readonly NetInt newConstructionTimer = new NetInt();

	[XmlIgnore]
	public float alpha = 1f;

	[XmlIgnore]
	protected bool _isMoving;

	public static Rectangle leftShadow = new Rectangle(656, 394, 16, 16);

	public static Rectangle middleShadow = new Rectangle(672, 394, 16, 16);

	public static Rectangle rightShadow = new Rectangle(688, 394, 16, 16);

	[XmlIgnore]
	public ModDataDictionary modData { get; } = new ModDataDictionary();

	[XmlElement("modData")]
	public ModDataDictionary modDataForSerialization
	{
		get
		{
			return modData.GetForSerialization();
		}
		set
		{
			modData.SetFromSerialization(value);
		}
	}

	public bool isCabin => buildingType.Value == "Cabin";

	public bool isMoving
	{
		get
		{
			return _isMoving;
		}
		set
		{
			if (_isMoving != value)
			{
				_isMoving = value;
				if (_isMoving)
				{
					OnStartMove();
				}
				if (!_isMoving)
				{
					OnEndMove();
				}
			}
		}
	}

	public NetFields NetFields { get; } = new NetFields("Building");

	public Building()
	{
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		id.Value = Guid.NewGuid();
		resetTexture();
		initNetFields();
	}

	public Building(string type, Vector2 tile)
		: this()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		tileX.Value = (int)tile.X;
		tileY.Value = (int)tile.Y;
		buildingType.Value = type;
		BuildingData val = ReloadBuildingData();
		daysOfConstructionLeft.Value = val?.BuildDays ?? 0;
	}

	public virtual bool CanBeReskinned(bool ignoreSeparateConstructionEntries = false)
	{
		BuildingData data = GetData();
		if (skinId.Value != null)
		{
			return true;
		}
		if (data?.Skins != null)
		{
			foreach (BuildingSkin skin in data.Skins)
			{
				if (!(skin.Id == skinId.Value) && (!ignoreSeparateConstructionEntries || !skin.ShowAsSeparateConstructionEntry) && GameStateQuery.CheckConditions(skin.Condition, GetParentLocation()))
				{
					return true;
				}
			}
		}
		return false;
	}

	public bool AllowsAnimalPregnancy()
	{
		return GetData()?.AllowAnimalPregnancy ?? false;
	}

	public virtual bool CanBePainted()
	{
		if (this is GreenhouseBuilding && !Game1.getFarm().greenhouseUnlocked.Value)
		{
			return false;
		}
		if ((isCabin || HasIndoorsName("Farmhouse")) && GetIndoors() is FarmHouse { upgradeLevel: <2 })
		{
			return false;
		}
		return GetPaintDataKey() != null;
	}

	public BuildingSkin GetSkin()
	{
		return GetSkin(skinId.Value, GetData());
	}

	public static BuildingSkin GetSkin(string skinId, BuildingData data)
	{
		if (skinId != null && data?.Skins != null)
		{
			foreach (BuildingSkin skin in data.Skins)
			{
				if (skin.Id == skinId)
				{
					return skin;
				}
			}
		}
		return null;
	}

	public virtual string GetPaintDataKey()
	{
		Dictionary<string, string> paintData = DataLoader.PaintData(Game1.content);
		return GetPaintDataKey(paintData);
	}

	public virtual string GetPaintDataKey(Dictionary<string, string> paintData)
	{
		if (skinId.Value != null && paintData.ContainsKey(skinId.Value))
		{
			return skinId.Value;
		}
		string value = buildingType.Value;
		string text = ((value == "Farmhouse") ? "House" : ((!(value == "Cabin")) ? buildingType.Value : "Stone Cabin"));
		if (!paintData.ContainsKey(text))
		{
			return null;
		}
		return text;
	}

	public string GetMetadata(string key)
	{
		if (buildingMetadata == null)
		{
			buildingMetadata = new Dictionary<string, string>();
			BuildingData data = GetData();
			if (data != null)
			{
				foreach (KeyValuePair<string, string> metadatum in data.Metadata)
				{
					buildingMetadata[metadatum.Key] = metadatum.Value;
				}
				BuildingSkin skin = GetSkin(skinId.Value, data);
				if (skin != null)
				{
					foreach (KeyValuePair<string, string> metadatum2 in skin.Metadata)
					{
						buildingMetadata[metadatum2.Key] = metadatum2.Value;
					}
				}
			}
		}
		if (!buildingMetadata.TryGetValue(key, out key))
		{
			return null;
		}
		return key;
	}

	public GameLocation GetParentLocation()
	{
		return Game1.getLocationFromName(parentLocationName.Value);
	}

	public bool IsInCurrentLocation()
	{
		if (Game1.currentLocation != null)
		{
			return Game1.currentLocation.NameOrUniqueName == parentLocationName.Value;
		}
		return false;
	}

	public virtual bool hasCarpenterPermissions()
	{
		if (Game1.IsMasterGame)
		{
			return true;
		}
		if (owner.Value == Game1.player.UniqueMultiplayerID)
		{
			return true;
		}
		if (GetIndoors() is FarmHouse { IsOwnedByCurrentPlayer: not false })
		{
			return true;
		}
		return false;
	}

	protected virtual void initNetFields()
	{
		NetFields.SetOwner(this).AddField(id, "id").AddField(indoors, "indoors")
			.AddField(nonInstancedIndoorsName, "nonInstancedIndoorsName")
			.AddField(tileX, "tileX")
			.AddField(tileY, "tileY")
			.AddField(tilesWide, "tilesWide")
			.AddField(tilesHigh, "tilesHigh")
			.AddField(maxOccupants, "maxOccupants")
			.AddField(currentOccupants, "currentOccupants")
			.AddField(daysOfConstructionLeft, "daysOfConstructionLeft")
			.AddField(daysUntilUpgrade, "daysUntilUpgrade")
			.AddField(buildingType, "buildingType")
			.AddField(humanDoor, "humanDoor")
			.AddField(animalDoor, "animalDoor")
			.AddField(magical, "magical")
			.AddField(fadeWhenPlayerIsBehind, "fadeWhenPlayerIsBehind")
			.AddField(animalDoorOpen, "animalDoorOpen")
			.AddField(owner, "owner")
			.AddField(newConstructionTimer, "newConstructionTimer")
			.AddField(netBuildingPaintColor, "netBuildingPaintColor")
			.AddField(buildingChests, "buildingChests")
			.AddField(animalDoorOpenAmount, "animalDoorOpenAmount")
			.AddField(hayCapacity, "hayCapacity")
			.AddField(parentLocationName, "parentLocationName")
			.AddField(upgradeName, "upgradeName")
			.AddField(skinId, "skinId")
			.AddField(modData, "modData");
		buildingType.fieldChangeVisibleEvent += delegate(NetString a, string b, string c)
		{
			hasChimney = null;
			bool forUpgrade = b != null && b != c;
			ReloadBuildingData(forUpgrade);
		};
		skinId.fieldChangeVisibleEvent += delegate
		{
			hasChimney = null;
			buildingMetadata = null;
			resetTexture();
		};
		buildingType.fieldChangeVisibleEvent += delegate
		{
			hasChimney = null;
			buildingMetadata = null;
			resetTexture();
		};
		indoors.fieldChangeVisibleEvent += delegate
		{
			UpdateIndoorParent();
		};
		parentLocationName.fieldChangeVisibleEvent += delegate
		{
			UpdateIndoorParent();
		};
		if (netBuildingPaintColor.Value == null)
		{
			netBuildingPaintColor.Value = new BuildingPaintColor();
		}
	}

	public virtual void UpdateIndoorParent()
	{
		GameLocation gameLocation = GetIndoors();
		if (gameLocation != null)
		{
			gameLocation.ParentBuilding = this;
			gameLocation.parentLocationName.Value = parentLocationName.Value;
		}
	}

	public virtual BuildingData GetData()
	{
		if (!TryGetData(buildingType.Value, out var data))
		{
			return null;
		}
		return data;
	}

	public static bool TryGetData(string buildingType, out BuildingData data)
	{
		if (buildingType == null)
		{
			data = null;
			return false;
		}
		return Game1.buildingData.TryGetValue(buildingType, out data);
	}

	public virtual BuildingData ReloadBuildingData(bool forUpgrade = false, bool forConstruction = false)
	{
		BuildingData data = GetData();
		if (data != null)
		{
			LoadFromBuildingData(data, forUpgrade, forConstruction);
		}
		return data;
	}

	public virtual void LoadFromBuildingData(BuildingData data, bool forUpgrade = false, bool forConstruction = false)
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (data == null)
		{
			return;
		}
		tilesWide.Value = data.Size.X;
		tilesHigh.Value = data.Size.Y;
		humanDoor.X = data.HumanDoor.X;
		humanDoor.Y = data.HumanDoor.Y;
		animalDoor.Value = ((Rectangle)(ref data.AnimalDoor)).Location;
		if (data.MaxOccupants >= 0)
		{
			maxOccupants.Value = data.MaxOccupants;
		}
		hayCapacity.Value = data.HayCapacity;
		magical.Value = data.Builder == "Wizard";
		fadeWhenPlayerIsBehind.Value = data.FadeWhenBehind;
		foreach (KeyValuePair<string, string> modDatum in data.ModData)
		{
			modData[modDatum.Key] = modDatum.Value;
		}
		GetIndoors()?.InvalidateCachedMultiplayerMap(Game1.multiplayer.cachedMultiplayerMaps);
		if (!Game1.IsMasterGame)
		{
			return;
		}
		if (hasLoaded || forConstruction)
		{
			if (nonInstancedIndoorsName.Value == null)
			{
				string indoorMap = data.IndoorMap;
				string text = typeof(GameLocation).ToString();
				if (data.IndoorMapType != null)
				{
					text = data.IndoorMapType;
				}
				if (indoorMap != null)
				{
					indoorMap = "Maps\\" + indoorMap;
					if (indoors.Value == null)
					{
						indoors.Value = createIndoors(data, data.IndoorMap);
						InitializeIndoor(data, forConstruction, forUpgrade);
					}
					else if (indoors.Value.mapPath.Value == indoorMap)
					{
						if (forUpgrade)
						{
							InitializeIndoor(data, forConstruction, forUpgrade: true);
						}
					}
					else
					{
						if (indoors.Value.GetType().ToString() != text)
						{
							load();
						}
						else
						{
							indoors.Value.mapPath.Value = indoorMap;
							indoors.Value.updateMap();
						}
						updateInteriorWarps(indoors.Value);
						InitializeIndoor(data, forConstruction, forUpgrade);
					}
				}
			}
			else
			{
				updateInteriorWarps();
			}
		}
		if (!(hasLoaded || forConstruction))
		{
			return;
		}
		HashSet<string> validChests = new HashSet<string>();
		if (data.Chests != null)
		{
			foreach (BuildingChest chest in data.Chests)
			{
				validChests.Add(chest.Id);
			}
		}
		buildingChests.RemoveWhere((Chest chest) => !validChests.Contains(chest.Name));
		if (data.Chests == null)
		{
			return;
		}
		foreach (BuildingChest chest2 in data.Chests)
		{
			if (GetBuildingChest(chest2.Id) == null)
			{
				Chest item = new Chest(playerChest: true)
				{
					Name = chest2.Id
				};
				buildingChests.Add(item);
			}
		}
	}

	public static Building CreateInstanceFromId(string typeId, Vector2 tile)
	{
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if (typeId != null && Game1.buildingData.TryGetValue(typeId, out var value))
		{
			Type type = ((value.BuildingType != null) ? Type.GetType(value.BuildingType) : null);
			if (type != null && type != typeof(Building))
			{
				try
				{
					return (Building)Activator.CreateInstance(type, typeId, tile);
				}
				catch (MissingMethodException)
				{
					try
					{
						Building obj = (Building)Activator.CreateInstance(type, tile);
						obj.buildingType.Value = typeId;
						return obj;
					}
					catch (Exception exception)
					{
						Game1.log.Error("Error trying to instantiate building for type '" + typeId + "'", exception);
					}
				}
			}
		}
		return new Building(typeId, tile);
	}

	public virtual void InitializeIndoor(BuildingData data, bool forConstruction, bool forUpgrade)
	{
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		if (data == null)
		{
			return;
		}
		GameLocation gameLocation = GetIndoors();
		if (gameLocation == null)
		{
			return;
		}
		if (gameLocation is AnimalHouse animalHouse && data.MaxOccupants > 0)
		{
			animalHouse.animalLimit.Value = data.MaxOccupants;
		}
		if (forUpgrade && data.IndoorItemMoves != null)
		{
			foreach (IndoorItemMove indoorItemMove in data.IndoorItemMoves)
			{
				for (int i = 0; i < indoorItemMove.Size.X; i++)
				{
					for (int j = 0; j < indoorItemMove.Size.Y; j++)
					{
						gameLocation.moveContents(indoorItemMove.Source.X + i, indoorItemMove.Source.Y + j, indoorItemMove.Destination.X + i, indoorItemMove.Destination.Y + j, indoorItemMove.UnlessItemId);
					}
				}
			}
		}
		if (!(forConstruction || forUpgrade) || data.IndoorItems == null)
		{
			return;
		}
		foreach (IndoorItemAdd indoorItem in data.IndoorItems)
		{
			Vector2 val = Utility.PointToVector2(indoorItem.Tile);
			Object obj = ItemRegistry.Create(indoorItem.ItemId) as Object;
			Furniture furniture = obj as Furniture;
			if (obj == null)
			{
				continue;
			}
			if (indoorItem.ClearTile)
			{
				if (furniture != null)
				{
					int k = 0;
					for (int num = furniture.getTilesHigh(); k < num; k++)
					{
						int l = 0;
						for (int num2 = furniture.getTilesWide(); l < num2; l++)
						{
							gameLocation.cleanUpTileForMapOverride(new Point((int)val.X + l, (int)val.Y + k), indoorItem.ItemId);
						}
					}
				}
				else
				{
					gameLocation.cleanUpTileForMapOverride(Utility.Vector2ToPoint(val), indoorItem.ItemId);
				}
			}
			if (!gameLocation.IsTileBlockedBy(val, CollisionMask.Furniture | CollisionMask.Objects))
			{
				if (indoorItem.Indestructible)
				{
					obj.fragility.Value = 2;
				}
				obj.TileLocation = val;
				if (furniture != null)
				{
					gameLocation.furniture.Add(furniture);
				}
				else
				{
					gameLocation.objects.Add(val, obj);
				}
			}
		}
	}

	public BuildingItemConversion GetItemConversionForItem(Item item, Chest chest)
	{
		if (item == null || chest == null)
		{
			return null;
		}
		BuildingData data = GetData();
		if (data?.ItemConversions != null)
		{
			foreach (BuildingItemConversion itemConversion in data.ItemConversions)
			{
				if (!(itemConversion.SourceChest == chest.Name))
				{
					continue;
				}
				bool flag = false;
				foreach (string requiredTag in itemConversion.RequiredTags)
				{
					if (!item.HasContextTag(requiredTag))
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					return itemConversion;
				}
			}
		}
		return null;
	}

	public bool IsValidObjectForChest(Item item, Chest chest)
	{
		return GetItemConversionForItem(item, chest) != null;
	}

	public bool PerformBuildingChestAction(string name, Farmer who)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Expected I4, but got Unknown
		Chest chest = GetBuildingChest(name);
		if (chest == null)
		{
			return false;
		}
		BuildingChest buildingChestData = GetBuildingChestData(name);
		if (buildingChestData == null)
		{
			return false;
		}
		BuildingChestType type = buildingChestData.Type;
		switch ((int)type)
		{
		case 0:
			((MenuWithInventory)(Game1.activeClickableMenu = new ItemGrabMenu(chest.Items, reverseGrab: false, showReceivingMenu: true, (Item item) => IsValidObjectForChest(item, chest), chest.grabItemFromInventory, null, chest.grabItemFromChest, snapToBottom: false, canBeExitedWithKey: true, playRightClickSound: true, allowRightClick: true, showOrganizeButton: true, 1, null, -1, this))).inventory.moveItemSound = buildingChestData.Sound;
			return true;
		case 2:
			if (who?.ActiveObject != null)
			{
				if (!IsValidObjectForChest(who.ActiveObject, chest))
				{
					if (buildingChestData.InvalidItemMessage != null && (buildingChestData.InvalidItemMessageCondition == null || GameStateQuery.CheckConditions(buildingChestData.InvalidItemMessageCondition, GetParentLocation(), who, who.ActiveObject, who.ActiveObject)))
					{
						Game1.showRedMessage(TokenParser.ParseText(buildingChestData.InvalidItemMessage));
					}
					return false;
				}
				BuildingItemConversion itemConversionForItem = GetItemConversionForItem(who.ActiveObject, chest);
				Utility.consolidateStacks(chest.Items);
				chest.clearNulls();
				int numberOfItemThatCanBeAddedToThisInventoryList = Utility.GetNumberOfItemThatCanBeAddedToThisInventoryList(who.ActiveObject, chest.Items, 36);
				if (who.ActiveObject.Stack > itemConversionForItem.RequiredCount && numberOfItemThatCanBeAddedToThisInventoryList < itemConversionForItem.RequiredCount)
				{
					Game1.showRedMessage(TokenParser.ParseText(buildingChestData.ChestFullMessage));
					return false;
				}
				int num = Math.Min(numberOfItemThatCanBeAddedToThisInventoryList, who.ActiveObject.Stack) / itemConversionForItem.RequiredCount * itemConversionForItem.RequiredCount;
				if (num == 0)
				{
					if (buildingChestData.InvalidCountMessage != null)
					{
						Game1.showRedMessage(TokenParser.ParseText(buildingChestData.InvalidCountMessage));
					}
					return false;
				}
				Item one = who.ActiveObject.getOne();
				if (who.ActiveObject.ConsumeStack(num) == null)
				{
					who.ActiveObject = null;
				}
				one.Stack = num;
				Utility.addItemToThisInventoryList(one, chest.Items, 36);
				if (buildingChestData.Sound != null)
				{
					Game1.playSound(buildingChestData.Sound);
				}
			}
			return true;
		case 1:
			Utility.CollectSingleItemOrShowChestMenu(chest);
			return true;
		default:
			return false;
		}
	}

	public BuildingChest GetBuildingChestData(string name)
	{
		return GetBuildingChestData(GetData(), name);
	}

	public static BuildingChest GetBuildingChestData(BuildingData data, string name)
	{
		if (data == null)
		{
			return null;
		}
		foreach (BuildingChest chest in data.Chests)
		{
			if (chest.Id == name)
			{
				return chest;
			}
		}
		return null;
	}

	public Chest GetBuildingChest(string name)
	{
		foreach (Chest buildingChest in buildingChests)
		{
			if (buildingChest.Name == name)
			{
				return buildingChest;
			}
		}
		return null;
	}

	public virtual string textureName()
	{
		BuildingData data = GetData();
		return GetSkin(skinId.Value, data)?.Texture ?? data?.Texture ?? ("Buildings\\" + buildingType.Value);
	}

	public virtual void resetTexture()
	{
		texture = new Lazy<Texture2D>((Func<Texture2D>)delegate
		{
			if (paintedTexture != null)
			{
				((GraphicsResource)paintedTexture).Dispose();
				paintedTexture = null;
			}
			string text = textureName();
			Texture2D val;
			try
			{
				val = Game1.content.Load<Texture2D>(text);
			}
			catch
			{
				return Game1.content.Load<Texture2D>("Buildings\\Error");
			}
			paintedTexture = BuildingPainter.Apply(val, text + "_PaintMask", netBuildingPaintColor.Value);
			if (paintedTexture != null)
			{
				val = paintedTexture;
			}
			return val;
		});
	}

	public int getTileSheetIndexForStructurePlacementTile(int x, int y)
	{
		if (x == humanDoor.X && y == humanDoor.Y)
		{
			return 2;
		}
		if (x == animalDoor.X && y == animalDoor.Y)
		{
			return 4;
		}
		return 0;
	}

	public virtual void performTenMinuteAction(int timeElapsed)
	{
	}

	public virtual void resetLocalState()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		alpha = 1f;
		color = Color.White;
		isMoving = false;
	}

	public virtual bool CanLeftClick(int x, int y)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		Rectangle boundingBox = default(Rectangle);
		((Rectangle)(ref boundingBox))._002Ector(x, y, 1, 1);
		return intersects(boundingBox);
	}

	public virtual bool leftClicked()
	{
		return false;
	}

	public virtual void ToggleAnimalDoor(Farmer who)
	{
		BuildingData data = GetData();
		string text = ((!animalDoorOpen.Value) ? data?.AnimalDoorCloseSound : data?.AnimalDoorOpenSound);
		if (text != null)
		{
			who.currentLocation.playSound(text);
		}
		animalDoorOpen.Value = !animalDoorOpen.Value;
	}

	public virtual bool OnUseHumanDoor(Farmer who)
	{
		return true;
	}

	public virtual bool doAction(Vector2 tileLocation, Farmer who)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		if (who.isRidingHorse())
		{
			return false;
		}
		if (who.IsLocalPlayer && occupiesTile(tileLocation) && daysOfConstructionLeft.Value > 0)
		{
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Buildings:UnderConstruction"));
		}
		else
		{
			if (who.ActiveObject != null && who.ActiveObject.IsFloorPathItem() && who.currentLocation != null && !who.currentLocation.terrainFeatures.ContainsKey(tileLocation))
			{
				return false;
			}
			GameLocation gameLocation = GetIndoors();
			if (who.IsLocalPlayer && tileLocation.X == (float)(humanDoor.X + tileX.Value) && tileLocation.Y == (float)(humanDoor.Y + tileY.Value) && gameLocation != null)
			{
				if (who.mount != null)
				{
					Game1.showRedMessage(Game1.content.LoadString("Strings\\Buildings:DismountBeforeEntering"));
					return false;
				}
				if (who.team.demolishLock.IsLocked())
				{
					Game1.showRedMessage(Game1.content.LoadString("Strings\\Buildings:CantEnter"));
					return false;
				}
				if (OnUseHumanDoor(who))
				{
					who.currentLocation.playSound("doorClose", tileLocation);
					bool isStructure = indoors.Value != null;
					Game1.warpFarmer(gameLocation.NameOrUniqueName, gameLocation.warps[0].X, gameLocation.warps[0].Y - 1, Game1.player.FacingDirection, isStructure);
				}
				return true;
			}
			BuildingData data = GetData();
			if (data != null)
			{
				Rectangle rectForAnimalDoor = getRectForAnimalDoor(data);
				rectForAnimalDoor.Width /= 64;
				rectForAnimalDoor.Height /= 64;
				rectForAnimalDoor.X /= 64;
				rectForAnimalDoor.Y /= 64;
				if (daysOfConstructionLeft.Value <= 0 && rectForAnimalDoor != Rectangle.Empty && ((Rectangle)(ref rectForAnimalDoor)).Contains(Utility.Vector2ToPoint(tileLocation)) && Game1.didPlayerJustRightClick(ignoreNonMouseHeldInput: true))
				{
					ToggleAnimalDoor(who);
					return true;
				}
				if (who.IsLocalPlayer && occupiesTile(tileLocation, applyTilePropertyRadius: true) && !isTilePassable(tileLocation))
				{
					string actionAtTile = data.GetActionAtTile((int)tileLocation.X - tileX.Value, (int)tileLocation.Y - tileY.Value);
					if (actionAtTile != null)
					{
						actionAtTile = TokenParser.ParseText(actionAtTile);
						if (who.currentLocation.performAction(actionAtTile, who, new Location((int)tileLocation.X, (int)tileLocation.Y)))
						{
							return true;
						}
					}
				}
			}
			else if (who.IsLocalPlayer)
			{
				if (!isTilePassable(tileLocation) && TryPerformObeliskWarp(buildingType.Value, who))
				{
					return true;
				}
				if (who.ActiveObject != null && !isTilePassable(tileLocation))
				{
					return performActiveObjectDropInAction(who, probe: false);
				}
			}
		}
		return false;
	}

	public static bool TryPerformObeliskWarp(string buildingType, Farmer who)
	{
		switch (buildingType)
		{
		case "Desert Obelisk":
			PerformObeliskWarp("Desert", 35, 43, force_dismount: true, who);
			return true;
		case "Water Obelisk":
			PerformObeliskWarp("Beach", 20, 4, force_dismount: false, who);
			return true;
		case "Earth Obelisk":
			PerformObeliskWarp("Mountain", 31, 20, force_dismount: false, who);
			return true;
		case "Island Obelisk":
			PerformObeliskWarp("IslandSouth", 11, 11, force_dismount: false, who);
			return true;
		default:
			return false;
		}
	}

	public static void PerformObeliskWarp(string destination, int warp_x, int warp_y, bool force_dismount, Farmer who)
	{
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		if (force_dismount && who.isRidingHorse() && who.mount != null)
		{
			who.mount.checkAction(who, who.currentLocation);
			return;
		}
		for (int i = 0; i < 12; i++)
		{
			who.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(354, Game1.random.Next(25, 75), 6, 1, new Vector2((float)Game1.random.Next((int)who.Position.X - 256, (int)who.Position.X + 192), (float)Game1.random.Next((int)who.Position.Y - 256, (int)who.Position.Y + 192)), flicker: false, Game1.random.NextBool()));
		}
		who.currentLocation.playSound("wand");
		Game1.displayFarmer = false;
		Game1.player.temporarilyInvincible = true;
		Game1.player.temporaryInvincibilityTimer = -2000;
		Game1.player.freezePause = 1000;
		Game1.flashAlpha = 1f;
		Rectangle boundingBox = who.GetBoundingBox();
		DelayedAction.fadeAfterDelay(delegate
		{
			obeliskWarpForReal(destination, warp_x, warp_y, who);
		}, 1000);
		Rectangle val = default(Rectangle);
		((Rectangle)(ref val))._002Ector(boundingBox.X, boundingBox.Y, 64, 64);
		((Rectangle)(ref val)).Inflate(192, 192);
		int num = 0;
		Point tilePoint = who.TilePoint;
		for (int num2 = tilePoint.X + 8; num2 >= tilePoint.X - 8; num2--)
		{
			who.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(6, new Vector2((float)num2, (float)tilePoint.Y) * 64f, Color.White, 8, flipped: false, 50f)
			{
				layerDepth = 1f,
				delayBeforeAnimationStart = num * 25,
				motion = new Vector2(-0.25f, 0f)
			});
			num++;
		}
	}

	private static void obeliskWarpForReal(string destination, int warp_x, int warp_y, Farmer who)
	{
		Game1.warpFarmer(destination, warp_x, warp_y, flip: false);
		Game1.fadeToBlackAlpha = 0.99f;
		Game1.screenGlow = false;
		Game1.player.temporarilyInvincible = false;
		Game1.player.temporaryInvincibilityTimer = 0;
		Game1.displayFarmer = true;
	}

	public virtual bool isActionableTile(int xTile, int yTile, Farmer who)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		BuildingData data = GetData();
		if (data != null)
		{
			Vector2 tile = default(Vector2);
			((Vector2)(ref tile))._002Ector((float)xTile, (float)yTile);
			if (occupiesTile(tile, applyTilePropertyRadius: true) && !isTilePassable(tile) && data.GetActionAtTile(xTile - tileX.Value, yTile - tileY.Value) != null)
			{
				return true;
			}
		}
		if (humanDoor.X >= 0 && xTile == tileX.Value + humanDoor.X && yTile == tileY.Value + humanDoor.Y)
		{
			return true;
		}
		Rectangle rectForAnimalDoor = getRectForAnimalDoor(data);
		rectForAnimalDoor.Width /= 64;
		rectForAnimalDoor.Height /= 64;
		rectForAnimalDoor.X /= 64;
		rectForAnimalDoor.Y /= 64;
		if (rectForAnimalDoor != Rectangle.Empty)
		{
			return ((Rectangle)(ref rectForAnimalDoor)).Contains(new Point(xTile, yTile));
		}
		return false;
	}

	public virtual void performActionOnBuildingPlacement()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		GameLocation parentLocation = GetParentLocation();
		if (parentLocation == null)
		{
			return;
		}
		Vector2 key = default(Vector2);
		for (int i = 0; i < tilesHigh.Value; i++)
		{
			for (int j = 0; j < tilesWide.Value; j++)
			{
				((Vector2)(ref key))._002Ector((float)(tileX.Value + j), (float)(tileY.Value + i));
				if (!(parentLocation.terrainFeatures.GetValueOrDefault(key) is Flooring) || !(GetData()?.AllowsFlooringUnderneath ?? false))
				{
					parentLocation.terrainFeatures.Remove(key);
				}
			}
		}
		Vector2 key2 = default(Vector2);
		foreach (BuildingPlacementTile additionalPlacementTile in GetAdditionalPlacementTiles())
		{
			bool onlyNeedsToBePassable = additionalPlacementTile.OnlyNeedsToBePassable;
			foreach (Point point in additionalPlacementTile.TileArea.GetPoints())
			{
				((Vector2)(ref key2))._002Ector((float)(tileX.Value + point.X), (float)(tileY.Value + point.Y));
				if ((!onlyNeedsToBePassable || (parentLocation.terrainFeatures.TryGetValue(key2, out var value) && !value.isPassable())) && (!(parentLocation.terrainFeatures.GetValueOrDefault(key2) is Flooring) || !(GetData()?.AllowsFlooringUnderneath ?? false)))
				{
					parentLocation.terrainFeatures.Remove(key2);
				}
			}
		}
	}

	public virtual void performActionOnConstruction(GameLocation location, Farmer who)
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_0357: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_036a: Unknown result type (might be due to invalid IL or missing references)
		//IL_036f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_038a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0410: Unknown result type (might be due to invalid IL or missing references)
		//IL_0415: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Unknown result type (might be due to invalid IL or missing references)
		//IL_043d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0482: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0504: Unknown result type (might be due to invalid IL or missing references)
		//IL_0518: Unknown result type (might be due to invalid IL or missing references)
		//IL_0532: Unknown result type (might be due to invalid IL or missing references)
		//IL_0537: Unknown result type (might be due to invalid IL or missing references)
		//IL_055a: Unknown result type (might be due to invalid IL or missing references)
		//IL_055f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05dd: Unknown result type (might be due to invalid IL or missing references)
		BuildingData data = GetData();
		LoadFromBuildingData(data, forUpgrade: false, forConstruction: true);
		Vector2 value = default(Vector2);
		((Vector2)(ref value))._002Ector((float)tileX.Value + (float)tilesWide.Value * 0.5f, (float)tileY.Value + (float)tilesHigh.Value * 0.5f);
		location.localSound("axchop", value);
		newConstructionTimer.Value = ((magical.Value || daysOfConstructionLeft.Value <= 0) ? 2000 : 1000);
		if (data?.AddMailOnBuild != null)
		{
			foreach (string item in data.AddMailOnBuild)
			{
				Game1.addMail(item, noLetter: false, sendToEveryone: true);
			}
		}
		if (!magical.Value)
		{
			location.localSound("axchop", value);
			for (int i = tileX.Value; i < tileX.Value + tilesWide.Value; i++)
			{
				for (int j = tileY.Value; j < tileY.Value + tilesHigh.Value; j++)
				{
					for (int k = 0; k < 5; k++)
					{
						location.temporarySprites.Add(new TemporaryAnimatedSprite(Game1.random.Choose(46, 12), new Vector2((float)i, (float)j) * 64f + new Vector2((float)Game1.random.Next(-16, 32), (float)Game1.random.Next(-16, 32)), Color.White, 10, Game1.random.NextBool())
						{
							delayBeforeAnimationStart = Math.Max(0, Game1.random.Next(-200, 400)),
							motion = new Vector2(0f, -1f),
							interval = Game1.random.Next(50, 80)
						});
					}
					location.temporarySprites.Add(new TemporaryAnimatedSprite(14, new Vector2((float)i, (float)j) * 64f + new Vector2((float)Game1.random.Next(-16, 32), (float)Game1.random.Next(-16, 32)), Color.White, 10, Game1.random.NextBool()));
				}
			}
			for (int l = 0; l < 8; l++)
			{
				DelayedAction.playSoundAfterDelay("dirtyHit", 250 + l * 150, location, value, -1, local: true);
			}
		}
		else
		{
			for (int m = 0; m < 8; m++)
			{
				DelayedAction.playSoundAfterDelay("dirtyHit", 100 + m * 210, location, value, -1, local: true);
			}
			if (Game1.player == who)
			{
				Game1.flashAlpha = 2f;
			}
			location.localSound("wand", value);
			Rectangle sourceRect = getSourceRect();
			Rectangle val = getSourceRectForMenu() ?? sourceRect;
			int n = 0;
			for (int num = sourceRect.Height / 16 * 2; n <= num; n++)
			{
				int num2 = 0;
				for (int num3 = val.Width / 16 * 2; num2 < num3; num2++)
				{
					location.temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(666, 1851, 8, 8), 40f, 4, 2, new Vector2((float)tileX.Value, (float)tileY.Value) * 64f + new Vector2((float)(num2 * 64 / 2), (float)(n * 64 / 2 - sourceRect.Height * 4 + tilesHigh.Value * 64)) + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-32, 32)), flicker: false, flipped: false)
					{
						layerDepth = (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + (float)num2 / 10000f,
						pingPong = true,
						delayBeforeAnimationStart = (sourceRect.Height / 16 * 2 - n) * 100,
						scale = 4f,
						alphaFade = 0.01f,
						color = Color.AliceBlue
					});
					location.temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(666, 1851, 8, 8), 40f, 4, 2, new Vector2((float)tileX.Value, (float)tileY.Value) * 64f + new Vector2((float)(num2 * 64 / 2), (float)(n * 64 / 2 - sourceRect.Height * 4 + tilesHigh.Value * 64)) + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-32, 32)), flicker: false, flipped: false)
					{
						layerDepth = (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + (float)num2 / 10000f + 0.0001f,
						pingPong = true,
						delayBeforeAnimationStart = (sourceRect.Height / 16 * 2 - n) * 100,
						scale = 4f,
						alphaFade = 0.01f,
						color = Color.AliceBlue
					});
				}
			}
		}
		if (GetIndoors() is Cabin { HasOwner: false } cabin)
		{
			cabin.CreateFarmhand();
			if (Game1.IsMasterGame)
			{
				hasLoaded = true;
			}
		}
	}

	public virtual void performActionOnDemolition(GameLocation location)
	{
		if (GetIndoors() is Cabin cabin)
		{
			cabin.DeleteFarmhand();
		}
		if (indoors.Value != null)
		{
			Game1.multiplayer.broadcastRemoveLocationFromLookup(indoors.Value);
			indoors.Value.OnRemoved();
			indoors.Value = null;
		}
	}

	public virtual bool ForEachItemExcludingInterior(Func<Item, bool> action)
	{
		return ForEachItemContextExcludingInterior(Handle, GetParentPath);
		IList<object> GetParentPath()
		{
			return new List<object> { GetParentLocation() };
		}
		bool Handle(in ForEachItemContext context)
		{
			return action(context.Item);
		}
	}

	public virtual bool ForEachItemContextExcludingInterior(ForEachItemDelegate handler, GetForEachItemPathDelegate getParentPath)
	{
		foreach (Chest buildingChest in buildingChests)
		{
			Chest chest = buildingChest;
			if (!chest.ForEachItem(handler, GetPath))
			{
				return false;
			}
			IList<object> GetPath()
			{
				return ForEachItemHelper.CombinePath(getParentPath, this, buildingChests, chest);
			}
		}
		return true;
	}

	public virtual void BeforeDemolish()
	{
		List<Item> quest_items = new List<Item>();
		ForEachItemExcludingInterior(delegate(Item item)
		{
			CollectQuestItem(item);
			return true;
		});
		if (indoors.Value != null)
		{
			Utility.ForEachItemIn(indoors.Value, delegate(Item item)
			{
				CollectQuestItem(item);
				return true;
			});
			if (indoors.Value is Cabin cabin)
			{
				Cellar cellar = cabin.GetCellar();
				if (cellar != null)
				{
					Utility.ForEachItemIn(cellar, delegate(Item item)
					{
						CollectQuestItem(item);
						return true;
					});
				}
			}
		}
		if (quest_items.Count > 0)
		{
			Game1.showGlobalMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:NewLostAndFoundItems"));
			for (int num = 0; num < quest_items.Count; num++)
			{
				Game1.player.team.returnedDonations.Add(quest_items[num]);
			}
		}
		void CollectQuestItem(Item item)
		{
			if (item is Object obj && obj.questItem.Value)
			{
				Item one = obj.getOne();
				one.Stack = obj.Stack;
				quest_items.Add(one);
			}
		}
	}

	public virtual void performActionOnUpgrade(GameLocation location)
	{
		if (location is Farm farm)
		{
			farm.UnsetFarmhouseValues();
		}
	}

	public virtual string isThereAnythingtoPreventConstruction(GameLocation location, Vector2 tile_location)
	{
		return null;
	}

	public virtual bool performActiveObjectDropInAction(Farmer who, bool probe)
	{
		return false;
	}

	public virtual void performToolAction(Tool t, int tileX, int tileY)
	{
	}

	public virtual void updateWhenFarmNotCurrentLocation(GameTime time)
	{
		if (indoors.Value != null && Game1.currentLocation != indoors.Value)
		{
			indoors.Value.netAudio.Update();
		}
		netBuildingPaintColor.Value?.Poll(resetTexture);
		if (newConstructionTimer.Value > 0)
		{
			newConstructionTimer.Value -= time.ElapsedGameTime.Milliseconds;
			if (newConstructionTimer.Value <= 0 && magical.Value)
			{
				daysOfConstructionLeft.Value = 0;
			}
		}
		if (!Game1.IsMasterGame)
		{
			return;
		}
		BuildingData data = GetData();
		if (data == null)
		{
			return;
		}
		if (animalDoorOpen.Value)
		{
			if (animalDoorOpenAmount.Value < 1f)
			{
				animalDoorOpenAmount.Value = ((data.AnimalDoorOpenDuration > 0f) ? Utility.MoveTowards(animalDoorOpenAmount.Value, 1f, (float)time.ElapsedGameTime.TotalSeconds / data.AnimalDoorOpenDuration) : 1f);
			}
		}
		else if (animalDoorOpenAmount.Value > 0f)
		{
			animalDoorOpenAmount.Value = ((data.AnimalDoorCloseDuration > 0f) ? Utility.MoveTowards(animalDoorOpenAmount.Value, 0f, (float)time.ElapsedGameTime.TotalSeconds / data.AnimalDoorCloseDuration) : 0f);
		}
	}

	public virtual void Update(GameTime time)
	{
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_0274: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		if (!hasLoaded && Game1.IsMasterGame && Game1.hasLoadedGame)
		{
			ReloadBuildingData(forUpgrade: false, forConstruction: true);
			load();
		}
		UpdateTransparency();
		if (isUnderConstruction())
		{
			return;
		}
		if (!hasChimney.HasValue)
		{
			string metadata = GetMetadata("ChimneyPosition");
			if (metadata != null)
			{
				hasChimney = true;
				string[] array = ArgUtility.SplitBySpace(metadata);
				chimneyPosition.X = int.Parse(array[0]);
				chimneyPosition.Y = int.Parse(array[1]);
			}
			else
			{
				hasChimney = false;
			}
		}
		GameLocation gameLocation = GetIndoors();
		if (gameLocation is FarmHouse { upgradeLevel: var upgradeLevel } && lastHouseUpgradeLevel != upgradeLevel)
		{
			lastHouseUpgradeLevel = upgradeLevel;
			string text = null;
			for (int i = 1; i <= lastHouseUpgradeLevel; i++)
			{
				string metadata2 = GetMetadata("ChimneyPosition" + (i + 1));
				if (metadata2 != null)
				{
					text = metadata2;
				}
			}
			if (text != null)
			{
				hasChimney = true;
				string[] array2 = ArgUtility.SplitBySpace(text);
				chimneyPosition.X = int.Parse(array2[0]);
				chimneyPosition.Y = int.Parse(array2[1]);
			}
		}
		if (hasChimney != true || gameLocation == null)
		{
			return;
		}
		chimneyTimer -= time.ElapsedGameTime.Milliseconds;
		if (chimneyTimer <= 0)
		{
			if (gameLocation.hasActiveFireplace())
			{
				GameLocation parentLocation = GetParentLocation();
				Rectangle sourceRect = getSourceRect();
				Vector2 val = default(Vector2);
				((Vector2)(ref val))._002Ector((float)(tileX.Value * 64), (float)(tileY.Value * 64 + tilesHigh.Value * 64 - sourceRect.Height * 4));
				BuildingData data = GetData();
				Vector2 val2 = ((data != null) ? (data.DrawOffset * 4f) : Vector2.Zero);
				TemporaryAnimatedSprite temporaryAnimatedSprite = TemporaryAnimatedSprite.GetTemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(372, 1956, 10, 10), new Vector2(val.X + val2.X, val.Y + val2.Y) + chimneyPosition * 4f + new Vector2(-8f, -12f), flipped: false, 0.002f, Color.Gray);
				temporaryAnimatedSprite.alpha = 0.75f;
				temporaryAnimatedSprite.motion = new Vector2(0f, -0.5f);
				temporaryAnimatedSprite.acceleration = new Vector2(0.002f, 0f);
				temporaryAnimatedSprite.interval = 99999f;
				temporaryAnimatedSprite.layerDepth = 1f;
				temporaryAnimatedSprite.scale = 2f;
				temporaryAnimatedSprite.scaleChange = 0.02f;
				temporaryAnimatedSprite.rotationChange = (float)Game1.random.Next(-5, 6) * (float)Math.PI / 256f;
				parentLocation.temporarySprites.Add(temporaryAnimatedSprite);
			}
			chimneyTimer = 500;
		}
	}

	public virtual void UpdateTransparency()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		if (fadeWhenPlayerIsBehind.Value)
		{
			Rectangle val = (Rectangle)(((_003F?)getSourceRectForMenu()) ?? getSourceRect());
			Rectangle val2 = default(Rectangle);
			((Rectangle)(ref val2))._002Ector(tileX.Value * 64, (tileY.Value + (-(val.Height / 16) + tilesHigh.Value)) * 64, tilesWide.Value * 64, (val.Height / 16 - tilesHigh.Value) * 64 + 32);
			Rectangle boundingBox = Game1.player.GetBoundingBox();
			if (((Rectangle)(ref boundingBox)).Intersects(val2))
			{
				if (alpha > 0.4f)
				{
					alpha = Math.Max(0.4f, alpha - 0.04f);
				}
				return;
			}
		}
		if (alpha < 1f)
		{
			alpha = Math.Min(1f, alpha + 0.05f);
		}
	}

	public virtual void showUpgradeAnimation(GameLocation location)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		color = Color.White;
		location.temporarySprites.Add(new TemporaryAnimatedSprite(46, getUpgradeSignLocation() + new Vector2((float)Game1.random.Next(-16, 16), (float)Game1.random.Next(-16, 16)), Color.Beige, 10, Game1.random.NextBool(), 75f)
		{
			motion = new Vector2(0f, -0.5f),
			acceleration = new Vector2(-0.02f, 0.01f),
			delayBeforeAnimationStart = Game1.random.Next(100),
			layerDepth = 0.89f
		});
		location.temporarySprites.Add(new TemporaryAnimatedSprite(46, getUpgradeSignLocation() + new Vector2((float)Game1.random.Next(-16, 16), (float)Game1.random.Next(-16, 16)), Color.Beige, 10, Game1.random.NextBool(), 75f)
		{
			motion = new Vector2(0f, -0.5f),
			acceleration = new Vector2(-0.02f, 0.01f),
			delayBeforeAnimationStart = Game1.random.Next(40),
			layerDepth = 0.89f
		});
	}

	public virtual Vector2 getUpgradeSignLocation()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		BuildingData data = GetData();
		Vector2 val = (Vector2)(((_003F?)data?.UpgradeSignTile) ?? new Vector2(0.5f, 0f));
		float num = data?.UpgradeSignHeight ?? 8f;
		return new Vector2(((float)tileX.Value + val.X) * 64f, ((float)tileY.Value + val.Y) * 64f - num * 4f);
	}

	public virtual void showDestroyedAnimation(GameLocation location)
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		for (int i = tileX.Value; i < tileX.Value + tilesWide.Value; i++)
		{
			for (int j = tileY.Value; j < tileY.Value + tilesHigh.Value; j++)
			{
				location.temporarySprites.Add(new TemporaryAnimatedSprite(362, Game1.random.Next(30, 90), 6, 1, new Vector2((float)(i * 64), (float)(j * 64)) + new Vector2((float)Game1.random.Next(-16, 16), (float)Game1.random.Next(-16, 16)), flicker: false, Game1.random.NextBool())
				{
					delayBeforeAnimationStart = Game1.random.Next(300)
				});
				location.temporarySprites.Add(new TemporaryAnimatedSprite(362, Game1.random.Next(30, 90), 6, 1, new Vector2((float)(i * 64), (float)(j * 64)) + new Vector2((float)Game1.random.Next(-16, 16), (float)Game1.random.Next(-16, 16)), flicker: false, Game1.random.NextBool())
				{
					delayBeforeAnimationStart = 250 + Game1.random.Next(300)
				});
				location.temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(276, 1985, 12, 11), new Vector2((float)i, (float)j) * 64f + new Vector2(32f, -32f) + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-16, 16)), flipped: false, 0f, Color.White)
				{
					interval = 30f,
					totalNumberOfLoops = 99999,
					animationLength = 4,
					scale = 4f,
					alphaFade = 0.01f
				});
			}
		}
	}

	public void FinishConstruction(bool onGameStart = false)
	{
		bool flag = false;
		if (daysOfConstructionLeft.Value > 0)
		{
			Game1.player.team.constructedBuildings.Add(buildingType.Value);
			if (buildingType.Value == "Slime Hutch")
			{
				Game1.player.mailReceived.Add("slimeHutchBuilt");
			}
			daysOfConstructionLeft.Value = 0;
			flag = true;
		}
		if (daysUntilUpgrade.Value > 0)
		{
			string text = upgradeName.Value ?? "Well";
			Game1.player.team.constructedBuildings.Add(text);
			buildingType.Value = text;
			ReloadBuildingData(forUpgrade: true);
			daysUntilUpgrade.Value = 0;
			OnUpgraded();
			flag = true;
		}
		if (flag)
		{
			Game1.netWorldState.Value.UpdateUnderConstruction();
			resetTexture();
		}
		if (onGameStart)
		{
			return;
		}
		foreach (Farmer allFarmer in Game1.getAllFarmers())
		{
			allFarmer.autoGenerateActiveDialogueEvent("structureBuilt_" + buildingType.Value);
		}
	}

	public virtual void dayUpdate(int dayOfMonth)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		if (daysOfConstructionLeft.Value > 0 && !Utility.isFestivalDay(dayOfMonth, Game1.season) && (!Game1.isGreenRain || Game1.year > 1))
		{
			if (daysOfConstructionLeft.Value == 1)
			{
				FinishConstruction();
			}
			else
			{
				daysOfConstructionLeft.Value--;
			}
			return;
		}
		if (daysUntilUpgrade.Value > 0 && !Utility.isFestivalDay(dayOfMonth, Game1.season) && (!Game1.isGreenRain || Game1.year > 1))
		{
			if (daysUntilUpgrade.Value == 1)
			{
				FinishConstruction();
			}
			else
			{
				daysUntilUpgrade.Value--;
			}
		}
		GameLocation gameLocation = GetIndoors();
		if (gameLocation is AnimalHouse animalHouse)
		{
			currentOccupants.Value = animalHouse.animals.Length;
		}
		if (GetIndoorsType() == IndoorsType.Instanced)
		{
			gameLocation?.DayUpdate(dayOfMonth);
		}
		BuildingData data = GetData();
		if (data == null || !(data.ItemConversions?.Count > 0))
		{
			return;
		}
		ItemQueryContext itemQueryContext = new ItemQueryContext(GetParentLocation(), null, null, "building '" + buildingType.Value + "' > item conversion rules");
		foreach (BuildingItemConversion itemConversion in data.ItemConversions)
		{
			CheckItemConversionRule(itemConversion, itemQueryContext);
		}
	}

	public virtual void CheckItemConversionRule(BuildingItemConversion conversion, ItemQueryContext itemQueryContext)
	{
		int num = 0;
		int num2 = 0;
		Chest buildingChest = GetBuildingChest(conversion.SourceChest);
		Chest buildingChest2 = GetBuildingChest(conversion.DestinationChest);
		if (buildingChest == null)
		{
			return;
		}
		foreach (Item item4 in buildingChest.Items)
		{
			if (item4 == null)
			{
				continue;
			}
			bool flag = false;
			foreach (string requiredTag in conversion.RequiredTags)
			{
				if (!item4.HasContextTag(requiredTag))
				{
					flag = true;
					break;
				}
			}
			if (flag)
			{
				continue;
			}
			num2 += item4.Stack;
			if (num2 >= conversion.RequiredCount)
			{
				int num3 = num2 / conversion.RequiredCount;
				if (conversion.MaxDailyConversions >= 0)
				{
					num3 = Math.Min(num3, conversion.MaxDailyConversions - num);
				}
				num += num3;
				num2 -= num3 * conversion.RequiredCount;
			}
			if (conversion.MaxDailyConversions >= 0 && num >= conversion.MaxDailyConversions)
			{
				break;
			}
		}
		if (num == 0)
		{
			return;
		}
		int num4 = 0;
		for (int i = 0; i < num; i++)
		{
			bool flag2 = false;
			for (int j = 0; j < conversion.ProducedItems.Count; j++)
			{
				GenericSpawnItemDataWithCondition val = conversion.ProducedItems[j];
				if (GameStateQuery.CheckConditions(val.Condition, GetParentLocation()))
				{
					Item item = ItemQueryResolver.TryResolveRandomItem((ISpawnItemData)(object)val, itemQueryContext);
					int stack = item.Stack;
					Item item2 = buildingChest2.addItem(item);
					if (item2 == null || item2.Stack != stack)
					{
						flag2 = true;
					}
				}
			}
			if (flag2)
			{
				num4++;
			}
		}
		if (num4 <= 0)
		{
			return;
		}
		int num5 = num4 * conversion.RequiredCount;
		for (int k = 0; k < buildingChest.Items.Count; k++)
		{
			Item item3 = buildingChest.Items[k];
			if (item3 == null)
			{
				continue;
			}
			bool flag3 = false;
			foreach (string requiredTag2 in conversion.RequiredTags)
			{
				if (!item3.HasContextTag(requiredTag2))
				{
					flag3 = true;
					break;
				}
			}
			if (!flag3)
			{
				int num6 = Math.Min(num5, item3.Stack);
				buildingChest.Items[k] = item3.ConsumeStack(num6);
				num5 -= num6;
				if (num5 <= 0)
				{
					break;
				}
			}
		}
	}

	public virtual void OnUpgraded()
	{
		GetIndoors()?.OnParentBuildingUpgraded(this);
		BuildingData data = GetData();
		if (data?.AddMailOnBuild == null)
		{
			return;
		}
		foreach (string item in data.AddMailOnBuild)
		{
			Game1.addMail(item, noLetter: false, sendToEveryone: true);
		}
	}

	public virtual Rectangle getSourceRect()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		BuildingData data = GetData();
		if (data != null)
		{
			Rectangle sourceRect = data.SourceRect;
			if (sourceRect == Rectangle.Empty)
			{
				return texture.Value.Bounds;
			}
			GameLocation gameLocation = GetIndoors();
			if (gameLocation is FarmHouse farmHouse)
			{
				if (gameLocation is Cabin)
				{
					sourceRect.X += sourceRect.Width * Math.Min(farmHouse.upgradeLevel, 2);
				}
				else
				{
					sourceRect.Y += sourceRect.Height * Math.Min(farmHouse.upgradeLevel, 2);
				}
			}
			sourceRect = ApplySourceRectOffsets(sourceRect);
			if (buildingType.Value == "Greenhouse" && GetParentLocation() is Farm farm && !farm.greenhouseUnlocked.Value)
			{
				sourceRect.Y -= sourceRect.Height;
			}
			return sourceRect;
		}
		if (isCabin)
		{
			return new Rectangle(((GetIndoors() is Cabin cabin) ? Math.Min(cabin.upgradeLevel, 2) : 0) * 80, 0, 80, 112);
		}
		return texture.Value.Bounds;
	}

	public virtual Rectangle ApplySourceRectOffsets(Rectangle source)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		BuildingData data = GetData();
		if (data != null && data.SeasonOffset != Point.Zero)
		{
			int seasonIndexForLocation = Game1.GetSeasonIndexForLocation(GetParentLocation());
			source.X += data.SeasonOffset.X * seasonIndexForLocation;
			source.Y += data.SeasonOffset.Y * seasonIndexForLocation;
		}
		return source;
	}

	public virtual Rectangle? getSourceRectForMenu()
	{
		return null;
	}

	public virtual void updateInteriorWarps(GameLocation interior = null)
	{
		interior = interior ?? GetIndoors();
		if (interior == null)
		{
			return;
		}
		GameLocation parentLocation = GetParentLocation();
		foreach (Warp warp in interior.warps)
		{
			if (warp.TargetName == "Farm" || (parentLocation != null && warp.TargetName == parentLocation.NameOrUniqueName))
			{
				warp.TargetName = parentLocation?.NameOrUniqueName ?? warp.TargetName;
				warp.TargetX = humanDoor.X + tileX.Value;
				warp.TargetY = humanDoor.Y + tileY.Value + 1;
			}
		}
	}

	public bool HasIndoors()
	{
		if (indoors.Value == null)
		{
			return nonInstancedIndoorsName.Value != null;
		}
		return true;
	}

	public bool HasIndoorsName(string name)
	{
		if (name != null)
		{
			return GetIndoorsName().EqualsIgnoreCase(name);
		}
		return false;
	}

	public string GetIndoorsName()
	{
		return indoors.Value?.NameOrUniqueName ?? nonInstancedIndoorsName.Value;
	}

	public IndoorsType GetIndoorsType()
	{
		if (indoors.Value != null)
		{
			return IndoorsType.Instanced;
		}
		if (nonInstancedIndoorsName.Value != null)
		{
			return IndoorsType.Global;
		}
		return IndoorsType.None;
	}

	public GameLocation GetIndoors()
	{
		if (indoors.Value != null)
		{
			return indoors.Value;
		}
		if (nonInstancedIndoorsName.Value != null)
		{
			return Game1.getLocationFromName(nonInstancedIndoorsName.Value);
		}
		return null;
	}

	protected virtual GameLocation createIndoors(BuildingData data, string nameOfIndoorsWithoutUnique)
	{
		GameLocation gameLocation = null;
		if (data != null && !string.IsNullOrEmpty(data.IndoorMap))
		{
			Type type = typeof(GameLocation);
			if (data.IndoorMapType != null)
			{
				Exception ex = null;
				try
				{
					type = Type.GetType(data.IndoorMapType);
				}
				catch (Exception ex2)
				{
					ex = ex2;
				}
				if ((object)type == null || ex != null)
				{
					Game1.log.Error($"Error constructing interior type '{data.IndoorMapType}' for building '{buildingType.Value}'" + ((ex != null) ? "." : ": that type doesn't exist."));
					type = typeof(GameLocation);
				}
			}
			string text = "Maps\\" + data.IndoorMap;
			try
			{
				gameLocation = (GameLocation)Activator.CreateInstance(type, text, buildingType.Value);
			}
			catch (Exception)
			{
				try
				{
					gameLocation = (GameLocation)Activator.CreateInstance(type, text);
				}
				catch (Exception exception)
				{
					Game1.log.Error($"Error trying to instantiate indoors for '{buildingType}'", exception);
					gameLocation = new GameLocation("Maps\\" + nameOfIndoorsWithoutUnique, buildingType.Value);
				}
			}
		}
		if (gameLocation != null)
		{
			gameLocation.uniqueName.Value = nameOfIndoorsWithoutUnique + GuidHelper.NewGuid();
			gameLocation.IsFarm = true;
			gameLocation.isStructure.Value = true;
			gameLocation.ParentBuilding = this;
			updateInteriorWarps(gameLocation);
		}
		return gameLocation;
	}

	public virtual Point getPointForHumanDoor()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		return new Point(tileX.Value + humanDoor.Value.X, tileY.Value + humanDoor.Value.Y);
	}

	public virtual Rectangle getRectForHumanDoor()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		return new Rectangle(getPointForHumanDoor().X * 64, getPointForHumanDoor().Y * 64, 64, 64);
	}

	public Rectangle getRectForAnimalDoor()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return getRectForAnimalDoor(GetData());
	}

	public virtual Rectangle getRectForAnimalDoor(BuildingData data)
	{
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		if (data != null)
		{
			Rectangle val = data.AnimalDoor;
			return new Rectangle((val.X + tileX.Value) * 64, (val.Y + tileY.Value) * 64, val.Width * 64, val.Height * 64);
		}
		return new Rectangle((animalDoor.X + tileX.Value) * 64, (tileY.Value + animalDoor.Y) * 64, 64, 64);
	}

	public virtual void load()
	{
		//IL_047d: Unknown result type (might be due to invalid IL or missing references)
		if (!Game1.IsMasterGame)
		{
			return;
		}
		BuildingData data = GetData();
		if (!hasLoaded)
		{
			hasLoaded = true;
			if (data != null)
			{
				if (data.NonInstancedIndoorLocation == null && nonInstancedIndoorsName.Value != null)
				{
					GameLocation gameLocation = GetIndoors();
					if (gameLocation != null)
					{
						gameLocation.parentLocationName.Value = null;
					}
					nonInstancedIndoorsName.Value = null;
				}
				else if (data.NonInstancedIndoorLocation != null)
				{
					bool nonInstancedLocationAlreadyUsed = false;
					Utility.ForEachBuilding(delegate(Building building)
					{
						if (building.HasIndoorsName(data.NonInstancedIndoorLocation))
						{
							nonInstancedLocationAlreadyUsed = true;
							return false;
						}
						return true;
					});
					if (!nonInstancedLocationAlreadyUsed)
					{
						nonInstancedIndoorsName.Value = Game1.RequireLocation(data.NonInstancedIndoorLocation).NameOrUniqueName;
					}
				}
			}
			LoadFromBuildingData(data);
		}
		if (nonInstancedIndoorsName.Value != null)
		{
			UpdateIndoorParent();
		}
		else
		{
			string text = data?.IndoorMap ?? indoors.Value?.Name;
			GameLocation gameLocation2 = createIndoors(data, text);
			if (gameLocation2 != null && indoors.Value != null)
			{
				gameLocation2.characters.Set(indoors.Value.characters);
				gameLocation2.netObjects.MoveFrom(indoors.Value.netObjects);
				gameLocation2.terrainFeatures.MoveFrom(indoors.Value.terrainFeatures);
				gameLocation2.IsFarm = true;
				gameLocation2.IsOutdoors = false;
				gameLocation2.isStructure.Value = true;
				gameLocation2.miniJukeboxCount.Set(indoors.Value.miniJukeboxCount.Value);
				gameLocation2.miniJukeboxTrack.Set(indoors.Value.miniJukeboxTrack.Value);
				gameLocation2.uniqueName.Value = indoors.Value.uniqueName.Value ?? (text + (tileX.Value * 2000 + tileY.Value));
				gameLocation2.numberOfSpawnedObjectsOnMap = indoors.Value.numberOfSpawnedObjectsOnMap;
				gameLocation2.animals.MoveFrom(indoors.Value.animals);
				if (indoors.Value is AnimalHouse animalHouse && gameLocation2 is AnimalHouse animalHouse2)
				{
					animalHouse2.animalsThatLiveHere.Set(animalHouse.animalsThatLiveHere);
				}
				foreach (KeyValuePair<long, FarmAnimal> pair in gameLocation2.animals.Pairs)
				{
					pair.Value.reload(gameLocation2);
				}
				gameLocation2.furniture.Set(indoors.Value.furniture);
				foreach (Furniture item in gameLocation2.furniture)
				{
					item.updateDrawPosition();
				}
				if (indoors.Value is Cabin cabin && gameLocation2 is Cabin cabin2)
				{
					cabin2.fridge.Value = cabin.fridge.Value;
					cabin2.farmhandReference.Value = cabin.farmhandReference.Value;
				}
				gameLocation2.TransferDataFromSavedLocation(indoors.Value);
				indoors.Value = gameLocation2;
			}
			updateInteriorWarps();
			if (indoors.Value != null)
			{
				for (int num = indoors.Value.characters.Count - 1; num >= 0; num--)
				{
					SaveGame.initializeCharacter(indoors.Value.characters[num], indoors.Value);
				}
				foreach (TerrainFeature value in indoors.Value.terrainFeatures.Values)
				{
					value.loadSprite();
				}
				foreach (KeyValuePair<Vector2, Object> pair2 in indoors.Value.objects.Pairs)
				{
					pair2.Value.initializeLightSource(pair2.Key);
					pair2.Value.reloadSprite();
				}
			}
		}
		if (data != null)
		{
			humanDoor.X = data.HumanDoor.X;
			humanDoor.Y = data.HumanDoor.Y;
		}
	}

	public IEnumerable<BuildingPlacementTile> GetAdditionalPlacementTiles()
	{
		IEnumerable<BuildingPlacementTile> enumerable = GetData()?.AdditionalPlacementTiles;
		return enumerable ?? LegacyShims.EmptyArray<BuildingPlacementTile>();
	}

	public bool isUnderConstruction(bool ignoreUpgrades = true)
	{
		if (!ignoreUpgrades && daysUntilUpgrade.Value > 0)
		{
			return true;
		}
		return daysOfConstructionLeft.Value > 0;
	}

	public bool occupiesTile(Vector2 tile, bool applyTilePropertyRadius = false)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return occupiesTile((int)tile.X, (int)tile.Y, applyTilePropertyRadius);
	}

	public virtual bool occupiesTile(int x, int y, bool applyTilePropertyRadius = false)
	{
		int num = (applyTilePropertyRadius ? GetAdditionalTilePropertyRadius() : 0);
		int value = tileX.Value;
		int value2 = tileY.Value;
		int value3 = tilesWide.Value;
		int value4 = tilesHigh.Value;
		if (x >= value - num && x < value + value3 + num && y >= value2 - num)
		{
			return y < value2 + value4 + num;
		}
		return false;
	}

	public virtual bool isTilePassable(Vector2 tile)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		bool flag = occupiesTile(tile);
		if (flag && isUnderConstruction())
		{
			return false;
		}
		BuildingData data = GetData();
		if (data != null && occupiesTile(tile, applyTilePropertyRadius: true))
		{
			return data.IsTilePassable((int)tile.X - tileX.Value, (int)tile.Y - tileY.Value);
		}
		return !flag;
	}

	public virtual bool isTileOccupiedForPlacement(Vector2 tile, Object to_place)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		if (!isTilePassable(tile))
		{
			return true;
		}
		return false;
	}

	public virtual Color? GetWaterColor(Vector2 tile)
	{
		return null;
	}

	public virtual bool isTileFishable(Vector2 tile)
	{
		return false;
	}

	public virtual bool CanRefillWateringCan()
	{
		return false;
	}

	public Rectangle GetBoundingBox()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		return new Rectangle(tileX.Value * 64, tileY.Value * 64, tilesWide.Value * 64, tilesHigh.Value * 64);
	}

	public virtual bool intersects(Rectangle boundingBox)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		Rectangle boundingBox2 = GetBoundingBox();
		int additionalTilePropertyRadius = GetAdditionalTilePropertyRadius();
		if (additionalTilePropertyRadius > 0)
		{
			((Rectangle)(ref boundingBox2)).Inflate(additionalTilePropertyRadius * 64, additionalTilePropertyRadius * 64);
		}
		if (((Rectangle)(ref boundingBox2)).Intersects(boundingBox))
		{
			int i = ((Rectangle)(ref boundingBox)).Top / 64;
			for (int num = ((Rectangle)(ref boundingBox)).Bottom / 64; i <= num; i++)
			{
				int j = ((Rectangle)(ref boundingBox)).Left / 64;
				for (int num2 = ((Rectangle)(ref boundingBox)).Right / 64; j <= num2; j++)
				{
					if (!isTilePassable(new Vector2((float)j, (float)i)))
					{
						return true;
					}
				}
			}
		}
		return false;
	}

	public virtual void drawInMenu(SpriteBatch b, int x, int y)
	{
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		BuildingData data = GetData();
		if (data != null)
		{
			x += (int)(data.DrawOffset.X * 4f);
			y += (int)(data.DrawOffset.Y * 4f);
		}
		float num = tilesHigh.Value * 64;
		float num2 = num;
		if (data != null)
		{
			num2 -= data.SortTileOffset * 64f;
		}
		num2 /= 10000f;
		if (ShouldDrawShadow(data))
		{
			drawShadow(b, x, y);
		}
		Rectangle sourceRect = getSourceRect();
		b.Draw(texture.Value, new Vector2((float)x, (float)y), (Rectangle?)sourceRect, color, 0f, new Vector2(0f, 0f), 4f, (SpriteEffects)0, num2);
		if (data?.DrawLayers == null)
		{
			return;
		}
		foreach (BuildingDrawLayer drawLayer in data.DrawLayers)
		{
			if (drawLayer.OnlyDrawIfChestHasContents == null)
			{
				num2 = num - drawLayer.SortTileOffset * 64f;
				num2 += 1f;
				if (drawLayer.DrawInBackground)
				{
					num2 = 0f;
				}
				num2 /= 10000f;
				Rectangle sourceRect2 = drawLayer.GetSourceRect((int)Game1.currentGameTime.TotalGameTime.TotalMilliseconds);
				sourceRect2 = ApplySourceRectOffsets(sourceRect2);
				Texture2D val = texture.Value;
				if (drawLayer.Texture != null)
				{
					val = Game1.content.Load<Texture2D>(drawLayer.Texture);
				}
				b.Draw(val, new Vector2((float)x, (float)y) + drawLayer.DrawPosition * 4f, (Rectangle?)sourceRect2, Color.White, 0f, new Vector2(0f, 0f), 4f, (SpriteEffects)0, num2);
			}
		}
	}

	public virtual void drawBackground(SpriteBatch b)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		if (isMoving || daysOfConstructionLeft.Value > 0 || newConstructionTimer.Value > 0)
		{
			return;
		}
		BuildingData data = GetData();
		if (data?.DrawLayers == null)
		{
			return;
		}
		Rectangle sourceRect = getSourceRect();
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(0f, (float)sourceRect.Height);
		Vector2 val2 = default(Vector2);
		((Vector2)(ref val2))._002Ector((float)(tileX.Value * 64), (float)(tileY.Value * 64 + tilesHigh.Value * 64));
		foreach (BuildingDrawLayer drawLayer in data.DrawLayers)
		{
			if (!drawLayer.DrawInBackground)
			{
				continue;
			}
			if (drawLayer.OnlyDrawIfChestHasContents != null)
			{
				Chest buildingChest = GetBuildingChest(drawLayer.OnlyDrawIfChestHasContents);
				if (buildingChest == null || buildingChest.isEmpty())
				{
					continue;
				}
			}
			Rectangle sourceRect2 = drawLayer.GetSourceRect((int)Game1.currentGameTime.TotalGameTime.TotalMilliseconds);
			sourceRect2 = ApplySourceRectOffsets(sourceRect2);
			Vector2 zero = Vector2.Zero;
			if (drawLayer.AnimalDoorOffset != Point.Zero)
			{
				((Vector2)(ref zero))._002Ector((float)drawLayer.AnimalDoorOffset.X * animalDoorOpenAmount.Value, (float)drawLayer.AnimalDoorOffset.Y * animalDoorOpenAmount.Value);
			}
			Texture2D val3 = texture.Value;
			if (drawLayer.Texture != null)
			{
				val3 = Game1.content.Load<Texture2D>(drawLayer.Texture);
			}
			b.Draw(val3, Game1.GlobalToLocal(Game1.viewport, val2 + (zero - val + drawLayer.DrawPosition) * 4f), (Rectangle?)sourceRect2, color * alpha, 0f, new Vector2(0f, 0f), 4f, (SpriteEffects)0, 0f);
		}
	}

	public virtual void draw(SpriteBatch b)
	{
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_032d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0375: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03db: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_040e: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0905: Unknown result type (might be due to invalid IL or missing references)
		//IL_090a: Unknown result type (might be due to invalid IL or missing references)
		//IL_091d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0927: Unknown result type (might be due to invalid IL or missing references)
		//IL_0932: Unknown result type (might be due to invalid IL or missing references)
		//IL_093c: Unknown result type (might be due to invalid IL or missing references)
		//IL_089d: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_08bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0580: Unknown result type (might be due to invalid IL or missing references)
		//IL_058c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0591: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0618: Unknown result type (might be due to invalid IL or missing references)
		//IL_061d: Unknown result type (might be due to invalid IL or missing references)
		//IL_062f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0639: Unknown result type (might be due to invalid IL or missing references)
		//IL_0643: Unknown result type (might be due to invalid IL or missing references)
		//IL_0657: Unknown result type (might be due to invalid IL or missing references)
		//IL_0723: Unknown result type (might be due to invalid IL or missing references)
		//IL_0728: Unknown result type (might be due to invalid IL or missing references)
		//IL_072b: Unknown result type (might be due to invalid IL or missing references)
		//IL_072d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0732: Unknown result type (might be due to invalid IL or missing references)
		//IL_0734: Unknown result type (might be due to invalid IL or missing references)
		//IL_0739: Unknown result type (might be due to invalid IL or missing references)
		//IL_073d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0742: Unknown result type (might be due to invalid IL or missing references)
		//IL_0780: Unknown result type (might be due to invalid IL or missing references)
		//IL_0785: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0809: Unknown result type (might be due to invalid IL or missing references)
		if (isMoving)
		{
			return;
		}
		if (daysOfConstructionLeft.Value > 0 || newConstructionTimer.Value > 0)
		{
			drawInConstruction(b);
			return;
		}
		BuildingData data = GetData();
		if (ShouldDrawShadow(data))
		{
			drawShadow(b);
		}
		float num = (tileY.Value + tilesHigh.Value) * 64;
		float num2 = num;
		if (data != null)
		{
			num2 -= data.SortTileOffset * 64f;
		}
		num2 /= 10000f;
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(tileX.Value * 64), (float)(tileY.Value * 64 + tilesHigh.Value * 64));
		Vector2 val2 = Vector2.Zero;
		if (data != null)
		{
			val2 = data.DrawOffset * 4f;
		}
		Rectangle sourceRect = getSourceRect();
		Vector2 val3 = default(Vector2);
		((Vector2)(ref val3))._002Ector(0f, (float)sourceRect.Height);
		b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, val + val2), (Rectangle?)sourceRect, color * alpha, 0f, val3, 4f, (SpriteEffects)0, num2);
		if (magical.Value && buildingType.Value.Equals("Gold Clock"))
		{
			if (Game1.netWorldState.Value.goldenClocksTurnedOff.Value)
			{
				b.Draw(Game1.mouseCursors_1_6, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 68), (float)(tileY.Value * 64 - 56))), (Rectangle?)new Rectangle(498, 368, 13, 9), Color.White * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + 0.0001f);
			}
			else
			{
				b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 92), (float)(tileY.Value * 64 - 40))), (Rectangle?)Town.hourHandSource, Color.White * alpha, (float)(Math.PI * 2.0 * (double)((float)(Game1.timeOfDay % 1200) / 1200f) + (double)((float)Game1.gameTimeInterval / (float)Game1.realMilliSecondsPerGameTenMinutes / 23f)), new Vector2(2.5f, 8f), 3f, (SpriteEffects)0, (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + 0.0001f);
				b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 92), (float)(tileY.Value * 64 - 40))), (Rectangle?)Town.minuteHandSource, Color.White * alpha, (float)(Math.PI * 2.0 * (double)((float)(Game1.timeOfDay % 1000 % 100 % 60) / 60f) + (double)((float)Game1.gameTimeInterval / (float)Game1.realMilliSecondsPerGameTenMinutes * 1.02f)), new Vector2(2.5f, 12f), 3f, (SpriteEffects)0, (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + 0.00011f);
				b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 92), (float)(tileY.Value * 64 - 40))), (Rectangle?)Town.clockNub, Color.White * alpha, 0f, new Vector2(2f, 2f), 4f, (SpriteEffects)0, (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + 0.00012f);
			}
		}
		if (data != null)
		{
			foreach (Chest buildingChest2 in buildingChests)
			{
				BuildingChest buildingChestData = GetBuildingChestData(data, buildingChest2.Name);
				if (buildingChestData.DisplayTile.X != -1f && buildingChestData.DisplayTile.Y != -1f && buildingChest2.Items.Count > 0 && buildingChest2.Items[0] != null)
				{
					num2 = ((float)tileY.Value + buildingChestData.DisplayTile.Y + 1f) * 64f;
					num2 += 1f;
					float num3 = 4f * (float)Math.Round(Math.Sin(Game1.currentGameTime.TotalGameTime.TotalMilliseconds / 250.0), 2) - buildingChestData.DisplayHeight * 64f;
					float num4 = ((float)tileX.Value + buildingChestData.DisplayTile.X) * 64f;
					float num5 = ((float)tileY.Value + buildingChestData.DisplayTile.Y - 1f) * 64f;
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2(num4, num5 + num3)), (Rectangle?)new Rectangle(141, 465, 20, 24), Color.White * 0.75f, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num2 / 10000f);
					ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(buildingChest2.Items[0].QualifiedItemId);
					b.Draw(dataOrErrorItem.GetTexture(), Game1.GlobalToLocal(Game1.viewport, new Vector2(num4 + 32f + 4f, num5 + 32f + num3)), (Rectangle?)dataOrErrorItem.GetSourceRect(), Color.White * 0.75f, 0f, new Vector2(8f, 8f), 4f, (SpriteEffects)0, (num2 + 1f) / 10000f);
				}
			}
			if (data.DrawLayers != null)
			{
				foreach (BuildingDrawLayer drawLayer in data.DrawLayers)
				{
					if (drawLayer.DrawInBackground)
					{
						continue;
					}
					if (drawLayer.OnlyDrawIfChestHasContents != null)
					{
						Chest buildingChest = GetBuildingChest(drawLayer.OnlyDrawIfChestHasContents);
						if (buildingChest == null || buildingChest.isEmpty())
						{
							continue;
						}
					}
					num2 = num - drawLayer.SortTileOffset * 64f;
					num2 += 1f;
					num2 /= 10000f;
					Rectangle sourceRect2 = drawLayer.GetSourceRect((int)Game1.currentGameTime.TotalGameTime.TotalMilliseconds);
					sourceRect2 = ApplySourceRectOffsets(sourceRect2);
					val2 = Vector2.Zero;
					if (drawLayer.AnimalDoorOffset != Point.Zero)
					{
						val2 = new Vector2((float)drawLayer.AnimalDoorOffset.X * animalDoorOpenAmount.Value, (float)drawLayer.AnimalDoorOffset.Y * animalDoorOpenAmount.Value);
					}
					Texture2D val4 = texture.Value;
					if (drawLayer.Texture != null)
					{
						val4 = Game1.content.Load<Texture2D>(drawLayer.Texture);
					}
					b.Draw(val4, Game1.GlobalToLocal(Game1.viewport, val + (val2 - val3 + drawLayer.DrawPosition) * 4f), (Rectangle?)sourceRect2, color * alpha, 0f, new Vector2(0f, 0f), 4f, (SpriteEffects)0, num2);
				}
			}
		}
		if (daysUntilUpgrade.Value <= 0)
		{
			return;
		}
		if (data != null)
		{
			if (data.UpgradeSignTile.X >= 0f)
			{
				num2 = ((float)tileY.Value + data.UpgradeSignTile.Y + 1f) * 64f;
				num2 += 2f;
				num2 /= 10000f;
				b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, getUpgradeSignLocation()), (Rectangle?)new Rectangle(367, 309, 16, 15), Color.White * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num2);
			}
		}
		else if (GetIndoors() is Shed)
		{
			b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, getUpgradeSignLocation()), (Rectangle?)new Rectangle(367, 309, 16, 15), Color.White * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + 0.0001f);
		}
	}

	public bool ShouldDrawShadow(BuildingData data)
	{
		return data?.DrawShadow ?? true;
	}

	public virtual void drawShadow(SpriteBatch b, int localX = -1, int localY = -1)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		Rectangle val = (Rectangle)(((_003F?)getSourceRectForMenu()) ?? getSourceRect());
		Vector2 val2 = (Vector2)((localX == -1) ? Game1.GlobalToLocal(new Vector2((float)(tileX.Value * 64), (float)((tileY.Value + tilesHigh.Value) * 64))) : new Vector2((float)localX, (float)(localY + val.Height * 4)));
		b.Draw(Game1.mouseCursors, val2, (Rectangle?)leftShadow, Color.White * ((localX == -1) ? alpha : 1f), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
		for (int i = 1; i < tilesWide.Value - 1; i++)
		{
			b.Draw(Game1.mouseCursors, val2 + new Vector2((float)(i * 64), 0f), (Rectangle?)middleShadow, Color.White * ((localX == -1) ? alpha : 1f), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
		}
		b.Draw(Game1.mouseCursors, val2 + new Vector2((float)((tilesWide.Value - 1) * 64), 0f), (Rectangle?)rightShadow, Color.White * ((localX == -1) ? alpha : 1f), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
	}

	public virtual void OnStartMove()
	{
	}

	public virtual void OnEndMove()
	{
		Game1.player.team.SendBuildingMovedEvent(GetParentLocation(), this);
	}

	public Point getPorchStandingSpot()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		if (isCabin)
		{
			return new Point(tileX.Value + 1, tileY.Value + tilesHigh.Value - 1);
		}
		return new Point(0, 0);
	}

	public virtual bool doesTileHaveProperty(int tile_x, int tile_y, string property_name, string layer_name, ref string property_value)
	{
		BuildingData data = GetData();
		if (data != null && daysOfConstructionLeft.Value <= 0 && data.HasPropertyAtTile(tile_x - tileX.Value, tile_y - tileY.Value, property_name, layer_name, ref property_value))
		{
			return true;
		}
		if (property_name == "NoSpawn" && layer_name == "Back" && occupiesTile(tile_x, tile_y))
		{
			property_value = "All";
			return true;
		}
		return false;
	}

	public Point getMailboxPosition()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		if (isCabin)
		{
			return new Point(tileX.Value + tilesWide.Value - 1, tileY.Value + tilesHigh.Value - 1);
		}
		return new Point(68, 16);
	}

	public virtual int GetAdditionalTilePropertyRadius()
	{
		return GetData()?.AdditionalTilePropertyRadius ?? 0;
	}

	public void removeOverlappingBushes(GameLocation location)
	{
		for (int i = tileX.Value; i < tileX.Value + tilesWide.Value; i++)
		{
			for (int j = tileY.Value; j < tileY.Value + tilesHigh.Value; j++)
			{
				if (location.isTerrainFeatureAt(i, j))
				{
					LargeTerrainFeature largeTerrainFeatureAt = location.getLargeTerrainFeatureAt(i, j);
					if (largeTerrainFeatureAt is Bush)
					{
						location.largeTerrainFeatures.Remove(largeTerrainFeatureAt);
					}
				}
			}
		}
	}

	public virtual void drawInConstruction(SpriteBatch b)
	{
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_09bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_09df: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_093d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0948: Unknown result type (might be due to invalid IL or missing references)
		//IL_0952: Unknown result type (might be due to invalid IL or missing references)
		//IL_0957: Unknown result type (might be due to invalid IL or missing references)
		//IL_096d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0972: Unknown result type (might be due to invalid IL or missing references)
		//IL_0985: Unknown result type (might be due to invalid IL or missing references)
		//IL_098f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0999: Unknown result type (might be due to invalid IL or missing references)
		//IL_063b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0666: Unknown result type (might be due to invalid IL or missing references)
		//IL_067f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0691: Unknown result type (might be due to invalid IL or missing references)
		//IL_0696: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b0c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b17: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b21: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b26: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a97: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0add: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a18: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c72: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c7d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c9d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ca2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bfd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c12: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c17: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c30: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c43: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c57: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b70: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a2f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a39: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a43: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0706: Unknown result type (might be due to invalid IL or missing references)
		//IL_071d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0731: Unknown result type (might be due to invalid IL or missing references)
		//IL_0423: Unknown result type (might be due to invalid IL or missing references)
		//IL_0428: Unknown result type (might be due to invalid IL or missing references)
		//IL_0451: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0df1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dfb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e11: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e16: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d71: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d8b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dc1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dcb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cd6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b75: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b91: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0777: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0474: Unknown result type (might be due to invalid IL or missing references)
		//IL_047f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0462: Unknown result type (might be due to invalid IL or missing references)
		//IL_046d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1096: Unknown result type (might be due to invalid IL or missing references)
		//IL_10a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_10ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_10b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_10c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_10c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1021: Unknown result type (might be due to invalid IL or missing references)
		//IL_102c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1036: Unknown result type (might be due to invalid IL or missing references)
		//IL_103b: Unknown result type (might be due to invalid IL or missing references)
		//IL_104f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1054: Unknown result type (might be due to invalid IL or missing references)
		//IL_1067: Unknown result type (might be due to invalid IL or missing references)
		//IL_1071: Unknown result type (might be due to invalid IL or missing references)
		//IL_107b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f47: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f52: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f5c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f72: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ed2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0edd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ee7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f05: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f18: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f22: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f2c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e4a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e29: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cdb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ced: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d01: Unknown result type (might be due to invalid IL or missing references)
		//IL_0493: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_0306: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0314: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0323: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_032d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0335: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_11e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_11f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_11fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_1210: Unknown result type (might be due to invalid IL or missing references)
		//IL_1215: Unknown result type (might be due to invalid IL or missing references)
		//IL_1170: Unknown result type (might be due to invalid IL or missing references)
		//IL_117b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1185: Unknown result type (might be due to invalid IL or missing references)
		//IL_118a: Unknown result type (might be due to invalid IL or missing references)
		//IL_119e: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_11b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_11c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_10fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_10d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f8a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e6b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e75: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0802: Unknown result type (might be due to invalid IL or missing references)
		//IL_082d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0837: Unknown result type (might be due to invalid IL or missing references)
		//IL_0842: Unknown result type (might be due to invalid IL or missing references)
		//IL_0859: Unknown result type (might be due to invalid IL or missing references)
		//IL_086d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0515: Unknown result type (might be due to invalid IL or missing references)
		//IL_052e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0540: Unknown result type (might be due to invalid IL or missing references)
		//IL_0545: Unknown result type (might be due to invalid IL or missing references)
		//IL_1326: Unknown result type (might be due to invalid IL or missing references)
		//IL_1331: Unknown result type (might be due to invalid IL or missing references)
		//IL_133b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1340: Unknown result type (might be due to invalid IL or missing references)
		//IL_1351: Unknown result type (might be due to invalid IL or missing references)
		//IL_1356: Unknown result type (might be due to invalid IL or missing references)
		//IL_12b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_12bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_12c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_12cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_12df: Unknown result type (might be due to invalid IL or missing references)
		//IL_12e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_12f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1301: Unknown result type (might be due to invalid IL or missing references)
		//IL_130b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1249: Unknown result type (might be due to invalid IL or missing references)
		//IL_1228: Unknown result type (might be due to invalid IL or missing references)
		//IL_10ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_1111: Unknown result type (might be due to invalid IL or missing references)
		//IL_111b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fb0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fc2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fcc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1523: Unknown result type (might be due to invalid IL or missing references)
		//IL_152e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1538: Unknown result type (might be due to invalid IL or missing references)
		//IL_153d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1551: Unknown result type (might be due to invalid IL or missing references)
		//IL_1556: Unknown result type (might be due to invalid IL or missing references)
		//IL_1569: Unknown result type (might be due to invalid IL or missing references)
		//IL_1573: Unknown result type (might be due to invalid IL or missing references)
		//IL_157d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1467: Unknown result type (might be due to invalid IL or missing references)
		//IL_1472: Unknown result type (might be due to invalid IL or missing references)
		//IL_147c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1481: Unknown result type (might be due to invalid IL or missing references)
		//IL_1492: Unknown result type (might be due to invalid IL or missing references)
		//IL_1497: Unknown result type (might be due to invalid IL or missing references)
		//IL_13f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_13fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_1407: Unknown result type (might be due to invalid IL or missing references)
		//IL_140c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1420: Unknown result type (might be due to invalid IL or missing references)
		//IL_1425: Unknown result type (might be due to invalid IL or missing references)
		//IL_1438: Unknown result type (might be due to invalid IL or missing references)
		//IL_1442: Unknown result type (might be due to invalid IL or missing references)
		//IL_144c: Unknown result type (might be due to invalid IL or missing references)
		//IL_138a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1369: Unknown result type (might be due to invalid IL or missing references)
		//IL_124e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1260: Unknown result type (might be due to invalid IL or missing references)
		//IL_126a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1274: Unknown result type (might be due to invalid IL or missing references)
		//IL_0570: Unknown result type (might be due to invalid IL or missing references)
		//IL_0575: Unknown result type (might be due to invalid IL or missing references)
		//IL_059e: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_14cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_14aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_138f: Unknown result type (might be due to invalid IL or missing references)
		//IL_13a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_13ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_13b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_14d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_14e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_14ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_14f6: Unknown result type (might be due to invalid IL or missing references)
		int num = Math.Min(16, Math.Max(0, (int)(16f - (float)newConstructionTimer.Value / 1000f * 16f)));
		float num2 = (float)(2000 - newConstructionTimer.Value) / 2000f;
		if (magical.Value || daysOfConstructionLeft.Value <= 0)
		{
			BuildingData data = GetData();
			if (ShouldDrawShadow(data))
			{
				drawShadow(b);
			}
			Rectangle sourceRect = getSourceRect();
			Rectangle val = getSourceRectForMenu() ?? sourceRect;
			int num3 = (int)((float)(sourceRect.Height * 4) * (1f - num2));
			float num4 = (tileY.Value + tilesHigh.Value) * 64;
			float num5 = num4;
			if (data != null)
			{
				num5 -= data.SortTileOffset * 64f;
			}
			num5 /= 10000f;
			Vector2 val2 = default(Vector2);
			((Vector2)(ref val2))._002Ector((float)(tileX.Value * 64), (float)(tileY.Value * 64 + tilesHigh.Value * 64));
			Vector2 val3 = Vector2.Zero;
			if (data != null)
			{
				val3 = data.DrawOffset * 4f;
			}
			Vector2 val4 = default(Vector2);
			((Vector2)(ref val4))._002Ector(0f, (float)(num3 + 4 - num3 % 4));
			Vector2 val5 = default(Vector2);
			((Vector2)(ref val5))._002Ector(0f, (float)sourceRect.Height);
			b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, val2 + val4 + val3), (Rectangle?)new Rectangle(((Rectangle)(ref sourceRect)).Left, ((Rectangle)(ref sourceRect)).Bottom - (int)(num2 * (float)sourceRect.Height), val.Width, (int)((float)sourceRect.Height * num2)), color * alpha, 0f, new Vector2(0f, (float)sourceRect.Height), 4f, (SpriteEffects)0, num5);
			if (data?.DrawLayers != null)
			{
				foreach (BuildingDrawLayer drawLayer in data.DrawLayers)
				{
					if (drawLayer.OnlyDrawIfChestHasContents != null)
					{
						continue;
					}
					num5 = num4 - drawLayer.SortTileOffset * 64f;
					num5 += 1f;
					num5 /= 10000f;
					Rectangle sourceRect2 = drawLayer.GetSourceRect((int)Game1.currentGameTime.TotalGameTime.TotalMilliseconds);
					sourceRect2 = ApplySourceRectOffsets(sourceRect2);
					float num6 = (float)(num3 / 4) - drawLayer.DrawPosition.Y;
					val3 = Vector2.Zero;
					if (!(num6 > (float)sourceRect2.Height))
					{
						if (num6 > 0f)
						{
							val3.Y += num6;
							sourceRect2.Y += (int)num6;
							sourceRect2.Height -= (int)num6;
						}
						Texture2D val6 = texture.Value;
						if (drawLayer.Texture != null)
						{
							val6 = Game1.content.Load<Texture2D>(drawLayer.Texture);
						}
						b.Draw(val6, Game1.GlobalToLocal(Game1.viewport, val2 + (val3 - val5 + drawLayer.DrawPosition) * 4f), (Rectangle?)sourceRect2, color * alpha, 0f, new Vector2(0f, 0f), 4f, (SpriteEffects)0, num5);
					}
				}
			}
			if (magical.Value)
			{
				for (int i = 0; i < tilesWide.Value * 4; i++)
				{
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + i * 16), (float)(tileY.Value * 64 - sourceRect.Height * 4 + tilesHigh.Value * 64) + (float)(sourceRect.Height * 4) * (1f - num2))) + new Vector2((float)Game1.random.Next(-1, 2), (float)(Game1.random.Next(-1, 2) - ((i % 2 == 0) ? 32 : 8))), (Rectangle?)new Rectangle(536 + (newConstructionTimer.Value + i * 4) % 56 / 8 * 8, 1945, 8, 8), (i % 2 == 1) ? (Color.Pink * alpha) : (Color.LightPink * alpha), 0f, new Vector2(0f, 0f), 4f + (float)Game1.random.Next(100) / 100f, (SpriteEffects)0, (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + 0.0001f);
					if (i % 2 == 0)
					{
						b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + i * 16), (float)(tileY.Value * 64 - sourceRect.Height * 4 + tilesHigh.Value * 64) + (float)(sourceRect.Height * 4) * (1f - num2))) + new Vector2((float)Game1.random.Next(-1, 2), (float)(Game1.random.Next(-1, 2) + ((i % 2 == 0) ? 32 : 8))), (Rectangle?)new Rectangle(536 + (newConstructionTimer.Value + i * 4) % 56 / 8 * 8, 1945, 8, 8), Color.White * alpha, 0f, new Vector2(0f, 0f), 4f + (float)Game1.random.Next(100) / 100f, (SpriteEffects)0, (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + 0.0001f);
					}
				}
				return;
			}
			for (int j = 0; j < tilesWide.Value * 4; j++)
			{
				b.Draw(Game1.animations, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 - 16 + j * 16), (float)(tileY.Value * 64 - sourceRect.Height * 4 + tilesHigh.Value * 64) + (float)(sourceRect.Height * 4) * (1f - num2))) + new Vector2((float)Game1.random.Next(-1, 2), (float)(Game1.random.Next(-1, 2) - ((j % 2 == 0) ? 32 : 8))), (Rectangle?)new Rectangle((newConstructionTimer.Value + j * 20) % 304 / 38 * 64, 768, 64, 64), Color.White * alpha * ((float)newConstructionTimer.Value / 500f), 0f, new Vector2(0f, 0f), 1f, (SpriteEffects)0, (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + 0.0001f);
				if (j % 2 == 0)
				{
					b.Draw(Game1.animations, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 - 16 + j * 16), (float)(tileY.Value * 64 - sourceRect.Height * 4 + tilesHigh.Value * 64) + (float)(sourceRect.Height * 4) * (1f - num2))) + new Vector2((float)Game1.random.Next(-1, 2), (float)(Game1.random.Next(-1, 2) - ((j % 2 == 0) ? 32 : 8))), (Rectangle?)new Rectangle((newConstructionTimer.Value + j * 20) % 400 / 50 * 64, 2944, 64, 64), Color.White * alpha * ((float)newConstructionTimer.Value / 500f), 0f, new Vector2(0f, 0f), 1f, (SpriteEffects)0, (float)((tileY.Value + tilesHigh.Value) * 64) / 10000f + 0.0001f);
				}
			}
			return;
		}
		bool flag = daysOfConstructionLeft.Value == 1;
		for (int k = tileX.Value; k < tileX.Value + tilesWide.Value; k++)
		{
			for (int l = tileY.Value; l < tileY.Value + tilesHigh.Value; l++)
			{
				if (k == tileX.Value + tilesWide.Value / 2 && l == tileY.Value + tilesHigh.Value - 1)
				{
					if (flag)
					{
						b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4 + 16 - 4)), (Rectangle?)new Rectangle(367, 277, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
					}
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4)) + (Vector2)((newConstructionTimer.Value > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero), (Rectangle?)new Rectangle(367, 309, 16, num), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(l * 64 + 64 - 1) / 10000f);
				}
				else if (k == tileX.Value && l == tileY.Value)
				{
					if (flag)
					{
						b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4 + 16)), (Rectangle?)new Rectangle(351, 261, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
					}
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4)) + (Vector2)((newConstructionTimer.Value > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero), (Rectangle?)new Rectangle(351, 293, 16, num), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(l * 64 + 64 - 1) / 10000f);
				}
				else if (k == tileX.Value + tilesWide.Value - 1 && l == tileY.Value)
				{
					if (flag)
					{
						b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4 + 16)), (Rectangle?)new Rectangle(383, 261, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
					}
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4)) + (Vector2)((newConstructionTimer.Value > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero), (Rectangle?)new Rectangle(383, 293, 16, num), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(l * 64 + 64 - 1) / 10000f);
				}
				else if (k == tileX.Value + tilesWide.Value - 1 && l == tileY.Value + tilesHigh.Value - 1)
				{
					if (flag)
					{
						b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4 + 16)), (Rectangle?)new Rectangle(383, 277, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
					}
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4)) + (Vector2)((newConstructionTimer.Value > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero), (Rectangle?)new Rectangle(383, 325, 16, num), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(l * 64) / 10000f);
				}
				else if (k == tileX.Value && l == tileY.Value + tilesHigh.Value - 1)
				{
					if (flag)
					{
						b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4 + 16)), (Rectangle?)new Rectangle(351, 277, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
					}
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4)) + (Vector2)((newConstructionTimer.Value > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero), (Rectangle?)new Rectangle(351, 325, 16, num), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(l * 64) / 10000f);
				}
				else if (k == tileX.Value + tilesWide.Value - 1)
				{
					if (flag)
					{
						b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4 + 16)), (Rectangle?)new Rectangle(383, 261, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
					}
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4)) + (Vector2)((newConstructionTimer.Value > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero), (Rectangle?)new Rectangle(383, 309, 16, num), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(l * 64) / 10000f);
				}
				else if (l == tileY.Value + tilesHigh.Value - 1)
				{
					if (flag)
					{
						b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4 + 16)), (Rectangle?)new Rectangle(367, 277, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
					}
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4)) + (Vector2)((newConstructionTimer.Value > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero), (Rectangle?)new Rectangle(367, 325, 16, num), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(l * 64) / 10000f);
				}
				else if (k == tileX.Value)
				{
					if (flag)
					{
						b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4 + 16)), (Rectangle?)new Rectangle(351, 261, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
					}
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4)) + (Vector2)((newConstructionTimer.Value > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero), (Rectangle?)new Rectangle(351, 309, 16, num), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(l * 64) / 10000f);
				}
				else if (l == tileY.Value)
				{
					if (flag)
					{
						b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4 + 16)), (Rectangle?)new Rectangle(367, 261, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
					}
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4)) + (Vector2)((newConstructionTimer.Value > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero), (Rectangle?)new Rectangle(367, 293, 16, num), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(l * 64 + 64 - 1) / 10000f);
				}
				else if (flag)
				{
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)k, (float)l) * 64f) + new Vector2(0f, (float)(64 - num * 4 + 16)), (Rectangle?)new Rectangle(367, 261, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
				}
			}
		}
	}
}
