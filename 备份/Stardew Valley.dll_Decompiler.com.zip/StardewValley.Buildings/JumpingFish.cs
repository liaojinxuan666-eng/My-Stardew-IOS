using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.ItemTypeDefinitions;

namespace StardewValley.Buildings;

public class JumpingFish
{
	public Vector2 startPosition;

	public Vector2 endPosition;

	protected float _age;

	public float jumpTime = 1f;

	protected FishPond _pond;

	protected Object _fishObject;

	protected bool _flipped;

	public Vector2 position;

	public float jumpHeight;

	public float angularVelocity;

	public float angle;

	public JumpingFish(FishPond pond, Vector2 start_position, Vector2 end_position)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		angularVelocity = Utility.RandomFloat(20f, 40f) * (float)Math.PI / 180f;
		startPosition = start_position;
		endPosition = end_position;
		position = startPosition;
		_pond = pond;
		_fishObject = pond.GetFishObject();
		if (startPosition.X > endPosition.X)
		{
			_flipped = true;
		}
		jumpHeight = Utility.RandomFloat(75f, 100f);
		Splash();
	}

	public void Splash()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (_pond != null && Game1.currentLocation.buildings.Contains(_pond))
		{
			Game1.playSound("dropItemInWater");
			Game1.currentLocation.TemporarySprites.Add(new TemporaryAnimatedSprite(28, 100f, 2, 1, position + new Vector2(-0.5f, -0.5f) * 64f, flicker: false, flipped: false)
			{
				delayBeforeAnimationStart = 0,
				layerDepth = startPosition.Y / 10000f
			});
		}
	}

	public bool Update(float time)
	{
		_age += time;
		angle += angularVelocity * time;
		if (_age >= jumpTime)
		{
			_age = time;
			Splash();
			return true;
		}
		position.X = Utility.Lerp(startPosition.X, endPosition.X, _age / jumpTime);
		position.Y = Utility.Lerp(startPosition.Y, endPosition.Y, _age / jumpTime);
		return false;
	}

	public void Draw(SpriteBatch b)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		float num = angle;
		SpriteEffects val = (SpriteEffects)0;
		if (_flipped)
		{
			val = (SpriteEffects)1;
			num *= -1f;
		}
		float num2 = 1f;
		Vector2 globalPosition = position + new Vector2(0f, (float)Math.Sin((double)(_age / jumpTime) * Math.PI) * (0f - jumpHeight));
		Vector2 val2 = default(Vector2);
		((Vector2)(ref val2))._002Ector(8f, 8f);
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(_fishObject.QualifiedItemId);
		b.Draw(dataOrErrorItem.GetTexture(), Game1.GlobalToLocal(Game1.viewport, globalPosition), (Rectangle?)dataOrErrorItem.GetSourceRect(), Color.White, num, val2, 4f * num2, val, position.Y / 10000f + 1E-06f);
		b.Draw(Game1.shadowTexture, Game1.GlobalToLocal(Game1.viewport, position), (Rectangle?)Game1.shadowTexture.Bounds, Color.White * 0.5f, 0f, new Vector2((float)(Game1.shadowTexture.Bounds.Width / 2), (float)(Game1.shadowTexture.Bounds.Height / 2)), 2f, val, position.Y / 10000f + 1E-06f);
	}
}
