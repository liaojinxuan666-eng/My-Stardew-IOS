using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Audio;
using StardewValley.Extensions;
using StardewValley.GameData;
using StardewValley.GameData.Buildings;
using StardewValley.GameData.FishPonds;
using StardewValley.Internal;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Menus;
using StardewValley.Network;
using StardewValley.Objects;
using StardewValley.Tools;

namespace StardewValley.Buildings;

public class FishPond : Building
{
	public const int MAXIMUM_OCCUPANCY = 10;

	public static readonly float FISHING_MILLISECONDS = 1000f;

	public static readonly int HARVEST_BASE_EXP = 10;

	public static readonly float HARVEST_OUTPUT_EXP_MULTIPLIER = 0.04f;

	public static readonly int QUEST_BASE_EXP = 20;

	public static readonly float QUEST_SPAWNRATE_EXP_MULTIPIER = 5f;

	public const int NUMBER_OF_NETTING_STYLE_TYPES = 4;

	[XmlArrayItem("int")]
	public readonly NetString fishType = new NetString();

	public readonly NetInt lastUnlockedPopulationGate = new NetInt(0);

	public readonly NetBool hasCompletedRequest = new NetBool(value: false);

	public readonly NetBool goldenAnimalCracker = new NetBool(value: false);

	[XmlIgnore]
	public readonly NetBool isPlayingGoldenCrackerAnimation = new NetBool(value: false);

	public readonly NetRef<Object> sign = new NetRef<Object>();

	public readonly NetColor overrideWaterColor = new NetColor(Color.White);

	public readonly NetRef<Item> output = new NetRef<Item>();

	public readonly NetRef<Item> neededItem = new NetRef<Item>();

	public readonly NetIntDelta neededItemCount = new NetIntDelta(0);

	public readonly NetInt daysSinceSpawn = new NetInt(0);

	public readonly NetInt nettingStyle = new NetInt(0);

	public readonly NetInt seedOffset = new NetInt(0);

	public readonly NetBool hasSpawnedFish = new NetBool(value: false);

	[XmlIgnore]
	public readonly NetMutex needsMutex = new NetMutex();

	[XmlIgnore]
	protected bool _hasAnimatedSpawnedFish;

	[XmlIgnore]
	protected float _delayUntilFishSilhouetteAdded;

	[XmlIgnore]
	protected int _numberOfFishToJump;

	[XmlIgnore]
	protected float _timeUntilFishHop;

	[XmlIgnore]
	protected Object _fishObject;

	[XmlIgnore]
	public List<PondFishSilhouette> _fishSilhouettes = new List<PondFishSilhouette>();

	[XmlIgnore]
	public List<JumpingFish> _jumpingFish = new List<JumpingFish>();

	[XmlIgnore]
	private readonly NetEvent0 animateHappyFishEvent = new NetEvent0();

	[XmlIgnore]
	public TemporaryAnimatedSpriteList animations = new TemporaryAnimatedSpriteList();

	[XmlIgnore]
	protected FishPondData _fishPondData;

	public int FishCount => currentOccupants.Value;

	public FishPond(Vector2 tileLocation)
		: base("Fish Pond", tileLocation)
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		UpdateMaximumOccupancy();
		fadeWhenPlayerIsBehind.Value = false;
		Reseed();
	}

	public FishPond()
		: this(Vector2.Zero)
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(fishType, "fishType").AddField(output, "output").AddField(daysSinceSpawn, "daysSinceSpawn")
			.AddField(lastUnlockedPopulationGate, "lastUnlockedPopulationGate")
			.AddField(animateHappyFishEvent, "animateHappyFishEvent")
			.AddField(hasCompletedRequest, "hasCompletedRequest")
			.AddField(goldenAnimalCracker, "goldenAnimalCracker")
			.AddField(isPlayingGoldenCrackerAnimation, "isPlayingGoldenCrackerAnimation")
			.AddField(neededItem, "neededItem")
			.AddField(seedOffset, "seedOffset")
			.AddField(hasSpawnedFish, "hasSpawnedFish")
			.AddField(needsMutex.NetFields, "needsMutex.NetFields")
			.AddField(neededItemCount, "neededItemCount")
			.AddField(overrideWaterColor, "overrideWaterColor")
			.AddField(sign, "sign")
			.AddField(nettingStyle, "nettingStyle");
		animateHappyFishEvent.onEvent += AnimateHappyFish;
		fishType.fieldChangeVisibleEvent += OnFishTypeChanged;
	}

	public virtual void OnFishTypeChanged(NetString field, string old_value, string new_value)
	{
		_fishSilhouettes.Clear();
		_jumpingFish.Clear();
		_fishObject = null;
	}

	public virtual void Reseed()
	{
		seedOffset.Value = DateTime.UtcNow.Millisecond;
	}

	public List<PondFishSilhouette> GetFishSilhouettes()
	{
		return _fishSilhouettes;
	}

	public void UpdateMaximumOccupancy()
	{
		GetFishPondData();
		if (_fishPondData == null)
		{
			return;
		}
		if (_fishPondData.MaxPopulation > 0)
		{
			maxOccupants.Value = _fishPondData.MaxPopulation;
			return;
		}
		for (int i = 1; i <= 10; i++)
		{
			if (i <= lastUnlockedPopulationGate.Value)
			{
				maxOccupants.Set(i);
				continue;
			}
			if (!(_fishPondData.PopulationGates?.ContainsKey(i) ?? false))
			{
				maxOccupants.Set(i);
				continue;
			}
			break;
		}
	}

	public FishPondData GetFishPondData()
	{
		FishPondData rawData = GetRawData(fishType.Value);
		if (rawData == null)
		{
			return null;
		}
		_fishPondData = rawData;
		if (_fishPondData.SpawnTime == -1)
		{
			int price = GetFishObject().Price;
			if (price <= 30)
			{
				_fishPondData.SpawnTime = 1;
			}
			else if (price <= 80)
			{
				_fishPondData.SpawnTime = 2;
			}
			else if (price <= 120)
			{
				_fishPondData.SpawnTime = 3;
			}
			else if (price <= 250)
			{
				_fishPondData.SpawnTime = 4;
			}
			else
			{
				_fishPondData.SpawnTime = 5;
			}
		}
		return _fishPondData;
	}

	public static FishPondData GetRawData(string itemId)
	{
		if (itemId == null)
		{
			return null;
		}
		HashSet<string> baseContextTags = ItemContextTagManager.GetBaseContextTags(itemId);
		if (baseContextTags.Contains("fish_pond_ignore"))
		{
			return null;
		}
		FishPondData val = null;
		foreach (FishPondData item in DataLoader.FishPondData(Game1.content))
		{
			if (!(val?.Precedence <= item.Precedence) && ItemContextTagManager.DoAllTagsMatch(item.RequiredTags, baseContextTags))
			{
				val = item;
			}
		}
		return val;
	}

	public Item GetFishProduce(Random random = null)
	{
		if (random == null)
		{
			random = Game1.random;
		}
		FishPondData fishPondData = GetFishPondData();
		if (fishPondData == null)
		{
			return null;
		}
		GameLocation parentLocation = GetParentLocation();
		Object fish = GetFishObject();
		FishPondReward selectedOutput = null;
		foreach (FishPondReward producedItem in fishPondData.ProducedItems)
		{
			if (!(selectedOutput?.Precedence <= producedItem.Precedence) && currentOccupants.Value >= producedItem.RequiredPopulation && random.NextBool(producedItem.Chance) && GameStateQuery.CheckConditions(((GenericSpawnItemDataWithCondition)producedItem).Condition, parentLocation, null, null, fish))
			{
				selectedOutput = producedItem;
			}
		}
		Item item = null;
		if (selectedOutput != null)
		{
			item = ItemQueryResolver.TryResolveRandomItem((ISpawnItemData)(object)selectedOutput, new ItemQueryContext(parentLocation, null, null, $"fish pond data '{fishType.Value}' > reward '{((GenericSpawnItemData)selectedOutput).Id}'"), avoidRepeat: false, null, (string id) => (!(ItemRegistry.QualifyItemId(((GenericSpawnItemData)selectedOutput).ItemId) == "(O)812")) ? id : ("FLAVORED_ITEM Roe " + fish.QualifiedItemId), fish);
		}
		if (item != null)
		{
			if (item.Name.Contains("Roe"))
			{
				while (random.NextDouble() < 0.2)
				{
					item.Stack++;
				}
			}
			if (goldenAnimalCracker.Value)
			{
				item.Stack *= 2;
			}
		}
		return item;
	}

	private Item CreateFishInstance()
	{
		return new Object(fishType.Value, 1);
	}

	public override bool doAction(Vector2 tileLocation, Farmer who)
	{
		//IL_04a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if (daysOfConstructionLeft.Value <= 0 && occupiesTile(tileLocation))
		{
			if (who.isMoving())
			{
				Game1.haltAfterCheck = false;
			}
			if (who.ActiveObject != null && performActiveObjectDropInAction(who, probe: false))
			{
				return true;
			}
			if (output.Value != null)
			{
				Item value = output.Value;
				output.Value = null;
				if (who.addItemToInventoryBool(value))
				{
					Game1.playSound("coin");
					int num = 0;
					if (value is Object obj)
					{
						num = (int)((float)obj.sellToStorePrice(-1L) * HARVEST_OUTPUT_EXP_MULTIPLIER);
					}
					who.gainExperience(1, num + HARVEST_BASE_EXP);
				}
				else
				{
					output.Value = value;
					Game1.showRedMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:Crop.cs.588"));
				}
				return true;
			}
			if (who.ActiveObject != null && HasUnresolvedNeeds() && who.ActiveObject.QualifiedItemId == neededItem.Value.QualifiedItemId)
			{
				if (neededItemCount.Value == 1)
				{
					showObjectThrownIntoPondAnimation(who, who.ActiveObject, delegate
					{
						if (neededItemCount.Value <= 0)
						{
							Game1.playSound("jingle1");
						}
					});
				}
				else
				{
					showObjectThrownIntoPondAnimation(who, who.ActiveObject);
				}
				who.reduceActiveItemByOne();
				if (who == Game1.player)
				{
					neededItemCount.Value--;
					if (neededItemCount.Value <= 0)
					{
						needsMutex.RequestLock(delegate
						{
							needsMutex.ReleaseLock();
							ResolveNeeds(who);
						});
						neededItemCount.Value = -1;
					}
				}
				if (neededItemCount.Value <= 0)
				{
					animateHappyFishEvent.Fire();
				}
				return true;
			}
			if (who.ActiveObject != null && (who.ActiveObject.Category == -4 || who.ActiveObject.QualifiedItemId == "(O)393" || who.ActiveObject.QualifiedItemId == "(O)397"))
			{
				if (fishType.Value != null)
				{
					if (!isLegalFishForPonds(fishType.Value))
					{
						string displayName = who.ActiveObject.DisplayName;
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Buildings:CantPutInPonds", displayName.ToLower()));
						return true;
					}
					if (who.ActiveObject.ItemId != fishType.Value)
					{
						string displayName2 = who.ActiveObject.DisplayName;
						if (who.ActiveObject.QualifiedItemId == "(O)393" || who.ActiveObject.QualifiedItemId == "(O)397")
						{
							Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Buildings:WrongFishTypeCoral", displayName2));
						}
						else
						{
							string displayName3 = ItemRegistry.GetDataOrErrorItem(fishType.Value).DisplayName;
							if (Game1.content.GetCurrentLanguage() == LocalizedContentManager.LanguageCode.de)
							{
								Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Buildings:WrongFishType", displayName2, displayName3));
							}
							else
							{
								Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Buildings:WrongFishType", displayName2.ToLower(), displayName3.ToLower()));
							}
						}
						return true;
					}
					if (currentOccupants.Value >= maxOccupants.Value)
					{
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Buildings:PondFull"));
						return true;
					}
					return addFishToPond(who, who.ActiveObject);
				}
				if (!isLegalFishForPonds(who.ActiveObject.ItemId))
				{
					string displayName4 = who.ActiveObject.DisplayName;
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Buildings:CantPutInPonds", displayName4));
					return true;
				}
				return addFishToPond(who, who.ActiveObject);
			}
			if (fishType.Value != null)
			{
				if (Game1.didPlayerJustRightClick(ignoreNonMouseHeldInput: true))
				{
					Game1.playSound("bigSelect");
					Game1.activeClickableMenu = new PondQueryMenu(this);
					return true;
				}
			}
			else if (Game1.didPlayerJustRightClick(ignoreNonMouseHeldInput: true))
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Buildings:NoFish"));
				return true;
			}
		}
		return base.doAction(tileLocation, who);
	}

	public void AnimateHappyFish()
	{
		_numberOfFishToJump = currentOccupants.Value;
		_timeUntilFishHop = 1f;
	}

	public Vector2 GetItemBucketTile()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2((float)(tileX.Value + 4), (float)(tileY.Value + 4));
	}

	public Vector2 GetRequestTile()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2((float)(tileX.Value + 2), (float)(tileY.Value + 2));
	}

	public Vector2 GetCenterTile()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2((float)(tileX.Value + 2), (float)(tileY.Value + 2));
	}

	public void ResolveNeeds(Farmer who)
	{
		Reseed();
		hasCompletedRequest.Value = true;
		lastUnlockedPopulationGate.Value = maxOccupants.Value + 1;
		UpdateMaximumOccupancy();
		daysSinceSpawn.Value = 0;
		int num = 0;
		FishPondData fishPondData = GetFishPondData();
		if (fishPondData != null)
		{
			num = (int)((float)fishPondData.SpawnTime * QUEST_SPAWNRATE_EXP_MULTIPIER);
		}
		who.gainExperience(1, num + QUEST_BASE_EXP);
		Random r = Utility.CreateDaySaveRandom(seedOffset.Value);
		Game1.showGlobalMessage(PondQueryMenu.getCompletedRequestString(this, GetFishObject(), r));
	}

	public override void resetLocalState()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		base.resetLocalState();
		_jumpingFish.Clear();
		while (_fishSilhouettes.Count < currentOccupants.Value)
		{
			PondFishSilhouette pondFishSilhouette = new PondFishSilhouette(this);
			_fishSilhouettes.Add(pondFishSilhouette);
			pondFishSilhouette.position = (GetCenterTile() + new Vector2(Utility.Lerp(-0.5f, 0.5f, (float)Game1.random.NextDouble()) * (float)(tilesWide.Value - 2), Utility.Lerp(-0.5f, 0.5f, (float)Game1.random.NextDouble()) * (float)(tilesHigh.Value - 2))) * 64f;
		}
	}

	private bool isLegalFishForPonds(string itemId)
	{
		return GetRawData(itemId) != null;
	}

	private void showObjectThrownIntoPondAnimation(Farmer who, Object whichObject, Action callback = null)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_049d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_04da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_037d: Unknown result type (might be due to invalid IL or missing references)
		//IL_038a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0628: Unknown result type (might be due to invalid IL or missing references)
		//IL_062d: Unknown result type (might be due to invalid IL or missing references)
		//IL_063a: Unknown result type (might be due to invalid IL or missing references)
		//IL_063f: Unknown result type (might be due to invalid IL or missing references)
		//IL_065c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0666: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0707: Unknown result type (might be due to invalid IL or missing references)
		//IL_0741: Unknown result type (might be due to invalid IL or missing references)
		//IL_074e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0758: Unknown result type (might be due to invalid IL or missing references)
		//IL_077b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0780: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0800: Unknown result type (might be due to invalid IL or missing references)
		//IL_080a: Unknown result type (might be due to invalid IL or missing references)
		//IL_082d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0832: Unknown result type (might be due to invalid IL or missing references)
		//IL_086b: Unknown result type (might be due to invalid IL or missing references)
		who.faceGeneralDirection(GetCenterTile() * 64f + new Vector2(32f, 32f));
		if (who.FacingDirection == 1 || who.FacingDirection == 3)
		{
			float num = Vector2.Distance(who.Position, GetCenterTile() * 64f);
			float num2 = GetCenterTile().Y * 64f + 32f - who.position.Y;
			num -= 8f;
			float num3 = 0.0025f;
			float num4 = (float)((double)num * Math.Sqrt(num3 / (2f * (num + 96f))));
			float num5 = 2f * (num4 / num3) + (float)((Math.Sqrt(num4 * num4 + 2f * num3 * 96f) - (double)num4) / (double)num3);
			num5 += num2;
			float num6 = 0f;
			if (num2 > 0f)
			{
				num6 = num2 / 832f;
				num5 += num6 * 200f;
			}
			Game1.playSound("throwDownITem");
			TemporaryAnimatedSpriteList temporaryAnimatedSpriteList = new TemporaryAnimatedSpriteList();
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(whichObject.QualifiedItemId);
			temporaryAnimatedSpriteList.Add(new TemporaryAnimatedSprite(dataOrErrorItem.GetTextureName(), dataOrErrorItem.GetSourceRect(), who.Position + new Vector2(0f, -64f), flipped: false, 0f, Color.White)
			{
				scale = 4f,
				layerDepth = 1f,
				totalNumberOfLoops = 1,
				interval = num5,
				motion = new Vector2((float)((who.FacingDirection != 3) ? 1 : (-1)) * (num4 - num6), (0f - num4) * 3f / 2f),
				acceleration = new Vector2(0f, num3),
				timeBasedMotion = true
			});
			temporaryAnimatedSpriteList.Add(new TemporaryAnimatedSprite(28, 100f, 2, 1, GetCenterTile() * 64f, flicker: false, flipped: false)
			{
				delayBeforeAnimationStart = (int)num5,
				layerDepth = (((float)tileY.Value + 0.5f) * 64f + 2f) / 10000f
			});
			temporaryAnimatedSpriteList.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 0, 64, 64), 55f, 8, 0, GetCenterTile() * 64f, flicker: false, Game1.random.NextBool(), (((float)tileY.Value + 0.5f) * 64f + 1f) / 10000f, 0.01f, Color.White, 0.75f, 0.003f, 0f, 0f)
			{
				delayBeforeAnimationStart = (int)num5
			});
			temporaryAnimatedSpriteList.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 0, 64, 64), 65f, 8, 0, GetCenterTile() * 64f + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-16, 32)), flicker: false, Game1.random.NextBool(), (((float)tileY.Value + 0.5f) * 64f + 1f) / 10000f, 0.01f, Color.White, 0.75f, 0.003f, 0f, 0f)
			{
				delayBeforeAnimationStart = (int)num5
			});
			temporaryAnimatedSpriteList.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 0, 64, 64), 75f, 8, 0, GetCenterTile() * 64f + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-16, 32)), flicker: false, Game1.random.NextBool(), (((float)tileY.Value + 0.5f) * 64f + 1f) / 10000f, 0.01f, Color.White, 0.75f, 0.003f, 0f, 0f)
			{
				delayBeforeAnimationStart = (int)num5
			});
			if (who.IsLocalPlayer)
			{
				DelayedAction.playSoundAfterDelay("waterSlosh", (int)num5, who.currentLocation);
				if (callback != null)
				{
					DelayedAction.functionAfterDelay(callback, (int)num5);
				}
			}
			if (fishType.Value != null && whichObject.ItemId == fishType.Value)
			{
				_delayUntilFishSilhouetteAdded = num5 / 1000f;
			}
			Game1.multiplayer.broadcastSprites(who.currentLocation, temporaryAnimatedSpriteList);
			return;
		}
		float num7 = Vector2.Distance(who.Position, GetCenterTile() * 64f);
		float num8 = Math.Abs(num7);
		if (who.FacingDirection == 0)
		{
			num7 = 0f - num7;
			num8 += 64f;
		}
		float num9 = GetCenterTile().X * 64f - who.position.X;
		float num10 = 0.0025f;
		float num11 = (float)Math.Sqrt(2f * num10 * num8);
		float num12 = (float)(Math.Sqrt(2f * (num8 - num7) / num10) + (double)(num11 / num10));
		num12 *= 1.05f;
		num12 = ((who.FacingDirection != 0) ? (num12 * 2.5f) : (num12 * 0.7f));
		num12 -= Math.Abs(num9) / ((who.FacingDirection == 0) ? 100f : 2f);
		Game1.playSound("throwDownITem");
		TemporaryAnimatedSpriteList temporaryAnimatedSpriteList2 = new TemporaryAnimatedSpriteList();
		ParsedItemData dataOrErrorItem2 = ItemRegistry.GetDataOrErrorItem(whichObject.QualifiedItemId);
		temporaryAnimatedSpriteList2.Add(new TemporaryAnimatedSprite(dataOrErrorItem2.GetTextureName(), dataOrErrorItem2.GetSourceRect(), who.Position + new Vector2(0f, -64f), flipped: false, 0f, Color.White)
		{
			scale = 4f,
			layerDepth = 1f,
			totalNumberOfLoops = 1,
			interval = num12,
			motion = new Vector2(num9 / ((who.FacingDirection == 0) ? 900f : 1000f), 0f - num11),
			acceleration = new Vector2(0f, num10),
			timeBasedMotion = true
		});
		temporaryAnimatedSpriteList2.Add(new TemporaryAnimatedSprite(28, 100f, 2, 1, GetCenterTile() * 64f, flicker: false, flipped: false)
		{
			delayBeforeAnimationStart = (int)num12,
			layerDepth = (((float)tileY.Value + 0.5f) * 64f + 2f) / 10000f
		});
		temporaryAnimatedSpriteList2.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 0, 64, 64), 55f, 8, 0, GetCenterTile() * 64f, flicker: false, Game1.random.NextBool(), (((float)tileY.Value + 0.5f) * 64f + 1f) / 10000f, 0.01f, Color.White, 0.75f, 0.003f, 0f, 0f)
		{
			delayBeforeAnimationStart = (int)num12
		});
		temporaryAnimatedSpriteList2.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 0, 64, 64), 65f, 8, 0, GetCenterTile() * 64f + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-16, 32)), flicker: false, Game1.random.NextBool(), (((float)tileY.Value + 0.5f) * 64f + 1f) / 10000f, 0.01f, Color.White, 0.75f, 0.003f, 0f, 0f)
		{
			delayBeforeAnimationStart = (int)num12
		});
		temporaryAnimatedSpriteList2.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 0, 64, 64), 75f, 8, 0, GetCenterTile() * 64f + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-16, 32)), flicker: false, Game1.random.NextBool(), (((float)tileY.Value + 0.5f) * 64f + 1f) / 10000f, 0.01f, Color.White, 0.75f, 0.003f, 0f, 0f)
		{
			delayBeforeAnimationStart = (int)num12
		});
		if (who.IsLocalPlayer)
		{
			DelayedAction.playSoundAfterDelay("waterSlosh", (int)num12, who.currentLocation);
			if (callback != null)
			{
				DelayedAction.functionAfterDelay(callback, (int)num12);
			}
		}
		if (fishType.Value != null && whichObject.ItemId == fishType.Value)
		{
			_delayUntilFishSilhouetteAdded = num12 / 1000f;
		}
		Game1.multiplayer.broadcastSprites(who.currentLocation, temporaryAnimatedSpriteList2);
	}

	private bool addFishToPond(Farmer who, Object fish)
	{
		who.reduceActiveItemByOne();
		currentOccupants.Value++;
		if (currentOccupants.Value == 1)
		{
			fishType.Value = fish.ItemId;
			_fishPondData = null;
			UpdateMaximumOccupancy();
		}
		showObjectThrownIntoPondAnimation(who, fish);
		return true;
	}

	public override void dayUpdate(int dayOfMonth)
	{
		hasSpawnedFish.Value = false;
		_hasAnimatedSpawnedFish = false;
		if (hasCompletedRequest.Value)
		{
			neededItem.Value = null;
			neededItemCount.Set(-1);
			hasCompletedRequest.Value = false;
		}
		FishPondData fishPondData = GetFishPondData();
		if (currentOccupants.Value > 0 && fishPondData != null)
		{
			Random random = Utility.CreateDaySaveRandom(tileX.Value * 1000, tileY.Value * 2000);
			if ((fishPondData.BaseMinProduceChance >= fishPondData.BaseMaxProduceChance) ? random.NextBool(fishPondData.BaseMinProduceChance) : (random.NextDouble() < (double)Utility.Lerp(fishPondData.BaseMinProduceChance, fishPondData.BaseMaxProduceChance, (float)currentOccupants.Value / 10f)))
			{
				output.Value = GetFishProduce(random);
			}
			daysSinceSpawn.Value++;
			if (daysSinceSpawn.Value > fishPondData.SpawnTime)
			{
				daysSinceSpawn.Value = fishPondData.SpawnTime;
			}
			if (daysSinceSpawn.Value >= fishPondData.SpawnTime)
			{
				if (TryGetNeededItemData(out var itemId, out var count))
				{
					if (currentOccupants.Value >= maxOccupants.Value && neededItem.Value == null)
					{
						neededItem.Value = ItemRegistry.Create(itemId);
						neededItemCount.Value = count;
					}
				}
				else
				{
					SpawnFish();
				}
			}
			if (currentOccupants.Value == 10 && fishType.Value == "717")
			{
				foreach (Farmer allFarmer in Game1.getAllFarmers())
				{
					if (allFarmer.mailReceived.Add("FullCrabPond"))
					{
						allFarmer.activeDialogueEvents["FullCrabPond"] = 14;
					}
				}
			}
			doFishSpecificWaterColoring();
		}
		base.dayUpdate(dayOfMonth);
	}

	private void doFishSpecificWaterColoring()
	{
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		FishPondData fishPondData = GetFishPondData();
		Color? val = null;
		if (fishPondData != null && fishPondData.WaterColor?.Count > 0)
		{
			foreach (FishPondWaterColor item in fishPondData.WaterColor)
			{
				if (currentOccupants.Value >= item.MinPopulation && lastUnlockedPopulationGate.Value >= item.MinUnlockedPopulationGate && (item.Condition == null || GameStateQuery.CheckConditions(item.Condition, GetParentLocation(), null, null, GetFishObject())))
				{
					if (item.Color.EqualsIgnoreCase("CopyFromInput"))
					{
						Object fishObject = GetFishObject();
						ColoredObject obj = fishObject as ColoredObject;
						val = ((obj != null) ? new Color?(obj.color.Value) : ItemContextTagManager.GetColorFromTags(fishObject));
					}
					else
					{
						val = Utility.StringToColor(item.Color);
					}
					break;
				}
			}
		}
		overrideWaterColor.Value = (Color)(((_003F?)val) ?? Color.White);
	}

	public override Color? GetWaterColor(Vector2 tile)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (!(overrideWaterColor.Value != Color.White))
		{
			return null;
		}
		return overrideWaterColor.Value;
	}

	public bool JumpFish()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (_fishSilhouettes.Count == 0)
		{
			return false;
		}
		PondFishSilhouette pondFishSilhouette = Game1.random.ChooseFrom(_fishSilhouettes);
		_fishSilhouettes.Remove(pondFishSilhouette);
		_jumpingFish.Add(new JumpingFish(this, pondFishSilhouette.position, (GetCenterTile() + new Vector2(0.5f, 0.5f)) * 64f));
		return true;
	}

	public void SpawnFish()
	{
		if (currentOccupants.Value < maxOccupants.Value && currentOccupants.Value > 0)
		{
			hasSpawnedFish.Value = true;
			daysSinceSpawn.Value = 0;
			currentOccupants.Value += 1;
			if (currentOccupants.Value > maxOccupants.Value)
			{
				currentOccupants.Value = maxOccupants.Value;
			}
		}
	}

	public override bool performActiveObjectDropInAction(Farmer who, bool probe)
	{
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		Object activeObject = who.ActiveObject;
		if (IsValidSignItem(activeObject) && (sign.Value == null || activeObject.QualifiedItemId != sign.Value.QualifiedItemId))
		{
			if (probe)
			{
				return true;
			}
			Object value = sign.Value;
			sign.Value = (Object)activeObject.getOne();
			who.reduceActiveItemByOne();
			if (value != null)
			{
				Game1.createItemDebris(value, new Vector2((float)tileX.Value + 0.5f, (float)(tileY.Value + tilesHigh.Value)) * 64f, 3, who.currentLocation);
			}
			who.currentLocation.playSound("axe");
			return true;
		}
		if (activeObject?.QualifiedItemId == "(O)GoldenAnimalCracker" && !goldenAnimalCracker.Value && currentOccupants.Value > 0)
		{
			if (probe)
			{
				return true;
			}
			who.reduceActiveItemByOne();
			goldenAnimalCracker.Value = true;
			isPlayingGoldenCrackerAnimation.Value = true;
			showObjectThrownIntoPondAnimation(who, activeObject, delegate
			{
				isPlayingGoldenCrackerAnimation.Value = false;
			});
			return true;
		}
		return base.performActiveObjectDropInAction(who, probe);
	}

	public override void performToolAction(Tool t, int tileX, int tileY)
	{
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if ((t is Axe || t is Pickaxe) && sign.Value != null)
		{
			if (t.getLastFarmerToUse() != null)
			{
				Game1.createItemDebris(sign.Value, new Vector2((float)base.tileX.Value + 0.5f, (float)(base.tileY.Value + tilesHigh.Value)) * 64f, 3, t.getLastFarmerToUse().currentLocation);
			}
			sign.Value = null;
			t.getLastFarmerToUse().currentLocation.playSound("hammer", (Vector2?)new Vector2((float)tileX, (float)tileY), (int?)null, SoundContext.Default);
		}
		base.performToolAction(t, tileX, tileY);
	}

	public override void performActionOnConstruction(GameLocation location, Farmer who)
	{
		base.performActionOnConstruction(location, who);
		nettingStyle.Value = (tileX.Value / 3 + tileY.Value / 3) % 3;
	}

	public override void performActionOnBuildingPlacement()
	{
		base.performActionOnBuildingPlacement();
		nettingStyle.Value = (tileX.Value / 3 + tileY.Value / 3) % 3;
	}

	public bool HasUnresolvedNeeds()
	{
		if (neededItem.Value != null && TryGetNeededItemData(out var _, out var _))
		{
			return !hasCompletedRequest.Value;
		}
		return false;
	}

	private bool TryGetNeededItemData(out string itemId, out int count)
	{
		itemId = null;
		count = 1;
		if (currentOccupants.Value < maxOccupants.Value)
		{
			return false;
		}
		GetFishPondData();
		if (_fishPondData?.PopulationGates != null)
		{
			if (maxOccupants.Value + 1 <= lastUnlockedPopulationGate.Value)
			{
				return false;
			}
			if (_fishPondData.PopulationGates.TryGetValue(maxOccupants.Value + 1, out var value))
			{
				Random random = Utility.CreateDaySaveRandom(Utility.CreateRandomSeed(tileX.Value * 1000, tileY.Value * 2000));
				string[] array = ArgUtility.SplitBySpace(random.ChooseFrom(value));
				if (array.Length >= 1)
				{
					itemId = array[0];
				}
				if (array.Length >= 3)
				{
					count = random.Next(Convert.ToInt32(array[1]), Convert.ToInt32(array[2]) + 1);
				}
				else if (array.Length >= 2)
				{
					count = Convert.ToInt32(array[1]);
				}
				return true;
			}
		}
		return false;
	}

	public void ClearPond()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		Rectangle boundingBox = GetBoundingBox();
		for (int i = 0; i < currentOccupants.Value; i++)
		{
			Vector2 pixelOrigin = Utility.PointToVector2(((Rectangle)(ref boundingBox)).Center);
			int num = Game1.random.Next(4);
			switch (num)
			{
			case 0:
				((Vector2)(ref pixelOrigin))._002Ector((float)Game1.random.Next(((Rectangle)(ref boundingBox)).Left, ((Rectangle)(ref boundingBox)).Right), (float)((Rectangle)(ref boundingBox)).Top);
				break;
			case 1:
				((Vector2)(ref pixelOrigin))._002Ector((float)((Rectangle)(ref boundingBox)).Right, (float)Game1.random.Next(((Rectangle)(ref boundingBox)).Top, ((Rectangle)(ref boundingBox)).Bottom));
				break;
			case 2:
				((Vector2)(ref pixelOrigin))._002Ector((float)Game1.random.Next(((Rectangle)(ref boundingBox)).Left, ((Rectangle)(ref boundingBox)).Right), (float)((Rectangle)(ref boundingBox)).Bottom);
				break;
			case 3:
				((Vector2)(ref pixelOrigin))._002Ector((float)((Rectangle)(ref boundingBox)).Left, (float)Game1.random.Next(((Rectangle)(ref boundingBox)).Top, ((Rectangle)(ref boundingBox)).Bottom));
				break;
			}
			Game1.createItemDebris(CreateFishInstance(), pixelOrigin, num, Game1.currentLocation, -1, flopFish: true);
		}
		_hasAnimatedSpawnedFish = false;
		hasSpawnedFish.Value = false;
		_fishSilhouettes.Clear();
		_jumpingFish.Clear();
		goldenAnimalCracker.Value = false;
		isPlayingGoldenCrackerAnimation.Value = false;
		_fishObject = null;
		currentOccupants.Value = 0;
		daysSinceSpawn.Value = 0;
		neededItem.Value = null;
		neededItemCount.Value = -1;
		lastUnlockedPopulationGate.Value = 0;
		fishType.Value = null;
		Reseed();
		overrideWaterColor.Value = Color.White;
	}

	public Object CatchFish()
	{
		if (currentOccupants.Value == 0)
		{
			return null;
		}
		currentOccupants.Value--;
		return (Object)CreateFishInstance();
	}

	public Object GetFishObject()
	{
		if (_fishObject == null)
		{
			_fishObject = new Object(fishType.Value, 1);
		}
		return _fishObject;
	}

	public override void Update(GameTime time)
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		needsMutex.Update(GetParentLocation());
		animateHappyFishEvent.Poll();
		if (!_hasAnimatedSpawnedFish && hasSpawnedFish.Value && _numberOfFishToJump <= 0 && Utility.isOnScreen((GetCenterTile() + new Vector2(0.5f, 0.5f)) * 64f, 64))
		{
			_hasAnimatedSpawnedFish = true;
			if (fishType.Value != "393" && fishType.Value != "397")
			{
				_numberOfFishToJump = 1;
				_timeUntilFishHop = Utility.RandomFloat(2f, 5f);
			}
		}
		if (_delayUntilFishSilhouetteAdded > 0f)
		{
			_delayUntilFishSilhouetteAdded -= (float)time.ElapsedGameTime.TotalSeconds;
			if (_delayUntilFishSilhouetteAdded < 0f)
			{
				_delayUntilFishSilhouetteAdded = 0f;
			}
		}
		if (_numberOfFishToJump > 0 && _timeUntilFishHop > 0f)
		{
			_timeUntilFishHop -= (float)time.ElapsedGameTime.TotalSeconds;
			if (_timeUntilFishHop <= 0f && JumpFish())
			{
				_numberOfFishToJump--;
				_timeUntilFishHop = Utility.RandomFloat(0.15f, 0.25f);
			}
		}
		while (_fishSilhouettes.Count > currentOccupants.Value - _jumpingFish.Count)
		{
			_fishSilhouettes.RemoveAt(0);
		}
		if (_delayUntilFishSilhouetteAdded <= 0f)
		{
			while (_fishSilhouettes.Count < currentOccupants.Value - _jumpingFish.Count)
			{
				_fishSilhouettes.Add(new PondFishSilhouette(this));
			}
		}
		for (int i = 0; i < _fishSilhouettes.Count; i++)
		{
			_fishSilhouettes[i].Update((float)time.ElapsedGameTime.TotalSeconds);
		}
		for (int j = 0; j < _jumpingFish.Count; j++)
		{
			if (_jumpingFish[j].Update((float)time.ElapsedGameTime.TotalSeconds))
			{
				PondFishSilhouette pondFishSilhouette = new PondFishSilhouette(this);
				pondFishSilhouette.position = _jumpingFish[j].position;
				_fishSilhouettes.Add(pondFishSilhouette);
				_jumpingFish.RemoveAt(j);
				j--;
			}
		}
		base.Update(time);
	}

	public override bool isTileFishable(Vector2 tile)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		if (daysOfConstructionLeft.Value > 0)
		{
			return false;
		}
		if (tile.X > (float)tileX.Value && tile.X < (float)(tileX.Value + tilesWide.Value - 1) && tile.Y > (float)tileY.Value)
		{
			return tile.Y < (float)(tileY.Value + tilesHigh.Value - 1);
		}
		return false;
	}

	public override bool CanRefillWateringCan()
	{
		return daysOfConstructionLeft.Value <= 0;
	}

	public override Rectangle? getSourceRectForMenu()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		return new Rectangle(0, 0, 80, 80);
	}

	public override void drawInMenu(SpriteBatch b, int x, int y)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0323: Unknown result type (might be due to invalid IL or missing references)
		//IL_0332: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0348: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_037d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0389: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		BuildingData data = GetData();
		y += 32;
		if (ShouldDrawShadow(data))
		{
			drawShadow(b, x, y);
		}
		b.Draw(texture.Value, new Vector2((float)x, (float)y), (Rectangle?)new Rectangle(0, 80, 80, 80), new Color(60, 126, 150) * alpha, 0f, new Vector2(0f, 0f), 4f, (SpriteEffects)0, 0.75f);
		for (int i = tileY.Value; i < tileY.Value + 5; i++)
		{
			for (int j = tileX.Value; j < tileX.Value + 4; j++)
			{
				bool num = i == tileY.Value + 4;
				bool flag = i == tileY.Value;
				if (num)
				{
					b.Draw(Game1.mouseCursors, new Vector2((float)(x + j * 64 + 32), (float)(y + (i + 1) * 64 - (int)Game1.currentLocation.waterPosition - 32)), (Rectangle?)new Rectangle(Game1.currentLocation.waterAnimationIndex * 64, 2064 + (((j + i) % 2 != 0) ? ((!Game1.currentLocation.waterTileFlip) ? 128 : 0) : (Game1.currentLocation.waterTileFlip ? 128 : 0)), 64, 32 + (int)Game1.currentLocation.waterPosition - 5), Game1.currentLocation.waterColor.Value, 0f, Vector2.Zero, 1f, (SpriteEffects)0, 0.8f);
				}
				else
				{
					b.Draw(Game1.mouseCursors, new Vector2((float)(x + j * 64 + 32), (float)(y + i * 64 + 32 - (int)((!flag) ? Game1.currentLocation.waterPosition : 0f))), (Rectangle?)new Rectangle(Game1.currentLocation.waterAnimationIndex * 64, 2064 + (((j + i) % 2 != 0) ? ((!Game1.currentLocation.waterTileFlip) ? 128 : 0) : (Game1.currentLocation.waterTileFlip ? 128 : 0)) + (flag ? ((int)Game1.currentLocation.waterPosition) : 0), 64, 64 + (flag ? ((int)(0f - Game1.currentLocation.waterPosition)) : 0)), Game1.currentLocation.waterColor.Value, 0f, Vector2.Zero, 1f, (SpriteEffects)0, 0.8f);
				}
			}
		}
		b.Draw(texture.Value, new Vector2((float)x, (float)y), (Rectangle?)new Rectangle(0, 0, 80, 80), color * alpha, 0f, new Vector2(0f, 0f), 4f, (SpriteEffects)0, 0.9f);
		b.Draw(texture.Value, new Vector2((float)(x + 64), (float)(y + 44 + ((Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 2500.0 < 1250.0) ? 4 : 0))), (Rectangle?)new Rectangle(16, 160, 48, 7), color * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.95f);
		b.Draw(texture.Value, new Vector2((float)x, (float)(y - 128)), (Rectangle?)new Rectangle(80, 0, 80, 48), color * alpha, 0f, new Vector2(0f, 0f), 4f, (SpriteEffects)0, 1f);
	}

	public override void OnEndMove()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		foreach (PondFishSilhouette fishSilhouette in _fishSilhouettes)
		{
			fishSilhouette.position = (GetCenterTile() + new Vector2(Utility.Lerp(-0.5f, 0.5f, (float)Game1.random.NextDouble()) * (float)(tilesWide.Value - 2), Utility.Lerp(-0.5f, 0.5f, (float)Game1.random.NextDouble()) * (float)(tilesHigh.Value - 2))) * 64f;
		}
	}

	public override void draw(SpriteBatch b)
	{
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0403: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_051a: Unknown result type (might be due to invalid IL or missing references)
		//IL_051f: Unknown result type (might be due to invalid IL or missing references)
		//IL_052a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0535: Unknown result type (might be due to invalid IL or missing references)
		//IL_0540: Unknown result type (might be due to invalid IL or missing references)
		//IL_0554: Unknown result type (might be due to invalid IL or missing references)
		//IL_041e: Unknown result type (might be due to invalid IL or missing references)
		//IL_059f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0600: Unknown result type (might be due to invalid IL or missing references)
		//IL_060b: Unknown result type (might be due to invalid IL or missing references)
		//IL_061f: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0682: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0474: Unknown result type (might be due to invalid IL or missing references)
		//IL_0479: Unknown result type (might be due to invalid IL or missing references)
		//IL_0488: Unknown result type (might be due to invalid IL or missing references)
		//IL_0493: Unknown result type (might be due to invalid IL or missing references)
		//IL_049e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0769: Unknown result type (might be due to invalid IL or missing references)
		//IL_076e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_078f: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07de: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0804: Unknown result type (might be due to invalid IL or missing references)
		//IL_083b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0880: Unknown result type (might be due to invalid IL or missing references)
		//IL_0885: Unknown result type (might be due to invalid IL or missing references)
		//IL_088a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0892: Unknown result type (might be due to invalid IL or missing references)
		//IL_089d: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d06: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d10: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d15: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d48: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d83: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d95: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dbd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aeb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b20: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b25: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b2f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b45: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bb6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bbb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bfa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c02: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c17: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c21: Unknown result type (might be due to invalid IL or missing references)
		//IL_0946: Unknown result type (might be due to invalid IL or missing references)
		//IL_094b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0979: Unknown result type (might be due to invalid IL or missing references)
		//IL_0984: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		//IL_0358: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e23: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e32: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e41: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e46: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e64: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e6f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e79: Unknown result type (might be due to invalid IL or missing references)
		//IL_0385: Unknown result type (might be due to invalid IL or missing references)
		//IL_036a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0efb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f05: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f0a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f0f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f29: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f34: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f3e: Unknown result type (might be due to invalid IL or missing references)
		//IL_038f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1032: Unknown result type (might be due to invalid IL or missing references)
		//IL_103c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1072: Unknown result type (might be due to invalid IL or missing references)
		//IL_107d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1087: Unknown result type (might be due to invalid IL or missing references)
		//IL_108c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1098: Unknown result type (might be due to invalid IL or missing references)
		//IL_109d: Unknown result type (might be due to invalid IL or missing references)
		//IL_10a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_10b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_10ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_10f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_10f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1108: Unknown result type (might be due to invalid IL or missing references)
		//IL_1112: Unknown result type (might be due to invalid IL or missing references)
		//IL_111c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1126: Unknown result type (might be due to invalid IL or missing references)
		//IL_115b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1160: Unknown result type (might be due to invalid IL or missing references)
		//IL_1162: Unknown result type (might be due to invalid IL or missing references)
		//IL_1164: Unknown result type (might be due to invalid IL or missing references)
		//IL_1169: Unknown result type (might be due to invalid IL or missing references)
		//IL_117b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1185: Unknown result type (might be due to invalid IL or missing references)
		//IL_118f: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f84: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fa7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fb6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fc0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fc5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fdd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fe8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ffd: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_11f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_11f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_11fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_1201: Unknown result type (might be due to invalid IL or missing references)
		//IL_1206: Unknown result type (might be due to invalid IL or missing references)
		//IL_120b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1219: Unknown result type (might be due to invalid IL or missing references)
		//IL_1223: Unknown result type (might be due to invalid IL or missing references)
		//IL_1237: Unknown result type (might be due to invalid IL or missing references)
		//IL_1273: Unknown result type (might be due to invalid IL or missing references)
		//IL_1278: Unknown result type (might be due to invalid IL or missing references)
		//IL_127a: Unknown result type (might be due to invalid IL or missing references)
		//IL_127c: Unknown result type (might be due to invalid IL or missing references)
		//IL_128b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1290: Unknown result type (might be due to invalid IL or missing references)
		//IL_1295: Unknown result type (might be due to invalid IL or missing references)
		//IL_12a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_12b2: Unknown result type (might be due to invalid IL or missing references)
		if (base.isMoving)
		{
			return;
		}
		if (daysOfConstructionLeft.Value > 0)
		{
			drawInConstruction(b);
			return;
		}
		BuildingData data = GetData();
		for (int num = animations.Count - 1; num >= 0; num--)
		{
			animations[num].draw(b);
		}
		if (ShouldDrawShadow(data))
		{
			drawShadow(b);
		}
		b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64), (float)(tileY.Value * 64 + tilesHigh.Value * 64))), (Rectangle?)new Rectangle(0, 80, 80, 80), (Color)((overrideWaterColor.Value == Color.White) ? new Color(60, 126, 150) : overrideWaterColor.Value) * alpha, 0f, new Vector2(0f, 80f), 4f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f - 3f) / 10000f);
		for (int i = tileY.Value; i < tileY.Value + 5; i++)
		{
			for (int j = tileX.Value; j < tileX.Value + 4; j++)
			{
				bool num2 = i == tileY.Value + 4;
				bool flag = i == tileY.Value;
				if (num2)
				{
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(j * 64 + 32), (float)((i + 1) * 64 - (int)Game1.currentLocation.waterPosition - 32))), (Rectangle?)new Rectangle(Game1.currentLocation.waterAnimationIndex * 64, 2064 + (((j + i) % 2 != 0) ? ((!Game1.currentLocation.waterTileFlip) ? 128 : 0) : (Game1.currentLocation.waterTileFlip ? 128 : 0)), 64, 32 + (int)Game1.currentLocation.waterPosition - 5), overrideWaterColor.Equals(Color.White) ? Game1.currentLocation.waterColor.Value : (overrideWaterColor.Value * 0.5f), 0f, Vector2.Zero, 1f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f - 2f) / 10000f);
				}
				else
				{
					b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(j * 64 + 32), (float)(i * 64 + 32 - (int)((!flag) ? Game1.currentLocation.waterPosition : 0f)))), (Rectangle?)new Rectangle(Game1.currentLocation.waterAnimationIndex * 64, 2064 + (((j + i) % 2 != 0) ? ((!Game1.currentLocation.waterTileFlip) ? 128 : 0) : (Game1.currentLocation.waterTileFlip ? 128 : 0)) + (flag ? ((int)Game1.currentLocation.waterPosition) : 0), 64, 64 + (flag ? ((int)(0f - Game1.currentLocation.waterPosition)) : 0)), (overrideWaterColor.Value == Color.White) ? Game1.currentLocation.waterColor.Value : (overrideWaterColor.Value * 0.5f), 0f, Vector2.Zero, 1f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f - 2f) / 10000f);
				}
			}
		}
		Color value = overrideWaterColor.Value;
		if (((Color)(ref value)).Equals(Color.White))
		{
			b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 64), (float)(tileY.Value * 64 + 44 + ((Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 2500.0 < 1250.0) ? 4 : 0)))), (Rectangle?)new Rectangle(16, 160, 48, 7), color * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f + 1f) / 10000f);
		}
		b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64), (float)(tileY.Value * 64 + tilesHigh.Value * 64))), (Rectangle?)new Rectangle(0, 0, 80, 80), color * alpha, 0f, new Vector2(0f, 80f), 4f, (SpriteEffects)0, ((float)tileY.Value + 0.5f) * 64f / 10000f);
		if (nettingStyle.Value < 3)
		{
			b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64), (float)(tileY.Value * 64 + tilesHigh.Value * 64 - 128))), (Rectangle?)new Rectangle(80, nettingStyle.Value * 48, 80, 48), color * alpha, 0f, new Vector2(0f, 80f), 4f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f + 2f) / 10000f);
		}
		if (sign.Value != null)
		{
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(sign.Value.QualifiedItemId);
			b.Draw(dataOrErrorItem.GetTexture(), Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 8), (float)(tileY.Value * 64 + tilesHigh.Value * 64 - 128 - 32))), (Rectangle?)dataOrErrorItem.GetSourceRect(), color * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f + 2f) / 10000f);
			if (fishType.Value != null)
			{
				ParsedItemData data2 = ItemRegistry.GetData(fishType.Value);
				if (data2 != null)
				{
					Texture2D val = data2.GetTexture();
					Rectangle sourceRect = data2.GetSourceRect();
					float num3 = ((maxOccupants.Value == 1) ? 6f : 0f);
					b.Draw(val, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 8 + 8 - 4), (float)(tileY.Value * 64 + tilesHigh.Value * 64 - 128 - 8 + 4) + num3)), (Rectangle?)sourceRect, Color.Black * 0.4f * alpha, 0f, Vector2.Zero, 3f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f + 3f) / 10000f);
					b.Draw(val, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 8 + 8 - 1), (float)(tileY.Value * 64 + tilesHigh.Value * 64 - 128 - 8 + 1) + num3)), (Rectangle?)sourceRect, color * alpha, 0f, Vector2.Zero, 3f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f + 4f) / 10000f);
					if (maxOccupants.Value > 1)
					{
						Utility.drawTinyDigits(currentOccupants.Value, b, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 32 + 8 + ((currentOccupants.Value < 10) ? 8 : 0)), (float)(tileY.Value * 64 + tilesHigh.Value * 64 - 96))), 3f, (((float)tileY.Value + 0.5f) * 64f + 5f) / 10000f, Color.LightYellow * alpha);
					}
				}
			}
		}
		if (_fishObject != null && (_fishObject.QualifiedItemId == "(O)393" || _fishObject.QualifiedItemId == "(O)397"))
		{
			for (int k = 0; k < currentOccupants.Value; k++)
			{
				Vector2 zero = Vector2.Zero;
				int num4 = (k + seedOffset.Value) % 10;
				switch (num4)
				{
				case 0:
					((Vector2)(ref zero))._002Ector(0f, 0f);
					break;
				case 1:
					((Vector2)(ref zero))._002Ector(48f, 32f);
					break;
				case 2:
					((Vector2)(ref zero))._002Ector(80f, 72f);
					break;
				case 3:
					((Vector2)(ref zero))._002Ector(140f, 28f);
					break;
				case 4:
					((Vector2)(ref zero))._002Ector(96f, 0f);
					break;
				case 5:
					((Vector2)(ref zero))._002Ector(0f, 96f);
					break;
				case 6:
					((Vector2)(ref zero))._002Ector(140f, 80f);
					break;
				case 7:
					((Vector2)(ref zero))._002Ector(64f, 120f);
					break;
				case 8:
					((Vector2)(ref zero))._002Ector(140f, 140f);
					break;
				case 9:
					((Vector2)(ref zero))._002Ector(0f, 150f);
					break;
				}
				b.Draw(Game1.shadowTexture, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 64 + 7), (float)(tileY.Value * 64 + 64 + 32)) + zero), (Rectangle?)Game1.shadowTexture.Bounds, color * alpha, 0f, Vector2.Zero, 3f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f - 2f) / 10000f - 1.1E-05f);
				ParsedItemData dataOrErrorItem2 = ItemRegistry.GetDataOrErrorItem("(O)" + fishType.Value);
				Texture2D val2 = dataOrErrorItem2.GetTexture();
				Rectangle sourceRect2 = dataOrErrorItem2.GetSourceRect();
				b.Draw(val2, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64 + 64), (float)(tileY.Value * 64 + 64)) + zero), (Rectangle?)sourceRect2, color * alpha * 0.75f, 0f, Vector2.Zero, 3f, (SpriteEffects)(num4 % 3 == 0), (((float)tileY.Value + 0.5f) * 64f - 2f) / 10000f - 1E-05f);
			}
		}
		else
		{
			for (int l = 0; l < _fishSilhouettes.Count; l++)
			{
				_fishSilhouettes[l].Draw(b);
			}
		}
		for (int m = 0; m < _jumpingFish.Count; m++)
		{
			_jumpingFish[m].Draw(b);
		}
		if (HasUnresolvedNeeds())
		{
			Vector2 val3 = GetRequestTile() * 64f;
			val3 += 64f * new Vector2(0.5f, 0.5f);
			float num5 = 3f * (float)Math.Round(Math.Sin(Game1.currentGameTime.TotalGameTime.TotalMilliseconds / 250.0), 2);
			float num6 = (val3.Y + 160f) / 10000f + 1E-06f;
			val3.Y += num5 - 32f;
			b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, val3), (Rectangle?)new Rectangle(403, 496, 5, 14), Color.White * 0.75f, 0f, new Vector2(2f, 14f), 4f, (SpriteEffects)0, num6);
		}
		bool flag2 = goldenAnimalCracker.Value && !isPlayingGoldenCrackerAnimation.Value;
		if (flag2)
		{
			b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64), (float)(tileY.Value * 64)) + new Vector2(65f, 59f) * 4f), (Rectangle?)new Rectangle(130, 160, 15, 16), color * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f + 2f) / 10000f);
		}
		if (output.Value != null)
		{
			b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64), (float)(tileY.Value * 64)) + new Vector2(65f, 59f) * 4f), (Rectangle?)new Rectangle(0, 160, 15, 16), color * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f + 1f) / 10000f);
			if (flag2)
			{
				b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value * 64), (float)(tileY.Value * 64)) + new Vector2(65f, 59f) * 4f), (Rectangle?)new Rectangle(145, 160, 15, 16), color * alpha, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (((float)tileY.Value + 0.5f) * 64f + 3f) / 10000f);
			}
			Vector2 val4 = GetItemBucketTile() * 64f;
			float num7 = 4f * (float)Math.Round(Math.Sin(Game1.currentGameTime.TotalGameTime.TotalMilliseconds / 250.0), 2);
			Vector2 val5 = val4 + new Vector2(0f, -2f) * 64f + new Vector2(0f, num7);
			Vector2 val6 = default(Vector2);
			((Vector2)(ref val6))._002Ector(40f, 36f);
			float num8 = (val4.Y + 64f) / 10000f + 1E-06f;
			float num9 = (val4.Y + 64f) / 10000f + 1E-05f;
			b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, val5), (Rectangle?)new Rectangle(141, 465, 20, 24), Color.White * 0.75f, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num8);
			ParsedItemData dataOrErrorItem3 = ItemRegistry.GetDataOrErrorItem(output.Value.QualifiedItemId);
			Texture2D val7 = dataOrErrorItem3.GetTexture();
			b.Draw(val7, Game1.GlobalToLocal(Game1.viewport, val5 + val6), (Rectangle?)dataOrErrorItem3.GetSourceRect(), Color.White * 0.75f, 0f, new Vector2(8f, 8f), 4f, (SpriteEffects)0, num9);
			if (output.Value is ColoredObject coloredObject)
			{
				Rectangle sourceRect3 = ItemRegistry.GetDataOrErrorItem(output.Value.QualifiedItemId).GetSourceRect(1);
				b.Draw(val7, Game1.GlobalToLocal(Game1.viewport, val5 + val6), (Rectangle?)sourceRect3, coloredObject.color.Value * 0.75f, 0f, new Vector2(8f, 8f), 4f, (SpriteEffects)0, num9 + 1E-05f);
			}
			if (output.Value.Stack > 1)
			{
				Utility.drawTinyDigits(output.Value.Stack, b, Game1.GlobalToLocal(Game1.viewport, val5 + val6 + new Vector2(16f, 12f)), 3f, num9 + 2E-05f, Color.LightYellow * alpha);
			}
		}
	}

	public bool IsValidSignItem(Item item)
	{
		if (item == null)
		{
			return false;
		}
		if (!item.HasContextTag("sign_item"))
		{
			return item.QualifiedItemId == "(BC)34";
		}
		return true;
	}
}
