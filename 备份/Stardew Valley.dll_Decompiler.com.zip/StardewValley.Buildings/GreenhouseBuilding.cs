using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Extensions;
using xTile;
using xTile.Dimensions;
using xTile.Layers;
using xTile.Tiles;

namespace StardewValley.Buildings;

public class GreenhouseBuilding : Building
{
	protected Farm _farm;

	public GreenhouseBuilding(Vector2 tileLocation)
		: base("Greenhouse", tileLocation)
	{
	}//IL_0006: Unknown result type (might be due to invalid IL or missing references)


	public GreenhouseBuilding()
		: this(Vector2.Zero)
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public override void drawBackground(SpriteBatch b)
	{
		base.drawBackground(b);
		if (!base.isMoving)
		{
			DrawEntranceTiles(b);
			drawShadow(b);
		}
	}

	public Farm GetFarm()
	{
		if (_farm == null)
		{
			_farm = Game1.getFarm();
		}
		return _farm;
	}

	public override bool OnUseHumanDoor(Farmer who)
	{
		if (Game1.MasterPlayer.mailReceived.Contains("ccPantry"))
		{
			return true;
		}
		Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Farm_GreenhouseRuins"));
		return false;
	}

	public override string isThereAnythingtoPreventConstruction(GameLocation location, Vector2 tile_position)
	{
		return null;
	}

	public override bool doesTileHaveProperty(int tile_x, int tile_y, string property_name, string layer_name, ref string property_value)
	{
		if (base.isMoving)
		{
			return false;
		}
		if (layer_name == "Back" && ((tile_x >= tileX.Value - 1 && tile_x <= tileX.Value + tilesWide.Value - 1 && tile_y <= tileY.Value + tilesHigh.Value && tile_y >= tileY.Value) || (CanDrawEntranceTiles() && tile_x >= tileX.Value + 1 && tile_x <= tileX.Value + tilesWide.Value - 2 && tile_y == tileY.Value + tilesHigh.Value + 1)))
		{
			if (CanDrawEntranceTiles() && tile_x >= tileX.Value + humanDoor.X - 1 && tile_x <= tileX.Value + humanDoor.X + 1 && tile_y <= tileY.Value + tilesHigh.Value + 1 && tile_y >= tileY.Value + humanDoor.Y + 1)
			{
				switch (property_name)
				{
				case "Type":
					property_value = "Stone";
					return true;
				case "NoSpawn":
					property_value = "All";
					return true;
				case "Buildable":
					property_value = null;
					return true;
				}
			}
			switch (property_name)
			{
			case "Buildable":
				property_value = "T";
				return true;
			case "NoSpawn":
				property_value = "Tree";
				return true;
			case "Diggable":
				property_value = null;
				return true;
			}
		}
		return base.doesTileHaveProperty(tile_x, tile_y, property_name, layer_name, ref property_value);
	}

	public virtual bool CanDrawEntranceTiles()
	{
		return true;
	}

	public virtual void DrawEntranceTiles(SpriteBatch b)
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Expected O, but got Unknown
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Expected O, but got Unknown
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		Map map = GetFarm().Map;
		Layer val = map.RequireLayer("Back");
		TileSheet val2 = map.GetTileSheet("untitled tile sheet");
		if (val2 == null)
		{
			val2 = map.TileSheets[Math.Min(1, map.TileSheets.Count - 1)];
		}
		if (val2 != null)
		{
			StaticTile val3 = new StaticTile(val, val2, (BlendMode)0, 812);
			if (CanDrawEntranceTiles())
			{
				float num = 0f;
				Vector2 val4 = Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value + humanDoor.Value.X - 1), (float)(tileY.Value + humanDoor.Value.Y + 1)) * 64f);
				Location val5 = default(Location);
				((Location)(ref val5))._002Ector((int)val4.X, (int)val4.Y);
				Game1.mapDisplayDevice.DrawTile((Tile)(object)val3, val5, num);
				val5.X += 64;
				Game1.mapDisplayDevice.DrawTile((Tile)(object)val3, val5, num);
				val5.X += 64;
				Game1.mapDisplayDevice.DrawTile((Tile)(object)val3, val5, num);
				val3 = new StaticTile(val, val2, (BlendMode)0, 838);
				val4 = Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(tileX.Value + humanDoor.Value.X - 1), (float)(tileY.Value + humanDoor.Value.Y + 2)) * 64f);
				val5.X = (int)val4.X;
				val5.Y = (int)val4.Y;
				Game1.mapDisplayDevice.DrawTile((Tile)(object)val3, val5, num);
				val5.X += 64;
				Game1.mapDisplayDevice.DrawTile((Tile)(object)val3, val5, num);
				val5.X += 64;
				Game1.mapDisplayDevice.DrawTile((Tile)(object)val3, val5, num);
			}
		}
	}

	public override void drawShadow(SpriteBatch b, int localX = -1, int localY = -1)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		Rectangle value = default(Rectangle);
		((Rectangle)(ref value))._002Ector(112, 0, 128, 144);
		if (CanDrawEntranceTiles())
		{
			value.Y = 144;
		}
		b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)((tileX.Value - 1) * 64), (float)(tileY.Value * 64))), (Rectangle?)value, Color.White * ((localX == -1) ? alpha : 1f), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0f);
	}
}
