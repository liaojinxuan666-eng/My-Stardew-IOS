using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.BellsAndWhistles;
using StardewValley.Characters;
using StardewValley.GameData.Buildings;
using StardewValley.Tools;

namespace StardewValley.Buildings;

public class PetBowl : Building
{
	[XmlElement("watered")]
	public readonly NetBool watered = new NetBool();

	private int nameTimer;

	private string nameTimerMessage;

	[XmlElement("petGuid")]
	public readonly NetGuid petId = new NetGuid();

	public PetBowl(Vector2 tileLocation)
		: base("Pet Bowl", tileLocation)
	{
	}//IL_001c: Unknown result type (might be due to invalid IL or missing references)


	public PetBowl()
		: this(Vector2.Zero)
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public virtual void AssignPet(Pet pet)
	{
		petId.Value = pet.petId.Value;
		pet.homeLocationName.Value = parentLocationName.Value;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(watered, "watered").AddField(petId, "petId");
	}

	public virtual Point GetPetSpot()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		return new Point(tileX.Value, tileY.Value + 1);
	}

	public override bool doAction(Vector2 tileLocation, Farmer who)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		if (!isTilePassable(tileLocation))
		{
			_ = petId.Value;
			Pet pet = Utility.findPet(petId.Value);
			if (pet != null)
			{
				nameTimer = 3500;
				nameTimerMessage = Game1.content.LoadString("Strings\\1_6_Strings:PetBowlName", pet.displayName);
			}
		}
		return base.doAction(tileLocation, who);
	}

	public override void Update(GameTime time)
	{
		if (nameTimer > 0)
		{
			nameTimer -= (int)time.ElapsedGameTime.TotalMilliseconds;
		}
		base.Update(time);
	}

	public override void performToolAction(Tool t, int tileX, int tileY)
	{
		if (t is WateringCan)
		{
			string property_value = null;
			if (doesTileHaveProperty(tileX, tileY, "PetBowl", "Buildings", ref property_value))
			{
				watered.Value = true;
			}
		}
		base.performToolAction(t, tileX, tileY);
	}

	public bool HasPet()
	{
		return petId.Value != Guid.Empty;
	}

	public override void draw(SpriteBatch b)
	{
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		base.draw(b);
		if (base.isMoving || isUnderConstruction())
		{
			return;
		}
		if (watered.Value)
		{
			BuildingData data = GetData();
			float num = (tileY.Value + tilesHigh.Value) * 64;
			if (data != null)
			{
				num -= data.SortTileOffset * 64f;
			}
			num += 1.5f;
			num /= 10000f;
			Vector2 val = default(Vector2);
			((Vector2)(ref val))._002Ector((float)(tileX.Value * 64), (float)(tileY.Value * 64 + tilesHigh.Value * 64));
			Vector2 val2 = Vector2.Zero;
			if (data != null)
			{
				val2 = data.DrawOffset * 4f;
			}
			Rectangle sourceRect = getSourceRect();
			sourceRect.X += sourceRect.Width;
			Vector2 val3 = default(Vector2);
			((Vector2)(ref val3))._002Ector(0f, (float)sourceRect.Height);
			b.Draw(texture.Value, Game1.GlobalToLocal(Game1.viewport, val + val2), (Rectangle?)sourceRect, color * alpha, 0f, val3, 4f, (SpriteEffects)0, num);
		}
		if (nameTimer > 0)
		{
			BuildingData data2 = GetData();
			float num2 = (tileY.Value + tilesHigh.Value) * 64;
			if (data2 != null)
			{
				num2 -= data2.SortTileOffset * 64f;
			}
			num2 += 1.5f;
			num2 /= 10000f;
			SpriteText.drawSmallTextBubble(b, nameTimerMessage, Game1.GlobalToLocal(new Vector2(((float)tileX.Value + 1.5f) * 64f, (float)(tileY.Value * 64 - 32))), -1, num2 + 1E-06f);
		}
	}
}
