using System;
using Microsoft.Xna.Framework;
using StardewValley.Characters;
using StardewValley.Util;

namespace StardewValley.Buildings;

public class Stable : Building
{
	public Guid HorseId
	{
		get
		{
			return id.Value;
		}
		set
		{
			id.Value = value;
		}
	}

	public Stable()
		: this(Vector2.Zero)
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public Stable(Vector2 tileLocation)
		: this(tileLocation, GuidHelper.NewGuid())
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public Stable(Vector2 tileLocation, Guid horseId)
		: base("Stable", tileLocation)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		HorseId = horseId;
	}

	public override Rectangle? getSourceRectForMenu()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		return new Rectangle(0, 0, texture.Value.Bounds.Width, texture.Value.Bounds.Height);
	}

	public Horse getStableHorse()
	{
		return Utility.findHorse(HorseId);
	}

	public Point GetDefaultHorseTile()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		return new Point(tileX.Value + 1, tileY.Value + 1);
	}

	public virtual void grabHorse()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if (daysOfConstructionLeft.Value <= 0)
		{
			Horse horse = Utility.findHorse(HorseId);
			Point defaultHorseTile = GetDefaultHorseTile();
			if (horse == null)
			{
				horse = new Horse(HorseId, defaultHorseTile.X, defaultHorseTile.Y);
				GetParentLocation().characters.Add(horse);
			}
			else
			{
				Game1.warpCharacter(horse, parentLocationName.Value, defaultHorseTile);
			}
			horse.ownerId.Value = owner.Value;
		}
	}

	public virtual void updateHorseOwnership()
	{
		if (daysOfConstructionLeft.Value > 0)
		{
			return;
		}
		Horse horse = Utility.findHorse(HorseId);
		if (horse == null)
		{
			return;
		}
		horse.ownerId.Value = owner.Value;
		if (horse.getOwner() != null)
		{
			if (horse.getOwner().horseName.Value != null)
			{
				horse.name.Value = horse.getOwner().horseName.Value;
				horse.displayName = horse.getOwner().horseName.Value;
			}
			else
			{
				horse.name.Value = "";
				horse.displayName = "";
			}
		}
	}

	public override void dayUpdate(int dayOfMonth)
	{
		base.dayUpdate(dayOfMonth);
		grabHorse();
	}

	public override void performActionOnDemolition(GameLocation location)
	{
		base.performActionOnDemolition(location);
		Horse stableHorse = getStableHorse();
		stableHorse?.currentLocation?.characters.Remove(stableHorse);
	}
}
