using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Extensions;

namespace StardewValley;

internal class EventScript_GreenTea : ICustomEventScript
{
	private const int Phase_intro = 0;

	private const int Phase_text1 = 1;

	private const int Phase_text2 = 2;

	private const int Phase_text3 = 3;

	private const int Phase_buddy = 4;

	private const int Phase_end = 5;

	private int width;

	private int height;

	private int topLeftX;

	private int topLeftY;

	private int phaseTimer = 5000;

	private int steamTimer = 100;

	private int cupTimer = 500;

	private int currentPhase;

	private int buddyPhase;

	private int buddyTimer;

	private int textColor;

	private string text;

	private Texture2D tempText;

	private Color bgColor;

	private Color hillColor;

	private Color lightLeafColor;

	private Color darkLeafColor;

	private Vector2 globalCenterPosition;

	private TemporaryAnimatedSprite buddy;

	public EventScript_GreenTea(Vector2 onScreenCenterPosition, Event e)
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		tempText = Game1.temporaryContent.Load<Texture2D>("LooseSprites\\temporary_sprites_1");
		width = 1920;
		height = 1080;
		Viewport viewport = Game1.graphics.GraphicsDevice.Viewport;
		topLeftX = ((Viewport)(ref viewport)).Width / 2 - width / 2;
		viewport = Game1.graphics.GraphicsDevice.Viewport;
		topLeftY = ((Viewport)(ref viewport)).Height / 2 - height / 2;
		bgColor = new Color(20, 104, 82);
		hillColor = new Color(55, 68, 53);
		lightLeafColor = new Color(11, 56, 39);
		darkLeafColor = new Color(5, 3, 4);
		globalCenterPosition = onScreenCenterPosition;
		e.aboveMapSprites = new TemporaryAnimatedSpriteList();
		addStar(new Vector2((float)(topLeftX + 608), (float)(topLeftY + 228)), e);
		addStar(new Vector2((float)(topLeftX + 644), (float)(topLeftY + 364)), e);
		addStar(new Vector2((float)(topLeftX + 876), (float)(topLeftY + 256)), e);
		addStar(new Vector2((float)(topLeftX + 740), (float)(topLeftY + 452)), e);
		addStar(new Vector2((float)(topLeftX + 1052), (float)(topLeftY + 472)), e);
		addStar(new Vector2((float)(topLeftX + 1204), (float)(topLeftY + 252)), e);
		addStar(new Vector2((float)(topLeftX + 1188), (float)(topLeftY + 400)), e);
		addStar(new Vector2((float)(topLeftX + 736), (float)(topLeftY + 248)), e);
		addStar(new Vector2((float)(topLeftX + 1120), (float)(topLeftY + 256)), e);
		currentPhase = 0;
		phaseTimer = 5000;
	}

	private void addStar(Vector2 pos, Event e)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		e.aboveMapSprites.Add(new TemporaryAnimatedSprite
		{
			texture = tempText,
			local = true,
			position = pos,
			initialPosition = pos,
			sourceRect = new Rectangle(408, 459, 7, 7),
			scale = 4f,
			sourceRectStartingPos = new Vector2(408f, 459f),
			animationLength = 6,
			totalNumberOfLoops = 99999,
			interval = 150 + Game1.random.Next(-20, 21),
			layerDepth = 1f,
			overrideLocationDestroy = true
		});
	}

	public void draw(SpriteBatch b)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_035b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_0370: Unknown result type (might be due to invalid IL or missing references)
		//IL_037a: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_040c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_0421: Unknown result type (might be due to invalid IL or missing references)
		//IL_042b: Unknown result type (might be due to invalid IL or missing references)
		//IL_045f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0469: Unknown result type (might be due to invalid IL or missing references)
		//IL_0474: Unknown result type (might be due to invalid IL or missing references)
		//IL_047e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04df: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0513: Unknown result type (might be due to invalid IL or missing references)
		//IL_0522: Unknown result type (might be due to invalid IL or missing references)
		//IL_052c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0531: Unknown result type (might be due to invalid IL or missing references)
		//IL_0544: Unknown result type (might be due to invalid IL or missing references)
		//IL_054f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0559: Unknown result type (might be due to invalid IL or missing references)
		//IL_0583: Unknown result type (might be due to invalid IL or missing references)
		//IL_0592: Unknown result type (might be due to invalid IL or missing references)
		//IL_059c: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0602: Unknown result type (might be due to invalid IL or missing references)
		//IL_060c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0611: Unknown result type (might be due to invalid IL or missing references)
		//IL_0624: Unknown result type (might be due to invalid IL or missing references)
		//IL_062f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0639: Unknown result type (might be due to invalid IL or missing references)
		//IL_0663: Unknown result type (might be due to invalid IL or missing references)
		//IL_0672: Unknown result type (might be due to invalid IL or missing references)
		//IL_067c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0681: Unknown result type (might be due to invalid IL or missing references)
		//IL_0694: Unknown result type (might be due to invalid IL or missing references)
		//IL_069f: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0704: Unknown result type (might be due to invalid IL or missing references)
		//IL_070f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0719: Unknown result type (might be due to invalid IL or missing references)
		//IL_0743: Unknown result type (might be due to invalid IL or missing references)
		//IL_0752: Unknown result type (might be due to invalid IL or missing references)
		//IL_075c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0761: Unknown result type (might be due to invalid IL or missing references)
		//IL_0774: Unknown result type (might be due to invalid IL or missing references)
		//IL_077f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0789: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0823: Unknown result type (might be due to invalid IL or missing references)
		//IL_0832: Unknown result type (might be due to invalid IL or missing references)
		//IL_083c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0841: Unknown result type (might be due to invalid IL or missing references)
		//IL_0854: Unknown result type (might be due to invalid IL or missing references)
		//IL_085f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0869: Unknown result type (might be due to invalid IL or missing references)
		//IL_0893: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_08cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0903: Unknown result type (might be due to invalid IL or missing references)
		//IL_0912: Unknown result type (might be due to invalid IL or missing references)
		//IL_091c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0921: Unknown result type (might be due to invalid IL or missing references)
		//IL_0934: Unknown result type (might be due to invalid IL or missing references)
		//IL_093f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0949: Unknown result type (might be due to invalid IL or missing references)
		//IL_0973: Unknown result type (might be due to invalid IL or missing references)
		//IL_0982: Unknown result type (might be due to invalid IL or missing references)
		//IL_098c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0991: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_09af: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a03: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a26: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a30: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a70: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a92: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a9d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b09: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b14: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b68: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b80: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b8b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b95: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bdf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c02: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c0c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c3d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c4c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c56: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c5b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c79: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c83: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cbc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ccb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cde: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d2c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d36: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d3b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d4e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d63: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d8d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dbe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dc9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dfd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e0c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e16: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e39: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e43: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e8b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e9e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ea9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eb3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0edd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ef6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0efb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f0e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f23: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f5c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f66: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f71: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f7b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fb6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fc0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fcb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd5: Unknown result type (might be due to invalid IL or missing references)
		//IL_100a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1014: Unknown result type (might be due to invalid IL or missing references)
		//IL_101f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1029: Unknown result type (might be due to invalid IL or missing references)
		//IL_105a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1064: Unknown result type (might be due to invalid IL or missing references)
		//IL_106f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1079: Unknown result type (might be due to invalid IL or missing references)
		//IL_10a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_10b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_10ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_10bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_10d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_10dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_10e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1114: Unknown result type (might be due to invalid IL or missing references)
		//IL_1123: Unknown result type (might be due to invalid IL or missing references)
		//IL_112d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1132: Unknown result type (might be due to invalid IL or missing references)
		//IL_1145: Unknown result type (might be due to invalid IL or missing references)
		//IL_1150: Unknown result type (might be due to invalid IL or missing references)
		//IL_115a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1187: Unknown result type (might be due to invalid IL or missing references)
		//IL_1196: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_11b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_11c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_11cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_11fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_1209: Unknown result type (might be due to invalid IL or missing references)
		//IL_1213: Unknown result type (might be due to invalid IL or missing references)
		//IL_1218: Unknown result type (might be due to invalid IL or missing references)
		//IL_122b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1236: Unknown result type (might be due to invalid IL or missing references)
		//IL_1240: Unknown result type (might be due to invalid IL or missing references)
		//IL_126d: Unknown result type (might be due to invalid IL or missing references)
		//IL_127c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1286: Unknown result type (might be due to invalid IL or missing references)
		//IL_128b: Unknown result type (might be due to invalid IL or missing references)
		//IL_129e: Unknown result type (might be due to invalid IL or missing references)
		//IL_12a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_12b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_12e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_12ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_12f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_12fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_1311: Unknown result type (might be due to invalid IL or missing references)
		//IL_131c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1326: Unknown result type (might be due to invalid IL or missing references)
		//IL_1353: Unknown result type (might be due to invalid IL or missing references)
		//IL_1362: Unknown result type (might be due to invalid IL or missing references)
		//IL_136c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1371: Unknown result type (might be due to invalid IL or missing references)
		//IL_1384: Unknown result type (might be due to invalid IL or missing references)
		//IL_138f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1399: Unknown result type (might be due to invalid IL or missing references)
		//IL_13c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_13d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_13df: Unknown result type (might be due to invalid IL or missing references)
		//IL_13e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_13f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1402: Unknown result type (might be due to invalid IL or missing references)
		//IL_140c: Unknown result type (might be due to invalid IL or missing references)
		//IL_143c: Unknown result type (might be due to invalid IL or missing references)
		//IL_144b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1455: Unknown result type (might be due to invalid IL or missing references)
		//IL_145a: Unknown result type (might be due to invalid IL or missing references)
		//IL_146d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1478: Unknown result type (might be due to invalid IL or missing references)
		//IL_1482: Unknown result type (might be due to invalid IL or missing references)
		//IL_14b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_14c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_14cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_14d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_14e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_14ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_14f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1528: Unknown result type (might be due to invalid IL or missing references)
		//IL_1537: Unknown result type (might be due to invalid IL or missing references)
		//IL_1541: Unknown result type (might be due to invalid IL or missing references)
		//IL_1546: Unknown result type (might be due to invalid IL or missing references)
		//IL_1559: Unknown result type (might be due to invalid IL or missing references)
		//IL_1564: Unknown result type (might be due to invalid IL or missing references)
		//IL_156e: Unknown result type (might be due to invalid IL or missing references)
		//IL_159e: Unknown result type (might be due to invalid IL or missing references)
		//IL_15ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_15b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_15bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_15cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_15da: Unknown result type (might be due to invalid IL or missing references)
		//IL_15e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1614: Unknown result type (might be due to invalid IL or missing references)
		//IL_1623: Unknown result type (might be due to invalid IL or missing references)
		//IL_162d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1632: Unknown result type (might be due to invalid IL or missing references)
		//IL_1645: Unknown result type (might be due to invalid IL or missing references)
		//IL_1650: Unknown result type (might be due to invalid IL or missing references)
		//IL_165a: Unknown result type (might be due to invalid IL or missing references)
		//IL_168a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1699: Unknown result type (might be due to invalid IL or missing references)
		//IL_16a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_16a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_16bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_16c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_16d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1700: Unknown result type (might be due to invalid IL or missing references)
		//IL_170f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1719: Unknown result type (might be due to invalid IL or missing references)
		//IL_171e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1731: Unknown result type (might be due to invalid IL or missing references)
		//IL_173c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1746: Unknown result type (might be due to invalid IL or missing references)
		//IL_1776: Unknown result type (might be due to invalid IL or missing references)
		//IL_1785: Unknown result type (might be due to invalid IL or missing references)
		//IL_178f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1794: Unknown result type (might be due to invalid IL or missing references)
		//IL_17a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_17b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_17bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_17f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1802: Unknown result type (might be due to invalid IL or missing references)
		//IL_180c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1811: Unknown result type (might be due to invalid IL or missing references)
		//IL_1824: Unknown result type (might be due to invalid IL or missing references)
		//IL_182f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1839: Unknown result type (might be due to invalid IL or missing references)
		//IL_1870: Unknown result type (might be due to invalid IL or missing references)
		//IL_187f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1889: Unknown result type (might be due to invalid IL or missing references)
		//IL_188e: Unknown result type (might be due to invalid IL or missing references)
		//IL_18a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_18ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_18b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_18ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_18fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_1906: Unknown result type (might be due to invalid IL or missing references)
		//IL_190b: Unknown result type (might be due to invalid IL or missing references)
		//IL_191e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1929: Unknown result type (might be due to invalid IL or missing references)
		//IL_1933: Unknown result type (might be due to invalid IL or missing references)
		//IL_196a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1979: Unknown result type (might be due to invalid IL or missing references)
		//IL_1983: Unknown result type (might be due to invalid IL or missing references)
		//IL_1988: Unknown result type (might be due to invalid IL or missing references)
		//IL_199b: Unknown result type (might be due to invalid IL or missing references)
		//IL_19a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_19b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_19e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_19f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a00: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a05: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a18: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a23: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a2d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a64: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a73: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a7d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a82: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a95: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aa0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aaa: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ae1: Unknown result type (might be due to invalid IL or missing references)
		//IL_1af0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1afa: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aff: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b12: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b27: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b77: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b8f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b9a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ba4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bd1: Unknown result type (might be due to invalid IL or missing references)
		//IL_1be0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bea: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bef: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c02: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c17: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c44: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c53: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c5d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c62: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c75: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c80: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c8a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cb7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cc6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cd0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cd5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ce8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cf3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cfd: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d2a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d39: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d43: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d48: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d5b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d66: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d70: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d9d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dac: Unknown result type (might be due to invalid IL or missing references)
		//IL_1db6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dbb: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dce: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1de3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e10: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e1f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e29: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e41: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e4c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e56: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e83: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e92: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e9c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ea1: Unknown result type (might be due to invalid IL or missing references)
		//IL_1eb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ebf: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ec9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ef6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f05: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f0f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f14: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f27: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f32: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f66: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f75: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f84: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f94: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f9f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fa9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fd3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fe2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fec: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ff1: Unknown result type (might be due to invalid IL or missing references)
		//IL_2001: Unknown result type (might be due to invalid IL or missing references)
		//IL_200c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2016: Unknown result type (might be due to invalid IL or missing references)
		//IL_2040: Unknown result type (might be due to invalid IL or missing references)
		//IL_204f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2059: Unknown result type (might be due to invalid IL or missing references)
		//IL_205e: Unknown result type (might be due to invalid IL or missing references)
		//IL_206e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2079: Unknown result type (might be due to invalid IL or missing references)
		//IL_2083: Unknown result type (might be due to invalid IL or missing references)
		//IL_20ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_20bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_20c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_20cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_20db: Unknown result type (might be due to invalid IL or missing references)
		//IL_20e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_20f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_211a: Unknown result type (might be due to invalid IL or missing references)
		//IL_2129: Unknown result type (might be due to invalid IL or missing references)
		//IL_2133: Unknown result type (might be due to invalid IL or missing references)
		//IL_2138: Unknown result type (might be due to invalid IL or missing references)
		//IL_2148: Unknown result type (might be due to invalid IL or missing references)
		//IL_2153: Unknown result type (might be due to invalid IL or missing references)
		//IL_215d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2187: Unknown result type (might be due to invalid IL or missing references)
		//IL_2196: Unknown result type (might be due to invalid IL or missing references)
		//IL_21a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_21a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_21b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_21c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_21ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_21f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_2203: Unknown result type (might be due to invalid IL or missing references)
		//IL_220d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2212: Unknown result type (might be due to invalid IL or missing references)
		//IL_2222: Unknown result type (might be due to invalid IL or missing references)
		//IL_222d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2237: Unknown result type (might be due to invalid IL or missing references)
		//IL_2261: Unknown result type (might be due to invalid IL or missing references)
		//IL_2270: Unknown result type (might be due to invalid IL or missing references)
		//IL_227a: Unknown result type (might be due to invalid IL or missing references)
		//IL_227f: Unknown result type (might be due to invalid IL or missing references)
		//IL_228f: Unknown result type (might be due to invalid IL or missing references)
		//IL_229a: Unknown result type (might be due to invalid IL or missing references)
		//IL_22a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_22ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_22dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_22e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_22ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_22fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_2307: Unknown result type (might be due to invalid IL or missing references)
		//IL_2311: Unknown result type (might be due to invalid IL or missing references)
		//IL_233b: Unknown result type (might be due to invalid IL or missing references)
		//IL_234a: Unknown result type (might be due to invalid IL or missing references)
		//IL_2354: Unknown result type (might be due to invalid IL or missing references)
		//IL_2359: Unknown result type (might be due to invalid IL or missing references)
		//IL_2369: Unknown result type (might be due to invalid IL or missing references)
		//IL_2374: Unknown result type (might be due to invalid IL or missing references)
		//IL_237e: Unknown result type (might be due to invalid IL or missing references)
		//IL_23a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_23b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_23c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_23c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_23d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_23e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_23eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_2415: Unknown result type (might be due to invalid IL or missing references)
		//IL_2424: Unknown result type (might be due to invalid IL or missing references)
		//IL_242e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2433: Unknown result type (might be due to invalid IL or missing references)
		//IL_2443: Unknown result type (might be due to invalid IL or missing references)
		//IL_244e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2458: Unknown result type (might be due to invalid IL or missing references)
		//IL_2482: Unknown result type (might be due to invalid IL or missing references)
		//IL_2491: Unknown result type (might be due to invalid IL or missing references)
		//IL_249b: Unknown result type (might be due to invalid IL or missing references)
		//IL_24a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_24b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_24bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_24c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_24ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_24fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_2508: Unknown result type (might be due to invalid IL or missing references)
		//IL_250d: Unknown result type (might be due to invalid IL or missing references)
		//IL_251d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2528: Unknown result type (might be due to invalid IL or missing references)
		//IL_2532: Unknown result type (might be due to invalid IL or missing references)
		//IL_255c: Unknown result type (might be due to invalid IL or missing references)
		//IL_256b: Unknown result type (might be due to invalid IL or missing references)
		//IL_2575: Unknown result type (might be due to invalid IL or missing references)
		//IL_257a: Unknown result type (might be due to invalid IL or missing references)
		//IL_258a: Unknown result type (might be due to invalid IL or missing references)
		//IL_2595: Unknown result type (might be due to invalid IL or missing references)
		//IL_259f: Unknown result type (might be due to invalid IL or missing references)
		//IL_25c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_25d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_25e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_25e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_25f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_2602: Unknown result type (might be due to invalid IL or missing references)
		//IL_260c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2636: Unknown result type (might be due to invalid IL or missing references)
		//IL_2645: Unknown result type (might be due to invalid IL or missing references)
		//IL_264f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2654: Unknown result type (might be due to invalid IL or missing references)
		//IL_2664: Unknown result type (might be due to invalid IL or missing references)
		//IL_266f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2679: Unknown result type (might be due to invalid IL or missing references)
		//IL_26a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_26b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_26bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_26c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_26d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_26df: Unknown result type (might be due to invalid IL or missing references)
		//IL_26e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_2713: Unknown result type (might be due to invalid IL or missing references)
		//IL_2722: Unknown result type (might be due to invalid IL or missing references)
		//IL_272c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2731: Unknown result type (might be due to invalid IL or missing references)
		//IL_2744: Unknown result type (might be due to invalid IL or missing references)
		//IL_274f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2759: Unknown result type (might be due to invalid IL or missing references)
		//IL_2783: Unknown result type (might be due to invalid IL or missing references)
		//IL_2792: Unknown result type (might be due to invalid IL or missing references)
		//IL_279c: Unknown result type (might be due to invalid IL or missing references)
		//IL_27a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_27b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_27bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_27c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_27f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_2802: Unknown result type (might be due to invalid IL or missing references)
		//IL_280c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2811: Unknown result type (might be due to invalid IL or missing references)
		//IL_2824: Unknown result type (might be due to invalid IL or missing references)
		//IL_282f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2839: Unknown result type (might be due to invalid IL or missing references)
		//IL_2863: Unknown result type (might be due to invalid IL or missing references)
		//IL_2872: Unknown result type (might be due to invalid IL or missing references)
		//IL_287c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2881: Unknown result type (might be due to invalid IL or missing references)
		//IL_2894: Unknown result type (might be due to invalid IL or missing references)
		//IL_289f: Unknown result type (might be due to invalid IL or missing references)
		//IL_28a9: Unknown result type (might be due to invalid IL or missing references)
		b.Draw(Game1.staminaRect, new Rectangle(topLeftX + 208, topLeftY + 8, width - 416, height - 16), (Rectangle?)Game1.staminaRect.Bounds, bgColor, 0f, Vector2.Zero, (SpriteEffects)0, 0.05f);
		for (int i = 0; i < 5; i++)
		{
			b.Draw(tempText, new Vector2((float)(topLeftX + 208 + i * 71 * 4), (float)(topLeftY + height / 2)), (Rectangle?)new Rectangle(386, 472, 71, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.1f);
		}
		b.Draw(Game1.staminaRect, new Rectangle(topLeftX + 208, topLeftY + height / 2 + 60, width - 416, height / 2 - 76), (Rectangle?)Game1.staminaRect.Bounds, hillColor, 0f, Vector2.Zero, (SpriteEffects)0, 0.15f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(276f, 110f) * 4f, (Rectangle?)new Rectangle(0, 315, 72, 69), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.1525f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(196f, 144f) * 4f, (Rectangle?)new Rectangle(145, 440, 129, 72), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.155f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(200f, 152f) * 4f, (Rectangle?)new Rectangle(336 + (int)(Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 800.0) / 200 * 44, 493, 44, 19), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.156f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(215f, 170f) * 4f, (Rectangle?)new Rectangle(278, 482, 19, 30), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.159f);
		buddy?.draw(b);
		b.Draw(Game1.staminaRect, new Rectangle(topLeftX + 208, topLeftY + 8, 296, 1064), (Rectangle?)Game1.staminaRect.Bounds, lightLeafColor, 0f, Vector2.Zero, (SpriteEffects)0, 0.16f);
		b.Draw(Game1.staminaRect, new Rectangle(topLeftX + width - 504, topLeftY + 8, 296, 1064), (Rectangle?)Game1.staminaRect.Bounds, lightLeafColor, 0f, Vector2.Zero, (SpriteEffects)0, 0.16f);
		b.Draw(Game1.staminaRect, new Rectangle(topLeftX + 504, topLeftY + 900, 936, 180), (Rectangle?)Game1.staminaRect.Bounds, lightLeafColor, 0f, Vector2.Zero, (SpriteEffects)0, 0.165f);
		b.Draw(Game1.staminaRect, new Rectangle(topLeftX + 504, topLeftY + 8, 936, 180), (Rectangle?)Game1.staminaRect.Bounds, lightLeafColor, 0f, Vector2.Zero, (SpriteEffects)0, 0.165f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(124f, 213f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(154f, 205f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(200f, 213f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(244f, 209f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(290f, 205f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(325f, 213f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(148f, 27f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(142f, 40f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(148f, 70f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(138f, 102f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(148f, 150f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(135f, 186f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width), (float)topLeftY) + new Vector2(-148f, 67f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width), (float)topLeftY) + new Vector2(-142f, 80f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width), (float)topLeftY) + new Vector2(-148f, 110f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width), (float)topLeftY) + new Vector2(-138f, 142f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width), (float)topLeftY) + new Vector2(-148f, 190f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width), (float)topLeftY) + new Vector2(-135f, 226f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(164f, 62f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(214f, 55f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(240f, 59f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(274f, 55f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(320f, 57f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(365f, 62f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), lightLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.2f);
		b.Draw(Game1.staminaRect, new Rectangle(topLeftX + 208, topLeftY + 8, 140, 1064), (Rectangle?)Game1.staminaRect.Bounds, darkLeafColor, 0f, Vector2.Zero, (SpriteEffects)0, 0.17f);
		b.Draw(Game1.staminaRect, new Rectangle(topLeftX + width - 340, topLeftY + 8, 132, 1064), (Rectangle?)Game1.staminaRect.Bounds, darkLeafColor, 0f, Vector2.Zero, (SpriteEffects)0, 0.17f);
		b.Draw(Game1.staminaRect, new Rectangle(topLeftX + 340, topLeftY + 1020, 1240, 60), (Rectangle?)Game1.staminaRect.Bounds, darkLeafColor, 0f, Vector2.Zero, (SpriteEffects)0, 0.175f);
		b.Draw(Game1.staminaRect, new Rectangle(topLeftX + 340, topLeftY + 8, 1240, 60), (Rectangle?)Game1.staminaRect.Bounds, darkLeafColor, 0f, Vector2.Zero, (SpriteEffects)0, 0.175f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY + 112)) + new Vector2(94f, 213f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY + 112)) + new Vector2(124f, 213f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY + 112)) + new Vector2(153f, 207f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY + 112)) + new Vector2(200f, 214f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY + 112)) + new Vector2(244f, 209f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY + 112)) + new Vector2(290f, 205f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY + 112)) + new Vector2(325f, 213f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY + 112)) + new Vector2(350f, 213f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX - 160), (float)topLeftY) + new Vector2(148f, 0f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX - 160), (float)topLeftY) + new Vector2(148f, 27f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX - 160), (float)topLeftY) + new Vector2(142f, 40f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX - 160), (float)topLeftY) + new Vector2(148f, 70f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX - 160), (float)topLeftY) + new Vector2(138f, 102f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX - 160), (float)topLeftY) + new Vector2(148f, 150f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX - 160), (float)topLeftY) + new Vector2(135f, 186f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX - 160), (float)topLeftY) + new Vector2(148f, 220f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width + 164), (float)topLeftY) + new Vector2(-148f, 57f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width + 164), (float)topLeftY) + new Vector2(-148f, 67f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width + 164), (float)topLeftY) + new Vector2(-142f, 80f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width + 164), (float)topLeftY) + new Vector2(-148f, 110f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width + 164), (float)topLeftY) + new Vector2(-138f, 142f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width + 164), (float)topLeftY) + new Vector2(-148f, 190f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width + 164), (float)topLeftY) + new Vector2(-135f, 226f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)(topLeftX + width + 164), (float)topLeftY) + new Vector2(-148f, 260f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY - 112)) + new Vector2(124f, 62f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY - 112)) + new Vector2(164f, 62f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY - 112)) + new Vector2(214f, 55f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY - 112)) + new Vector2(240f, 59f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY - 112)) + new Vector2(274f, 54f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY - 112)) + new Vector2(320f, 58f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY - 112)) + new Vector2(365f, 62f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)(topLeftY - 112)) + new Vector2(394f, 62f) * 4f, (Rectangle?)new Rectangle(462, 470, 50, 22), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(111f, 228f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.22f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(159f, 214f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.22f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(226f, 232f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.22f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(294f, 218f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.22f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(358f, 221f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.22f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(128f, 156f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(108f, 200f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(130f, 78f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(117f, 33f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, (float)Math.PI / 2f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(184f, 44f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(228f, 42f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(311f, 38f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(123f, 39f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, (float)Math.PI, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(353f, 101f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(366f, 140f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(352f, 183f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(352f, 50f) * 4f, (Rectangle?)new Rectangle(79, 354, 41, 27), darkLeafColor, 4.712389f, Vector2.Zero, 4f, (SpriteEffects)0, 0.21f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(121f, 16f) * 4f, (Rectangle?)new Rectangle(129, 353, 12, 46), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.22f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(106f, 93f) * 4f, (Rectangle?)new Rectangle(129, 353, 12, 46), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.22f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(361f, 153f) * 4f, (Rectangle?)new Rectangle(129, 353, 12, 46), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.22f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(341f, 22f) * 4f, (Rectangle?)new Rectangle(129, 353, 12, 46), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.22f);
		b.Draw(tempText, new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(326f, 0f) * 4f, (Rectangle?)new Rectangle(129, 353, 12, 46), darkLeafColor, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.22f);
	}

	public void drawAboveAlwaysFront(SpriteBatch b)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (currentPhase == 5)
		{
			b.Draw(Game1.staminaRect, new Rectangle(topLeftX, topLeftY, width, height), (Rectangle?)Game1.staminaRect.Bounds, darkLeafColor * (1f - (float)Math.Min(2000, phaseTimer) / 2000f), 0f, Vector2.Zero, (SpriteEffects)0, 1f);
		}
	}

	public bool update(GameTime time, Event e)
	{
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0300: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0314: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		//IL_0339: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		//IL_036e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_060f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0614: Unknown result type (might be due to invalid IL or missing references)
		//IL_062f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0634: Unknown result type (might be due to invalid IL or missing references)
		//IL_081e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0828: Unknown result type (might be due to invalid IL or missing references)
		//IL_0832: Unknown result type (might be due to invalid IL or missing references)
		//IL_0837: Unknown result type (might be due to invalid IL or missing references)
		//IL_087a: Unknown result type (might be due to invalid IL or missing references)
		//IL_087f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0881: Unknown result type (might be due to invalid IL or missing references)
		//IL_0886: Unknown result type (might be due to invalid IL or missing references)
		//IL_0892: Unknown result type (might be due to invalid IL or missing references)
		//IL_0897: Unknown result type (might be due to invalid IL or missing references)
		//IL_0899: Unknown result type (might be due to invalid IL or missing references)
		//IL_089e: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0905: Unknown result type (might be due to invalid IL or missing references)
		//IL_090a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0925: Unknown result type (might be due to invalid IL or missing references)
		//IL_092a: Unknown result type (might be due to invalid IL or missing references)
		phaseTimer -= time.ElapsedGameTime.Milliseconds;
		steamTimer -= time.ElapsedGameTime.Milliseconds;
		cupTimer -= time.ElapsedGameTime.Milliseconds;
		if (steamTimer <= 0)
		{
			if (e.aboveMapSprites == null)
			{
				e.aboveMapSprites = new TemporaryAnimatedSpriteList();
			}
			int num = Game1.random.Next(-48, 64);
			e.aboveMapSprites.Add(new TemporaryAnimatedSprite
			{
				texture = tempText,
				local = true,
				position = new Vector2((float)(topLeftX + width / 2), (float)(topLeftY + height / 2)) + new Vector2((float)(-64 + num), 64f),
				initialPosition = new Vector2((float)(topLeftX + width / 2), (float)(topLeftY + height / 2)) + new Vector2((float)(-64 + num), 64f),
				motion = new Vector2(-0.1f, -1f),
				alphaFade = -0.01f,
				alphaFadeFade = -0.0001f,
				alpha = 0.1f,
				rotationChange = Utility.Lerp(-0.01f, 0.01f, (float)Game1.random.NextDouble()),
				sourceRect = new Rectangle(472, 450, 16, 14),
				scale = 4f,
				sourceRectStartingPos = new Vector2(472f, 450f),
				animationLength = 1,
				totalNumberOfLoops = 1,
				interval = 50000f,
				layerDepth = 1f,
				overrideLocationDestroy = true
			});
			steamTimer = 100;
		}
		if (phaseTimer <= 0)
		{
			currentPhase++;
			phaseTimer = 99999;
			switch (currentPhase)
			{
			case 1:
				text = Game1.content.LoadString("Strings\\Locations:Caroline_Tea_Event1");
				textColor = 6;
				break;
			case 2:
				text = Game1.content.LoadString("Strings\\Locations:Caroline_Tea_Event2");
				textColor = 6;
				break;
			case 3:
				text = Game1.content.LoadString("Strings\\Locations:Caroline_Tea_Event3");
				textColor = 6;
				break;
			case 4:
				buddy = new TemporaryAnimatedSprite
				{
					texture = tempText,
					local = true,
					position = new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(213f, 170f) * 4f,
					initialPosition = new Vector2((float)topLeftX, (float)topLeftY) + new Vector2(219f, 170f) * 4f,
					motion = new Vector2(0f, -9f),
					acceleration = new Vector2(0f, 0.2f),
					sourceRect = new Rectangle(0, 242, 27, 32),
					scale = 4f,
					sourceRectStartingPos = new Vector2(0f, 242f),
					animationLength = 1,
					totalNumberOfLoops = 1,
					interval = 950000f,
					layerDepth = 0.158f,
					overrideLocationDestroy = true
				};
				setBuddyFrame(7);
				Game1.playSound("pullItemFromWater");
				buddyPhase = 0;
				break;
			case 5:
				phaseTimer = 3000;
				break;
			default:
				phaseTimer = 5000;
				break;
			}
		}
		if (buddy != null)
		{
			float y = buddy.motion.Y;
			buddy.update(time);
			if (y <= 0f && buddy.motion.Y > 0f)
			{
				buddy.layerDepth = 0.161f;
			}
			if (buddy.motion.Y > 0f && buddy.position.Y >= (float)(topLeftY + 608))
			{
				buddy.motion.Y = 0f;
				buddy.acceleration.Y = 0f;
				buddy.position.Y = topLeftY + 608;
				setBuddyFrame(0);
				Game1.playSound("coin");
				buddyPhase = 1;
				buddyTimer = 2500;
			}
			if (buddyTimer >= 0)
			{
				buddyTimer -= time.ElapsedGameTime.Milliseconds;
			}
			switch (buddyPhase)
			{
			case 1:
				setBuddyFrame(buddyTimer % 1000 / 500);
				if (buddyTimer <= 0)
				{
					buddyPhase = 2;
					buddyTimer = 1500;
					setBuddyFrame(5);
					Game1.playSound("dwop");
					e.aboveMapSprites.Add(new TemporaryAnimatedSprite
					{
						texture = tempText,
						local = true,
						position = buddy.position + new Vector2(-7f, -7f) * 4f,
						initialPosition = buddy.position + new Vector2(-7f, -7f) * 4f,
						sourceRect = new Rectangle(0, 384, 16, 16),
						scale = 4f,
						sourceRectStartingPos = new Vector2(0f, 384f),
						animationLength = 8,
						totalNumberOfLoops = 4,
						interval = 100f,
						layerDepth = 1f,
						id = 777,
						overrideLocationDestroy = true
					});
				}
				break;
			case 2:
				if (buddyTimer <= 0)
				{
					setBuddyFrame(6);
					buddyPhase = 3;
					Game1.playSound("sipTea");
					buddyTimer = 1000;
					e.aboveMapSprites.RemoveWhere((TemporaryAnimatedSprite sprite) => sprite.id == 777);
				}
				break;
			case 3:
				if (buddyTimer <= 0)
				{
					setBuddyFrame(8);
					Game1.playSound("gulp");
					buddyPhase = 4;
					buddyTimer = 1500;
				}
				break;
			case 4:
				if (buddyTimer < 1000)
				{
					setBuddyFrame(9);
				}
				if (buddyTimer <= 0)
				{
					buddyPhase = 5;
					buddyTimer = 2400;
					Game1.playSound("dustMeep");
					DelayedAction.playSoundAfterDelay("dustMeep", 400);
					DelayedAction.playSoundAfterDelay("dustMeep", 800);
					DelayedAction.playSoundAfterDelay("dustMeep", 1200);
				}
				break;
			case 5:
				if (buddyTimer > 1000)
				{
					setBuddyFrame(2 + buddyTimer % 400 / 200);
				}
				else
				{
					setBuddyFrame(4);
				}
				if (buddyTimer <= 0)
				{
					buddyTimer = 2000;
					buddyPhase = 6;
					for (int i = 0; i < 30; i++)
					{
						Vector2 val = Utility.getRandomPositionInThisRectangle(new Rectangle(-8, -8, 27, 32), Game1.random) * 4f;
						float num2 = Utility.Lerp(-2f, 2f, (float)Game1.random.NextDouble());
						e.aboveMapSprites.Add(new TemporaryAnimatedSprite
						{
							texture = tempText,
							local = true,
							position = buddy.position + val,
							initialPosition = buddy.position + val,
							motion = new Vector2(num2, -0.5f),
							alphaFade = -0.0125f,
							alphaFadeFade = -0.0002f,
							alpha = 0.25f,
							rotationChange = Utility.Lerp(-0.01f, 0.01f, (float)Game1.random.NextDouble()),
							sourceRect = new Rectangle(472, 450, 16, 14),
							scale = 4f,
							sourceRectStartingPos = new Vector2(472f, 450f),
							animationLength = 1,
							totalNumberOfLoops = 1,
							interval = 50000f,
							layerDepth = 1f,
							overrideLocationDestroy = true
						});
					}
					buddy = null;
					phaseTimer = 1;
					Game1.playSound("fireball");
				}
				break;
			case 6:
				if (buddyTimer <= 0)
				{
					phaseTimer = 1;
				}
				break;
			}
			Game1.InvalidateOldMouseMovement();
		}
		if (text != null)
		{
			e.int_useMeForAnything2 = textColor;
			e.float_useMeForAnything += time.ElapsedGameTime.Milliseconds;
			if (e.float_useMeForAnything > 80f)
			{
				if (e.int_useMeForAnything >= text.Length)
				{
					if (e.float_useMeForAnything >= 2500f)
					{
						e.int_useMeForAnything = 0;
						e.float_useMeForAnything = 0f;
						e.spriteTextToDraw = "";
						text = null;
						phaseTimer = 1;
					}
				}
				else
				{
					e.int_useMeForAnything++;
					e.float_useMeForAnything = 0f;
				}
			}
			e.spriteTextToDraw = text;
		}
		if (currentPhase == 5 && phaseTimer <= 20)
		{
			e.aboveMapSprites.Clear();
			return true;
		}
		return false;
	}

	private void setBuddyFrame(int frame)
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		if (buddy != null)
		{
			buddy.sourceRect.X = frame % 5 * 27;
			buddy.sourceRect.Y = 242 + frame / 5 * 32;
			buddy.sourceRectStartingPos = new Vector2((float)buddy.sourceRect.X, (float)buddy.sourceRect.Y);
		}
	}
}
