using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace StardewValley;

public class NPCController
{
	public delegate void endBehavior();

	public Character puppet;

	private bool loop;

	private bool destroyAtNextTurn;

	private List<Vector2> path;

	private Vector2 target;

	private int pathIndex;

	private int pauseTime = -1;

	private int speed;

	private endBehavior behaviorAtEnd;

	private int CurrentPathX
	{
		get
		{
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			if (pathIndex >= path.Count)
			{
				return 0;
			}
			return (int)path[pathIndex].X;
		}
	}

	private int CurrentPathY
	{
		get
		{
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			if (pathIndex >= path.Count)
			{
				return 0;
			}
			return (int)path[pathIndex].Y;
		}
	}

	private bool MovingHorizontally => CurrentPathX != 0;

	public NPCController(Character n, List<Vector2> path, bool loop, endBehavior endBehavior = null)
	{
		if (n != null)
		{
			speed = n.speed;
			this.loop = loop;
			puppet = n;
			this.path = path;
			setMoving(newTarget: true);
			behaviorAtEnd = endBehavior;
		}
	}

	public void destroyAtNextCrossroad()
	{
		destroyAtNextTurn = true;
	}

	private bool setMoving(bool newTarget)
	{
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		if (puppet != null && pathIndex < path.Count)
		{
			int direction = 2;
			if (CurrentPathX > 0)
			{
				direction = 1;
			}
			else if (CurrentPathX < 0)
			{
				direction = 3;
			}
			else if (CurrentPathY < 0)
			{
				direction = 0;
			}
			else if (CurrentPathY > 0)
			{
				direction = 2;
			}
			puppet.Halt();
			puppet.faceDirection(direction);
			if (CurrentPathX != 0 && CurrentPathY != 0)
			{
				pauseTime = CurrentPathY;
				direction = CurrentPathX % 4;
				puppet.faceDirection(direction);
				return true;
			}
			puppet.setMovingInFacingDirection();
			if (newTarget)
			{
				target = new Vector2(puppet.Position.X + (float)(CurrentPathX * 64), puppet.Position.Y + (float)(CurrentPathY * 64));
			}
			return true;
		}
		return false;
	}

	public bool update(GameTime time, GameLocation location, List<NPCController> allControllers)
	{
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		puppet.speed = speed;
		bool flag = false;
		foreach (NPCController allController in allControllers)
		{
			if (allController.puppet == null)
			{
				continue;
			}
			if (allController.puppet.Equals(puppet))
			{
				flag = true;
			}
			if (allController.puppet.FacingDirection != puppet.FacingDirection || allController.puppet.Equals(puppet))
			{
				continue;
			}
			Rectangle boundingBox = allController.puppet.GetBoundingBox();
			if (((Rectangle)(ref boundingBox)).Intersects(puppet.nextPosition(puppet.FacingDirection)))
			{
				if (flag)
				{
					break;
				}
				return false;
			}
		}
		if (puppet is Farmer farmer)
		{
			farmer.setRunning(isRunning: false, force: true);
			farmer.speed = 2;
			farmer.ignoreCollisions = true;
			if (Game1.CurrentEvent != null && Game1.CurrentEvent.farmer != puppet)
			{
				farmer.updateMovementAnimation(time);
			}
		}
		puppet.MovePosition(time, Game1.viewport, location);
		if (pauseTime < 0 && !puppet.isMoving())
		{
			setMoving(newTarget: false);
		}
		if (pauseTime < 0 && Math.Abs(Vector2.Distance(puppet.Position, target)) <= (float)puppet.Speed)
		{
			pathIndex++;
			if (destroyAtNextTurn)
			{
				return true;
			}
			if (!setMoving(newTarget: true))
			{
				if (loop)
				{
					pathIndex = 0;
					setMoving(newTarget: true);
				}
				else if (Game1.currentMinigame == null)
				{
					behaviorAtEnd?.Invoke();
					return true;
				}
			}
		}
		else if (pauseTime >= 0)
		{
			pauseTime -= time.ElapsedGameTime.Milliseconds;
			if (pauseTime < 0)
			{
				pathIndex++;
				if (destroyAtNextTurn)
				{
					return true;
				}
				if (!setMoving(newTarget: true))
				{
					if (loop)
					{
						pathIndex = 0;
						setMoving(newTarget: true);
					}
					else if (Game1.currentMinigame == null)
					{
						behaviorAtEnd?.Invoke();
						return true;
					}
				}
			}
		}
		return false;
	}
}
