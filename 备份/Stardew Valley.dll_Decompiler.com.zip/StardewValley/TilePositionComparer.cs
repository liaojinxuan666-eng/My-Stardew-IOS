using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace StardewValley;

public class TilePositionComparer : IEqualityComparer<Vector2>
{
	public bool Equals(Vector2 a, Vector2 b)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		return ((Vector2)(ref a)).Equals(b);
	}

	public int GetHashCode(Vector2 a)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return (ushort)a.X | ((ushort)a.Y << 16);
	}
}
