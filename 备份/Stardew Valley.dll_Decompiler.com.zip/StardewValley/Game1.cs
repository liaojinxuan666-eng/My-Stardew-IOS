using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Netcode;
using SkiaSharp;
using StardewValley.Audio;
using StardewValley.BellsAndWhistles;
using StardewValley.Buildings;
using StardewValley.Characters;
using StardewValley.Delegates;
using StardewValley.Enchantments;
using StardewValley.Events;
using StardewValley.Extensions;
using StardewValley.GameData;
using StardewValley.GameData.BigCraftables;
using StardewValley.GameData.Buildings;
using StardewValley.GameData.Characters;
using StardewValley.GameData.Crops;
using StardewValley.GameData.FarmAnimals;
using StardewValley.GameData.FloorsAndPaths;
using StardewValley.GameData.FruitTrees;
using StardewValley.GameData.LocationContexts;
using StardewValley.GameData.Locations;
using StardewValley.GameData.Objects;
using StardewValley.GameData.Pants;
using StardewValley.GameData.Pets;
using StardewValley.GameData.Shirts;
using StardewValley.GameData.Tools;
using StardewValley.GameData.Weapons;
using StardewValley.Hashing;
using StardewValley.Internal;
using StardewValley.Inventories;
using StardewValley.Locations;
using StardewValley.Logging;
using StardewValley.Menus;
using StardewValley.Minigames;
using StardewValley.Mods;
using StardewValley.Monsters;
using StardewValley.Network;
using StardewValley.Network.Dedicated;
using StardewValley.Network.NetReady;
using StardewValley.Objects;
using StardewValley.Pathfinding;
using StardewValley.Projectiles;
using StardewValley.Quests;
using StardewValley.SaveMigrations;
using StardewValley.SaveSerialization;
using StardewValley.SpecialOrders;
using StardewValley.TerrainFeatures;
using StardewValley.TokenizableStrings;
using StardewValley.Tools;
using StardewValley.Triggers;
using StardewValley.Util;
using xTile.Dimensions;
using xTile.Display;
using xTile.Layers;
using xTile.ObjectModel;
using xTile.Tiles;

namespace StardewValley;

[InstanceStatics]
public class Game1 : InstanceGame
{
	public enum BundleType
	{
		Default,
		Remixed
	}

	public enum MineChestType
	{
		Default,
		Remixed
	}

	public delegate void afterFadeFunction();

	public const bool IncrementalLoadEnabled = false;

	public const int defaultResolutionX = 1280;

	public const int defaultResolutionY = 720;

	public const int pixelZoom = 4;

	public const int tileSize = 64;

	public const int smallestTileSize = 16;

	public const int up = 0;

	public const int right = 1;

	public const int down = 2;

	public const int left = 3;

	public const int dialogueBoxTileHeight = 5;

	public static int realMilliSecondsPerGameMinute;

	public static int realMilliSecondsPerGameTenMinutes;

	public const int rainDensity = 70;

	public const int rainLoopLength = 70;

	public static readonly int cursor_none;

	public static readonly int cursor_default;

	public static readonly int cursor_wait;

	public static readonly int cursor_grab;

	public static readonly int cursor_gift;

	public static readonly int cursor_talk;

	public static readonly int cursor_look;

	public static readonly int cursor_harvest;

	public static readonly int cursor_gamepad_pointer;

	public static readonly string asianSpacingRegexString;

	public const int legacy_weather_sunny = 0;

	public const int legacy_weather_rain = 1;

	public const int legacy_weather_debris = 2;

	public const int legacy_weather_lightning = 3;

	public const int legacy_weather_festival = 4;

	public const int legacy_weather_snow = 5;

	public const int legacy_weather_wedding = 6;

	public const string weather_sunny = "Sun";

	public const string weather_rain = "Rain";

	public const string weather_green_rain = "GreenRain";

	public const string weather_debris = "Wind";

	public const string weather_lightning = "Storm";

	public const string weather_festival = "Festival";

	public const string weather_snow = "Snow";

	public const string weather_wedding = "Wedding";

	public const string builder_robin = "Robin";

	public const string builder_wizard = "Wizard";

	public const string shop_adventurersGuild = "AdventureShop";

	public const string shop_adventurersGuildItemRecovery = "AdventureGuildRecovery";

	public const string shop_animalSupplies = "AnimalShop";

	public const string shop_blacksmith = "Blacksmith";

	public const string shop_blacksmithUpgrades = "ClintUpgrade";

	public const string shop_boxOffice = "BoxOffice";

	public const string shop_catalogue = "Catalogue";

	public const string shop_carpenter = "Carpenter";

	public const string shop_casino = "Casino";

	public const string shop_desertTrader = "DesertTrade";

	public const string shop_dwarf = "Dwarf";

	public const string shop_fish = "FishShop";

	public const string shop_furnitureCatalogue = "Furniture Catalogue";

	public const string shop_generalStore = "SeedShop";

	public const string shop_hatMouse = "HatMouse";

	public const string shop_hospital = "Hospital";

	public const string shop_iceCreamStand = "IceCreamStand";

	public const string shop_islandTrader = "IslandTrade";

	public const string shop_jojaMart = "Joja";

	public const string shop_krobus = "ShadowShop";

	public const string shop_qiGemShop = "QiGemShop";

	public const string shop_resortBar = "ResortBar";

	public const string shop_sandy = "Sandy";

	public const string shop_saloon = "Saloon";

	public const string shop_travelingCart = "Traveler";

	public const string shop_volcanoShop = "VolcanoShop";

	public const string shop_bookseller = "Bookseller";

	public const string shop_bookseller_trade = "BooksellerTrade";

	public const string shop_jojaCatalogue = "JojaFurnitureCatalogue";

	public const string shop_wizardCatalogue = "WizardFurnitureCatalogue";

	public const string shop_junimoCatalogue = "JunimoFurnitureCatalogue";

	public const string shop_retroCatalogue = "RetroFurnitureCatalogue";

	public const string shop_trashCatalogue = "TrashFurnitureCatalogue";

	public const string shop_petAdoption = "PetAdoption";

	public const byte singlePlayer = 0;

	public const byte multiplayerClient = 1;

	public const byte multiplayerServer = 2;

	public const byte logoScreenGameMode = 4;

	public const byte titleScreenGameMode = 0;

	public const byte loadScreenGameMode = 1;

	public const byte newGameMode = 2;

	public const byte playingGameMode = 3;

	public const byte loadingMode = 6;

	public const byte saveMode = 7;

	public const byte saveCompleteMode = 8;

	public const byte selectGameScreen = 9;

	public const byte creditsMode = 10;

	public const byte errorLogMode = 11;

	public static readonly string GameAssemblyName;

	public static readonly string version;

	public static readonly string versionLabel;

	public static readonly int versionBuildNumber;

	public const float keyPollingThreshold = 650f;

	public const float toolHoldPerPowerupLevel = 600f;

	public const float startingMusicVolume = 1f;

	public LocalizedContentManager xTileContent;

	public static DelayedAction morningSongPlayAction;

	private static LocalizedContentManager _temporaryContent;

	[NonInstancedStatic]
	private static bool FinishedIncrementalLoad;

	[NonInstancedStatic]
	private static bool FinishedFirstLoadContent;

	[NonInstancedStatic]
	private static volatile bool FinishedFirstInitSounds;

	[NonInstancedStatic]
	private static volatile bool FinishedFirstInitSerializers;

	[NonInstancedStatic]
	private static IEnumerator<int> LoadContentEnumerator;

	[NonInstancedStatic]
	public static GraphicsDeviceManager graphics;

	[NonInstancedStatic]
	public static LocalizedContentManager content;

	public static SpriteBatch spriteBatch;

	public static float MusicDuckTimer;

	public static GamePadState oldPadState;

	public static float thumbStickSensitivity;

	public static float runThreshold;

	public static int rightStickHoldTime;

	public static int emoteMenuShowTime;

	public static int nextFarmerWarpOffsetX;

	public static int nextFarmerWarpOffsetY;

	public static KeyboardState oldKBState;

	public static MouseState oldMouseState;

	[NonInstancedStatic]
	public static Game1 keyboardFocusInstance;

	private static Farmer _player;

	public static NetFarmerRoot serverHost;

	protected static bool _isWarping;

	[NonInstancedStatic]
	public static bool hasLocalClientsOnly;

	protected bool _instanceIsPlayingBackgroundMusic;

	protected bool _instanceIsPlayingOutdoorsAmbience;

	protected bool _instanceIsPlayingNightAmbience;

	protected bool _instanceIsPlayingTownMusic;

	protected bool _instanceIsPlayingMorningSong;

	public static bool isUsingBackToFrontSorting;

	protected static StringBuilder _debugStringBuilder;

	[NonInstancedStatic]
	internal static readonly DebugTimings debugTimings;

	public static Dictionary<string, GameLocation> _locationLookup;

	public IList<GameLocation> _locations = new List<GameLocation>();

	public static Regex asianSpacingRegex;

	public static Viewport defaultDeviceViewport;

	public static LocationRequest locationRequest;

	public static bool warpingForForcedRemoteEvent;

	protected static GameLocation _PreviousNonNullLocation;

	public GameLocation instanceGameLocation;

	public static IDisplayDevice mapDisplayDevice;

	public static Rectangle viewport;

	public static Rectangle uiViewport;

	public static Texture2D objectSpriteSheet;

	public static Texture2D cropSpriteSheet;

	public static Texture2D emoteSpriteSheet;

	public static Texture2D debrisSpriteSheet;

	public static Texture2D rainTexture;

	public static Texture2D bigCraftableSpriteSheet;

	public static Texture2D buffsIcons;

	public static Texture2D daybg;

	public static Texture2D nightbg;

	public static Texture2D menuTexture;

	public static Texture2D uncoloredMenuTexture;

	public static Texture2D lantern;

	public static Texture2D windowLight;

	public static Texture2D sconceLight;

	public static Texture2D cauldronLight;

	public static Texture2D shadowTexture;

	public static Texture2D mouseCursors;

	public static Texture2D mouseCursors2;

	public static Texture2D mouseCursors_1_6;

	public static Texture2D giftboxTexture;

	public static Texture2D controllerMaps;

	public static Texture2D indoorWindowLight;

	public static Texture2D animations;

	public static Texture2D concessionsSpriteSheet;

	public static Texture2D birdsSpriteSheet;

	public static Texture2D objectSpriteSheet_2;

	public static Texture2D bobbersTexture;

	public static Dictionary<string, Stack<Dialogue>> npcDialogues;

	protected readonly List<Farmer> _farmerShadows = new List<Farmer>();

	public static Queue<Action> morningQueue;

	[NonInstancedStatic]
	protected internal static ModHooks hooks;

	public static InputState input;

	protected internal static IInputSimulator inputSimulator;

	public const string concessionsSpriteSheetName = "LooseSprites\\Concessions";

	public const string cropSpriteSheetName = "TileSheets\\crops";

	public const string objectSpriteSheetName = "Maps\\springobjects";

	public const string animationsName = "TileSheets\\animations";

	public const string mouseCursorsName = "LooseSprites\\Cursors";

	public const string mouseCursors2Name = "LooseSprites\\Cursors2";

	public const string mouseCursors1_6Name = "LooseSprites\\Cursors_1_6";

	public const string giftboxName = "LooseSprites\\Giftbox";

	public const string toolSpriteSheetName = "TileSheets\\tools";

	public const string bigCraftableSpriteSheetName = "TileSheets\\Craftables";

	public const string debrisSpriteSheetName = "TileSheets\\debris";

	public const string parrotSheetName = "LooseSprites\\parrots";

	public const string hatsSheetName = "Characters\\Farmer\\hats";

	public const string bobbersTextureName = "TileSheets\\bobbers";

	private static Texture2D _toolSpriteSheet;

	public static Dictionary<Vector2, int> crabPotOverlayTiles;

	protected static bool _setSaveName;

	protected static string _currentSaveName;

	public static List<string> mailDeliveredFromMailForTomorrow;

	private static RenderTarget2D _lightmap;

	public static Texture2D[] dynamicPixelRects;

	public static Texture2D fadeToBlackRect;

	public static Texture2D staminaRect;

	public static Texture2D lightingRect;

	public static SpriteFont dialogueFont;

	public static SpriteFont smallFont;

	public static SpriteFont tinyFont;

	public static float screenGlowAlpha;

	public static float flashAlpha;

	public static float noteBlockTimer;

	public static int currentGemBirdIndex;

	public Dictionary<string, object> newGameSetupOptions = new Dictionary<string, object>();

	public static bool dialogueUp;

	public static bool dialogueTyping;

	public static bool isQuestion;

	public static bool newDay;

	public static bool eventUp;

	public static bool viewportFreeze;

	public static bool eventOver;

	public static bool screenGlow;

	public static bool screenGlowHold;

	public static bool screenGlowUp;

	public static bool killScreen;

	public static bool messagePause;

	public static bool weddingToday;

	public static bool exitToTitle;

	public static bool debugMode;

	public static bool displayHUD;

	public static bool displayFarmer;

	public static bool dialogueButtonShrinking;

	public static bool drawLighting;

	public static bool quit;

	public static bool drawGrid;

	public static bool freezeControls;

	public static bool saveOnNewDay;

	public static bool panMode;

	public static bool showingEndOfNightStuff;

	public static bool wasRainingYesterday;

	public static bool hasLoadedGame;

	public static bool isActionAtCurrentCursorTile;

	public static bool isInspectionAtCurrentCursorTile;

	public static bool isSpeechAtCurrentCursorTile;

	public static bool paused;

	public static bool isTimePaused;

	public static bool frameByFrame;

	public static bool lastCursorMotionWasMouse;

	public static bool showingHealth;

	public static bool cabinsSeparate;

	public static bool showingHealthBar;

	public static bool hasStartedDay;

	public static HashSet<string> eventsSeenSinceLastLocationChange;

	internal static bool hasApplied1_3_UpdateChanges;

	internal static bool hasApplied1_4_UpdateChanges;

	private static Action postExitToTitleCallback;

	protected int _lastUsedDisplay = -1;

	public bool wasAskedLeoMemory;

	public float controllerSlingshotSafeTime;

	public static BundleType bundleType;

	public static bool isRaining;

	public static bool isSnowing;

	public static bool isLightning;

	public static bool isDebrisWeather;

	private static bool _isGreenRain;

	internal static bool wasGreenRain;

	internal static bool greenRainNeedsCleanup;

	public static Season? debrisWeatherSeason;

	public static string weatherForTomorrow;

	public float zoomModifier = 1f;

	private static ScreenFade screenFade;

	public static Season season;

	public static SerializableDictionary<string, string> bannedUsers;

	private static object _debugOutputLock;

	private static string _debugOutput;

	public static string requestedMusicTrack;

	public static string messageAfterPause;

	public static string samBandName;

	public static string loadingMessage;

	public static string errorMessage;

	protected Dictionary<MusicContext, KeyValuePair<string, bool>> _instanceRequestedMusicTracks = new Dictionary<MusicContext, KeyValuePair<string, bool>>();

	protected MusicContext _instanceActiveMusicContext;

	public static bool requestedMusicTrackOverrideable;

	public static bool currentTrackOverrideable;

	public static bool requestedMusicDirty;

	protected bool _useUnscaledLighting;

	protected bool _didInitiateItemStow;

	public bool instanceIsOverridingTrack;

	private static string[] _shortDayDisplayName;

	public static Queue<string> currentObjectDialogue;

	public static HashSet<string> worldStateIDs;

	public static List<Response> questionChoices;

	public static int xLocationAfterWarp;

	public static int yLocationAfterWarp;

	public static int gameTimeInterval;

	public static int currentQuestionChoice;

	public static int currentDialogueCharacterIndex;

	public static int dialogueTypingInterval;

	public static int dayOfMonth;

	public static int year;

	public static int timeOfDay;

	public static int timeOfDayAfterFade;

	public static int dialogueWidth;

	public static int facingDirectionAfterWarp;

	public static int mouseClickPolling;

	public static int gamePadXButtonPolling;

	public static int gamePadAButtonPolling;

	public static int weatherIcon;

	public static int hitShakeTimer;

	public static int staminaShakeTimer;

	public static int pauseThenDoFunctionTimer;

	public static int cursorTileHintCheckTimer;

	public static int timerUntilMouseFade;

	public static int whichFarm;

	public static int startingCabins;

	public static ModFarmType whichModFarm;

	public static ulong? startingGameSeed;

	public static int elliottPiano;

	public static Rectangle viewportClampArea;

	public static SaveFixes lastAppliedSaveFix;

	public static Color eveningColor;

	public static Color unselectedOptionColor;

	public static Color screenGlowColor;

	public static NPC currentSpeaker;

	public static Random random;

	public static Random recentMultiplayerRandom;

	public static Dictionary<int, string> achievements;

	public static IDictionary<string, BigCraftableData> bigCraftableData;

	public static IDictionary<string, BuildingData> buildingData;

	public static IDictionary<string, CharacterData> characterData;

	public static IDictionary<string, CropData> cropData;

	public static IDictionary<string, FarmAnimalData> farmAnimalData;

	public static IDictionary<string, FloorPathData> floorPathData;

	public static IDictionary<string, FruitTreeData> fruitTreeData;

	public static IDictionary<string, JukeboxTrackData> jukeboxTrackData;

	public static IDictionary<string, LocationData> locationData;

	public static IDictionary<string, LocationContextData> locationContextData;

	public static IDictionary<string, string> NPCGiftTastes;

	public static IDictionary<string, ObjectData> objectData;

	public static IDictionary<string, PantsData> pantsData;

	public static IDictionary<string, PetData> petData;

	public static IDictionary<string, ShirtData> shirtData;

	public static IDictionary<string, ToolData> toolData;

	public static IDictionary<string, WeaponData> weaponData;

	public static List<HUDMessage> hudMessages;

	public static float musicPlayerVolume;

	public static float ambientPlayerVolume;

	public static float pauseAccumulator;

	public static float pauseTime;

	public static float upPolling;

	public static float downPolling;

	public static float rightPolling;

	public static float leftPolling;

	public static float debrisSoundInterval;

	public static float windGust;

	public static float dialogueButtonScale;

	public ICue instanceCurrentSong;

	public static IAudioCategory musicCategory;

	public static IAudioCategory soundCategory;

	public static IAudioCategory ambientCategory;

	public static IAudioCategory footstepCategory;

	public PlayerIndex instancePlayerOneIndex;

	[NonInstancedStatic]
	public static IAudioEngine audioEngine;

	[NonInstancedStatic]
	public static WaveBank waveBank;

	[NonInstancedStatic]
	public static WaveBank waveBank1_4;

	[NonInstancedStatic]
	public static ISoundBank soundBank;

	public static Vector2 previousViewportPosition;

	public static Vector2 currentCursorTile;

	public static Vector2 lastCursorTile;

	public static Vector2 snowPos;

	public Rectangle localMultiplayerWindow;

	public static RainDrop[] rainDrops;

	public static ICue chargeUpSound;

	public static ICue wind;

	public static LoopingCueManager loopingLocationCues;

	public static ISoundsHelper sounds;

	[NonInstancedStatic]
	public static AudioCueModificationManager CueModification;

	public static List<WeatherDebris> debrisWeather;

	public static TemporaryAnimatedSpriteList screenOverlayTempSprites;

	public static TemporaryAnimatedSpriteList uiOverlayTempSprites;

	private static byte _gameMode;

	private bool _isSaving;

	[NonInstancedStatic]
	protected internal static IGameLogger log;

	[NonInstancedStatic]
	public static IHashUtility hash;

	protected internal static Multiplayer multiplayer;

	public static byte multiplayerMode;

	public static IEnumerator<int> currentLoader;

	public static ulong uniqueIDForThisGame;

	public static int[] directionKeyPolling;

	public static Dictionary<string, LightSource> currentLightSources;

	public static Color ambientLight;

	public static Color outdoorLight;

	public static Color textColor;

	public static Color textShadowColor;

	public static Color textShadowDarkerColor;

	public static IClickableMenu overlayMenu;

	private static IClickableMenu _activeClickableMenu;

	public static List<IClickableMenu> nextClickableMenu;

	public static List<Action> actionsWhenPlayerFree;

	public static bool isCheckingNonMousePlacement;

	private static IMinigame _currentMinigame;

	public static IList<IClickableMenu> onScreenMenus;

	public static BuffsDisplay buffsDisplay;

	public static DayTimeMoneyBox dayTimeMoneyBox;

	public static NetRootDictionary<long, Farmer> otherFarmers;

	private static readonly FarmerCollection _onlineFarmers;

	public static IGameServer server;

	public static Client client;

	public KeyboardDispatcher instanceKeyboardDispatcher;

	public static Background background;

	public static FarmEvent farmEvent;

	public static FarmEvent farmEventOverride;

	public static afterFadeFunction afterFade;

	public static afterFadeFunction afterDialogues;

	public static afterFadeFunction afterViewport;

	public static afterFadeFunction viewportReachedTarget;

	public static afterFadeFunction afterPause;

	public static GameTime currentGameTime;

	public static IList<DelayedAction> delayedActions;

	public static Stack<IClickableMenu> endOfNightMenus;

	public Options instanceOptions;

	[NonInstancedStatic]
	public static SerializableDictionary<long, Options> splitscreenOptions;

	public static Game1 game1;

	public static Point lastMousePositionBeforeFade;

	public static int ticks;

	public static EmoteMenu emoteMenu;

	[NonInstancedStatic]
	public static SerializableDictionary<string, string> CustomData;

	public static ReadySynchronizer netReady;

	public static DedicatedServer dedicatedServer;

	public static NetRoot<NetWorldState> netWorldState;

	public static ChatBox chatBox;

	public TextEntryMenu instanceTextEntry;

	public static SpecialCurrencyDisplay specialCurrencyDisplay;

	private static string debugPresenceString;

	public static List<Action> remoteEventQueue;

	public static List<long> weddingsToday;

	public int instanceIndex;

	public int instanceId;

	public static bool overrideGameMenuReset;

	protected bool _windowResizing;

	protected Point _oldMousePosition;

	protected bool _oldGamepadConnectedState;

	protected int _oldScrollWheelValue;

	public static Point viewportCenter;

	public static Vector2 viewportTarget;

	public static float viewportSpeed;

	public static int viewportHold;

	private static bool _cursorDragEnabled;

	private static bool _cursorDragPrevEnabled;

	private static bool _cursorSpeedDirty;

	private const float CursorBaseSpeed = 16f;

	private static float _cursorSpeed;

	private static float _cursorSpeedScale;

	private static float _cursorUpdateElapsedSec;

	private static int thumbstickPollingTimer;

	public static bool toggleFullScreen;

	public static string whereIsTodaysFest;

	public const string NO_LETTER_MAIL = "%&NL&%";

	public const string BROADCAST_MAIL_FOR_TOMORROW_PREFIX = "%&MFT&%";

	public const string BROADCAST_SEEN_MAIL_PREFIX = "%&SM&%";

	public const string BROADCAST_MAILBOX_PREFIX = "%&MB&%";

	public bool isLocalMultiplayerNewDayActive;

	protected static Task _newDayTask;

	private static Action _afterNewDayAction;

	public static NewDaySynchronizer newDaySync;

	public static bool forceSnapOnNextViewportUpdate;

	public static Vector2 currentViewportTarget;

	public static Vector2 viewportPositionLerp;

	public static float screenGlowRate;

	public static float screenGlowMax;

	public static bool haltAfterCheck;

	public static bool uiMode;

	public static RenderTarget2D nonUIRenderTarget;

	public static int uiModeCount;

	protected static int _oldUIModeCount;

	internal string panModeString;

	public static bool conventionMode;

	internal static EventTest eventTest;

	internal bool panFacingDirectionWait;

	public static bool isRunningMacro;

	public static int thumbstickMotionMargin;

	public static float thumbstickMotionAccell;

	public static int triggerPolling;

	public static int rightClickPolling;

	private RenderTarget2D _screen;

	private RenderTarget2D _uiScreen;

	public static Color bgColor;

	protected readonly BlendState lightingBlend = new BlendState
	{
		ColorBlendFunction = (BlendFunction)2,
		ColorDestinationBlend = (Blend)0,
		ColorSourceBlend = (Blend)2
	};

	public bool isDrawing;

	[NonInstancedStatic]
	public static bool isRenderingScreenBuffer;

	protected bool _lastDrewMouseCursor;

	protected static int _activatedTick;

	public static int mouseCursor;

	private static float _mouseCursorTransparency;

	public static bool wasMouseVisibleThisFrame;

	public static NPC objectDialoguePortraitPerson;

	protected static StringBuilder _ParseTextStringBuilder;

	protected static StringBuilder _ParseTextStringBuilderLine;

	protected static StringBuilder _ParseTextStringBuilderWord;

	public bool ScreenshotBusy;

	public bool takingMapScreenshot;

	public bool IsActiveNoOverlay
	{
		get
		{
			if (!base.IsActive)
			{
				return false;
			}
			if (Program.sdk.HasOverlay)
			{
				return false;
			}
			return true;
		}
	}

	public static LocalizedContentManager temporaryContent
	{
		get
		{
			if (_temporaryContent == null)
			{
				_temporaryContent = content.CreateTemporary();
			}
			return _temporaryContent;
		}
	}

	private bool ShouldLoadIncrementally => false;

	public static Farmer player
	{
		get
		{
			return _player;
		}
		internal set
		{
			_player?.unload();
			_player = value;
			_player.Items.IsLocalPlayerInventory = true;
		}
	}

	public static bool IsPlayingBackgroundMusic
	{
		get
		{
			return game1._instanceIsPlayingBackgroundMusic;
		}
		set
		{
			game1._instanceIsPlayingBackgroundMusic = value;
		}
	}

	public static bool IsPlayingOutdoorsAmbience
	{
		get
		{
			return game1._instanceIsPlayingOutdoorsAmbience;
		}
		set
		{
			game1._instanceIsPlayingOutdoorsAmbience = value;
		}
	}

	public static bool IsPlayingNightAmbience
	{
		get
		{
			return game1._instanceIsPlayingNightAmbience;
		}
		set
		{
			game1._instanceIsPlayingNightAmbience = value;
		}
	}

	public static bool IsPlayingTownMusic
	{
		get
		{
			return game1._instanceIsPlayingTownMusic;
		}
		set
		{
			game1._instanceIsPlayingTownMusic = value;
		}
	}

	public static bool IsPlayingMorningSong
	{
		get
		{
			return game1._instanceIsPlayingMorningSong;
		}
		set
		{
			game1._instanceIsPlayingMorningSong = value;
		}
	}

	public static bool isWarping => _isWarping;

	public static IList<GameLocation> locations => game1._locations;

	public static GameLocation currentLocation
	{
		get
		{
			return game1.instanceGameLocation;
		}
		set
		{
			if (game1.instanceGameLocation != value)
			{
				if (_PreviousNonNullLocation == null)
				{
					_PreviousNonNullLocation = game1.instanceGameLocation;
				}
				game1.instanceGameLocation = value;
				if (game1.instanceGameLocation != null)
				{
					GameLocation previousNonNullLocation = _PreviousNonNullLocation;
					_PreviousNonNullLocation = null;
					OnLocationChanged(previousNonNullLocation, game1.instanceGameLocation);
				}
			}
		}
	}

	public static Texture2D toolSpriteSheet
	{
		get
		{
			if (_toolSpriteSheet == null)
			{
				ResetToolSpriteSheet();
			}
			return _toolSpriteSheet;
		}
	}

	public static RenderTarget2D lightmap => _lightmap;

	public static bool IsHudDrawn
	{
		get
		{
			if ((displayHUD || eventUp) && gameMode == 3 && !freezeControls && !panMode && !HostPaused)
			{
				return !game1.takingMapScreenshot;
			}
			return false;
		}
	}

	public static bool isGreenRain
	{
		get
		{
			return _isGreenRain;
		}
		set
		{
			_isGreenRain = value;
			wasGreenRain |= value;
		}
	}

	public static bool spawnMonstersAtNight
	{
		get
		{
			return player.team.spawnMonstersAtNight.Value;
		}
		set
		{
			player.team.spawnMonstersAtNight.Value = value;
		}
	}

	public static bool UseLegacyRandom
	{
		get
		{
			return player.team.useLegacyRandom.Value;
		}
		set
		{
			player.team.useLegacyRandom.Value = value;
		}
	}

	public static bool fadeToBlack
	{
		get
		{
			return screenFade.fadeToBlack;
		}
		set
		{
			screenFade.fadeToBlack = value;
		}
	}

	public static bool fadeIn
	{
		get
		{
			return screenFade.fadeIn;
		}
		set
		{
			screenFade.fadeIn = value;
		}
	}

	public static bool globalFade
	{
		get
		{
			return screenFade.globalFade;
		}
		set
		{
			screenFade.globalFade = value;
		}
	}

	public static bool nonWarpFade
	{
		get
		{
			return screenFade.nonWarpFade;
		}
		set
		{
			screenFade.nonWarpFade = value;
		}
	}

	public static float fadeToBlackAlpha
	{
		get
		{
			return screenFade.fadeToBlackAlpha;
		}
		set
		{
			screenFade.fadeToBlackAlpha = value;
		}
	}

	public static float globalFadeSpeed
	{
		get
		{
			return screenFade.globalFadeSpeed;
		}
		set
		{
			screenFade.globalFadeSpeed = value;
		}
	}

	public static string CurrentSeasonDisplayName => content.LoadString("Strings\\StringsFromCSFiles:" + currentSeason);

	public static string currentSeason
	{
		get
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			return Utility.getSeasonKey(season);
		}
		set
		{
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			if (Utility.TryParseEnum<Season>(value, out Season parsed))
			{
				season = parsed;
				return;
			}
			throw new ArgumentException("Can't parse value '" + value + "' as a season name.");
		}
	}

	public static int seasonIndex => (int)season;

	public static string debugOutput
	{
		get
		{
			return _debugOutput;
		}
		set
		{
			lock (_debugOutputLock)
			{
				if (_debugOutput != value)
				{
					_debugOutput = value;
					if (!string.IsNullOrEmpty(_debugOutput))
					{
						log.Debug("DebugOutput: " + _debugOutput);
					}
				}
			}
		}
	}

	public static string elliottBookName
	{
		get
		{
			if (player != null && player.DialogueQuestionsAnswered.Contains("958699"))
			{
				return content.LoadString("Strings\\Events:ElliottBook_mystery");
			}
			if (player != null && player.DialogueQuestionsAnswered.Contains("958700"))
			{
				return content.LoadString("Strings\\Events:ElliottBook_romance");
			}
			return content.LoadString("Strings\\Events:ElliottBook_default");
		}
		set
		{
		}
	}

	protected static Dictionary<MusicContext, KeyValuePair<string, bool>> _requestedMusicTracks
	{
		get
		{
			return game1._instanceRequestedMusicTracks;
		}
		set
		{
			game1._instanceRequestedMusicTracks = value;
		}
	}

	protected static MusicContext _activeMusicContext
	{
		get
		{
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			return game1._instanceActiveMusicContext;
		}
		set
		{
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			game1._instanceActiveMusicContext = value;
		}
	}

	public static bool isOverridingTrack
	{
		get
		{
			return game1.instanceIsOverridingTrack;
		}
		set
		{
			game1.instanceIsOverridingTrack = value;
		}
	}

	public bool useUnscaledLighting
	{
		get
		{
			return _useUnscaledLighting;
		}
		set
		{
			if (_useUnscaledLighting != value)
			{
				_useUnscaledLighting = value;
				allocateLightmap(localMultiplayerWindow.Width, localMultiplayerWindow.Height);
			}
		}
	}

	public static IList<string> mailbox => player.mailbox;

	public static ICue currentSong
	{
		get
		{
			return game1.instanceCurrentSong;
		}
		set
		{
			game1.instanceCurrentSong = value;
		}
	}

	public static PlayerIndex playerOneIndex
	{
		get
		{
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			return game1.instancePlayerOneIndex;
		}
		set
		{
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			game1.instancePlayerOneIndex = value;
		}
	}

	public static int gameModeTicks { get; private set; }

	public static byte gameMode
	{
		get
		{
			return _gameMode;
		}
		set
		{
			if (_gameMode != value)
			{
				log.Verbose("gameMode was '" + GameModeToString(_gameMode) + "', set to '" + GameModeToString(value) + "'.");
				_gameMode = value;
				gameModeTicks = 0;
			}
		}
	}

	public bool IsSaving
	{
		get
		{
			return _isSaving;
		}
		set
		{
			_isSaving = value;
		}
	}

	public static Multiplayer Multiplayer => multiplayer;

	public static Stats stats => player.stats;

	public static Quest questOfTheDay => netWorldState.Value.QuestOfTheDay;

	public static IClickableMenu activeClickableMenu
	{
		get
		{
			return _activeClickableMenu;
		}
		set
		{
			bool num = (activeClickableMenu is SaveGameMenu || activeClickableMenu is ShippingMenu) && !(value is SaveGameMenu) && !(value is ShippingMenu);
			if (_activeClickableMenu is IDisposable disposable && !_activeClickableMenu.HasDependencies())
			{
				disposable.Dispose();
			}
			if (textEntry != null && _activeClickableMenu != value)
			{
				closeTextEntry();
			}
			if (_activeClickableMenu != null && value == null)
			{
				timerUntilMouseFade = 0;
			}
			_activeClickableMenu = value;
			if (num)
			{
				OnDayStarted();
			}
			if (_activeClickableMenu != null)
			{
				if (!eventUp || (CurrentEvent != null && CurrentEvent.playerControlSequence && !player.UsingTool))
				{
					player.Halt();
				}
			}
			else if (nextClickableMenu.Count > 0)
			{
				activeClickableMenu = nextClickableMenu[0];
				nextClickableMenu.RemoveAt(0);
			}
		}
	}

	public static IMinigame currentMinigame
	{
		get
		{
			return _currentMinigame;
		}
		set
		{
			_currentMinigame = value;
			if (value == null)
			{
				if (currentLocation != null)
				{
					setRichPresence("location", currentLocation.Name);
				}
				randomizeDebrisWeatherPositions(debrisWeather);
				randomizeRainPositions();
			}
			else if (value.minigameId() != null)
			{
				setRichPresence("minigame", value.minigameId());
			}
		}
	}

	public static Object dishOfTheDay
	{
		get
		{
			return netWorldState.Value.DishOfTheDay;
		}
		set
		{
			netWorldState.Value.DishOfTheDay = value;
		}
	}

	public static KeyboardDispatcher keyboardDispatcher
	{
		get
		{
			return game1.instanceKeyboardDispatcher;
		}
		set
		{
			game1.instanceKeyboardDispatcher = value;
		}
	}

	public static Options options
	{
		get
		{
			return game1.instanceOptions;
		}
		set
		{
			game1.instanceOptions = value;
		}
	}

	public static TextEntryMenu textEntry
	{
		get
		{
			return game1.instanceTextEntry;
		}
		set
		{
			game1.instanceTextEntry = value;
		}
	}

	public static WorldDate Date => netWorldState.Value.Date;

	public static bool NetTimePaused => netWorldState.Get().IsTimePaused;

	public static bool HostPaused => netWorldState.Get().IsPaused;

	public static bool IsMultiplayer => otherFarmers.Count > 0;

	public static bool IsClient => multiplayerMode == 1;

	public static bool IsServer => multiplayerMode == 2;

	public static bool IsMasterGame
	{
		get
		{
			if (multiplayerMode != 0)
			{
				return multiplayerMode == 2;
			}
			return true;
		}
	}

	public static bool HasDedicatedHost
	{
		get
		{
			if (multiplayerMode != 0)
			{
				return player?.team?.hasDedicatedHost.Value == true;
			}
			return false;
		}
	}

	public static bool IsDedicatedHost
	{
		get
		{
			if (IsServer)
			{
				return HasDedicatedHost;
			}
			return false;
		}
	}

	public static Farmer MasterPlayer
	{
		get
		{
			if (!IsMasterGame)
			{
				return serverHost.Value;
			}
			return player;
		}
	}

	public static bool IsChatting
	{
		get
		{
			if (chatBox != null)
			{
				return chatBox.isActive();
			}
			return false;
		}
		set
		{
			if (value != chatBox.isActive())
			{
				if (value)
				{
					chatBox.activate();
				}
				else
				{
					chatBox.clickAway();
				}
			}
		}
	}

	public static Event CurrentEvent
	{
		get
		{
			if (currentLocation == null)
			{
				return null;
			}
			return currentLocation.currentEvent;
		}
	}

	public static MineShaft mine => (locationRequest?.Location as MineShaft) ?? (currentLocation as MineShaft);

	public static int CurrentMineLevel => (currentLocation as MineShaft)?.mineLevel ?? 0;

	public static int CurrentPlayerLimit
	{
		get
		{
			if (netWorldState?.Value != null)
			{
				_ = netWorldState.Value.CurrentPlayerLimit;
				return netWorldState.Value.CurrentPlayerLimit;
			}
			return multiplayer.playerLimit;
		}
	}

	private static float thumbstickToMouseModifier
	{
		get
		{
			if (_cursorSpeedDirty)
			{
				ComputeCursorSpeed();
			}
			return _cursorSpeed / 720f * (float)((Rectangle)(ref viewport)).Height * (float)currentGameTime.ElapsedGameTime.TotalSeconds;
		}
	}

	public static bool isFullscreen => graphics.IsFullScreen;

	public static bool IsSummer => (int)season == 1;

	public static bool IsSpring => (int)season == 0;

	public static bool IsFall => (int)season == 2;

	public static bool IsWinter => (int)season == 3;

	public RenderTarget2D screen
	{
		get
		{
			return _screen;
		}
		set
		{
			if (_screen != null)
			{
				((GraphicsResource)_screen).Dispose();
				_screen = null;
			}
			_screen = value;
		}
	}

	public RenderTarget2D uiScreen
	{
		get
		{
			return _uiScreen;
		}
		set
		{
			if (_uiScreen != null)
			{
				((GraphicsResource)_uiScreen).Dispose();
				_uiScreen = null;
			}
			_uiScreen = value;
		}
	}

	public static float mouseCursorTransparency
	{
		get
		{
			return _mouseCursorTransparency;
		}
		set
		{
			_mouseCursorTransparency = value;
		}
	}

	public static void GetHasRoomAnotherFarmAsync(ReportHasRoomAnotherFarmDelegate callback)
	{
		if (LocalMultiplayer.IsLocalMultiplayer())
		{
			bool hasRoomAnotherFarm = GetHasRoomAnotherFarm();
			callback(hasRoomAnotherFarm);
			return;
		}
		Task task = new Task(delegate
		{
			Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
			bool hasRoomAnotherFarm2 = GetHasRoomAnotherFarm();
			callback(hasRoomAnotherFarm2);
		});
		hooks.StartTask(task, "Farm_SpaceCheck");
	}

	private static string GameModeToString(byte mode)
	{
		return mode switch
		{
			4 => $"logoScreenGameMode ({mode})", 
			0 => $"titleScreenGameMode ({mode})", 
			1 => $"loadScreenGameMode ({mode})", 
			2 => $"newGameMode ({mode})", 
			3 => $"playingGameMode ({mode})", 
			6 => $"loadingMode ({mode})", 
			7 => $"saveMode ({mode})", 
			8 => $"saveCompleteMode ({mode})", 
			9 => $"selectGameScreen ({mode})", 
			10 => $"creditsMode ({mode})", 
			11 => $"errorLogMode ({mode})", 
			_ => $"unknown ({mode})", 
		};
	}

	public static string GetVersionString()
	{
		string text = version;
		if (!string.IsNullOrEmpty(versionLabel))
		{
			text = text + " '" + versionLabel + "'";
		}
		if (versionBuildNumber > 0)
		{
			text = text + " build " + versionBuildNumber;
		}
		return text;
	}

	public static void ResetToolSpriteSheet()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Expected O, but got Unknown
		if (_toolSpriteSheet != null)
		{
			((GraphicsResource)_toolSpriteSheet).Dispose();
			_toolSpriteSheet = null;
		}
		Texture2D val = content.Load<Texture2D>("TileSheets\\tools");
		int width = val.Width;
		int height = val.Height;
		Texture2D val2 = new Texture2D(game1.GraphicsDevice, width, height, false, (SurfaceFormat)0)
		{
			Name = ((GraphicsResource)val).Name
		};
		Color[] array = (Color[])(object)new Color[width * height];
		val.GetData<Color>(array);
		val2.SetData<Color>(array);
		_toolSpriteSheet = val2;
	}

	public static void SetSaveName(string new_save_name)
	{
		if (new_save_name == null)
		{
			new_save_name = "";
		}
		_currentSaveName = new_save_name;
		_setSaveName = true;
	}

	public static string GetSaveGameName(bool set_value = true)
	{
		if (!_setSaveName && set_value)
		{
			string value = MasterPlayer.farmName.Value;
			string text = value;
			int num = 2;
			while (SaveGame.IsNewGameSaveNameCollision(text))
			{
				text = value + num;
				num++;
			}
			SetSaveName(text);
		}
		return _currentSaveName;
	}

	private static void allocateLightmap(int width, int height)
	{
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Expected O, but got Unknown
		int num = 8;
		float num2 = 1f;
		if (options != null)
		{
			num = options.lightingQuality;
			num2 = ((!game1.useUnscaledLighting) ? options.zoomLevel : 1f);
		}
		int num3 = (int)((float)width * (1f / num2) + 64f) / (num / 2);
		int num4 = (int)((float)height * (1f / num2) + 64f) / (num / 2);
		RenderTarget2D obj = lightmap;
		if (obj == null || ((Texture2D)obj).Width != num3 || ((Texture2D)lightmap).Height != num4)
		{
			RenderTarget2D obj2 = _lightmap;
			if (obj2 != null)
			{
				((GraphicsResource)obj2).Dispose();
			}
			_lightmap = new RenderTarget2D(graphics.GraphicsDevice, num3, num4, false, (SurfaceFormat)0, (DepthFormat)0, 0, (RenderTargetUsage)1);
		}
	}

	public static bool canHaveWeddingOnDay(int day, Season season)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		if (!Utility.isFestivalDay(day, season))
		{
			return !Utility.isGreenRainDay(day, season);
		}
		return false;
	}

	public static void RefreshQuestOfTheDay()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		Quest quest = ((!Utility.isFestivalDay() && !Utility.isFestivalDay(dayOfMonth + 1, season)) ? Utility.getQuestOfTheDay() : null);
		quest?.dailyQuest.Set(newValue: true);
		quest?.reloadObjective();
		quest?.reloadDescription();
		netWorldState.Value.SetQuestOfTheDay(quest);
	}

	public static void ExitToTitle(Action postExitCallback = null)
	{
		currentMinigame?.unload();
		_requestedMusicTracks.Clear();
		UpdateRequestedMusicTrack();
		changeMusicTrack("none", track_interruptable: false, (MusicContext)0);
		setGameMode(0);
		exitToTitle = true;
		postExitToTitleCallback = postExitCallback;
	}

	static Game1()
	{
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03da: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0400: Unknown result type (might be due to invalid IL or missing references)
		//IL_0405: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_041b: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_054a: Unknown result type (might be due to invalid IL or missing references)
		//IL_054f: Unknown result type (might be due to invalid IL or missing references)
		realMilliSecondsPerGameMinute = 700;
		realMilliSecondsPerGameTenMinutes = realMilliSecondsPerGameMinute * 10;
		cursor_none = -1;
		cursor_default = 0;
		cursor_wait = 1;
		cursor_grab = 2;
		cursor_gift = 3;
		cursor_talk = 4;
		cursor_look = 5;
		cursor_harvest = 6;
		cursor_gamepad_pointer = 44;
		asianSpacingRegexString = "\\s|[（《“‘「『(](?:[\\w,%％]+|[^…—])[々ぁぃぅぇぉっゃゅょゎゕゖァィゥェォッャュョヶー]*[）》”’」』)，。、？！：；·～,.?!:;~…]*|.[々ぁぃぅぇぉっゃゅょゎゕゖァィゥェォッャュョヶー]*[·・].[々ぁぃぅぇぉっゃゅょゎゕゖァィゥェォッャュョヶー]*|(?:[\\w,%％]+|[^…—])[々ぁぃぅぇぉっゃゅょゎゕゖァィゥェォッャュョヶー]*[）》”’」』)]?(?:[，。、？！：；·～,.?!:;~…]{1,2}[）》”’」』)]?)?|[\\w,%％]+|.[々ぁぃぅぇぉっゃゅょゎゕゖァィゥェォッャュョヶー]+|……|——|.";
		FinishedIncrementalLoad = false;
		FinishedFirstLoadContent = false;
		FinishedFirstInitSounds = false;
		FinishedFirstInitSerializers = false;
		MusicDuckTimer = 0f;
		thumbStickSensitivity = 0.1f;
		runThreshold = 0.5f;
		rightStickHoldTime = 0;
		emoteMenuShowTime = 250;
		nextFarmerWarpOffsetX = 0;
		nextFarmerWarpOffsetY = 0;
		keyboardFocusInstance = null;
		_isWarping = false;
		hasLocalClientsOnly = false;
		isUsingBackToFrontSorting = false;
		_debugStringBuilder = new StringBuilder();
		debugTimings = new DebugTimings();
		_locationLookup = new Dictionary<string, GameLocation>(StringComparer.OrdinalIgnoreCase);
		asianSpacingRegex = new Regex(asianSpacingRegexString, RegexOptions.ECMAScript);
		warpingForForcedRemoteEvent = false;
		_PreviousNonNullLocation = null;
		npcDialogues = new Dictionary<string, Stack<Dialogue>>();
		morningQueue = new Queue<Action>();
		hooks = new ModHooks();
		input = new InputState();
		inputSimulator = null;
		_toolSpriteSheet = null;
		crabPotOverlayTiles = new Dictionary<Vector2, int>();
		_setSaveName = false;
		_currentSaveName = "";
		mailDeliveredFromMailForTomorrow = new List<string>();
		dynamicPixelRects = (Texture2D[])(object)new Texture2D[3];
		screenGlowAlpha = 0f;
		flashAlpha = 0f;
		currentGemBirdIndex = 0;
		dialogueUp = false;
		dialogueTyping = false;
		isQuestion = false;
		newDay = false;
		eventUp = false;
		viewportFreeze = false;
		eventOver = false;
		screenGlow = false;
		screenGlowHold = false;
		killScreen = false;
		displayHUD = true;
		displayFarmer = true;
		showingHealth = false;
		cabinsSeparate = false;
		showingHealthBar = false;
		hasStartedDay = false;
		eventsSeenSinceLastLocationChange = new HashSet<string>();
		hasApplied1_3_UpdateChanges = false;
		hasApplied1_4_UpdateChanges = false;
		postExitToTitleCallback = null;
		bundleType = BundleType.Default;
		isRaining = false;
		isSnowing = false;
		isLightning = false;
		isDebrisWeather = false;
		_isGreenRain = false;
		wasGreenRain = false;
		greenRainNeedsCleanup = false;
		season = (Season)0;
		bannedUsers = new SerializableDictionary<string, string>();
		_debugOutputLock = new object();
		requestedMusicTrack = "";
		messageAfterPause = "";
		samBandName = "The Alfalfas";
		loadingMessage = "";
		errorMessage = "";
		requestedMusicDirty = false;
		_shortDayDisplayName = new string[7];
		currentObjectDialogue = new Queue<string>();
		worldStateIDs = new HashSet<string>();
		questionChoices = new List<Response>();
		dayOfMonth = 0;
		year = 1;
		timeOfDay = 600;
		timeOfDayAfterFade = -1;
		whichModFarm = null;
		startingGameSeed = null;
		elliottPiano = 0;
		viewportClampArea = Rectangle.Empty;
		eveningColor = new Color(255, 255, 0);
		unselectedOptionColor = new Color(100, 100, 100);
		random = new Random();
		recentMultiplayerRandom = new Random();
		hudMessages = new List<HUDMessage>();
		dialogueButtonScale = 1f;
		lastCursorTile = Vector2.Zero;
		rainDrops = new RainDrop[70];
		loopingLocationCues = new LoopingCueManager();
		sounds = new SoundsHelper();
		CueModification = new AudioCueModificationManager();
		debrisWeather = new List<WeatherDebris>();
		screenOverlayTempSprites = new TemporaryAnimatedSpriteList();
		uiOverlayTempSprites = new TemporaryAnimatedSpriteList();
		log = new DefaultLogger(!Program.releaseBuild, shouldWriteToLogFile: false);
		hash = new HashUtility();
		multiplayer = new Multiplayer();
		uniqueIDForThisGame = Utility.NewUniqueIdForThisGame();
		directionKeyPolling = new int[4];
		currentLightSources = new Dictionary<string, LightSource>();
		outdoorLight = new Color(255, 255, 0);
		textColor = new Color(34, 17, 34);
		textShadowColor = new Color(206, 156, 95);
		textShadowDarkerColor = new Color(221, 148, 84);
		nextClickableMenu = new List<IClickableMenu>();
		actionsWhenPlayerFree = new List<Action>();
		isCheckingNonMousePlacement = false;
		_currentMinigame = null;
		onScreenMenus = new List<IClickableMenu>();
		_onlineFarmers = new FarmerCollection();
		delayedActions = new List<DelayedAction>();
		endOfNightMenus = new Stack<IClickableMenu>();
		splitscreenOptions = new SerializableDictionary<long, Options>();
		CustomData = new SerializableDictionary<string, string>();
		netReady = new ReadySynchronizer();
		dedicatedServer = new DedicatedServer();
		specialCurrencyDisplay = null;
		remoteEventQueue = new List<Action>();
		weddingsToday = new List<long>();
		viewportTarget = new Vector2(-2.1474836E+09f, -2.1474836E+09f);
		viewportSpeed = 2f;
		_cursorDragEnabled = false;
		_cursorDragPrevEnabled = false;
		_cursorSpeedDirty = true;
		_cursorSpeed = 16f;
		_cursorSpeedScale = 1f;
		_cursorUpdateElapsedSec = 0f;
		newDaySync = new NewDaySynchronizer();
		forceSnapOnNextViewportUpdate = false;
		screenGlowRate = 0.005f;
		haltAfterCheck = false;
		uiMode = false;
		nonUIRenderTarget = null;
		uiModeCount = 0;
		_oldUIModeCount = 0;
		conventionMode = false;
		isRunningMacro = false;
		thumbstickMotionAccell = 1f;
		bgColor = new Color(5, 3, 4);
		isRenderingScreenBuffer = false;
		_activatedTick = 0;
		mouseCursor = cursor_default;
		_mouseCursorTransparency = 1f;
		wasMouseVisibleThisFrame = true;
		_ParseTextStringBuilder = new StringBuilder(2408);
		_ParseTextStringBuilderLine = new StringBuilder(1024);
		_ParseTextStringBuilderWord = new StringBuilder(256);
		GameAssemblyName = typeof(Game1).Assembly.GetName().Name;
		AssemblyInformationalVersionAttribute customAttribute = typeof(Game1).Assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>();
		if (!string.IsNullOrWhiteSpace(customAttribute?.InformationalVersion))
		{
			string[] array = customAttribute.InformationalVersion.Split(',');
			if (array.Length == 4)
			{
				version = array[0].Trim();
				if (!string.IsNullOrWhiteSpace(array[1]))
				{
					versionLabel = array[1].Trim();
				}
				if (!string.IsNullOrWhiteSpace(array[2]))
				{
					if (!int.TryParse(array[2], out var result))
					{
						throw new InvalidOperationException("Can't parse game build number value '" + array[2] + "' as a number.");
					}
					versionBuildNumber = result;
				}
				if (!string.IsNullOrWhiteSpace(array[3]))
				{
					Multiplayer.protocolVersionOverride = array[3].Trim();
				}
			}
		}
		if (string.IsNullOrWhiteSpace(version))
		{
			throw new InvalidOperationException("No game version found in assembly info.");
		}
	}

	public Game1(PlayerIndex player_index, int index)
		: this()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		instancePlayerOneIndex = player_index;
		instanceIndex = index;
	}

	public Game1()
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Expected O, but got Unknown
		instanceId = GameRunner.instance.GetNewInstanceID();
		if (Program.gamePtr == null)
		{
			Program.gamePtr = this;
		}
		_temporaryContent = CreateContentManager(base.Content.ServiceProvider, base.Content.RootDirectory);
	}

	public void TranslateFields()
	{
		LocalizedContentManager.localizedAssetNames.Clear();
		BaseEnchantment.ResetEnchantments();
		samBandName = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2156");
		elliottBookName = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2157");
		objectSpriteSheet = content.Load<Texture2D>("Maps\\springobjects");
		objectSpriteSheet_2 = content.Load<Texture2D>("TileSheets\\Objects_2");
		bobbersTexture = content.Load<Texture2D>("TileSheets\\bobbers");
		dialogueFont = content.Load<SpriteFont>("Fonts\\SpriteFont1");
		smallFont = content.Load<SpriteFont>("Fonts\\SmallFont");
		smallFont.LineSpacing = 28;
		switch (LocalizedContentManager.CurrentLanguageCode)
		{
		case LocalizedContentManager.LanguageCode.ko:
		{
			SpriteFont obj2 = smallFont;
			obj2.LineSpacing += 16;
			break;
		}
		case LocalizedContentManager.LanguageCode.tr:
		{
			SpriteFont obj = smallFont;
			obj.LineSpacing += 4;
			break;
		}
		case LocalizedContentManager.LanguageCode.mod:
			smallFont.LineSpacing = LocalizedContentManager.CurrentModLanguage.SmallFontLineSpacing;
			break;
		}
		tinyFont = content.Load<SpriteFont>("Fonts\\tinyFont");
		objectData = DataLoader.Objects(content);
		bigCraftableData = DataLoader.BigCraftables(content);
		achievements = DataLoader.Achievements(content);
		CraftingRecipe.craftingRecipes = DataLoader.CraftingRecipes(content);
		CraftingRecipe.cookingRecipes = DataLoader.CookingRecipes(content);
		ItemRegistry.ResetCache();
		MovieTheater.ClearCachedLocalizedData();
		mouseCursors = content.Load<Texture2D>("LooseSprites\\Cursors");
		mouseCursors2 = content.Load<Texture2D>("LooseSprites\\Cursors2");
		mouseCursors_1_6 = content.Load<Texture2D>("LooseSprites\\Cursors_1_6");
		giftboxTexture = content.Load<Texture2D>("LooseSprites\\Giftbox");
		controllerMaps = content.Load<Texture2D>("LooseSprites\\ControllerMaps");
		NPCGiftTastes = DataLoader.NpcGiftTastes(content);
		_shortDayDisplayName[0] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3042");
		_shortDayDisplayName[1] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3043");
		_shortDayDisplayName[2] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3044");
		_shortDayDisplayName[3] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3045");
		_shortDayDisplayName[4] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3046");
		_shortDayDisplayName[5] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3047");
		_shortDayDisplayName[6] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3048");
	}

	public void exitEvent(object sender, EventArgs e)
	{
		multiplayer.Disconnect(Multiplayer.DisconnectType.ClosedGame);
		keyboardDispatcher.Cleanup();
	}

	public void refreshWindowSettings()
	{
		GameRunner.instance.OnWindowSizeChange(null, null);
	}

	public void Window_ClientSizeChanged(object sender, EventArgs e)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		if (_windowResizing)
		{
			return;
		}
		log.Verbose("Window_ClientSizeChanged(); Window.ClientBounds=" + ((object)base.Window.ClientBounds/*cast due to .constrained prefix*/).ToString());
		if (options == null)
		{
			log.Verbose("Window_ClientSizeChanged(); options is null, returning.");
			return;
		}
		_windowResizing = true;
		int w = (graphics.IsFullScreen ? graphics.PreferredBackBufferWidth : base.Window.ClientBounds.Width);
		int h = (graphics.IsFullScreen ? graphics.PreferredBackBufferHeight : base.Window.ClientBounds.Height);
		GameRunner.instance.ExecuteForInstances(delegate(Game1 instance)
		{
			instance.SetWindowSize(w, h);
		});
		_windowResizing = false;
	}

	public virtual void SetWindowSize(int w, int h)
	{
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_037d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0398: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0410: Unknown result type (might be due to invalid IL or missing references)
		//IL_0420: Expected O, but got Unknown
		//IL_0474: Unknown result type (might be due to invalid IL or missing references)
		//IL_0479: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Expected O, but got Unknown
		//IL_0542: Unknown result type (might be due to invalid IL or missing references)
		//IL_056b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d0: Unknown result type (might be due to invalid IL or missing references)
		Rectangle oldBounds = default(Rectangle);
		((Rectangle)(ref oldBounds))._002Ector(((Rectangle)(ref viewport)).X, ((Rectangle)(ref viewport)).Y, ((Rectangle)(ref viewport)).Width, ((Rectangle)(ref viewport)).Height);
		if (Environment.OSVersion.Platform == PlatformID.Win32NT)
		{
			if (w < 1280 && !graphics.IsFullScreen)
			{
				w = 1280;
			}
			if (h < 720 && !graphics.IsFullScreen)
			{
				h = 720;
			}
		}
		if (!graphics.IsFullScreen && base.Window.AllowUserResizing)
		{
			graphics.PreferredBackBufferWidth = w;
			graphics.PreferredBackBufferHeight = h;
		}
		if (base.IsMainInstance && graphics.SynchronizeWithVerticalRetrace != options.vsyncEnabled)
		{
			graphics.SynchronizeWithVerticalRetrace = options.vsyncEnabled;
			log.Verbose("Vsync toggled: " + graphics.SynchronizeWithVerticalRetrace);
		}
		graphics.ApplyChanges();
		try
		{
			if (graphics.IsFullScreen)
			{
				localMultiplayerWindow = new Rectangle(0, 0, graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight);
			}
			else
			{
				localMultiplayerWindow = new Rectangle(0, 0, w, h);
			}
		}
		catch (Exception)
		{
		}
		defaultDeviceViewport = new Viewport(localMultiplayerWindow);
		List<Vector4> list = new List<Vector4>();
		if (GameRunner.instance.gameInstances.Count <= 1)
		{
			list.Add(new Vector4(0f, 0f, 1f, 1f));
		}
		else
		{
			switch (GameRunner.instance.gameInstances.Count)
			{
			case 2:
				list.Add(new Vector4(0f, 0f, 0.5f, 1f));
				list.Add(new Vector4(0.5f, 0f, 0.5f, 1f));
				break;
			case 3:
				list.Add(new Vector4(0f, 0f, 1f, 0.5f));
				list.Add(new Vector4(0f, 0.5f, 0.5f, 0.5f));
				list.Add(new Vector4(0.5f, 0.5f, 0.5f, 0.5f));
				break;
			case 4:
				list.Add(new Vector4(0f, 0f, 0.5f, 0.5f));
				list.Add(new Vector4(0.5f, 0f, 0.5f, 0.5f));
				list.Add(new Vector4(0f, 0.5f, 0.5f, 0.5f));
				list.Add(new Vector4(0.5f, 0.5f, 0.5f, 0.5f));
				break;
			}
		}
		if (GameRunner.instance.gameInstances.Count <= 1)
		{
			zoomModifier = 1f;
		}
		else
		{
			zoomModifier = 0.5f;
		}
		Vector4 val = list[game1.instanceIndex];
		Vector2? val2 = null;
		if (uiScreen != null)
		{
			val2 = new Vector2((float)((Texture2D)uiScreen).Width, (float)((Texture2D)uiScreen).Height);
		}
		localMultiplayerWindow.X = (int)((float)w * val.X);
		localMultiplayerWindow.Y = (int)((float)h * val.Y);
		localMultiplayerWindow.Width = (int)Math.Ceiling((float)w * val.Z);
		localMultiplayerWindow.Height = (int)Math.Ceiling((float)h * val.W);
		try
		{
			int num = (int)Math.Ceiling((float)localMultiplayerWindow.Width * (1f / options.zoomLevel));
			int num2 = (int)Math.Ceiling((float)localMultiplayerWindow.Height * (1f / options.zoomLevel));
			screen = new RenderTarget2D(graphics.GraphicsDevice, num, num2, false, (SurfaceFormat)0, (DepthFormat)0, 0, (RenderTargetUsage)1)
			{
				Name = "@Game1.screen"
			};
			int num3 = (int)Math.Ceiling((float)localMultiplayerWindow.Width / options.uiScale);
			int num4 = (int)Math.Ceiling((float)localMultiplayerWindow.Height / options.uiScale);
			uiScreen = new RenderTarget2D(graphics.GraphicsDevice, num3, num4, false, (SurfaceFormat)0, (DepthFormat)0, 0, (RenderTargetUsage)1)
			{
				Name = "@Game1.uiScreen"
			};
		}
		catch (Exception)
		{
		}
		updateViewportForScreenSizeChange(fullscreenChange: false, localMultiplayerWindow.Width, localMultiplayerWindow.Height);
		if (val2.HasValue && val2.Value.X == (float)((Texture2D)uiScreen).Width && val2.Value.Y == (float)((Texture2D)uiScreen).Height)
		{
			return;
		}
		PushUIMode();
		textEntry?.gameWindowSizeChanged(oldBounds, new Rectangle(((Rectangle)(ref viewport)).X, ((Rectangle)(ref viewport)).Y, ((Rectangle)(ref viewport)).Width, ((Rectangle)(ref viewport)).Height));
		foreach (IClickableMenu onScreenMenu in onScreenMenus)
		{
			onScreenMenu.gameWindowSizeChanged(oldBounds, new Rectangle(((Rectangle)(ref viewport)).X, ((Rectangle)(ref viewport)).Y, ((Rectangle)(ref viewport)).Width, ((Rectangle)(ref viewport)).Height));
		}
		currentMinigame?.changeScreenSize();
		activeClickableMenu?.gameWindowSizeChanged(oldBounds, new Rectangle(((Rectangle)(ref viewport)).X, ((Rectangle)(ref viewport)).Y, ((Rectangle)(ref viewport)).Width, ((Rectangle)(ref viewport)).Height));
		if (activeClickableMenu?.GetType() == typeof(GameMenu))
		{
			GameMenu obj = activeClickableMenu as GameMenu;
			IClickableMenu currentPage = obj.GetCurrentPage();
			IClickableMenu currentPage2 = ((GameMenu)(activeClickableMenu = new GameMenu(obj.currentTab))).GetCurrentPage();
			if (!(currentPage2 is CollectionsPage collectionsPage))
			{
				if (!(currentPage2 is OptionsPage optionsPage))
				{
					if (currentPage2 is SocialPage socialPage)
					{
						socialPage.postWindowSizeChange(currentPage);
					}
				}
				else
				{
					optionsPage.postWindowSizeChange(currentPage);
				}
			}
			else
			{
				collectionsPage.postWindowSizeChange(currentPage);
			}
		}
		PopUIMode();
	}

	private void Game1_Exiting(object sender, EventArgs e)
	{
		Program.sdk.Shutdown();
	}

	public static void setGameMode(byte mode)
	{
		log.Verbose("setGameMode( '" + GameModeToString(mode) + "' )");
		_gameMode = mode;
		LocalizedContentManager localizedContentManager = temporaryContent;
		if (localizedContentManager != null)
		{
			((ContentManager)localizedContentManager).Unload();
		}
		if (mode != 0)
		{
			return;
		}
		bool flag = false;
		if (activeClickableMenu != null)
		{
			GameTime obj = currentGameTime;
			if (obj != null && obj.TotalGameTime.TotalSeconds > 10.0)
			{
				flag = true;
			}
		}
		if (game1.instanceIndex <= 0)
		{
			TitleMenu titleMenu = (TitleMenu)(activeClickableMenu = new TitleMenu());
			if (flag)
			{
				titleMenu.skipToTitleButtons();
			}
		}
	}

	public static void updateViewportForScreenSizeChange(bool fullscreenChange, int width, int height)
	{
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		forceSnapOnNextViewportUpdate = true;
		if (graphics.GraphicsDevice != null)
		{
			allocateLightmap(width, height);
		}
		width = (int)Math.Ceiling((float)width / options.zoomLevel);
		height = (int)Math.Ceiling((float)height / options.zoomLevel);
		Point val = default(Point);
		((Point)(ref val))._002Ector(((Rectangle)(ref viewport)).X + ((Rectangle)(ref viewport)).Width / 2, ((Rectangle)(ref viewport)).Y + ((Rectangle)(ref viewport)).Height / 2);
		bool flag = ((Rectangle)(ref viewport)).Width != width || ((Rectangle)(ref viewport)).Height != height;
		viewport = new Rectangle(val.X - width / 2, val.Y - height / 2, width, height);
		if (currentLocation == null)
		{
			return;
		}
		if (eventUp)
		{
			if (!IsFakedBlackScreen() && currentLocation.IsOutdoors)
			{
				clampViewportToGameMap();
			}
			return;
		}
		if (((Rectangle)(ref viewport)).X >= 0 || !currentLocation.IsOutdoors || fullscreenChange)
		{
			((Point)(ref val))._002Ector(((Rectangle)(ref viewport)).X + ((Rectangle)(ref viewport)).Width / 2, ((Rectangle)(ref viewport)).Y + ((Rectangle)(ref viewport)).Height / 2);
			viewport = new Rectangle(val.X - width / 2, val.Y - height / 2, width, height);
			UpdateViewPort(overrideFreeze: true, val);
		}
		if (flag)
		{
			forceSnapOnNextViewportUpdate = true;
			randomizeRainPositions();
			randomizeDebrisWeatherPositions(debrisWeather);
		}
	}

	public void Instance_Initialize()
	{
		Stopwatch stopwatch = Stopwatch.StartNew();
		Initialize();
		stopwatch.Stop();
		log.Verbose($"Instance_Initialize() finished, elapsed = '{stopwatch.Elapsed}'");
	}

	public static bool IsFading()
	{
		if (!globalFade && (!fadeIn || !(fadeToBlackAlpha > 0f)))
		{
			if (fadeToBlack)
			{
				return fadeToBlackAlpha < 1f;
			}
			return false;
		}
		return true;
	}

	public static bool IsFakedBlackScreen()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		if (currentMinigame != null)
		{
			return false;
		}
		if (CurrentEvent != null && CurrentEvent.currentCustomEventScript != null)
		{
			return false;
		}
		if (!eventUp)
		{
			return false;
		}
		return (float)(int)Math.Floor((float)new Point(((Rectangle)(ref viewport)).X + ((Rectangle)(ref viewport)).Width / 2, ((Rectangle)(ref viewport)).Y + ((Rectangle)(ref viewport)).Height / 2).X / 64f) <= -200f;
	}

	private void DoThreadedInitTask(ThreadStart initTask)
	{
		if (ShouldLoadIncrementally)
		{
			Thread thread = new Thread(initTask);
			thread.CurrentCulture = CultureInfo.InvariantCulture;
			thread.Priority = ThreadPriority.Highest;
			thread.Start();
		}
		else
		{
			initTask();
		}
	}

	protected override void Initialize()
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		keyboardDispatcher = new KeyboardDispatcher(base.Window);
		screenFade = new ScreenFade(onFadeToBlackComplete, onFadedBackInComplete);
		options = new Options();
		options.musicVolumeLevel = 1f;
		options.soundVolumeLevel = 1f;
		otherFarmers = new NetRootDictionary<long, Farmer>();
		DoThreadedInitTask(InitializeSerializers);
		viewport = new Rectangle(new Size(graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight));
		currentSong = null;
		DoThreadedInitTask(InitializeSounds);
		Viewport val = graphics.GraphicsDevice.Viewport;
		int width = ((Viewport)(ref val)).Width;
		val = graphics.GraphicsDevice.Viewport;
		int height = ((Viewport)(ref val)).Height;
		screen = new RenderTarget2D(graphics.GraphicsDevice, width, height, false, (SurfaceFormat)0, (DepthFormat)0, 0, (RenderTargetUsage)1);
		allocateLightmap(width, height);
		previousViewportPosition = Vector2.Zero;
		PushUIMode();
		PopUIMode();
		setRichPresence("menus");
	}

	private void InitializeSounds()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Expected O, but got Unknown
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Expected O, but got Unknown
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Expected O, but got Unknown
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Expected O, but got Unknown
		if (base.IsMainInstance)
		{
			try
			{
				string rootDirectory = base.Content.RootDirectory;
				AudioEngine val = new AudioEngine(Path.Combine(rootDirectory, "XACT", "FarmerSounds.xgs"));
				val.GetReverbSettings()[18] = 4f;
				val.GetReverbSettings()[17] = -12f;
				audioEngine = new AudioEngineWrapper(val);
				waveBank = new WaveBank(audioEngine.Engine, Path.Combine(rootDirectory, "XACT", "Wave Bank.xwb"));
				waveBank1_4 = new WaveBank(audioEngine.Engine, Path.Combine(rootDirectory, "XACT", "Wave Bank(1.4).xwb"));
				soundBank = new SoundBankWrapper(new SoundBank(audioEngine.Engine, Path.Combine(rootDirectory, "XACT", "Sound Bank.xsb")));
			}
			catch (Exception exception)
			{
				log.Error("Game.Initialize() caught exception initializing XACT.", exception);
				audioEngine = new DummyAudioEngine();
				soundBank = new DummySoundBank();
			}
		}
		audioEngine.Update();
		musicCategory = audioEngine.GetCategory("Music");
		soundCategory = audioEngine.GetCategory("Sound");
		ambientCategory = audioEngine.GetCategory("Ambient");
		footstepCategory = audioEngine.GetCategory("Footsteps");
		wind = soundBank.GetCue("wind");
		chargeUpSound = soundBank.GetCue("toolCharge");
		AmbientLocationSounds.InitShared();
		FinishedFirstInitSounds = true;
	}

	private void InitializeSerializers()
	{
		otherFarmers.Serializer = SaveSerializer.GetSerializer(typeof(Farmer));
		if (StartupPreferences.serializer == null)
		{
			StartupPreferences.serializer = SaveSerializer.GetSerializer(typeof(StartupPreferences));
		}
		FinishedFirstInitSerializers = true;
	}

	public static void pauseThenDoFunction(int pauseTime, afterFadeFunction function)
	{
		afterPause = function;
		pauseThenDoFunctionTimer = pauseTime;
	}

	protected internal virtual LocalizedContentManager CreateContentManager(IServiceProvider serviceProvider, string rootDirectory)
	{
		return new LocalizedContentManager(serviceProvider, rootDirectory);
	}

	protected internal virtual IDisplayDevice CreateDisplayDevice(ContentManager content, GraphicsDevice graphicsDevice)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Expected O, but got Unknown
		return (IDisplayDevice)new XnaDisplayDevice(content, graphicsDevice);
	}

	public void Instance_LoadContent()
	{
		Stopwatch stopwatch = Stopwatch.StartNew();
		LoadContent();
		stopwatch.Stop();
		log.Verbose($"Instance_LoadContent() finished, elapsed = '{stopwatch.Elapsed}'");
	}

	protected override void LoadContent()
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Expected O, but got Unknown
		content = CreateContentManager(base.Content.ServiceProvider, base.Content.RootDirectory);
		xTileContent = CreateContentManager(((ContentManager)content).ServiceProvider, ((ContentManager)content).RootDirectory);
		mapDisplayDevice = CreateDisplayDevice((ContentManager)(object)content, base.GraphicsDevice);
		spriteBatch = new SpriteBatch(base.GraphicsDevice);
		netWorldState = new NetRoot<NetWorldState>(new NetWorldState());
		LoadContentEnumerator = GetLoadContentEnumerator();
		if (!ShouldLoadIncrementally)
		{
			while (LoadContentEnumerator.MoveNext())
			{
			}
			LoadContentEnumerator = null;
			AfterLoadContent();
		}
	}

	private void AfterLoadContent()
	{
		saveOnNewDay = true;
		if (gameMode == 4)
		{
			fadeToBlackAlpha = -0.5f;
			fadeIn = true;
		}
		if (random.NextDouble() < 0.7)
		{
			isDebrisWeather = true;
			populateDebrisWeatherArray();
		}
		resetPlayer();
		CueModification.OnStartup();
		setGameMode(0);
	}

	private IEnumerator<int> GetLoadContentEnumerator()
	{
		int step = 0;
		bigCraftableData = DataLoader.BigCraftables(content);
		int num = step + 1;
		step = num;
		yield return num;
		objectData = DataLoader.Objects(content);
		num = step + 1;
		step = num;
		yield return num;
		cropData = DataLoader.Crops(content);
		num = step + 1;
		step = num;
		yield return num;
		characterData = DataLoader.Characters(content);
		num = step + 1;
		step = num;
		yield return num;
		pantsData = DataLoader.Pants(content);
		num = step + 1;
		step = num;
		yield return num;
		shirtData = DataLoader.Shirts(content);
		num = step + 1;
		step = num;
		yield return num;
		toolData = DataLoader.Tools(content);
		num = step + 1;
		step = num;
		yield return num;
		weaponData = DataLoader.Weapons(content);
		num = step + 1;
		step = num;
		yield return num;
		achievements = DataLoader.Achievements(content);
		num = step + 1;
		step = num;
		yield return num;
		buildingData = DataLoader.Buildings(content);
		num = step + 1;
		step = num;
		yield return num;
		farmAnimalData = DataLoader.FarmAnimals(content);
		num = step + 1;
		step = num;
		yield return num;
		floorPathData = DataLoader.FloorsAndPaths(content);
		num = step + 1;
		step = num;
		yield return num;
		fruitTreeData = DataLoader.FruitTrees(content);
		num = step + 1;
		step = num;
		yield return num;
		locationData = DataLoader.Locations(content);
		num = step + 1;
		step = num;
		yield return num;
		locationContextData = DataLoader.LocationContexts(content);
		num = step + 1;
		step = num;
		yield return num;
		petData = DataLoader.Pets(content);
		num = step + 1;
		step = num;
		yield return num;
		NPCGiftTastes = DataLoader.NpcGiftTastes(content);
		num = step + 1;
		step = num;
		yield return num;
		CraftingRecipe.InitShared();
		num = step + 1;
		step = num;
		yield return num;
		ItemRegistry.ResetCache();
		num = step + 1;
		step = num;
		yield return num;
		jukeboxTrackData = new Dictionary<string, JukeboxTrackData>(StringComparer.OrdinalIgnoreCase);
		foreach (KeyValuePair<string, JukeboxTrackData> item in DataLoader.JukeboxTracks(content))
		{
			if (!jukeboxTrackData.TryAdd(item.Key, item.Value))
			{
				log.Warn("Ignored duplicate ID '" + item.Key + "' in Data/JukeboxTracks.");
			}
		}
		num = step + 1;
		step = num;
		yield return num;
		concessionsSpriteSheet = content.Load<Texture2D>("LooseSprites\\Concessions");
		num = step + 1;
		step = num;
		yield return num;
		birdsSpriteSheet = content.Load<Texture2D>("LooseSprites\\birds");
		num = step + 1;
		step = num;
		yield return num;
		daybg = content.Load<Texture2D>("LooseSprites\\daybg");
		num = step + 1;
		step = num;
		yield return num;
		nightbg = content.Load<Texture2D>("LooseSprites\\nightbg");
		num = step + 1;
		step = num;
		yield return num;
		menuTexture = content.Load<Texture2D>("Maps\\MenuTiles");
		num = step + 1;
		step = num;
		yield return num;
		uncoloredMenuTexture = content.Load<Texture2D>("Maps\\MenuTilesUncolored");
		num = step + 1;
		step = num;
		yield return num;
		lantern = content.Load<Texture2D>("LooseSprites\\Lighting\\lantern");
		num = step + 1;
		step = num;
		yield return num;
		windowLight = content.Load<Texture2D>("LooseSprites\\Lighting\\windowLight");
		num = step + 1;
		step = num;
		yield return num;
		sconceLight = content.Load<Texture2D>("LooseSprites\\Lighting\\sconceLight");
		num = step + 1;
		step = num;
		yield return num;
		cauldronLight = content.Load<Texture2D>("LooseSprites\\Lighting\\greenLight");
		num = step + 1;
		step = num;
		yield return num;
		indoorWindowLight = content.Load<Texture2D>("LooseSprites\\Lighting\\indoorWindowLight");
		num = step + 1;
		step = num;
		yield return num;
		shadowTexture = content.Load<Texture2D>("LooseSprites\\shadow");
		num = step + 1;
		step = num;
		yield return num;
		mouseCursors = content.Load<Texture2D>("LooseSprites\\Cursors");
		num = step + 1;
		step = num;
		yield return num;
		mouseCursors2 = content.Load<Texture2D>("LooseSprites\\Cursors2");
		num = step + 1;
		step = num;
		yield return num;
		mouseCursors_1_6 = content.Load<Texture2D>("LooseSprites\\Cursors_1_6");
		num = step + 1;
		step = num;
		yield return num;
		giftboxTexture = content.Load<Texture2D>("LooseSprites\\Giftbox");
		num = step + 1;
		step = num;
		yield return num;
		controllerMaps = content.Load<Texture2D>("LooseSprites\\ControllerMaps");
		num = step + 1;
		step = num;
		yield return num;
		animations = content.Load<Texture2D>("TileSheets\\animations");
		num = step + 1;
		step = num;
		yield return num;
		objectSpriteSheet = content.Load<Texture2D>("Maps\\springobjects");
		num = step + 1;
		step = num;
		yield return num;
		objectSpriteSheet_2 = content.Load<Texture2D>("TileSheets\\Objects_2");
		num = step + 1;
		step = num;
		yield return num;
		bobbersTexture = content.Load<Texture2D>("TileSheets\\bobbers");
		num = step + 1;
		step = num;
		yield return num;
		cropSpriteSheet = content.Load<Texture2D>("TileSheets\\crops");
		num = step + 1;
		step = num;
		yield return num;
		emoteSpriteSheet = content.Load<Texture2D>("TileSheets\\emotes");
		num = step + 1;
		step = num;
		yield return num;
		debrisSpriteSheet = content.Load<Texture2D>("TileSheets\\debris");
		num = step + 1;
		step = num;
		yield return num;
		bigCraftableSpriteSheet = content.Load<Texture2D>("TileSheets\\Craftables");
		num = step + 1;
		step = num;
		yield return num;
		rainTexture = content.Load<Texture2D>("TileSheets\\rain");
		num = step + 1;
		step = num;
		yield return num;
		buffsIcons = content.Load<Texture2D>("TileSheets\\BuffsIcons");
		num = step + 1;
		step = num;
		yield return num;
		Tool.weaponsTexture = content.Load<Texture2D>("TileSheets\\weapons");
		num = step + 1;
		step = num;
		yield return num;
		FarmerRenderer.hairStylesTexture = content.Load<Texture2D>("Characters\\Farmer\\hairstyles");
		num = step + 1;
		step = num;
		yield return num;
		FarmerRenderer.shirtsTexture = content.Load<Texture2D>("Characters\\Farmer\\shirts");
		num = step + 1;
		step = num;
		yield return num;
		FarmerRenderer.pantsTexture = content.Load<Texture2D>("Characters\\Farmer\\pants");
		num = step + 1;
		step = num;
		yield return num;
		FarmerRenderer.hatsTexture = content.Load<Texture2D>("Characters\\Farmer\\hats");
		num = step + 1;
		step = num;
		yield return num;
		FarmerRenderer.accessoriesTexture = content.Load<Texture2D>("Characters\\Farmer\\accessories");
		num = step + 1;
		step = num;
		yield return num;
		MapSeat.mapChairTexture = content.Load<Texture2D>("TileSheets\\ChairTiles");
		num = step + 1;
		step = num;
		yield return num;
		SpriteText.spriteTexture = content.Load<Texture2D>("LooseSprites\\font_bold");
		num = step + 1;
		step = num;
		yield return num;
		SpriteText.coloredTexture = content.Load<Texture2D>("LooseSprites\\font_colored");
		num = step + 1;
		step = num;
		yield return num;
		Projectile.projectileSheet = content.Load<Texture2D>("TileSheets\\Projectiles");
		num = step + 1;
		step = num;
		yield return num;
		Color[] data = (Color[])(object)new Color[1] { Color.White };
		for (int i = 0; i < dynamicPixelRects.Length; i++)
		{
			dynamicPixelRects[i] = new Texture2D(base.GraphicsDevice, 1, 1, false, (SurfaceFormat)0)
			{
				Name = $"@{"Game1"}.{"dynamicPixelRects"}[{i}]"
			};
			dynamicPixelRects[i].SetData<Color>(data);
		}
		fadeToBlackRect = dynamicPixelRects[0];
		staminaRect = dynamicPixelRects[1];
		lightingRect = dynamicPixelRects[2];
		num = step + 1;
		step = num;
		yield return num;
		onScreenMenus.Clear();
		onScreenMenus.Add(dayTimeMoneyBox = new DayTimeMoneyBox());
		onScreenMenus.Add(new Toolbar());
		onScreenMenus.Add(buffsDisplay = new BuffsDisplay());
		num = step + 1;
		step = num;
		yield return num;
		for (int j = 0; j < 70; j++)
		{
			rainDrops[j] = new RainDrop(random.Next(((Rectangle)(ref viewport)).Width), random.Next(((Rectangle)(ref viewport)).Height), random.Next(4), random.Next(70));
		}
		num = step + 1;
		step = num;
		yield return num;
		dialogueWidth = Math.Min(1024, graphics.GraphicsDevice.Viewport.GetTitleSafeArea().Width - 256);
		dialogueFont = content.Load<SpriteFont>("Fonts\\SpriteFont1");
		dialogueFont.LineSpacing = 42;
		num = step + 1;
		step = num;
		yield return num;
		smallFont = content.Load<SpriteFont>("Fonts\\SmallFont");
		smallFont.LineSpacing = 28;
		num = step + 1;
		step = num;
		yield return num;
		tinyFont = content.Load<SpriteFont>("Fonts\\tinyFont");
		num = step + 1;
		step = num;
		yield return num;
		_shortDayDisplayName[0] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3042");
		num = step + 1;
		step = num;
		yield return num;
		_shortDayDisplayName[1] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3043");
		num = step + 1;
		step = num;
		yield return num;
		_shortDayDisplayName[2] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3044");
		num = step + 1;
		step = num;
		yield return num;
		_shortDayDisplayName[3] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3045");
		num = step + 1;
		step = num;
		yield return num;
		_shortDayDisplayName[4] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3046");
		num = step + 1;
		step = num;
		yield return num;
		_shortDayDisplayName[5] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3047");
		num = step + 1;
		step = num;
		yield return num;
		_shortDayDisplayName[6] = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3048");
		yield return step + 1;
	}

	public static void resetPlayer()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		List<Item> initialTools = Farmer.initialTools();
		player = new Farmer(new FarmerSprite(null), new Vector2(192f, 192f), 1, "", initialTools, isMale: true);
	}

	public static void resetVariables()
	{
		xLocationAfterWarp = 0;
		yLocationAfterWarp = 0;
		gameTimeInterval = 0;
		currentQuestionChoice = 0;
		currentDialogueCharacterIndex = 0;
		dialogueTypingInterval = 0;
		dayOfMonth = 0;
		year = 1;
		timeOfDay = 600;
		timeOfDayAfterFade = -1;
		facingDirectionAfterWarp = 0;
		dialogueWidth = 0;
		facingDirectionAfterWarp = 0;
		mouseClickPolling = 0;
		weatherIcon = 0;
		hitShakeTimer = 0;
		staminaShakeTimer = 0;
		pauseThenDoFunctionTimer = 0;
		weatherForTomorrow = "Sun";
	}

	public static bool playSound(string cueName, int? pitch = null)
	{
		ICue cue;
		return sounds.PlayLocal(cueName, null, null, pitch, SoundContext.Default, out cue);
	}

	public static bool playSound(string cueName, out ICue cue)
	{
		return sounds.PlayLocal(cueName, null, null, null, SoundContext.Default, out cue);
	}

	public static bool playSound(string cueName, int pitch, out ICue cue)
	{
		return sounds.PlayLocal(cueName, null, null, pitch, SoundContext.Default, out cue);
	}

	public static void setRichPresence(string friendlyName, object argument = null)
	{
		if (friendlyName == null)
		{
			return;
		}
		switch (friendlyName.Length)
		{
		case 8:
			switch (friendlyName[0])
			{
			case 'l':
				if (friendlyName == "location")
				{
					debugPresenceString = $"At {argument}";
				}
				break;
			case 'f':
				if (friendlyName == "festival")
				{
					debugPresenceString = $"At {argument}";
				}
				break;
			case 'm':
				if (friendlyName == "minigame")
				{
					debugPresenceString = $"Playing {argument}";
				}
				break;
			case 'e':
				if (friendlyName == "earnings")
				{
					debugPresenceString = $"Made {argument}g last night";
				}
				break;
			}
			break;
		case 7:
			switch (friendlyName[0])
			{
			case 'f':
				if (friendlyName == "fishing")
				{
					debugPresenceString = $"Fishing at {argument}";
				}
				break;
			case 'w':
				if (friendlyName == "wedding")
				{
					debugPresenceString = $"Getting married to {argument}";
				}
				break;
			}
			break;
		case 5:
			if (friendlyName == "menus")
			{
				debugPresenceString = "In menus";
			}
			break;
		case 9:
			if (friendlyName == "giantcrop")
			{
				debugPresenceString = $"Just harvested a Giant {argument}";
			}
			break;
		case 6:
			break;
		}
	}

	public static void GenerateBundles(BundleType bundle_type, bool use_seed = true)
	{
		if (bundle_type == BundleType.Remixed)
		{
			Random rng = (use_seed ? Utility.CreateRandom((double)uniqueIDForThisGame * 9.0) : new Random());
			Dictionary<string, string> bundleData = new BundleGenerator().Generate(DataLoader.RandomBundles(content), rng);
			netWorldState.Value.SetBundleData(bundleData);
		}
		else
		{
			netWorldState.Value.SetBundleData(DataLoader.Bundles(content));
		}
	}

	public void SetNewGameOption<T>(string key, T val)
	{
		newGameSetupOptions[key] = val;
	}

	public T GetNewGameOption<T>(string key)
	{
		if (!newGameSetupOptions.TryGetValue(key, out var value))
		{
			return default(T);
		}
		return (T)value;
	}

	public virtual void loadForNewGame(bool loadedGame = false)
	{
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		if (startingGameSeed.HasValue)
		{
			uniqueIDForThisGame = startingGameSeed.Value;
		}
		specialCurrencyDisplay = new SpecialCurrencyDisplay();
		flushLocationLookup();
		locations.Clear();
		mailbox.Clear();
		currentLightSources.Clear();
		questionChoices.Clear();
		hudMessages.Clear();
		weddingToday = false;
		timeOfDay = 600;
		season = (Season)0;
		if (!loadedGame)
		{
			year = 1;
		}
		dayOfMonth = 0;
		isQuestion = false;
		nonWarpFade = false;
		newDay = false;
		eventUp = false;
		viewportFreeze = false;
		eventOver = false;
		screenGlow = false;
		screenGlowHold = false;
		screenGlowUp = false;
		isRaining = false;
		wasGreenRain = false;
		killScreen = false;
		messagePause = false;
		isDebrisWeather = false;
		weddingToday = false;
		exitToTitle = false;
		dialogueUp = false;
		postExitToTitleCallback = null;
		displayHUD = true;
		messageAfterPause = "";
		samBandName = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2156");
		background = null;
		currentCursorTile = Vector2.Zero;
		if (!loadedGame)
		{
			lastAppliedSaveFix = SaveMigrator.LatestSaveFix;
		}
		resetVariables();
		player.team.sharedDailyLuck.Value = 0.001;
		if (!loadedGame)
		{
			options = new Options();
			options.LoadDefaultOptions();
			initializeVolumeLevels();
		}
		game1.CheckGamepadMode();
		onScreenMenus.Add(chatBox = new ChatBox());
		outdoorLight = Color.White;
		ambientLight = Color.White;
		UpdateDishOfTheDay();
		locations.Clear();
		Farm farm = new Farm("Maps\\" + Farm.getMapNameFromTypeInt(whichFarm), "Farm");
		locations.Add(farm);
		AddLocations();
		foreach (GameLocation location in locations)
		{
			location.AddDefaultBuildings();
		}
		forceSnapOnNextViewportUpdate = true;
		farm.onNewGame();
		if (!loadedGame)
		{
			foreach (GameLocation location2 in locations)
			{
				if (location2 is IslandLocation islandLocation)
				{
					islandLocation.AddAdditionalWalnutBushes();
				}
			}
		}
		if (!loadedGame)
		{
			hooks.CreatedInitialLocations();
		}
		else
		{
			hooks.SaveAddedLocations();
		}
		if (!loadedGame)
		{
			AddNPCs();
		}
		WarpPathfindingCache.PopulateCache();
		if (!loadedGame)
		{
			GenerateBundles(bundleType);
			foreach (string value in netWorldState.Value.BundleData.Values)
			{
				string[] array = ArgUtility.SplitBySpace(value.Split('/')[2]);
				if (!game1.GetNewGameOption<bool>("YearOneCompletable"))
				{
					continue;
				}
				for (int i = 0; i < array.Length; i += 3)
				{
					if (array[i] == "266")
					{
						int num = (16 - 2) * 2;
						num += 3;
						Random random = Utility.CreateRandom((double)uniqueIDForThisGame * 12.0);
						netWorldState.Value.VisitsUntilY1Guarantee = random.Next(2, num);
					}
				}
			}
			netWorldState.Value.ShuffleMineChests = game1.GetNewGameOption<MineChestType>("MineChests");
			if (game1.newGameSetupOptions.ContainsKey("SpawnMonstersAtNight"))
			{
				spawnMonstersAtNight = game1.GetNewGameOption<bool>("SpawnMonstersAtNight");
			}
		}
		player.ConvertClothingOverrideToClothesItems();
		player.addQuest("9");
		RefreshQuestOfTheDay();
		player.currentLocation = RequireLocation("FarmHouse");
		player.gameVersion = version;
		hudMessages.Clear();
		hasLoadedGame = true;
		setGraphicsForSeason(onLoad: true);
		if (!loadedGame)
		{
			_setSaveName = false;
		}
		game1.newGameSetupOptions.Clear();
		updateCellarAssignments();
		if (!loadedGame && netWorldState != null && netWorldState.Value != null)
		{
			netWorldState.Value.RegisterSpecialCurrencies();
		}
	}

	public bool IsLocalCoopJoinable()
	{
		if (GameRunner.instance.gameInstances.Count >= GameRunner.instance.GetMaxSimultaneousPlayers())
		{
			return false;
		}
		if (IsClient)
		{
			return false;
		}
		return true;
	}

	public static void StartLocalMultiplayerIfNecessary()
	{
		if (multiplayerMode == 0)
		{
			log.Verbose("Starting multiplayer server for local multiplayer...");
			multiplayerMode = 2;
			if (server == null)
			{
				multiplayer.StartLocalMultiplayerServer();
			}
		}
	}

	public static void EndLocalMultiplayer()
	{
	}

	public static void UpdatePassiveFestivalStates()
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		netWorldState.Value.ActivePassiveFestivals.Clear();
		foreach (KeyValuePair<string, PassiveFestivalData> item in DataLoader.PassiveFestivals(content))
		{
			string key = item.Key;
			PassiveFestivalData value = item.Value;
			if (dayOfMonth >= value.StartDay && dayOfMonth <= value.EndDay && season == value.Season && GameStateQuery.CheckConditions(value.Condition))
			{
				netWorldState.Value.ActivePassiveFestivals.Add(key);
			}
		}
	}

	public void Instance_UnloadContent()
	{
		UnloadContent();
	}

	protected override void UnloadContent()
	{
		base.UnloadContent();
		((GraphicsResource)spriteBatch).Dispose();
		((ContentManager)content).Unload();
		((ContentManager)xTileContent).Unload();
		server?.stopServer();
	}

	public static void showRedMessage(string message, bool playSound = true)
	{
		addHUDMessage(new HUDMessage(message, 3));
		if (!message.Contains("Inventory") && playSound)
		{
			Game1.playSound("cancel");
		}
		else if (player.mailReceived.Add("BackpackTip"))
		{
			addMailForTomorrow("pierreBackpack");
		}
	}

	public static void showRedMessageUsingLoadString(string loadString, bool playSound = true)
	{
		showRedMessage(content.LoadString(loadString), playSound);
	}

	public static bool didPlayerJustLeftClick(bool ignoreNonMouseHeldInput = false)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Invalid comparison between Unknown and I4
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Invalid comparison between Unknown and I4
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Invalid comparison between Unknown and I4
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		MouseState mouseState = input.GetMouseState();
		if ((int)((MouseState)(ref mouseState)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton != 1)
		{
			return true;
		}
		GamePadState gamePadState = input.GetGamePadState();
		GamePadButtons buttons = ((GamePadState)(ref gamePadState)).Buttons;
		if ((int)((GamePadButtons)(ref buttons)).X == 1 && (!ignoreNonMouseHeldInput || !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)16384)))
		{
			return true;
		}
		if (isOneOfTheseKeysDown(input.GetKeyboardState(), options.useToolButton) && (!ignoreNonMouseHeldInput || areAllOfTheseKeysUp(oldKBState, options.useToolButton)))
		{
			return true;
		}
		return false;
	}

	public static bool didPlayerJustRightClick(bool ignoreNonMouseHeldInput = false)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Invalid comparison between Unknown and I4
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Invalid comparison between Unknown and I4
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Invalid comparison between Unknown and I4
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		MouseState mouseState = input.GetMouseState();
		if ((int)((MouseState)(ref mouseState)).RightButton == 1 && (int)((MouseState)(ref oldMouseState)).RightButton != 1)
		{
			return true;
		}
		GamePadState gamePadState = input.GetGamePadState();
		GamePadButtons buttons = ((GamePadState)(ref gamePadState)).Buttons;
		if ((int)((GamePadButtons)(ref buttons)).A == 1 && (!ignoreNonMouseHeldInput || !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096)))
		{
			return true;
		}
		if (isOneOfTheseKeysDown(input.GetKeyboardState(), options.actionButton) && (!ignoreNonMouseHeldInput || !isOneOfTheseKeysDown(oldKBState, options.actionButton)))
		{
			return true;
		}
		return false;
	}

	public static bool didPlayerJustClickAtAll(bool ignoreNonMouseHeldInput = false)
	{
		if (!didPlayerJustLeftClick(ignoreNonMouseHeldInput))
		{
			return didPlayerJustRightClick(ignoreNonMouseHeldInput);
		}
		return true;
	}

	public static void showGlobalMessage(string message)
	{
		addHUDMessage(HUDMessage.ForCornerTextbox(message));
	}

	public static void globalFadeToBlack(afterFadeFunction afterFade = null, float fadeSpeed = 0.02f)
	{
		screenFade.GlobalFadeToBlack(afterFade, fadeSpeed);
	}

	public static void globalFadeToClear(afterFadeFunction afterFade = null, float fadeSpeed = 0.02f)
	{
		screenFade.GlobalFadeToClear(afterFade, fadeSpeed);
	}

	public void CheckGamepadMode()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Invalid comparison between Unknown and I4
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Invalid comparison between Unknown and I4
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Invalid comparison between Unknown and I4
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Invalid comparison between Unknown and I4
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		bool gamepadControls = options.gamepadControls;
		switch (options.gamepadMode)
		{
		case Options.GamepadModes.ForceOn:
			options.gamepadControls = true;
			return;
		case Options.GamepadModes.ForceOff:
			options.gamepadControls = false;
			return;
		}
		MouseState mouseState = input.GetMouseState();
		KeyboardState keyboardState = GetKeyboardState();
		GamePadState gamePadState = input.GetGamePadState();
		bool flag = false;
		if (((int)((MouseState)(ref mouseState)).LeftButton == 1 || (int)((MouseState)(ref mouseState)).MiddleButton == 1 || (int)((MouseState)(ref mouseState)).RightButton == 1 || ((MouseState)(ref mouseState)).ScrollWheelValue != _oldScrollWheelValue || ((((MouseState)(ref mouseState)).X != _oldMousePosition.X || ((MouseState)(ref mouseState)).Y != _oldMousePosition.Y) && lastCursorMotionWasMouse) || ((KeyboardState)(ref keyboardState)).GetPressedKeys().Length != 0) && (((KeyboardState)(ref keyboardState)).GetPressedKeys().Length != 1 || (int)((KeyboardState)(ref keyboardState)).GetPressedKeys()[0] != 19))
		{
			flag = true;
		}
		_oldScrollWheelValue = ((MouseState)(ref mouseState)).ScrollWheelValue;
		_oldMousePosition.X = ((MouseState)(ref mouseState)).X;
		_oldMousePosition.Y = ((MouseState)(ref mouseState)).Y;
		int num;
		if (!isAnyGamePadButtonBeingPressed() && !isDPadPressed() && !isGamePadThumbstickInMotion())
		{
			GamePadTriggers triggers = ((GamePadState)(ref gamePadState)).Triggers;
			if (((GamePadTriggers)(ref triggers)).Left == 0f)
			{
				triggers = ((GamePadState)(ref gamePadState)).Triggers;
				num = ((((GamePadTriggers)(ref triggers)).Right != 0f) ? 1 : 0);
				goto IL_015d;
			}
		}
		num = 1;
		goto IL_015d;
		IL_015d:
		bool flag2 = (byte)num != 0;
		if (_oldGamepadConnectedState != ((GamePadState)(ref gamePadState)).IsConnected)
		{
			_oldGamepadConnectedState = ((GamePadState)(ref gamePadState)).IsConnected;
			if (_oldGamepadConnectedState)
			{
				options.gamepadControls = true;
				showGlobalMessage(content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2574"));
			}
			else
			{
				options.gamepadControls = false;
				if ((int)instancePlayerOneIndex != -1)
				{
					showGlobalMessage(content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2575"));
					if (CanShowPauseMenu() && activeClickableMenu == null)
					{
						activeClickableMenu = new GameMenu();
					}
				}
			}
		}
		if (flag && options.gamepadControls)
		{
			options.gamepadControls = false;
		}
		if (!options.gamepadControls && flag2)
		{
			options.gamepadControls = true;
		}
		if (gamepadControls == options.gamepadControls || !options.gamepadControls)
		{
			return;
		}
		lastMousePositionBeforeFade = new Point(localMultiplayerWindow.Width / 2, localMultiplayerWindow.Height / 2);
		if (activeClickableMenu != null)
		{
			activeClickableMenu.setUpForGamePadMode();
			if (options.SnappyMenus)
			{
				activeClickableMenu.populateClickableComponentList();
				activeClickableMenu.snapToDefaultClickableComponent();
			}
		}
		timerUntilMouseFade = 0;
	}

	public void Instance_Update(GameTime gameTime)
	{
		Update(gameTime);
	}

	protected override void Update(GameTime gameTime)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		GameTime gameTime2 = gameTime;
		DebugTools.BeforeGameUpdate(this, ref gameTime2);
		input.UpdateStates();
		GamePadState gamePadState = input.GetGamePadState();
		if (((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)128))
		{
			rightStickHoldTime += gameTime.ElapsedGameTime.Milliseconds;
		}
		GameMenu.bundleItemHovered = false;
		_update(gameTime2);
		if (IsMultiplayer && player != null)
		{
			player.requestingTimePause.Value = !shouldTimePass(LocalMultiplayer.IsLocalMultiplayer(is_local_only: true));
			if (IsMasterGame)
			{
				bool flag = false;
				if (LocalMultiplayer.IsLocalMultiplayer(is_local_only: true))
				{
					flag = true;
					foreach (Farmer onlineFarmer in getOnlineFarmers())
					{
						if (!onlineFarmer.requestingTimePause.Value)
						{
							flag = false;
							break;
						}
					}
				}
				netWorldState.Value.IsTimePaused = flag;
			}
		}
		Rumble.update(gameTime.ElapsedGameTime.Milliseconds);
		if (options.gamepadControls && thumbstickMotionMargin > 0)
		{
			thumbstickMotionMargin -= gameTime.ElapsedGameTime.Milliseconds;
		}
		gamePadState = input.GetGamePadState();
		if (!((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)128))
		{
			rightStickHoldTime = 0;
		}
		base.Update(gameTime);
	}

	public void Instance_OnActivated(object sender, EventArgs args)
	{
		OnActivated(sender, args);
	}

	protected override void OnActivated(object sender, EventArgs args)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		base.OnActivated(sender, args);
		_activatedTick = ticks + 1;
		InputState inputState = input;
		KeyboardState keyboardState = GetKeyboardState();
		inputState.IgnoreKeys(((KeyboardState)(ref keyboardState)).GetPressedKeys());
	}

	public bool HasKeyboardFocus()
	{
		if (keyboardFocusInstance == null)
		{
			return base.IsMainInstance;
		}
		return keyboardFocusInstance == this;
	}

	private void _update(GameTime gameTime)
	{
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0570: Unknown result type (might be due to invalid IL or missing references)
		//IL_0575: Unknown result type (might be due to invalid IL or missing references)
		//IL_0596: Unknown result type (might be due to invalid IL or missing references)
		//IL_059d: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05db: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0612: Unknown result type (might be due to invalid IL or missing references)
		//IL_0619: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f80: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f85: Unknown result type (might be due to invalid IL or missing references)
		//IL_0795: Unknown result type (might be due to invalid IL or missing references)
		//IL_079d: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f11: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f13: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f18: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f1a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f1f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f21: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ebb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ebd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ecb: Unknown result type (might be due to invalid IL or missing references)
		//IL_10bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_10c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_10c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_10cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_10d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_10d7: Invalid comparison between Unknown and I4
		//IL_1325: Unknown result type (might be due to invalid IL or missing references)
		//IL_132a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1331: Unknown result type (might be due to invalid IL or missing references)
		//IL_1336: Unknown result type (might be due to invalid IL or missing references)
		//IL_133d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1342: Unknown result type (might be due to invalid IL or missing references)
		//IL_1344: Unknown result type (might be due to invalid IL or missing references)
		//IL_1104: Unknown result type (might be due to invalid IL or missing references)
		//IL_1109: Unknown result type (might be due to invalid IL or missing references)
		//IL_110d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1113: Invalid comparison between Unknown and I4
		//IL_10de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0817: Unknown result type (might be due to invalid IL or missing references)
		//IL_081f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1379: Unknown result type (might be due to invalid IL or missing references)
		//IL_137b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1380: Unknown result type (might be due to invalid IL or missing references)
		//IL_1382: Unknown result type (might be due to invalid IL or missing references)
		//IL_1357: Unknown result type (might be due to invalid IL or missing references)
		//IL_1138: Unknown result type (might be due to invalid IL or missing references)
		//IL_111a: Unknown result type (might be due to invalid IL or missing references)
		//IL_136d: Unknown result type (might be due to invalid IL or missing references)
		//IL_136f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1371: Unknown result type (might be due to invalid IL or missing references)
		//IL_114b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1184: Unknown result type (might be due to invalid IL or missing references)
		//IL_1186: Unknown result type (might be due to invalid IL or missing references)
		//IL_1190: Unknown result type (might be due to invalid IL or missing references)
		//IL_1195: Unknown result type (might be due to invalid IL or missing references)
		//IL_083d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0844: Unknown result type (might be due to invalid IL or missing references)
		//IL_12df: Unknown result type (might be due to invalid IL or missing references)
		//IL_115e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0859: Unknown result type (might be due to invalid IL or missing references)
		//IL_089f: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0884: Unknown result type (might be due to invalid IL or missing references)
		//IL_0886: Unknown result type (might be due to invalid IL or missing references)
		//IL_088b: Unknown result type (might be due to invalid IL or missing references)
		//IL_088d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0892: Unknown result type (might be due to invalid IL or missing references)
		//IL_0894: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bdd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_08bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d92: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d94: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d99: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c21: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c23: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c28: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c31: Unknown result type (might be due to invalid IL or missing references)
		//IL_08cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0905: Unknown result type (might be due to invalid IL or missing references)
		//IL_090a: Unknown result type (might be due to invalid IL or missing references)
		//IL_090e: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dbc: Invalid comparison between Unknown and I4
		//IL_0d1f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d24: Unknown result type (might be due to invalid IL or missing references)
		//IL_094c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0951: Unknown result type (might be due to invalid IL or missing references)
		//IL_0955: Unknown result type (might be due to invalid IL or missing references)
		//IL_0924: Unknown result type (might be due to invalid IL or missing references)
		//IL_0929: Unknown result type (might be due to invalid IL or missing references)
		//IL_092d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0def: Invalid comparison between Unknown and I4
		//IL_0dc3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dc9: Invalid comparison between Unknown and I4
		//IL_0993: Unknown result type (might be due to invalid IL or missing references)
		//IL_0998: Unknown result type (might be due to invalid IL or missing references)
		//IL_099c: Unknown result type (might be due to invalid IL or missing references)
		//IL_096b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0970: Unknown result type (might be due to invalid IL or missing references)
		//IL_0974: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0df6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dfc: Invalid comparison between Unknown and I4
		//IL_0d3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d3f: Unknown result type (might be due to invalid IL or missing references)
		//IL_09da: Unknown result type (might be due to invalid IL or missing references)
		//IL_09df: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_09bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e28: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2e: Invalid comparison between Unknown and I4
		//IL_0d4c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d4e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a24: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a29: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a2d: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_09fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a02: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e84: Invalid comparison between Unknown and I4
		//IL_0e59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e5f: Invalid comparison between Unknown and I4
		//IL_0a6b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a70: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a74: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a40: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a45: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a49: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e8b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e91: Invalid comparison between Unknown and I4
		//IL_0ab2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0abb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a90: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0afe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b02: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ace: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b15: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b90: Unknown result type (might be due to invalid IL or missing references)
		if (graphics.GraphicsDevice == null)
		{
			return;
		}
		bool flag = false;
		gameModeTicks++;
		if (options != null && !takingMapScreenshot)
		{
			if (options.baseUIScale != options.desiredUIScale)
			{
				if (options.desiredUIScale < 0f)
				{
					options.desiredUIScale = options.desiredBaseZoomLevel;
				}
				options.baseUIScale = options.desiredUIScale;
				flag = true;
			}
			if (options.desiredBaseZoomLevel != options.baseZoomLevel)
			{
				options.baseZoomLevel = options.desiredBaseZoomLevel;
				forceSnapOnNextViewportUpdate = true;
				flag = true;
			}
		}
		if (flag)
		{
			refreshWindowSettings();
		}
		if (!ShouldLoadIncrementally)
		{
			CheckGamepadMode();
		}
		FarmAnimal.NumPathfindingThisTick = 0;
		options.reApplySetOptions();
		if (toggleFullScreen)
		{
			toggleFullscreen();
			toggleFullScreen = false;
		}
		input.Update();
		if (frameByFrame)
		{
			KeyboardState keyboardState = GetKeyboardState();
			if (((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)27) && ((KeyboardState)(ref oldKBState)).IsKeyUp((Keys)27))
			{
				frameByFrame = false;
			}
			keyboardState = GetKeyboardState();
			if (!((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)71) || !((KeyboardState)(ref oldKBState)).IsKeyUp((Keys)71))
			{
				oldKBState = GetKeyboardState();
				return;
			}
		}
		if (client != null && client.timedOut)
		{
			multiplayer.clientRemotelyDisconnected(client.pendingDisconnect);
		}
		if (_newDayTask != null)
		{
			if (_newDayTask.Status == TaskStatus.Created)
			{
				hooks.StartTask(_newDayTask, "NewDay");
			}
			if (_newDayTask.Status >= TaskStatus.RanToCompletion)
			{
				if (_newDayTask.IsFaulted)
				{
					Exception baseException = _newDayTask.Exception.GetBaseException();
					if (!IsMasterGame)
					{
						if (baseException is AbortNetSynchronizerException)
						{
							log.Verbose("_newDayTask failed: client lost connection to the server");
						}
						else
						{
							log.Error("Client _newDayTask failed with an exception:", baseException);
						}
						multiplayer.clientRemotelyDisconnected(Multiplayer.DisconnectType.ClientTimeout);
						_newDayTask = null;
						Utility.CollectGarbage();
						return;
					}
					log.Error("_newDayTask failed with an exception:", baseException);
					throw new Exception($"Error on new day: \n---------------\n{baseException}\n---------------\n");
				}
				_newDayTask = null;
				Utility.CollectGarbage();
			}
			UpdateChatBox();
			return;
		}
		if (isLocalMultiplayerNewDayActive)
		{
			UpdateChatBox();
			return;
		}
		if (IsSaving)
		{
			PushUIMode();
			activeClickableMenu?.update(gameTime);
			if (overlayMenu != null)
			{
				overlayMenu.update(gameTime);
				if (overlayMenu == null)
				{
					PopUIMode();
					return;
				}
			}
			PopUIMode();
			UpdateChatBox();
			return;
		}
		if (exitToTitle)
		{
			exitToTitle = false;
			CleanupReturningToTitle();
			Utility.CollectGarbage();
			postExitToTitleCallback?.Invoke();
		}
		SetFreeCursorElapsed((float)gameTime.ElapsedGameTime.TotalSeconds);
		Program.sdk.Update();
		if (game1.IsMainInstance)
		{
			keyboardFocusInstance = game1;
			foreach (Game1 gameInstance in GameRunner.instance.gameInstances)
			{
				if (gameInstance.instanceKeyboardDispatcher.Subscriber != null && gameInstance.instanceTextEntry != null)
				{
					keyboardFocusInstance = gameInstance;
					break;
				}
			}
		}
		if (base.IsMainInstance)
		{
			int displayIndex = base.Window.GetDisplayIndex();
			if (_lastUsedDisplay != -1 && _lastUsedDisplay != displayIndex)
			{
				StartupPreferences startupPreferences = new StartupPreferences();
				startupPreferences.loadPreferences(async: false, applyLanguage: false);
				startupPreferences.displayIndex = displayIndex;
				startupPreferences.savePreferences(async: false);
			}
			_lastUsedDisplay = displayIndex;
		}
		if (HasKeyboardFocus())
		{
			keyboardDispatcher.Poll();
		}
		else
		{
			keyboardDispatcher.Discard();
		}
		if (gameMode == 6)
		{
			multiplayer.UpdateLoading();
		}
		if (gameMode == 3)
		{
			multiplayer.UpdateEarly();
			dedicatedServer.Tick();
			if (player?.team != null)
			{
				player.team.Update();
			}
		}
		if ((paused || (!IsActiveNoOverlay && Program.releaseBuild)) && (options == null || options.pauseWhenOutOfFocus || paused) && multiplayerMode == 0)
		{
			UpdateChatBox();
			return;
		}
		if (quit)
		{
			Exit();
		}
		currentGameTime = gameTime;
		if (gameMode != 11 && !ShouldLoadIncrementally)
		{
			ticks++;
			if (IsActiveNoOverlay)
			{
				checkForEscapeKeys();
			}
			updateMusic();
			updateRaindropPosition();
			if (globalFade)
			{
				screenFade.UpdateGlobalFade();
			}
			else if (pauseThenDoFunctionTimer > 0)
			{
				freezeControls = true;
				pauseThenDoFunctionTimer -= gameTime.ElapsedGameTime.Milliseconds;
				if (pauseThenDoFunctionTimer <= 0)
				{
					freezeControls = false;
					afterPause?.Invoke();
				}
			}
			if (options.gamepadControls && (activeClickableMenu?.shouldClampGamePadCursor() ?? false))
			{
				Point mousePositionRaw = getMousePositionRaw();
				Rectangle val = default(Rectangle);
				((Rectangle)(ref val))._002Ector(0, 0, localMultiplayerWindow.Width, localMultiplayerWindow.Height);
				if (mousePositionRaw.X < val.X)
				{
					mousePositionRaw.X = val.X;
				}
				else if (mousePositionRaw.X > ((Rectangle)(ref val)).Right)
				{
					mousePositionRaw.X = ((Rectangle)(ref val)).Right;
				}
				if (mousePositionRaw.Y < val.Y)
				{
					mousePositionRaw.Y = val.Y;
				}
				else if (mousePositionRaw.Y > ((Rectangle)(ref val)).Bottom)
				{
					mousePositionRaw.Y = ((Rectangle)(ref val)).Bottom;
				}
				setMousePositionRaw(mousePositionRaw.X, mousePositionRaw.Y);
			}
			if (gameMode == 3 || gameMode == 2)
			{
				if (!warpingForForcedRemoteEvent && !eventUp && !dialogueUp && remoteEventQueue.Count > 0 && player != null && player.isCustomized.Value && (!fadeIn || !(fadeToBlackAlpha > 0f)))
				{
					if (activeClickableMenu != null)
					{
						activeClickableMenu.emergencyShutDown();
						exitActiveMenu();
					}
					else if (currentMinigame != null && currentMinigame.forceQuit())
					{
						currentMinigame = null;
					}
					if (activeClickableMenu == null && currentMinigame == null && player.freezePause <= 0)
					{
						Action action = remoteEventQueue[0];
						remoteEventQueue.RemoveAt(0);
						action();
					}
				}
				player.millisecondsPlayed += (uint)gameTime.ElapsedGameTime.Milliseconds;
				bool flag2 = true;
				if (currentMinigame != null && !HostPaused)
				{
					if (pauseTime > 0f)
					{
						updatePause(gameTime);
					}
					if (fadeToBlack)
					{
						screenFade.UpdateFadeAlpha(gameTime);
						if (fadeToBlackAlpha >= 1f)
						{
							fadeToBlack = false;
						}
					}
					else
					{
						if (thumbstickMotionMargin > 0)
						{
							thumbstickMotionMargin -= gameTime.ElapsedGameTime.Milliseconds;
						}
						KeyboardState val2 = default(KeyboardState);
						MouseState val3 = default(MouseState);
						GamePadState padState = default(GamePadState);
						if (base.IsActive)
						{
							val2 = GetKeyboardState();
							val3 = input.GetMouseState();
							padState = input.GetGamePadState();
							if ((chatBox?.isActive() ?? false) || textEntry != null)
							{
								val2 = default(KeyboardState);
								padState = default(GamePadState);
							}
							else
							{
								Keys[] pressedKeys = ((KeyboardState)(ref val2)).GetPressedKeys();
								foreach (Keys val4 in pressedKeys)
								{
									if (!((KeyboardState)(ref oldKBState)).IsKeyDown(val4) && currentMinigame != null)
									{
										currentMinigame.receiveKeyPress(val4);
									}
								}
								if (options.gamepadControls)
								{
									if (currentMinigame == null)
									{
										oldMouseState = val3;
										oldKBState = val2;
										oldPadState = padState;
										UpdateChatBox();
										return;
									}
									ButtonCollection.ButtonEnumerator enumerator2 = Utility.getPressedButtons(padState, oldPadState).GetEnumerator();
									while (enumerator2.MoveNext())
									{
										Buttons current2 = enumerator2.Current;
										currentMinigame?.receiveKeyPress(Utility.mapGamePadButtonToKey(current2));
									}
									if (currentMinigame == null)
									{
										oldMouseState = val3;
										oldKBState = val2;
										oldPadState = padState;
										UpdateChatBox();
										return;
									}
									GamePadThumbSticks thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
									if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y < -0.2f)
									{
										thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
										if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y >= -0.2f)
										{
											currentMinigame.receiveKeyPress((Keys)40);
										}
									}
									thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
									if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y > 0.2f)
									{
										thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
										if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y <= 0.2f)
										{
											currentMinigame.receiveKeyPress((Keys)38);
										}
									}
									thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
									if (((GamePadThumbSticks)(ref thumbSticks)).Right.X < -0.2f)
									{
										thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
										if (((GamePadThumbSticks)(ref thumbSticks)).Right.X >= -0.2f)
										{
											currentMinigame.receiveKeyPress((Keys)37);
										}
									}
									thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
									if (((GamePadThumbSticks)(ref thumbSticks)).Right.X > 0.2f)
									{
										thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
										if (((GamePadThumbSticks)(ref thumbSticks)).Right.X <= 0.2f)
										{
											currentMinigame.receiveKeyPress((Keys)39);
										}
									}
									thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
									if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y < -0.2f)
									{
										thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
										if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y >= -0.2f)
										{
											currentMinigame.receiveKeyRelease((Keys)40);
										}
									}
									thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
									if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y > 0.2f)
									{
										thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
										if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y <= 0.2f)
										{
											currentMinigame.receiveKeyRelease((Keys)38);
										}
									}
									thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
									if (((GamePadThumbSticks)(ref thumbSticks)).Right.X < -0.2f)
									{
										thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
										if (((GamePadThumbSticks)(ref thumbSticks)).Right.X >= -0.2f)
										{
											currentMinigame.receiveKeyRelease((Keys)37);
										}
									}
									thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
									if (((GamePadThumbSticks)(ref thumbSticks)).Right.X > 0.2f)
									{
										thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
										if (((GamePadThumbSticks)(ref thumbSticks)).Right.X <= 0.2f)
										{
											currentMinigame.receiveKeyRelease((Keys)39);
										}
									}
									if (isGamePadThumbstickInMotion() && currentMinigame != null && !currentMinigame.overrideFreeMouseMovement())
									{
										int mouseX = getMouseX();
										thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
										int x = mouseX + (int)(((GamePadThumbSticks)(ref thumbSticks)).Left.X * thumbstickToMouseModifier);
										int mouseY = getMouseY();
										thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
										setMousePosition(x, mouseY - (int)(((GamePadThumbSticks)(ref thumbSticks)).Left.Y * thumbstickToMouseModifier));
									}
									else if (getMouseX() != getOldMouseX() || getMouseY() != getOldMouseY())
									{
										lastCursorMotionWasMouse = true;
									}
								}
								pressedKeys = ((KeyboardState)(ref oldKBState)).GetPressedKeys();
								foreach (Keys val5 in pressedKeys)
								{
									if (!((KeyboardState)(ref val2)).IsKeyDown(val5) && currentMinigame != null)
									{
										currentMinigame.receiveKeyRelease(val5);
									}
								}
								if (options.gamepadControls)
								{
									if (currentMinigame == null)
									{
										oldMouseState = val3;
										oldKBState = val2;
										oldPadState = padState;
										UpdateChatBox();
										return;
									}
									if (((GamePadState)(ref padState)).IsConnected)
									{
										if (((GamePadState)(ref padState)).IsButtonDown((Buttons)16384) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)16384))
										{
											currentMinigame.receiveRightClick(getMouseX(), getMouseY());
										}
										else if (((GamePadState)(ref padState)).IsButtonDown((Buttons)4096) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096))
										{
											currentMinigame.receiveLeftClick(getMouseX(), getMouseY());
										}
										else if (!((GamePadState)(ref padState)).IsButtonDown((Buttons)16384) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)16384))
										{
											currentMinigame.releaseRightClick(getMouseX(), getMouseY());
										}
										else if (!((GamePadState)(ref padState)).IsButtonDown((Buttons)4096) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096))
										{
											currentMinigame.releaseLeftClick(getMouseX(), getMouseY());
										}
									}
									ButtonCollection.ButtonEnumerator enumerator2 = Utility.getPressedButtons(oldPadState, padState).GetEnumerator();
									while (enumerator2.MoveNext())
									{
										Buttons current3 = enumerator2.Current;
										currentMinigame?.receiveKeyRelease(Utility.mapGamePadButtonToKey(current3));
									}
									if (((GamePadState)(ref padState)).IsConnected && ((GamePadState)(ref padState)).IsButtonDown((Buttons)4096) && currentMinigame != null)
									{
										currentMinigame.leftClickHeld(0, 0);
									}
								}
								if (currentMinigame == null)
								{
									oldMouseState = val3;
									oldKBState = val2;
									oldPadState = padState;
									UpdateChatBox();
									return;
								}
								if (currentMinigame != null && (int)((MouseState)(ref val3)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton != 1)
								{
									currentMinigame.receiveLeftClick(getMouseX(), getMouseY());
								}
								if (currentMinigame != null && (int)((MouseState)(ref val3)).RightButton == 1 && (int)((MouseState)(ref oldMouseState)).RightButton != 1)
								{
									currentMinigame.receiveRightClick(getMouseX(), getMouseY());
								}
								if (currentMinigame != null && (int)((MouseState)(ref val3)).LeftButton == 0 && (int)((MouseState)(ref oldMouseState)).LeftButton == 1)
								{
									currentMinigame.releaseLeftClick(getMouseX(), getMouseY());
								}
								if (currentMinigame != null && (int)((MouseState)(ref val3)).RightButton == 0 && (int)((MouseState)(ref oldMouseState)).RightButton == 1)
								{
									currentMinigame.releaseLeftClick(getMouseX(), getMouseY());
								}
								if (currentMinigame != null && (int)((MouseState)(ref val3)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton == 1)
								{
									currentMinigame.leftClickHeld(getMouseX(), getMouseY());
								}
							}
						}
						if (currentMinigame != null && currentMinigame.tick(gameTime))
						{
							oldMouseState = val3;
							oldKBState = val2;
							oldPadState = padState;
							currentMinigame?.unload();
							currentMinigame = null;
							fadeIn = true;
							fadeToBlackAlpha = 1f;
							UpdateChatBox();
							return;
						}
						if (currentMinigame == null && IsMusicContextActive((MusicContext)4))
						{
							stopMusicTrack((MusicContext)4);
						}
						oldMouseState = val3;
						oldKBState = val2;
						oldPadState = padState;
					}
					flag2 = IsMultiplayer || currentMinigame == null || currentMinigame.doMainGameUpdates();
				}
				else if (farmEvent != null && !HostPaused && farmEvent.tickUpdate(gameTime))
				{
					farmEvent.makeChangesToLocation();
					timeOfDay = 600;
					outdoorLight = Color.White;
					displayHUD = true;
					farmEvent = null;
					netWorldState.Value.WriteToGame1();
					currentLocation = player.currentLocation;
					LocationRequest obj = getLocationRequest(currentLocation.Name);
					obj.OnWarp += delegate
					{
						//IL_0014: Unknown result type (might be due to invalid IL or missing references)
						//IL_0019: Unknown result type (might be due to invalid IL or missing references)
						//IL_0023: Unknown result type (might be due to invalid IL or missing references)
						if (currentLocation is FarmHouse farmHouse)
						{
							player.Position = Utility.PointToVector2(farmHouse.GetPlayerBedSpot()) * 64f;
							BedFurniture.ShiftPositionForBed(player);
						}
						else
						{
							BedFurniture.ApplyWakeUpPosition(player);
						}
						if (player.IsSitting())
						{
							player.StopSitting(animate: false);
						}
						changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
						player.forceCanMove();
						freezeControls = false;
						displayFarmer = true;
						viewportFreeze = false;
						fadeToBlackAlpha = 0f;
						fadeToBlack = false;
						globalFadeToClear();
						RemoveDeliveredMailForTomorrow();
						handlePostFarmEventActions();
						showEndOfNightStuff();
					};
					warpFarmer(obj, 5, 9, player.FacingDirection);
					fadeToBlackAlpha = 1.1f;
					fadeToBlack = true;
					nonWarpFade = false;
					UpdateOther(gameTime);
				}
				if (flag2)
				{
					if (endOfNightMenus.Count > 0 && activeClickableMenu == null)
					{
						activeClickableMenu = endOfNightMenus.Pop();
						if (activeClickableMenu != null && options.SnappyMenus)
						{
							activeClickableMenu.snapToDefaultClickableComponent();
						}
					}
					specialCurrencyDisplay?.Update(gameTime);
					if (currentLocation != null && currentMinigame == null)
					{
						if (emoteMenu != null)
						{
							emoteMenu.update(gameTime);
							if (emoteMenu != null)
							{
								PushUIMode();
								emoteMenu.performHoverAction(getMouseX(), getMouseY());
								KeyboardState keyboardState2 = GetKeyboardState();
								MouseState mouseState = input.GetMouseState();
								if ((int)((MouseState)(ref mouseState)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton == 0)
								{
									emoteMenu.receiveLeftClick(getMouseX(), getMouseY());
								}
								else
								{
									mouseState = input.GetMouseState();
									if ((int)((MouseState)(ref mouseState)).RightButton == 1 && (int)((MouseState)(ref oldMouseState)).RightButton == 0)
									{
										emoteMenu.receiveRightClick(getMouseX(), getMouseY());
									}
									else if (isOneOfTheseKeysDown(keyboardState2, options.menuButton) || (isOneOfTheseKeysDown(keyboardState2, options.emoteButton) && areAllOfTheseKeysUp(oldKBState, options.emoteButton)))
									{
										emoteMenu.exitThisMenu(playSound: false);
									}
								}
								PopUIMode();
								oldKBState = keyboardState2;
								oldMouseState = input.GetMouseState();
							}
						}
						else if (textEntry != null)
						{
							PushUIMode();
							updateTextEntry(gameTime);
							PopUIMode();
						}
						else if (activeClickableMenu != null)
						{
							PushUIMode();
							updateActiveMenu(gameTime);
							PopUIMode();
						}
						else
						{
							if (pauseTime > 0f)
							{
								updatePause(gameTime);
							}
							if (!globalFade && !freezeControls && activeClickableMenu == null && (IsActiveNoOverlay || inputSimulator != null))
							{
								UpdateControlInput(gameTime);
							}
						}
					}
					if (showingEndOfNightStuff && endOfNightMenus.Count == 0 && activeClickableMenu == null)
					{
						newDaySync.destroy();
						player.team.endOfNightStatus.WithdrawState();
						showingEndOfNightStuff = false;
						Action afterNewDayAction = _afterNewDayAction;
						if (afterNewDayAction != null)
						{
							_afterNewDayAction = null;
							afterNewDayAction();
						}
						player.ReequipEnchantments();
						globalFadeToClear(doMorningStuff);
					}
					if (currentLocation != null)
					{
						if (!HostPaused && !showingEndOfNightStuff)
						{
							if (IsMultiplayer || (activeClickableMenu == null && currentMinigame == null) || player.viewingLocation.Value != null)
							{
								UpdateGameClock(gameTime);
							}
							UpdateCharacters(gameTime);
							UpdateLocations(gameTime);
							if (currentMinigame == null)
							{
								UpdateViewPort(overrideFreeze: false, getViewportCenter());
							}
							else
							{
								previousViewportPosition.X = ((Rectangle)(ref viewport)).X;
								previousViewportPosition.Y = ((Rectangle)(ref viewport)).Y;
							}
							UpdateOther(gameTime);
						}
						if (messagePause)
						{
							KeyboardState keyboardState3 = GetKeyboardState();
							MouseState mouseState2 = input.GetMouseState();
							GamePadState gamePadState = input.GetGamePadState();
							if (isOneOfTheseKeysDown(keyboardState3, options.actionButton) && !isOneOfTheseKeysDown(oldKBState, options.actionButton))
							{
								pressActionButton(keyboardState3, mouseState2, gamePadState);
							}
							oldKBState = keyboardState3;
							oldPadState = gamePadState;
						}
					}
				}
				else if (textEntry != null)
				{
					PushUIMode();
					updateTextEntry(gameTime);
					PopUIMode();
				}
			}
			else
			{
				UpdateTitleScreen(gameTime);
				if (textEntry != null)
				{
					PushUIMode();
					updateTextEntry(gameTime);
					PopUIMode();
				}
				else if (activeClickableMenu != null)
				{
					PushUIMode();
					updateActiveMenu(gameTime);
					PopUIMode();
				}
				if (gameMode == 10)
				{
					UpdateOther(gameTime);
				}
			}
			audioEngine?.Update();
			UpdateChatBox();
			if (gameMode != 6)
			{
				multiplayer.UpdateLate();
			}
		}
		else if (ShouldLoadIncrementally)
		{
			Stopwatch stopwatch = Stopwatch.StartNew();
			do
			{
				if (!LoadContentEnumerator.MoveNext())
				{
					FinishedFirstLoadContent = true;
					break;
				}
			}
			while (stopwatch.Elapsed.TotalMilliseconds < 25.0);
			if (FinishedFirstLoadContent && FinishedFirstInitSounds && FinishedFirstInitSerializers)
			{
				FinishedIncrementalLoad = true;
				AfterLoadContent();
			}
		}
		if (gameMode == 3 && gameModeTicks == 1)
		{
			OnDayStarted();
		}
	}

	public static void OnDayStarted()
	{
		TriggerActionManager.Raise("DayStarted");
		Utility.ForEachLocation(delegate(GameLocation location)
		{
			location.OnDayStarted();
			return true;
		});
		Utility.fixAllAnimals();
		foreach (NPC allCharacter in Utility.getAllCharacters())
		{
			allCharacter.OnDayStarted();
		}
		Utility.ForEachLocation(delegate(GameLocation location)
		{
			foreach (FarmAnimal value in location.animals.Values)
			{
				value.OnDayStarted();
			}
			return true;
		});
		player.currentLocation.resetForPlayerEntry();
		if (!hasStartedDay)
		{
			foreach (string buildingType in player.team.constructedBuildings)
			{
				player.NotifyQuests((Quest quest) => quest.OnBuildingExists(buildingType));
			}
			if (Stats.AllowRetroactiveAchievements)
			{
				foreach (int achievement in player.achievements)
				{
					getPlatformAchievement(achievement.ToString());
				}
			}
			hasStartedDay = true;
		}
		if (IsMasterGame)
		{
			Woods.ResetLostItemsShop();
		}
	}

	public static void PerformPassiveFestivalSetup()
	{
		foreach (string activePassiveFestival in netWorldState.Value.ActivePassiveFestivals)
		{
			if (Utility.TryGetPassiveFestivalData(activePassiveFestival, out var data) && data.DailySetupMethod != null)
			{
				if (StaticDelegateBuilder.TryCreateDelegate<FestivalDailySetupDelegate>(data.DailySetupMethod, out var createdDelegate, out var error))
				{
					createdDelegate();
					continue;
				}
				log.Warn($"Passive festival '{activePassiveFestival}' has invalid daily setup method '{data.DailySetupMethod}': {error}");
			}
		}
	}

	public static void showTextEntry(TextBox text_box)
	{
		timerUntilMouseFade = 0;
		PushUIMode();
		textEntry = new TextEntryMenu(text_box);
		PopUIMode();
	}

	public static void closeTextEntry()
	{
		if (textEntry != null)
		{
			textEntry = null;
		}
		if (activeClickableMenu != null && options.SnappyMenus)
		{
			if (activeClickableMenu is TitleMenu && TitleMenu.subMenu != null)
			{
				TitleMenu.subMenu.snapCursorToCurrentSnappedComponent();
			}
			else
			{
				activeClickableMenu.snapCursorToCurrentSnappedComponent();
			}
		}
	}

	public static bool isDarkOut(GameLocation location)
	{
		return timeOfDay >= getTrulyDarkTime(location);
	}

	public static bool isTimeToTurnOffLighting(GameLocation location)
	{
		return timeOfDay >= getTrulyDarkTime(location) - 100;
	}

	public static bool isStartingToGetDarkOut(GameLocation location)
	{
		return timeOfDay >= getStartingToGetDarkTime(location);
	}

	public static int getStartingToGetDarkTime(GameLocation location)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Invalid comparison between Unknown and I4
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Invalid comparison between Unknown and I4
		if (location != null && location.InIslandContext())
		{
			return 1800;
		}
		Season val = season;
		if ((int)val != 2)
		{
			if ((int)val == 3)
			{
				return 1500;
			}
			return 1800;
		}
		return 1700;
	}

	public static void updateCellarAssignments()
	{
		if (!IsMasterGame)
		{
			return;
		}
		player.team.cellarAssignments[1] = MasterPlayer.UniqueMultiplayerID;
		for (int i = 2; i <= netWorldState.Value.HighestPlayerLimit; i++)
		{
			string name = "Cellar" + i;
			if (i == 1 || getLocationFromName(name) == null)
			{
				continue;
			}
			if (player.team.cellarAssignments.TryGetValue(i, out var value))
			{
				if (GetPlayer(value) != null)
				{
					continue;
				}
				player.team.cellarAssignments.Remove(i);
			}
			foreach (Farmer allFarmer in getAllFarmers())
			{
				if (!player.team.cellarAssignments.Values.Contains(allFarmer.UniqueMultiplayerID))
				{
					player.team.cellarAssignments[i] = allFarmer.UniqueMultiplayerID;
					break;
				}
			}
		}
	}

	public static int getModeratelyDarkTime(GameLocation location)
	{
		return (getTrulyDarkTime(location) + getStartingToGetDarkTime(location)) / 2;
	}

	public static int getTrulyDarkTime(GameLocation location)
	{
		return getStartingToGetDarkTime(location) + 200;
	}

	public static void playMorningSong(bool ignoreDelay = false)
	{
		LocationContextData context;
		if (!eventUp && dayOfMonth > 0)
		{
			LocationData data = currentLocation.GetData();
			if (currentLocation.GetLocationSpecificMusic() != null && (data == null || !data.MusicIsTownTheme))
			{
				changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
				GameLocation.HandleMusicChange(null, currentLocation);
				return;
			}
			if (IsRainingHere())
			{
				if (ignoreDelay)
				{
					PlayRain();
				}
				else
				{
					morningSongPlayAction = DelayedAction.functionAfterDelay(PlayRain, 500);
				}
				return;
			}
			context = currentLocation?.GetLocationContext();
			if (context?.DefaultMusic != null)
			{
				if (context.DefaultMusicCondition == null || GameStateQuery.CheckConditions(context.DefaultMusicCondition))
				{
					if (ignoreDelay)
					{
						PlayLocationSong();
					}
					else
					{
						morningSongPlayAction = DelayedAction.functionAfterDelay(PlayLocationSong, 500);
					}
				}
			}
			else if (ignoreDelay)
			{
				PlayDefault();
			}
			else
			{
				morningSongPlayAction = DelayedAction.functionAfterDelay(PlayDefault, 500);
			}
		}
		else if (getMusicTrackName((MusicContext)0) == "silence")
		{
			changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
		}
		static void PlayDefault()
		{
			changeMusicTrack(currentLocation.GetMorningSong(), track_interruptable: true, (MusicContext)0);
			IsPlayingBackgroundMusic = true;
			IsPlayingMorningSong = true;
		}
		void PlayLocationSong()
		{
			if (currentLocation == null)
			{
				changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
			}
			else
			{
				changeMusicTrack(context.DefaultMusic, track_interruptable: true, (MusicContext)0);
				IsPlayingBackgroundMusic = true;
			}
		}
		static void PlayRain()
		{
			changeMusicTrack("rain", track_interruptable: true, (MusicContext)0);
		}
	}

	public static void doMorningStuff()
	{
		playMorningSong();
		DelayedAction.functionAfterDelay(delegate
		{
			while (morningQueue.Count > 0)
			{
				morningQueue.Dequeue()();
			}
		}, 1000);
		if (player.hasPendingCompletedQuests)
		{
			dayTimeMoneyBox.PingQuestLog();
		}
	}

	public static void addMorningFluffFunction(Action action)
	{
		morningQueue.Enqueue(action);
	}

	private Point getViewportCenter()
	{
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		if (viewportTarget.X != -2.1474836E+09f)
		{
			if (!(Math.Abs((float)viewportCenter.X - viewportTarget.X) <= viewportSpeed) || !(Math.Abs((float)viewportCenter.Y - viewportTarget.Y) <= viewportSpeed))
			{
				Vector2 velocityTowardPoint = Utility.getVelocityTowardPoint(viewportCenter, viewportTarget, viewportSpeed);
				viewportCenter.X += (int)Math.Round(velocityTowardPoint.X);
				viewportCenter.Y += (int)Math.Round(velocityTowardPoint.Y);
			}
			else
			{
				if (viewportReachedTarget != null)
				{
					viewportReachedTarget();
					viewportReachedTarget = null;
				}
				viewportHold -= currentGameTime.ElapsedGameTime.Milliseconds;
				if (viewportHold <= 0)
				{
					viewportTarget = new Vector2(-2.1474836E+09f, -2.1474836E+09f);
					afterViewport?.Invoke();
				}
			}
		}
		else
		{
			viewportCenter = getPlayerOrEventFarmer().StandingPixel;
		}
		return viewportCenter;
	}

	public static void afterFadeReturnViewportToPlayer()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		viewportTarget = new Vector2(-2.1474836E+09f, -2.1474836E+09f);
		viewportHold = 0;
		viewportFreeze = false;
		viewportCenter = player.StandingPixel;
		globalFadeToClear();
	}

	public static bool isViewportOnCustomPath()
	{
		return viewportTarget.X != -2.1474836E+09f;
	}

	public static void moveViewportTo(Vector2 target, float speed, int holdTimer = 0, afterFadeFunction reachedTarget = null, afterFadeFunction endFunction = null)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		viewportTarget = target;
		viewportSpeed = speed;
		viewportHold = holdTimer;
		afterViewport = endFunction;
		viewportReachedTarget = reachedTarget;
	}

	public static Farm getFarm()
	{
		return RequireLocation<Farm>("Farm");
	}

	public static void setMousePosition(int x, int y, bool ui_scale)
	{
		if (ui_scale)
		{
			setMousePositionRaw((int)((float)x * options.uiScale), (int)((float)y * options.uiScale));
		}
		else
		{
			setMousePositionRaw((int)((float)x * options.zoomLevel), (int)((float)y * options.zoomLevel));
		}
	}

	public static void setMousePosition(int x, int y)
	{
		setMousePosition(x, y, uiMode);
	}

	public static void setMousePosition(Point position, bool ui_scale)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		setMousePosition(position.X, position.Y, ui_scale);
	}

	public static void setMousePosition(Point position)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		setMousePosition(position, uiMode);
	}

	public static void setMousePositionRaw(int x, int y)
	{
		input.SetMousePosition(x, y);
		InvalidateOldMouseMovement();
		lastCursorMotionWasMouse = false;
	}

	public static Point getMousePositionRaw()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		return new Point(getMouseXRaw(), getMouseYRaw());
	}

	public static Point getMousePosition(bool ui_scale)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		return new Point(getMouseX(ui_scale), getMouseY(ui_scale));
	}

	public static Point getMousePosition()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		return getMousePosition(uiMode);
	}

	private static void ComputeCursorSpeed()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		_cursorSpeedDirty = false;
		GamePadState gamePadState = input.GetGamePadState();
		float num = 0.9f;
		bool flag = false;
		GamePadThumbSticks thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
		Vector2 val = ((GamePadThumbSticks)(ref thumbSticks)).Left;
		float num2 = ((Vector2)(ref val)).Length();
		thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
		val = ((GamePadThumbSticks)(ref thumbSticks)).Right;
		float num3 = ((Vector2)(ref val)).Length();
		if (num2 > num || num3 > num)
		{
			flag = true;
		}
		float num4 = 0.7f;
		float num5 = 2f;
		float num6 = 1f;
		if (_cursorDragEnabled)
		{
			num4 = 0.5f;
			num5 = 2f;
			num6 = 1f;
		}
		if (!flag)
		{
			num6 = -5f;
		}
		if (_cursorDragPrevEnabled != _cursorDragEnabled)
		{
			_cursorSpeedScale *= 0.5f;
		}
		_cursorDragPrevEnabled = _cursorDragEnabled;
		_cursorSpeedScale += _cursorUpdateElapsedSec * num6;
		_cursorSpeedScale = MathHelper.Clamp(_cursorSpeedScale, num4, num5);
		float num7 = 16f / (float)game1.TargetElapsedTime.TotalSeconds * _cursorSpeedScale;
		float num8 = num7 - _cursorSpeed;
		_cursorSpeed = num7;
		_cursorUpdateElapsedSec = 0f;
		if (debugMode)
		{
			log.Verbose("_cursorSpeed=" + _cursorSpeed.ToString("0.0") + ", _cursorSpeedScale=" + _cursorSpeedScale.ToString("0.0") + ", deltaSpeed=" + num8.ToString("0.0"));
		}
	}

	private static void SetFreeCursorElapsed(float elapsedSec)
	{
		if (elapsedSec != _cursorUpdateElapsedSec)
		{
			_cursorUpdateElapsedSec = elapsedSec;
			_cursorSpeedDirty = true;
		}
	}

	public static void ResetFreeCursorDrag()
	{
		if (_cursorDragEnabled)
		{
			_cursorSpeedDirty = true;
		}
		_cursorDragEnabled = false;
	}

	public static void SetFreeCursorDrag()
	{
		if (!_cursorDragEnabled)
		{
			_cursorSpeedDirty = true;
		}
		_cursorDragEnabled = true;
	}

	public static void updateActiveMenu(GameTime gameTime)
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Invalid comparison between Unknown and I4
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f5: Invalid comparison between Unknown and I4
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0369: Unknown result type (might be due to invalid IL or missing references)
		//IL_036f: Invalid comparison between Unknown and I4
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0376: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_0554: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0587: Unknown result type (might be due to invalid IL or missing references)
		//IL_058d: Invalid comparison between Unknown and I4
		//IL_0560: Unknown result type (might be due to invalid IL or missing references)
		//IL_0566: Invalid comparison between Unknown and I4
		//IL_04a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_04af: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0594: Unknown result type (might be due to invalid IL or missing references)
		//IL_059a: Invalid comparison between Unknown and I4
		//IL_0522: Unknown result type (might be due to invalid IL or missing references)
		//IL_0527: Unknown result type (might be due to invalid IL or missing references)
		//IL_052b: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0500: Unknown result type (might be due to invalid IL or missing references)
		//IL_0504: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_060b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d50: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d56: Invalid comparison between Unknown and I4
		//IL_05e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0850: Unknown result type (might be due to invalid IL or missing references)
		//IL_069b: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_063b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0640: Unknown result type (might be due to invalid IL or missing references)
		//IL_0644: Unknown result type (might be due to invalid IL or missing references)
		//IL_0655: Unknown result type (might be due to invalid IL or missing references)
		//IL_065a: Unknown result type (might be due to invalid IL or missing references)
		//IL_065e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d84: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d89: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d8a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d8f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d90: Unknown result type (might be due to invalid IL or missing references)
		//IL_091a: Unknown result type (might be due to invalid IL or missing references)
		//IL_072b: Unknown result type (might be due to invalid IL or missing references)
		//IL_097f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0880: Unknown result type (might be due to invalid IL or missing references)
		//IL_0885: Unknown result type (might be due to invalid IL or missing references)
		//IL_0889: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_094a: Unknown result type (might be due to invalid IL or missing references)
		//IL_094f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0953: Unknown result type (might be due to invalid IL or missing references)
		//IL_075b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0760: Unknown result type (might be due to invalid IL or missing references)
		//IL_0764: Unknown result type (might be due to invalid IL or missing references)
		//IL_0775: Unknown result type (might be due to invalid IL or missing references)
		//IL_077a: Unknown result type (might be due to invalid IL or missing references)
		//IL_077e: Unknown result type (might be due to invalid IL or missing references)
		//IL_09af: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a09: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_080a: Unknown result type (might be due to invalid IL or missing references)
		//IL_080f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0813: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a41: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a79: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c0c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b21: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b82: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c25: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bda: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c39: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c3e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c63: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cba: Unknown result type (might be due to invalid IL or missing references)
		IClickableMenu childMenu = activeClickableMenu;
		while (childMenu.GetChildMenu() != null)
		{
			childMenu = childMenu.GetChildMenu();
		}
		if (!Program.gamePtr.IsActiveNoOverlay && Program.releaseBuild)
		{
			if (childMenu != null && childMenu.IsActive())
			{
				childMenu.update(gameTime);
			}
			return;
		}
		MouseState mouseState = input.GetMouseState();
		KeyboardState keyboardState = GetKeyboardState();
		GamePadState gamePadState = input.GetGamePadState();
		if (CurrentEvent != null)
		{
			if (((int)((MouseState)(ref mouseState)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton == 0) || (options.gamepadControls && ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4096) && ((GamePadState)(ref oldPadState)).IsButtonUp((Buttons)4096)))
			{
				CurrentEvent.receiveMouseClick(getMouseX(), getMouseY());
			}
			else if (options.gamepadControls && ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)32) && ((GamePadState)(ref oldPadState)).IsButtonUp((Buttons)32) && !CurrentEvent.skipped && CurrentEvent.skippable)
			{
				CurrentEvent.skipped = true;
				CurrentEvent.skipEvent();
				freezeControls = false;
			}
			if (CurrentEvent != null && CurrentEvent.skipped)
			{
				oldMouseState = input.GetMouseState();
				oldKBState = keyboardState;
				oldPadState = gamePadState;
				return;
			}
		}
		GamePadThumbSticks thumbSticks;
		if (options.gamepadControls && childMenu != null && childMenu.IsActive())
		{
			if (isGamePadThumbstickInMotion() && (!options.snappyMenus || childMenu.overrideSnappyMenuCursorMovementBan()))
			{
				float num = ((MouseState)(ref mouseState)).X;
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				int x = (int)(num + ((GamePadThumbSticks)(ref thumbSticks)).Left.X * thumbstickToMouseModifier);
				float num2 = ((MouseState)(ref mouseState)).Y;
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				setMousePositionRaw(x, (int)(num2 - ((GamePadThumbSticks)(ref thumbSticks)).Left.Y * thumbstickToMouseModifier));
			}
			if (childMenu != null && childMenu.IsActive() && (chatBox == null || !chatBox.isActive()))
			{
				ButtonCollection.ButtonEnumerator enumerator = Utility.getPressedButtons(gamePadState, oldPadState).GetEnumerator();
				while (enumerator.MoveNext())
				{
					Buttons current = enumerator.Current;
					childMenu.receiveGamePadButton(current);
					if (childMenu == null || !childMenu.IsActive())
					{
						break;
					}
				}
				enumerator = Utility.getHeldButtons(gamePadState).GetEnumerator();
				while (enumerator.MoveNext())
				{
					Buttons current2 = enumerator.Current;
					if (childMenu != null && childMenu.IsActive())
					{
						childMenu.gamePadButtonHeld(current2);
					}
					if (childMenu == null || !childMenu.IsActive())
					{
						break;
					}
				}
			}
		}
		if ((getMouseX() != getOldMouseX() || getMouseY() != getOldMouseY()) && !isGamePadThumbstickInMotion() && !isDPadPressed())
		{
			lastCursorMotionWasMouse = true;
		}
		ResetFreeCursorDrag();
		if (childMenu != null && childMenu.IsActive())
		{
			childMenu.performHoverAction(getMouseX(), getMouseY());
		}
		if (childMenu != null && childMenu.IsActive())
		{
			childMenu.update(gameTime);
		}
		if (childMenu != null && childMenu.IsActive() && (int)((MouseState)(ref mouseState)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton == 0)
		{
			if (chatBox != null && chatBox.isActive() && chatBox.isWithinBounds(getMouseX(), getMouseY()))
			{
				chatBox.receiveLeftClick(getMouseX(), getMouseY());
			}
			else
			{
				childMenu.receiveLeftClick(getMouseX(), getMouseY());
			}
		}
		else if (childMenu != null && childMenu.IsActive() && (int)((MouseState)(ref mouseState)).RightButton == 1 && ((int)((MouseState)(ref oldMouseState)).RightButton == 0 || ((float)mouseClickPolling > 650f && !(childMenu is DialogueBox))))
		{
			childMenu.receiveRightClick(getMouseX(), getMouseY());
			if ((float)mouseClickPolling > 650f)
			{
				mouseClickPolling = 600;
			}
			if ((childMenu == null || !childMenu.IsActive()) && activeClickableMenu == null)
			{
				rightClickPolling = 500;
				mouseClickPolling = 0;
			}
		}
		if (((MouseState)(ref mouseState)).ScrollWheelValue != ((MouseState)(ref oldMouseState)).ScrollWheelValue && childMenu != null && childMenu.IsActive())
		{
			if (chatBox != null && chatBox.choosingEmoji && chatBox.emojiMenu.isWithinBounds(getOldMouseX(), getOldMouseY()))
			{
				chatBox.receiveScrollWheelAction(((MouseState)(ref mouseState)).ScrollWheelValue - ((MouseState)(ref oldMouseState)).ScrollWheelValue);
			}
			else
			{
				childMenu.receiveScrollWheelAction(((MouseState)(ref mouseState)).ScrollWheelValue - ((MouseState)(ref oldMouseState)).ScrollWheelValue);
			}
		}
		if (options.gamepadControls && childMenu != null && childMenu.IsActive())
		{
			thumbstickPollingTimer -= currentGameTime.ElapsedGameTime.Milliseconds;
			if (thumbstickPollingTimer <= 0)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y > 0.2f)
				{
					childMenu.receiveScrollWheelAction(1);
				}
				else
				{
					thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
					if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y < -0.2f)
					{
						childMenu.receiveScrollWheelAction(-1);
					}
				}
			}
			if (thumbstickPollingTimer <= 0)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				thumbstickPollingTimer = 220 - (int)(Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Right.Y) * 170f);
			}
			thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
			if (Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Right.Y) < 0.2f)
			{
				thumbstickPollingTimer = 0;
			}
		}
		if (childMenu != null && childMenu.IsActive() && (int)((MouseState)(ref mouseState)).LeftButton == 0 && (int)((MouseState)(ref oldMouseState)).LeftButton == 1)
		{
			childMenu.releaseLeftClick(getMouseX(), getMouseY());
		}
		else if (childMenu != null && childMenu.IsActive() && (int)((MouseState)(ref mouseState)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton == 1)
		{
			childMenu.leftClickHeld(getMouseX(), getMouseY());
		}
		Keys[] pressedKeys = ((KeyboardState)(ref keyboardState)).GetPressedKeys();
		foreach (Keys val in pressedKeys)
		{
			if (childMenu != null && childMenu.IsActive() && !((KeyboardState)(ref oldKBState)).GetPressedKeys().Contains(val))
			{
				childMenu.receiveKeyPress(val);
			}
		}
		if (chatBox == null || !chatBox.isActive())
		{
			if (isOneOfTheseKeysDown(oldKBState, options.moveUpButton))
			{
				goto IL_0674;
			}
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				float num3 = Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.X);
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (num3 < ((GamePadThumbSticks)(ref thumbSticks)).Left.Y || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)1))
				{
					goto IL_0674;
				}
			}
			if (isOneOfTheseKeysDown(oldKBState, options.moveRightButton))
			{
				goto IL_0704;
			}
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				float x2 = ((GamePadThumbSticks)(ref thumbSticks)).Left.X;
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (x2 > Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.Y) || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)8))
				{
					goto IL_0704;
				}
			}
			if (isOneOfTheseKeysDown(oldKBState, options.moveDownButton))
			{
				goto IL_0799;
			}
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				float num4 = Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.X);
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (num4 < Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.Y) || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)2))
				{
					goto IL_0799;
				}
			}
			if (isOneOfTheseKeysDown(oldKBState, options.moveLeftButton))
			{
				goto IL_082e;
			}
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				float num5 = Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.X);
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (num5 > Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.Y) || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4))
				{
					goto IL_082e;
				}
			}
			goto IL_0850;
		}
		goto IL_0d4e;
		IL_09e4:
		if (directionKeyPolling[0] <= 0 && childMenu != null && childMenu.IsActive())
		{
			childMenu.receiveKeyPress(options.getFirstKeyboardKeyFromInputButtonList(options.moveUpButton));
			directionKeyPolling[0] = 70;
		}
		if (directionKeyPolling[1] <= 0 && childMenu != null && childMenu.IsActive())
		{
			childMenu.receiveKeyPress(options.getFirstKeyboardKeyFromInputButtonList(options.moveRightButton));
			directionKeyPolling[1] = 70;
		}
		if (directionKeyPolling[2] <= 0 && childMenu != null && childMenu.IsActive())
		{
			childMenu.receiveKeyPress(options.getFirstKeyboardKeyFromInputButtonList(options.moveDownButton));
			directionKeyPolling[2] = 70;
		}
		if (directionKeyPolling[3] <= 0 && childMenu != null && childMenu.IsActive())
		{
			childMenu.receiveKeyPress(options.getFirstKeyboardKeyFromInputButtonList(options.moveLeftButton));
			directionKeyPolling[3] = 70;
		}
		if (options.gamepadControls && childMenu != null && childMenu.IsActive())
		{
			if (!childMenu.areGamePadControlsImplemented() && ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4096) && (!((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096) || ((float)gamePadAButtonPolling > 650f && !(childMenu is DialogueBox))))
			{
				childMenu.receiveLeftClick(getMousePosition().X, getMousePosition().Y);
				if ((float)gamePadAButtonPolling > 650f)
				{
					gamePadAButtonPolling = 600;
				}
			}
			else if (!childMenu.areGamePadControlsImplemented() && !((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4096) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096))
			{
				childMenu.releaseLeftClick(getMousePosition().X, getMousePosition().Y);
			}
			else if (!childMenu.areGamePadControlsImplemented() && ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)16384) && (!((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)16384) || ((float)gamePadXButtonPolling > 650f && !(childMenu is DialogueBox))))
			{
				childMenu.receiveRightClick(getMousePosition().X, getMousePosition().Y);
				if ((float)gamePadXButtonPolling > 650f)
				{
					gamePadXButtonPolling = 600;
				}
			}
			ButtonCollection.ButtonEnumerator enumerator = Utility.getPressedButtons(gamePadState, oldPadState).GetEnumerator();
			while (enumerator.MoveNext())
			{
				Buttons current3 = enumerator.Current;
				if (childMenu == null || !childMenu.IsActive())
				{
					break;
				}
				Keys key = Utility.mapGamePadButtonToKey(current3);
				if (!(childMenu is FarmhandMenu) || game1.IsMainInstance || !options.doesInputListContain(options.menuButton, key))
				{
					childMenu.receiveKeyPress(key);
				}
			}
			if (childMenu != null && childMenu.IsActive() && !childMenu.areGamePadControlsImplemented() && ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4096) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096))
			{
				childMenu.leftClickHeld(getMousePosition().X, getMousePosition().Y);
			}
			if (((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)16384))
			{
				gamePadXButtonPolling += gameTime.ElapsedGameTime.Milliseconds;
			}
			else
			{
				gamePadXButtonPolling = 0;
			}
			if (((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4096))
			{
				gamePadAButtonPolling += gameTime.ElapsedGameTime.Milliseconds;
			}
			else
			{
				gamePadAButtonPolling = 0;
			}
			if (!childMenu.IsActive() && activeClickableMenu == null)
			{
				rightClickPolling = 500;
				gamePadXButtonPolling = 0;
				gamePadAButtonPolling = 0;
			}
		}
		goto IL_0d4e;
		IL_0799:
		directionKeyPolling[2] -= currentGameTime.ElapsedGameTime.Milliseconds;
		goto IL_0850;
		IL_08b5:
		if (areAllOfTheseKeysUp(oldKBState, options.moveRightButton))
		{
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (!((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X < 0.1) || !((GamePadState)(ref gamePadState)).IsButtonUp((Buttons)8))
				{
					goto IL_091a;
				}
			}
			directionKeyPolling[1] = 250;
		}
		goto IL_091a;
		IL_0850:
		if (areAllOfTheseKeysUp(oldKBState, options.moveUpButton))
		{
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (!((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y < 0.1) || !((GamePadState)(ref gamePadState)).IsButtonUp((Buttons)1))
				{
					goto IL_08b5;
				}
			}
			directionKeyPolling[0] = 250;
		}
		goto IL_08b5;
		IL_097f:
		if (areAllOfTheseKeysUp(oldKBState, options.moveLeftButton))
		{
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (!((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X > -0.1) || !((GamePadState)(ref gamePadState)).IsButtonUp((Buttons)4))
				{
					goto IL_09e4;
				}
			}
			directionKeyPolling[3] = 250;
		}
		goto IL_09e4;
		IL_0704:
		directionKeyPolling[1] -= currentGameTime.ElapsedGameTime.Milliseconds;
		goto IL_0850;
		IL_091a:
		if (areAllOfTheseKeysUp(oldKBState, options.moveDownButton))
		{
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (!((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y > -0.1) || !((GamePadState)(ref gamePadState)).IsButtonUp((Buttons)2))
				{
					goto IL_097f;
				}
			}
			directionKeyPolling[2] = 250;
		}
		goto IL_097f;
		IL_0674:
		directionKeyPolling[0] -= currentGameTime.ElapsedGameTime.Milliseconds;
		goto IL_0850;
		IL_082e:
		directionKeyPolling[3] -= currentGameTime.ElapsedGameTime.Milliseconds;
		goto IL_0850;
		IL_0d4e:
		if ((int)((MouseState)(ref mouseState)).RightButton == 1)
		{
			mouseClickPolling += gameTime.ElapsedGameTime.Milliseconds;
		}
		else
		{
			mouseClickPolling = 0;
		}
		oldMouseState = input.GetMouseState();
		oldKBState = keyboardState;
		oldPadState = gamePadState;
	}

	public bool ShowLocalCoopJoinMenu()
	{
		if (!base.IsMainInstance)
		{
			return false;
		}
		if (gameMode != 3)
		{
			return false;
		}
		int free_farmhands = 0;
		Utility.ForEachLocation(delegate(GameLocation location)
		{
			if (location is Cabin cabin && (!cabin.HasOwner || !cabin.IsOwnerActivated))
			{
				free_farmhands++;
			}
			return true;
		});
		if (free_farmhands == 0)
		{
			showRedMessage(content.LoadString("Strings\\UI:CoopMenu_NoSlots"));
			return false;
		}
		if (currentMinigame != null)
		{
			return false;
		}
		if (activeClickableMenu != null)
		{
			return false;
		}
		if (!IsLocalCoopJoinable())
		{
			return false;
		}
		playSound("bigSelect");
		activeClickableMenu = new LocalCoopJoinMenu();
		return true;
	}

	public static void updateTextEntry(GameTime gameTime)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Invalid comparison between Unknown and I4
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Invalid comparison between Unknown and I4
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Invalid comparison between Unknown and I4
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Invalid comparison between Unknown and I4
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Invalid comparison between Unknown and I4
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_039b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0378: Unknown result type (might be due to invalid IL or missing references)
		//IL_0386: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_042b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0645: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_06aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_070f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0610: Unknown result type (might be due to invalid IL or missing references)
		//IL_0615: Unknown result type (might be due to invalid IL or missing references)
		//IL_0619: Unknown result type (might be due to invalid IL or missing references)
		//IL_045b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0460: Unknown result type (might be due to invalid IL or missing references)
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_0470: Unknown result type (might be due to invalid IL or missing references)
		//IL_0475: Unknown result type (might be due to invalid IL or missing references)
		//IL_0479: Unknown result type (might be due to invalid IL or missing references)
		//IL_0675: Unknown result type (might be due to invalid IL or missing references)
		//IL_067a: Unknown result type (might be due to invalid IL or missing references)
		//IL_067e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0550: Unknown result type (might be due to invalid IL or missing references)
		//IL_06da: Unknown result type (might be due to invalid IL or missing references)
		//IL_06df: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0505: Unknown result type (might be due to invalid IL or missing references)
		//IL_050a: Unknown result type (might be due to invalid IL or missing references)
		//IL_050e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0799: Unknown result type (might be due to invalid IL or missing references)
		//IL_073f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0744: Unknown result type (might be due to invalid IL or missing references)
		//IL_0748: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0580: Unknown result type (might be due to invalid IL or missing references)
		//IL_0585: Unknown result type (might be due to invalid IL or missing references)
		//IL_0589: Unknown result type (might be due to invalid IL or missing references)
		//IL_059a: Unknown result type (might be due to invalid IL or missing references)
		//IL_059f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0809: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab2: Invalid comparison between Unknown and I4
		//IL_0841: Unknown result type (might be due to invalid IL or missing references)
		//IL_0adb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aeb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aec: Unknown result type (might be due to invalid IL or missing references)
		//IL_099c: Unknown result type (might be due to invalid IL or missing references)
		//IL_099d: Unknown result type (might be due to invalid IL or missing references)
		//IL_08aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0913: Unknown result type (might be due to invalid IL or missing references)
		//IL_091d: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_096b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0975: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a14: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1e: Unknown result type (might be due to invalid IL or missing references)
		MouseState mouseState = input.GetMouseState();
		KeyboardState keyboardState = GetKeyboardState();
		GamePadState gamePadState = input.GetGamePadState();
		if (options.gamepadControls && textEntry != null && textEntry != null)
		{
			ButtonCollection.ButtonEnumerator enumerator = Utility.getPressedButtons(gamePadState, oldPadState).GetEnumerator();
			while (enumerator.MoveNext())
			{
				Buttons current = enumerator.Current;
				textEntry.receiveGamePadButton(current);
				if (textEntry == null)
				{
					break;
				}
			}
			enumerator = Utility.getHeldButtons(gamePadState).GetEnumerator();
			while (enumerator.MoveNext())
			{
				Buttons current2 = enumerator.Current;
				textEntry?.gamePadButtonHeld(current2);
				if (textEntry == null)
				{
					break;
				}
			}
		}
		textEntry?.performHoverAction(getMouseX(), getMouseY());
		textEntry?.update(gameTime);
		if (textEntry != null && (int)((MouseState)(ref mouseState)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton == 0)
		{
			textEntry.receiveLeftClick(getMouseX(), getMouseY());
		}
		else if (textEntry != null && (int)((MouseState)(ref mouseState)).RightButton == 1 && ((int)((MouseState)(ref oldMouseState)).RightButton == 0 || (float)mouseClickPolling > 650f))
		{
			textEntry.receiveRightClick(getMouseX(), getMouseY());
			if ((float)mouseClickPolling > 650f)
			{
				mouseClickPolling = 600;
			}
			if (textEntry == null)
			{
				rightClickPolling = 500;
				mouseClickPolling = 0;
			}
		}
		if (((MouseState)(ref mouseState)).ScrollWheelValue != ((MouseState)(ref oldMouseState)).ScrollWheelValue && textEntry != null)
		{
			if (chatBox != null && chatBox.choosingEmoji && chatBox.emojiMenu.isWithinBounds(getOldMouseX(), getOldMouseY()))
			{
				chatBox.receiveScrollWheelAction(((MouseState)(ref mouseState)).ScrollWheelValue - ((MouseState)(ref oldMouseState)).ScrollWheelValue);
			}
			else
			{
				textEntry.receiveScrollWheelAction(((MouseState)(ref mouseState)).ScrollWheelValue - ((MouseState)(ref oldMouseState)).ScrollWheelValue);
			}
		}
		GamePadThumbSticks thumbSticks;
		if (options.gamepadControls && textEntry != null)
		{
			thumbstickPollingTimer -= currentGameTime.ElapsedGameTime.Milliseconds;
			if (thumbstickPollingTimer <= 0)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y > 0.2f)
				{
					textEntry.receiveScrollWheelAction(1);
				}
				else
				{
					thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
					if (((GamePadThumbSticks)(ref thumbSticks)).Right.Y < -0.2f)
					{
						textEntry.receiveScrollWheelAction(-1);
					}
				}
			}
			if (thumbstickPollingTimer <= 0)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				thumbstickPollingTimer = 220 - (int)(Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Right.Y) * 170f);
			}
			thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
			if (Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Right.Y) < 0.2f)
			{
				thumbstickPollingTimer = 0;
			}
		}
		if (textEntry != null && (int)((MouseState)(ref mouseState)).LeftButton == 0 && (int)((MouseState)(ref oldMouseState)).LeftButton == 1)
		{
			textEntry.releaseLeftClick(getMouseX(), getMouseY());
		}
		else if (textEntry != null && (int)((MouseState)(ref mouseState)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton == 1)
		{
			textEntry.leftClickHeld(getMouseX(), getMouseY());
		}
		Keys[] pressedKeys = ((KeyboardState)(ref keyboardState)).GetPressedKeys();
		foreach (Keys val in pressedKeys)
		{
			if (textEntry != null && !((KeyboardState)(ref oldKBState)).GetPressedKeys().Contains(val))
			{
				textEntry.receiveKeyPress(val);
			}
		}
		if (isOneOfTheseKeysDown(oldKBState, options.moveUpButton))
		{
			goto IL_0404;
		}
		if (options.snappyMenus && options.gamepadControls)
		{
			thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
			float num = Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.X);
			thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
			if (num < ((GamePadThumbSticks)(ref thumbSticks)).Left.Y || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)1))
			{
				goto IL_0404;
			}
		}
		if (isOneOfTheseKeysDown(oldKBState, options.moveRightButton))
		{
			goto IL_0494;
		}
		if (options.snappyMenus && options.gamepadControls)
		{
			thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
			float x = ((GamePadThumbSticks)(ref thumbSticks)).Left.X;
			thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
			if (x > Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.Y) || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)8))
			{
				goto IL_0494;
			}
		}
		if (isOneOfTheseKeysDown(oldKBState, options.moveDownButton))
		{
			goto IL_0529;
		}
		if (options.snappyMenus && options.gamepadControls)
		{
			thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
			float num2 = Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.X);
			thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
			if (num2 < Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.Y) || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)2))
			{
				goto IL_0529;
			}
		}
		if (isOneOfTheseKeysDown(oldKBState, options.moveLeftButton))
		{
			goto IL_05be;
		}
		if (options.snappyMenus && options.gamepadControls)
		{
			thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
			float num3 = Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.X);
			thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
			if (num3 > Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.Y) || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4))
			{
				goto IL_05be;
			}
		}
		goto IL_05e0;
		IL_0645:
		if (areAllOfTheseKeysUp(oldKBState, options.moveRightButton))
		{
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (!((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X < 0.1) || !((GamePadState)(ref gamePadState)).IsButtonUp((Buttons)8))
				{
					goto IL_06aa;
				}
			}
			directionKeyPolling[1] = 250;
		}
		goto IL_06aa;
		IL_05be:
		directionKeyPolling[3] -= currentGameTime.ElapsedGameTime.Milliseconds;
		goto IL_05e0;
		IL_0774:
		if (directionKeyPolling[0] <= 0 && textEntry != null)
		{
			textEntry.receiveKeyPress(options.getFirstKeyboardKeyFromInputButtonList(options.moveUpButton));
			directionKeyPolling[0] = 70;
		}
		if (directionKeyPolling[1] <= 0 && textEntry != null)
		{
			textEntry.receiveKeyPress(options.getFirstKeyboardKeyFromInputButtonList(options.moveRightButton));
			directionKeyPolling[1] = 70;
		}
		if (directionKeyPolling[2] <= 0 && textEntry != null)
		{
			textEntry.receiveKeyPress(options.getFirstKeyboardKeyFromInputButtonList(options.moveDownButton));
			directionKeyPolling[2] = 70;
		}
		if (directionKeyPolling[3] <= 0 && textEntry != null)
		{
			textEntry.receiveKeyPress(options.getFirstKeyboardKeyFromInputButtonList(options.moveLeftButton));
			directionKeyPolling[3] = 70;
		}
		if (options.gamepadControls && textEntry != null)
		{
			if (!textEntry.areGamePadControlsImplemented() && ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4096) && (!((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096) || (float)gamePadAButtonPolling > 650f))
			{
				textEntry.receiveLeftClick(getMousePosition().X, getMousePosition().Y);
				if ((float)gamePadAButtonPolling > 650f)
				{
					gamePadAButtonPolling = 600;
				}
			}
			else if (!textEntry.areGamePadControlsImplemented() && !((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4096) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096))
			{
				textEntry.releaseLeftClick(getMousePosition().X, getMousePosition().Y);
			}
			else if (!textEntry.areGamePadControlsImplemented() && ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)16384) && (!((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)16384) || (float)gamePadXButtonPolling > 650f))
			{
				textEntry.receiveRightClick(getMousePosition().X, getMousePosition().Y);
				if ((float)gamePadXButtonPolling > 650f)
				{
					gamePadXButtonPolling = 600;
				}
			}
			ButtonCollection.ButtonEnumerator enumerator = Utility.getPressedButtons(gamePadState, oldPadState).GetEnumerator();
			while (enumerator.MoveNext())
			{
				Buttons current3 = enumerator.Current;
				if (textEntry == null)
				{
					break;
				}
				textEntry.receiveKeyPress(Utility.mapGamePadButtonToKey(current3));
			}
			if (textEntry != null && !textEntry.areGamePadControlsImplemented() && ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4096) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096))
			{
				textEntry.leftClickHeld(getMousePosition().X, getMousePosition().Y);
			}
			if (((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)16384))
			{
				gamePadXButtonPolling += gameTime.ElapsedGameTime.Milliseconds;
			}
			else
			{
				gamePadXButtonPolling = 0;
			}
			if (((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4096))
			{
				gamePadAButtonPolling += gameTime.ElapsedGameTime.Milliseconds;
			}
			else
			{
				gamePadAButtonPolling = 0;
			}
			if (textEntry == null)
			{
				rightClickPolling = 500;
				gamePadAButtonPolling = 0;
				gamePadXButtonPolling = 0;
			}
		}
		if ((int)((MouseState)(ref mouseState)).RightButton == 1)
		{
			mouseClickPolling += gameTime.ElapsedGameTime.Milliseconds;
		}
		else
		{
			mouseClickPolling = 0;
		}
		oldMouseState = input.GetMouseState();
		oldKBState = keyboardState;
		oldPadState = gamePadState;
		return;
		IL_0494:
		directionKeyPolling[1] -= currentGameTime.ElapsedGameTime.Milliseconds;
		goto IL_05e0;
		IL_070f:
		if (areAllOfTheseKeysUp(oldKBState, options.moveLeftButton))
		{
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (!((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X > -0.1) || !((GamePadState)(ref gamePadState)).IsButtonUp((Buttons)4))
				{
					goto IL_0774;
				}
			}
			directionKeyPolling[3] = 250;
		}
		goto IL_0774;
		IL_05e0:
		if (areAllOfTheseKeysUp(oldKBState, options.moveUpButton))
		{
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (!((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y < 0.1) || !((GamePadState)(ref gamePadState)).IsButtonUp((Buttons)1))
				{
					goto IL_0645;
				}
			}
			directionKeyPolling[0] = 250;
		}
		goto IL_0645;
		IL_0529:
		directionKeyPolling[2] -= currentGameTime.ElapsedGameTime.Milliseconds;
		goto IL_05e0;
		IL_0404:
		directionKeyPolling[0] -= currentGameTime.ElapsedGameTime.Milliseconds;
		goto IL_05e0;
		IL_06aa:
		if (areAllOfTheseKeysUp(oldKBState, options.moveDownButton))
		{
			if (options.snappyMenus && options.gamepadControls)
			{
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (!((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y > -0.1) || !((GamePadState)(ref gamePadState)).IsButtonUp((Buttons)2))
				{
					goto IL_070f;
				}
			}
			directionKeyPolling[2] = 250;
		}
		goto IL_070f;
	}

	public static string DateCompiled()
	{
		Version version = Assembly.GetExecutingAssembly().GetName().Version;
		return version.Major + "." + version.Minor + "." + version.Build + "." + version.Revision;
	}

	public static void updatePause(GameTime gameTime)
	{
		if (IsDedicatedHost)
		{
			pauseTime = 0f;
		}
		pauseTime -= gameTime.ElapsedGameTime.Milliseconds;
		if (player.isCrafting && random.NextDouble() < 0.007)
		{
			playSound("crafting");
		}
		if (!(pauseTime <= 0f))
		{
			return;
		}
		if (currentObjectDialogue.Count == 0)
		{
			messagePause = false;
		}
		pauseTime = 0f;
		if (!string.IsNullOrEmpty(messageAfterPause))
		{
			player.isCrafting = false;
			drawObjectDialogue(messageAfterPause);
			messageAfterPause = "";
			if (killScreen)
			{
				killScreen = false;
				player.health = 10;
			}
		}
		else if (killScreen)
		{
			multiplayer.globalChatInfoMessage("PlayerDeath", player.Name);
			screenGlow = false;
			bool flag = false;
			if (currentLocation.GetLocationContext().ReviveLocations != null)
			{
				foreach (ReviveLocation reviveLocation in currentLocation.GetLocationContext().ReviveLocations)
				{
					if (GameStateQuery.CheckConditions(reviveLocation.Condition, null, player))
					{
						warpFarmer(reviveLocation.Location, reviveLocation.Position.X, reviveLocation.Position.Y, flip: false);
						flag = true;
						break;
					}
				}
			}
			else
			{
				foreach (ReviveLocation reviveLocation2 in LocationContexts.Default.ReviveLocations)
				{
					if (GameStateQuery.CheckConditions(reviveLocation2.Condition, null, player))
					{
						warpFarmer(reviveLocation2.Location, reviveLocation2.Position.X, reviveLocation2.Position.Y, flip: false);
						flag = true;
						break;
					}
				}
			}
			if (!flag)
			{
				warpFarmer("Hospital", 20, 12, flip: false);
			}
		}
		if (currentLocation.currentEvent != null)
		{
			currentLocation.currentEvent.CurrentCommand++;
		}
	}

	public static void CheckValidFullscreenResolution(ref int width, ref int height)
	{
		int num = width;
		int num2 = height;
		foreach (DisplayMode supportedDisplayMode in graphics.GraphicsDevice.Adapter.SupportedDisplayModes)
		{
			if (supportedDisplayMode.Width >= 1280 && supportedDisplayMode.Width == num && supportedDisplayMode.Height == num2)
			{
				width = num;
				height = num2;
				return;
			}
		}
		foreach (DisplayMode supportedDisplayMode2 in graphics.GraphicsDevice.Adapter.SupportedDisplayModes)
		{
			if (supportedDisplayMode2.Width >= 1280 && supportedDisplayMode2.Width == graphics.GraphicsDevice.Adapter.CurrentDisplayMode.Width && supportedDisplayMode2.Height == graphics.GraphicsDevice.Adapter.CurrentDisplayMode.Height)
			{
				width = graphics.GraphicsDevice.Adapter.CurrentDisplayMode.Width;
				height = graphics.GraphicsDevice.Adapter.CurrentDisplayMode.Height;
				return;
			}
		}
		bool flag = false;
		foreach (DisplayMode supportedDisplayMode3 in graphics.GraphicsDevice.Adapter.SupportedDisplayModes)
		{
			if (supportedDisplayMode3.Width >= 1280 && num > supportedDisplayMode3.Width)
			{
				width = supportedDisplayMode3.Width;
				height = supportedDisplayMode3.Height;
				flag = true;
			}
		}
		if (!flag)
		{
			log.Warn("Requested fullscreen resolution not valid, switching to windowed.");
			width = 1280;
			height = 720;
			options.fullscreen = false;
		}
	}

	public static void toggleNonBorderlessWindowedFullscreen()
	{
		int width = options.preferredResolutionX;
		int height = options.preferredResolutionY;
		graphics.HardwareModeSwitch = options.fullscreen && !options.windowedBorderlessFullscreen;
		if (options.fullscreen && !options.windowedBorderlessFullscreen)
		{
			CheckValidFullscreenResolution(ref width, ref height);
		}
		if (!options.fullscreen && !options.windowedBorderlessFullscreen)
		{
			width = 1280;
			height = 720;
		}
		graphics.PreferredBackBufferWidth = width;
		graphics.PreferredBackBufferHeight = height;
		if (options.fullscreen != graphics.IsFullScreen)
		{
			graphics.ToggleFullScreen();
		}
		graphics.ApplyChanges();
		updateViewportForScreenSizeChange(fullscreenChange: true, graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight);
		GameRunner.instance.OnWindowSizeChange(null, null);
	}

	public static void toggleFullscreen()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (options.windowedBorderlessFullscreen)
		{
			graphics.HardwareModeSwitch = false;
			graphics.IsFullScreen = true;
			graphics.ApplyChanges();
			graphics.PreferredBackBufferWidth = Program.gamePtr.Window.ClientBounds.Width;
			graphics.PreferredBackBufferHeight = Program.gamePtr.Window.ClientBounds.Height;
		}
		else
		{
			toggleNonBorderlessWindowedFullscreen();
		}
		GameRunner.instance.OnWindowSizeChange(null, null);
	}

	private void checkForEscapeKeys()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		KeyboardState keyboardState = input.GetKeyboardState();
		if (!base.IsMainInstance)
		{
			return;
		}
		if (((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)164) && ((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)13) && (((KeyboardState)(ref oldKBState)).IsKeyUp((Keys)164) || ((KeyboardState)(ref oldKBState)).IsKeyUp((Keys)13)))
		{
			if (options.isCurrentlyFullscreen() || options.isCurrentlyWindowedBorderless())
			{
				options.setWindowedOption(1);
			}
			else
			{
				options.setWindowedOption(0);
			}
		}
		if ((player.UsingTool || freezeControls) && ((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)161) && ((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)82) && ((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)46))
		{
			freezeControls = false;
			player.forceCanMove();
			player.completelyStopAnimatingOrDoingAction();
			player.UsingTool = false;
		}
	}

	public static bool IsPressEvent(ref KeyboardState state, Keys key)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		if (((KeyboardState)(ref state)).IsKeyDown(key) && !((KeyboardState)(ref oldKBState)).IsKeyDown(key))
		{
			oldKBState = state;
			return true;
		}
		return false;
	}

	public static bool IsPressEvent(ref GamePadState state, Buttons btn)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if (((GamePadState)(ref state)).IsConnected && ((GamePadState)(ref state)).IsButtonDown(btn) && !((GamePadState)(ref oldPadState)).IsButtonDown(btn))
		{
			oldPadState = state;
			return true;
		}
		return false;
	}

	public static bool isOneOfTheseKeysDown(KeyboardState state, InputButton[] keys)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < keys.Length; i++)
		{
			InputButton inputButton = keys[i];
			if ((int)inputButton.key != 0 && ((KeyboardState)(ref state)).IsKeyDown(inputButton.key))
			{
				return true;
			}
		}
		return false;
	}

	public static bool areAllOfTheseKeysUp(KeyboardState state, InputButton[] keys)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < keys.Length; i++)
		{
			InputButton inputButton = keys[i];
			if ((int)inputButton.key != 0 && !((KeyboardState)(ref state)).IsKeyUp(inputButton.key))
			{
				return false;
			}
		}
		return true;
	}

	internal void UpdateTitleScreen(GameTime time)
	{
		if (quit)
		{
			Exit();
			changeMusicTrack("none", track_interruptable: false, (MusicContext)0);
		}
		switch (gameMode)
		{
		case 6:
			UpdateTitleScreenDuringLoadingMode();
			return;
		case 7:
			currentLoader.MoveNext();
			return;
		case 8:
			pauseAccumulator -= time.ElapsedGameTime.Milliseconds;
			if (pauseAccumulator <= 0f)
			{
				pauseAccumulator = 0f;
				setGameMode(3);
				if (currentObjectDialogue.Count > 0)
				{
					messagePause = true;
					pauseTime = 1E+10f;
					fadeToBlackAlpha = 1f;
					player.CanMove = false;
				}
			}
			return;
		}
		if (game1.instanceIndex > 0)
		{
			if (activeClickableMenu == null && ticks > 1)
			{
				activeClickableMenu = new FarmhandMenu(multiplayer.InitClient(new LidgrenClient("localhost")));
				activeClickableMenu.populateClickableComponentList();
				if (options.SnappyMenus)
				{
					activeClickableMenu.snapToDefaultClickableComponent();
				}
			}
			return;
		}
		if (fadeToBlackAlpha < 1f && fadeIn)
		{
			fadeToBlackAlpha += 0.02f;
		}
		else if (fadeToBlackAlpha > 0f && fadeToBlack)
		{
			fadeToBlackAlpha -= 0.02f;
		}
		if (pauseTime > 0f)
		{
			pauseTime = Math.Max(0f, pauseTime - (float)time.ElapsedGameTime.Milliseconds);
		}
		if (fadeToBlackAlpha >= 1f)
		{
			switch (gameMode)
			{
			case 4:
				if (!fadeToBlack)
				{
					fadeIn = false;
					fadeToBlack = true;
					fadeToBlackAlpha = 2.5f;
				}
				break;
			case 0:
				if (currentSong == null && pauseTime <= 0f && base.IsMainInstance)
				{
					playSound("spring_day_ambient", out var cue);
					currentSong = cue;
				}
				if (activeClickableMenu == null && !quit)
				{
					activeClickableMenu = new TitleMenu();
				}
				break;
			}
			return;
		}
		if (!(fadeToBlackAlpha <= 0f))
		{
			return;
		}
		switch (gameMode)
		{
		case 4:
			if (fadeToBlack)
			{
				fadeIn = true;
				fadeToBlack = false;
				setGameMode(0);
				pauseTime = 2000f;
			}
			break;
		case 0:
			if (fadeToBlack)
			{
				currentLoader = Utility.generateNewFarm(IsClient);
				setGameMode(6);
				loadingMessage = (IsClient ? content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2574", client.serverName) : content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2575"));
				exitActiveMenu();
			}
			break;
		}
	}

	internal void UpdateTitleScreenDuringLoadingMode()
	{
		if (_requestedMusicTracks.Count > 0)
		{
			_requestedMusicTracks = new Dictionary<MusicContext, KeyValuePair<string, bool>>();
		}
		requestedMusicTrack = "none";
		requestedMusicTrackOverrideable = false;
		requestedMusicDirty = true;
		if (currentLoader != null && !currentLoader.MoveNext())
		{
			currentLoader = null;
			if (gameMode == 3)
			{
				setGameMode(3);
				fadeIn = true;
				fadeToBlackAlpha = 0.99f;
			}
			else
			{
				ExitToTitle();
			}
		}
	}

	public static bool IsThereABuildingUnderConstruction(string builder = "Robin")
	{
		if (netWorldState.Value.GetBuilderData(builder) != null)
		{
			return true;
		}
		return false;
	}

	public static Building GetBuildingUnderConstruction(string builder = "Robin")
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		BuilderData builderData = netWorldState.Value.GetBuilderData(builder);
		if (builderData == null)
		{
			return null;
		}
		GameLocation locationFromName = getLocationFromName(builderData.buildingLocation.Value);
		if (locationFromName == null)
		{
			return null;
		}
		if (client != null && !multiplayer.isActiveLocation(locationFromName))
		{
			return null;
		}
		return locationFromName.getBuildingAt(Utility.PointToVector2(builderData.buildingTile.Value));
	}

	public static bool IsBuildingConstructed(string name)
	{
		return GetNumberBuildingsConstructed(name) > 0;
	}

	public static int GetNumberBuildingsConstructed(bool includeUnderConstruction = false)
	{
		int num = 0;
		foreach (string locationsWithBuilding in netWorldState.Value.LocationsWithBuildings)
		{
			num += getLocationFromName(locationsWithBuilding)?.getNumberBuildingsConstructed(includeUnderConstruction) ?? 0;
		}
		return num;
	}

	public static int GetNumberBuildingsConstructed(string name, bool includeUnderConstruction = false)
	{
		int num = 0;
		foreach (string locationsWithBuilding in netWorldState.Value.LocationsWithBuildings)
		{
			num += getLocationFromName(locationsWithBuilding)?.getNumberBuildingsConstructed(name, includeUnderConstruction) ?? 0;
		}
		return num;
	}

	private void UpdateLocations(GameTime time)
	{
		loopingLocationCues.Update(currentLocation);
		if (IsClient)
		{
			currentLocation.UpdateWhenCurrentLocation(time);
			{
				foreach (GameLocation item in multiplayer.activeLocations())
				{
					item.updateEvenIfFarmerIsntHere(time);
				}
				return;
			}
		}
		Utility.ForEachLocation(delegate(GameLocation location)
		{
			_UpdateLocation(location, time);
			return true;
		});
		if (currentLocation.IsTemporary)
		{
			_UpdateLocation(currentLocation, time);
		}
		MineShaft.UpdateMines(time);
		VolcanoDungeon.UpdateLevels(time);
	}

	protected void _UpdateLocation(GameLocation location, GameTime time)
	{
		bool flag = location.farmers.Any();
		if (!flag && location.CanBeRemotedlyViewed())
		{
			if (player.currentLocation == location)
			{
				flag = true;
			}
			else
			{
				foreach (Farmer value in otherFarmers.Values)
				{
					if (value.viewingLocation.Value != null && value.viewingLocation.Value.Equals(location.NameOrUniqueName))
					{
						flag = true;
						break;
					}
				}
			}
		}
		if (flag)
		{
			location.UpdateWhenCurrentLocation(time);
		}
		location.updateEvenIfFarmerIsntHere(time);
		if (location.wasInhabited != flag)
		{
			location.wasInhabited = flag;
			if (IsMasterGame)
			{
				location.cleanupForVacancy();
			}
		}
	}

	public static void performTenMinuteClockUpdate()
	{
		hooks.OnGame1_PerformTenMinuteClockUpdate(delegate
		{
			//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
			int num = getTrulyDarkTime(currentLocation) - 100;
			gameTimeInterval = 0;
			if (IsMasterGame)
			{
				timeOfDay += 10;
			}
			if (timeOfDay % 100 >= 60)
			{
				timeOfDay = timeOfDay - timeOfDay % 100 + 100;
			}
			timeOfDay = Math.Min(timeOfDay, 2600);
			if (isLightning && timeOfDay < 2400 && IsMasterGame)
			{
				Utility.performLightningUpdate(timeOfDay);
			}
			if (timeOfDay == num)
			{
				currentLocation.switchOutNightTiles();
			}
			else if (timeOfDay == getModeratelyDarkTime(currentLocation) && currentLocation.IsOutdoors && !currentLocation.IsRainingHere())
			{
				ambientLight = Color.White;
			}
			if (!eventUp && isDarkOut(currentLocation) && IsPlayingBackgroundMusic)
			{
				changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
			}
			if (weatherIcon == 1)
			{
				Dictionary<string, string> dictionary = temporaryContent.Load<Dictionary<string, string>>("Data\\Festivals\\" + currentSeason + dayOfMonth);
				string[] array = dictionary["conditions"].Split('/');
				int num2 = Convert.ToInt32(ArgUtility.SplitBySpaceAndGet(array[1], 0));
				if (whereIsTodaysFest == null)
				{
					whereIsTodaysFest = array[0];
				}
				if (timeOfDay == num2)
				{
					if (dictionary.TryGetValue("startedMessage", out var value))
					{
						showGlobalMessage(TokenParser.ParseText(value));
					}
					else
					{
						if (!dictionary.TryGetValue("locationDisplayName", out var value2))
						{
							value2 = array[0];
							value2 = value2 switch
							{
								"Forest" => IsWinter ? content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2634") : content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2635"), 
								"Town" => content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2637"), 
								"Beach" => content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2639"), 
								_ => TokenParser.ParseText(GameLocation.GetData(value2)?.DisplayName) ?? value2, 
							};
						}
						showGlobalMessage(content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2640", dictionary["name"]) + value2);
					}
				}
			}
			player.performTenMinuteUpdate();
			switch (timeOfDay)
			{
			case 1200:
				if (currentLocation.isOutdoors.Value && !currentLocation.IsRainingHere() && (IsPlayingOutdoorsAmbience || currentSong == null || isMusicContextActiveButNotPlaying((MusicContext)0)))
				{
					playMorningSong();
				}
				break;
			case 2000:
				if (IsPlayingTownMusic)
				{
					changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
				}
				break;
			case 2400:
				dayTimeMoneyBox.timeShakeTimer = 2000;
				player.doEmote(24);
				showGlobalMessage(content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2652"));
				break;
			case 2500:
				dayTimeMoneyBox.timeShakeTimer = 2000;
				player.doEmote(24);
				break;
			case 2600:
				dayTimeMoneyBox.timeShakeTimer = 2000;
				player.mount?.dismount();
				if (player.IsSitting())
				{
					player.StopSitting(animate: false);
				}
				if (player.UsingTool && (!(player.CurrentTool is FishingRod fishingRod) || (!fishingRod.isReeling && !fishingRod.pullingOutOfWater)))
				{
					if (player.UsingTool && player.CurrentTool != null && player.CurrentTool is FishingRod { fishCaught: not false } fishingRod2)
					{
						fishingRod2.doneHoldingFish(player, endOfNight: true);
					}
					else
					{
						player.completelyStopAnimatingOrDoingAction();
					}
				}
				break;
			case 2800:
				if (activeClickableMenu != null)
				{
					activeClickableMenu.emergencyShutDown();
					exitActiveMenu();
				}
				player.startToPassOut();
				player.mount?.dismount();
				break;
			}
			foreach (string activePassiveFestival in netWorldState.Value.ActivePassiveFestivals)
			{
				if (Utility.TryGetPassiveFestivalData(activePassiveFestival, out var data) && timeOfDay == data.StartTime && (!data.OnlyShowMessageOnFirstDay || Utility.GetDayOfPassiveFestival(activePassiveFestival) == 1))
				{
					showGlobalMessage(TokenParser.ParseText(data.StartMessage));
				}
			}
			foreach (GameLocation location in locations)
			{
				GameLocation current2 = location;
				if (current2.NameOrUniqueName == currentLocation.NameOrUniqueName)
				{
					current2 = currentLocation;
				}
				current2.performTenMinuteUpdate(timeOfDay);
				current2.timeUpdate(10);
			}
			MineShaft.UpdateMines10Minutes(timeOfDay);
			VolcanoDungeon.UpdateLevels10Minutes(timeOfDay);
			if (IsMasterGame && farmEvent == null)
			{
				netWorldState.Value.UpdateFromGame1();
			}
			currentLightSources.RemoveWhere((KeyValuePair<string, LightSource> p) => p.Value.color.A <= 0);
		});
	}

	public static bool shouldPlayMorningSong(bool loading_game = false)
	{
		if (eventUp)
		{
			return false;
		}
		if ((double)options.musicVolumeLevel <= 0.025)
		{
			return false;
		}
		if (timeOfDay >= 1200)
		{
			return false;
		}
		if (!loading_game)
		{
			if (currentSong != null)
			{
				return IsPlayingOutdoorsAmbience;
			}
			return false;
		}
		return true;
	}

	public static void UpdateGameClock(GameTime time)
	{
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		if (shouldTimePass() && !IsClient)
		{
			gameTimeInterval += time.ElapsedGameTime.Milliseconds;
		}
		if (timeOfDay >= getTrulyDarkTime(currentLocation))
		{
			int num = (int)((float)(timeOfDay - timeOfDay % 100) + (float)(timeOfDay % 100 / 10) * 16.66f);
			float num2 = Math.Min(0.93f, 0.75f + ((float)(num - getTrulyDarkTime(currentLocation)) + (float)gameTimeInterval / (float)realMilliSecondsPerGameTenMinutes * 16.6f) * 0.000625f);
			outdoorLight = (IsRainingHere() ? ambientLight : eveningColor) * num2;
		}
		else if (timeOfDay >= getStartingToGetDarkTime(currentLocation))
		{
			int num3 = (int)((float)(timeOfDay - timeOfDay % 100) + (float)(timeOfDay % 100 / 10) * 16.66f);
			float num4 = Math.Min(0.93f, 0.3f + ((float)(num3 - getStartingToGetDarkTime(currentLocation)) + (float)gameTimeInterval / (float)realMilliSecondsPerGameTenMinutes * 16.6f) * 0.00225f);
			outdoorLight = (IsRainingHere() ? ambientLight : eveningColor) * num4;
		}
		else if (IsRainingHere())
		{
			outdoorLight = ambientLight * 0.3f;
		}
		else
		{
			outdoorLight = ambientLight;
		}
		int num5 = gameTimeInterval;
		int num6 = realMilliSecondsPerGameTenMinutes;
		GameLocation gameLocation = currentLocation;
		if (num5 > num6 + ((gameLocation != null) ? new int?(gameLocation.ExtraMillisecondsPerInGameMinute * 10) : ((int?)null)))
		{
			if (panMode)
			{
				gameTimeInterval = 0;
			}
			else
			{
				performTenMinuteClockUpdate();
			}
		}
	}

	public static Event getAvailableWeddingEvent()
	{
		if (weddingsToday.Count > 0)
		{
			long id = weddingsToday[0];
			weddingsToday.RemoveAt(0);
			Farmer farmer = GetPlayer(id);
			if (farmer == null)
			{
				return null;
			}
			if (farmer.hasRoommate())
			{
				return null;
			}
			if (farmer.spouse != null)
			{
				return Utility.getWeddingEvent(farmer);
			}
			long? spouse = farmer.team.GetSpouse(farmer.UniqueMultiplayerID);
			Farmer farmer2 = GetPlayer(spouse.Value);
			if (farmer2 == null)
			{
				return null;
			}
			if (!getOnlineFarmers().Contains(farmer) || !getOnlineFarmers().Contains(farmer2))
			{
				return null;
			}
			player.team.GetFriendship(farmer.UniqueMultiplayerID, spouse.Value).Status = FriendshipStatus.Married;
			player.team.GetFriendship(farmer.UniqueMultiplayerID, spouse.Value).WeddingDate = new WorldDate(Date);
			return Utility.getWeddingEvent(farmer);
		}
		return null;
	}

	public static void exitActiveMenu()
	{
		activeClickableMenu = null;
	}

	public static void PerformActionWhenPlayerFree(Action action)
	{
		if (player.IsBusyDoingSomething())
		{
			actionsWhenPlayerFree.Add(action);
		}
		else
		{
			action();
		}
	}

	public static void fadeScreenToBlack()
	{
		screenFade.FadeScreenToBlack();
	}

	public static void fadeClear()
	{
		screenFade.FadeClear();
	}

	private bool onFadeToBlackComplete()
	{
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		bool result = false;
		if (killScreen)
		{
			viewportFreeze = true;
			((Rectangle)(ref viewport)).X = -10000;
		}
		if (exitToTitle)
		{
			setGameMode(4);
			fadeIn = false;
			fadeToBlack = true;
			fadeToBlackAlpha = 0.01f;
			exitToTitle = false;
			changeMusicTrack("none", track_interruptable: false, (MusicContext)0);
			debrisWeather.Clear();
			return true;
		}
		if (timeOfDayAfterFade != -1)
		{
			timeOfDay = timeOfDayAfterFade;
			timeOfDayAfterFade = -1;
		}
		if (!nonWarpFade && locationRequest != null)
		{
			if (IsMasterGame && locationRequest.Location == null)
			{
				log.Error("Warp to " + locationRequest.Name + " failed: location wasn't found or couldn't be loaded.");
				locationRequest = null;
			}
			if (locationRequest != null)
			{
				GameLocation location = currentLocation;
				emoteMenu?.exitThisMenuNoSound();
				if (client != null)
				{
					currentLocation?.StoreCachedMultiplayerMap(multiplayer.cachedMultiplayerMaps);
				}
				currentLocation.cleanupBeforePlayerExit();
				multiplayer.broadcastLocationDelta(currentLocation);
				bool flag = false;
				displayFarmer = true;
				if (eventOver)
				{
					eventFinished();
					if (dayOfMonth == 0)
					{
						newDayAfterFade(delegate
						{
							//IL_000f: Unknown result type (might be due to invalid IL or missing references)
							player.Position = new Vector2(320f, 320f);
						});
					}
					return true;
				}
				if (locationRequest.IsRequestFor(currentLocation) && player.previousLocationName != "" && !eventUp && !MineShaft.IsGeneratedLevel(currentLocation))
				{
					player.Position = new Vector2((float)(xLocationAfterWarp * 64), (float)(yLocationAfterWarp * 64 - (player.Sprite.getHeight() - 32) + 16));
					viewportFreeze = false;
					currentLocation.resetForPlayerEntry();
					flag = true;
				}
				else
				{
					if (MineShaft.IsGeneratedLevel(locationRequest.Name))
					{
						MineShaft mineShaft = locationRequest.Location as MineShaft;
						if (player.IsSitting())
						{
							player.StopSitting(animate: false);
						}
						player.Halt();
						player.forceCanMove();
						if (!IsClient || locationRequest.Location?.Root != null)
						{
							currentLocation = mineShaft;
							mineShaft.resetForPlayerEntry();
							flag = true;
						}
						currentLocation.Map.LoadTileSheets(mapDisplayDevice);
						checkForRunButton(GetKeyboardState());
					}
					if (!eventUp)
					{
						player.Position = new Vector2((float)(xLocationAfterWarp * 64), (float)(yLocationAfterWarp * 64 - (player.Sprite.getHeight() - 32) + 16));
					}
					if (!MineShaft.IsGeneratedLevel(locationRequest.Name) && locationRequest.Location != null)
					{
						currentLocation = locationRequest.Location;
						if (!IsClient)
						{
							locationRequest.Loaded(locationRequest.Location);
							currentLocation.resetForPlayerEntry();
							flag = true;
						}
						currentLocation.Map.LoadTileSheets(mapDisplayDevice);
						if (!viewportFreeze && currentLocation.Map.DisplayWidth <= ((Rectangle)(ref viewport)).Width)
						{
							((Rectangle)(ref viewport)).X = (currentLocation.Map.DisplayWidth - ((Rectangle)(ref viewport)).Width) / 2;
						}
						if (!viewportFreeze && currentLocation.Map.DisplayHeight <= ((Rectangle)(ref viewport)).Height)
						{
							((Rectangle)(ref viewport)).Y = (currentLocation.Map.DisplayHeight - ((Rectangle)(ref viewport)).Height) / 2;
						}
						checkForRunButton(GetKeyboardState(), ignoreKeyPressQualifier: true);
					}
					if (!eventUp)
					{
						viewportFreeze = false;
					}
				}
				forceSnapOnNextViewportUpdate = true;
				player.FarmerSprite.PauseForSingleAnimation = false;
				player.faceDirection(facingDirectionAfterWarp);
				_isWarping = false;
				if (player.ActiveObject != null)
				{
					player.showCarrying();
				}
				else
				{
					player.showNotCarrying();
				}
				if (IsClient)
				{
					if (locationRequest.Location != null && locationRequest.Location.Root != null && multiplayer.isActiveLocation(locationRequest.Location))
					{
						if (HasDedicatedHost)
						{
							notifyServerOfWarp(needsLocationInfo: false);
						}
						currentLocation = locationRequest.Location;
						locationRequest.Loaded(locationRequest.Location);
						if (!flag)
						{
							currentLocation.resetForPlayerEntry();
						}
						player.currentLocation = currentLocation;
						locationRequest.Warped(currentLocation);
						currentLocation.updateSeasonalTileSheets();
						if (IsDebrisWeatherHere())
						{
							populateDebrisWeatherArray();
						}
						warpingForForcedRemoteEvent = false;
						locationRequest = null;
					}
					else
					{
						requestLocationInfoFromServer();
						if (currentLocation == null)
						{
							return true;
						}
					}
				}
				else
				{
					player.currentLocation = locationRequest.Location;
					locationRequest.Warped(locationRequest.Location);
					locationRequest = null;
				}
				if (locationRequest == null && currentLocation.Name == "Farm" && !eventUp)
				{
					if (player.position.X / 64f >= (float)(currentLocation.map.Layers[0].LayerWidth - 1))
					{
						player.position.X -= 64f;
					}
					else if (player.position.Y / 64f >= (float)(currentLocation.map.Layers[0].LayerHeight - 1))
					{
						player.position.Y -= 32f;
					}
					if (player.position.Y / 64f >= (float)(currentLocation.map.Layers[0].LayerHeight - 2))
					{
						player.position.X -= 48f;
					}
				}
				if (MineShaft.IsGeneratedLevel(location) && currentLocation != null && !MineShaft.IsGeneratedLevel(currentLocation))
				{
					MineShaft.OnLeftMines();
				}
				player.OnWarp();
				result = true;
			}
		}
		if (newDay)
		{
			newDayAfterFade(AfterNewDay);
			return true;
		}
		if (eventOver)
		{
			eventFinished();
			if (dayOfMonth == 0)
			{
				newDayAfterFade(AfterEventOver);
			}
			return true;
		}
		if (currentSong?.Name == "rain" && currentLocation.IsRainingHere())
		{
			if (currentLocation.IsOutdoors)
			{
				currentSong.SetVariable("Frequency", 100f);
			}
			else if (!MineShaft.IsGeneratedLevel(currentLocation.Name))
			{
				currentSong.SetVariable("Frequency", 15f);
			}
		}
		return result;
		static void AfterEventOver()
		{
			currentLocation.resetForPlayerEntry();
			nonWarpFade = false;
			fadeIn = false;
		}
		static void AfterNewDay()
		{
			if (eventOver)
			{
				eventFinished();
				if (dayOfMonth == 0)
				{
					newDayAfterFade(delegate
					{
						//IL_000f: Unknown result type (might be due to invalid IL or missing references)
						player.Position = new Vector2(320f, 320f);
					});
				}
			}
			nonWarpFade = false;
			fadeIn = false;
		}
	}

	public static void OnLocationChanged(GameLocation oldLocation, GameLocation newLocation)
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		if (!hasLoadedGame)
		{
			return;
		}
		eventsSeenSinceLastLocationChange.Clear();
		if (newLocation.Name != null && !MineShaft.IsGeneratedLevel(newLocation) && !VolcanoDungeon.IsGeneratedLevel(newLocation.Name))
		{
			player.locationsVisited.Add(newLocation.Name);
		}
		if (newLocation.IsOutdoors && !newLocation.ignoreDebrisWeather.Value && newLocation.IsDebrisWeatherHere() && (Season?)GetSeasonForLocation(newLocation) != debrisWeatherSeason)
		{
			windGust = 0f;
			WeatherDebris.globalWind = 0f;
			populateDebrisWeatherArray();
			if (wind != null)
			{
				wind.Stop((AudioStopOptions)0);
				wind = null;
			}
		}
		GameLocation.HandleMusicChange(oldLocation, newLocation);
		TriggerActionManager.Raise("LocationChanged");
	}

	private static void onFadedBackInComplete()
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (killScreen)
		{
			pauseThenMessage(1500, "..." + player.Name + "?");
		}
		else if (!eventUp)
		{
			player.CanMove = true;
		}
		checkForRunButton(oldKBState, ignoreKeyPressQualifier: true);
	}

	public static void UpdateOther(GameTime time)
	{
		//IL_04a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0494: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0561: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		//IL_0431: Unknown result type (might be due to invalid IL or missing references)
		//IL_0436: Unknown result type (might be due to invalid IL or missing references)
		//IL_0446: Unknown result type (might be due to invalid IL or missing references)
		//IL_044b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fb: Unknown result type (might be due to invalid IL or missing references)
		if (currentLocation == null || (!player.passedOut && screenFade.UpdateFade(time)))
		{
			return;
		}
		if (dialogueUp)
		{
			player.CanMove = false;
		}
		for (int num = delayedActions.Count - 1; num >= 0; num--)
		{
			DelayedAction delayedAction = delayedActions[num];
			if (delayedAction.update(time) && delayedActions.Contains(delayedAction))
			{
				delayedActions.Remove(delayedAction);
			}
		}
		if (timeOfDay >= 2600 || player.stamina <= -15f)
		{
			if (currentMinigame != null && currentMinigame.forceQuit())
			{
				currentMinigame = null;
			}
			if (currentMinigame == null && player.canMove && player.freezePause <= 0 && !player.UsingTool && !eventUp && (IsMasterGame || player.isCustomized.Value) && locationRequest == null && activeClickableMenu == null)
			{
				player.startToPassOut();
				player.freezePause = 7000;
			}
		}
		screenOverlayTempSprites.RemoveWhere((TemporaryAnimatedSprite sprite) => sprite.update(time));
		uiOverlayTempSprites.RemoveWhere((TemporaryAnimatedSprite sprite) => sprite.update(time));
		if ((player.CanMove || player.UsingTool) && shouldTimePass())
		{
			buffsDisplay.update(time);
		}
		player.CurrentItem?.actionWhenBeingHeld(player);
		float num2 = dialogueButtonScale;
		dialogueButtonScale = (float)(16.0 * Math.Sin(time.TotalGameTime.TotalMilliseconds % 1570.0 / 500.0));
		if (num2 > dialogueButtonScale && !dialogueButtonShrinking)
		{
			dialogueButtonShrinking = true;
		}
		else if (num2 < dialogueButtonScale && dialogueButtonShrinking)
		{
			dialogueButtonShrinking = false;
		}
		if (screenGlow)
		{
			if (screenGlowUp || screenGlowHold)
			{
				if (screenGlowHold)
				{
					screenGlowAlpha = Math.Min(screenGlowAlpha + screenGlowRate, screenGlowMax);
				}
				else
				{
					screenGlowAlpha = Math.Min(screenGlowAlpha + 0.03f, 0.6f);
					if (screenGlowAlpha >= 0.6f)
					{
						screenGlowUp = false;
					}
				}
			}
			else
			{
				screenGlowAlpha -= 0.01f;
				if (screenGlowAlpha <= 0f)
				{
					screenGlow = false;
				}
			}
		}
		hudMessages.RemoveAll((HUDMessage hudMessage) => hudMessage.update(time));
		updateWeather(time);
		if (!fadeToBlack)
		{
			currentLocation.checkForMusic(time);
		}
		if (debrisSoundInterval > 0f)
		{
			debrisSoundInterval -= time.ElapsedGameTime.Milliseconds;
		}
		noteBlockTimer += time.ElapsedGameTime.Milliseconds;
		if (noteBlockTimer > 1000f)
		{
			noteBlockTimer = 0f;
			if (player.health < 20 && CurrentEvent == null)
			{
				hitShakeTimer = 250;
				if (player.health <= 10)
				{
					hitShakeTimer = 500;
					if (showingHealthBar && fadeToBlackAlpha <= 0f)
					{
						for (int num3 = 0; num3 < 3; num3++)
						{
							uiOverlayTempSprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(366, 412, 5, 6), new Vector2((float)(random.Next(32) + ((Rectangle)(ref uiViewport)).Width - 112), (float)(((Rectangle)(ref uiViewport)).Height - 224 - (player.maxHealth - 100) - 16 + 4)), flipped: false, 0.017f, Color.Red)
							{
								motion = new Vector2(-1.5f, (float)(-8 + random.Next(-1, 2))),
								acceleration = new Vector2(0f, 0.5f),
								local = true,
								scale = 4f,
								delayBeforeAnimationStart = num3 * 150
							});
						}
					}
				}
			}
		}
		int num4;
		if (!currentLocation.IsOutdoors || ((Color)(ref outdoorLight)).Equals(Color.White))
		{
			if (((Color)(ref ambientLight)).Equals(Color.White))
			{
				if (currentLocation is MineShaft)
				{
					Color lightingColor = ((MineShaft)currentLocation).getLightingColor(time);
					num4 = ((!((Color)(ref lightingColor)).Equals(Color.White)) ? 1 : 0);
				}
				else
				{
					num4 = 0;
				}
			}
			else
			{
				num4 = 1;
			}
		}
		else
		{
			num4 = 1;
		}
		drawLighting = (byte)num4 != 0;
		if (player.hasBuff("26"))
		{
			drawLighting = true;
		}
		if (hitShakeTimer > 0)
		{
			hitShakeTimer -= time.ElapsedGameTime.Milliseconds;
		}
		if (staminaShakeTimer > 0)
		{
			staminaShakeTimer -= time.ElapsedGameTime.Milliseconds;
		}
		background?.update(viewport);
		cursorTileHintCheckTimer -= (int)time.ElapsedGameTime.TotalMilliseconds;
		currentCursorTile.X = (((Rectangle)(ref viewport)).X + getOldMouseX()) / 64;
		currentCursorTile.Y = (((Rectangle)(ref viewport)).Y + getOldMouseY()) / 64;
		if (cursorTileHintCheckTimer <= 0 || !((Vector2)(ref currentCursorTile)).Equals(lastCursorTile))
		{
			cursorTileHintCheckTimer = 250;
			updateCursorTileHint();
			if (player.CanMove)
			{
				checkForRunButton(oldKBState, ignoreKeyPressQualifier: true);
			}
		}
		if (!MineShaft.IsGeneratedLevel(currentLocation.Name))
		{
			MineShaft.timeSinceLastMusic = 200000;
		}
		if (activeClickableMenu == null && farmEvent == null && keyboardDispatcher != null && !IsChatting)
		{
			keyboardDispatcher.Subscriber = null;
		}
	}

	public static void updateWeather(GameTime time)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0357: Unknown result type (might be due to invalid IL or missing references)
		//IL_035d: Invalid comparison between Unknown and I4
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		if (currentLocation.IsOutdoors && currentLocation.IsSnowingHere())
		{
			Vector2 current = default(Vector2);
			((Vector2)(ref current))._002Ector((float)((Rectangle)(ref viewport)).X, (float)((Rectangle)(ref viewport)).Y);
			snowPos = updateFloatingObjectPositionForMovement(snowPos, current, previousViewportPosition, -1f);
			return;
		}
		if (currentLocation.IsOutdoors && currentLocation.IsRainingHere())
		{
			Point val = default(Point);
			for (int i = 0; i < rainDrops.Length; i++)
			{
				if (rainDrops[i].frame == 0)
				{
					rainDrops[i].accumulator += time.ElapsedGameTime.Milliseconds;
					if (rainDrops[i].accumulator < 70)
					{
						continue;
					}
					ref Vector2 position = ref rainDrops[i].position;
					position += new Vector2((float)(-16 + i * 8 / rainDrops.Length), (float)(32 - i * 8 / rainDrops.Length));
					rainDrops[i].accumulator = 0;
					if (random.NextDouble() < 0.1)
					{
						rainDrops[i].frame++;
					}
					if (currentLocation is IslandNorth || currentLocation is Caldera)
					{
						((Point)(ref val))._002Ector((int)(rainDrops[i].position.X + (float)((Rectangle)(ref viewport)).X) / 64, (int)(rainDrops[i].position.Y + (float)((Rectangle)(ref viewport)).Y) / 64);
						val.Y--;
						if (currentLocation.isTileOnMap(val.X, val.Y) && !currentLocation.hasTileAt(val, "Back") && !currentLocation.hasTileAt(val, "Buildings"))
						{
							rainDrops[i].frame = 0;
						}
					}
					if (rainDrops[i].position.Y > (float)(((Rectangle)(ref viewport)).Height + 64))
					{
						rainDrops[i].position.Y = -64f;
					}
					continue;
				}
				rainDrops[i].accumulator += time.ElapsedGameTime.Milliseconds;
				if (rainDrops[i].accumulator > 70)
				{
					rainDrops[i].frame = (rainDrops[i].frame + 1) % 4;
					rainDrops[i].accumulator = 0;
					if (rainDrops[i].frame == 0)
					{
						rainDrops[i].position = new Vector2((float)random.Next(((Rectangle)(ref viewport)).Width), (float)random.Next(((Rectangle)(ref viewport)).Height));
					}
				}
			}
			return;
		}
		if (currentLocation.IsOutdoors && !currentLocation.ignoreDebrisWeather.Value && currentLocation.IsDebrisWeatherHere())
		{
			if ((int)currentLocation.GetSeason() == 2)
			{
				if (WeatherDebris.globalWind == 0f)
				{
					WeatherDebris.globalWind = -0.5f;
				}
				if (random.NextDouble() < 0.001 && windGust == 0f && WeatherDebris.globalWind >= -0.5f)
				{
					windGust += (float)random.Next(-10, -1) / 100f;
					playSound("wind", out wind);
				}
				else if (windGust != 0f)
				{
					windGust = Math.Max(-5f, windGust * 1.02f);
					WeatherDebris.globalWind = -0.5f + windGust;
					if (windGust < -0.2f && random.NextDouble() < 0.007)
					{
						windGust = 0f;
					}
				}
				if (WeatherDebris.globalWind < -0.5f)
				{
					WeatherDebris.globalWind = Math.Min(-0.5f, WeatherDebris.globalWind + 0.015f);
					if (wind != null)
					{
						wind.SetVariable("Volume", (0f - WeatherDebris.globalWind) * 20f);
						wind.SetVariable("Frequency", (0f - WeatherDebris.globalWind) * 20f);
						if (WeatherDebris.globalWind == -0.5f)
						{
							wind.Stop((AudioStopOptions)0);
						}
					}
				}
			}
			else
			{
				if (WeatherDebris.globalWind == 0f)
				{
					WeatherDebris.globalWind = -0.25f;
				}
				if (wind != null)
				{
					wind.Stop((AudioStopOptions)0);
					wind = null;
				}
			}
			{
				foreach (WeatherDebris item in debrisWeather)
				{
					item.update();
				}
				return;
			}
		}
		if (wind != null)
		{
			wind.Stop((AudioStopOptions)0);
			wind = null;
		}
	}

	public static void updateCursorTileHint()
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		if (activeClickableMenu != null)
		{
			return;
		}
		mouseCursorTransparency = 1f;
		isActionAtCurrentCursorTile = false;
		isInspectionAtCurrentCursorTile = false;
		isSpeechAtCurrentCursorTile = false;
		int xTile = (((Rectangle)(ref viewport)).X + getOldMouseX()) / 64;
		int num = (((Rectangle)(ref viewport)).Y + getOldMouseY()) / 64;
		if (currentLocation != null)
		{
			isActionAtCurrentCursorTile = currentLocation.isActionableTile(xTile, num, player);
			if (!isActionAtCurrentCursorTile)
			{
				isActionAtCurrentCursorTile = currentLocation.isActionableTile(xTile, num + 1, player);
			}
		}
		lastCursorTile = currentCursorTile;
	}

	public static void updateMusic()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Expected I4, but got Unknown
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		if (game1.IsMainInstance)
		{
			Game1 game = null;
			string text = null;
			int num = 1;
			int num2 = 2;
			int num3 = 5;
			int num4 = 6;
			int num5 = 7;
			int num6 = 0;
			float num7 = GetDefaultSongPriority(getMusicTrackName((MusicContext)0), game1.instanceIsOverridingTrack, game1);
			MusicContext val = (MusicContext)0;
			foreach (Game1 gameInstance in GameRunner.instance.gameInstances)
			{
				MusicContext instanceActiveMusicContext = gameInstance._instanceActiveMusicContext;
				if (gameInstance.IsMainInstance)
				{
					val = instanceActiveMusicContext;
				}
				string text2 = null;
				string text3 = null;
				if (gameInstance._instanceRequestedMusicTracks.TryGetValue(instanceActiveMusicContext, out var value))
				{
					text2 = value.Key;
				}
				if (gameInstance.instanceIsOverridingTrack && gameInstance.instanceCurrentSong != null)
				{
					text3 = gameInstance.instanceCurrentSong.Name;
				}
				switch ((int)instanceActiveMusicContext)
				{
				case 3:
					if (num6 < num4 && text2 != null)
					{
						num6 = num4;
						game = gameInstance;
						text = text2;
					}
					break;
				case 4:
					if (num6 < num3 && text2 != null)
					{
						num6 = num3;
						game = gameInstance;
						text = text2;
					}
					break;
				case 1:
					if (num6 < num && text2 != null)
					{
						num6 = num;
						game = gameInstance;
						text = ((text3 == null) ? text2 : text3);
					}
					break;
				case 0:
					if (text2 == "mermaidSong")
					{
						num6 = num5;
						game = gameInstance;
						text = text2;
					}
					if (val <= instanceActiveMusicContext && text2 != null)
					{
						float num8 = GetDefaultSongPriority(text2, gameInstance.instanceIsOverridingTrack, gameInstance);
						if (num7 < num8)
						{
							num7 = num8;
							num6 = num2;
							game = gameInstance;
							text = ((text3 == null) ? text2 : text3);
						}
					}
					break;
				}
			}
			if (game == null || game == game1)
			{
				if (doesMusicContextHaveTrack((MusicContext)5))
				{
					stopMusicTrack((MusicContext)5);
				}
			}
			else if (text == null && doesMusicContextHaveTrack((MusicContext)5))
			{
				stopMusicTrack((MusicContext)5);
			}
			else if (text != null && getMusicTrackName((MusicContext)5) != text)
			{
				changeMusicTrack(text, track_interruptable: false, (MusicContext)5);
			}
		}
		string text4 = null;
		bool flag = false;
		bool flag2 = false;
		if (currentLocation != null && currentLocation.IsMiniJukeboxPlaying() && (!requestedMusicDirty || requestedMusicTrackOverrideable) && currentTrackOverrideable)
		{
			text4 = null;
			flag2 = true;
			string text5 = currentLocation.miniJukeboxTrack.Value;
			if (text5 == "random")
			{
				text5 = ((currentLocation.randomMiniJukeboxTrack.Value != null) ? currentLocation.randomMiniJukeboxTrack.Value : "");
			}
			if (currentSong == null || !currentSong.IsPlaying || currentSong.Name != text5)
			{
				if (!soundBank.Exists(text5))
				{
					log.Error($"Location {currentLocation.NameOrUniqueName} has invalid jukebox track '{text5}' selected, turning off jukebox.");
					player.currentLocation.miniJukeboxTrack.Value = "";
				}
				else
				{
					text4 = text5;
					requestedMusicDirty = false;
					flag = true;
				}
			}
		}
		if (isOverridingTrack != flag2)
		{
			isOverridingTrack = flag2;
			if (!isOverridingTrack)
			{
				requestedMusicDirty = true;
			}
		}
		if (requestedMusicDirty)
		{
			text4 = requestedMusicTrack;
			flag = requestedMusicTrackOverrideable;
		}
		if (!string.IsNullOrEmpty(text4))
		{
			musicPlayerVolume = Math.Max(0f, Math.Min(options.musicVolumeLevel, musicPlayerVolume - 0.01f));
			ambientPlayerVolume = Math.Max(0f, Math.Min(options.musicVolumeLevel, ambientPlayerVolume - 0.01f));
			if (game1.IsMainInstance)
			{
				musicCategory.SetVolume(musicPlayerVolume);
				ambientCategory.SetVolume(ambientPlayerVolume);
			}
			if (musicPlayerVolume != 0f || ambientPlayerVolume != 0f)
			{
				return;
			}
			if (text4 == "none" || text4 == "silence")
			{
				if (game1.IsMainInstance && currentSong != null)
				{
					currentSong.Stop((AudioStopOptions)1);
					currentSong.Dispose();
					currentSong = null;
				}
			}
			else if ((options.musicVolumeLevel != 0f || options.ambientVolumeLevel != 0f) && (text4 != "rain" || endOfNightMenus.Count == 0))
			{
				if (game1.IsMainInstance && currentSong != null)
				{
					currentSong.Stop((AudioStopOptions)1);
					currentSong.Dispose();
					currentSong = null;
				}
				currentSong = soundBank.GetCue(text4);
				if (game1.IsMainInstance)
				{
					currentSong.Play();
				}
				if (game1.IsMainInstance && currentSong != null && currentSong.Name == "rain" && currentLocation != null)
				{
					if (IsRainingHere())
					{
						if (currentLocation.IsOutdoors)
						{
							currentSong.SetVariable("Frequency", 100f);
						}
						else if (!MineShaft.IsGeneratedLevel(currentLocation))
						{
							currentSong.SetVariable("Frequency", 15f);
						}
					}
					else if (eventUp)
					{
						currentSong.SetVariable("Frequency", 100f);
					}
				}
			}
			else
			{
				currentSong?.Stop((AudioStopOptions)1);
			}
			currentTrackOverrideable = flag;
			requestedMusicDirty = false;
		}
		else if (MusicDuckTimer > 0f)
		{
			MusicDuckTimer -= (float)currentGameTime.ElapsedGameTime.TotalMilliseconds;
			musicPlayerVolume = Math.Max(musicPlayerVolume - options.musicVolumeLevel / 33f, options.musicVolumeLevel / 12f);
			if (game1.IsMainInstance)
			{
				musicCategory.SetVolume(musicPlayerVolume);
			}
		}
		else if (musicPlayerVolume < options.musicVolumeLevel || ambientPlayerVolume < options.ambientVolumeLevel)
		{
			if (musicPlayerVolume < options.musicVolumeLevel)
			{
				musicPlayerVolume = Math.Min(1f, musicPlayerVolume += 0.01f);
				if (game1.IsMainInstance)
				{
					musicCategory.SetVolume(musicPlayerVolume);
				}
			}
			if (ambientPlayerVolume < options.ambientVolumeLevel)
			{
				ambientPlayerVolume = Math.Min(1f, ambientPlayerVolume += 0.015f);
				if (game1.IsMainInstance)
				{
					ambientCategory.SetVolume(ambientPlayerVolume);
				}
			}
		}
		else if (currentSong != null && !currentSong.IsPlaying && !currentSong.IsStopped)
		{
			currentSong = soundBank.GetCue(currentSong.Name);
			if (game1.IsMainInstance)
			{
				currentSong.Play();
			}
		}
	}

	public static int GetDefaultSongPriority(string song_name, bool is_playing_override, Game1 instance)
	{
		if (is_playing_override)
		{
			return 9;
		}
		if (song_name == "none")
		{
			return 0;
		}
		if (instance._instanceIsPlayingOutdoorsAmbience || instance._instanceIsPlayingNightAmbience || song_name == "rain")
		{
			return 1;
		}
		if (instance._instanceIsPlayingMorningSong)
		{
			return 2;
		}
		if (instance._instanceIsPlayingTownMusic)
		{
			return 3;
		}
		if (song_name == "jungle_ambience")
		{
			return 7;
		}
		if (instance._instanceIsPlayingBackgroundMusic)
		{
			return 8;
		}
		if (instance.instanceGameLocation is MineShaft)
		{
			if (song_name.Contains("Ambient"))
			{
				return 7;
			}
			if (song_name.EndsWith("Mine"))
			{
				return 20;
			}
		}
		return 10;
	}

	public static void updateRainDropPositionForPlayerMovement(int direction, float speed)
	{
		if (currentLocation.IsRainingHere())
		{
			for (int i = 0; i < rainDrops.Length; i++)
			{
				switch (direction)
				{
				case 0:
					rainDrops[i].position.Y += speed;
					if (rainDrops[i].position.Y > (float)(((Rectangle)(ref viewport)).Height + 64))
					{
						rainDrops[i].position.Y = -64f;
					}
					break;
				case 1:
					rainDrops[i].position.X -= speed;
					if (rainDrops[i].position.X < -64f)
					{
						rainDrops[i].position.X = ((Rectangle)(ref viewport)).Width;
					}
					break;
				case 2:
					rainDrops[i].position.Y -= speed;
					if (rainDrops[i].position.Y < -64f)
					{
						rainDrops[i].position.Y = ((Rectangle)(ref viewport)).Height;
					}
					break;
				case 3:
					rainDrops[i].position.X += speed;
					if (rainDrops[i].position.X > (float)(((Rectangle)(ref viewport)).Width + 64))
					{
						rainDrops[i].position.X = -64f;
					}
					break;
				}
			}
		}
		else
		{
			updateDebrisWeatherForMovement(debrisWeather, direction, speed);
		}
	}

	public static void initializeVolumeLevels()
	{
		if (!LocalMultiplayer.IsLocalMultiplayer() || game1.IsMainInstance)
		{
			soundCategory.SetVolume(options.soundVolumeLevel);
			musicCategory.SetVolume(options.musicVolumeLevel);
			ambientCategory.SetVolume(options.ambientVolumeLevel);
			footstepCategory.SetVolume(options.footstepVolumeLevel);
		}
	}

	public static void updateDebrisWeatherForMovement(List<WeatherDebris> debris, int direction, float speed)
	{
		if (!(fadeToBlackAlpha <= 0f) || debris == null)
		{
			return;
		}
		foreach (WeatherDebris debri in debris)
		{
			switch (direction)
			{
			case 0:
				debri.position.Y += speed;
				if (debri.position.Y > (float)(((Rectangle)(ref viewport)).Height + 64))
				{
					debri.position.Y = -64f;
				}
				break;
			case 1:
				debri.position.X -= speed;
				if (debri.position.X < -64f)
				{
					debri.position.X = ((Rectangle)(ref viewport)).Width;
				}
				break;
			case 2:
				debri.position.Y -= speed;
				if (debri.position.Y < -64f)
				{
					debri.position.Y = ((Rectangle)(ref viewport)).Height;
				}
				break;
			case 3:
				debri.position.X += speed;
				if (debri.position.X > (float)(((Rectangle)(ref viewport)).Width + 64))
				{
					debri.position.X = -64f;
				}
				break;
			}
		}
	}

	public static Vector2 updateFloatingObjectPositionForMovement(Vector2 w, Vector2 current, Vector2 previous, float speed)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		if (current.Y < previous.Y)
		{
			w.Y -= Math.Abs(current.Y - previous.Y) * speed;
		}
		else if (current.Y > previous.Y)
		{
			w.Y += Math.Abs(current.Y - previous.Y) * speed;
		}
		if (current.X > previous.X)
		{
			w.X += Math.Abs(current.X - previous.X) * speed;
		}
		else if (current.X < previous.X)
		{
			w.X -= Math.Abs(current.X - previous.X) * speed;
		}
		return w;
	}

	public static void updateRaindropPosition()
	{
		if (HostPaused)
		{
			return;
		}
		if (IsRainingHere())
		{
			int num = ((Rectangle)(ref viewport)).X - (int)previousViewportPosition.X;
			int num2 = ((Rectangle)(ref viewport)).Y - (int)previousViewportPosition.Y;
			for (int i = 0; i < rainDrops.Length; i++)
			{
				rainDrops[i].position.X -= (float)num * 1f;
				rainDrops[i].position.Y -= (float)num2 * 1f;
				if (rainDrops[i].position.Y > (float)(((Rectangle)(ref viewport)).Height + 64))
				{
					rainDrops[i].position.Y = -64f;
				}
				else if (rainDrops[i].position.X < -64f)
				{
					rainDrops[i].position.X = ((Rectangle)(ref viewport)).Width;
				}
				else if (rainDrops[i].position.Y < -64f)
				{
					rainDrops[i].position.Y = ((Rectangle)(ref viewport)).Height;
				}
				else if (rainDrops[i].position.X > (float)(((Rectangle)(ref viewport)).Width + 64))
				{
					rainDrops[i].position.X = -64f;
				}
			}
		}
		else
		{
			updateDebrisWeatherForMovement(debrisWeather);
		}
	}

	public static void updateDebrisWeatherForMovement(List<WeatherDebris> debris)
	{
		if (HostPaused || debris == null || !(fadeToBlackAlpha < 1f))
		{
			return;
		}
		int num = ((Rectangle)(ref viewport)).X - (int)previousViewportPosition.X;
		int num2 = ((Rectangle)(ref viewport)).Y - (int)previousViewportPosition.Y;
		if (Math.Abs(num) > 100 || Math.Abs(num2) > 80)
		{
			return;
		}
		int num3 = 16;
		foreach (WeatherDebris debri in debris)
		{
			debri.position.X -= (float)num * 1f;
			debri.position.Y -= (float)num2 * 1f;
			if (debri.position.Y > (float)(((Rectangle)(ref viewport)).Height + 64 + num3))
			{
				debri.position.Y = -64f;
			}
			else if (debri.position.X < (float)(-64 - num3))
			{
				debri.position.X = ((Rectangle)(ref viewport)).Width;
			}
			else if (debri.position.Y < (float)(-64 - num3))
			{
				debri.position.Y = ((Rectangle)(ref viewport)).Height;
			}
			else if (debri.position.X > (float)(((Rectangle)(ref viewport)).Width + 64 + num3))
			{
				debri.position.X = -64f;
			}
		}
	}

	public static void randomizeRainPositions()
	{
		for (int i = 0; i < 70; i++)
		{
			rainDrops[i] = new RainDrop(random.Next(((Rectangle)(ref viewport)).Width), random.Next(((Rectangle)(ref viewport)).Height), random.Next(4), random.Next(70));
		}
	}

	public static void randomizeDebrisWeatherPositions(List<WeatherDebris> debris)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if (debris == null)
		{
			return;
		}
		foreach (WeatherDebris debri in debris)
		{
			debri.position = Utility.getRandomPositionOnScreen();
		}
	}

	public static void eventFinished()
	{
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		player.canOnlyWalk = false;
		if (player.bathingClothes.Value)
		{
			player.canOnlyWalk = true;
		}
		eventOver = false;
		eventUp = false;
		player.CanMove = true;
		displayHUD = true;
		player.faceDirection(player.orientationBeforeEvent);
		player.completelyStopAnimatingOrDoingAction();
		viewportFreeze = false;
		Action action = null;
		if (currentLocation.currentEvent?.onEventFinished != null)
		{
			action = currentLocation.currentEvent.onEventFinished;
			currentLocation.currentEvent.onEventFinished = null;
		}
		LocationRequest locationRequest = null;
		if (currentLocation.currentEvent != null)
		{
			locationRequest = currentLocation.currentEvent.exitLocation;
			currentLocation.currentEvent.cleanup();
			currentLocation.currentEvent = null;
		}
		if (player.ActiveObject != null)
		{
			player.showCarrying();
		}
		if (dayOfMonth != 0)
		{
			currentLightSources.Clear();
		}
		if (locationRequest == null && currentLocation != null && Game1.locationRequest == null)
		{
			locationRequest = new LocationRequest(currentLocation.NameOrUniqueName, currentLocation.isStructure.Value, currentLocation);
		}
		if (locationRequest != null)
		{
			if (locationRequest.Location is Farm && player.positionBeforeEvent.Y == 64f)
			{
				player.positionBeforeEvent.X += 1f;
			}
			locationRequest.OnWarp += delegate
			{
				player.locationBeforeForcedEvent.Value = null;
			};
			if (locationRequest.Location == currentLocation)
			{
				GameLocation.HandleMusicChange(currentLocation, currentLocation);
			}
			warpFarmer(locationRequest, (int)player.positionBeforeEvent.X, (int)player.positionBeforeEvent.Y, player.orientationBeforeEvent);
		}
		else
		{
			GameLocation.HandleMusicChange(currentLocation, currentLocation);
			player.setTileLocation(player.positionBeforeEvent);
			player.locationBeforeForcedEvent.Value = null;
		}
		nonWarpFade = false;
		fadeToBlackAlpha = 1f;
		action?.Invoke();
	}

	public static void populateDebrisWeatherArray()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Expected I4, but got Unknown
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		Season seasonForLocation = GetSeasonForLocation(currentLocation);
		int num = random.Next(16, 64);
		int which = (seasonForLocation - 1) switch
		{
			1 => 2, 
			2 => 3, 
			0 => 1, 
			_ => 0, 
		};
		isDebrisWeather = true;
		debrisWeatherSeason = seasonForLocation;
		debrisWeather.Clear();
		for (int i = 0; i < num; i++)
		{
			debrisWeather.Add(new WeatherDebris(new Vector2((float)random.Next(0, ((Rectangle)(ref viewport)).Width), (float)random.Next(0, ((Rectangle)(ref viewport)).Height)), which, (float)random.Next(15) / 500f, (float)random.Next(-10, 0) / 50f, (float)random.Next(10) / 50f));
		}
	}

	private static void OnNewSeason()
	{
		setGraphicsForSeason();
		Utility.ForEachLocation(delegate(GameLocation location)
		{
			location.seasonUpdate();
			return true;
		});
	}

	public static void prepareSpouseForWedding(Farmer farmer)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		NPC nPC = RequireCharacter(farmer.spouse);
		nPC.ClearSchedule();
		nPC.DefaultMap = farmer.homeLocation.Value;
		nPC.DefaultPosition = Utility.PointToVector2(RequireLocation<FarmHouse>(farmer.homeLocation.Value).getSpouseBedSpot(farmer.spouse)) * 64f;
		nPC.DefaultFacingDirection = 2;
	}

	public static bool AddCharacterIfNecessary(string characterId, bool bypassConditions = false)
	{
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Invalid comparison between Unknown and I4
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		if (!NPC.TryGetData(characterId, out var data))
		{
			return false;
		}
		bool result = false;
		if (getCharacterFromName(characterId) == null)
		{
			if (!bypassConditions && !GameStateQuery.CheckConditions(data.UnlockConditions))
			{
				return false;
			}
			NPC.ReadNpcHomeData(data, null, out var locationName, out var tile, out var direction);
			bool canBeRomanced = data.CanBeRomanced;
			Point size = data.Size;
			GameLocation locationFromNameInLocationsList = getLocationFromNameInLocationsList(locationName);
			if (locationFromNameInLocationsList == null)
			{
				return false;
			}
			string textureNameForCharacter = NPC.getTextureNameForCharacter(characterId);
			NPC nPC;
			try
			{
				nPC = new NPC(new AnimatedSprite("Characters\\" + textureNameForCharacter, 0, size.X, size.Y), new Vector2((float)(tile.X * 64), (float)(tile.Y * 64)), locationName, direction, characterId, canBeRomanced, content.Load<Texture2D>("Portraits\\" + textureNameForCharacter));
			}
			catch (Exception exception)
			{
				log.Error("Failed to spawn NPC '" + characterId + "'.", exception);
				return false;
			}
			nPC.Breather = data.Breather;
			locationFromNameInLocationsList.addCharacter(nPC);
			result = true;
		}
		if ((int)data.SocialTab == 1 && !player.friendshipData.ContainsKey(characterId))
		{
			player.friendshipData.Add(characterId, new Friendship());
		}
		return result;
	}

	public static GameLocation CreateGameLocation(string id)
	{
		if (string.IsNullOrWhiteSpace(id))
		{
			return null;
		}
		LocationData value;
		CreateLocationData createData = (locationData.TryGetValue(id, out value) ? value.CreateOnLoad : null);
		return CreateGameLocation(id, createData);
	}

	public static GameLocation CreateGameLocation(string id, CreateLocationData createData)
	{
		if (createData == null)
		{
			return null;
		}
		GameLocation gameLocation = ((createData.Type == null) ? new GameLocation(createData.MapPath, id) : ((GameLocation)Activator.CreateInstance(Type.GetType(createData.Type) ?? throw new Exception("Invalid type for location " + id + ": " + createData.Type), createData.MapPath, id)));
		gameLocation.isAlwaysActive.Value = createData.AlwaysActive;
		return gameLocation;
	}

	public static void AddLocations()
	{
		bool flag = false;
		foreach (KeyValuePair<string, LocationData> locationDatum in locationData)
		{
			if (locationDatum.Value.CreateOnLoad == null)
			{
				continue;
			}
			GameLocation gameLocation;
			try
			{
				gameLocation = CreateGameLocation(locationDatum.Key, locationDatum.Value.CreateOnLoad);
			}
			catch (Exception exception)
			{
				log.Error("Couldn't create the '" + locationDatum.Key + "' location. Is its data in Data/Locations invalid?", exception);
				continue;
			}
			if (gameLocation == null)
			{
				log.Error("Couldn't create the '" + locationDatum.Key + "' location. Is its data in Data/Locations invalid?");
				continue;
			}
			if (!flag)
			{
				try
				{
					gameLocation.map.LoadTileSheets(mapDisplayDevice);
					currentLocation = gameLocation;
					flag = true;
				}
				catch (Exception exception2)
				{
					log.Error("Couldn't load tilesheets for the '" + locationDatum.Key + "' location.", exception2);
				}
			}
			locations.Add(gameLocation);
		}
		for (int i = 1; i < netWorldState.Value.HighestPlayerLimit; i++)
		{
			GameLocation gameLocation2 = CreateGameLocation("Cellar");
			gameLocation2.name.Value += i + 1;
			locations.Add(gameLocation2);
		}
	}

	public static void AddNPCs()
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		foreach (KeyValuePair<string, CharacterData> characterDatum in characterData)
		{
			if (characterDatum.Value.SpawnIfMissing)
			{
				AddCharacterIfNecessary(characterDatum.Key);
			}
		}
		GameLocation locationFromNameInLocationsList = getLocationFromNameInLocationsList("QiNutRoom");
		if (locationFromNameInLocationsList.getCharacterFromName("Mister Qi") == null)
		{
			AnimatedSprite sprite = new AnimatedSprite("Characters\\MrQi", 0, 16, 32);
			locationFromNameInLocationsList.addCharacter(new NPC(sprite, new Vector2(448f, 256f), "QiNutRoom", 0, "Mister Qi", datable: false, content.Load<Texture2D>("Portraits\\MrQi")));
		}
	}

	public static void AddModNPCs()
	{
	}

	public static void fixProblems()
	{
		if (!IsMasterGame)
		{
			return;
		}
		foreach (Farmer allFarmer in getAllFarmers())
		{
			allFarmer.LearnDefaultRecipes();
			allFarmer.AddMissedMailAndRecipes();
			LevelUpMenu.RevalidateHealth(allFarmer);
			LevelUpMenu.AddMissedProfessionChoices(allFarmer);
		}
		Utility.ForEachLocation(delegate(GameLocation location)
		{
			location.characters.RemoveWhere(delegate(NPC npc)
			{
				if (npc == null)
				{
					log.Warn("Removed broken NPC in " + location.NameOrUniqueName + ": null instance.");
					return true;
				}
				if (npc.IsVillager && npc.GetData() == null)
				{
					try
					{
						if (npc.Sprite.Texture == null)
						{
							log.Warn($"Removed broken NPC '{npc.Name}' in {location.NameOrUniqueName}: villager with no data or sprites.");
							return true;
						}
					}
					catch
					{
						log.Warn($"Removed broken NPC '{npc.Name}' in {location.NameOrUniqueName}: villager with no data or sprites.");
						return true;
					}
				}
				return false;
			});
			return true;
		});
		AddNPCs();
		List<NPC> divorced = null;
		Utility.ForEachVillager(delegate(NPC n)
		{
			if (!n.datable.Value || n.getSpouse() != null)
			{
				return true;
			}
			if (n.DefaultMap == null || !n.DefaultMap.ContainsIgnoreCase("cabin") || n.DefaultMap != "FarmHouse")
			{
				return true;
			}
			CharacterData data = n.GetData();
			if (data == null)
			{
				return true;
			}
			NPC.ReadNpcHomeData(data, n.currentLocation, out var locationName, out var _, out var _);
			if (n.DefaultMap != locationName)
			{
				if (divorced == null)
				{
					divorced = new List<NPC>();
				}
				divorced.Add(n);
			}
			return true;
		});
		if (divorced != null)
		{
			foreach (NPC item3 in divorced)
			{
				log.Warn("Fixing " + item3.Name + " who was improperly divorced and left stranded");
				item3.PerformDivorce();
			}
		}
		foreach (Farmer allFarmer2 in getAllFarmers())
		{
			if (allFarmer2.hasQuest("130"))
			{
				HashSet<string> requiredQuestItems = new HashSet<string> { "(O)864", "(O)865", "(O)866", "(O)867", "(O)868", "(O)869", "(O)870" };
				bool found = false;
				foreach (string item4 in requiredQuestItems)
				{
					if (allFarmer2.Items.ContainsId(item4))
					{
						found = true;
						break;
					}
				}
				if (!found)
				{
					Utility.ForEachItem(delegate(Item item2)
					{
						found = requiredQuestItems.Contains(item2.QualifiedItemId);
						return !found;
					});
				}
				if (!found)
				{
					Object obj = ItemRegistry.Create<Object>("(O)864");
					obj.specialItem = true;
					obj.questItem.Value = true;
					if (!allFarmer2.addItemToInventoryBool(obj))
					{
						allFarmer2.team.returnedDonations.Add(obj);
						allFarmer2.team.newLostAndFoundItems.Value = true;
					}
				}
			}
			else if (!allFarmer2.craftingRecipes.ContainsKey("Fairy Dust") && allFarmer2.mailReceived.Contains("birdieQuestBegun"))
			{
				allFarmer2.mailReceived.Remove("birdieQuestBegun");
			}
		}
		int num = getAllFarmers().Count();
		Dictionary<Type, int> missingTools = new Dictionary<Type, int>
		{
			[typeof(Axe)] = num,
			[typeof(Pickaxe)] = num,
			[typeof(Hoe)] = num,
			[typeof(WateringCan)] = num,
			[typeof(Wand)] = 0
		};
		foreach (Farmer allFarmer3 in getAllFarmers())
		{
			if (allFarmer3.hasOrWillReceiveMail("ReturnScepter"))
			{
				missingTools[typeof(Wand)]++;
			}
		}
		int missingScythes = num;
		foreach (Farmer allFarmer4 in getAllFarmers())
		{
			if (allFarmer4.toolBeingUpgraded.Value != null)
			{
				allFarmer4.toolBeingUpgraded.Value.FixStackSize();
				Type type = allFarmer4.toolBeingUpgraded.Value.GetType();
				if (missingTools.TryGetValue(type, out var value))
				{
					missingTools[type] = value - 1;
				}
			}
			for (int num2 = 0; num2 < allFarmer4.Items.Count; num2++)
			{
				if (allFarmer4.Items[num2] != null)
				{
					checkIsMissingTool(missingTools, ref missingScythes, allFarmer4.Items[num2]);
				}
			}
		}
		bool flag = true;
		foreach (int value2 in missingTools.Values)
		{
			if (value2 > 0)
			{
				flag = false;
				break;
			}
		}
		if (missingScythes > 0)
		{
			flag = false;
		}
		if (flag)
		{
			return;
		}
		Utility.ForEachLocation(delegate(GameLocation l)
		{
			List<Debris> list2 = new List<Debris>();
			foreach (Debris debri in l.debris)
			{
				Item item2 = debri.item;
				if (item2 != null)
				{
					foreach (Type key in missingTools.Keys)
					{
						if (item2.GetType() == key)
						{
							list2.Add(debri);
						}
					}
					if (item2.QualifiedItemId == "(W)47")
					{
						list2.Add(debri);
					}
				}
			}
			foreach (Debris item5 in list2)
			{
				l.debris.Remove(item5);
			}
			return true;
		});
		Utility.iterateChestsAndStorage(delegate(Item item2)
		{
			checkIsMissingTool(missingTools, ref missingScythes, item2);
		});
		List<string> list = new List<string>();
		foreach (KeyValuePair<Type, int> item6 in missingTools)
		{
			if (item6.Value > 0)
			{
				for (int num3 = 0; num3 < item6.Value; num3++)
				{
					list.Add(item6.Key.ToString());
				}
			}
		}
		for (int num4 = 0; num4 < missingScythes; num4++)
		{
			list.Add("Scythe");
		}
		if (list.Count > 0)
		{
			addMailForTomorrow("foundLostTools");
		}
		for (int num5 = 0; num5 < list.Count; num5++)
		{
			Item item = null;
			switch (list[num5])
			{
			case "StardewValley.Tools.Axe":
				item = ItemRegistry.Create("(T)Axe");
				break;
			case "StardewValley.Tools.Hoe":
				item = ItemRegistry.Create("(T)Hoe");
				break;
			case "StardewValley.Tools.WateringCan":
				item = ItemRegistry.Create("(T)WateringCan");
				break;
			case "Scythe":
				item = ItemRegistry.Create("(W)47");
				break;
			case "StardewValley.Tools.Pickaxe":
				item = ItemRegistry.Create("(T)Pickaxe");
				break;
			case "StardewValley.Tools.Wand":
				item = ItemRegistry.Create("(T)ReturnScepter");
				break;
			}
			if (item != null)
			{
				if (newDaySync.hasInstance())
				{
					player.team.newLostAndFoundItems.Value = true;
				}
				player.team.returnedDonations.Add(item);
			}
		}
	}

	private static void checkIsMissingTool(Dictionary<Type, int> missingTools, ref int missingScythes, Item item)
	{
		foreach (Type key in missingTools.Keys)
		{
			if (item.GetType() == key)
			{
				missingTools[key]--;
			}
		}
		if (item.QualifiedItemId == "(W)47")
		{
			missingScythes--;
		}
	}

	public static void newDayAfterFade(Action after)
	{
		if (player.currentLocation != null)
		{
			if (player.rightRing.Value != null)
			{
				player.rightRing.Value.onLeaveLocation(player, player.currentLocation);
			}
			if (player.leftRing.Value != null)
			{
				player.leftRing.Value.onLeaveLocation(player, player.currentLocation);
			}
		}
		if (LocalMultiplayer.IsLocalMultiplayer())
		{
			hooks.OnGame1_NewDayAfterFade(delegate
			{
				game1.isLocalMultiplayerNewDayActive = true;
				_afterNewDayAction = after;
				GameRunner.instance.activeNewDayProcesses.Add(new KeyValuePair<Game1, IEnumerator<int>>(game1, _newDayAfterFade()));
			});
			return;
		}
		hooks.OnGame1_NewDayAfterFade(delegate
		{
			_afterNewDayAction = after;
			if (_newDayTask != null)
			{
				log.Warn("Warning: There is already a _newDayTask; unusual code path.\n" + StackTraceHelper.StackTrace);
			}
			else
			{
				_newDayTask = new Task(delegate
				{
					Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
					IEnumerator<int> enumerator = _newDayAfterFade();
					while (enumerator.MoveNext())
					{
					}
				});
			}
		});
	}

	public static bool CanAcceptDailyQuest()
	{
		if (questOfTheDay == null)
		{
			return false;
		}
		if (player.acceptedDailyQuest.Value)
		{
			return false;
		}
		if (string.IsNullOrEmpty(questOfTheDay.questDescription))
		{
			return false;
		}
		return true;
	}

	private static IEnumerator<int> _newDayAfterFade()
	{
		TriggerActionManager.Raise("DayEnding");
		newDaySync.start();
		while (!newDaySync.hasStarted())
		{
			yield return 0;
		}
		int timeWentToSleep = timeOfDay;
		newDaySync.barrier("start");
		while (!newDaySync.isBarrierReady("start"))
		{
			yield return 0;
		}
		int overnightMinutesElapsed = Utility.CalculateMinutesUntilMorning(timeWentToSleep);
		stats.AverageBedtime = (uint)timeWentToSleep;
		if (IsMasterGame)
		{
			dayOfMonth++;
			stats.DaysPlayed++;
			if (dayOfMonth > 28)
			{
				dayOfMonth = 1;
				Season val = season;
				switch ((int)val)
				{
				case 0:
					season = (Season)1;
					break;
				case 1:
					season = (Season)2;
					break;
				case 2:
					season = (Season)3;
					break;
				case 3:
					season = (Season)0;
					year++;
					MineShaft.yearUpdate();
					break;
				}
			}
			timeOfDay = 600;
			netWorldState.Value.UpdateFromGame1();
		}
		newDaySync.barrier("date");
		while (!newDaySync.isBarrierReady("date"))
		{
			yield return 0;
		}
		player.dayOfMonthForSaveGame = dayOfMonth;
		player.seasonForSaveGame = seasonIndex;
		player.yearForSaveGame = year;
		flushLocationLookup();
		Event.OnNewDay();
		try
		{
			fixProblems();
		}
		catch (Exception)
		{
		}
		foreach (Farmer allFarmer in getAllFarmers())
		{
			allFarmer.FarmerSprite.PauseForSingleAnimation = false;
		}
		whereIsTodaysFest = null;
		if (wind != null)
		{
			wind.Stop((AudioStopOptions)1);
			wind = null;
		}
		player.chestConsumedMineLevels.RemoveWhere((KeyValuePair<int, bool> pair) => pair.Key > 120);
		player.currentEyes = 0;
		int num;
		if (IsMasterGame)
		{
			player.team.announcedSleepingFarmers.Clear();
			num = Utility.CreateRandomSeed(uniqueIDForThisGame / 100, stats.DaysPlayed * 10 + 1, stats.StepsTaken);
			newDaySync.sendVar<NetInt, int>("seed", num);
		}
		else
		{
			while (!newDaySync.isVarReady("seed"))
			{
				yield return 0;
			}
			num = newDaySync.waitForVar<NetInt, int>("seed");
		}
		random = Utility.CreateRandom(num);
		for (int num2 = 0; num2 < dayOfMonth; num2++)
		{
			random.Next();
		}
		player.team.endOfNightStatus.UpdateState("sleep");
		newDaySync.barrier("sleep");
		while (!newDaySync.isBarrierReady("sleep"))
		{
			yield return 0;
		}
		gameTimeInterval = 0;
		game1.wasAskedLeoMemory = false;
		player.team.Update();
		player.team.NewDay();
		player.passedOut = false;
		player.CanMove = true;
		player.FarmerSprite.PauseForSingleAnimation = false;
		player.FarmerSprite.StopAnimation();
		player.completelyStopAnimatingOrDoingAction();
		changeMusicTrack("silence", track_interruptable: false, (MusicContext)0);
		if (IsMasterGame)
		{
			UpdateDishOfTheDay();
		}
		newDaySync.barrier("dishOfTheDay");
		while (!newDaySync.isBarrierReady("dishOfTheDay"))
		{
			yield return 0;
		}
		npcDialogues = null;
		Utility.ForEachCharacter(delegate(NPC n)
		{
			n.updatedDialogueYet = false;
			return true;
		});
		Utility.ForEachLocation(delegate(GameLocation location)
		{
			location.currentEvent = null;
			if (IsMasterGame)
			{
				location.passTimeForObjects(overnightMinutesElapsed);
			}
			return true;
		});
		outdoorLight = Color.White;
		ambientLight = Color.White;
		if (isLightning && IsMasterGame)
		{
			Utility.overnightLightning(timeWentToSleep);
		}
		if (MasterPlayer.hasOrWillReceiveMail("ccBulletinThankYou") && !player.hasOrWillReceiveMail("ccBulletinThankYou"))
		{
			addMailForTomorrow("ccBulletinThankYou");
		}
		ReceiveMailForTomorrow();
		if (Utility.TryGetRandom(player.friendshipData, out var key, out var value) && random.NextBool((double)(value.Points / 250) * 0.1) && player.spouse != key && DataLoader.Mail(content).ContainsKey(key))
		{
			mailbox.Add(key);
		}
		MineShaft.clearActiveMines();
		VolcanoDungeon.ClearAllLevels();
		netWorldState.Value.CheckedGarbage.Clear();
		for (int num3 = player.enchantments.Count - 1; num3 >= 0; num3--)
		{
			player.enchantments[num3].OnUnequip(player);
		}
		player.dayupdate(timeWentToSleep);
		if (IsMasterGame)
		{
			player.team.sharedDailyLuck.Value = Math.Min(0.10000000149011612, (double)random.Next(-100, 101) / 1000.0);
		}
		player.showToolUpgradeAvailability();
		if (IsMasterGame)
		{
			queueWeddingsForToday();
			newDaySync.sendVar<NetRef<NetLongList>, NetLongList>("weddingsToday", new NetLongList(weddingsToday));
		}
		else
		{
			while (!newDaySync.isVarReady("weddingsToday"))
			{
				yield return 0;
			}
			weddingsToday = new List<long>(newDaySync.waitForVar<NetRef<NetLongList>, NetLongList>("weddingsToday"));
		}
		weddingToday = false;
		foreach (long item in weddingsToday)
		{
			Farmer farmer = GetPlayer(item);
			if (farmer != null && !farmer.hasCurrentOrPendingRoommate())
			{
				weddingToday = true;
				break;
			}
		}
		if (player.spouse != null && player.isEngaged() && weddingsToday.Contains(player.UniqueMultiplayerID))
		{
			Friendship friendship = player.friendshipData[player.spouse];
			friendship.Status = FriendshipStatus.Married;
			friendship.WeddingDate = new WorldDate(Date);
			prepareSpouseForWedding(player);
			if (!player.getSpouse().isRoommate())
			{
				player.autoGenerateActiveDialogueEvent("married_" + player.spouse);
				if (!player.autoGenerateActiveDialogueEvent("married"))
				{
					player.autoGenerateActiveDialogueEvent("married_twice");
				}
			}
			else
			{
				player.autoGenerateActiveDialogueEvent("roommates_" + player.spouse);
			}
		}
		NetLongDictionary<NetList<Item, NetRef<Item>>, NetRef<NetList<Item, NetRef<Item>>>> additional_shipped_items = new NetLongDictionary<NetList<Item, NetRef<Item>>, NetRef<NetList<Item, NetRef<Item>>>>();
		if (IsMasterGame)
		{
			Utility.ForEachLocation(delegate(GameLocation location)
			{
				foreach (Object value4 in location.objects.Values)
				{
					if (value4 is Chest { SpecialChestType: Chest.SpecialChestTypes.MiniShippingBin } chest)
					{
						chest.clearNulls();
						if (player.team.useSeparateWallets.Value)
						{
							foreach (long key3 in chest.separateWalletItems.Keys)
							{
								if (!additional_shipped_items.ContainsKey(key3))
								{
									additional_shipped_items[key3] = new NetList<Item, NetRef<Item>>();
								}
								List<Item> list3 = new List<Item>(chest.separateWalletItems[key3]);
								chest.separateWalletItems[key3].Clear();
								foreach (Item item2 in list3)
								{
									item2.onDetachedFromParent();
									additional_shipped_items[key3].Add(item2);
								}
							}
						}
						else
						{
							IInventory shippingBin4 = getFarm().getShippingBin(player);
							shippingBin4.RemoveEmptySlots();
							foreach (Item item3 in chest.Items)
							{
								item3.onDetachedFromParent();
								shippingBin4.Add(item3);
							}
						}
						chest.Items.Clear();
						chest.separateWalletItems.Clear();
					}
				}
				return true;
			});
		}
		if (IsMasterGame)
		{
			newDaySync.sendVar<NetRef<NetLongDictionary<NetList<Item, NetRef<Item>>, NetRef<NetList<Item, NetRef<Item>>>>>, NetLongDictionary<NetList<Item, NetRef<Item>>, NetRef<NetList<Item, NetRef<Item>>>>>("additional_shipped_items", additional_shipped_items);
		}
		else
		{
			while (!newDaySync.isVarReady("additional_shipped_items"))
			{
				yield return 0;
			}
			additional_shipped_items = newDaySync.waitForVar<NetRef<NetLongDictionary<NetList<Item, NetRef<Item>>, NetRef<NetList<Item, NetRef<Item>>>>>, NetLongDictionary<NetList<Item, NetRef<Item>>, NetRef<NetList<Item, NetRef<Item>>>>>("additional_shipped_items");
		}
		if (player.team.useSeparateWallets.Value)
		{
			IInventory shippingBin = getFarm().getShippingBin(player);
			if (additional_shipped_items.TryGetValue(player.UniqueMultiplayerID, out var value2))
			{
				foreach (Item item4 in value2)
				{
					shippingBin.Add(item4);
				}
			}
		}
		newDaySync.barrier("handleMiniShippingBins");
		while (!newDaySync.isBarrierReady("handleMiniShippingBins"))
		{
			yield return 0;
		}
		IInventory shippingBin2 = getFarm().getShippingBin(player);
		shippingBin2.RemoveEmptySlots();
		foreach (Item item5 in shippingBin2)
		{
			player.displayedShippedItems.Add(item5);
		}
		if (player.useSeparateWallets || player.IsMainPlayer)
		{
			int num4 = 0;
			foreach (Item item6 in shippingBin2)
			{
				int num5 = 0;
				if (item6 is Object obj)
				{
					num5 = obj.sellToStorePrice(-1L) * obj.Stack;
					num4 += num5;
				}
				if (player.team.specialOrders == null)
				{
					continue;
				}
				foreach (SpecialOrder specialOrder in player.team.specialOrders)
				{
					specialOrder.onItemShipped?.Invoke(player, item6, num5);
				}
			}
			player.Money += num4;
		}
		if (IsMasterGame)
		{
			if (IsWinter && dayOfMonth == 18)
			{
				GameLocation gameLocation = RequireLocation("Submarine");
				if (gameLocation.objects.Length >= 0)
				{
					Utility.transferPlacedObjectsFromOneLocationToAnother(gameLocation, (GameLocation)null, (Vector2?)new Vector2(20f, 20f), getLocationFromName("Beach"));
				}
				gameLocation = RequireLocation("MermaidHouse");
				if (gameLocation.objects.Length >= 0)
				{
					Utility.transferPlacedObjectsFromOneLocationToAnother(gameLocation, (GameLocation)null, (Vector2?)new Vector2(21f, 20f), getLocationFromName("Beach"));
				}
			}
			if (player.hasOrWillReceiveMail("pamHouseUpgrade") && !player.hasOrWillReceiveMail("transferredObjectsPamHouse"))
			{
				addMailForTomorrow("transferredObjectsPamHouse", noLetter: true);
				GameLocation gameLocation2 = RequireLocation("Trailer");
				GameLocation locationFromName = getLocationFromName("Trailer_Big");
				if (gameLocation2.objects.Length >= 0)
				{
					Utility.transferPlacedObjectsFromOneLocationToAnother(gameLocation2, locationFromName, (Vector2?)new Vector2(14f, 23f), (GameLocation)null);
				}
			}
			if (Utility.HasAnyPlayerSeenEvent("191393") && !player.hasOrWillReceiveMail("transferredObjectsJojaMart"))
			{
				addMailForTomorrow("transferredObjectsJojaMart", noLetter: true);
				GameLocation gameLocation3 = RequireLocation("JojaMart");
				if (gameLocation3.objects.Length >= 0)
				{
					Utility.transferPlacedObjectsFromOneLocationToAnother(gameLocation3, (GameLocation)null, (Vector2?)new Vector2(89f, 51f), getLocationFromName("Town"));
				}
			}
		}
		if (player.useSeparateWallets && player.IsMainPlayer)
		{
			foreach (Farmer offlineFarmhand in getOfflineFarmhands())
			{
				if (offlineFarmhand.isUnclaimedFarmhand)
				{
					continue;
				}
				int num6 = 0;
				IInventory shippingBin3 = getFarm().getShippingBin(offlineFarmhand);
				shippingBin3.RemoveEmptySlots();
				foreach (Item item7 in shippingBin3)
				{
					int num7 = 0;
					if (item7 is Object obj2)
					{
						num7 = obj2.sellToStorePrice(offlineFarmhand.UniqueMultiplayerID) * obj2.Stack;
						num6 += num7;
					}
					if (player.team.specialOrders == null)
					{
						continue;
					}
					foreach (SpecialOrder specialOrder2 in player.team.specialOrders)
					{
						specialOrder2.onItemShipped?.Invoke(player, item7, num7);
					}
				}
				player.team.AddIndividualMoney(offlineFarmhand, num6);
				shippingBin3.Clear();
			}
		}
		List<NPC> divorceNPCs = new List<NPC>();
		if (IsMasterGame)
		{
			foreach (Farmer allFarmer2 in getAllFarmers())
			{
				if (allFarmer2.isActive() && allFarmer2.divorceTonight.Value && allFarmer2.getSpouse() != null)
				{
					divorceNPCs.Add(allFarmer2.getSpouse());
				}
			}
		}
		newDaySync.barrier("player.dayupdate");
		while (!newDaySync.isBarrierReady("player.dayupdate"))
		{
			yield return 0;
		}
		if (player.divorceTonight.Value)
		{
			player.doDivorce();
		}
		newDaySync.barrier("player.divorce");
		while (!newDaySync.isBarrierReady("player.divorce"))
		{
			yield return 0;
		}
		if (IsMasterGame)
		{
			foreach (NPC item8 in divorceNPCs)
			{
				if (item8.getSpouse() == null)
				{
					item8.PerformDivorce();
				}
			}
		}
		newDaySync.barrier("player.finishDivorce");
		while (!newDaySync.isBarrierReady("player.finishDivorce"))
		{
			yield return 0;
		}
		if (IsMasterGame)
		{
			Utility.ForEachBuilding(delegate(Building building)
			{
				if (building?.GetIndoors() is Cabin cabin)
				{
					cabin.updateFarmLayout();
				}
				return true;
			});
		}
		newDaySync.barrier("updateFarmLayout");
		while (!newDaySync.isBarrierReady("updateFarmLayout"))
		{
			yield return 0;
		}
		if (IsMasterGame && player.changeWalletTypeTonight.Value)
		{
			if (player.useSeparateWallets)
			{
				ManorHouse.MergeWallets();
			}
			else
			{
				ManorHouse.SeparateWallets();
			}
		}
		newDaySync.barrier("player.wallets");
		while (!newDaySync.isBarrierReady("player.wallets"))
		{
			yield return 0;
		}
		getFarm().lastItemShipped = null;
		getFarm().getShippingBin(player).Clear();
		newDaySync.barrier("clearShipping");
		while (!newDaySync.isBarrierReady("clearShipping"))
		{
			yield return 0;
		}
		if (IsClient)
		{
			multiplayer.sendFarmhand();
			newDaySync.processMessages();
		}
		newDaySync.barrier("sendFarmhands");
		while (!newDaySync.isBarrierReady("sendFarmhands"))
		{
			yield return 0;
		}
		if (IsMasterGame)
		{
			multiplayer.saveFarmhands();
		}
		newDaySync.barrier("saveFarmhands");
		while (!newDaySync.isBarrierReady("saveFarmhands"))
		{
			yield return 0;
		}
		if (IsMasterGame)
		{
			UpdatePassiveFestivalStates();
			if (Utility.IsPassiveFestivalDay("NightMarket") && IsMasterGame && netWorldState.Value.VisitsUntilY1Guarantee >= 0)
			{
				netWorldState.Value.VisitsUntilY1Guarantee--;
			}
		}
		if (dayOfMonth == 1)
		{
			OnNewSeason();
		}
		if (IsMasterGame && (dayOfMonth == 1 || dayOfMonth == 8 || dayOfMonth == 15 || dayOfMonth == 22))
		{
			SpecialOrder.UpdateAvailableSpecialOrders("", forceRefresh: true);
			SpecialOrder.UpdateAvailableSpecialOrders("Qi", forceRefresh: true);
		}
		if (IsMasterGame)
		{
			netWorldState.Value.UpdateFromGame1();
		}
		newDaySync.barrier("specialOrders");
		while (!newDaySync.isBarrierReady("specialOrders"))
		{
			yield return 0;
		}
		if (IsMasterGame)
		{
			player.team.specialOrders.RemoveWhere(delegate(SpecialOrder order)
			{
				if (order.questState.Value != SpecialOrderStatus.Complete && order.GetDaysLeft() <= 0)
				{
					order.OnFail();
					return true;
				}
				return false;
			});
		}
		newDaySync.barrier("processOrders");
		while (!newDaySync.isBarrierReady("processOrders"))
		{
			yield return 0;
		}
		if (IsMasterGame)
		{
			foreach (string item9 in player.team.specialRulesRemovedToday)
			{
				SpecialOrder.RemoveSpecialRuleAtEndOfDay(item9);
			}
		}
		player.team.specialRulesRemovedToday.Clear();
		if (DataLoader.Mail(content).ContainsKey(currentSeason + "_" + dayOfMonth + "_" + year))
		{
			mailbox.Add(currentSeason + "_" + dayOfMonth + "_" + year);
		}
		else if (DataLoader.Mail(content).ContainsKey(currentSeason + "_" + dayOfMonth))
		{
			mailbox.Add(currentSeason + "_" + dayOfMonth);
		}
		if (MasterPlayer.mailReceived.Contains("ccVault") && IsSpring && dayOfMonth == 14)
		{
			mailbox.Add("DesertFestival");
		}
		if (IsMasterGame)
		{
			if (player.team.toggleMineShrineOvernight.Value)
			{
				player.team.toggleMineShrineOvernight.Value = false;
				player.team.mineShrineActivated.Value = !player.team.mineShrineActivated.Value;
				if (player.team.mineShrineActivated.Value)
				{
					netWorldState.Value.MinesDifficulty++;
				}
				else
				{
					netWorldState.Value.MinesDifficulty--;
				}
			}
			if (player.team.toggleSkullShrineOvernight.Value)
			{
				player.team.toggleSkullShrineOvernight.Value = false;
				player.team.skullShrineActivated.Value = !player.team.skullShrineActivated.Value;
				if (player.team.skullShrineActivated.Value)
				{
					netWorldState.Value.SkullCavesDifficulty++;
				}
				else
				{
					netWorldState.Value.SkullCavesDifficulty--;
				}
			}
		}
		if (IsMasterGame)
		{
			if (!player.team.SpecialOrderRuleActive("MINE_HARD") && netWorldState.Value.MinesDifficulty > 1)
			{
				netWorldState.Value.MinesDifficulty = 1;
			}
			if (!player.team.SpecialOrderRuleActive("SC_HARD") && netWorldState.Value.SkullCavesDifficulty > 1)
			{
				netWorldState.Value.SkullCavesDifficulty = 1;
			}
		}
		if (IsMasterGame)
		{
			RefreshQuestOfTheDay();
		}
		newDaySync.barrier("questOfTheDay");
		while (!newDaySync.isBarrierReady("questOfTheDay"))
		{
			yield return 0;
		}
		bool yesterdayWasGreenRain = wasGreenRain;
		wasGreenRain = false;
		UpdateWeatherForNewDay();
		newDaySync.barrier("updateWeather");
		while (!newDaySync.isBarrierReady("updateWeather"))
		{
			yield return 0;
		}
		ApplyWeatherForNewDay();
		if (isGreenRain)
		{
			morningQueue.Enqueue(delegate
			{
				showGlobalMessage(content.LoadString("Strings\\1_6_Strings:greenrainmessage"));
			});
			if (year == 1 && !player.hasOrWillReceiveMail("GreenRainGus"))
			{
				mailbox.Add("GreenRainGus");
			}
			if (IsMasterGame)
			{
				Utility.ForEachLocation(delegate(GameLocation location)
				{
					location.performGreenRainUpdate();
					return true;
				});
			}
		}
		else if (yesterdayWasGreenRain)
		{
			if (IsMasterGame)
			{
				Utility.ForEachLocation(delegate(GameLocation location)
				{
					location.performDayAfterGreenRainUpdate();
					return true;
				});
			}
			if (year == 1)
			{
				player.activeDialogueEvents.TryAdd("GreenRainFinished", 1);
			}
		}
		if (Utility.getDaysOfBooksellerThisSeason().Contains(dayOfMonth))
		{
			addMorningFluffFunction(delegate
			{
				showGlobalMessage(content.LoadString("Strings\\1_6_Strings:BooksellerInTown"));
			});
		}
		WeatherDebris.globalWind = 0f;
		windGust = 0f;
		AddNPCs();
		Utility.ForEachVillager(delegate(NPC n)
		{
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			player.mailReceived.Remove(n.Name);
			player.mailReceived.Remove(n.Name + "Cooking");
			n.drawOffset = Vector2.Zero;
			if (!IsMasterGame)
			{
				n.ChooseAppearance();
			}
			return true;
		});
		FarmAnimal.reservedGrass.Clear();
		if (IsMasterGame)
		{
			NPC.hasSomeoneRepairedTheFences = false;
			NPC.hasSomeoneFedTheAnimals = false;
			NPC.hasSomeoneFedThePet = false;
			NPC.hasSomeoneWateredCrops = false;
			foreach (GameLocation location in locations)
			{
				location.ResetCharacterDialogues();
				location.DayUpdate(dayOfMonth);
			}
			netWorldState.Value.UpdateUnderConstruction();
			UpdateHorseOwnership();
			foreach (NPC allCharacter in Utility.getAllCharacters())
			{
				if (allCharacter.IsVillager)
				{
					allCharacter.islandScheduleName.Value = null;
					allCharacter.currentScheduleDelay = 0f;
				}
				allCharacter.dayUpdate(dayOfMonth);
			}
			IslandSouth.SetupIslandSchedules();
			HashSet<NPC> purchased_item_npcs = new HashSet<NPC>();
			UpdateShopPlayerItemInventory("SeedShop", purchased_item_npcs);
			UpdateShopPlayerItemInventory("FishShop", purchased_item_npcs);
		}
		if (IsMasterGame && netWorldState.Value.GetWeatherForLocation("Island").IsRaining)
		{
			Vector2 tile_position = default(Vector2);
			((Vector2)(ref tile_position))._002Ector(0f, 0f);
			IslandLocation islandLocation = null;
			List<int> list = new List<int>();
			for (int num8 = 0; num8 < 4; num8++)
			{
				list.Add(num8);
			}
			Utility.Shuffle(Utility.CreateRandom(uniqueIDForThisGame), list);
			switch (list[currentGemBirdIndex])
			{
			case 0:
				islandLocation = getLocationFromName("IslandSouth") as IslandLocation;
				((Vector2)(ref tile_position))._002Ector(10f, 30f);
				break;
			case 1:
				islandLocation = getLocationFromName("IslandNorth") as IslandLocation;
				((Vector2)(ref tile_position))._002Ector(56f, 56f);
				break;
			case 2:
				islandLocation = getLocationFromName("Islandwest") as IslandLocation;
				((Vector2)(ref tile_position))._002Ector(53f, 51f);
				break;
			case 3:
				islandLocation = getLocationFromName("IslandEast") as IslandLocation;
				((Vector2)(ref tile_position))._002Ector(21f, 35f);
				break;
			}
			currentGemBirdIndex = (currentGemBirdIndex + 1) % 4;
			if (islandLocation != null)
			{
				islandLocation.locationGemBird.Value = new IslandGemBird(tile_position, IslandGemBird.GetBirdTypeForLocation(islandLocation.Name));
			}
		}
		if (IsMasterGame)
		{
			Utility.ForEachLocation(delegate(GameLocation location)
			{
				if (location.IsOutdoors && location.IsRainingHere())
				{
					foreach (Building building in location.buildings)
					{
						if (building is PetBowl petBowl)
						{
							petBowl.watered.Value = true;
						}
					}
					foreach (KeyValuePair<Vector2, TerrainFeature> pair in location.terrainFeatures.Pairs)
					{
						if (pair.Value is HoeDirt hoeDirt && hoeDirt.state.Value != 2)
						{
							hoeDirt.state.Value = 1;
						}
					}
				}
				return true;
			});
		}
		WorldDate worldDate = new WorldDate(Date);
		worldDate.TotalDays--;
		foreach (KeyValuePair<string, PassiveFestivalData> item10 in DataLoader.PassiveFestivals(content))
		{
			string key2 = item10.Key;
			PassiveFestivalData value3 = item10.Value;
			if (worldDate.DayOfMonth == value3.EndDay && worldDate.Season == value3.Season && GameStateQuery.CheckConditions(value3.Condition) && value3 != null && value3.CleanupMethod != null)
			{
				if (StaticDelegateBuilder.TryCreateDelegate<FestivalCleanupDelegate>(value3.CleanupMethod, out var createdDelegate, out var error))
				{
					createdDelegate();
					continue;
				}
				log.Warn($"Passive festival '{key2}' has invalid cleanup method '{value3.CleanupMethod}': {error}");
			}
		}
		PerformPassiveFestivalSetup();
		newDaySync.barrier("buildingUpgrades");
		while (!newDaySync.isBarrierReady("buildingUpgrades"))
		{
			yield return 0;
		}
		List<string> list2 = new List<string>(player.team.mailToRemoveOvernight);
		foreach (string item11 in new List<string>(player.team.itemsToRemoveOvernight))
		{
			if (IsMasterGame)
			{
				game1._PerformRemoveNormalItemFromWorldOvernight(item11);
				foreach (Farmer offlineFarmhand2 in getOfflineFarmhands())
				{
					game1._PerformRemoveNormalItemFromFarmerOvernight(offlineFarmhand2, item11);
				}
			}
			game1._PerformRemoveNormalItemFromFarmerOvernight(player, item11);
		}
		foreach (string item12 in list2)
		{
			if (IsMasterGame)
			{
				foreach (Farmer allFarmer3 in getAllFarmers())
				{
					allFarmer3.RemoveMail(item12, allFarmer3 == MasterPlayer);
				}
			}
			else
			{
				player.RemoveMail(item12);
			}
		}
		newDaySync.barrier("removeItemsFromWorld");
		while (!newDaySync.isBarrierReady("removeItemsFromWorld"))
		{
			yield return 0;
		}
		if (IsMasterGame)
		{
			player.team.itemsToRemoveOvernight.Clear();
			player.team.mailToRemoveOvernight.Clear();
		}
		newDay = false;
		if (IsMasterGame)
		{
			netWorldState.Value.UpdateFromGame1();
		}
		if (player.currentLocation != null)
		{
			player.currentLocation.resetForPlayerEntry();
			BedFurniture.ApplyWakeUpPosition(player);
			forceSnapOnNextViewportUpdate = true;
			UpdateViewPort(overrideFreeze: false, player.StandingPixel);
			previousViewportPosition = new Vector2((float)((Rectangle)(ref viewport)).X, (float)((Rectangle)(ref viewport)).Y);
		}
		displayFarmer = true;
		updateWeatherIcon();
		freezeControls = false;
		if (stats.DaysPlayed > 1 || !IsMasterGame)
		{
			farmEvent = null;
			if (IsMasterGame)
			{
				farmEvent = Utility.pickFarmEvent() ?? farmEventOverride;
				farmEventOverride = null;
				newDaySync.sendVar<NetRef<FarmEvent>, FarmEvent>("farmEvent", farmEvent);
			}
			else
			{
				while (!newDaySync.isVarReady("farmEvent"))
				{
					yield return 0;
				}
				farmEvent = newDaySync.waitForVar<NetRef<FarmEvent>, FarmEvent>("farmEvent");
			}
			if (farmEvent == null)
			{
				farmEvent = Utility.pickPersonalFarmEvent();
			}
			if (farmEvent != null && farmEvent.setUp())
			{
				farmEvent = null;
			}
		}
		if (farmEvent == null)
		{
			RemoveDeliveredMailForTomorrow();
		}
		if (player.team.newLostAndFoundItems.Value)
		{
			morningQueue.Enqueue(delegate
			{
				showGlobalMessage(content.LoadString("Strings\\StringsFromCSFiles:NewLostAndFoundItems"));
			});
		}
		newDaySync.barrier("mail");
		while (!newDaySync.isBarrierReady("mail"))
		{
			yield return 0;
		}
		if (IsMasterGame)
		{
			player.team.newLostAndFoundItems.Value = false;
		}
		Utility.ForEachBuilding(delegate(Building building)
		{
			if (building.GetIndoors() is Cabin)
			{
				player.slotCanHost = true;
				return false;
			}
			return true;
		});
		if (Utility.percentGameComplete() + (float)netWorldState.Value.PerfectionWaivers * 0.01f >= 1f)
		{
			player.team.farmPerfect.Value = true;
		}
		newDaySync.barrier("checkcompletion");
		while (!newDaySync.isBarrierReady("checkcompletion"))
		{
			yield return 0;
		}
		UpdateFarmPerfection();
		if (farmEvent == null)
		{
			handlePostFarmEventActions();
			showEndOfNightStuff();
		}
		if (server != null)
		{
			server.updateLobbyData();
		}
	}

	public static void UpdateDishOfTheDay()
	{
		string text;
		do
		{
			text = random.Next(194, 240).ToString();
		}
		while (Utility.IsForbiddenDishOfTheDay(text));
		int amount = random.Next(1, 4 + ((random.NextDouble() < 0.08) ? 10 : 0));
		dishOfTheDay = ItemRegistry.Create<Object>("(O)" + text, amount);
	}

	public static void UpdateFarmPerfection()
	{
		if (MasterPlayer.mailReceived.Contains("Farm_Eternal") || (!MasterPlayer.hasCompletedCommunityCenter() && !Utility.hasFinishedJojaRoute()) || !player.team.farmPerfect.Value)
		{
			return;
		}
		addMorningFluffFunction(delegate
		{
			changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
			if (IsMasterGame)
			{
				multiplayer.globalChatInfoMessageEvenInSinglePlayer("Eternal1");
			}
			playSound("discoverMineral");
			if (IsMasterGame)
			{
				DelayedAction.functionAfterDelay(delegate
				{
					multiplayer.globalChatInfoMessageEvenInSinglePlayer("Eternal2", MasterPlayer.farmName.Value);
				}, 4000);
			}
			player.mailReceived.Add("Farm_Eternal");
			DelayedAction.functionAfterDelay(delegate
			{
				playSound("thunder_small");
				if (IsMultiplayer)
				{
					if (IsMasterGame)
					{
						multiplayer.globalChatInfoMessage("Eternal3");
					}
				}
				else
				{
					showGlobalMessage(content.LoadString("Strings\\UI:Chat_Eternal3"));
				}
			}, 12000);
		});
	}

	public static bool IsGreenRainingHere(GameLocation location = null)
	{
		if (location == null)
		{
			location = currentLocation;
		}
		if (location != null && netWorldState != null)
		{
			return location.IsGreenRainingHere();
		}
		return false;
	}

	public static bool IsRainingHere(GameLocation location = null)
	{
		if (location == null)
		{
			location = currentLocation;
		}
		if (location != null && netWorldState != null)
		{
			return location.IsRainingHere();
		}
		return false;
	}

	public static bool IsLightningHere(GameLocation location = null)
	{
		if (location == null)
		{
			location = currentLocation;
		}
		if (location != null && netWorldState != null)
		{
			return location.IsLightningHere();
		}
		return false;
	}

	public static bool IsSnowingHere(GameLocation location = null)
	{
		if (location == null)
		{
			location = currentLocation;
		}
		if (location != null && netWorldState != null)
		{
			return location.IsSnowingHere();
		}
		return false;
	}

	public static bool IsDebrisWeatherHere(GameLocation location = null)
	{
		if (location == null)
		{
			location = currentLocation;
		}
		if (location != null && netWorldState != null)
		{
			return location.IsDebrisWeatherHere();
		}
		return false;
	}

	public static string getWeatherModificationsForDate(WorldDate date, string default_weather)
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Invalid comparison between Unknown and I4
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		string result = default_weather;
		int num = date.TotalDays - Date.TotalDays;
		if (date.DayOfMonth == 1 || stats.DaysPlayed + num <= 4)
		{
			result = "Sun";
		}
		if (stats.DaysPlayed + num == 3)
		{
			result = "Rain";
		}
		if (Utility.isGreenRainDay(date.DayOfMonth, date.Season))
		{
			result = "GreenRain";
		}
		if ((int)date.Season == 1 && date.DayOfMonth % 13 == 0)
		{
			result = "Storm";
		}
		if (Utility.isFestivalDay(date.DayOfMonth, date.Season))
		{
			result = "Festival";
		}
		foreach (PassiveFestivalData value in DataLoader.PassiveFestivals(content).Values)
		{
			if (date.DayOfMonth < value.StartDay || date.DayOfMonth > value.EndDay || date.Season != value.Season || !GameStateQuery.CheckConditions(value.Condition) || value.MapReplacements == null)
			{
				continue;
			}
			foreach (string key in value.MapReplacements.Keys)
			{
				GameLocation locationFromName = getLocationFromName(key);
				if (locationFromName != null && locationFromName.InValleyContext())
				{
					result = "Sun";
					break;
				}
			}
		}
		return result;
	}

	public static void UpdateWeatherForNewDay()
	{
		weatherForTomorrow = getWeatherModificationsForDate(Date, weatherForTomorrow);
		if (weddingToday)
		{
			weatherForTomorrow = "Wedding";
		}
		if (IsMasterGame)
		{
			netWorldState.Value.GetWeatherForLocation("Default").WeatherForTomorrow = weatherForTomorrow;
		}
		wasRainingYesterday = isRaining || isLightning;
		debrisWeather.Clear();
		if (!IsMasterGame)
		{
			return;
		}
		foreach (KeyValuePair<string, LocationContextData> locationContextDatum in locationContextData)
		{
			netWorldState.Value.GetWeatherForLocation(locationContextDatum.Key).UpdateDailyWeather(locationContextDatum.Key, locationContextDatum.Value, random);
		}
		foreach (KeyValuePair<string, LocationContextData> locationContextDatum2 in locationContextData)
		{
			string copyWeatherFromLocation = locationContextDatum2.Value.CopyWeatherFromLocation;
			if (copyWeatherFromLocation != null)
			{
				try
				{
					LocationWeather weatherForLocation = netWorldState.Value.GetWeatherForLocation(locationContextDatum2.Key);
					LocationWeather weatherForLocation2 = netWorldState.Value.GetWeatherForLocation(copyWeatherFromLocation);
					weatherForLocation.CopyFrom(weatherForLocation2);
				}
				catch
				{
				}
			}
		}
	}

	public static void ApplyWeatherForNewDay()
	{
		LocationWeather weatherForLocation = netWorldState.Value.GetWeatherForLocation("Default");
		weatherForTomorrow = weatherForLocation.WeatherForTomorrow;
		isRaining = weatherForLocation.IsRaining;
		isSnowing = weatherForLocation.IsSnowing;
		isLightning = weatherForLocation.IsLightning;
		isDebrisWeather = weatherForLocation.IsDebrisWeather;
		isGreenRain = weatherForLocation.IsGreenRain;
		if (isDebrisWeather)
		{
			populateDebrisWeatherArray();
		}
		if (!IsMasterGame)
		{
			return;
		}
		foreach (string key in netWorldState.Value.LocationWeather.Keys)
		{
			LocationWeather locationWeather = netWorldState.Value.LocationWeather[key];
			if (dayOfMonth == 1)
			{
				locationWeather.monthlyNonRainyDayCount.Value = 0;
			}
			if (!locationWeather.IsRaining)
			{
				locationWeather.monthlyNonRainyDayCount.Value++;
			}
		}
	}

	public static void UpdateShopPlayerItemInventory(string location_name, HashSet<NPC> purchased_item_npcs)
	{
		if (!(getLocationFromName(location_name) is ShopLocation { itemsFromPlayerToSell: var itemsFromPlayerToSell } shopLocation))
		{
			return;
		}
		for (int num = itemsFromPlayerToSell.Count - 1; num >= 0; num--)
		{
			if (!(itemsFromPlayerToSell[num] is Object obj))
			{
				itemsFromPlayerToSell.RemoveAt(num);
			}
			else
			{
				for (int i = 0; i < obj.Stack; i++)
				{
					bool flag = false;
					if (obj.edibility.Value != -300 && random.NextDouble() < 0.04)
					{
						NPC randomNpc = Utility.GetRandomNpc((string name, CharacterData data) => data.CanCommentOnPurchasedShopItems ?? (data.HomeRegion == "Town"));
						if (randomNpc.Age != 2 && randomNpc.getSpouse() == null)
						{
							if (!purchased_item_npcs.Contains(randomNpc))
							{
								Dialogue purchasedItemDialogueForNPC = shopLocation.getPurchasedItemDialogueForNPC(obj, randomNpc);
								if (purchasedItemDialogueForNPC != null)
								{
									randomNpc.addExtraDialogue(purchasedItemDialogueForNPC);
									purchased_item_npcs.Add(randomNpc);
								}
							}
							itemsFromPlayerToSell[num] = obj.ConsumeStack(1);
							flag = true;
						}
					}
					if (!flag && random.NextDouble() < 0.15)
					{
						itemsFromPlayerToSell[num] = obj.ConsumeStack(1);
					}
					if (itemsFromPlayerToSell[num] == null)
					{
						itemsFromPlayerToSell.RemoveAt(num);
						break;
					}
				}
			}
		}
	}

	private static void handlePostFarmEventActions()
	{
		Utility.ForEachLocation(delegate(GameLocation location)
		{
			foreach (Action postFarmEventOvernightAction in location.postFarmEventOvernightActions)
			{
				postFarmEventOvernightAction();
			}
			location.postFarmEventOvernightActions.Clear();
			return true;
		});
		if (IsMasterGame)
		{
			Mountain mountain = RequireLocation<Mountain>("Mountain");
			mountain.ApplyTreehouseIfNecessary();
			if (mountain.treehouseDoorDirty)
			{
				mountain.treehouseDoorDirty = false;
				WarpPathfindingCache.PopulateCache();
			}
		}
	}

	public static void ReceiveMailForTomorrow(string mail_to_transfer = null)
	{
		foreach (string item in player.mailForTomorrow)
		{
			if (item == null)
			{
				continue;
			}
			string text = item.Replace("%&NL&%", "");
			if (mail_to_transfer == null || !(mail_to_transfer != item) || !(mail_to_transfer != text))
			{
				mailDeliveredFromMailForTomorrow.Add(item);
				if (item.Contains("%&NL&%"))
				{
					player.mailReceived.Add(text);
				}
				else
				{
					mailbox.Add(item);
				}
			}
		}
	}

	public static void RemoveDeliveredMailForTomorrow()
	{
		ReceiveMailForTomorrow("abandonedJojaMartAccessible");
		foreach (string item in mailDeliveredFromMailForTomorrow)
		{
			player.mailForTomorrow.Remove(item);
		}
		mailDeliveredFromMailForTomorrow.Clear();
	}

	public static void queueWeddingsForToday()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		weddingsToday.Clear();
		weddingToday = false;
		if (!canHaveWeddingOnDay(dayOfMonth, season))
		{
			return;
		}
		foreach (Farmer item in from farmer2 in getOnlineFarmers()
			orderby farmer2.UniqueMultiplayerID
			select farmer2)
		{
			if (item.spouse != null && item.isEngaged() && item.friendshipData[item.spouse].CountdownToWedding < 1)
			{
				weddingsToday.Add(item.UniqueMultiplayerID);
			}
			if (!item.team.IsEngaged(item.UniqueMultiplayerID))
			{
				continue;
			}
			long? spouse = item.team.GetSpouse(item.UniqueMultiplayerID);
			if (spouse.HasValue && !weddingsToday.Contains(spouse.Value))
			{
				Farmer farmer = GetPlayer(spouse.Value);
				if (farmer != null && getOnlineFarmers().Contains(farmer) && getOnlineFarmers().Contains(item) && player.team.GetFriendship(item.UniqueMultiplayerID, spouse.Value).CountdownToWedding < 1)
				{
					weddingsToday.Add(item.UniqueMultiplayerID);
				}
			}
		}
	}

	public static bool PollForEndOfNewDaySync()
	{
		if (!IsMultiplayer)
		{
			newDaySync.destroy();
			currentLocation.resetForPlayerEntry();
			return true;
		}
		if (newDaySync.readyForFinish())
		{
			if (IsMasterGame && newDaySync.hasInstance() && !newDaySync.hasFinished())
			{
				newDaySync.finish();
			}
			if (IsClient)
			{
				player.sleptInTemporaryBed.Value = false;
			}
			if (newDaySync.hasInstance() && newDaySync.hasFinished())
			{
				newDaySync.destroy();
				currentLocation.resetForPlayerEntry();
				return true;
			}
		}
		return false;
	}

	public static void updateWeatherIcon()
	{
		if (IsSnowingHere())
		{
			weatherIcon = 7;
		}
		else if (IsRainingHere())
		{
			weatherIcon = 4;
		}
		else if (IsDebrisWeatherHere() && IsSpring)
		{
			weatherIcon = 3;
		}
		else if (IsDebrisWeatherHere() && IsFall)
		{
			weatherIcon = 6;
		}
		else if (IsDebrisWeatherHere() && IsWinter)
		{
			weatherIcon = 7;
		}
		else if (weddingToday)
		{
			weatherIcon = 0;
		}
		else
		{
			weatherIcon = 2;
		}
		if (IsLightningHere())
		{
			weatherIcon = 5;
		}
		if (Utility.isFestivalDay())
		{
			weatherIcon = 1;
		}
		if (IsGreenRainingHere())
		{
			weatherIcon = 999;
		}
	}

	public static void showEndOfNightStuff()
	{
		hooks.OnGame1_ShowEndOfNightStuff(delegate
		{
			//IL_0092: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			if (!IsDedicatedHost)
			{
				bool flag = false;
				if (player.displayedShippedItems.Count > 0)
				{
					endOfNightMenus.Push(new ShippingMenu(player.displayedShippedItems));
					player.displayedShippedItems.Clear();
					flag = true;
				}
				bool flag2 = false;
				if (player.newLevels.Count > 0 && !flag)
				{
					endOfNightMenus.Push(new SaveGameMenu());
				}
				for (int num = player.newLevels.Count - 1; num >= 0; num--)
				{
					endOfNightMenus.Push(new LevelUpMenu(player.newLevels[num].X, player.newLevels[num].Y));
					flag2 = true;
				}
				if (player.farmingLevel.Value == 10 && player.miningLevel.Value == 10 && player.fishingLevel.Value == 10 && player.foragingLevel.Value == 10 && player.combatLevel.Value == 10 && player.mailReceived.Add("gotMasteryHint") && !player.locationsVisited.Contains("MasteryCave"))
				{
					morningQueue.Enqueue(delegate
					{
						showGlobalMessage(content.LoadString("Strings\\1_6_Strings:MasteryHint"));
					});
				}
				if (flag2)
				{
					playSound("newRecord");
				}
				if (client != null && client.timedOut)
				{
					return;
				}
			}
			if (endOfNightMenus.Count > 0)
			{
				showingEndOfNightStuff = true;
				activeClickableMenu = endOfNightMenus.Pop();
			}
			else
			{
				showingEndOfNightStuff = true;
				activeClickableMenu = new SaveGameMenu();
			}
		});
	}

	public static void setGraphicsForSeason(bool onLoad = false)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Expected I4, but got Unknown
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_0335: Unknown result type (might be due to invalid IL or missing references)
		foreach (GameLocation location in locations)
		{
			Season val = location.GetSeason();
			location.seasonUpdate(onLoad);
			location.updateSeasonalTileSheets();
			if (!location.IsOutdoors)
			{
				continue;
			}
			switch ((int)val)
			{
			case 0:
				eveningColor = new Color(255, 255, 0);
				break;
			case 1:
				foreach (Object value2 in location.Objects.Values)
				{
					if (!value2.IsWeeds())
					{
						continue;
					}
					switch (value2.QualifiedItemId)
					{
					case "(O)792":
						value2.SetIdAndSprite(value2.ParentSheetIndex + 1);
						continue;
					case "(O)882":
					case "(O)883":
					case "(O)884":
						continue;
					}
					if (random.NextDouble() < 0.3)
					{
						value2.SetIdAndSprite(676);
					}
					else if (random.NextDouble() < 0.3)
					{
						value2.SetIdAndSprite(677);
					}
				}
				eveningColor = new Color(255, 255, 0);
				break;
			case 2:
				foreach (Object value3 in location.Objects.Values)
				{
					if (value3.IsWeeds())
					{
						switch (value3.QualifiedItemId)
						{
						case "(O)793":
							value3.SetIdAndSprite(value3.ParentSheetIndex + 1);
							break;
						default:
							value3.SetIdAndSprite(random.Choose(678, 679));
							break;
						case "(O)882":
						case "(O)883":
						case "(O)884":
							break;
						}
					}
				}
				eveningColor = new Color(255, 255, 0);
				foreach (WeatherDebris item in debrisWeather)
				{
					item.which = 2;
				}
				break;
			case 3:
			{
				KeyValuePair<Vector2, Object>[] array = location.Objects.Pairs.ToArray();
				for (int i = 0; i < array.Length; i++)
				{
					KeyValuePair<Vector2, Object> keyValuePair = array[i];
					Object value = keyValuePair.Value;
					if (value.IsWeeds())
					{
						switch (value.QualifiedItemId)
						{
						case "(O)882":
						case "(O)883":
						case "(O)884":
							continue;
						}
						location.Objects.Remove(keyValuePair.Key);
					}
				}
				foreach (WeatherDebris item2 in debrisWeather)
				{
					item2.which = 3;
				}
				eveningColor = new Color(245, 225, 170);
				break;
			}
			}
		}
	}

	public static void pauseThenMessage(int millisecondsPause, string message)
	{
		messageAfterPause = message;
		pauseTime = millisecondsPause;
	}

	public static bool IsVisitingIslandToday(string npc_name)
	{
		return netWorldState.Value.IslandVisitors.Contains(npc_name);
	}

	public static bool shouldTimePass(bool ignore_multiplayer = false)
	{
		if (isFestival())
		{
			return false;
		}
		if (CurrentEvent != null && CurrentEvent.isWedding)
		{
			return false;
		}
		if (farmEvent != null)
		{
			return false;
		}
		if (IsMultiplayer && !ignore_multiplayer)
		{
			return !netWorldState.Value.IsTimePaused;
		}
		if (paused || freezeControls || overlayMenu != null || isTimePaused)
		{
			return false;
		}
		if (eventUp)
		{
			return false;
		}
		if (activeClickableMenu != null && !(activeClickableMenu is BobberBar))
		{
			return false;
		}
		if (!player.CanMove && !player.UsingTool)
		{
			return player.forceTimePass;
		}
		return true;
	}

	public static Farmer getPlayerOrEventFarmer()
	{
		if (eventUp && CurrentEvent != null && !CurrentEvent.isFestival && CurrentEvent.farmer != null)
		{
			return CurrentEvent.farmer;
		}
		return player;
	}

	public static void UpdateViewPort(bool overrideFreeze, Point centerPoint)
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_039b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0475: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0372: Unknown result type (might be due to invalid IL or missing references)
		//IL_0378: Unknown result type (might be due to invalid IL or missing references)
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_044c: Unknown result type (might be due to invalid IL or missing references)
		previousViewportPosition.X = ((Rectangle)(ref viewport)).X;
		previousViewportPosition.Y = ((Rectangle)(ref viewport)).Y;
		Farmer playerOrEventFarmer = getPlayerOrEventFarmer();
		if (currentLocation == null)
		{
			return;
		}
		if (!viewportFreeze || overrideFreeze)
		{
			Rectangle val = (Rectangle)((viewportClampArea == Rectangle.Empty) ? new Rectangle(0, 0, currentLocation.Map.DisplayWidth, currentLocation.Map.DisplayHeight) : viewportClampArea);
			Point standingPixel = playerOrEventFarmer.StandingPixel;
			bool flag = forceSnapOnNextViewportUpdate || Math.Abs(currentViewportTarget.X + (float)(((Rectangle)(ref viewport)).Width / 2) + (float)val.X - (float)standingPixel.X) > 64f || Math.Abs(currentViewportTarget.Y + (float)(((Rectangle)(ref viewport)).Height / 2) + (float)val.Y - (float)standingPixel.Y) > 64f;
			if (centerPoint.X >= val.X + ((Rectangle)(ref viewport)).Width / 2 && centerPoint.X <= val.X + val.Width - ((Rectangle)(ref viewport)).Width / 2)
			{
				if (playerOrEventFarmer.isRafting || flag)
				{
					currentViewportTarget.X = centerPoint.X - ((Rectangle)(ref viewport)).Width / 2;
				}
				else if (Math.Abs(currentViewportTarget.X - (currentViewportTarget.X = centerPoint.X - ((Rectangle)(ref viewport)).Width / 2 + val.X)) > playerOrEventFarmer.getMovementSpeed())
				{
					currentViewportTarget.X += (float)Math.Sign(currentViewportTarget.X - (currentViewportTarget.X = centerPoint.X - ((Rectangle)(ref viewport)).Width / 2 + val.X)) * playerOrEventFarmer.getMovementSpeed();
				}
			}
			else if (centerPoint.X < ((Rectangle)(ref viewport)).Width / 2 + val.X && ((Rectangle)(ref viewport)).Width <= val.Width)
			{
				if (playerOrEventFarmer.isRafting || flag)
				{
					currentViewportTarget.X = val.X;
				}
				else if (Math.Abs(currentViewportTarget.X - (float)val.X) > playerOrEventFarmer.getMovementSpeed())
				{
					currentViewportTarget.X -= (float)Math.Sign(currentViewportTarget.X - (float)val.X) * playerOrEventFarmer.getMovementSpeed();
				}
			}
			else if (((Rectangle)(ref viewport)).Width <= val.Width)
			{
				if (playerOrEventFarmer.isRafting || flag)
				{
					currentViewportTarget.X = val.X + val.Width - ((Rectangle)(ref viewport)).Width;
				}
				else if (!(Math.Abs(currentViewportTarget.X - (float)(val.Width - ((Rectangle)(ref viewport)).Width)) > playerOrEventFarmer.getMovementSpeed()))
				{
				}
			}
			else if (val.Width < ((Rectangle)(ref viewport)).Width)
			{
				if (playerOrEventFarmer.isRafting || flag)
				{
					currentViewportTarget.X = (val.Width - ((Rectangle)(ref viewport)).Width) / 2 + val.X;
				}
				else
				{
					Math.Abs(currentViewportTarget.X - (float)((val.Width + val.X - ((Rectangle)(ref viewport)).Width) / 2));
					playerOrEventFarmer.getMovementSpeed();
				}
			}
			if (centerPoint.Y >= ((Rectangle)(ref viewport)).Height / 2 && centerPoint.Y <= currentLocation.Map.DisplayHeight - ((Rectangle)(ref viewport)).Height / 2)
			{
				if (playerOrEventFarmer.isRafting || flag)
				{
					currentViewportTarget.Y = centerPoint.Y - ((Rectangle)(ref viewport)).Height / 2;
				}
				else if (Math.Abs(currentViewportTarget.Y - (float)(centerPoint.Y - ((Rectangle)(ref viewport)).Height / 2)) >= playerOrEventFarmer.getMovementSpeed())
				{
					currentViewportTarget.Y -= (float)Math.Sign(currentViewportTarget.Y - (float)(centerPoint.Y - ((Rectangle)(ref viewport)).Height / 2)) * playerOrEventFarmer.getMovementSpeed();
				}
			}
			else if (centerPoint.Y < ((Rectangle)(ref viewport)).Height / 2 && ((Rectangle)(ref viewport)).Height <= currentLocation.Map.DisplayHeight)
			{
				if (playerOrEventFarmer.isRafting || flag)
				{
					currentViewportTarget.Y = 0f;
				}
				else if (Math.Abs(currentViewportTarget.Y - 0f) > playerOrEventFarmer.getMovementSpeed())
				{
					currentViewportTarget.Y -= (float)Math.Sign(currentViewportTarget.Y - 0f) * playerOrEventFarmer.getMovementSpeed();
				}
				currentViewportTarget.Y = 0f;
			}
			else if (((Rectangle)(ref viewport)).Height <= currentLocation.Map.DisplayHeight)
			{
				if (playerOrEventFarmer.isRafting || flag)
				{
					currentViewportTarget.Y = currentLocation.Map.DisplayHeight - ((Rectangle)(ref viewport)).Height;
				}
				else if (Math.Abs(currentViewportTarget.Y - (float)(currentLocation.Map.DisplayHeight - ((Rectangle)(ref viewport)).Height)) > playerOrEventFarmer.getMovementSpeed())
				{
					currentViewportTarget.Y -= (float)Math.Sign(currentViewportTarget.Y - (float)(currentLocation.Map.DisplayHeight - ((Rectangle)(ref viewport)).Height)) * playerOrEventFarmer.getMovementSpeed();
				}
			}
			else if (currentLocation.Map.DisplayHeight < ((Rectangle)(ref viewport)).Height)
			{
				if (playerOrEventFarmer.isRafting || flag)
				{
					currentViewportTarget.Y = (currentLocation.Map.DisplayHeight - ((Rectangle)(ref viewport)).Height) / 2;
				}
				else if (Math.Abs(currentViewportTarget.Y - (float)((currentLocation.Map.DisplayHeight - ((Rectangle)(ref viewport)).Height) / 2)) > playerOrEventFarmer.getMovementSpeed())
				{
					currentViewportTarget.Y -= (float)Math.Sign(currentViewportTarget.Y - (float)((currentLocation.Map.DisplayHeight - ((Rectangle)(ref viewport)).Height) / 2)) * playerOrEventFarmer.getMovementSpeed();
				}
			}
		}
		if (currentLocation.forceViewportPlayerFollow)
		{
			currentViewportTarget.X = playerOrEventFarmer.Position.X - (float)(((Rectangle)(ref viewport)).Width / 2);
			currentViewportTarget.Y = playerOrEventFarmer.Position.Y - (float)(((Rectangle)(ref viewport)).Height / 2);
		}
		bool flag2 = forceSnapOnNextViewportUpdate;
		forceSnapOnNextViewportUpdate = false;
		if (currentViewportTarget.X != -2.1474836E+09f && (!viewportFreeze || overrideFreeze))
		{
			int num = (int)(currentViewportTarget.X - (float)((Rectangle)(ref viewport)).X);
			if (Math.Abs(num) > 128)
			{
				viewportPositionLerp.X = currentViewportTarget.X;
			}
			else
			{
				viewportPositionLerp.X += (float)num * playerOrEventFarmer.getMovementSpeed() * 0.03f;
			}
			num = (int)(currentViewportTarget.Y - (float)((Rectangle)(ref viewport)).Y);
			if (Math.Abs(num) > 128)
			{
				viewportPositionLerp.Y = (int)currentViewportTarget.Y;
			}
			else
			{
				viewportPositionLerp.Y += (float)num * playerOrEventFarmer.getMovementSpeed() * 0.03f;
			}
			if (flag2)
			{
				viewportPositionLerp.X = (int)currentViewportTarget.X;
				viewportPositionLerp.Y = (int)currentViewportTarget.Y;
			}
			((Rectangle)(ref viewport)).X = (int)viewportPositionLerp.X;
			((Rectangle)(ref viewport)).Y = (int)viewportPositionLerp.Y;
		}
	}

	private void UpdateCharacters(GameTime time)
	{
		if (CurrentEvent?.farmer != null && CurrentEvent.farmer != player)
		{
			CurrentEvent.farmer.Update(time, currentLocation);
		}
		player.Update(time, currentLocation);
		foreach (KeyValuePair<long, Farmer> otherFarmer in otherFarmers)
		{
			if (otherFarmer.Key != player.UniqueMultiplayerID)
			{
				otherFarmer.Value.UpdateIfOtherPlayer(time);
			}
		}
	}

	public static void addMail(string mailName, bool noLetter = false, bool sendToEveryone = false)
	{
		if (sendToEveryone)
		{
			multiplayer.broadcastPartyWideMail(mailName, Multiplayer.PartyWideMessageQueue.SeenMail, noLetter);
			return;
		}
		mailName = mailName.Trim();
		mailName = mailName.Replace(Environment.NewLine, "");
		if (!player.hasOrWillReceiveMail(mailName))
		{
			if (noLetter)
			{
				player.mailReceived.Add(mailName);
			}
			else
			{
				player.mailbox.Add(mailName);
			}
		}
	}

	public static void addMailForTomorrow(string mailName, bool noLetter = false, bool sendToEveryone = false)
	{
		if (sendToEveryone)
		{
			multiplayer.broadcastPartyWideMail(mailName, Multiplayer.PartyWideMessageQueue.MailForTomorrow, noLetter);
			return;
		}
		mailName = mailName.Trim();
		mailName = mailName.Replace(Environment.NewLine, "");
		if (player.hasOrWillReceiveMail(mailName))
		{
			return;
		}
		if (noLetter)
		{
			mailName += "%&NL&%";
		}
		player.mailForTomorrow.Add(mailName);
		if (!sendToEveryone || !IsMultiplayer)
		{
			return;
		}
		foreach (Farmer value in otherFarmers.Values)
		{
			if (value != player && !player.hasOrWillReceiveMail(mailName))
			{
				value.mailForTomorrow.Add(mailName);
			}
		}
	}

	public static void drawDialogue(NPC speaker)
	{
		if (speaker.CurrentDialogue.Count == 0)
		{
			return;
		}
		activeClickableMenu = new DialogueBox(speaker.CurrentDialogue.Peek());
		if (activeClickableMenu is DialogueBox { dialogueFinished: not false })
		{
			activeClickableMenu = null;
			return;
		}
		dialogueUp = true;
		if (!eventUp)
		{
			player.Halt();
			player.CanMove = false;
		}
		if (speaker != null)
		{
			currentSpeaker = speaker;
		}
	}

	public static void multipleDialogues(string[] messages)
	{
		activeClickableMenu = new DialogueBox(messages.ToList());
		dialogueUp = true;
		player.CanMove = false;
	}

	public static void drawDialogueNoTyping(string dialogue)
	{
		drawObjectDialogue(dialogue);
		if (activeClickableMenu is DialogueBox dialogueBox)
		{
			dialogueBox.showTyping = false;
		}
	}

	public static void drawDialogueNoTyping(List<string> dialogues)
	{
		drawObjectDialogue(dialogues);
		if (activeClickableMenu is DialogueBox dialogueBox)
		{
			dialogueBox.showTyping = false;
		}
	}

	public static void DrawAnsweringMachineDialogue(NPC npc, string translationKey, params object[] substitutions)
	{
		Dialogue dialogue = Dialogue.FromTranslation(npc, translationKey, substitutions);
		dialogue.overridePortrait = temporaryContent.Load<Texture2D>("Portraits\\AnsweringMachine");
		DrawDialogue(dialogue);
	}

	public static void DrawDialogue(NPC npc, string translationKey)
	{
		DrawDialogue(new Dialogue(npc, translationKey));
	}

	public static void DrawDialogue(NPC npc, string translationKey, params object[] substitutions)
	{
		DrawDialogue(Dialogue.FromTranslation(npc, translationKey, substitutions));
	}

	public static void DrawDialogue(Dialogue dialogue)
	{
		if (dialogue.speaker != null)
		{
			dialogue.speaker.CurrentDialogue.Push(dialogue);
			drawDialogue(dialogue.speaker);
			return;
		}
		activeClickableMenu = new DialogueBox(dialogue);
		dialogueUp = true;
		if (!eventUp)
		{
			player.Halt();
			player.CanMove = false;
		}
	}

	private static void checkIfDialogueIsQuestion()
	{
		if (currentSpeaker != null && currentSpeaker.CurrentDialogue.Count > 0 && currentSpeaker.CurrentDialogue.Peek().isCurrentDialogueAQuestion())
		{
			questionChoices.Clear();
			isQuestion = true;
			List<NPCDialogueResponse> nPCResponseOptions = currentSpeaker.CurrentDialogue.Peek().getNPCResponseOptions();
			for (int i = 0; i < nPCResponseOptions.Count; i++)
			{
				questionChoices.Add(nPCResponseOptions[i]);
			}
		}
	}

	public static void drawLetterMessage(string message)
	{
		activeClickableMenu = new LetterViewerMenu(message);
	}

	public static void drawObjectDialogue(string dialogue)
	{
		activeClickableMenu?.emergencyShutDown();
		activeClickableMenu = new DialogueBox(dialogue);
		player.CanMove = false;
		dialogueUp = true;
	}

	public static void drawObjectDialogue(List<string> dialogue)
	{
		activeClickableMenu?.emergencyShutDown();
		activeClickableMenu = new DialogueBox(dialogue);
		player.CanMove = false;
		dialogueUp = true;
	}

	public static void drawObjectQuestionDialogue(string dialogue, Response[] choices, int width)
	{
		activeClickableMenu = new DialogueBox(dialogue, choices, width);
		dialogueUp = true;
		player.CanMove = false;
	}

	public static void drawObjectQuestionDialogue(string dialogue, Response[] choices)
	{
		activeClickableMenu = new DialogueBox(dialogue, choices);
		dialogueUp = true;
		player.CanMove = false;
	}

	public static void warpCharacter(NPC character, string targetLocationName, Point position)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		Game1.warpCharacter(character, targetLocationName, new Vector2((float)position.X, (float)position.Y));
	}

	public static void warpCharacter(NPC character, string targetLocationName, Vector2 position)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		warpCharacter(character, RequireLocation(targetLocationName), position);
	}

	public static void warpCharacter(NPC character, GameLocation targetLocation, Vector2 position)
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		foreach (string activePassiveFestival in netWorldState.Value.ActivePassiveFestivals)
		{
			if (Utility.TryGetPassiveFestivalData(activePassiveFestival, out var data) && dayOfMonth >= data.StartDay && dayOfMonth <= data.EndDay && data.Season == season && data.MapReplacements != null && data.MapReplacements.TryGetValue(targetLocation.name.Value, out var value))
			{
				targetLocation = RequireLocation(value);
			}
		}
		if (targetLocation.name.Equals("Trailer") && MasterPlayer.mailReceived.Contains("pamHouseUpgrade"))
		{
			targetLocation = RequireLocation("Trailer_Big");
			if (position.X == 12f && position.Y == 9f)
			{
				position.X = 13f;
				position.Y = 24f;
			}
		}
		if (IsClient)
		{
			multiplayer.requestCharacterWarp(character, targetLocation, position);
			return;
		}
		if (!targetLocation.characters.Contains(character))
		{
			character.currentLocation?.characters.Remove(character);
			targetLocation.addCharacter(character);
		}
		character.isCharging = false;
		character.speed = 2;
		character.blockedInterval = 0;
		NPC.getTextureNameForCharacter(character.Name);
		character.position.X = position.X * 64f;
		character.position.Y = position.Y * 64f;
		if (character.CurrentDialogue.Count > 0 && character.CurrentDialogue.Peek().removeOnNextMove && character.Tile != character.DefaultPosition / 64f)
		{
			character.CurrentDialogue.Pop();
		}
		if (targetLocation is FarmHouse farmHouse)
		{
			character.arriveAtFarmHouse(farmHouse);
		}
		else
		{
			character.arriveAt(targetLocation);
		}
		if (character.currentLocation != null && !character.currentLocation.Equals(targetLocation))
		{
			character.currentLocation.characters.Remove(character);
		}
		character.currentLocation = targetLocation;
	}

	public static LocationRequest getLocationRequest(string locationName, bool isStructure = false)
	{
		if (locationName == null)
		{
			throw new ArgumentException();
		}
		return new LocationRequest(locationName, isStructure, getLocationFromName(locationName, isStructure));
	}

	public static void warpHome()
	{
		LocationRequest obj = getLocationRequest(player.homeLocation.Value);
		obj.OnWarp += delegate
		{
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			player.position.Set(Utility.PointToVector2((currentLocation as FarmHouse).GetPlayerBedSpot()) * 64f);
		};
		warpFarmer(obj, 5, 9, player.FacingDirection);
	}

	public static void warpFarmer(string locationName, int tileX, int tileY, bool flip)
	{
		warpFarmer(getLocationRequest(locationName), tileX, tileY, flip ? ((player.FacingDirection + 2) % 4) : player.FacingDirection);
	}

	public static void warpFarmer(string locationName, int tileX, int tileY, int facingDirectionAfterWarp)
	{
		warpFarmer(getLocationRequest(locationName), tileX, tileY, facingDirectionAfterWarp);
	}

	public static void warpFarmer(string locationName, int tileX, int tileY, int facingDirectionAfterWarp, bool isStructure)
	{
		warpFarmer(getLocationRequest(locationName, isStructure), tileX, tileY, facingDirectionAfterWarp);
	}

	public virtual bool ShouldDismountOnWarp(Horse mount, GameLocation old_location, GameLocation new_location)
	{
		if (mount == null)
		{
			return false;
		}
		if (currentLocation != null && currentLocation.IsOutdoors && new_location != null)
		{
			return !new_location.IsOutdoors;
		}
		return false;
	}

	public static void warpFarmer(LocationRequest locationRequest, int tileX, int tileY, int facingDirectionAfterWarp)
	{
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		//IL_034a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0590: Unknown result type (might be due to invalid IL or missing references)
		int warp_offset_x = nextFarmerWarpOffsetX;
		int warp_offset_y = nextFarmerWarpOffsetY;
		nextFarmerWarpOffsetX = 0;
		nextFarmerWarpOffsetY = 0;
		foreach (string activePassiveFestival in netWorldState.Value.ActivePassiveFestivals)
		{
			if (Utility.TryGetPassiveFestivalData(activePassiveFestival, out var data) && dayOfMonth >= data.StartDay && dayOfMonth <= data.EndDay && data.Season == season && data.MapReplacements != null && data.MapReplacements.TryGetValue(locationRequest.Name, out var value))
			{
				locationRequest = getLocationRequest(value);
			}
		}
		switch (locationRequest.Name)
		{
		case "BusStop":
			if (tileX < 10)
			{
				tileX = 10;
			}
			break;
		case "Farm":
			switch (currentLocation?.NameOrUniqueName)
			{
			case "FarmCave":
			{
				if (tileX != 34 || tileY != 6)
				{
					break;
				}
				if (getFarm().TryGetMapPropertyAs("FarmCaveEntry", out Point parsed3, required: false))
				{
					tileX = parsed3.X;
					tileY = parsed3.Y;
					break;
				}
				switch (whichFarm)
				{
				case 6:
					tileX = 34;
					tileY = 16;
					break;
				case 5:
					tileX = 30;
					tileY = 36;
					break;
				}
				break;
			}
			case "Forest":
			{
				if (tileX != 41 || tileY != 64)
				{
					break;
				}
				if (getFarm().TryGetMapPropertyAs("ForestEntry", out Point parsed4, required: false))
				{
					tileX = parsed4.X;
					tileY = parsed4.Y;
					break;
				}
				switch (whichFarm)
				{
				case 6:
					tileX = 82;
					tileY = 103;
					break;
				case 5:
					tileX = 40;
					tileY = 64;
					break;
				}
				break;
			}
			case "BusStop":
			{
				if (tileX == 79 && tileY == 17 && getFarm().TryGetMapPropertyAs("BusStopEntry", out Point parsed2, required: false))
				{
					tileX = parsed2.X;
					tileY = parsed2.Y;
				}
				break;
			}
			case "Backwoods":
			{
				if (tileX == 40 && tileY == 0 && getFarm().TryGetMapPropertyAs("BackwoodsEntry", out Point parsed, required: false))
				{
					tileX = parsed.X;
					tileY = parsed.Y;
				}
				break;
			}
			}
			break;
		case "IslandSouth":
			if (tileX <= 15 && tileY <= 6)
			{
				tileX = 21;
				tileY = 43;
			}
			break;
		case "Trailer":
			if (MasterPlayer.mailReceived.Contains("pamHouseUpgrade"))
			{
				locationRequest = getLocationRequest("Trailer_Big");
				tileX = 13;
				tileY = 24;
			}
			break;
		case "Club":
			if (player.hasClubCard)
			{
				break;
			}
			locationRequest = getLocationRequest("SandyHouse");
			locationRequest.OnWarp += delegate
			{
				//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
				//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
				//IL_0118: Unknown result type (might be due to invalid IL or missing references)
				//IL_0125: Unknown result type (might be due to invalid IL or missing references)
				//IL_012b: Unknown result type (might be due to invalid IL or missing references)
				//IL_013a: Unknown result type (might be due to invalid IL or missing references)
				//IL_0144: Unknown result type (might be due to invalid IL or missing references)
				//IL_0149: Unknown result type (might be due to invalid IL or missing references)
				//IL_015a: Unknown result type (might be due to invalid IL or missing references)
				//IL_0194: Unknown result type (might be due to invalid IL or missing references)
				//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
				//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
				//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
				//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
				//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
				//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
				//IL_0218: Unknown result type (might be due to invalid IL or missing references)
				//IL_0225: Unknown result type (might be due to invalid IL or missing references)
				//IL_022b: Unknown result type (might be due to invalid IL or missing references)
				//IL_023a: Unknown result type (might be due to invalid IL or missing references)
				//IL_0244: Unknown result type (might be due to invalid IL or missing references)
				//IL_0249: Unknown result type (might be due to invalid IL or missing references)
				//IL_025a: Unknown result type (might be due to invalid IL or missing references)
				NPC characterFromName = currentLocation.getCharacterFromName("Bouncer");
				if (characterFromName != null)
				{
					Vector2 val = default(Vector2);
					((Vector2)(ref val))._002Ector(17f, 4f);
					characterFromName.showTextAboveHead(content.LoadString("Strings\\Locations:Club_Bouncer_TextAboveHead" + (random.Next(2) + 1)));
					int num = random.Next();
					currentLocation.playSound("thudStep");
					multiplayer.broadcastSprites(currentLocation, new TemporaryAnimatedSprite(288, 100f, 1, 24, val * 64f, flicker: true, flipped: false, currentLocation, player)
					{
						shakeIntensity = 0.5f,
						shakeIntensityChange = 0.002f,
						extraInfoForEndBehavior = num,
						endFunction = currentLocation.removeTemporarySpritesWithID
					}, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(598, 1279, 3, 4), 53f, 5, 9, val * 64f + new Vector2(5f, 0f) * 4f, flicker: true, flipped: false, 0.0263f, 0f, Color.Yellow, 4f, 0f, 0f, 0f)
					{
						id = num
					}, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(598, 1279, 3, 4), 53f, 5, 9, val * 64f + new Vector2(5f, 0f) * 4f, flicker: true, flipped: true, 0.0263f, 0f, Color.Orange, 4f, 0f, 0f, 0f)
					{
						delayBeforeAnimationStart = 100,
						id = num
					}, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(598, 1279, 3, 4), 53f, 5, 9, val * 64f + new Vector2(5f, 0f) * 4f, flicker: true, flipped: false, 0.0263f, 0f, Color.White, 3f, 0f, 0f, 0f)
					{
						delayBeforeAnimationStart = 200,
						id = num
					});
					currentLocation.netAudio.StartPlaying("fuse");
				}
			};
			tileX = 17;
			tileY = 4;
			break;
		}
		if (VolcanoDungeon.IsGeneratedLevel(locationRequest.Name))
		{
			warp_offset_x = 0;
			warp_offset_y = 0;
		}
		if (player.isRidingHorse() && currentLocation != null)
		{
			GameLocation gameLocation = locationRequest.Location;
			if (gameLocation == null)
			{
				gameLocation = getLocationFromName(locationRequest.Name);
			}
			if (game1.ShouldDismountOnWarp(player.mount, currentLocation, gameLocation))
			{
				player.mount.dismount();
				warp_offset_x = 0;
				warp_offset_y = 0;
			}
		}
		if (weatherIcon == 1 && whereIsTodaysFest != null && locationRequest.Name.Equals(whereIsTodaysFest) && !warpingForForcedRemoteEvent)
		{
			string[] array = ArgUtility.SplitBySpace(temporaryContent.Load<Dictionary<string, string>>("Data\\Festivals\\" + currentSeason + dayOfMonth)["conditions"].Split('/')[1]);
			if (timeOfDay <= Convert.ToInt32(array[1]))
			{
				if (timeOfDay < Convert.ToInt32(array[0]))
				{
					if (!(currentLocation?.Name == "Hospital"))
					{
						player.Position = player.lastPosition;
						drawObjectDialogue(content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.2973"));
						return;
					}
					locationRequest = getLocationRequest("BusStop");
					tileX = 34;
					tileY = 23;
				}
				else
				{
					if (IsMultiplayer)
					{
						netReady.SetLocalReady("festivalStart", ready: true);
						activeClickableMenu = new ReadyCheckDialog("festivalStart", allowCancel: true, delegate
						{
							exitActiveMenu();
							if (player.mount != null)
							{
								player.mount.dismount();
								warp_offset_x = 0;
								warp_offset_y = 0;
							}
							performWarpFarmer(locationRequest, tileX, tileY, facingDirectionAfterWarp);
						});
						return;
					}
					if (player.mount != null)
					{
						player.mount.dismount();
						warp_offset_x = 0;
						warp_offset_y = 0;
					}
				}
			}
		}
		tileX += warp_offset_x;
		tileY += warp_offset_y;
		performWarpFarmer(locationRequest, tileX, tileY, facingDirectionAfterWarp);
	}

	private static void performWarpFarmer(LocationRequest locationRequest, int tileX, int tileY, int facingDirectionAfterWarp)
	{
		if (locationRequest.Location != null)
		{
			if (tileX >= locationRequest.Location.Map.Layers[0].LayerWidth - 1)
			{
				tileX--;
			}
			if (IsMasterGame)
			{
				locationRequest.Location.hostSetup();
			}
		}
		log.Verbose("Warping to " + locationRequest.Name);
		if (player.IsSitting())
		{
			player.StopSitting(animate: false);
		}
		if (player.UsingTool)
		{
			player.completelyStopAnimatingOrDoingAction();
		}
		player.previousLocationName = ((player.currentLocation != null) ? player.currentLocation.name.Value : "");
		Game1.locationRequest = locationRequest;
		xLocationAfterWarp = tileX;
		yLocationAfterWarp = tileY;
		_isWarping = true;
		Game1.facingDirectionAfterWarp = facingDirectionAfterWarp;
		fadeScreenToBlack();
		setRichPresence("location", locationRequest.Name);
		if (IsDedicatedHost)
		{
			fadeToBlackAlpha = 1.1f;
			fadeToBlack = true;
			nonWarpFade = false;
		}
	}

	private static void notifyServerOfWarp(bool needsLocationInfo)
	{
		if (locationRequest != null)
		{
			byte b = (byte)((locationRequest.IsStructure ? 1u : 0u) | (uint)(warpingForForcedRemoteEvent ? 2 : 0) | (uint)(needsLocationInfo ? 4 : 0));
			b = facingDirectionAfterWarp switch
			{
				1 => (byte)(b | 0x10), 
				2 => (byte)(b | 0x20), 
				3 => (byte)(b | 0x40), 
				_ => (byte)(b | 8), 
			};
			client.sendMessage(5, (short)xLocationAfterWarp, (short)yLocationAfterWarp, locationRequest.Name, b);
		}
	}

	public static void requestLocationInfoFromServer()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		notifyServerOfWarp(needsLocationInfo: true);
		currentLocation = null;
		player.Position = new Vector2((float)(xLocationAfterWarp * 64), (float)(yLocationAfterWarp * 64 - (player.Sprite.getHeight() - 32) + 16));
		player.faceDirection(facingDirectionAfterWarp);
	}

	public static T GetCharacterWhere<T>(Func<T, bool> check, bool includeEventActors = false) where T : NPC
	{
		T match = null;
		T fallback = null;
		Utility.ForEachCharacter(delegate(NPC rawNpc)
		{
			if (rawNpc is T val && check(val))
			{
				if (val.currentLocation?.IsActiveLocation() ?? false)
				{
					match = val;
					return false;
				}
				fallback = val;
			}
			return true;
		}, includeEventActors);
		return match ?? fallback;
	}

	public static T GetCharacterOfType<T>(bool includeEventActors = false) where T : NPC
	{
		T match = null;
		T fallback = null;
		Utility.ForEachCharacter(delegate(NPC rawNpc)
		{
			if (rawNpc is T val)
			{
				if (rawNpc.currentLocation?.IsActiveLocation() ?? false)
				{
					match = val;
					return false;
				}
				fallback = val;
			}
			return true;
		}, includeEventActors);
		return match ?? fallback;
	}

	public static T getCharacterFromName<T>(string name, bool mustBeVillager = true, bool includeEventActors = false) where T : NPC
	{
		T match = null;
		T fallback = null;
		Utility.ForEachCharacter(delegate(NPC rawNpc)
		{
			if (rawNpc is T val && val.Name == name && (!mustBeVillager || val.IsVillager))
			{
				if (val.currentLocation?.IsActiveLocation() ?? false)
				{
					match = val;
					return false;
				}
				fallback = val;
			}
			return true;
		}, includeEventActors);
		return match ?? fallback;
	}

	public static NPC getCharacterFromName(string name, bool mustBeVillager = true, bool includeEventActors = false)
	{
		NPC match = null;
		NPC fallback = null;
		Utility.ForEachCharacter(delegate(NPC npc)
		{
			if (npc.Name == name && (!mustBeVillager || npc.IsVillager))
			{
				if (npc.currentLocation?.IsActiveLocation() ?? false)
				{
					match = npc;
					return false;
				}
				fallback = npc;
			}
			return true;
		}, includeEventActors);
		return match ?? fallback;
	}

	public static NPC RequireCharacter(string name, bool mustBeVillager = true)
	{
		return getCharacterFromName(name, mustBeVillager) ?? throw new KeyNotFoundException($"Required {(mustBeVillager ? "villager" : "NPC")} '{name}' not found.");
	}

	public static T RequireCharacter<T>(string name, bool mustBeVillager = true) where T : NPC
	{
		NPC characterFromName = getCharacterFromName(name, mustBeVillager);
		if (!(characterFromName is T result))
		{
			if (characterFromName == null)
			{
				throw new KeyNotFoundException($"Required {(mustBeVillager ? "villager" : "NPC")} '{name}' not found.");
			}
			throw new InvalidCastException($"Can't convert NPC '{name}' from '{characterFromName?.GetType().FullName}' to the required '{typeof(T).FullName}'.");
		}
		return result;
	}

	public static GameLocation RequireLocation(string name, bool isStructure = false)
	{
		return getLocationFromName(name, isStructure) ?? throw new KeyNotFoundException($"Required {(isStructure ? "structure " : "")}location '{name}' not found.");
	}

	public static TLocation RequireLocation<TLocation>(string name, bool isStructure = false) where TLocation : GameLocation
	{
		GameLocation locationFromName = getLocationFromName(name, isStructure);
		if (!(locationFromName is TLocation result))
		{
			if (locationFromName == null)
			{
				throw new KeyNotFoundException($"Required {(isStructure ? "structure " : "")}location '{name}' not found.");
			}
			throw new InvalidCastException($"Can't convert location {name} from '{locationFromName?.GetType().FullName}' to the required '{typeof(TLocation).FullName}'.");
		}
		return result;
	}

	public static GameLocation getLocationFromName(string name)
	{
		return getLocationFromName(name, isStructure: false);
	}

	public static GameLocation getLocationFromName(string name, bool isStructure)
	{
		if (string.IsNullOrEmpty(name))
		{
			return null;
		}
		if (currentLocation != null)
		{
			if (!isStructure)
			{
				if (currentLocation.name.Value.EqualsIgnoreCase(name))
				{
					return currentLocation;
				}
				if (currentLocation.isStructure.Value && currentLocation.Root != null && currentLocation.Root.Value.NameOrUniqueName.EqualsIgnoreCase(name))
				{
					return currentLocation.Root.Value;
				}
			}
			else if (currentLocation.NameOrUniqueName == name)
			{
				return currentLocation;
			}
		}
		if (_locationLookup.TryGetValue(name, out var value))
		{
			return value;
		}
		return getLocationFromNameInLocationsList(name, isStructure);
	}

	public static GameLocation getLocationFromNameInLocationsList(string name, bool isStructure = false)
	{
		for (int i = 0; i < locations.Count; i++)
		{
			GameLocation gameLocation = locations[i];
			if (!isStructure)
			{
				if (gameLocation.Name.EqualsIgnoreCase(name))
				{
					_locationLookup[gameLocation.Name] = gameLocation;
					return gameLocation;
				}
				continue;
			}
			GameLocation gameLocation2 = findStructure(gameLocation, name);
			if (gameLocation2 != null)
			{
				_locationLookup[name] = gameLocation2;
				return gameLocation2;
			}
		}
		if (MineShaft.IsGeneratedLevel(name))
		{
			return MineShaft.GetMine(name);
		}
		if (VolcanoDungeon.IsGeneratedLevel(name))
		{
			return VolcanoDungeon.GetLevel(name);
		}
		if (!isStructure)
		{
			return getLocationFromName(name, isStructure: true);
		}
		return null;
	}

	public static void flushLocationLookup()
	{
		_locationLookup.Clear();
	}

	public static void removeLocationFromLocationLookup(string nameOrUniqueName)
	{
		_locationLookup.RemoveWhere((KeyValuePair<string, GameLocation> p) => p.Value.NameOrUniqueName == nameOrUniqueName);
	}

	public static void removeLocationFromLocationLookup(GameLocation location)
	{
		_locationLookup.RemoveWhere((KeyValuePair<string, GameLocation> p) => p.Value == location);
	}

	public static GameLocation findStructure(GameLocation parentLocation, string name)
	{
		foreach (Building building in parentLocation.buildings)
		{
			if (building.HasIndoorsName(name))
			{
				return building.GetIndoors();
			}
		}
		return null;
	}

	public static void addNewFarmBuildingMaps()
	{
		FarmHouse homeOfFarmer = Utility.getHomeOfFarmer(player);
		if (player.HouseUpgradeLevel >= 1 && ((Component)homeOfFarmer.Map).Id.Equals("FarmHouse"))
		{
			homeOfFarmer.updateMap();
		}
	}

	public static void PassOutNewDay()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		player.lastSleepLocation.Value = currentLocation.NameOrUniqueName;
		player.lastSleepPoint.Value = player.TilePoint;
		if (!IsMultiplayer)
		{
			NewDay(0f);
			return;
		}
		player.FarmerSprite.setCurrentSingleFrame(5, 3000);
		player.FarmerSprite.PauseForSingleAnimation = true;
		player.passedOut = true;
		if (activeClickableMenu != null)
		{
			activeClickableMenu.emergencyShutDown();
			exitActiveMenu();
		}
		activeClickableMenu = new ReadyCheckDialog("sleep", allowCancel: false, delegate
		{
			NewDay(0f);
		});
	}

	public static void NewDay(float timeToPause)
	{
		if (activeClickableMenu is ReadyCheckDialog { checkName: "sleep" } readyCheckDialog && !readyCheckDialog.isCancelable())
		{
			readyCheckDialog.confirm();
		}
		currentMinigame = null;
		newDay = true;
		newDaySync.create();
		if (player.isInBed.Value || player.passedOut)
		{
			nonWarpFade = true;
			screenFade.FadeScreenToBlack(player.passedOut ? 1.1f : 0f);
			player.Halt();
			player.currentEyes = 1;
			player.blinkTimer = -4000;
			player.CanMove = false;
			player.passedOut = false;
			pauseTime = timeToPause;
		}
		if (activeClickableMenu != null && !dialogueUp)
		{
			activeClickableMenu.emergencyShutDown();
			exitActiveMenu();
		}
	}

	public static void screenGlowOnce(Color glowColor, bool hold, float rate = 0.005f, float maxAlpha = 0.3f)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		screenGlowMax = maxAlpha;
		screenGlowRate = rate;
		screenGlowAlpha = 0f;
		screenGlowUp = true;
		screenGlowColor = glowColor;
		screenGlow = true;
		screenGlowHold = hold;
	}

	public static string shortDayNameFromDayOfSeason(int dayOfSeason)
	{
		return (dayOfSeason % 7) switch
		{
			0 => "Sun", 
			1 => "Mon", 
			2 => "Tue", 
			3 => "Wed", 
			4 => "Thu", 
			5 => "Fri", 
			6 => "Sat", 
			_ => "", 
		};
	}

	public static string shortDayDisplayNameFromDayOfSeason(int dayOfSeason)
	{
		if (dayOfSeason < 0)
		{
			return string.Empty;
		}
		return _shortDayDisplayName[dayOfSeason % 7];
	}

	public static void runTestEvent()
	{
		StreamReader streamReader = new StreamReader("test_event.txt");
		string? locationName = streamReader.ReadLine();
		string event_string = streamReader.ReadToEnd();
		event_string = event_string.Replace("\r\n", "/").Replace("\n", "/");
		log.Verbose("Running test event: " + event_string);
		LocationRequest locationRequest = getLocationRequest(locationName);
		locationRequest.OnWarp += delegate
		{
			currentLocation.currentEvent = new Event(event_string);
			currentLocation.checkForEvents();
		};
		int x = 8;
		int y = 8;
		Utility.getDefaultWarpLocation(locationName, ref x, ref y);
		warpFarmer(locationRequest, x, y, player.FacingDirection);
	}

	public static bool isMusicContextActiveButNotPlaying(MusicContext music_context = (MusicContext)0)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if (_activeMusicContext != music_context)
		{
			return false;
		}
		if (morningSongPlayAction != null)
		{
			return false;
		}
		string musicTrackName = getMusicTrackName(music_context);
		if (musicTrackName == "none")
		{
			return true;
		}
		if (currentSong != null && currentSong.Name == musicTrackName && !currentSong.IsPlaying)
		{
			return true;
		}
		return false;
	}

	public static bool IsMusicContextActive(MusicContext music_context = (MusicContext)0)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		if (_activeMusicContext != music_context)
		{
			return true;
		}
		return false;
	}

	public static bool doesMusicContextHaveTrack(MusicContext music_context = (MusicContext)0)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		return _requestedMusicTracks.ContainsKey(music_context);
	}

	public static string getMusicTrackName(MusicContext music_context = (MusicContext)0)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		if (_requestedMusicTracks.TryGetValue(music_context, out var value))
		{
			return value.Key;
		}
		if ((int)music_context == 0)
		{
			return getMusicTrackName((MusicContext)1);
		}
		return "none";
	}

	public static void stopMusicTrack(MusicContext music_context)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		if (_requestedMusicTracks.Remove(music_context))
		{
			if ((int)music_context == 0)
			{
				stopMusicTrack((MusicContext)1);
			}
			UpdateRequestedMusicTrack();
		}
	}

	public static void changeMusicTrack(string newTrackName, bool track_interruptable = false, MusicContext music_context = (MusicContext)0)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Invalid comparison between Unknown and I4
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Invalid comparison between Unknown and I4
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		if (newTrackName == null)
		{
			return;
		}
		if ((int)music_context == 0)
		{
			if (morningSongPlayAction != null)
			{
				if (delayedActions.Contains(morningSongPlayAction))
				{
					delayedActions.Remove(morningSongPlayAction);
				}
				morningSongPlayAction = null;
			}
			if (IsGreenRainingHere() && !currentLocation.InIslandContext() && IsRainingHere(currentLocation) && !newTrackName.Equals("rain"))
			{
				return;
			}
		}
		if ((int)music_context == 0 || (int)music_context == 1)
		{
			IsPlayingBackgroundMusic = false;
			IsPlayingOutdoorsAmbience = false;
			IsPlayingNightAmbience = false;
			IsPlayingTownMusic = false;
			IsPlayingMorningSong = false;
		}
		if ((int)music_context != 5 && !player.songsHeard.Contains(newTrackName))
		{
			Utility.farmerHeardSong(newTrackName);
		}
		_requestedMusicTracks[music_context] = new KeyValuePair<string, bool>(newTrackName, track_interruptable);
		UpdateRequestedMusicTrack();
	}

	public static void UpdateRequestedMusicTrack()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Invalid comparison between Unknown and I4
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		_activeMusicContext = (MusicContext)0;
		KeyValuePair<string, bool> keyValuePair = new KeyValuePair<string, bool>("none", value: true);
		for (int i = 0; i < 6; i++)
		{
			MusicContext val = (MusicContext)i;
			if (_requestedMusicTracks.TryGetValue(val, out var value))
			{
				if ((int)val != 5)
				{
					_activeMusicContext = val;
				}
				keyValuePair = value;
			}
		}
		if (keyValuePair.Key != requestedMusicTrack || keyValuePair.Value != requestedMusicTrackOverrideable)
		{
			requestedMusicDirty = true;
			requestedMusicTrack = keyValuePair.Key;
			requestedMusicTrackOverrideable = keyValuePair.Value;
		}
	}

	public static void enterMine(int whatLevel, int? forceLayout = null)
	{
		warpFarmer(MineShaft.GetLevelName(whatLevel, forceLayout), 6, 6, 2);
		player.temporarilyInvincible = true;
		player.temporaryInvincibilityTimer = 0;
		player.flashDuringThisTemporaryInvincibility = false;
		player.currentTemporaryInvincibilityDuration = 1000;
	}

	public static Season GetSeasonForLocation(GameLocation location)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		return location?.GetSeason() ?? season;
	}

	public static int GetSeasonIndexForLocation(GameLocation location)
	{
		return location?.GetSeasonIndex() ?? seasonIndex;
	}

	public static string GetSeasonKeyForLocation(GameLocation location)
	{
		return location?.GetSeasonKey() ?? currentSeason;
	}

	public static void getPlatformAchievement(string which)
	{
		Program.sdk.GetAchievement(which);
	}

	public static void getSteamAchievement(string which)
	{
		if (which.Equals("0"))
		{
			which = "a0";
		}
		getPlatformAchievement(which);
	}

	public static void getAchievement(int which, bool allowBroadcasting = true)
	{
		if (player.achievements.Contains(which) || gameMode != 3 || !achievements.TryGetValue(which, out var value))
		{
			return;
		}
		string achievementName = value.Split('^')[0];
		player.achievements.Add(which);
		if (which < 32 && allowBroadcasting)
		{
			if (stats.isSharedAchievement(which))
			{
				multiplayer.sendSharedAchievementMessage(which);
			}
			else
			{
				string text = player.Name;
				if (text == "")
				{
					text = TokenStringBuilder.LocalizedText("Strings\\UI:Chat_PlayerJoinedNewName");
				}
				multiplayer.globalChatInfoMessage("Achievement", text, TokenStringBuilder.AchievementName(which));
			}
		}
		playSound("achievement");
		addHUDMessage(HUDMessage.ForAchievement(achievementName));
		player.autoGenerateActiveDialogueEvent("achievement_" + which);
		getPlatformAchievement(which.ToString());
		if (!player.hasOrWillReceiveMail("hatter"))
		{
			addMailForTomorrow("hatter");
		}
	}

	public static void createMultipleObjectDebris(string id, int xTile, int yTile, int number)
	{
		for (int i = 0; i < number; i++)
		{
			createObjectDebris(id, xTile, yTile);
		}
	}

	public static void createMultipleObjectDebris(string id, int xTile, int yTile, int number, GameLocation location)
	{
		for (int i = 0; i < number; i++)
		{
			createObjectDebris(id, xTile, yTile, -1, 0, 1f, location);
		}
	}

	public static void createMultipleObjectDebris(string id, int xTile, int yTile, int number, float velocityMultiplier)
	{
		for (int i = 0; i < number; i++)
		{
			createObjectDebris(id, xTile, yTile, -1, 0, velocityMultiplier);
		}
	}

	public static void createMultipleObjectDebris(string id, int xTile, int yTile, int number, long who)
	{
		for (int i = 0; i < number; i++)
		{
			createObjectDebris(id, xTile, yTile, who);
		}
	}

	public static void createMultipleObjectDebris(string id, int xTile, int yTile, int number, long who, GameLocation location)
	{
		for (int i = 0; i < number; i++)
		{
			createObjectDebris(id, xTile, yTile, who, location);
		}
	}

	public static void createDebris(int debrisType, int xTile, int yTile, int numberOfChunks)
	{
		createDebris(debrisType, xTile, yTile, numberOfChunks, currentLocation);
	}

	public static void createDebris(int debrisType, int xTile, int yTile, int numberOfChunks, GameLocation location)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		if (location == null)
		{
			location = currentLocation;
		}
		location.debris.Add(new Debris(debrisType, numberOfChunks, new Vector2((float)(xTile * 64 + 32), (float)(yTile * 64 + 32)), player.getStandingPosition()));
	}

	public static Debris createItemDebris(Item item, Vector2 pixelOrigin, int direction, GameLocation location = null, int groundLevel = -1, bool flopFish = false)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		if (location == null)
		{
			location = currentLocation;
		}
		Vector2 standingPosition = default(Vector2);
		((Vector2)(ref standingPosition))._002Ector(pixelOrigin.X, pixelOrigin.Y);
		switch (direction)
		{
		case 0:
			pixelOrigin.Y -= 16f + (float)recentMultiplayerRandom.Next(32);
			standingPosition.Y -= 35.2f;
			break;
		case 1:
			pixelOrigin.X += 16f;
			pixelOrigin.Y -= 32 - recentMultiplayerRandom.Next(8);
			standingPosition.X += 128f;
			break;
		case 2:
			pixelOrigin.Y += recentMultiplayerRandom.Next(16);
			standingPosition.Y += 64f;
			break;
		case 3:
			pixelOrigin.X -= 16f;
			pixelOrigin.Y -= 32 - recentMultiplayerRandom.Next(8);
			standingPosition.X -= 128f;
			break;
		case -1:
			standingPosition = player.getStandingPosition();
			break;
		}
		Debris debris = new Debris(item, pixelOrigin, standingPosition);
		if (flopFish && item.Category == -4)
		{
			debris.floppingFish.Value = true;
		}
		if (groundLevel != -1)
		{
			debris.chunkFinalYLevel = groundLevel;
		}
		location.debris.Add(debris);
		return debris;
	}

	public static void createMultipleItemDebris(Item item, Vector2 pixelOrigin, int direction, GameLocation location = null, int groundLevel = -1, bool flopFish = false)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		int stack = item.Stack;
		item.Stack = 1;
		createItemDebris(item, pixelOrigin, (direction == -1) ? random.Next(4) : direction, location, groundLevel, flopFish);
		for (int i = 1; i < stack; i++)
		{
			createItemDebris(item.getOne(), pixelOrigin, (direction == -1) ? random.Next(4) : direction, location, groundLevel, flopFish);
		}
	}

	public static void createRadialDebris(GameLocation location, int debrisType, int xTile, int yTile, int numberOfChunks, bool resource, int groundLevel = -1, bool item = false, Color? color = null)
	{
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		if (groundLevel == -1)
		{
			groundLevel = yTile * 64 + 32;
		}
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(xTile * 64 + 64), (float)(yTile * 64 + 64));
		if (item)
		{
			Vector2 val2 = default(Vector2);
			while (numberOfChunks > 0)
			{
				switch (random.Next(4))
				{
				case 0:
					((Vector2)(ref val2))._002Ector(-64f, 0f);
					break;
				case 1:
					((Vector2)(ref val2))._002Ector(64f, 0f);
					break;
				case 2:
					((Vector2)(ref val2))._002Ector(0f, 64f);
					break;
				default:
					((Vector2)(ref val2))._002Ector(0f, -64f);
					break;
				}
				Item item2 = ItemRegistry.Create("(O)" + debrisType);
				location.debris.Add(new Debris(item2, val, val + val2));
				numberOfChunks--;
			}
		}
		if (resource)
		{
			location.debris.Add(new Debris(debrisType, numberOfChunks / 4, val, val + new Vector2(-64f, 0f)));
			numberOfChunks++;
			location.debris.Add(new Debris(debrisType, numberOfChunks / 4, val, val + new Vector2(64f, 0f)));
			numberOfChunks++;
			location.debris.Add(new Debris(debrisType, numberOfChunks / 4, val, val + new Vector2(0f, -64f)));
			numberOfChunks++;
			location.debris.Add(new Debris(debrisType, numberOfChunks / 4, val, val + new Vector2(0f, 64f)));
		}
		else
		{
			location.debris.Add(new Debris(debrisType, numberOfChunks / 4, val, val + new Vector2(-64f, 0f), groundLevel, color));
			numberOfChunks++;
			location.debris.Add(new Debris(debrisType, numberOfChunks / 4, val, val + new Vector2(64f, 0f), groundLevel, color));
			numberOfChunks++;
			location.debris.Add(new Debris(debrisType, numberOfChunks / 4, val, val + new Vector2(0f, -64f), groundLevel, color));
			numberOfChunks++;
			location.debris.Add(new Debris(debrisType, numberOfChunks / 4, val, val + new Vector2(0f, 64f), groundLevel, color));
		}
	}

	public static void createRadialDebris(GameLocation location, string texture, Rectangle sourcerectangle, int xTile, int yTile, int numberOfChunks)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		createRadialDebris(location, texture, sourcerectangle, xTile, yTile, numberOfChunks, yTile);
	}

	public static void createRadialDebris(GameLocation location, string texture, Rectangle sourcerectangle, int xTile, int yTile, int numberOfChunks, int groundLevelTile)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		createRadialDebris(location, texture, sourcerectangle, 8, xTile * 64 + 32 + random.Next(32), yTile * 64 + 32 + random.Next(32), numberOfChunks, groundLevelTile);
	}

	public static void createRadialDebris(GameLocation location, string texture, Rectangle sourcerectangle, int sizeOfSourceRectSquares, int xPosition, int yPosition, int numberOfChunks, int groundLevelTile)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)xPosition, (float)yPosition);
		location.debris.Add(new Debris(texture, sourcerectangle, numberOfChunks / 4, val, val + new Vector2(-64f, 0f), groundLevelTile * 64, sizeOfSourceRectSquares));
		location.debris.Add(new Debris(texture, sourcerectangle, numberOfChunks / 4, val, val + new Vector2(64f, 0f), groundLevelTile * 64, sizeOfSourceRectSquares));
		location.debris.Add(new Debris(texture, sourcerectangle, numberOfChunks / 4, val, val + new Vector2(0f, -64f), groundLevelTile * 64, sizeOfSourceRectSquares));
		location.debris.Add(new Debris(texture, sourcerectangle, numberOfChunks / 4, val, val + new Vector2(0f, 64f), groundLevelTile * 64, sizeOfSourceRectSquares));
	}

	public static void createRadialDebris_MoreNatural(GameLocation location, string texture, Rectangle sourcerectangle, int sizeOfSourceRectSquares, int xPosition, int yPosition, int numberOfChunks, int groundLevel)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)xPosition, (float)yPosition);
		for (int i = 0; i < numberOfChunks; i++)
		{
			location.debris.Add(new Debris(texture, sourcerectangle, numberOfChunks / 4, val, val + new Vector2((float)random.Next(-64, 64), (float)random.Next(-64, 64)), groundLevel + random.Next(-32, 32), sizeOfSourceRectSquares));
		}
	}

	public static void createRadialDebris(GameLocation location, string texture, Rectangle sourcerectangle, int sizeOfSourceRectSquares, int xPosition, int yPosition, int numberOfChunks, int groundLevelTile, Color color)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		createRadialDebris(location, texture, sourcerectangle, sizeOfSourceRectSquares, xPosition, yPosition, numberOfChunks, groundLevelTile, color, 1f);
	}

	public static void createRadialDebris(GameLocation location, string texture, Rectangle sourcerectangle, int sizeOfSourceRectSquares, int xPosition, int yPosition, int numberOfChunks, int groundLevelTile, Color color, float scale)
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)xPosition, (float)yPosition);
		while (numberOfChunks > 0)
		{
			switch (random.Next(4))
			{
			case 0:
			{
				Debris debris = new Debris(texture, sourcerectangle, 1, val, val + new Vector2(-64f, 0f), groundLevelTile * 64, sizeOfSourceRectSquares);
				debris.nonSpriteChunkColor.Value = color;
				location?.debris.Add(debris);
				debris.Chunks[0].scale = scale;
				break;
			}
			case 1:
			{
				Debris debris = new Debris(texture, sourcerectangle, 1, val, val + new Vector2(64f, 0f), groundLevelTile * 64, sizeOfSourceRectSquares);
				debris.nonSpriteChunkColor.Value = color;
				location?.debris.Add(debris);
				debris.Chunks[0].scale = scale;
				break;
			}
			case 2:
			{
				Debris debris = new Debris(texture, sourcerectangle, 1, val, val + new Vector2((float)random.Next(-64, 64), -64f), groundLevelTile * 64, sizeOfSourceRectSquares);
				debris.nonSpriteChunkColor.Value = color;
				location?.debris.Add(debris);
				debris.Chunks[0].scale = scale;
				break;
			}
			case 3:
			{
				Debris debris = new Debris(texture, sourcerectangle, 1, val, val + new Vector2((float)random.Next(-64, 64), 64f), groundLevelTile * 64, sizeOfSourceRectSquares);
				debris.nonSpriteChunkColor.Value = color;
				location?.debris.Add(debris);
				debris.Chunks[0].scale = scale;
				break;
			}
			}
			numberOfChunks--;
		}
	}

	public static void createObjectDebris(string id, int xTile, int yTile, long whichPlayer)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		Farmer farmer = GetPlayer(whichPlayer) ?? player;
		currentLocation.debris.Add(new Debris(id, new Vector2((float)(xTile * 64 + 32), (float)(yTile * 64 + 32)), farmer.getStandingPosition()));
	}

	public static void createObjectDebris(string id, int xTile, int yTile, long whichPlayer, GameLocation location)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		Farmer farmer = GetPlayer(whichPlayer) ?? player;
		location.debris.Add(new Debris(id, new Vector2((float)(xTile * 64 + 32), (float)(yTile * 64 + 32)), farmer.getStandingPosition()));
	}

	public static void createObjectDebris(string id, int xTile, int yTile, GameLocation location)
	{
		createObjectDebris(id, xTile, yTile, -1, 0, 1f, location);
	}

	public static void createObjectDebris(string id, int xTile, int yTile, int groundLevel = -1, int itemQuality = 0, float velocityMultiplyer = 1f, GameLocation location = null)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if (location == null)
		{
			location = currentLocation;
		}
		Debris debris = new Debris(id, new Vector2((float)(xTile * 64 + 32), (float)(yTile * 64 + 32)), player.getStandingPosition())
		{
			itemQuality = itemQuality
		};
		foreach (Chunk chunk in debris.Chunks)
		{
			chunk.xVelocity.Value *= velocityMultiplyer;
			chunk.yVelocity.Value *= velocityMultiplyer;
		}
		if (groundLevel != -1)
		{
			debris.chunkFinalYLevel = groundLevel;
		}
		location.debris.Add(debris);
	}

	[Obsolete("Use GetPlayer instead. Equivalent usage: `GetPlayer(id, onlineOnly: true) ?? Game1.MasterPlayer`.")]
	public static Farmer getFarmer(long id)
	{
		return GetPlayer(id, onlyOnline: true) ?? MasterPlayer;
	}

	[Obsolete("Use GetPlayer instead.")]
	public static Farmer getFarmerMaybeOffline(long id)
	{
		return GetPlayer(id);
	}

	public static Farmer? GetPlayer(long id, bool onlyOnline = false)
	{
		if (MasterPlayer.UniqueMultiplayerID == id)
		{
			return MasterPlayer;
		}
		if (otherFarmers.TryGetValue(id, out var value))
		{
			return value;
		}
		if (!onlyOnline && netWorldState.Value.farmhandData.TryGetValue(id, out var value2))
		{
			return value2;
		}
		return null;
	}

	public static IEnumerable<Farmer> getAllFarmers()
	{
		return Enumerable.Repeat(MasterPlayer, 1).Concat(getAllFarmhands());
	}

	public static FarmerCollection getOnlineFarmers()
	{
		return _onlineFarmers;
	}

	public static IEnumerable<Farmer> getAllFarmhands()
	{
		foreach (Farmer value in netWorldState.Value.farmhandData.Values)
		{
			if (value.isActive())
			{
				yield return otherFarmers[value.UniqueMultiplayerID];
			}
			else
			{
				yield return value;
			}
		}
	}

	public static IEnumerable<Farmer> getOfflineFarmhands()
	{
		foreach (Farmer value in netWorldState.Value.farmhandData.Values)
		{
			if (!value.isActive())
			{
				yield return value;
			}
		}
	}

	public static void farmerFindsArtifact(string itemId)
	{
		Item item = ItemRegistry.Create(itemId);
		player.addItemToInventoryBool(item);
	}

	public static bool doesHUDMessageExist(string s)
	{
		for (int i = 0; i < hudMessages.Count; i++)
		{
			if (s.Equals(hudMessages[i].message))
			{
				return true;
			}
		}
		return false;
	}

	public static void addHUDMessage(HUDMessage message)
	{
		if (message.type != null || message.whatType != 0)
		{
			for (int i = 0; i < hudMessages.Count; i++)
			{
				if (message.type != null && message.type == hudMessages[i].type)
				{
					hudMessages[i].number = hudMessages[i].number + message.number;
					hudMessages[i].timeLeft = 3500f;
					hudMessages[i].transparency = 1f;
					if (hudMessages[i].number > 50000)
					{
						HUDMessage.numbersEasterEgg(hudMessages[i].number);
					}
					return;
				}
				if (message.whatType == hudMessages[i].whatType && message.whatType != 1 && message.message != null && message.message.Equals(hudMessages[i].message))
				{
					hudMessages[i].timeLeft = message.timeLeft;
					hudMessages[i].transparency = 1f;
					return;
				}
			}
		}
		hudMessages.Add(message);
		for (int num = hudMessages.Count - 1; num >= 0; num--)
		{
			if (hudMessages[num].noIcon)
			{
				HUDMessage item = hudMessages[num];
				hudMessages.RemoveAt(num);
				hudMessages.Add(item);
			}
		}
	}

	public static void showSwordswipeAnimation(int direction, Vector2 source, float animationSpeed, bool flip)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		switch (direction)
		{
		case 0:
			currentLocation.TemporarySprites.Add(new TemporaryAnimatedSprite(-1, animationSpeed, 5, 1, new Vector2(source.X + 32f, source.Y), flicker: false, flipped: false, !flip, -(float)Math.PI / 2f));
			break;
		case 1:
			currentLocation.TemporarySprites.Add(new TemporaryAnimatedSprite(-1, animationSpeed, 5, 1, new Vector2(source.X + 96f + 16f, source.Y + 48f), flicker: false, flip, verticalFlipped: false, flip ? (-(float)Math.PI) : 0f));
			break;
		case 2:
			currentLocation.TemporarySprites.Add(new TemporaryAnimatedSprite(-1, animationSpeed, 5, 1, new Vector2(source.X + 32f, source.Y + 128f), flicker: false, flipped: false, !flip, (float)Math.PI / 2f));
			break;
		case 3:
			currentLocation.TemporarySprites.Add(new TemporaryAnimatedSprite(-1, animationSpeed, 5, 1, new Vector2(source.X - 32f - 16f, source.Y + 48f), flicker: false, !flip, verticalFlipped: false, flip ? (-(float)Math.PI) : 0f));
			break;
		}
	}

	public static void removeDebris(Debris.DebrisType type)
	{
		currentLocation.debris.RemoveWhere((Debris debris) => debris.debrisType.Value == type);
	}

	public static void toolAnimationDone(Farmer who)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		float stamina = player.Stamina;
		if (who.CurrentTool == null)
		{
			return;
		}
		if (who.Stamina > 0f)
		{
			int power = 1;
			Vector2 toolLocation = who.GetToolLocation();
			if (who.CurrentTool is FishingRod { isFishing: not false })
			{
				who.canReleaseTool = false;
			}
			else if (!(who.CurrentTool is FishingRod))
			{
				who.UsingTool = false;
				if (who.CurrentTool.QualifiedItemId == "(T)WateringCan")
				{
					switch (who.FacingDirection)
					{
					case 0:
					case 2:
						who.CurrentTool.DoFunction(currentLocation, (int)toolLocation.X, (int)toolLocation.Y, power, who);
						break;
					case 1:
					case 3:
						who.CurrentTool.DoFunction(currentLocation, (int)toolLocation.X, (int)toolLocation.Y, power, who);
						break;
					}
				}
				else if (who.CurrentTool is MeleeWeapon)
				{
					who.CurrentTool.CurrentParentTileIndex = who.CurrentTool.IndexOfMenuItemView;
				}
				else
				{
					if (who.CurrentTool.QualifiedItemId == "(T)ReturnScepter")
					{
						who.CurrentTool.CurrentParentTileIndex = who.CurrentTool.IndexOfMenuItemView;
					}
					who.CurrentTool.DoFunction(currentLocation, (int)toolLocation.X, (int)toolLocation.Y, power, who);
				}
			}
			else
			{
				who.UsingTool = false;
			}
		}
		else if (who.CurrentTool.instantUse.Value)
		{
			who.CurrentTool.DoFunction(currentLocation, 0, 0, 0, who);
		}
		else
		{
			who.UsingTool = false;
		}
		who.lastClick = Vector2.Zero;
		if (who.IsLocalPlayer)
		{
			KeyboardState keyboardState = GetKeyboardState();
			if (!((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)160))
			{
				who.setRunning(options.autoRun);
			}
		}
		if (!who.UsingTool && who.FarmerSprite.PauseForSingleAnimation)
		{
			who.FarmerSprite.StopAnimation();
		}
		if (player.Stamina <= 0f && stamina > 0f)
		{
			player.doEmote(36);
		}
	}

	public static bool pressActionButton(KeyboardState currentKBState, MouseState currentMouseState, GamePadState currentPadState)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_051b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0525: Unknown result type (might be due to invalid IL or missing references)
		//IL_052a: Unknown result type (might be due to invalid IL or missing references)
		//IL_052c: Unknown result type (might be due to invalid IL or missing references)
		//IL_052e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0405: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_0410: Unknown result type (might be due to invalid IL or missing references)
		//IL_0415: Unknown result type (might be due to invalid IL or missing references)
		//IL_041a: Unknown result type (might be due to invalid IL or missing references)
		//IL_041b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_056d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0546: Unknown result type (might be due to invalid IL or missing references)
		//IL_054e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0586: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c04: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c05: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c0f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c14: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c1a: Unknown result type (might be due to invalid IL or missing references)
		//IL_05df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0631: Unknown result type (might be due to invalid IL or missing references)
		//IL_0632: Unknown result type (might be due to invalid IL or missing references)
		//IL_063c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0641: Unknown result type (might be due to invalid IL or missing references)
		//IL_0646: Unknown result type (might be due to invalid IL or missing references)
		//IL_0647: Unknown result type (might be due to invalid IL or missing references)
		//IL_0676: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07be: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06be: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0856: Unknown result type (might be due to invalid IL or missing references)
		//IL_0857: Unknown result type (might be due to invalid IL or missing references)
		//IL_0861: Unknown result type (might be due to invalid IL or missing references)
		//IL_0866: Unknown result type (might be due to invalid IL or missing references)
		//IL_086b: Unknown result type (might be due to invalid IL or missing references)
		//IL_086c: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0720: Unknown result type (might be due to invalid IL or missing references)
		//IL_0728: Unknown result type (might be due to invalid IL or missing references)
		//IL_0962: Unknown result type (might be due to invalid IL or missing references)
		//IL_0967: Unknown result type (might be due to invalid IL or missing references)
		//IL_0969: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0801: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0940: Unknown result type (might be due to invalid IL or missing references)
		//IL_0941: Unknown result type (might be due to invalid IL or missing references)
		//IL_094b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0950: Unknown result type (might be due to invalid IL or missing references)
		//IL_0955: Unknown result type (might be due to invalid IL or missing references)
		//IL_0956: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_080f: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_09bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bdc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bdd: Unknown result type (might be due to invalid IL or missing references)
		if (IsChatting)
		{
			currentKBState = default(KeyboardState);
		}
		if (dialogueTyping)
		{
			bool flag = true;
			dialogueTyping = false;
			if (currentSpeaker != null)
			{
				currentDialogueCharacterIndex = currentSpeaker.CurrentDialogue.Peek().getCurrentDialogue().Length;
			}
			else if (currentObjectDialogue.Count > 0)
			{
				currentDialogueCharacterIndex = currentObjectDialogue.Peek().Length;
			}
			else
			{
				flag = false;
			}
			dialogueTypingInterval = 0;
			oldKBState = currentKBState;
			oldMouseState = input.GetMouseState();
			oldPadState = currentPadState;
			if (flag)
			{
				playSound("dialogueCharacterClose");
				return false;
			}
		}
		if (dialogueUp)
		{
			if (isQuestion)
			{
				isQuestion = false;
				if (currentSpeaker != null)
				{
					if (currentSpeaker.CurrentDialogue.Peek().chooseResponse(questionChoices[currentQuestionChoice]))
					{
						currentDialogueCharacterIndex = 1;
						dialogueTyping = true;
						oldKBState = currentKBState;
						oldMouseState = input.GetMouseState();
						oldPadState = currentPadState;
						return false;
					}
				}
				else
				{
					dialogueUp = false;
					if (eventUp && currentLocation.afterQuestion == null)
					{
						currentLocation.currentEvent.answerDialogue(currentLocation.lastQuestionKey, currentQuestionChoice);
						currentQuestionChoice = 0;
						oldKBState = currentKBState;
						oldMouseState = input.GetMouseState();
						oldPadState = currentPadState;
					}
					else if (currentLocation.answerDialogue(questionChoices[currentQuestionChoice]))
					{
						currentQuestionChoice = 0;
						oldKBState = currentKBState;
						oldMouseState = input.GetMouseState();
						oldPadState = currentPadState;
						return false;
					}
					if (dialogueUp)
					{
						currentDialogueCharacterIndex = 1;
						dialogueTyping = true;
						oldKBState = currentKBState;
						oldMouseState = input.GetMouseState();
						oldPadState = currentPadState;
						return false;
					}
				}
				currentQuestionChoice = 0;
			}
			string text = null;
			if (currentSpeaker != null)
			{
				if (currentSpeaker.immediateSpeak)
				{
					currentSpeaker.immediateSpeak = false;
					return false;
				}
				text = ((currentSpeaker.CurrentDialogue.Count > 0) ? currentSpeaker.CurrentDialogue.Peek().exitCurrentDialogue() : null);
			}
			if (text == null)
			{
				if (currentSpeaker != null && currentSpeaker.CurrentDialogue.Count > 0 && currentSpeaker.CurrentDialogue.Peek().isOnFinalDialogue() && currentSpeaker.CurrentDialogue.Count > 0)
				{
					currentSpeaker.CurrentDialogue.Pop();
				}
				dialogueUp = false;
				if (messagePause)
				{
					pauseTime = 500f;
				}
				if (currentObjectDialogue.Count > 0)
				{
					currentObjectDialogue.Dequeue();
				}
				currentDialogueCharacterIndex = 0;
				if (currentObjectDialogue.Count > 0)
				{
					dialogueUp = true;
					questionChoices.Clear();
					oldKBState = currentKBState;
					oldMouseState = input.GetMouseState();
					oldPadState = currentPadState;
					dialogueTyping = true;
					return false;
				}
				if (currentSpeaker != null && !currentSpeaker.Name.Equals("Gunther") && !eventUp && !currentSpeaker.doingEndOfRouteAnimation.Value)
				{
					currentSpeaker.doneFacingPlayer(player);
				}
				currentSpeaker = null;
				if (!eventUp)
				{
					player.CanMove = true;
				}
				else if (currentLocation.currentEvent.CurrentCommand > 0 || currentLocation.currentEvent.specialEventVariable1)
				{
					if (!isFestival() || !currentLocation.currentEvent.canMoveAfterDialogue())
					{
						currentLocation.currentEvent.CurrentCommand++;
					}
					else
					{
						player.CanMove = true;
					}
				}
				questionChoices.Clear();
				playSound("smallSelect");
			}
			else
			{
				playSound("smallSelect");
				currentDialogueCharacterIndex = 0;
				dialogueTyping = true;
				checkIfDialogueIsQuestion();
			}
			oldKBState = currentKBState;
			oldMouseState = input.GetMouseState();
			oldPadState = currentPadState;
			return false;
		}
		if (!player.UsingTool && (!eventUp || (currentLocation.currentEvent != null && currentLocation.currentEvent.playerControlSequence)) && !fadeToBlack)
		{
			if (wasMouseVisibleThisFrame && currentLocation.animals.Length > 0)
			{
				Vector2 val = default(Vector2);
				((Vector2)(ref val))._002Ector((float)(getOldMouseX() + ((Rectangle)(ref viewport)).X), (float)(getOldMouseY() + ((Rectangle)(ref viewport)).Y));
				if (Utility.withinRadiusOfPlayer((int)val.X, (int)val.Y, 1, player))
				{
					if (currentLocation.CheckPetAnimal(val, player))
					{
						return true;
					}
					if (didPlayerJustRightClick(ignoreNonMouseHeldInput: true) && currentLocation.CheckInspectAnimal(val, player))
					{
						return true;
					}
				}
			}
			Vector2 val2 = new Vector2((float)(getOldMouseX() + ((Rectangle)(ref viewport)).X), (float)(getOldMouseY() + ((Rectangle)(ref viewport)).Y)) / 64f;
			Vector2 val3 = val2;
			bool flag2 = false;
			if (!wasMouseVisibleThisFrame || mouseCursorTransparency == 0f || !Utility.tileWithinRadiusOfPlayer((int)val2.X, (int)val2.Y, 1, player))
			{
				val2 = player.GetGrabTile();
				flag2 = true;
			}
			bool flag3 = false;
			if (eventUp && !isFestival())
			{
				CurrentEvent?.receiveActionPress((int)val2.X, (int)val2.Y);
				oldKBState = currentKBState;
				oldMouseState = input.GetMouseState();
				oldPadState = currentPadState;
				return false;
			}
			if (tryToCheckAt(val2, player))
			{
				return false;
			}
			if (player.isRidingHorse())
			{
				player.mount.checkAction(player, player.currentLocation);
				return false;
			}
			if (!player.canMove)
			{
				return false;
			}
			if (!flag3 && player.currentLocation.isCharacterAtTile(val2) != null)
			{
				flag3 = true;
			}
			bool flag4 = false;
			if (player.ActiveObject != null && !(player.ActiveObject is Furniture))
			{
				if (player.ActiveObject.performUseAction(currentLocation))
				{
					player.reduceActiveItemByOne();
					oldKBState = currentKBState;
					oldMouseState = input.GetMouseState();
					oldPadState = currentPadState;
					return false;
				}
				int stack = player.ActiveObject.Stack;
				isCheckingNonMousePlacement = !IsPerformingMousePlacement();
				if (flag2)
				{
					isCheckingNonMousePlacement = true;
				}
				if (isOneOfTheseKeysDown(currentKBState, options.actionButton))
				{
					isCheckingNonMousePlacement = true;
				}
				Vector2 nearbyValidPlacementPosition = Utility.GetNearbyValidPlacementPosition(player, currentLocation, player.ActiveObject, (int)val2.X * 64 + 32, (int)val2.Y * 64 + 32);
				if (!isCheckingNonMousePlacement && player.ActiveObject is Wallpaper && Utility.tryToPlaceItem(currentLocation, player.ActiveObject, (int)val3.X * 64, (int)val3.Y * 64))
				{
					isCheckingNonMousePlacement = false;
					return true;
				}
				if (Utility.tryToPlaceItem(currentLocation, player.ActiveObject, (int)nearbyValidPlacementPosition.X, (int)nearbyValidPlacementPosition.Y))
				{
					isCheckingNonMousePlacement = false;
					return true;
				}
				if (!eventUp && (player.ActiveObject == null || player.ActiveObject.Stack < stack || player.ActiveObject.isPlaceable()))
				{
					flag4 = true;
				}
				isCheckingNonMousePlacement = false;
			}
			if (!flag4 && !flag3)
			{
				val2.Y += 1f;
				if (player.FacingDirection >= 0 && player.FacingDirection <= 3)
				{
					Vector2 val4 = val2 - player.Tile;
					if (val4.X > 0f || val4.Y > 0f)
					{
						((Vector2)(ref val4)).Normalize();
					}
					if (Vector2.Dot(Utility.DirectionsTileVectors[player.FacingDirection], val4) >= 0f && tryToCheckAt(val2, player))
					{
						return false;
					}
				}
				if (!eventUp && player.ActiveObject is Furniture furniture)
				{
					furniture.rotate();
					playSound("dwoop");
					oldKBState = currentKBState;
					oldMouseState = input.GetMouseState();
					oldPadState = currentPadState;
					return false;
				}
				val2.Y -= 2f;
				if (player.FacingDirection >= 0 && player.FacingDirection <= 3 && !flag3)
				{
					Vector2 val5 = val2 - player.Tile;
					if (val5.X > 0f || val5.Y > 0f)
					{
						((Vector2)(ref val5)).Normalize();
					}
					if (Vector2.Dot(Utility.DirectionsTileVectors[player.FacingDirection], val5) >= 0f && tryToCheckAt(val2, player))
					{
						return false;
					}
				}
				if (!eventUp && player.ActiveObject is Furniture furniture2)
				{
					furniture2.rotate();
					playSound("dwoop");
					oldKBState = currentKBState;
					oldMouseState = input.GetMouseState();
					oldPadState = currentPadState;
					return false;
				}
				val2 = player.Tile;
				if (tryToCheckAt(val2, player))
				{
					return false;
				}
				if (!eventUp && player.ActiveObject is Furniture furniture3)
				{
					furniture3.rotate();
					playSound("dwoop");
					oldKBState = currentKBState;
					oldMouseState = input.GetMouseState();
					oldPadState = currentPadState;
					return false;
				}
			}
			if (!player.isEating && player.ActiveObject != null && !dialogueUp && !eventUp && !player.canOnlyWalk && !player.FarmerSprite.PauseForSingleAnimation && !fadeToBlack && player.ActiveObject.Edibility != -300 && didPlayerJustRightClick(ignoreNonMouseHeldInput: true))
			{
				if (player.team.SpecialOrderRuleActive("SC_NO_FOOD"))
				{
					MineShaft obj = player.currentLocation as MineShaft;
					if (obj != null && obj.getMineArea() == 121)
					{
						addHUDMessage(new HUDMessage(content.LoadString("Strings\\StringsFromCSFiles:Object.cs.13053"), 3));
						return false;
					}
				}
				if (player.hasBuff("25") && player.ActiveObject != null && !player.ActiveObject.HasContextTag("ginger_item"))
				{
					addHUDMessage(new HUDMessage(content.LoadString("Strings\\StringsFromCSFiles:Nauseous_CantEat"), 3));
					return false;
				}
				player.faceDirection(2);
				player.itemToEat = player.ActiveObject;
				player.FarmerSprite.setCurrentSingleAnimation(304);
				if (objectData.TryGetValue(player.ActiveObject.ItemId, out var value))
				{
					currentLocation.createQuestionDialogue((value.IsDrink && player.ActiveObject.preserve.Value != Object.PreserveType.Pickle) ? content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3159", player.ActiveObject.DisplayName) : content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3160", player.ActiveObject.DisplayName), currentLocation.createYesNoResponses(), "Eat");
				}
				oldKBState = currentKBState;
				oldMouseState = input.GetMouseState();
				oldPadState = currentPadState;
				return false;
			}
		}
		if (player.CurrentTool is MeleeWeapon && player.CanMove && !player.canOnlyWalk && !eventUp && !player.onBridge.Value && didPlayerJustRightClick(ignoreNonMouseHeldInput: true))
		{
			((MeleeWeapon)player.CurrentTool).animateSpecialMove(player);
			return false;
		}
		return true;
	}

	public static bool IsPerformingMousePlacement()
	{
		if (mouseCursorTransparency == 0f || !wasMouseVisibleThisFrame || (!lastCursorMotionWasMouse && (player.ActiveObject == null || (!player.ActiveObject.isPlaceable() && player.ActiveObject.Category != -74 && !player.ActiveObject.isSapling()))))
		{
			return false;
		}
		return true;
	}

	public static Vector2 GetPlacementGrabTile()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		if (!IsPerformingMousePlacement())
		{
			return player.GetGrabTile();
		}
		return new Vector2((float)(getOldMouseX() + ((Rectangle)(ref viewport)).X), (float)(getOldMouseY() + ((Rectangle)(ref viewport)).Y)) / 64f;
	}

	public static bool tryToCheckAt(Vector2 grabTile, Farmer who)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		if (player.onBridge.Value)
		{
			return false;
		}
		haltAfterCheck = true;
		if (Utility.tileWithinRadiusOfPlayer((int)grabTile.X, (int)grabTile.Y, 1, player) && hooks.OnGameLocation_CheckAction(currentLocation, new Location((int)grabTile.X, (int)grabTile.Y), viewport, who, () => currentLocation.checkAction(new Location((int)grabTile.X, (int)grabTile.Y), viewport, who)))
		{
			updateCursorTileHint();
			who.lastGrabTile = grabTile;
			if (who.CanMove && haltAfterCheck)
			{
				who.faceGeneralDirection(grabTile * 64f);
				who.Halt();
			}
			oldKBState = GetKeyboardState();
			oldMouseState = input.GetMouseState();
			oldPadState = input.GetGamePadState();
			return true;
		}
		return false;
	}

	public static void pressSwitchToolButton()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		if (player.netItemStowed.Value)
		{
			player.netItemStowed.Set(newValue: false);
			player.UpdateItemStow();
		}
		MouseState mouseState = input.GetMouseState();
		int num;
		if (((MouseState)(ref mouseState)).ScrollWheelValue <= ((MouseState)(ref oldMouseState)).ScrollWheelValue)
		{
			mouseState = input.GetMouseState();
			num = ((((MouseState)(ref mouseState)).ScrollWheelValue < ((MouseState)(ref oldMouseState)).ScrollWheelValue) ? 1 : 0);
		}
		else
		{
			num = -1;
		}
		int num2 = num;
		if (options.gamepadControls && num2 == 0)
		{
			GamePadState gamePadState = input.GetGamePadState();
			if (((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)8388608))
			{
				num2 = -1;
			}
			else
			{
				gamePadState = input.GetGamePadState();
				if (((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4194304))
				{
					num2 = 1;
				}
			}
		}
		if (options.invertScrollDirection)
		{
			num2 *= -1;
		}
		if (num2 == 0)
		{
			return;
		}
		player.CurrentToolIndex = (player.CurrentToolIndex + num2) % 12;
		if (player.CurrentToolIndex < 0)
		{
			player.CurrentToolIndex = 11;
		}
		for (int i = 0; i < 12; i++)
		{
			if (player.CurrentItem != null)
			{
				break;
			}
			player.CurrentToolIndex = (num2 + player.CurrentToolIndex) % 12;
			if (player.CurrentToolIndex < 0)
			{
				player.CurrentToolIndex = 11;
			}
		}
		playSound("toolSwap");
		if (player.ActiveObject != null)
		{
			player.showCarrying();
		}
		else
		{
			player.showNotCarrying();
		}
	}

	public static bool pressUseToolButton()
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_035b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0428: Unknown result type (might be due to invalid IL or missing references)
		//IL_043a: Unknown result type (might be due to invalid IL or missing references)
		//IL_049c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0557: Unknown result type (might be due to invalid IL or missing references)
		//IL_055c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0572: Unknown result type (might be due to invalid IL or missing references)
		//IL_057d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_058d: Unknown result type (might be due to invalid IL or missing references)
		//IL_059e: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0533: Unknown result type (might be due to invalid IL or missing references)
		//IL_0538: Unknown result type (might be due to invalid IL or missing references)
		//IL_0676: Unknown result type (might be due to invalid IL or missing references)
		//IL_067b: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_084f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0855: Unknown result type (might be due to invalid IL or missing references)
		//IL_085a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0866: Unknown result type (might be due to invalid IL or missing references)
		//IL_086f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0878: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0757: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_07dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e2: Unknown result type (might be due to invalid IL or missing references)
		bool didInitiateItemStow = game1._didInitiateItemStow;
		game1._didInitiateItemStow = false;
		if (fadeToBlack)
		{
			return false;
		}
		player.toolPower.Value = 0;
		player.toolHold.Value = 0;
		bool flag = false;
		if (player.CurrentTool == null && player.ActiveObject == null)
		{
			Vector2 val = player.GetToolLocation() / 64f;
			val.X = (int)val.X;
			val.Y = (int)val.Y;
			if (currentLocation.Objects.TryGetValue(val, out var value) && !value.readyForHarvest.Value && value.heldObject.Value == null && !(value is Fence) && !(value is CrabPot) && (value.Type == "Crafting" || value.Type == "interactive") && !value.IsTwig())
			{
				flag = true;
				value.setHealth(value.getHealth() - 1);
				value.shakeTimer = 300;
				value.playNearbySoundAll("hammer");
				if (value.getHealth() < 2)
				{
					value.playNearbySoundAll("hammer");
					if (value.getHealth() < 1)
					{
						Tool tool = ItemRegistry.Create<Tool>("(T)Pickaxe");
						tool.DoFunction(currentLocation, -1, -1, 0, player);
						if (value.performToolAction(tool))
						{
							value.performRemoveAction();
							if (value.Type == "Crafting" && value.fragility.Value != 2)
							{
								currentLocation.debris.Add(new Debris(value.QualifiedItemId, player.GetToolLocation(), Utility.PointToVector2(player.StandingPixel)));
							}
							currentLocation.Objects.Remove(val);
							return true;
						}
					}
				}
			}
		}
		if (currentMinigame == null && !player.UsingTool && (player.IsSitting() || player.isRidingHorse() || player.onBridge.Value || dialogueUp || (eventUp && !CurrentEvent.canPlayerUseTool() && (!currentLocation.currentEvent.playerControlSequence || (activeClickableMenu == null && currentMinigame == null))) || (player.CurrentTool != null && (currentLocation.doesPositionCollideWithCharacter(Utility.getRectangleCenteredAt(player.GetToolLocation(), 64), ignoreMonsters: true)?.IsVillager ?? false))))
		{
			pressActionButton(GetKeyboardState(), input.GetMouseState(), input.GetGamePadState());
			return false;
		}
		if (player.canOnlyWalk)
		{
			return true;
		}
		Vector2 position = (Vector2)((!wasMouseVisibleThisFrame) ? player.GetToolLocation() : new Vector2((float)(getOldMouseX() + ((Rectangle)(ref viewport)).X), (float)(getOldMouseY() + ((Rectangle)(ref viewport)).Y)));
		if (Utility.canGrabSomethingFromHere((int)position.X, (int)position.Y, player))
		{
			Vector2 tile = new Vector2(position.X / 64f, position.Y / 64f);
			if (hooks.OnGameLocation_CheckAction(currentLocation, new Location((int)tile.X, (int)tile.Y), viewport, player, () => currentLocation.checkAction(new Location((int)tile.X, (int)tile.Y), viewport, player)))
			{
				updateCursorTileHint();
				return true;
			}
			if (currentLocation.terrainFeatures.TryGetValue(tile, out var value2))
			{
				value2.performUseAction(tile);
				return true;
			}
			return false;
		}
		if (currentLocation.leftClick((int)position.X, (int)position.Y, player))
		{
			return true;
		}
		isCheckingNonMousePlacement = !IsPerformingMousePlacement();
		if (player.ActiveObject != null)
		{
			if (options.allowStowing && CanPlayerStowItem(GetPlacementGrabTile()))
			{
				if (didPlayerJustLeftClick() || didInitiateItemStow)
				{
					game1._didInitiateItemStow = true;
					playSound("stoneStep");
					player.netItemStowed.Set(newValue: true);
					return true;
				}
				return true;
			}
			if (Utility.withinRadiusOfPlayer((int)position.X, (int)position.Y, 1, player) && hooks.OnGameLocation_CheckAction(currentLocation, new Location((int)position.X / 64, (int)position.Y / 64), viewport, player, () => currentLocation.checkAction(new Location((int)position.X / 64, (int)position.Y / 64), viewport, player)))
			{
				return true;
			}
			Vector2 placementGrabTile = GetPlacementGrabTile();
			Vector2 nearbyValidPlacementPosition = Utility.GetNearbyValidPlacementPosition(player, currentLocation, player.ActiveObject, (int)placementGrabTile.X * 64, (int)placementGrabTile.Y * 64);
			if (Utility.tryToPlaceItem(currentLocation, player.ActiveObject, (int)nearbyValidPlacementPosition.X, (int)nearbyValidPlacementPosition.Y))
			{
				isCheckingNonMousePlacement = false;
				return true;
			}
			isCheckingNonMousePlacement = false;
		}
		if (currentLocation.LowPriorityLeftClick((int)position.X, (int)position.Y, player))
		{
			return true;
		}
		if (options.allowStowing && player.netItemStowed.Value && !flag && (didInitiateItemStow || didPlayerJustLeftClick(ignoreNonMouseHeldInput: true)))
		{
			game1._didInitiateItemStow = true;
			playSound("toolSwap");
			player.netItemStowed.Set(newValue: false);
			return true;
		}
		if (player.UsingTool)
		{
			player.lastClick = new Vector2((float)(int)position.X, (float)(int)position.Y);
			player.CurrentTool.DoFunction(player.currentLocation, (int)player.lastClick.X, (int)player.lastClick.Y, 1, player);
			return true;
		}
		if (player.ActiveObject == null && !player.isEating && player.CurrentTool != null)
		{
			if (player.Stamina <= 20f && player.CurrentTool != null && !(player.CurrentTool is MeleeWeapon) && !eventUp)
			{
				staminaShakeTimer = 1000;
				for (int num = 0; num < 4; num++)
				{
					uiOverlayTempSprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(366, 412, 5, 6), new Vector2((float)(random.Next(32) + ((Rectangle)(ref uiViewport)).Width - 56), (float)(((Rectangle)(ref uiViewport)).Height - 224 - 16 - (int)((double)(player.MaxStamina - 270) * 0.715))), flipped: false, 0.012f, Color.SkyBlue)
					{
						motion = new Vector2(-2f, -10f),
						acceleration = new Vector2(0f, 0.5f),
						local = true,
						scale = 4 + random.Next(-1, 0),
						delayBeforeAnimationStart = num * 30
					});
				}
			}
			if (!(player.CurrentTool is MeleeWeapon) || didPlayerJustLeftClick(ignoreNonMouseHeldInput: true))
			{
				int facingDirection = player.FacingDirection;
				Vector2 toolLocation = player.GetToolLocation(position);
				player.FacingDirection = player.getGeneralDirectionTowards(new Vector2((float)(int)toolLocation.X, (float)(int)toolLocation.Y));
				player.lastClick = new Vector2((float)(int)position.X, (float)(int)position.Y);
				player.BeginUsingTool();
				if (!player.usingTool.Value)
				{
					player.FacingDirection = facingDirection;
				}
				else if (player.FarmerSprite.IsPlayingBasicAnimation(facingDirection, carrying: true) || player.FarmerSprite.IsPlayingBasicAnimation(facingDirection, carrying: false))
				{
					player.FarmerSprite.StopAnimation();
				}
			}
		}
		return false;
	}

	public static bool CanPlayerStowItem(Vector2 position)
	{
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		if (player.ActiveObject == null)
		{
			return false;
		}
		if (player.ActiveObject.bigCraftable.Value)
		{
			return false;
		}
		Object activeObject = player.ActiveObject;
		if (!(activeObject is Furniture))
		{
			if (activeObject != null && (player.ActiveObject.Category == -74 || player.ActiveObject.Category == -19))
			{
				Vector2 nearbyValidPlacementPosition = Utility.GetNearbyValidPlacementPosition(player, currentLocation, player.ActiveObject, (int)position.X * 64, (int)position.Y * 64);
				if (Utility.playerCanPlaceItemHere(player.currentLocation, player.ActiveObject, (int)nearbyValidPlacementPosition.X, (int)nearbyValidPlacementPosition.Y, player) && (!player.ActiveObject.isSapling() || IsPerformingMousePlacement()))
				{
					return false;
				}
			}
			return true;
		}
		return false;
	}

	public static int getMouseXRaw()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		MouseState mouseState = input.GetMouseState();
		return ((MouseState)(ref mouseState)).X;
	}

	public static int getMouseYRaw()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		MouseState mouseState = input.GetMouseState();
		return ((MouseState)(ref mouseState)).Y;
	}

	public static bool IsOnMainThread()
	{
		if (Thread.CurrentThread != null)
		{
			return !Thread.CurrentThread.IsBackground;
		}
		return false;
	}

	public static void PushUIMode()
	{
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		if (!IsOnMainThread())
		{
			return;
		}
		uiModeCount++;
		if (uiModeCount <= 0 || uiMode)
		{
			return;
		}
		uiMode = true;
		if (game1.isDrawing && IsOnMainThread())
		{
			if (game1.uiScreen != null && !((GraphicsResource)game1.uiScreen).IsDisposed)
			{
				RenderTargetBinding[] renderTargets = graphics.GraphicsDevice.GetRenderTargets();
				if (renderTargets.Length != 0)
				{
					Texture renderTarget = ((RenderTargetBinding)(ref renderTargets[0])).RenderTarget;
					nonUIRenderTarget = (RenderTarget2D)(object)((renderTarget is RenderTarget2D) ? renderTarget : null);
				}
				else
				{
					nonUIRenderTarget = null;
				}
				SetRenderTarget(game1.uiScreen);
			}
			if (isRenderingScreenBuffer)
			{
				SetRenderTarget(null);
			}
		}
		Rectangle val = default(Rectangle);
		((Rectangle)(ref val))._002Ector(0, 0, (int)Math.Ceiling((float)((Rectangle)(ref viewport)).Width * options.zoomLevel / options.uiScale), (int)Math.Ceiling((float)((Rectangle)(ref viewport)).Height * options.zoomLevel / options.uiScale));
		((Rectangle)(ref val)).X = ((Rectangle)(ref viewport)).X;
		((Rectangle)(ref val)).Y = ((Rectangle)(ref viewport)).Y;
		uiViewport = val;
	}

	public static void PopUIMode()
	{
		if (!IsOnMainThread())
		{
			return;
		}
		uiModeCount--;
		if (uiModeCount > 0 || !uiMode)
		{
			return;
		}
		if (game1.isDrawing)
		{
			if (graphics.GraphicsDevice.GetRenderTargets().Length != 0 && (object)((RenderTargetBinding)(ref graphics.GraphicsDevice.GetRenderTargets()[0])).RenderTarget == game1.uiScreen)
			{
				if (nonUIRenderTarget != null && !((GraphicsResource)nonUIRenderTarget).IsDisposed)
				{
					SetRenderTarget(nonUIRenderTarget);
				}
				else
				{
					SetRenderTarget(null);
				}
			}
			if (isRenderingScreenBuffer)
			{
				SetRenderTarget(null);
			}
		}
		nonUIRenderTarget = null;
		uiMode = false;
	}

	public static void SetRenderTarget(RenderTarget2D target)
	{
		if (!isRenderingScreenBuffer && IsOnMainThread())
		{
			graphics.GraphicsDevice.SetRenderTarget(target);
		}
	}

	public static void InUIMode(Action action)
	{
		PushUIMode();
		try
		{
			action();
		}
		finally
		{
			PopUIMode();
		}
	}

	public static void StartWorldDrawInUI(SpriteBatch b)
	{
		_oldUIModeCount = 0;
		if (uiMode)
		{
			_oldUIModeCount = uiModeCount;
			if (b != null)
			{
				b.End();
			}
			while (uiModeCount > 0)
			{
				PopUIMode();
			}
			if (b != null)
			{
				b.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			}
		}
	}

	public static void EndWorldDrawInUI(SpriteBatch b)
	{
		if (_oldUIModeCount > 0)
		{
			if (b != null)
			{
				b.End();
			}
			for (int i = 0; i < _oldUIModeCount; i++)
			{
				PushUIMode();
			}
			if (b != null)
			{
				b.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			}
		}
		_oldUIModeCount = 0;
	}

	public static int getMouseX()
	{
		return getMouseX(uiMode);
	}

	public static int getMouseX(bool ui_scale)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		MouseState mouseState;
		if (ui_scale)
		{
			mouseState = input.GetMouseState();
			return (int)((float)((MouseState)(ref mouseState)).X / options.uiScale);
		}
		mouseState = input.GetMouseState();
		return (int)((float)((MouseState)(ref mouseState)).X * (1f / options.zoomLevel));
	}

	public static int getOldMouseX()
	{
		return getOldMouseX(uiMode);
	}

	public static int getOldMouseX(bool ui_scale)
	{
		if (ui_scale)
		{
			return (int)((float)((MouseState)(ref oldMouseState)).X / options.uiScale);
		}
		return (int)((float)((MouseState)(ref oldMouseState)).X * (1f / options.zoomLevel));
	}

	public static int getMouseY()
	{
		return getMouseY(uiMode);
	}

	public static int getMouseY(bool ui_scale)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		MouseState mouseState;
		if (ui_scale)
		{
			mouseState = input.GetMouseState();
			return (int)((float)((MouseState)(ref mouseState)).Y / options.uiScale);
		}
		mouseState = input.GetMouseState();
		return (int)((float)((MouseState)(ref mouseState)).Y * (1f / options.zoomLevel));
	}

	public static int getOldMouseY()
	{
		return getOldMouseY(uiMode);
	}

	public static int getOldMouseY(bool ui_scale)
	{
		if (ui_scale)
		{
			return (int)((float)((MouseState)(ref oldMouseState)).Y / options.uiScale);
		}
		return (int)((float)((MouseState)(ref oldMouseState)).Y * (1f / options.zoomLevel));
	}

	public static bool PlayEvent(string eventId, GameLocation location, out bool validEvent, bool checkPreconditions = true, bool checkSeen = true)
	{
		string eventAssetName;
		Dictionary<string, string> locationEvents;
		try
		{
			if (!location.TryGetLocationEvents(out eventAssetName, out locationEvents))
			{
				validEvent = false;
				return false;
			}
		}
		catch
		{
			validEvent = false;
			return false;
		}
		if (locationEvents == null)
		{
			validEvent = false;
			return false;
		}
		foreach (string key in locationEvents.Keys)
		{
			if (!(key.Split('/')[0] == eventId))
			{
				continue;
			}
			validEvent = true;
			if (checkSeen && (player.eventsSeen.Contains(eventId) || eventsSeenSinceLastLocationChange.Contains(eventId)))
			{
				return false;
			}
			string id = eventId;
			if (checkPreconditions)
			{
				id = location.checkEventPrecondition(key, check_seen: false);
			}
			if (!string.IsNullOrEmpty(id) && id != "-1")
			{
				if (location.Name != currentLocation.Name)
				{
					LocationRequest obj2 = getLocationRequest(location.Name);
					obj2.OnLoad += delegate
					{
						currentLocation.currentEvent = new Event(locationEvents[key], eventAssetName, id);
					};
					int x = 8;
					int y = 8;
					Utility.getDefaultWarpLocation(obj2.Name, ref x, ref y);
					warpFarmer(obj2, x, y, player.FacingDirection);
				}
				else
				{
					globalFadeToBlack(delegate
					{
						forceSnapOnNextViewportUpdate = true;
						currentLocation.startEvent(new Event(locationEvents[key], eventAssetName, id));
						globalFadeToClear();
					});
				}
				return true;
			}
			return false;
		}
		validEvent = false;
		return false;
	}

	public static bool PlayEvent(string eventId, bool checkPreconditions = true, bool checkSeen = true)
	{
		if (checkSeen && (player.eventsSeen.Contains(eventId) || eventsSeenSinceLastLocationChange.Contains(eventId)))
		{
			return false;
		}
		if (PlayEvent(eventId, currentLocation, out var validEvent, checkPreconditions, checkSeen))
		{
			return true;
		}
		if (validEvent)
		{
			return false;
		}
		foreach (GameLocation location in locations)
		{
			if (location != currentLocation)
			{
				if (PlayEvent(eventId, location, out validEvent, checkPreconditions, checkSeen))
				{
					return true;
				}
				if (validEvent)
				{
					return false;
				}
			}
		}
		return false;
	}

	public static int numberOfPlayers()
	{
		return _onlineFarmers.Count;
	}

	public static bool isFestival()
	{
		return currentLocation?.currentEvent?.isFestival ?? false;
	}

	public bool parseDebugInput(string debugInput, IGameLogger log = null)
	{
		debugInput = debugInput.Trim();
		string[] command = ArgUtility.SplitBySpaceQuoteAware(debugInput);
		try
		{
			return DebugCommands.TryHandle(command, log);
		}
		catch (Exception ex)
		{
			Game1.log.Error("Debug command error.", ex);
			debugOutput = ex.Message;
			return false;
		}
	}

	public void RecountWalnuts()
	{
		if (!IsMasterGame || netWorldState.Value.ActivatedGoldenParrot || !(getLocationFromName("IslandHut") is IslandHut islandHut))
		{
			return;
		}
		int num = islandHut.ShowNutHint();
		int num2 = 130 - num;
		netWorldState.Value.GoldenWalnutsFound = num2;
		foreach (GameLocation location in locations)
		{
			if (!(location is IslandLocation islandLocation))
			{
				continue;
			}
			foreach (ParrotUpgradePerch parrotUpgradePerch in islandLocation.parrotUpgradePerches)
			{
				if (parrotUpgradePerch.currentState.Value == ParrotUpgradePerch.UpgradeState.Complete)
				{
					num2 -= parrotUpgradePerch.requiredNuts.Value;
				}
			}
		}
		if (MasterPlayer.hasOrWillReceiveMail("Island_VolcanoShortcutOut"))
		{
			num2 -= 5;
		}
		if (MasterPlayer.hasOrWillReceiveMail("Island_VolcanoBridge"))
		{
			num2 -= 5;
		}
		netWorldState.Value.GoldenWalnuts = num2;
	}

	public void ResetIslandLocations()
	{
		netWorldState.Value.GoldenWalnutsFound = 0;
		player.team.collectedNutTracker.Clear();
		NetStringHashSet[] array = new NetStringHashSet[3]
		{
			player.mailReceived,
			player.mailForTomorrow,
			player.team.broadcastedMail
		};
		foreach (NetStringHashSet obj in array)
		{
			obj.Remove("birdieQuestBegun");
			obj.Remove("birdieQuestFinished");
			obj.Remove("tigerSlimeNut");
			obj.Remove("Island_W_BuriedTreasureNut");
			obj.Remove("Island_W_BuriedTreasure");
			obj.Remove("islandNorthCaveOpened");
			obj.Remove("Saw_Flame_Sprite_North_North");
			obj.Remove("Saw_Flame_Sprite_North_South");
			obj.Remove("Island_N_BuriedTreasureNut");
			obj.Remove("Island_W_BuriedTreasure");
			obj.Remove("Saw_Flame_Sprite_South");
			obj.Remove("Visited_Island");
			obj.Remove("Island_FirstParrot");
			obj.Remove("gotBirdieReward");
			obj.RemoveWhere((string key) => key.StartsWith("Island_Upgrade"));
		}
		player.secretNotesSeen.RemoveWhere((int id) => id >= GameLocation.JOURNAL_INDEX);
		player.team.limitedNutDrops.Clear();
		netWorldState.Value.GoldenCoconutCracked = false;
		netWorldState.Value.GoldenWalnuts = 0;
		netWorldState.Value.ParrotPlatformsUnlocked = false;
		netWorldState.Value.FoundBuriedNuts.Clear();
		for (int num = 0; num < locations.Count; num++)
		{
			GameLocation gameLocation = locations[num];
			if (gameLocation.InIslandContext())
			{
				_locationLookup.Clear();
				string value = gameLocation.mapPath.Value;
				string value2 = gameLocation.name.Value;
				object[] args = new object[2] { value, value2 };
				try
				{
					locations[num] = Activator.CreateInstance(gameLocation.GetType(), args) as GameLocation;
				}
				catch
				{
					locations[num] = Activator.CreateInstance(gameLocation.GetType()) as GameLocation;
				}
				_locationLookup.Clear();
			}
		}
		AddCharacterIfNecessary("Birdie");
	}

	public void ShowTelephoneMenu()
	{
		playSound("openBox");
		if (IsGreenRainingHere())
		{
			drawObjectDialogue("...................");
			return;
		}
		List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
		foreach (IPhoneHandler phoneHandler in Phone.PhoneHandlers)
		{
			list.AddRange(phoneHandler.GetOutgoingNumbers());
		}
		list.Add(new KeyValuePair<string, string>("HangUp", content.LoadString("Strings\\Locations:MineCart_Destination_Cancel")));
		currentLocation.ShowPagedResponses(content.LoadString("Strings\\Characters:Phone_SelectNumber"), list, delegate(string callId)
		{
			if (callId == "HangUp")
			{
				Phone.HangUp();
			}
			else
			{
				foreach (IPhoneHandler phoneHandler2 in Phone.PhoneHandlers)
				{
					if (phoneHandler2.TryHandleOutgoingCall(callId))
					{
						return;
					}
				}
				Phone.HangUp();
			}
		}, auto_select_single_choice: false, addCancel: false, 6);
	}

	public void requestDebugInput()
	{
		chatBox.activate();
		chatBox.setText("/");
	}

	private void panModeSuccess(KeyboardState currentKBState)
	{
		panFacingDirectionWait = false;
		playSound("smallSelect");
		if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)160))
		{
			panModeString += " (animation_name_here)";
		}
		debugOutput = panModeString;
	}

	private void updatePanModeControls(MouseState currentMouseState, KeyboardState currentKBState)
	{
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Invalid comparison between Unknown and I4
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_034b: Invalid comparison between Unknown and I4
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_038a: Unknown result type (might be due to invalid IL or missing references)
		//IL_032c: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ee: Unknown result type (might be due to invalid IL or missing references)
		if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)119) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)119))
		{
			requestDebugInput();
			return;
		}
		if (!panFacingDirectionWait)
		{
			if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)87))
			{
				((Rectangle)(ref viewport)).Y = ((Rectangle)(ref viewport)).Y - 16;
			}
			if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)65))
			{
				((Rectangle)(ref viewport)).X = ((Rectangle)(ref viewport)).X - 16;
			}
			if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)83))
			{
				((Rectangle)(ref viewport)).Y = ((Rectangle)(ref viewport)).Y + 16;
			}
			if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)68))
			{
				((Rectangle)(ref viewport)).X = ((Rectangle)(ref viewport)).X + 16;
			}
		}
		else
		{
			if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)87))
			{
				panModeString += "0";
				panModeSuccess(currentKBState);
			}
			if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)65))
			{
				panModeString += "3";
				panModeSuccess(currentKBState);
			}
			if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)83))
			{
				panModeString += "2";
				panModeSuccess(currentKBState);
			}
			if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)68))
			{
				panModeString += "1";
				panModeSuccess(currentKBState);
			}
		}
		if (getMouseX(ui_scale: false) < 192)
		{
			((Rectangle)(ref viewport)).X = ((Rectangle)(ref viewport)).X - 8;
			((Rectangle)(ref viewport)).X = ((Rectangle)(ref viewport)).X - (192 - getMouseX()) / 8;
		}
		if (getMouseX(ui_scale: false) > ((Rectangle)(ref viewport)).Width - 192)
		{
			((Rectangle)(ref viewport)).X = ((Rectangle)(ref viewport)).X + 8;
			((Rectangle)(ref viewport)).X = ((Rectangle)(ref viewport)).X + (getMouseX() - ((Rectangle)(ref viewport)).Width + 192) / 8;
		}
		if (getMouseY(ui_scale: false) < 192)
		{
			((Rectangle)(ref viewport)).Y = ((Rectangle)(ref viewport)).Y - 8;
			((Rectangle)(ref viewport)).Y = ((Rectangle)(ref viewport)).Y - (192 - getMouseY()) / 8;
		}
		if (getMouseY(ui_scale: false) > ((Rectangle)(ref viewport)).Height - 192)
		{
			((Rectangle)(ref viewport)).Y = ((Rectangle)(ref viewport)).Y + 8;
			((Rectangle)(ref viewport)).Y = ((Rectangle)(ref viewport)).Y + (getMouseY() - ((Rectangle)(ref viewport)).Height + 192) / 8;
		}
		if ((int)((MouseState)(ref currentMouseState)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton == 0)
		{
			string text = panModeString;
			if (text != null && text.Length > 0)
			{
				int num = (getMouseX() + ((Rectangle)(ref viewport)).X) / 64;
				int num2 = (getMouseY() + ((Rectangle)(ref viewport)).Y) / 64;
				panModeString = panModeString + currentLocation.Name + " " + num + " " + num2 + " ";
				panFacingDirectionWait = true;
				currentLocation.playTerrainSound(new Vector2((float)num, (float)num2));
				debugOutput = panModeString;
			}
		}
		if ((int)((MouseState)(ref currentMouseState)).RightButton == 1 && (int)((MouseState)(ref oldMouseState)).RightButton == 0)
		{
			int num3 = getMouseX() + ((Rectangle)(ref viewport)).X;
			int num4 = getMouseY() + ((Rectangle)(ref viewport)).Y;
			Warp warp = currentLocation.isCollidingWithWarpOrDoor(new Rectangle(num3, num4, 1, 1));
			if (warp != null)
			{
				currentLocation = RequireLocation(warp.TargetName);
				currentLocation.map.LoadTileSheets(mapDisplayDevice);
				((Rectangle)(ref viewport)).X = warp.TargetX * 64 - ((Rectangle)(ref viewport)).Width / 2;
				((Rectangle)(ref viewport)).Y = warp.TargetY * 64 - ((Rectangle)(ref viewport)).Height / 2;
				playSound("dwop");
			}
		}
		if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)27) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)27))
		{
			Warp warp2 = currentLocation.warps[0];
			currentLocation = RequireLocation(warp2.TargetName);
			currentLocation.map.LoadTileSheets(mapDisplayDevice);
			((Rectangle)(ref viewport)).X = warp2.TargetX * 64 - ((Rectangle)(ref viewport)).Width / 2;
			((Rectangle)(ref viewport)).Y = warp2.TargetY * 64 - ((Rectangle)(ref viewport)).Height / 2;
			playSound("dwop");
		}
		if (((Rectangle)(ref viewport)).X < -64)
		{
			((Rectangle)(ref viewport)).X = -64;
		}
		if (((Rectangle)(ref viewport)).X + ((Rectangle)(ref viewport)).Width > currentLocation.Map.Layers[0].LayerWidth * 64 + 128)
		{
			((Rectangle)(ref viewport)).X = currentLocation.Map.Layers[0].LayerWidth * 64 + 128 - ((Rectangle)(ref viewport)).Width;
		}
		if (((Rectangle)(ref viewport)).Y < -64)
		{
			((Rectangle)(ref viewport)).Y = -64;
		}
		if (((Rectangle)(ref viewport)).Y + ((Rectangle)(ref viewport)).Height > currentLocation.Map.Layers[0].LayerHeight * 64 + 128)
		{
			((Rectangle)(ref viewport)).Y = currentLocation.Map.Layers[0].LayerHeight * 64 + 128 - ((Rectangle)(ref viewport)).Height;
		}
		oldMouseState = input.GetMouseState();
		oldKBState = currentKBState;
	}

	public static bool isLocationAccessible(string locationName)
	{
		switch (locationName)
		{
		case "Desert":
			if (MasterPlayer.mailReceived.Contains("ccVault"))
			{
				return true;
			}
			break;
		case "CommunityCenter":
			if (player.eventsSeen.Contains("191393"))
			{
				return true;
			}
			break;
		case "JojaMart":
			if (!Utility.HasAnyPlayerSeenEvent("191393"))
			{
				return true;
			}
			break;
		case "Railroad":
			if (stats.DaysPlayed > 31)
			{
				return true;
			}
			break;
		default:
			return true;
		}
		return false;
	}

	public static bool isDPadPressed()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		return isDPadPressed(input.GetGamePadState());
	}

	public static bool isDPadPressed(GamePadState pad_state)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Invalid comparison between Unknown and I4
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Invalid comparison between Unknown and I4
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Invalid comparison between Unknown and I4
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Invalid comparison between Unknown and I4
		GamePadDPad dPad = ((GamePadState)(ref pad_state)).DPad;
		if ((int)((GamePadDPad)(ref dPad)).Up != 1)
		{
			dPad = ((GamePadState)(ref pad_state)).DPad;
			if ((int)((GamePadDPad)(ref dPad)).Down != 1)
			{
				dPad = ((GamePadState)(ref pad_state)).DPad;
				if ((int)((GamePadDPad)(ref dPad)).Left != 1)
				{
					dPad = ((GamePadState)(ref pad_state)).DPad;
					if ((int)((GamePadDPad)(ref dPad)).Right != 1)
					{
						return false;
					}
				}
			}
		}
		return true;
	}

	public static bool isGamePadThumbstickInMotion(double threshold = 0.2)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		GamePadState gamePadState = input.GetGamePadState();
		GamePadThumbSticks thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X < 0.0 - threshold || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)2097152))
		{
			flag = true;
		}
		thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X > threshold || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)1073741824))
		{
			flag = true;
		}
		thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y < 0.0 - threshold || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)268435456))
		{
			flag = true;
		}
		thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y > threshold || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)536870912))
		{
			flag = true;
		}
		thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Right.X < 0.0 - threshold)
		{
			flag = true;
		}
		thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Right.X > threshold)
		{
			flag = true;
		}
		thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Right.Y < 0.0 - threshold)
		{
			flag = true;
		}
		thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Right.Y > threshold)
		{
			flag = true;
		}
		if (flag)
		{
			thumbstickMotionMargin = 50;
		}
		return thumbstickMotionMargin > 0;
	}

	public static bool isAnyGamePadButtonBeingPressed()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		return Utility.getPressedButtons(input.GetGamePadState(), oldPadState).Count > 0;
	}

	public static bool isAnyGamePadButtonBeingHeld()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		return Utility.getHeldButtons(input.GetGamePadState()).Count > 0;
	}

	private static void UpdateChatBox()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		if (chatBox == null)
		{
			return;
		}
		KeyboardState keyboardState = input.GetKeyboardState();
		GamePadState gamePadState = input.GetGamePadState();
		if (IsChatting)
		{
			if (textEntry != null)
			{
				return;
			}
			if (((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)4096))
			{
				MouseState mouseState = input.GetMouseState();
				if (chatBox != null && chatBox.isActive() && !chatBox.isHoveringOverClickable(((MouseState)(ref mouseState)).X, ((MouseState)(ref mouseState)).Y))
				{
					oldPadState = gamePadState;
					oldKBState = keyboardState;
					showTextEntry(chatBox.chatBox);
				}
			}
			if (((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)27) || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)8192) || ((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)32))
			{
				chatBox.clickAway();
				oldKBState = keyboardState;
			}
		}
		else if (keyboardDispatcher.Subscriber == null && ((isOneOfTheseKeysDown(keyboardState, options.chatButton) && game1.HasKeyboardFocus()) || (!((GamePadState)(ref gamePadState)).IsButtonDown((Buttons)128) && rightStickHoldTime > 0 && rightStickHoldTime < emoteMenuShowTime)))
		{
			chatBox.activate();
			if (((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)191))
			{
				chatBox.setText("/");
			}
		}
	}

	public static KeyboardState GetKeyboardState()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		KeyboardState keyboardState = input.GetKeyboardState();
		if (chatBox != null)
		{
			if (IsChatting)
			{
				return default(KeyboardState);
			}
			if (keyboardDispatcher.Subscriber == null && isOneOfTheseKeysDown(keyboardState, options.chatButton) && game1.HasKeyboardFocus())
			{
				return default(KeyboardState);
			}
		}
		return keyboardState;
	}

	private void UpdateControlInput(GameTime time)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		KeyboardState currentKBState = GetKeyboardState();
		MouseState currentMouseState = input.GetMouseState();
		GamePadState currentPadState = input.GetGamePadState();
		if (ticks < _activatedTick + 2 && ((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)9) != ((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)9))
		{
			List<Keys> list = ((KeyboardState)(ref oldKBState)).GetPressedKeys().ToList();
			if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)9))
			{
				list.Add((Keys)9);
			}
			else
			{
				list.Remove((Keys)9);
			}
			oldKBState = new KeyboardState(list.ToArray());
		}
		hooks.OnGame1_UpdateControlInput(ref currentKBState, ref currentMouseState, ref currentPadState, delegate
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_0077: Unknown result type (might be due to invalid IL or missing references)
			//IL_009b: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_0046: Unknown result type (might be due to invalid IL or missing references)
			//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01fc: Invalid comparison between Unknown and I4
			//IL_01da: Unknown result type (might be due to invalid IL or missing references)
			//IL_0217: Unknown result type (might be due to invalid IL or missing references)
			//IL_0203: Unknown result type (might be due to invalid IL or missing references)
			//IL_0249: Unknown result type (might be due to invalid IL or missing references)
			//IL_024f: Invalid comparison between Unknown and I4
			//IL_022d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0260: Unknown result type (might be due to invalid IL or missing references)
			//IL_0256: Unknown result type (might be due to invalid IL or missing references)
			//IL_0292: Unknown result type (might be due to invalid IL or missing references)
			//IL_0276: Unknown result type (might be due to invalid IL or missing references)
			//IL_029e: Unknown result type (might be due to invalid IL or missing references)
			//IL_02a4: Invalid comparison between Unknown and I4
			//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
			//IL_012a: Unknown result type (might be due to invalid IL or missing references)
			//IL_012f: Unknown result type (might be due to invalid IL or missing references)
			//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_02fa: Invalid comparison between Unknown and I4
			//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
			//IL_030c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0301: Unknown result type (might be due to invalid IL or missing references)
			//IL_033c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0322: Unknown result type (might be due to invalid IL or missing references)
			//IL_036c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0352: Unknown result type (might be due to invalid IL or missing references)
			//IL_039c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0382: Unknown result type (might be due to invalid IL or missing references)
			//IL_03cc: Unknown result type (might be due to invalid IL or missing references)
			//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
			//IL_03fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_03e2: Unknown result type (might be due to invalid IL or missing references)
			//IL_042c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0412: Unknown result type (might be due to invalid IL or missing references)
			//IL_045c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0442: Unknown result type (might be due to invalid IL or missing references)
			//IL_048c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0472: Unknown result type (might be due to invalid IL or missing references)
			//IL_04a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_04c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_04da: Unknown result type (might be due to invalid IL or missing references)
			//IL_04f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_0510: Unknown result type (might be due to invalid IL or missing references)
			//IL_0516: Invalid comparison between Unknown and I4
			//IL_051c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0538: Unknown result type (might be due to invalid IL or missing references)
			//IL_053e: Invalid comparison between Unknown and I4
			//IL_0593: Unknown result type (might be due to invalid IL or missing references)
			//IL_0599: Invalid comparison between Unknown and I4
			//IL_05a1: Unknown result type (might be due to invalid IL or missing references)
			//IL_05a7: Invalid comparison between Unknown and I4
			//IL_0ba7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0bbd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d04: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d0a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ff6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ffb: Unknown result type (might be due to invalid IL or missing references)
			//IL_1001: Unknown result type (might be due to invalid IL or missing references)
			//IL_1006: Unknown result type (might be due to invalid IL or missing references)
			//IL_100c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0fb7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0fbc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0db6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dbb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dc1: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dc6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dcc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dd1: Unknown result type (might be due to invalid IL or missing references)
			//IL_0fd5: Unknown result type (might be due to invalid IL or missing references)
			//IL_0fda: Unknown result type (might be due to invalid IL or missing references)
			//IL_0fe1: Unknown result type (might be due to invalid IL or missing references)
			//IL_109f: Unknown result type (might be due to invalid IL or missing references)
			//IL_10a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_1037: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f05: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f0a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f10: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f15: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f1b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f20: Unknown result type (might be due to invalid IL or missing references)
			//IL_08ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_08f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_08f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_091c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0921: Unknown result type (might be due to invalid IL or missing references)
			//IL_0925: Unknown result type (might be due to invalid IL or missing references)
			//IL_11d8: Unknown result type (might be due to invalid IL or missing references)
			//IL_11de: Unknown result type (might be due to invalid IL or missing references)
			//IL_11e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f4b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f50: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f56: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f5b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f61: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f66: Unknown result type (might be due to invalid IL or missing references)
			//IL_0947: Unknown result type (might be due to invalid IL or missing references)
			//IL_094c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0950: Unknown result type (might be due to invalid IL or missing references)
			//IL_11f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_11f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_1200: Unknown result type (might be due to invalid IL or missing references)
			//IL_1205: Unknown result type (might be due to invalid IL or missing references)
			//IL_120b: Unknown result type (might be due to invalid IL or missing references)
			//IL_1210: Unknown result type (might be due to invalid IL or missing references)
			//IL_0974: Unknown result type (might be due to invalid IL or missing references)
			//IL_0979: Unknown result type (might be due to invalid IL or missing references)
			//IL_097d: Unknown result type (might be due to invalid IL or missing references)
			//IL_099e: Unknown result type (might be due to invalid IL or missing references)
			//IL_09a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_09a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_1187: Unknown result type (might be due to invalid IL or missing references)
			//IL_118c: Unknown result type (might be due to invalid IL or missing references)
			//IL_09c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_09ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_09d2: Unknown result type (might be due to invalid IL or missing references)
			//IL_119e: Unknown result type (might be due to invalid IL or missing references)
			//IL_11a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_11a9: Unknown result type (might be due to invalid IL or missing references)
			//IL_11ae: Unknown result type (might be due to invalid IL or missing references)
			//IL_09f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_09f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_09fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a1f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a24: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a28: Unknown result type (might be due to invalid IL or missing references)
			//IL_12e9: Unknown result type (might be due to invalid IL or missing references)
			//IL_12ee: Unknown result type (might be due to invalid IL or missing references)
			//IL_12f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_12f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_12ff: Unknown result type (might be due to invalid IL or missing references)
			//IL_1304: Unknown result type (might be due to invalid IL or missing references)
			//IL_1ee5: Unknown result type (might be due to invalid IL or missing references)
			//IL_21dc: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f22: Unknown result type (might be due to invalid IL or missing references)
			//IL_1efb: Unknown result type (might be due to invalid IL or missing references)
			//IL_21f2: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f5f: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f38: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a9e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0aa3: Unknown result type (might be due to invalid IL or missing references)
			//IL_0aa7: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f9c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f75: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ac8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0acd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ad1: Unknown result type (might be due to invalid IL or missing references)
			//IL_231f: Unknown result type (might be due to invalid IL or missing references)
			//IL_1fd9: Unknown result type (might be due to invalid IL or missing references)
			//IL_1fb2: Unknown result type (might be due to invalid IL or missing references)
			//IL_2335: Unknown result type (might be due to invalid IL or missing references)
			//IL_2016: Unknown result type (might be due to invalid IL or missing references)
			//IL_1fef: Unknown result type (might be due to invalid IL or missing references)
			//IL_234f: Unknown result type (might be due to invalid IL or missing references)
			//IL_2053: Unknown result type (might be due to invalid IL or missing references)
			//IL_202c: Unknown result type (might be due to invalid IL or missing references)
			//IL_2365: Unknown result type (might be due to invalid IL or missing references)
			//IL_2090: Unknown result type (might be due to invalid IL or missing references)
			//IL_2069: Unknown result type (might be due to invalid IL or missing references)
			//IL_237f: Unknown result type (might be due to invalid IL or missing references)
			//IL_20cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_20a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_2395: Unknown result type (might be due to invalid IL or missing references)
			//IL_210a: Unknown result type (might be due to invalid IL or missing references)
			//IL_20e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_2145: Unknown result type (might be due to invalid IL or missing references)
			//IL_2120: Unknown result type (might be due to invalid IL or missing references)
			//IL_2180: Unknown result type (might be due to invalid IL or missing references)
			//IL_215b: Unknown result type (might be due to invalid IL or missing references)
			//IL_2196: Unknown result type (might be due to invalid IL or missing references)
			//IL_1c0c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1c92: Unknown result type (might be due to invalid IL or missing references)
			//IL_1d2f: Unknown result type (might be due to invalid IL or missing references)
			//IL_25d0: Unknown result type (might be due to invalid IL or missing references)
			//IL_25dc: Unknown result type (might be due to invalid IL or missing references)
			//IL_25e1: Unknown result type (might be due to invalid IL or missing references)
			//IL_25eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_25f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_25f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_25fb: Unknown result type (might be due to invalid IL or missing references)
			bool flag;
			GamePadThumbSticks thumbSticks;
			if (options.gamepadControls)
			{
				flag = false;
				thumbSticks = ((GamePadState)(ref currentPadState)).ThumbSticks;
				if (!(Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Right.X) > 0f))
				{
					thumbSticks = ((GamePadState)(ref currentPadState)).ThumbSticks;
					if (!(Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Right.Y) > 0f))
					{
						goto IL_00be;
					}
				}
				float num = ((MouseState)(ref currentMouseState)).X;
				thumbSticks = ((GamePadState)(ref currentPadState)).ThumbSticks;
				int x = (int)(num + ((GamePadThumbSticks)(ref thumbSticks)).Right.X * thumbstickToMouseModifier);
				float num2 = ((MouseState)(ref currentMouseState)).Y;
				thumbSticks = ((GamePadState)(ref currentPadState)).ThumbSticks;
				setMousePositionRaw(x, (int)(num2 - ((GamePadThumbSticks)(ref thumbSticks)).Right.Y * thumbstickToMouseModifier));
				flag = true;
				goto IL_00be;
			}
			if (getMouseX() != getOldMouseX() || getMouseY() != getOldMouseY())
			{
				lastCursorMotionWasMouse = true;
			}
			goto IL_018e;
			IL_00be:
			if (IsChatting)
			{
				flag = true;
			}
			if (((getMouseX() != getOldMouseX() || getMouseY() != getOldMouseY()) && getMouseX() != 0 && getMouseY() != 0) || flag)
			{
				if (flag)
				{
					if (timerUntilMouseFade <= 0)
					{
						lastMousePositionBeforeFade = new Point(localMultiplayerWindow.Width / 2, localMultiplayerWindow.Height / 2);
					}
				}
				else
				{
					lastCursorMotionWasMouse = true;
				}
				if (timerUntilMouseFade <= 0 && !lastCursorMotionWasMouse)
				{
					setMousePositionRaw(lastMousePositionBeforeFade.X, lastMousePositionBeforeFade.Y);
				}
				timerUntilMouseFade = 4000;
			}
			goto IL_018e;
			IL_018e:
			bool actionButtonPressed = false;
			bool switchToolButtonPressed = false;
			bool useToolButtonPressed = false;
			bool useToolButtonReleased = false;
			bool addItemToInventoryButtonPressed = false;
			bool cancelButtonPressed = false;
			bool moveUpPressed = false;
			bool moveRightPressed = false;
			bool moveLeftPressed = false;
			bool moveDownPressed = false;
			bool moveUpReleased = false;
			bool moveRightReleased = false;
			bool moveDownReleased = false;
			bool moveLeftReleased = false;
			bool moveUpHeld = false;
			bool moveRightHeld = false;
			bool moveDownHeld = false;
			bool moveLeftHeld = false;
			bool flag2 = false;
			if ((isOneOfTheseKeysDown(currentKBState, options.actionButton) && areAllOfTheseKeysUp(oldKBState, options.actionButton)) || ((int)((MouseState)(ref currentMouseState)).RightButton == 1 && (int)((MouseState)(ref oldMouseState)).RightButton == 0))
			{
				actionButtonPressed = true;
				rightClickPolling = 250;
			}
			if ((isOneOfTheseKeysDown(currentKBState, options.useToolButton) && areAllOfTheseKeysUp(oldKBState, options.useToolButton)) || ((int)((MouseState)(ref currentMouseState)).LeftButton == 1 && (int)((MouseState)(ref oldMouseState)).LeftButton == 0))
			{
				useToolButtonPressed = true;
			}
			if ((areAllOfTheseKeysUp(currentKBState, options.useToolButton) && isOneOfTheseKeysDown(oldKBState, options.useToolButton)) || ((int)((MouseState)(ref currentMouseState)).LeftButton == 0 && (int)((MouseState)(ref oldMouseState)).LeftButton == 1))
			{
				useToolButtonReleased = true;
			}
			if (((MouseState)(ref currentMouseState)).ScrollWheelValue != ((MouseState)(ref oldMouseState)).ScrollWheelValue)
			{
				switchToolButtonPressed = true;
			}
			if ((isOneOfTheseKeysDown(currentKBState, options.cancelButton) && areAllOfTheseKeysUp(oldKBState, options.cancelButton)) || ((int)((MouseState)(ref currentMouseState)).RightButton == 1 && (int)((MouseState)(ref oldMouseState)).RightButton == 0))
			{
				cancelButtonPressed = true;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.moveUpButton) && areAllOfTheseKeysUp(oldKBState, options.moveUpButton))
			{
				moveUpPressed = true;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.moveRightButton) && areAllOfTheseKeysUp(oldKBState, options.moveRightButton))
			{
				moveRightPressed = true;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.moveDownButton) && areAllOfTheseKeysUp(oldKBState, options.moveDownButton))
			{
				moveDownPressed = true;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.moveLeftButton) && areAllOfTheseKeysUp(oldKBState, options.moveLeftButton))
			{
				moveLeftPressed = true;
			}
			if (areAllOfTheseKeysUp(currentKBState, options.moveUpButton) && isOneOfTheseKeysDown(oldKBState, options.moveUpButton))
			{
				moveUpReleased = true;
			}
			if (areAllOfTheseKeysUp(currentKBState, options.moveRightButton) && isOneOfTheseKeysDown(oldKBState, options.moveRightButton))
			{
				moveRightReleased = true;
			}
			if (areAllOfTheseKeysUp(currentKBState, options.moveDownButton) && isOneOfTheseKeysDown(oldKBState, options.moveDownButton))
			{
				moveDownReleased = true;
			}
			if (areAllOfTheseKeysUp(currentKBState, options.moveLeftButton) && isOneOfTheseKeysDown(oldKBState, options.moveLeftButton))
			{
				moveLeftReleased = true;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.moveUpButton))
			{
				moveUpHeld = true;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.moveRightButton))
			{
				moveRightHeld = true;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.moveDownButton))
			{
				moveDownHeld = true;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.moveLeftButton))
			{
				moveLeftHeld = true;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.useToolButton) || (int)((MouseState)(ref currentMouseState)).LeftButton == 1)
			{
				flag2 = true;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.actionButton) || (int)((MouseState)(ref currentMouseState)).RightButton == 1)
			{
				rightClickPolling -= time.ElapsedGameTime.Milliseconds;
				if (rightClickPolling <= 0)
				{
					rightClickPolling = 100;
					actionButtonPressed = true;
				}
			}
			if (options.gamepadControls)
			{
				if (((KeyboardState)(ref currentKBState)).GetPressedKeys().Length != 0 || (int)((MouseState)(ref currentMouseState)).LeftButton == 1 || (int)((MouseState)(ref currentMouseState)).RightButton == 1)
				{
					timerUntilMouseFade = 4000;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)4096) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096))
				{
					actionButtonPressed = true;
					lastCursorMotionWasMouse = false;
					rightClickPolling = 250;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)16384) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)16384))
				{
					useToolButtonPressed = true;
					lastCursorMotionWasMouse = false;
				}
				if (!((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)16384) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)16384))
				{
					useToolButtonReleased = true;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)4194304) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4194304))
				{
					switchToolButtonPressed = true;
					triggerPolling = 300;
				}
				else if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)8388608) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)8388608))
				{
					switchToolButtonPressed = true;
					triggerPolling = 300;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)16384))
				{
					flag2 = true;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)4096))
				{
					rightClickPolling -= time.ElapsedGameTime.Milliseconds;
					if (rightClickPolling <= 0)
					{
						rightClickPolling = 100;
						actionButtonPressed = true;
					}
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)4194304) || ((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)8388608))
				{
					triggerPolling -= time.ElapsedGameTime.Milliseconds;
					if (triggerPolling <= 0)
					{
						triggerPolling = 100;
						switchToolButtonPressed = true;
					}
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)512) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)512) && IsHudDrawn)
				{
					player.shiftToolbar(right: true);
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)256) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)256) && IsHudDrawn)
				{
					player.shiftToolbar(right: false);
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)1) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)1))
				{
					moveUpPressed = true;
				}
				else if (!((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)1) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)1))
				{
					moveUpReleased = true;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)8) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)8))
				{
					moveRightPressed = true;
				}
				else if (!((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)8) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)8))
				{
					moveRightReleased = true;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)2) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)2))
				{
					moveDownPressed = true;
				}
				else if (!((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)2) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)2))
				{
					moveDownReleased = true;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)4) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4))
				{
					moveLeftPressed = true;
				}
				else if (!((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)4) && ((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4))
				{
					moveLeftReleased = true;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)1))
				{
					moveUpHeld = true;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)8))
				{
					moveRightHeld = true;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)2))
				{
					moveDownHeld = true;
				}
				if (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)4))
				{
					moveLeftHeld = true;
				}
				thumbSticks = ((GamePadState)(ref currentPadState)).ThumbSticks;
				if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X < -0.2)
				{
					moveLeftPressed = true;
					moveLeftHeld = true;
				}
				else
				{
					thumbSticks = ((GamePadState)(ref currentPadState)).ThumbSticks;
					if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X > 0.2)
					{
						moveRightPressed = true;
						moveRightHeld = true;
					}
				}
				thumbSticks = ((GamePadState)(ref currentPadState)).ThumbSticks;
				if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y < -0.2)
				{
					moveDownPressed = true;
					moveDownHeld = true;
				}
				else
				{
					thumbSticks = ((GamePadState)(ref currentPadState)).ThumbSticks;
					if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y > 0.2)
					{
						moveUpPressed = true;
						moveUpHeld = true;
					}
				}
				thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
				if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X < -0.2 && !moveLeftHeld)
				{
					moveLeftReleased = true;
				}
				thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
				if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X > 0.2 && !moveRightHeld)
				{
					moveRightReleased = true;
				}
				thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
				if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y < -0.2 && !moveDownHeld)
				{
					moveDownReleased = true;
				}
				thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
				if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y > 0.2 && !moveUpHeld)
				{
					moveUpReleased = true;
				}
				if (controllerSlingshotSafeTime > 0f)
				{
					if (!((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)1) && !((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)2) && !((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)4) && !((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)8))
					{
						thumbSticks = ((GamePadState)(ref currentPadState)).ThumbSticks;
						if ((double)Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.X) < 0.04)
						{
							thumbSticks = ((GamePadState)(ref currentPadState)).ThumbSticks;
							if ((double)Math.Abs(((GamePadThumbSticks)(ref thumbSticks)).Left.Y) < 0.04)
							{
								controllerSlingshotSafeTime = 0f;
							}
						}
					}
					if (controllerSlingshotSafeTime <= 0f)
					{
						controllerSlingshotSafeTime = 0f;
					}
					else
					{
						controllerSlingshotSafeTime -= (float)time.ElapsedGameTime.TotalSeconds;
						moveUpPressed = false;
						moveDownPressed = false;
						moveLeftPressed = false;
						moveRightPressed = false;
						moveUpHeld = false;
						moveDownHeld = false;
						moveLeftHeld = false;
						moveRightHeld = false;
					}
				}
			}
			else
			{
				controllerSlingshotSafeTime = 0f;
			}
			ResetFreeCursorDrag();
			if (flag2)
			{
				mouseClickPolling += time.ElapsedGameTime.Milliseconds;
			}
			else
			{
				mouseClickPolling = 0;
			}
			if (isOneOfTheseKeysDown(currentKBState, options.toolbarSwap) && areAllOfTheseKeysUp(oldKBState, options.toolbarSwap) && IsHudDrawn)
			{
				player.shiftToolbar(!((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)162));
			}
			if (mouseClickPolling > 250 && (!(player.CurrentTool is FishingRod) || player.CurrentTool.upgradeLevel.Value <= 0))
			{
				useToolButtonPressed = true;
				mouseClickPolling = 100;
			}
			PushUIMode();
			foreach (IClickableMenu onScreenMenu in onScreenMenus)
			{
				if ((IsHudDrawn || onScreenMenu == chatBox) && wasMouseVisibleThisFrame && onScreenMenu.isWithinBounds(getMouseX(), getMouseY()))
				{
					onScreenMenu.performHoverAction(getMouseX(), getMouseY());
				}
			}
			PopUIMode();
			if (chatBox != null && chatBox.chatBox.Selected && ((MouseState)(ref oldMouseState)).ScrollWheelValue != ((MouseState)(ref currentMouseState)).ScrollWheelValue)
			{
				chatBox.receiveScrollWheelAction(((MouseState)(ref currentMouseState)).ScrollWheelValue - ((MouseState)(ref oldMouseState)).ScrollWheelValue);
			}
			if (panMode)
			{
				updatePanModeControls(currentMouseState, currentKBState);
			}
			else
			{
				if (inputSimulator != null)
				{
					if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)27))
					{
						inputSimulator = null;
					}
					else
					{
						inputSimulator.SimulateInput(ref actionButtonPressed, ref switchToolButtonPressed, ref useToolButtonPressed, ref useToolButtonReleased, ref addItemToInventoryButtonPressed, ref cancelButtonPressed, ref moveUpPressed, ref moveRightPressed, ref moveLeftPressed, ref moveDownPressed, ref moveUpReleased, ref moveRightReleased, ref moveLeftReleased, ref moveDownReleased, ref moveUpHeld, ref moveRightHeld, ref moveLeftHeld, ref moveDownHeld);
					}
				}
				if (useToolButtonReleased && player.CurrentTool != null && CurrentEvent == null && pauseTime <= 0f && player.CurrentTool.onRelease(currentLocation, getMouseX(), getMouseY(), player))
				{
					oldMouseState = input.GetMouseState();
					oldKBState = currentKBState;
					oldPadState = currentPadState;
					player.usingSlingshot = false;
					player.canReleaseTool = true;
					player.UsingTool = false;
					player.CanMove = true;
				}
				else
				{
					if (((useToolButtonPressed && !isAnyGamePadButtonBeingPressed()) || (actionButtonPressed && isAnyGamePadButtonBeingPressed())) && pauseTime <= 0f && wasMouseVisibleThisFrame)
					{
						if (debugMode)
						{
							Console.WriteLine(getMouseX() + ((Rectangle)(ref viewport)).X + ", " + (getMouseY() + ((Rectangle)(ref viewport)).Y));
						}
						PushUIMode();
						foreach (IClickableMenu onScreenMenu2 in onScreenMenus)
						{
							if (IsHudDrawn || onScreenMenu2 == chatBox)
							{
								if ((!IsChatting || onScreenMenu2 == chatBox) && !(onScreenMenu2 is LevelUpMenu { informationUp: false }) && onScreenMenu2.isWithinBounds(getMouseX(), getMouseY()))
								{
									onScreenMenu2.receiveLeftClick(getMouseX(), getMouseY());
									PopUIMode();
									oldMouseState = input.GetMouseState();
									oldKBState = currentKBState;
									oldPadState = currentPadState;
									return;
								}
								if (onScreenMenu2 == chatBox && options.gamepadControls && IsChatting)
								{
									oldMouseState = input.GetMouseState();
									oldKBState = currentKBState;
									oldPadState = currentPadState;
									PopUIMode();
									return;
								}
								onScreenMenu2.clickAway();
							}
						}
						PopUIMode();
					}
					if (IsChatting || player.freezePause > 0)
					{
						if (IsChatting)
						{
							ButtonCollection.ButtonEnumerator enumerator2 = Utility.getPressedButtons(currentPadState, oldPadState).GetEnumerator();
							while (enumerator2.MoveNext())
							{
								Buttons current3 = enumerator2.Current;
								chatBox.receiveGamePadButton(current3);
							}
						}
						oldMouseState = input.GetMouseState();
						oldKBState = currentKBState;
						oldPadState = currentPadState;
					}
					else
					{
						if (paused || HostPaused)
						{
							if (!HostPaused || !IsMasterGame || (!isOneOfTheseKeysDown(currentKBState, options.menuButton) && !((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)8192) && !((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)32)))
							{
								oldMouseState = input.GetMouseState();
								return;
							}
							netWorldState.Value.IsPaused = false;
							chatBox?.globalInfoMessage("Resumed");
						}
						if (eventUp)
						{
							if (currentLocation.currentEvent == null && locationRequest == null)
							{
								eventUp = false;
							}
							else if (actionButtonPressed || useToolButtonPressed)
							{
								CurrentEvent?.receiveMouseClick(getMouseX(), getMouseY());
							}
						}
						bool flag3 = eventUp || farmEvent != null;
						if (actionButtonPressed || (dialogueUp && useToolButtonPressed))
						{
							PushUIMode();
							foreach (IClickableMenu onScreenMenu3 in onScreenMenus)
							{
								if (wasMouseVisibleThisFrame && (IsHudDrawn || onScreenMenu3 == chatBox) && onScreenMenu3.isWithinBounds(getMouseX(), getMouseY()) && !(onScreenMenu3 is LevelUpMenu { informationUp: false }))
								{
									onScreenMenu3.receiveRightClick(getMouseX(), getMouseY());
									oldMouseState = input.GetMouseState();
									if (!isAnyGamePadButtonBeingPressed())
									{
										PopUIMode();
										oldKBState = currentKBState;
										oldPadState = currentPadState;
										return;
									}
								}
							}
							PopUIMode();
							if (!pressActionButton(currentKBState, currentMouseState, currentPadState))
							{
								oldKBState = currentKBState;
								oldMouseState = input.GetMouseState();
								oldPadState = currentPadState;
								return;
							}
						}
						if (useToolButtonPressed && (!player.UsingTool || player.CurrentTool is MeleeWeapon) && !player.isEating && !dialogueUp && farmEvent == null && (player.CanMove || player.CurrentTool is MeleeWeapon))
						{
							if (player.CurrentTool != null && (!(player.CurrentTool is MeleeWeapon) || didPlayerJustLeftClick(ignoreNonMouseHeldInput: true)))
							{
								player.FireTool();
							}
							if (!pressUseToolButton() && player.canReleaseTool && player.UsingTool)
							{
								_ = player.CurrentTool;
							}
							if (player.UsingTool)
							{
								oldMouseState = input.GetMouseState();
								oldKBState = currentKBState;
								oldPadState = currentPadState;
								return;
							}
						}
						if (useToolButtonReleased && _didInitiateItemStow)
						{
							_didInitiateItemStow = false;
						}
						if (useToolButtonReleased && player.canReleaseTool && player.UsingTool && player.CurrentTool != null)
						{
							player.EndUsingTool();
						}
						if (switchToolButtonPressed && !player.UsingTool && !dialogueUp && player.CanMove && player.Items.HasAny() && !flag3)
						{
							pressSwitchToolButton();
						}
						if (player.CurrentTool != null && flag2 && player.canReleaseTool && !flag3 && !dialogueUp && player.Stamina >= 1f && !(player.CurrentTool is FishingRod))
						{
							int num3 = (player.CurrentTool.hasEnchantmentOfType<ReachingToolEnchantment>() ? 1 : 0);
							if (player.toolHold.Value <= 0 && player.CurrentTool.upgradeLevel.Value + num3 > player.toolPower.Value)
							{
								float num4 = 1f;
								if (player.CurrentTool != null)
								{
									num4 = player.CurrentTool.AnimationSpeedModifier;
								}
								player.toolHold.Value = (int)(600f * num4);
								player.toolHoldStartTime.Value = player.toolHold.Value;
							}
							else if (player.CurrentTool.upgradeLevel.Value + num3 > player.toolPower.Value)
							{
								player.toolHold.Value -= time.ElapsedGameTime.Milliseconds;
								if (player.toolHold.Value <= 0)
								{
									player.toolPowerIncrease();
								}
							}
						}
						if (upPolling >= 650f)
						{
							moveUpPressed = true;
							upPolling -= 100f;
						}
						else if (downPolling >= 650f)
						{
							moveDownPressed = true;
							downPolling -= 100f;
						}
						else if (rightPolling >= 650f)
						{
							moveRightPressed = true;
							rightPolling -= 100f;
						}
						else if (leftPolling >= 650f)
						{
							moveLeftPressed = true;
							leftPolling -= 100f;
						}
						else if (pauseTime <= 0f && locationRequest == null && (!player.UsingTool || player.canStrafeForToolUse()) && (!flag3 || (CurrentEvent != null && CurrentEvent.playerControlSequence)))
						{
							if (player.movementDirections.Count < 2)
							{
								if (moveUpHeld)
								{
									player.setMoving(1);
								}
								if (moveRightHeld)
								{
									player.setMoving(2);
								}
								if (moveDownHeld)
								{
									player.setMoving(4);
								}
								if (moveLeftHeld)
								{
									player.setMoving(8);
								}
							}
							if (moveUpReleased || (player.movementDirections.Contains(0) && !moveUpHeld))
							{
								player.setMoving(33);
								if (player.movementDirections.Count == 0)
								{
									player.setMoving(64);
								}
							}
							if (moveRightReleased || (player.movementDirections.Contains(1) && !moveRightHeld))
							{
								player.setMoving(34);
								if (player.movementDirections.Count == 0)
								{
									player.setMoving(64);
								}
							}
							if (moveDownReleased || (player.movementDirections.Contains(2) && !moveDownHeld))
							{
								player.setMoving(36);
								if (player.movementDirections.Count == 0)
								{
									player.setMoving(64);
								}
							}
							if (moveLeftReleased || (player.movementDirections.Contains(3) && !moveLeftHeld))
							{
								player.setMoving(40);
								if (player.movementDirections.Count == 0)
								{
									player.setMoving(64);
								}
							}
							if ((!moveUpHeld && !moveRightHeld && !moveDownHeld && !moveLeftHeld && !player.UsingTool) || activeClickableMenu != null)
							{
								player.Halt();
							}
						}
						else if (isQuestion)
						{
							if (moveUpPressed)
							{
								currentQuestionChoice = Math.Max(currentQuestionChoice - 1, 0);
								playSound("toolSwap");
							}
							else if (moveDownPressed)
							{
								currentQuestionChoice = Math.Min(currentQuestionChoice + 1, questionChoices.Count - 1);
								playSound("toolSwap");
							}
						}
						if (moveUpHeld && !player.CanMove)
						{
							upPolling += time.ElapsedGameTime.Milliseconds;
						}
						else if (moveDownHeld && !player.CanMove)
						{
							downPolling += time.ElapsedGameTime.Milliseconds;
						}
						else if (moveRightHeld && !player.CanMove)
						{
							rightPolling += time.ElapsedGameTime.Milliseconds;
						}
						else if (moveLeftHeld && !player.CanMove)
						{
							leftPolling += time.ElapsedGameTime.Milliseconds;
						}
						else if (moveUpReleased)
						{
							upPolling = 0f;
						}
						else if (moveDownReleased)
						{
							downPolling = 0f;
						}
						else if (moveRightReleased)
						{
							rightPolling = 0f;
						}
						else if (moveLeftReleased)
						{
							leftPolling = 0f;
						}
						if (debugMode)
						{
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)81))
							{
								((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)81);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)80) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)80))
							{
								NewDay(0f);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)77) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)77))
							{
								dayOfMonth = 28;
								NewDay(0f);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)84) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)84))
							{
								addHour();
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)89) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)89))
							{
								addMinute();
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)49) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)49))
							{
								warpFarmer("Mountain", 15, 35, flip: false);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)50) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)50))
							{
								warpFarmer("Town", 35, 35, flip: false);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)51) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)51))
							{
								warpFarmer("Farm", 64, 15, flip: false);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)52) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)52))
							{
								warpFarmer("Forest", 34, 13, flip: false);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)53) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)52))
							{
								warpFarmer("Beach", 34, 10, flip: false);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)54) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)54))
							{
								warpFarmer("Mine", 18, 12, flip: false);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)55) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)55))
							{
								warpFarmer("SandyHouse", 16, 3, flip: false);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)75) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)75))
							{
								enterMine(mine.mineLevel + 1);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)72) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)72))
							{
								player.changeHat(random.Next(FarmerRenderer.hatsTexture.Height / 80 * 12));
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)73) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)73))
							{
								player.changeHairStyle(random.Next(FarmerRenderer.hairStylesTexture.Height / 96 * 8));
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)74) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)74))
							{
								player.changeShirt(random.Next(1000, 1040).ToString());
								player.changePantsColor(new Color(random.Next(255), random.Next(255), random.Next(255)));
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)76) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)76))
							{
								player.changeShirt(random.Next(1000, 1040).ToString());
								player.changePantsColor(new Color(random.Next(255), random.Next(255), random.Next(255)));
								player.changeHairStyle(random.Next(FarmerRenderer.hairStylesTexture.Height / 96 * 8));
								if (random.NextBool())
								{
									player.changeHat(random.Next(-1, FarmerRenderer.hatsTexture.Height / 80 * 12));
								}
								else
								{
									player.changeHat(-1);
								}
								player.changeHairColor(new Color(random.Next(255), random.Next(255), random.Next(255)));
								player.changeSkinColor(random.Next(16));
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)85) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)85))
							{
								FarmHouse farmHouse = RequireLocation<FarmHouse>("FarmHouse");
								farmHouse.SetWallpaper(random.Next(112).ToString(), null);
								farmHouse.SetFloor(random.Next(40).ToString(), null);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)113))
							{
								((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)113);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)116) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)116))
							{
								displayFarmer = !displayFarmer;
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)117))
							{
								((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)117);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)118) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)118))
							{
								drawGrid = !drawGrid;
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)66) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)66) && IsHudDrawn)
							{
								player.shiftToolbar(right: false);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)78) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)78) && IsHudDrawn)
							{
								player.shiftToolbar(right: true);
							}
							if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)121) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)121) && server == null)
							{
								multiplayer.StartServer();
							}
						}
						else if (!player.UsingTool)
						{
							if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot1) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot1))
							{
								player.CurrentToolIndex = 0;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot2) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot2))
							{
								player.CurrentToolIndex = 1;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot3) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot3))
							{
								player.CurrentToolIndex = 2;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot4) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot4))
							{
								player.CurrentToolIndex = 3;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot5) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot5))
							{
								player.CurrentToolIndex = 4;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot6) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot6))
							{
								player.CurrentToolIndex = 5;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot7) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot7))
							{
								player.CurrentToolIndex = 6;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot8) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot8))
							{
								player.CurrentToolIndex = 7;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot9) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot9))
							{
								player.CurrentToolIndex = 8;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot10) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot10))
							{
								player.CurrentToolIndex = 9;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot11) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot11))
							{
								player.CurrentToolIndex = 10;
							}
							else if (isOneOfTheseKeysDown(currentKBState, options.inventorySlot12) && areAllOfTheseKeysUp(oldKBState, options.inventorySlot12))
							{
								player.CurrentToolIndex = 11;
							}
						}
						if (((options.gamepadControls && rightStickHoldTime >= emoteMenuShowTime && activeClickableMenu == null) || (isOneOfTheseKeysDown(input.GetKeyboardState(), options.emoteButton) && areAllOfTheseKeysUp(oldKBState, options.emoteButton))) && !debugMode && player.CanEmote())
						{
							if (player.CanMove)
							{
								player.Halt();
							}
							emoteMenu = new EmoteMenu();
							emoteMenu.gamepadMode = options.gamepadControls && rightStickHoldTime >= emoteMenuShowTime;
							timerUntilMouseFade = 0;
						}
						if (!Program.releaseBuild)
						{
							if (IsPressEvent(ref currentKBState, (Keys)114) || IsPressEvent(ref currentPadState, (Buttons)64))
							{
								debugMode = !debugMode;
								if (gameMode == 11)
								{
									gameMode = 3;
								}
							}
							if (IsPressEvent(ref currentKBState, (Keys)119))
							{
								requestDebugInput();
							}
						}
						if (((KeyboardState)(ref currentKBState)).IsKeyDown((Keys)115) && !((KeyboardState)(ref oldKBState)).IsKeyDown((Keys)115))
						{
							displayHUD = !displayHUD;
							playSound("smallSelect");
							if (!displayHUD)
							{
								showGlobalMessage(content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3666"));
							}
						}
						bool flag4 = isOneOfTheseKeysDown(currentKBState, options.menuButton) && areAllOfTheseKeysUp(oldKBState, options.menuButton);
						bool flag5 = isOneOfTheseKeysDown(currentKBState, options.journalButton) && areAllOfTheseKeysUp(oldKBState, options.journalButton);
						bool flag6 = isOneOfTheseKeysDown(currentKBState, options.mapButton) && areAllOfTheseKeysUp(oldKBState, options.mapButton);
						if (options.gamepadControls && !flag4)
						{
							flag4 = (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)16) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)16)) || (((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)8192) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)8192));
						}
						if (options.gamepadControls && !flag5)
						{
							flag5 = ((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)32) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)32);
						}
						if (options.gamepadControls && !flag6)
						{
							flag6 = ((GamePadState)(ref currentPadState)).IsButtonDown((Buttons)32768) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)32768);
						}
						if (flag4 && CanShowPauseMenu())
						{
							if (activeClickableMenu == null)
							{
								PushUIMode();
								activeClickableMenu = new GameMenu();
								PopUIMode();
							}
							else if (activeClickableMenu.readyToClose())
							{
								exitActiveMenu();
							}
						}
						if (dayOfMonth > 0 && player.CanMove && flag5 && !dialogueUp && !flag3)
						{
							if (activeClickableMenu == null)
							{
								activeClickableMenu = new QuestLog();
							}
						}
						else if (flag3 && CurrentEvent != null && flag5 && !CurrentEvent.skipped && CurrentEvent.skippable)
						{
							CurrentEvent.skipped = true;
							CurrentEvent.skipEvent();
							freezeControls = false;
						}
						if (options.gamepadControls && dayOfMonth > 0 && player.CanMove && isAnyGamePadButtonBeingPressed() && flag6 && !dialogueUp && !flag3)
						{
							if (activeClickableMenu == null)
							{
								PushUIMode();
								activeClickableMenu = new GameMenu(GameMenu.craftingTab);
								PopUIMode();
							}
						}
						else if (dayOfMonth > 0 && player.CanMove && flag6 && !dialogueUp && !flag3 && activeClickableMenu == null)
						{
							PushUIMode();
							activeClickableMenu = new GameMenu(GameMenu.mapTab);
							PopUIMode();
						}
						checkForRunButton(currentKBState);
						oldKBState = currentKBState;
						oldMouseState = input.GetMouseState();
						oldPadState = currentPadState;
					}
				}
			}
		});
	}

	public static bool CanShowPauseMenu()
	{
		if (dayOfMonth > 0 && player.CanMove && !dialogueUp && (!eventUp || (isFestival() && CurrentEvent.festivalTimer <= 0)) && currentMinigame == null)
		{
			return farmEvent == null;
		}
		return false;
	}

	internal static void addHour()
	{
		timeOfDay += 100;
		foreach (GameLocation location in locations)
		{
			for (int i = 0; i < location.characters.Count; i++)
			{
				NPC nPC = location.characters[i];
				nPC.checkSchedule(timeOfDay);
				nPC.checkSchedule(timeOfDay - 50);
				nPC.checkSchedule(timeOfDay - 60);
				nPC.checkSchedule(timeOfDay - 70);
				nPC.checkSchedule(timeOfDay - 80);
				nPC.checkSchedule(timeOfDay - 90);
			}
		}
		switch (timeOfDay)
		{
		case 1900:
			currentLocation.switchOutNightTiles();
			break;
		case 2000:
			if (!currentLocation.IsRainingHere())
			{
				changeMusicTrack("none", track_interruptable: false, (MusicContext)0);
			}
			break;
		}
	}

	internal static void addMinute()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		KeyboardState keyboardState = GetKeyboardState();
		if (((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)160))
		{
			timeOfDay -= 10;
		}
		else
		{
			timeOfDay += 10;
		}
		if (timeOfDay % 100 == 60)
		{
			timeOfDay += 40;
		}
		if (timeOfDay % 100 == 90)
		{
			timeOfDay -= 40;
		}
		currentLocation.performTenMinuteUpdate(timeOfDay);
		foreach (GameLocation location in locations)
		{
			for (int i = 0; i < location.characters.Count; i++)
			{
				location.characters[i].checkSchedule(timeOfDay);
			}
		}
		if (isLightning && IsMasterGame)
		{
			Utility.performLightningUpdate(timeOfDay);
		}
		switch (timeOfDay)
		{
		case 1750:
			outdoorLight = Color.White;
			break;
		case 1900:
			currentLocation.switchOutNightTiles();
			break;
		case 2000:
			if (!currentLocation.IsRainingHere())
			{
				changeMusicTrack("none", track_interruptable: false, (MusicContext)0);
			}
			break;
		}
	}

	public static void checkForRunButton(KeyboardState kbState, bool ignoreKeyPressQualifier = false)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		bool running = player.running;
		bool flag = isOneOfTheseKeysDown(kbState, options.runButton) && (!isOneOfTheseKeysDown(oldKBState, options.runButton) || ignoreKeyPressQualifier);
		bool flag2 = !isOneOfTheseKeysDown(kbState, options.runButton) && (isOneOfTheseKeysDown(oldKBState, options.runButton) || ignoreKeyPressQualifier);
		if (options.gamepadControls)
		{
			GamePadState gamePadState;
			GamePadThumbSticks thumbSticks;
			if (!options.autoRun)
			{
				gamePadState = input.GetGamePadState();
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (Math.Abs(Vector2.Distance(((GamePadThumbSticks)(ref thumbSticks)).Left, Vector2.Zero)) > 0.9f)
				{
					flag = true;
					goto IL_0112;
				}
			}
			thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
			if (Math.Abs(Vector2.Distance(((GamePadThumbSticks)(ref thumbSticks)).Left, Vector2.Zero)) > 0.9f)
			{
				gamePadState = input.GetGamePadState();
				thumbSticks = ((GamePadState)(ref gamePadState)).ThumbSticks;
				if (Math.Abs(Vector2.Distance(((GamePadThumbSticks)(ref thumbSticks)).Left, Vector2.Zero)) <= 0.9f)
				{
					flag2 = true;
				}
			}
		}
		goto IL_0112;
		IL_0112:
		if (flag && !player.canOnlyWalk)
		{
			player.setRunning(!options.autoRun);
			player.setMoving((byte)(player.running ? 16u : 48u));
		}
		else if (flag2 && !player.canOnlyWalk)
		{
			player.setRunning(options.autoRun);
			player.setMoving((byte)(player.running ? 16u : 48u));
		}
		if (player.running != running && !player.UsingTool)
		{
			player.Halt();
		}
	}

	public static Vector2 getMostRecentViewportMotion()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2((float)((Rectangle)(ref viewport)).X - previousViewportPosition.X, (float)((Rectangle)(ref viewport)).Y - previousViewportPosition.Y);
	}

	protected virtual void DrawOverlays(GameTime time, RenderTarget2D target_screen)
	{
		if (takingMapScreenshot)
		{
			return;
		}
		PushUIMode();
		spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
		if (hooks.OnRendering(RenderSteps.Overlays, spriteBatch, time, target_screen))
		{
			specialCurrencyDisplay?.Draw(spriteBatch);
			emoteMenu?.draw(spriteBatch);
			currentLocation?.drawOverlays(spriteBatch);
			if (HostPaused && !takingMapScreenshot)
			{
				string s = content.LoadString("Strings\\StringsFromCSFiles:DayTimeMoneyBox.cs.10378");
				SpriteText.drawStringWithScrollBackground(spriteBatch, s, 96, 32);
			}
			if (overlayMenu != null)
			{
				if (hooks.OnRendering(RenderSteps.Overlays_OverlayMenu, spriteBatch, time, target_screen))
				{
					overlayMenu.draw(spriteBatch);
				}
				hooks.OnRendered(RenderSteps.Overlays_OverlayMenu, spriteBatch, time, target_screen);
			}
			if (chatBox != null)
			{
				if (hooks.OnRendering(RenderSteps.Overlays_Chatbox, spriteBatch, time, target_screen))
				{
					chatBox.update(currentGameTime);
					chatBox.draw(spriteBatch);
				}
				hooks.OnRendered(RenderSteps.Overlays_Chatbox, spriteBatch, time, target_screen);
			}
			if (textEntry != null)
			{
				if (hooks.OnRendering(RenderSteps.Overlays_OnscreenKeyboard, spriteBatch, time, target_screen))
				{
					textEntry.draw(spriteBatch);
				}
				hooks.OnRendered(RenderSteps.Overlays_OnscreenKeyboard, spriteBatch, time, target_screen);
			}
			if ((displayHUD || eventUp || currentLocation is Summit) && gameMode == 3 && !freezeControls && !panMode)
			{
				drawMouseCursor();
			}
		}
		hooks.OnRendered(RenderSteps.Overlays, spriteBatch, time, target_screen);
		spriteBatch.End();
		PopUIMode();
	}

	public static void setBGColor(byte r, byte g, byte b)
	{
		((Color)(ref bgColor)).R = r;
		((Color)(ref bgColor)).G = g;
		((Color)(ref bgColor)).B = b;
	}

	public void Instance_Draw(GameTime gameTime)
	{
		Draw(gameTime);
	}

	protected override void Draw(GameTime gameTime)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		isDrawing = true;
		RenderTarget2D val = null;
		if (ShouldDrawOnBuffer())
		{
			val = screen;
		}
		if (uiScreen != null)
		{
			SetRenderTarget(uiScreen);
			base.GraphicsDevice.Clear(Color.Transparent);
			SetRenderTarget(val);
		}
		GameTime time = gameTime;
		DebugTools.BeforeGameDraw(this, ref time);
		_draw(time, val);
		isRenderingScreenBuffer = true;
		renderScreenBuffer(val);
		isRenderingScreenBuffer = false;
		if (uiModeCount != 0)
		{
			log.Warn("WARNING: Mismatched UI Mode Push/Pop counts. Correcting.");
			while (uiModeCount < 0)
			{
				PushUIMode();
			}
			while (uiModeCount > 0)
			{
				PopUIMode();
			}
		}
		base.Draw(gameTime);
		isDrawing = false;
	}

	public virtual bool ShouldDrawOnBuffer()
	{
		if (LocalMultiplayer.IsLocalMultiplayer())
		{
			return true;
		}
		if (options.zoomLevel != 1f)
		{
			return true;
		}
		return false;
	}

	public static bool ShouldShowOnscreenUsernames()
	{
		return false;
	}

	public virtual bool checkCharacterTilesForShadowDrawFlag(Character character)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		if (character is Farmer farmer && farmer.onBridge.Value)
		{
			return true;
		}
		Rectangle boundingBox = character.GetBoundingBox();
		boundingBox.Height += 8;
		int num = ((Rectangle)(ref boundingBox)).Right / 64;
		int num2 = ((Rectangle)(ref boundingBox)).Bottom / 64;
		int num3 = ((Rectangle)(ref boundingBox)).Left / 64;
		int num4 = ((Rectangle)(ref boundingBox)).Top / 64;
		for (int i = num3; i <= num; i++)
		{
			for (int j = num4; j <= num2; j++)
			{
				if (currentLocation.shouldShadowBeDrawnAboveBuildingsLayer(new Vector2((float)i, (float)j)))
				{
					return true;
				}
			}
		}
		return false;
	}

	protected virtual void _draw(GameTime gameTime, RenderTarget2D target_screen)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		debugTimings.StartDrawTimer();
		showingHealthBar = false;
		if (_newDayTask != null || isLocalMultiplayerNewDayActive || ShouldLoadIncrementally)
		{
			base.GraphicsDevice.Clear(bgColor);
			return;
		}
		if (target_screen != null)
		{
			SetRenderTarget(target_screen);
		}
		if (IsSaving)
		{
			base.GraphicsDevice.Clear(bgColor);
			DrawMenu(gameTime, target_screen);
			PushUIMode();
			if (overlayMenu != null)
			{
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
				overlayMenu.draw(spriteBatch);
				spriteBatch.End();
			}
			PopUIMode();
			return;
		}
		base.GraphicsDevice.Clear(bgColor);
		if (hooks.OnRendering(RenderSteps.FullScene, spriteBatch, gameTime, target_screen))
		{
			if (gameMode == 11)
			{
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
				spriteBatch.DrawString(dialogueFont, content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3685"), new Vector2(16f, 16f), Color.HotPink);
				spriteBatch.DrawString(dialogueFont, content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3686"), new Vector2(16f, 32f), new Color(0, 255, 0));
				SpriteBatch obj = spriteBatch;
				SpriteFont obj2 = dialogueFont;
				string text = errorMessage;
				SpriteFont whichFont = dialogueFont;
				Viewport val = graphics.GraphicsDevice.Viewport;
				obj.DrawString(obj2, parseText(text, whichFont, ((Viewport)(ref val)).Width), new Vector2(16f, 48f), Color.White);
				spriteBatch.End();
				return;
			}
			bool flag = true;
			if (activeClickableMenu != null && options.showMenuBackground && activeClickableMenu.showWithoutTransparencyIfOptionIsSet() && !takingMapScreenshot)
			{
				PushUIMode();
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
				if (hooks.OnRendering(RenderSteps.MenuBackground, spriteBatch, gameTime, target_screen))
				{
					activeClickableMenu.drawBackground(spriteBatch);
					flag = false;
				}
				hooks.OnRendered(RenderSteps.MenuBackground, spriteBatch, gameTime, target_screen);
				spriteBatch.End();
				PopUIMode();
			}
			if (currentMinigame != null)
			{
				if (hooks.OnRendering(RenderSteps.Minigame, spriteBatch, gameTime, target_screen))
				{
					currentMinigame.draw(spriteBatch);
					flag = false;
				}
				hooks.OnRendered(RenderSteps.Minigame, spriteBatch, gameTime, target_screen);
			}
			if (gameMode == 6 || (gameMode == 3 && currentLocation == null))
			{
				if (hooks.OnRendering(RenderSteps.LoadingScreen, spriteBatch, gameTime, target_screen))
				{
					DrawLoadScreen(gameTime, target_screen);
				}
				hooks.OnRendered(RenderSteps.LoadingScreen, spriteBatch, gameTime, target_screen);
				flag = false;
			}
			if (showingEndOfNightStuff)
			{
				flag = false;
			}
			else if (gameMode == 0)
			{
				flag = false;
			}
			if (gameMode == 3 && dayOfMonth == 0 && newDay)
			{
				base.Draw(gameTime);
				return;
			}
			if (flag)
			{
				DrawWorld(gameTime, target_screen);
				PushUIMode();
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
				if (hooks.OnRendering(RenderSteps.HUD, spriteBatch, gameTime, target_screen))
				{
					if (IsHudDrawn)
					{
						drawHUD();
					}
					if (hudMessages.Count > 0 && !takingMapScreenshot)
					{
						int heightUsed = 0;
						for (int num = hudMessages.Count - 1; num >= 0; num--)
						{
							hudMessages[num].draw(spriteBatch, num, ref heightUsed);
						}
					}
				}
				hooks.OnRendered(RenderSteps.HUD, spriteBatch, gameTime, target_screen);
				debugTimings.Draw();
				spriteBatch.End();
				PopUIMode();
			}
			bool flag2 = false;
			if (!takingMapScreenshot)
			{
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
				PushUIMode();
				if ((messagePause || globalFade) && dialogueUp)
				{
					flag2 = true;
				}
				else if (dialogueUp && !messagePause && (activeClickableMenu == null || !(activeClickableMenu is DialogueBox)))
				{
					if (hooks.OnRendering(RenderSteps.DialogueBox, spriteBatch, gameTime, target_screen))
					{
						drawDialogueBox();
					}
					hooks.OnRendered(RenderSteps.DialogueBox, spriteBatch, gameTime, target_screen);
				}
				spriteBatch.End();
				PopUIMode();
				DrawGlobalFade(gameTime, target_screen);
				if (flag2)
				{
					spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
					PushUIMode();
					if (hooks.OnRendering(RenderSteps.DialogueBox, spriteBatch, gameTime, target_screen))
					{
						drawDialogueBox();
					}
					hooks.OnRendered(RenderSteps.DialogueBox, spriteBatch, gameTime, target_screen);
					spriteBatch.End();
					PopUIMode();
				}
				DrawScreenOverlaySprites(gameTime, target_screen);
				if (debugMode)
				{
					DrawDebugUIs(gameTime, target_screen);
				}
				DrawMenu(gameTime, target_screen);
			}
			farmEvent?.drawAboveEverything(spriteBatch);
			DrawOverlays(gameTime, target_screen);
		}
		hooks.OnRendered(RenderSteps.FullScene, spriteBatch, gameTime, target_screen);
		debugTimings.StopDrawTimer();
	}

	public virtual void DrawLoadScreen(GameTime time, RenderTarget2D target_screen)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		PushUIMode();
		base.GraphicsDevice.Clear(bgColor);
		spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
		string text = "".PadRight((int)Math.Ceiling(time.TotalGameTime.TotalMilliseconds % 999.0 / 333.0), '.');
		string text2 = content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3688");
		string s = text2 + text;
		string text3 = text2 + "... ";
		int widthOfString = SpriteText.getWidthOfString(text3);
		int num = 64;
		int x = 64;
		Rectangle titleSafeArea = graphics.GraphicsDevice.Viewport.GetTitleSafeArea();
		int y = ((Rectangle)(ref titleSafeArea)).Bottom - num;
		SpriteText.drawString(spriteBatch, s, x, y, 999999, widthOfString, num, 1f, 0.88f, junimoText: false, 0, text3);
		spriteBatch.End();
		PopUIMode();
	}

	public virtual void DrawMenu(GameTime time, RenderTarget2D target_screen)
	{
		PushUIMode();
		spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
		if (hooks.OnRendering(RenderSteps.Menu, spriteBatch, time, target_screen))
		{
			IClickableMenu menu = activeClickableMenu;
			while (menu != null && hooks.TryDrawMenu(menu, delegate
			{
				menu.draw(spriteBatch);
			}))
			{
				menu = menu.GetChildMenu();
			}
		}
		hooks.OnRendered(RenderSteps.Menu, spriteBatch, time, target_screen);
		spriteBatch.End();
		PopUIMode();
	}

	public virtual void DrawScreenOverlaySprites(GameTime time, RenderTarget2D target_screen)
	{
		if (hooks.OnRendering(RenderSteps.OverlayTemporarySprites, spriteBatch, time, target_screen))
		{
			spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			foreach (TemporaryAnimatedSprite screenOverlayTempSprite in screenOverlayTempSprites)
			{
				screenOverlayTempSprite.draw(spriteBatch, localPosition: true);
			}
			spriteBatch.End();
			PushUIMode();
			spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			foreach (TemporaryAnimatedSprite uiOverlayTempSprite in uiOverlayTempSprites)
			{
				uiOverlayTempSprite.draw(spriteBatch, localPosition: true);
			}
			spriteBatch.End();
			PopUIMode();
		}
		hooks.OnRendered(RenderSteps.OverlayTemporarySprites, spriteBatch, time, target_screen);
	}

	public virtual void DrawWorld(GameTime time, RenderTarget2D target_screen)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ace: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a90: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a95: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa4: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0702: Unknown result type (might be due to invalid IL or missing references)
		//IL_070a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0712: Unknown result type (might be due to invalid IL or missing references)
		//IL_0725: Unknown result type (might be due to invalid IL or missing references)
		//IL_072a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0731: Unknown result type (might be due to invalid IL or missing references)
		//IL_0736: Unknown result type (might be due to invalid IL or missing references)
		//IL_073b: Unknown result type (might be due to invalid IL or missing references)
		//IL_073f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0747: Unknown result type (might be due to invalid IL or missing references)
		//IL_075b: Unknown result type (might be due to invalid IL or missing references)
		//IL_075d: Unknown result type (might be due to invalid IL or missing references)
		//IL_083b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0840: Unknown result type (might be due to invalid IL or missing references)
		//IL_084a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e5a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e5f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e63: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c53: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c58: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c66: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cfe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d03: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d23: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d28: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d41: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d89: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dde: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e85: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e8f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e76: Unknown result type (might be due to invalid IL or missing references)
		//IL_092f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0934: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fb9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fc2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fc7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd1: Unknown result type (might be due to invalid IL or missing references)
		//IL_110e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1113: Unknown result type (might be due to invalid IL or missing references)
		//IL_1117: Unknown result type (might be due to invalid IL or missing references)
		//IL_111c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1130: Unknown result type (might be due to invalid IL or missing references)
		//IL_105b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1060: Unknown result type (might be due to invalid IL or missing references)
		//IL_101d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1022: Unknown result type (might be due to invalid IL or missing references)
		//IL_102c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1031: Unknown result type (might be due to invalid IL or missing references)
		//IL_103b: Unknown result type (might be due to invalid IL or missing references)
		if (hooks.OnRendering(RenderSteps.World, spriteBatch, time, target_screen))
		{
			mapDisplayDevice.BeginScene(spriteBatch);
			if (drawLighting)
			{
				DrawLighting(time, target_screen);
			}
			base.GraphicsDevice.Clear(bgColor);
			spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			if (hooks.OnRendering(RenderSteps.World_Background, spriteBatch, time, target_screen))
			{
				background?.draw(spriteBatch);
				currentLocation.drawBackground(spriteBatch);
				spriteBatch.End();
				for (int i = 0; i < currentLocation.backgroundLayers.Count; i++)
				{
					spriteBatch.Begin((SpriteSortMode)2, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
					currentLocation.backgroundLayers[i].Key.Draw(mapDisplayDevice, viewport, Location.Origin, false, 4, -1f);
					spriteBatch.End();
				}
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
				currentLocation.drawWater(spriteBatch);
				spriteBatch.End();
				spriteBatch.Begin((SpriteSortMode)4, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
				currentLocation.drawFloorDecorations(spriteBatch);
				spriteBatch.End();
			}
			hooks.OnRendered(RenderSteps.World_Background, spriteBatch, time, target_screen);
			spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			_farmerShadows.Clear();
			if (currentLocation.currentEvent != null && !currentLocation.currentEvent.isFestival && currentLocation.currentEvent.farmerActors.Count > 0)
			{
				foreach (Farmer farmerActor in currentLocation.currentEvent.farmerActors)
				{
					if ((farmerActor.IsLocalPlayer && displayFarmer) || !farmerActor.hidden.Value)
					{
						_farmerShadows.Add(farmerActor);
					}
				}
			}
			else
			{
				foreach (Farmer farmer in currentLocation.farmers)
				{
					if ((farmer.IsLocalPlayer && displayFarmer) || !farmer.hidden.Value)
					{
						_farmerShadows.Add(farmer);
					}
				}
			}
			if (!currentLocation.shouldHideCharacters())
			{
				if (CurrentEvent == null)
				{
					foreach (NPC character in currentLocation.characters)
					{
						if (!character.swimming.Value && !character.HideShadow && !character.IsInvisible && !checkCharacterTilesForShadowDrawFlag(character))
						{
							character.DrawShadow(spriteBatch);
						}
					}
				}
				else
				{
					foreach (NPC actor in CurrentEvent.actors)
					{
						if ((CurrentEvent == null || !CurrentEvent.ShouldHideCharacter(actor)) && !actor.swimming.Value && !actor.HideShadow && !checkCharacterTilesForShadowDrawFlag(actor))
						{
							actor.DrawShadow(spriteBatch);
						}
					}
				}
				foreach (Farmer farmerShadow in _farmerShadows)
				{
					if (!multiplayer.isDisconnecting(farmerShadow.UniqueMultiplayerID) && !farmerShadow.swimming.Value && !farmerShadow.isRidingHorse() && !farmerShadow.IsSitting() && (currentLocation == null || !checkCharacterTilesForShadowDrawFlag(farmerShadow)))
					{
						farmerShadow.DrawShadow(spriteBatch);
					}
				}
			}
			float num = 0.1f;
			for (int j = 0; j < currentLocation.buildingLayers.Count; j++)
			{
				float num2 = 0f;
				if (currentLocation.buildingLayers.Count > 1)
				{
					num2 = (float)j / (float)(currentLocation.buildingLayers.Count - 1);
				}
				currentLocation.buildingLayers[j].Key.Draw(mapDisplayDevice, viewport, Location.Origin, false, 4, num * num2);
			}
			Layer val = currentLocation.Map.RequireLayer("Buildings");
			spriteBatch.End();
			spriteBatch.Begin((SpriteSortMode)4, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			if (hooks.OnRendering(RenderSteps.World_Sorted, spriteBatch, time, target_screen))
			{
				if (!currentLocation.shouldHideCharacters())
				{
					if (CurrentEvent == null)
					{
						foreach (NPC character2 in currentLocation.characters)
						{
							if (!character2.swimming.Value && !character2.HideShadow && !character2.isInvisible.Value && checkCharacterTilesForShadowDrawFlag(character2))
							{
								character2.DrawShadow(spriteBatch);
							}
						}
					}
					else
					{
						foreach (NPC actor2 in CurrentEvent.actors)
						{
							if ((CurrentEvent == null || !CurrentEvent.ShouldHideCharacter(actor2)) && !actor2.swimming.Value && !actor2.HideShadow && checkCharacterTilesForShadowDrawFlag(actor2))
							{
								actor2.DrawShadow(spriteBatch);
							}
						}
					}
					foreach (Farmer farmerShadow2 in _farmerShadows)
					{
						if (!farmerShadow2.swimming.Value && !farmerShadow2.isRidingHorse() && !farmerShadow2.IsSitting() && currentLocation != null && checkCharacterTilesForShadowDrawFlag(farmerShadow2))
						{
							farmerShadow2.DrawShadow(spriteBatch);
						}
					}
				}
				if ((eventUp || killScreen) && !killScreen && currentLocation.currentEvent != null)
				{
					currentLocation.currentEvent.draw(spriteBatch);
				}
				currentLocation.draw(spriteBatch);
				Location val4 = default(Location);
				foreach (Vector2 key in crabPotOverlayTiles.Keys)
				{
					Tile val2 = val.Tiles[(int)key.X, (int)key.Y];
					if (val2 != null)
					{
						Vector2 val3 = GlobalToLocal(viewport, key * 64f);
						((Location)(ref val4))._002Ector((int)val3.X, (int)val3.Y);
						mapDisplayDevice.DrawTile(val2, val4, (key.Y * 64f - 1f) / 10000f);
					}
				}
				if (player.ActiveObject == null && player.UsingTool && player.CurrentTool != null)
				{
					drawTool(player);
				}
				if (panMode)
				{
					spriteBatch.Draw(fadeToBlackRect, new Rectangle((int)Math.Floor((double)(getOldMouseX() + ((Rectangle)(ref viewport)).X) / 64.0) * 64 - ((Rectangle)(ref viewport)).X, (int)Math.Floor((double)(getOldMouseY() + ((Rectangle)(ref viewport)).Y) / 64.0) * 64 - ((Rectangle)(ref viewport)).Y, 64, 64), Color.Lime * 0.75f);
					foreach (Warp warp in currentLocation.warps)
					{
						spriteBatch.Draw(fadeToBlackRect, new Rectangle(warp.X * 64 - ((Rectangle)(ref viewport)).X, warp.Y * 64 - ((Rectangle)(ref viewport)).Y, 64, 64), Color.Red * 0.75f);
					}
				}
				for (int k = 0; k < currentLocation.frontLayers.Count; k++)
				{
					float num3 = 0f;
					if (currentLocation.frontLayers.Count > 1)
					{
						num3 = (float)k / (float)(currentLocation.frontLayers.Count - 1);
					}
					currentLocation.frontLayers[k].Key.Draw(mapDisplayDevice, viewport, Location.Origin, false, 4, 64f + num * num3);
				}
				currentLocation.drawAboveFrontLayer(spriteBatch);
			}
			hooks.OnRendered(RenderSteps.World_Sorted, spriteBatch, time, target_screen);
			spriteBatch.End();
			if (hooks.OnRendering(RenderSteps.World_AlwaysFront, spriteBatch, time, target_screen))
			{
				for (int l = 0; l < currentLocation.alwaysFrontLayers.Count; l++)
				{
					spriteBatch.Begin((SpriteSortMode)2, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
					currentLocation.alwaysFrontLayers[l].Key.Draw(mapDisplayDevice, viewport, Location.Origin, false, 4, -1f);
					spriteBatch.End();
				}
			}
			hooks.OnRendered(RenderSteps.World_AlwaysFront, spriteBatch, time, target_screen);
			spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			Viewport val5;
			if (currentLocation.LightLevel > 0f && timeOfDay < 2000)
			{
				SpriteBatch obj = spriteBatch;
				Texture2D obj2 = fadeToBlackRect;
				val5 = graphics.GraphicsDevice.Viewport;
				obj.Draw(obj2, ((Viewport)(ref val5)).Bounds, Color.Black * currentLocation.LightLevel);
			}
			if (screenGlow)
			{
				SpriteBatch obj3 = spriteBatch;
				Texture2D obj4 = fadeToBlackRect;
				val5 = graphics.GraphicsDevice.Viewport;
				obj3.Draw(obj4, ((Viewport)(ref val5)).Bounds, screenGlowColor * screenGlowAlpha);
			}
			spriteBatch.End();
			spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			currentLocation.drawAboveAlwaysFrontLayer(spriteBatch);
			if (!IsFakedBlackScreen())
			{
				spriteBatch.End();
				drawWeather(time, target_screen);
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			}
			if (player.CurrentTool is FishingRod fishingRod && (fishingRod.isTimingCast || fishingRod.castingChosenCountdown > 0f || fishingRod.fishCaught || fishingRod.showingTreasure))
			{
				player.CurrentTool.draw(spriteBatch);
			}
			spriteBatch.End();
			DrawCharacterEmotes(time, target_screen);
			mapDisplayDevice.EndScene();
			if (drawLighting && !IsFakedBlackScreen())
			{
				DrawLightmapOnScreen(time, target_screen);
			}
			if (!eventUp && farmEvent == null && gameMode == 3 && !takingMapScreenshot && isOutdoorMapSmallerThanViewport())
			{
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
				SpriteBatch obj5 = spriteBatch;
				Texture2D obj6 = fadeToBlackRect;
				int num4 = -((Rectangle)(ref viewport)).X;
				val5 = graphics.GraphicsDevice.Viewport;
				obj5.Draw(obj6, new Rectangle(0, 0, num4, ((Viewport)(ref val5)).Height), Color.Black);
				SpriteBatch obj7 = spriteBatch;
				Texture2D obj8 = fadeToBlackRect;
				int num5 = -((Rectangle)(ref viewport)).X + currentLocation.map.Layers[0].LayerWidth * 64;
				val5 = graphics.GraphicsDevice.Viewport;
				int num6 = ((Viewport)(ref val5)).Width - (-((Rectangle)(ref viewport)).X + currentLocation.map.Layers[0].LayerWidth * 64);
				val5 = graphics.GraphicsDevice.Viewport;
				obj7.Draw(obj8, new Rectangle(num5, 0, num6, ((Viewport)(ref val5)).Height), Color.Black);
				SpriteBatch obj9 = spriteBatch;
				Texture2D obj10 = fadeToBlackRect;
				val5 = graphics.GraphicsDevice.Viewport;
				obj9.Draw(obj10, new Rectangle(0, 0, ((Viewport)(ref val5)).Width, -((Rectangle)(ref viewport)).Y), Color.Black);
				SpriteBatch obj11 = spriteBatch;
				Texture2D obj12 = fadeToBlackRect;
				int num7 = -((Rectangle)(ref viewport)).Y + currentLocation.map.Layers[0].LayerHeight * 64;
				val5 = graphics.GraphicsDevice.Viewport;
				int width = ((Viewport)(ref val5)).Width;
				val5 = graphics.GraphicsDevice.Viewport;
				obj11.Draw(obj12, new Rectangle(0, num7, width, ((Viewport)(ref val5)).Height - (-((Rectangle)(ref viewport)).Y + currentLocation.map.Layers[0].LayerHeight * 64)), Color.Black);
				spriteBatch.End();
			}
			spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			if (currentLocation != null && currentLocation.isOutdoors.Value && !IsFakedBlackScreen() && currentLocation.IsRainingHere())
			{
				bool flag = IsGreenRainingHere();
				SpriteBatch obj13 = spriteBatch;
				Texture2D obj14 = staminaRect;
				val5 = graphics.GraphicsDevice.Viewport;
				obj13.Draw(obj14, ((Viewport)(ref val5)).Bounds, flag ? (new Color(0, 120, 150) * 0.22f) : (Color.Blue * 0.2f));
			}
			spriteBatch.End();
			if (farmEvent != null)
			{
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
				farmEvent.draw(spriteBatch);
				spriteBatch.End();
			}
			if (eventUp && currentLocation?.currentEvent != null)
			{
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
				currentLocation.currentEvent.drawAfterMap(spriteBatch);
				spriteBatch.End();
			}
			if (!takingMapScreenshot)
			{
				if (drawGrid)
				{
					spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
					int num8 = -((Rectangle)(ref viewport)).X % 64;
					float num9 = -((Rectangle)(ref viewport)).Y % 64;
					int num10 = num8;
					while (true)
					{
						int num11 = num10;
						val5 = graphics.GraphicsDevice.Viewport;
						if (num11 >= ((Viewport)(ref val5)).Width)
						{
							break;
						}
						SpriteBatch obj15 = spriteBatch;
						Texture2D obj16 = staminaRect;
						int num12 = num10;
						int num13 = (int)num9;
						val5 = graphics.GraphicsDevice.Viewport;
						obj15.Draw(obj16, new Rectangle(num12, num13, 1, ((Viewport)(ref val5)).Height), Color.Red * 0.5f);
						num10 += 64;
					}
					float num14 = num9;
					while (true)
					{
						float num15 = num14;
						val5 = graphics.GraphicsDevice.Viewport;
						if (!(num15 < (float)((Viewport)(ref val5)).Height))
						{
							break;
						}
						SpriteBatch obj17 = spriteBatch;
						Texture2D obj18 = staminaRect;
						int num16 = (int)num14;
						val5 = graphics.GraphicsDevice.Viewport;
						obj17.Draw(obj18, new Rectangle(num8, num16, ((Viewport)(ref val5)).Width, 1), Color.Red * 0.5f);
						num14 += 64f;
					}
					spriteBatch.End();
				}
				if (ShouldShowOnscreenUsernames() && currentLocation != null)
				{
					spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
					currentLocation.DrawFarmerUsernames(spriteBatch);
					spriteBatch.End();
				}
				if (flashAlpha > 0f)
				{
					if (options.screenFlash)
					{
						spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
						SpriteBatch obj19 = spriteBatch;
						Texture2D obj20 = fadeToBlackRect;
						val5 = graphics.GraphicsDevice.Viewport;
						obj19.Draw(obj20, ((Viewport)(ref val5)).Bounds, Color.White * Math.Min(1f, flashAlpha));
						spriteBatch.End();
					}
					flashAlpha -= 0.1f;
				}
			}
		}
		hooks.OnRendered(RenderSteps.World, spriteBatch, time, target_screen);
	}

	public virtual void DrawCharacterEmotes(GameTime time, RenderTarget2D target_screen)
	{
		if (!eventUp || currentLocation.currentEvent == null)
		{
			return;
		}
		spriteBatch.Begin((SpriteSortMode)4, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
		foreach (NPC actor in currentLocation.currentEvent.actors)
		{
			actor.DrawEmote(spriteBatch);
		}
		spriteBatch.End();
	}

	public virtual void DrawLightmapOnScreen(GameTime time, RenderTarget2D target_screen)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		if (hooks.OnRendering(RenderSteps.World_DrawLightmapOnScreen, spriteBatch, time, target_screen))
		{
			spriteBatch.Begin((SpriteSortMode)0, lightingBlend, SamplerState.LinearClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			Viewport val = base.GraphicsDevice.Viewport;
			((Viewport)(ref val)).Bounds = ((target_screen != null) ? ((Texture2D)target_screen).Bounds : base.GraphicsDevice.PresentationParameters.Bounds);
			base.GraphicsDevice.Viewport = val;
			float num = options.lightingQuality / 2;
			if (useUnscaledLighting)
			{
				num /= options.zoomLevel;
			}
			spriteBatch.Draw((Texture2D)(object)lightmap, Vector2.Zero, (Rectangle?)((Texture2D)lightmap).Bounds, Color.White, 0f, Vector2.Zero, num, (SpriteEffects)0, 1f);
			if (currentLocation.isOutdoors.Value && currentLocation.IsRainingHere())
			{
				spriteBatch.Draw(lightingRect, ((Viewport)(ref val)).Bounds, Color.OrangeRed * 0.45f);
			}
		}
		hooks.OnRendered(RenderSteps.World_DrawLightmapOnScreen, spriteBatch, time, target_screen);
		spriteBatch.End();
	}

	public virtual void DrawDebugUIs(GameTime time, RenderTarget2D target_screen)
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		StringBuilder debugStringBuilder = _debugStringBuilder;
		debugStringBuilder.Clear();
		if (panMode)
		{
			debugStringBuilder.Append((getOldMouseX() + ((Rectangle)(ref viewport)).X) / 64);
			debugStringBuilder.Append(",");
			debugStringBuilder.Append((getOldMouseY() + ((Rectangle)(ref viewport)).Y) / 64);
		}
		else
		{
			Point standingPixel = player.StandingPixel;
			debugStringBuilder.Append("player: ");
			debugStringBuilder.Append(standingPixel.X / 64);
			debugStringBuilder.Append(", ");
			debugStringBuilder.Append(standingPixel.Y / 64);
		}
		debugStringBuilder.Append(" mouseTransparency: ");
		debugStringBuilder.Append(mouseCursorTransparency);
		debugStringBuilder.Append(" mousePosition: ");
		debugStringBuilder.Append(getMouseX());
		debugStringBuilder.Append(",");
		debugStringBuilder.Append(getMouseY());
		debugStringBuilder.Append(Environment.NewLine);
		debugStringBuilder.Append(" mouseWorldPosition: ");
		debugStringBuilder.Append(getMouseX() + ((Rectangle)(ref viewport)).X);
		debugStringBuilder.Append(",");
		debugStringBuilder.Append(getMouseY() + ((Rectangle)(ref viewport)).Y);
		debugStringBuilder.Append("  debugOutput: ");
		debugStringBuilder.Append(debugOutput);
		PushUIMode();
		spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
		spriteBatch.DrawString(smallFont, debugStringBuilder, new Vector2((float)base.GraphicsDevice.Viewport.GetTitleSafeArea().X, (float)(base.GraphicsDevice.Viewport.GetTitleSafeArea().Y + smallFont.LineSpacing * 8)), Color.Red, 0f, Vector2.Zero, 1f, (SpriteEffects)0, 0.9999999f);
		spriteBatch.End();
		PopUIMode();
	}

	public virtual void DrawGlobalFade(GameTime time, RenderTarget2D target_screen)
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		if ((fadeToBlack || globalFade) && !takingMapScreenshot)
		{
			PushUIMode();
			spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			if (hooks.OnRendering(RenderSteps.GlobalFade, spriteBatch, time, target_screen))
			{
				SpriteBatch obj = spriteBatch;
				Texture2D obj2 = fadeToBlackRect;
				Viewport val = graphics.GraphicsDevice.Viewport;
				obj.Draw(obj2, ((Viewport)(ref val)).Bounds, Color.Black * ((gameMode == 0) ? (1f - fadeToBlackAlpha) : fadeToBlackAlpha));
			}
			hooks.OnRendered(RenderSteps.GlobalFade, spriteBatch, time, target_screen);
			spriteBatch.End();
			PopUIMode();
		}
	}

	public virtual void DrawLighting(GameTime time, RenderTarget2D target_screen)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		SetRenderTarget(lightmap);
		base.GraphicsDevice.Clear(Color.White * 0f);
		Matrix value = Matrix.Identity;
		if (useUnscaledLighting)
		{
			value = Matrix.CreateScale(options.zoomLevel);
		}
		spriteBatch.Begin((SpriteSortMode)0, BlendState.NonPremultiplied, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)value);
		if (hooks.OnRendering(RenderSteps.World_RenderLightmap, spriteBatch, time, target_screen))
		{
			Color val = ((!(currentLocation is MineShaft mineShaft)) ? ((((Color)(ref ambientLight)).Equals(Color.White) || (currentLocation.isOutdoors.Value && currentLocation.IsRainingHere())) ? outdoorLight : ambientLight) : mineShaft.getLightingColor(time));
			float lightMultiplier = 1f;
			if (player.hasBuff("26"))
			{
				if (val == Color.White)
				{
					((Color)(ref val))._002Ector(0.75f, 0.75f, 0.75f);
				}
				else
				{
					((Color)(ref val)).R = (byte)Utility.Lerp((int)((Color)(ref val)).R, 255f, 0.5f);
					((Color)(ref val)).G = (byte)Utility.Lerp((int)((Color)(ref val)).G, 255f, 0.5f);
					((Color)(ref val)).B = (byte)Utility.Lerp((int)((Color)(ref val)).B, 255f, 0.5f);
				}
				lightMultiplier = 0.33f;
			}
			if (IsGreenRainingHere())
			{
				((Color)(ref val)).R = (byte)Utility.Lerp((int)((Color)(ref val)).R, 255f, 0.25f);
				((Color)(ref val)).G = (byte)Utility.Lerp((int)((Color)(ref val)).R, 0f, 0.25f);
			}
			spriteBatch.Draw(staminaRect, ((Texture2D)lightmap).Bounds, val);
			foreach (KeyValuePair<string, LightSource> currentLightSource in currentLightSources)
			{
				currentLightSource.Value.Draw(spriteBatch, currentLocation, lightMultiplier);
			}
		}
		hooks.OnRendered(RenderSteps.World_RenderLightmap, spriteBatch, time, target_screen);
		spriteBatch.End();
		SetRenderTarget(target_screen);
	}

	public virtual void drawWeather(GameTime time, RenderTarget2D target_screen)
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_036f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0376: Unknown result type (might be due to invalid IL or missing references)
		spriteBatch.Begin((SpriteSortMode)2, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
		if (hooks.OnRendering(RenderSteps.World_Weather, spriteBatch, time, target_screen) && currentLocation.IsOutdoors)
		{
			if (currentLocation.IsSnowingHere())
			{
				snowPos.X %= 64f;
				Vector2 val = default(Vector2);
				for (float num = -64f + snowPos.X % 64f; num < (float)((Rectangle)(ref viewport)).Width; num += 64f)
				{
					for (float num2 = -64f + snowPos.Y % 64f; num2 < (float)((Rectangle)(ref viewport)).Height; num2 += 64f)
					{
						val.X = (int)num;
						val.Y = (int)num2;
						spriteBatch.Draw(mouseCursors, val, (Rectangle?)new Rectangle(368 + (int)(currentGameTime.TotalGameTime.TotalMilliseconds % 1200.0) / 75 * 16, 192, 16, 16), Color.White * 0.8f * options.snowTransparency, 0f, Vector2.Zero, 4.001f, (SpriteEffects)0, 1f);
					}
				}
			}
			if (!currentLocation.ignoreDebrisWeather.Value && currentLocation.IsDebrisWeatherHere())
			{
				if (takingMapScreenshot)
				{
					if (debrisWeather != null)
					{
						foreach (WeatherDebris item in debrisWeather)
						{
							Vector2 position = item.position;
							item.position = new Vector2((float)random.Next(((Rectangle)(ref viewport)).Width - item.sourceRect.Width * 3), (float)random.Next(((Rectangle)(ref viewport)).Height - item.sourceRect.Height * 3));
							item.draw(spriteBatch);
							item.position = position;
						}
					}
				}
				else if (((Rectangle)(ref viewport)).X > -((Rectangle)(ref viewport)).Width)
				{
					foreach (WeatherDebris item2 in debrisWeather)
					{
						item2.draw(spriteBatch);
					}
				}
			}
			if (currentLocation.IsRainingHere() && !(currentLocation is Summit) && (!eventUp || currentLocation.isTileOnMap(new Vector2((float)(((Rectangle)(ref viewport)).X / 64), (float)(((Rectangle)(ref viewport)).Y / 64)))))
			{
				bool flag = IsGreenRainingHere();
				Color val2 = (flag ? Color.LimeGreen : Color.White);
				int num3 = ((!flag) ? 1 : 2);
				for (int i = 0; i < rainDrops.Length; i++)
				{
					for (int j = 0; j < num3; j++)
					{
						spriteBatch.Draw(rainTexture, rainDrops[i].position, (Rectangle?)getSourceRectForStandardTileSheet(rainTexture, rainDrops[i].frame + (flag ? 4 : 0), 16, 16), val2, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
					}
				}
			}
		}
		hooks.OnRendered(RenderSteps.World_Weather, spriteBatch, time, target_screen);
		spriteBatch.End();
	}

	protected virtual void renderScreenBuffer(RenderTarget2D target_screen)
	{
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		graphics.GraphicsDevice.SetRenderTarget((RenderTarget2D)null);
		if (!takingMapScreenshot && !LocalMultiplayer.IsLocalMultiplayer() && (target_screen == null || !target_screen.IsContentLost))
		{
			if (ShouldDrawOnBuffer() && target_screen != null)
			{
				base.GraphicsDevice.Clear(bgColor);
				spriteBatch.Begin((SpriteSortMode)0, BlendState.Opaque, SamplerState.LinearClamp, DepthStencilState.Default, RasterizerState.CullNone, (Effect)null, (Matrix?)null);
				spriteBatch.Draw((Texture2D)(object)target_screen, new Vector2(0f, 0f), (Rectangle?)((Texture2D)target_screen).Bounds, Color.White, 0f, Vector2.Zero, options.zoomLevel, (SpriteEffects)0, 1f);
				spriteBatch.End();
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.LinearClamp, DepthStencilState.Default, RasterizerState.CullNone, (Effect)null, (Matrix?)null);
				spriteBatch.Draw((Texture2D)(object)uiScreen, new Vector2(0f, 0f), (Rectangle?)((Texture2D)uiScreen).Bounds, Color.White, 0f, Vector2.Zero, options.uiScale, (SpriteEffects)0, 1f);
				spriteBatch.End();
			}
			else
			{
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.LinearClamp, DepthStencilState.Default, RasterizerState.CullNone, (Effect)null, (Matrix?)null);
				spriteBatch.Draw((Texture2D)(object)uiScreen, new Vector2(0f, 0f), (Rectangle?)((Texture2D)uiScreen).Bounds, Color.White, 0f, Vector2.Zero, options.uiScale, (SpriteEffects)0, 1f);
				spriteBatch.End();
			}
		}
	}

	public virtual void DrawSplitScreenWindow()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		if (!LocalMultiplayer.IsLocalMultiplayer())
		{
			return;
		}
		graphics.GraphicsDevice.SetRenderTarget((RenderTarget2D)null);
		if (screen == null || !screen.IsContentLost)
		{
			Viewport val = base.GraphicsDevice.Viewport;
			GraphicsDevice graphicsDevice = base.GraphicsDevice;
			Viewport val2 = (base.GraphicsDevice.Viewport = defaultDeviceViewport);
			graphicsDevice.Viewport = val2;
			spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.LinearClamp, DepthStencilState.Default, RasterizerState.CullNone, (Effect)null, (Matrix?)null);
			spriteBatch.Draw((Texture2D)(object)screen, new Vector2((float)localMultiplayerWindow.X, (float)localMultiplayerWindow.Y), (Rectangle?)((Texture2D)screen).Bounds, Color.White, 0f, Vector2.Zero, instanceOptions.zoomLevel, (SpriteEffects)0, 1f);
			if (uiScreen != null)
			{
				spriteBatch.Draw((Texture2D)(object)uiScreen, new Vector2((float)localMultiplayerWindow.X, (float)localMultiplayerWindow.Y), (Rectangle?)((Texture2D)uiScreen).Bounds, Color.White, 0f, Vector2.Zero, instanceOptions.uiScale, (SpriteEffects)0, 1f);
			}
			spriteBatch.End();
			base.GraphicsDevice.Viewport = val;
		}
	}

	public static void drawWithBorder(string message, Color borderColor, Color insideColor, Vector2 position)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		drawWithBorder(message, borderColor, insideColor, position, 0f, 1f, 1f, tiny: false);
	}

	public static void drawWithBorder(string message, Color borderColor, Color insideColor, Vector2 position, float rotate, float scale, float layerDepth)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		drawWithBorder(message, borderColor, insideColor, position, rotate, scale, layerDepth, tiny: false);
	}

	public static void drawWithBorder(string message, Color borderColor, Color insideColor, Vector2 position, float rotate, float scale, float layerDepth, bool tiny)
	{
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		string[] array = ArgUtility.SplitBySpace(message);
		int num = 0;
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].Contains('='))
			{
				spriteBatch.DrawString(tiny ? tinyFont : dialogueFont, array[i], new Vector2(position.X + (float)num, position.Y), Color.Purple, rotate, Vector2.Zero, scale, (SpriteEffects)0, layerDepth);
				num += (int)((tiny ? tinyFont : dialogueFont).MeasureString(array[i]).X + 8f);
			}
			else
			{
				spriteBatch.DrawString(tiny ? tinyFont : dialogueFont, array[i], new Vector2(position.X + (float)num, position.Y), insideColor, rotate, Vector2.Zero, scale, (SpriteEffects)0, layerDepth);
				num += (int)((tiny ? tinyFont : dialogueFont).MeasureString(array[i]).X + 8f);
			}
		}
	}

	public static bool isOutdoorMapSmallerThanViewport()
	{
		if (uiMode)
		{
			return false;
		}
		if (currentLocation != null && currentLocation.IsOutdoors && !(currentLocation is Summit))
		{
			if (currentLocation.map.Layers[0].LayerWidth * 64 >= ((Rectangle)(ref viewport)).Width)
			{
				return currentLocation.map.Layers[0].LayerHeight * 64 < ((Rectangle)(ref viewport)).Height;
			}
			return true;
		}
		return false;
	}

	protected virtual void drawHUD()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_035a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_0366: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_03af: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03de: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0400: Unknown result type (might be due to invalid IL or missing references)
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0414: Unknown result type (might be due to invalid IL or missing references)
		//IL_042f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0306: Unknown result type (might be due to invalid IL or missing references)
		//IL_043d: Unknown result type (might be due to invalid IL or missing references)
		//IL_045a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_0469: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0483: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0571: Unknown result type (might be due to invalid IL or missing references)
		//IL_0576: Unknown result type (might be due to invalid IL or missing references)
		//IL_057b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0616: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0620: Unknown result type (might be due to invalid IL or missing references)
		//IL_063f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0646: Unknown result type (might be due to invalid IL or missing references)
		//IL_065f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0664: Unknown result type (might be due to invalid IL or missing references)
		//IL_0669: Unknown result type (might be due to invalid IL or missing references)
		//IL_0678: Unknown result type (might be due to invalid IL or missing references)
		//IL_0686: Unknown result type (might be due to invalid IL or missing references)
		//IL_0699: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0709: Unknown result type (might be due to invalid IL or missing references)
		//IL_070f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0730: Unknown result type (might be due to invalid IL or missing references)
		//IL_0743: Unknown result type (might be due to invalid IL or missing references)
		//IL_0762: Unknown result type (might be due to invalid IL or missing references)
		//IL_079f: Unknown result type (might be due to invalid IL or missing references)
		//IL_075b: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0802: Unknown result type (might be due to invalid IL or missing references)
		//IL_080d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0814: Unknown result type (might be due to invalid IL or missing references)
		//IL_081e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0824: Unknown result type (might be due to invalid IL or missing references)
		//IL_086a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0922: Unknown result type (might be due to invalid IL or missing references)
		//IL_0929: Unknown result type (might be due to invalid IL or missing references)
		//IL_0933: Unknown result type (might be due to invalid IL or missing references)
		//IL_0939: Unknown result type (might be due to invalid IL or missing references)
		//IL_087b: Unknown result type (might be due to invalid IL or missing references)
		//IL_088c: Unknown result type (might be due to invalid IL or missing references)
		//IL_08cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08db: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0901: Unknown result type (might be due to invalid IL or missing references)
		//IL_0906: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a23: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a32: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a52: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a57: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a60: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a64: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a73: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a88: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d04: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d09: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d13: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d22: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d27: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b22: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d79: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d7e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d82: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b4e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e10: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b7d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b9e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e30: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e34: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e39: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ea4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eb2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c1a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c02: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f0f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f20: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f25: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f29: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ed8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ee9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ef2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ef7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c66: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c71: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c83: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c85: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c8a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c96: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c98: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c9f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f6a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f73: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fc2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fda: Unknown result type (might be due to invalid IL or missing references)
		//IL_0feb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f92: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f97: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fa0: Unknown result type (might be due to invalid IL or missing references)
		if (eventUp || farmEvent != null)
		{
			return;
		}
		float num = 0.625f;
		Rectangle val = graphics.GraphicsDevice.Viewport.GetTitleSafeArea();
		float num2 = ((Rectangle)(ref val)).Right - 48 - 8;
		val = graphics.GraphicsDevice.Viewport.GetTitleSafeArea();
		Vector2 val2 = default(Vector2);
		((Vector2)(ref val2))._002Ector(num2, (float)(((Rectangle)(ref val)).Bottom - 224 - 16 - (int)((float)(player.MaxStamina - 270) * num)));
		if (isOutdoorMapSmallerThanViewport())
		{
			val2.X = Math.Min(val2.X, -((Rectangle)(ref viewport)).X + currentLocation.map.Layers[0].LayerWidth * 64 - 48);
		}
		if (staminaShakeTimer > 0)
		{
			val2.X += random.Next(-3, 4);
			val2.Y += random.Next(-3, 4);
		}
		spriteBatch.Draw(mouseCursors, val2, (Rectangle?)new Rectangle(256, 408, 12, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
		SpriteBatch obj = spriteBatch;
		Texture2D obj2 = mouseCursors;
		int num3 = (int)val2.X;
		int num4 = (int)(val2.Y + 64f);
		val = graphics.GraphicsDevice.Viewport.GetTitleSafeArea();
		obj.Draw(obj2, new Rectangle(num3, num4, 48, ((Rectangle)(ref val)).Bottom - 64 - 16 - (int)(val2.Y + 64f - 8f)), (Rectangle?)new Rectangle(256, 424, 12, 16), Color.White);
		spriteBatch.Draw(mouseCursors, new Vector2(val2.X, val2.Y + 224f + (float)(int)((float)(player.MaxStamina - 270) * num) - 64f), (Rectangle?)new Rectangle(256, 448, 12, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
		Rectangle val3 = default(Rectangle);
		((Rectangle)(ref val3))._002Ector((int)val2.X + 12, (int)val2.Y + 16 + 32 + (int)((float)player.MaxStamina * num) - (int)(Math.Max(0f, player.Stamina) * num), 24, (int)(player.Stamina * num) - 1);
		if ((float)getOldMouseX() >= val2.X && (float)getOldMouseY() >= val2.Y)
		{
			drawWithBorder((int)Math.Max(0f, player.Stamina) + "/" + player.MaxStamina, Color.Black * 0f, Color.White, val2 + new Vector2(0f - dialogueFont.MeasureString("999/999").X - 16f - (float)(showingHealth ? 64 : 0), 64f));
		}
		Color redToGreenLerpColor = Utility.getRedToGreenLerpColor(player.stamina / (float)player.maxStamina.Value);
		spriteBatch.Draw(staminaRect, val3, redToGreenLerpColor);
		val3.Height = 4;
		((Color)(ref redToGreenLerpColor)).R = (byte)Math.Max(0, ((Color)(ref redToGreenLerpColor)).R - 50);
		((Color)(ref redToGreenLerpColor)).G = (byte)Math.Max(0, ((Color)(ref redToGreenLerpColor)).G - 50);
		spriteBatch.Draw(staminaRect, val3, redToGreenLerpColor);
		if (player.exhausted.Value)
		{
			spriteBatch.Draw(mouseCursors, val2 - new Vector2(0f, 11f) * 4f, (Rectangle?)new Rectangle(191, 406, 12, 11), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
			if ((float)getOldMouseX() >= val2.X && (float)getOldMouseY() >= val2.Y - 44f)
			{
				drawWithBorder(content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3747"), Color.Black * 0f, Color.White, val2 + new Vector2(0f - dialogueFont.MeasureString(content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3747")).X - 16f - (float)(showingHealth ? 64 : 0), 96f));
			}
		}
		if (currentLocation is MineShaft || currentLocation is Woods || currentLocation is SlimeHutch || currentLocation is VolcanoDungeon || player.health < player.maxHealth)
		{
			showingHealthBar = true;
			showingHealth = true;
			int num5 = 168 + (player.maxHealth - 100);
			int num6 = (int)((float)player.health / (float)player.maxHealth * (float)num5);
			val2.X -= 56 + ((hitShakeTimer > 0) ? random.Next(-3, 4) : 0);
			val = graphics.GraphicsDevice.Viewport.GetTitleSafeArea();
			val2.Y = ((Rectangle)(ref val)).Bottom - 224 - 16 - (player.maxHealth - 100);
			spriteBatch.Draw(mouseCursors, val2, (Rectangle?)new Rectangle(268, 408, 12, 16), (player.health < 20) ? (Color.Pink * ((float)Math.Sin(currentGameTime.TotalGameTime.TotalMilliseconds / (double)((float)player.health * 50f)) / 4f + 0.9f)) : Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
			SpriteBatch obj3 = spriteBatch;
			Texture2D obj4 = mouseCursors;
			int num7 = (int)val2.X;
			int num8 = (int)(val2.Y + 64f);
			val = graphics.GraphicsDevice.Viewport.GetTitleSafeArea();
			obj3.Draw(obj4, new Rectangle(num7, num8, 48, ((Rectangle)(ref val)).Bottom - 64 - 16 - (int)(val2.Y + 64f)), (Rectangle?)new Rectangle(268, 424, 12, 16), (player.health < 20) ? (Color.Pink * ((float)Math.Sin(currentGameTime.TotalGameTime.TotalMilliseconds / (double)((float)player.health * 50f)) / 4f + 0.9f)) : Color.White);
			spriteBatch.Draw(mouseCursors, new Vector2(val2.X, val2.Y + 224f + (float)(player.maxHealth - 100) - 64f), (Rectangle?)new Rectangle(268, 448, 12, 16), (player.health < 20) ? (Color.Pink * ((float)Math.Sin(currentGameTime.TotalGameTime.TotalMilliseconds / (double)((float)player.health * 50f)) / 4f + 0.9f)) : Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
			Rectangle val4 = default(Rectangle);
			((Rectangle)(ref val4))._002Ector((int)val2.X + 12, (int)val2.Y + 16 + 32 + num5 - num6, 24, num6);
			redToGreenLerpColor = Utility.getRedToGreenLerpColor((float)player.health / (float)player.maxHealth);
			spriteBatch.Draw(staminaRect, val4, (Rectangle?)staminaRect.Bounds, redToGreenLerpColor, 0f, Vector2.Zero, (SpriteEffects)0, 1f);
			((Color)(ref redToGreenLerpColor)).R = (byte)Math.Max(0, ((Color)(ref redToGreenLerpColor)).R - 50);
			((Color)(ref redToGreenLerpColor)).G = (byte)Math.Max(0, ((Color)(ref redToGreenLerpColor)).G - 50);
			if ((float)getOldMouseX() >= val2.X && (float)getOldMouseY() >= val2.Y && (float)getOldMouseX() < val2.X + 32f)
			{
				drawWithBorder(Math.Max(0, player.health) + "/" + player.maxHealth, Color.Black * 0f, Color.Red, val2 + new Vector2(0f - dialogueFont.MeasureString("999/999").X - 32f, 64f));
			}
			val4.Height = 4;
			spriteBatch.Draw(staminaRect, val4, (Rectangle?)staminaRect.Bounds, redToGreenLerpColor, 0f, Vector2.Zero, (SpriteEffects)0, 1f);
		}
		else
		{
			showingHealth = false;
		}
		foreach (IClickableMenu onScreenMenu in onScreenMenus)
		{
			if (onScreenMenu != chatBox)
			{
				onScreenMenu.update(currentGameTime);
				onScreenMenu.draw(spriteBatch);
			}
		}
		if (!player.professions.Contains(17) || !currentLocation.IsOutdoors)
		{
			return;
		}
		Rectangle val7 = default(Rectangle);
		Vector2 renderSize = default(Vector2);
		foreach (KeyValuePair<Vector2, Object> pair in currentLocation.objects.Pairs)
		{
			if ((pair.Value.isSpawnedObject.Value || pair.Value.QualifiedItemId == "(O)590") && !Utility.isOnScreen(pair.Key * 64f + new Vector2(32f, 32f), 64))
			{
				Viewport val5 = graphics.GraphicsDevice.Viewport;
				Rectangle bounds = ((Viewport)(ref val5)).Bounds;
				Vector2 val6 = default(Vector2);
				float num9 = 0f;
				if (pair.Key.X * 64f > (float)(((Rectangle)(ref viewport)).MaxCorner.X - 64))
				{
					val6.X = ((Rectangle)(ref bounds)).Right - 8;
					num9 = (float)Math.PI / 2f;
				}
				else if (pair.Key.X * 64f < (float)((Rectangle)(ref viewport)).X)
				{
					val6.X = 8f;
					num9 = -(float)Math.PI / 2f;
				}
				else
				{
					val6.X = pair.Key.X * 64f - (float)((Rectangle)(ref viewport)).X;
				}
				if (pair.Key.Y * 64f > (float)(((Rectangle)(ref viewport)).MaxCorner.Y - 64))
				{
					val6.Y = ((Rectangle)(ref bounds)).Bottom - 8;
					num9 = (float)Math.PI;
				}
				else if (pair.Key.Y * 64f < (float)((Rectangle)(ref viewport)).Y)
				{
					val6.Y = 8f;
				}
				else
				{
					val6.Y = pair.Key.Y * 64f - (float)((Rectangle)(ref viewport)).Y;
				}
				if (val6.X == 8f && val6.Y == 8f)
				{
					num9 += (float)Math.PI / 4f;
				}
				if (val6.X == 8f && val6.Y == (float)(((Rectangle)(ref bounds)).Bottom - 8))
				{
					num9 += (float)Math.PI / 4f;
				}
				if (val6.X == (float)(((Rectangle)(ref bounds)).Right - 8) && val6.Y == 8f)
				{
					num9 -= (float)Math.PI / 4f;
				}
				if (val6.X == (float)(((Rectangle)(ref bounds)).Right - 8) && val6.Y == (float)(((Rectangle)(ref bounds)).Bottom - 8))
				{
					num9 -= (float)Math.PI / 4f;
				}
				((Rectangle)(ref val7))._002Ector(412, 495, 5, 4);
				float num10 = 4f;
				((Vector2)(ref renderSize))._002Ector((float)val7.Width * num10, (float)val7.Height * num10);
				Vector2 val8 = Utility.makeSafe(val6, renderSize);
				spriteBatch.Draw(mouseCursors, val8, (Rectangle?)val7, Color.White, num9, new Vector2(2f, 2f), num10, (SpriteEffects)0, 1f);
			}
		}
		if (currentLocation.orePanPoint.Equals(Point.Zero) || Utility.isOnScreen(Utility.PointToVector2(currentLocation.orePanPoint.Value) * 64f + new Vector2(32f, 32f), 64))
		{
			return;
		}
		Vector2 val9 = default(Vector2);
		float num11 = 0f;
		Viewport val10;
		if (currentLocation.orePanPoint.X * 64 > ((Rectangle)(ref viewport)).MaxCorner.X - 64)
		{
			val10 = graphics.GraphicsDevice.Viewport;
			val = ((Viewport)(ref val10)).Bounds;
			val9.X = ((Rectangle)(ref val)).Right - 8;
			num11 = (float)Math.PI / 2f;
		}
		else if (currentLocation.orePanPoint.X * 64 < ((Rectangle)(ref viewport)).X)
		{
			val9.X = 8f;
			num11 = -(float)Math.PI / 2f;
		}
		else
		{
			val9.X = currentLocation.orePanPoint.X * 64 - ((Rectangle)(ref viewport)).X;
		}
		if (currentLocation.orePanPoint.Y * 64 > ((Rectangle)(ref viewport)).MaxCorner.Y - 64)
		{
			val10 = graphics.GraphicsDevice.Viewport;
			val = ((Viewport)(ref val10)).Bounds;
			val9.Y = ((Rectangle)(ref val)).Bottom - 8;
			num11 = (float)Math.PI;
		}
		else if (currentLocation.orePanPoint.Y * 64 < ((Rectangle)(ref viewport)).Y)
		{
			val9.Y = 8f;
		}
		else
		{
			val9.Y = currentLocation.orePanPoint.Y * 64 - ((Rectangle)(ref viewport)).Y;
		}
		if (val9.X == 8f && val9.Y == 8f)
		{
			num11 += (float)Math.PI / 4f;
		}
		if (val9.X == 8f)
		{
			float y = val9.Y;
			val10 = graphics.GraphicsDevice.Viewport;
			val = ((Viewport)(ref val10)).Bounds;
			if (y == (float)(((Rectangle)(ref val)).Bottom - 8))
			{
				num11 += (float)Math.PI / 4f;
			}
		}
		float x = val9.X;
		val10 = graphics.GraphicsDevice.Viewport;
		val = ((Viewport)(ref val10)).Bounds;
		if (x == (float)(((Rectangle)(ref val)).Right - 8) && val9.Y == 8f)
		{
			num11 -= (float)Math.PI / 4f;
		}
		float x2 = val9.X;
		val10 = graphics.GraphicsDevice.Viewport;
		val = ((Viewport)(ref val10)).Bounds;
		if (x2 == (float)(((Rectangle)(ref val)).Right - 8))
		{
			float y2 = val9.Y;
			val10 = graphics.GraphicsDevice.Viewport;
			val = ((Viewport)(ref val10)).Bounds;
			if (y2 == (float)(((Rectangle)(ref val)).Bottom - 8))
			{
				num11 -= (float)Math.PI / 4f;
			}
		}
		spriteBatch.Draw(mouseCursors, val9, (Rectangle?)new Rectangle(412, 495, 5, 4), Color.Cyan, num11, new Vector2(2f, 2f), 4f, (SpriteEffects)0, 1f);
	}

	public static void InvalidateOldMouseMovement()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		MouseState mouseState = input.GetMouseState();
		oldMouseState = new MouseState(((MouseState)(ref mouseState)).X, ((MouseState)(ref mouseState)).Y, ((MouseState)(ref oldMouseState)).ScrollWheelValue, ((MouseState)(ref oldMouseState)).LeftButton, ((MouseState)(ref oldMouseState)).MiddleButton, ((MouseState)(ref oldMouseState)).RightButton, ((MouseState)(ref oldMouseState)).XButton1, ((MouseState)(ref oldMouseState)).XButton2);
	}

	public static bool IsRenderingNonNativeUIScale()
	{
		return options.uiScale != options.zoomLevel;
	}

	public virtual void drawMouseCursor()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_03be: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0507: Unknown result type (might be due to invalid IL or missing references)
		//IL_0511: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0403: Unknown result type (might be due to invalid IL or missing references)
		//IL_041a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0422: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		if (activeClickableMenu == null && timerUntilMouseFade > 0)
		{
			timerUntilMouseFade -= currentGameTime.ElapsedGameTime.Milliseconds;
			lastMousePositionBeforeFade = getMousePosition();
		}
		if (options.gamepadControls && timerUntilMouseFade <= 0 && activeClickableMenu == null && (emoteMenu == null || emoteMenu.gamepadMode))
		{
			mouseCursorTransparency = 0f;
		}
		if (activeClickableMenu == null && mouseCursor > cursor_none && currentLocation != null)
		{
			if (IsRenderingNonNativeUIScale())
			{
				spriteBatch.End();
				PopUIMode();
				if (ShouldDrawOnBuffer())
				{
					SetRenderTarget(screen);
				}
				else
				{
					SetRenderTarget(null);
				}
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			}
			if (!(mouseCursorTransparency > 0f) || !Utility.canGrabSomethingFromHere(getOldMouseX() + ((Rectangle)(ref viewport)).X, getOldMouseY() + ((Rectangle)(ref viewport)).Y, player) || mouseCursor == cursor_gift)
			{
				if (player.ActiveObject != null && mouseCursor != cursor_gift && !eventUp && currentMinigame == null && !player.isRidingHorse() && player.CanMove && displayFarmer)
				{
					if (mouseCursorTransparency > 0f || options.showPlacementTileForGamepad)
					{
						player.ActiveObject.drawPlacementBounds(spriteBatch, currentLocation);
						if (mouseCursorTransparency > 0f)
						{
							spriteBatch.End();
							PushUIMode();
							spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
							bool flag = Utility.playerCanPlaceItemHere(currentLocation, player.CurrentItem, getMouseX() + ((Rectangle)(ref viewport)).X, getMouseY() + ((Rectangle)(ref viewport)).Y, player) || (Utility.isThereAnObjectHereWhichAcceptsThisItem(currentLocation, player.CurrentItem, getMouseX() + ((Rectangle)(ref viewport)).X, getMouseY() + ((Rectangle)(ref viewport)).Y) && Utility.withinRadiusOfPlayer(getMouseX() + ((Rectangle)(ref viewport)).X, getMouseY() + ((Rectangle)(ref viewport)).Y, 1, player));
							player.CurrentItem?.drawInMenu(spriteBatch, new Vector2((float)(getMouseX() + 16), (float)(getMouseY() + 16)), flag ? (dialogueButtonScale / 75f + 1f) : 1f, flag ? 1f : 0.5f, 0.999f);
							spriteBatch.End();
							PopUIMode();
							spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
						}
					}
				}
				else if (mouseCursor == cursor_default && isActionAtCurrentCursorTile && currentMinigame == null)
				{
					mouseCursor = (isSpeechAtCurrentCursorTile ? cursor_talk : (isInspectionAtCurrentCursorTile ? cursor_look : cursor_grab));
				}
				else if (mouseCursorTransparency > 0f)
				{
					NetLongDictionary<FarmAnimal, NetRef<FarmAnimal>> animals = currentLocation.animals;
					if (animals != null)
					{
						Vector2 val = default(Vector2);
						((Vector2)(ref val))._002Ector((float)(getOldMouseX() + ((Rectangle)(ref uiViewport)).X), (float)(getOldMouseY() + ((Rectangle)(ref uiViewport)).Y));
						bool flag2 = Utility.withinRadiusOfPlayer((int)val.X, (int)val.Y, 1, player);
						foreach (KeyValuePair<long, FarmAnimal> pair in animals.Pairs)
						{
							Rectangle cursorPetBoundingBox = pair.Value.GetCursorPetBoundingBox();
							if (!pair.Value.wasPet.Value && ((Rectangle)(ref cursorPetBoundingBox)).Contains((int)val.X, (int)val.Y))
							{
								mouseCursor = cursor_grab;
								if (!flag2)
								{
									mouseCursorTransparency = 0.5f;
								}
								break;
							}
						}
					}
				}
			}
			if (IsRenderingNonNativeUIScale())
			{
				spriteBatch.End();
				PushUIMode();
				SetRenderTarget(uiScreen);
				spriteBatch.Begin((SpriteSortMode)0, BlendState.AlphaBlend, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
			}
			if (currentMinigame != null)
			{
				mouseCursor = cursor_default;
			}
			if (!freezeControls && !options.hardwareCursor)
			{
				spriteBatch.Draw(mouseCursors, new Vector2((float)getMouseX(), (float)getMouseY()), (Rectangle?)getSourceRectForStandardTileSheet(mouseCursors, mouseCursor, 16, 16), Color.White * mouseCursorTransparency, 0f, Vector2.Zero, 4f + dialogueButtonScale / 150f, (SpriteEffects)0, 1f);
			}
			wasMouseVisibleThisFrame = mouseCursorTransparency > 0f;
			_lastDrewMouseCursor = wasMouseVisibleThisFrame;
		}
		mouseCursor = cursor_default;
		if (!isActionAtCurrentCursorTile && activeClickableMenu == null)
		{
			mouseCursorTransparency = 1f;
		}
	}

	public static void panScreen(int x, int y)
	{
		int num = uiModeCount;
		while (uiModeCount > 0)
		{
			PopUIMode();
		}
		previousViewportPosition.X = viewport.Location.X;
		previousViewportPosition.Y = viewport.Location.Y;
		((Rectangle)(ref viewport)).X = ((Rectangle)(ref viewport)).X + x;
		((Rectangle)(ref viewport)).Y = ((Rectangle)(ref viewport)).Y + y;
		clampViewportToGameMap();
		updateRaindropPosition();
		for (int i = 0; i < num; i++)
		{
			PushUIMode();
		}
	}

	public static void clampViewportToGameMap()
	{
		if (((Rectangle)(ref viewport)).X < 0)
		{
			((Rectangle)(ref viewport)).X = 0;
		}
		if (((Rectangle)(ref viewport)).X > currentLocation.map.DisplayWidth - ((Rectangle)(ref viewport)).Width)
		{
			((Rectangle)(ref viewport)).X = currentLocation.map.DisplayWidth - ((Rectangle)(ref viewport)).Width;
		}
		if (((Rectangle)(ref viewport)).Y < 0)
		{
			((Rectangle)(ref viewport)).Y = 0;
		}
		if (((Rectangle)(ref viewport)).Y > currentLocation.map.DisplayHeight - ((Rectangle)(ref viewport)).Height)
		{
			((Rectangle)(ref viewport)).Y = currentLocation.map.DisplayHeight - ((Rectangle)(ref viewport)).Height;
		}
	}

	protected void drawDialogueBox()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		if (currentSpeaker != null)
		{
			int val = (int)dialogueFont.MeasureString(currentSpeaker.CurrentDialogue.Peek().getCurrentDialogue()).Y;
			val = Math.Max(val, 320);
			drawDialogueBox((base.GraphicsDevice.Viewport.GetTitleSafeArea().Width - Math.Min(1280, base.GraphicsDevice.Viewport.GetTitleSafeArea().Width - 128)) / 2, base.GraphicsDevice.Viewport.GetTitleSafeArea().Height - val, Math.Min(1280, base.GraphicsDevice.Viewport.GetTitleSafeArea().Width - 128), val, speaker: true, drawOnlyBox: false, null, objectDialoguePortraitPerson != null && currentSpeaker == null);
		}
	}

	public static void drawDialogueBox(string message)
	{
		drawDialogueBox(((Rectangle)(ref viewport)).Width / 2, ((Rectangle)(ref viewport)).Height / 2, speaker: false, drawOnlyBox: false, message);
	}

	public static void drawDialogueBox(int centerX, int centerY, bool speaker, bool drawOnlyBox, string message)
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		string text = null;
		if (speaker && currentSpeaker != null)
		{
			text = currentSpeaker.CurrentDialogue.Peek().getCurrentDialogue();
		}
		else if (message != null)
		{
			text = message;
		}
		else if (currentObjectDialogue.Count > 0)
		{
			text = currentObjectDialogue.Peek();
		}
		if (text != null)
		{
			Vector2 val = dialogueFont.MeasureString(text);
			int num = (int)val.X + 128;
			int num2 = (int)val.Y + 128;
			int x = centerX - num / 2;
			int y = centerY - num2 / 2;
			drawDialogueBox(x, y, num, num2, speaker, drawOnlyBox, message, objectDialoguePortraitPerson != null && !speaker);
		}
	}

	public static void DrawBox(int x, int y, int width, int height, Color? color = null)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		Rectangle val = default(Rectangle);
		((Rectangle)(ref val))._002Ector(0, 0, 64, 64);
		val.X = 64;
		val.Y = 128;
		Texture2D val2 = menuTexture;
		Color val3 = Color.White;
		Color white = Color.White;
		if (color.HasValue)
		{
			val3 = color.Value;
			val2 = uncoloredMenuTexture;
			((Color)(ref white))._002Ector((int)Utility.Lerp((int)((Color)(ref val3)).R, Math.Min(255, ((Color)(ref val3)).R + 150), 0.65f), (int)Utility.Lerp((int)((Color)(ref val3)).G, Math.Min(255, ((Color)(ref val3)).G + 150), 0.65f), (int)Utility.Lerp((int)((Color)(ref val3)).B, Math.Min(255, ((Color)(ref val3)).B + 150), 0.65f));
		}
		spriteBatch.Draw(val2, new Rectangle(x, y, width, height), (Rectangle?)val, white);
		val.Y = 0;
		Vector2 val4 = default(Vector2);
		((Vector2)(ref val4))._002Ector((float)(-val.Width) * 0.5f, (float)(-val.Height) * 0.5f);
		val.X = 0;
		spriteBatch.Draw(val2, new Vector2((float)x + val4.X, (float)y + val4.Y), (Rectangle?)val, val3);
		val.X = 192;
		spriteBatch.Draw(val2, new Vector2((float)x + val4.X + (float)width, (float)y + val4.Y), (Rectangle?)val, val3);
		val.Y = 192;
		spriteBatch.Draw(val2, new Vector2((float)(x + width) + val4.X, (float)(y + height) + val4.Y), (Rectangle?)val, val3);
		val.X = 0;
		spriteBatch.Draw(val2, new Vector2((float)x + val4.X, (float)(y + height) + val4.Y), (Rectangle?)val, val3);
		val.X = 128;
		val.Y = 0;
		spriteBatch.Draw(val2, new Rectangle(64 + x + (int)val4.X, y + (int)val4.Y, width - 64, 64), (Rectangle?)val, val3);
		val.Y = 192;
		spriteBatch.Draw(val2, new Rectangle(64 + x + (int)val4.X, y + (int)val4.Y + height, width - 64, 64), (Rectangle?)val, val3);
		val.Y = 128;
		val.X = 0;
		spriteBatch.Draw(val2, new Rectangle(x + (int)val4.X, y + (int)val4.Y + 64, 64, height - 64), (Rectangle?)val, val3);
		val.X = 192;
		spriteBatch.Draw(val2, new Rectangle(x + width + (int)val4.X, y + (int)val4.Y + 64, 64, height - 64), (Rectangle?)val, val3);
	}

	public static void drawDialogueBox(int x, int y, int width, int height, bool speaker, bool drawOnlyBox, string message = null, bool objectDialogueWithPortrait = false, bool ignoreTitleSafe = true, int r = -1, int g = -1, int b = -1)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0339: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_0376: Unknown result type (might be due to invalid IL or missing references)
		//IL_037b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0382: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03be: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_042f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0434: Unknown result type (might be due to invalid IL or missing references)
		//IL_043b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0470: Unknown result type (might be due to invalid IL or missing references)
		//IL_0475: Unknown result type (might be due to invalid IL or missing references)
		//IL_047c: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_050d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0512: Unknown result type (might be due to invalid IL or missing references)
		//IL_0519: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b04: Unknown result type (might be due to invalid IL or missing references)
		//IL_0739: Unknown result type (might be due to invalid IL or missing references)
		//IL_073e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b7d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d4b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d0c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d18: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d22: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d38: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0821: Unknown result type (might be due to invalid IL or missing references)
		//IL_0826: Unknown result type (might be due to invalid IL or missing references)
		//IL_082d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0837: Unknown result type (might be due to invalid IL or missing references)
		//IL_089c: Unknown result type (might be due to invalid IL or missing references)
		//IL_08cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_08fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_090e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c17: Unknown result type (might be due to invalid IL or missing references)
		//IL_104a: Unknown result type (might be due to invalid IL or missing references)
		//IL_098a: Unknown result type (might be due to invalid IL or missing references)
		//IL_106d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1077: Unknown result type (might be due to invalid IL or missing references)
		//IL_1081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fa1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dc4: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_09fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e33: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e73: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e84: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f03: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f56: Unknown result type (might be due to invalid IL or missing references)
		if (!drawOnlyBox)
		{
			return;
		}
		Rectangle titleSafeArea = graphics.GraphicsDevice.Viewport.GetTitleSafeArea();
		int height2 = titleSafeArea.Height;
		int width2 = titleSafeArea.Width;
		int num = 0;
		int num2 = 0;
		if (!ignoreTitleSafe)
		{
			num2 = ((y <= titleSafeArea.Y) ? (titleSafeArea.Y - y) : 0);
		}
		int num3 = 0;
		width = Math.Min(titleSafeArea.Width, width);
		if (!isQuestion && currentSpeaker == null && currentObjectDialogue.Count > 0 && !drawOnlyBox)
		{
			width = (int)dialogueFont.MeasureString(currentObjectDialogue.Peek()).X + 128;
			height = (int)dialogueFont.MeasureString(currentObjectDialogue.Peek()).Y + 64;
			x = width2 / 2 - width / 2;
			num3 = ((height > 256) ? (-(height - 256)) : 0);
		}
		Rectangle value = default(Rectangle);
		((Rectangle)(ref value))._002Ector(0, 0, 64, 64);
		int num4 = -1;
		if (questionChoices.Count >= 3)
		{
			num4 = questionChoices.Count - 3;
		}
		if (!drawOnlyBox && currentObjectDialogue.Count > 0)
		{
			if (dialogueFont.MeasureString(currentObjectDialogue.Peek()).Y >= (float)(height - 128))
			{
				num4 -= (int)(((float)(height - 128) - dialogueFont.MeasureString(currentObjectDialogue.Peek()).Y) / 64f) - 1;
			}
			else
			{
				height += (int)dialogueFont.MeasureString(currentObjectDialogue.Peek()).Y / 2;
				num3 -= (int)dialogueFont.MeasureString(currentObjectDialogue.Peek()).Y / 2;
				if ((int)dialogueFont.MeasureString(currentObjectDialogue.Peek()).Y / 2 > 64)
				{
					num4 = 0;
				}
			}
		}
		if (currentSpeaker != null && isQuestion && currentSpeaker.CurrentDialogue.Peek().getCurrentDialogue().Substring(0, currentDialogueCharacterIndex)
			.Contains(Environment.NewLine))
		{
			num4++;
		}
		value.Width = 64;
		value.Height = 64;
		value.X = 64;
		value.Y = 128;
		Color val = (Color)((r == -1) ? Color.White : new Color(r, g, b));
		Texture2D val2 = ((r == -1) ? menuTexture : uncoloredMenuTexture);
		spriteBatch.Draw(val2, new Rectangle(28 + x + num, 28 + y - 64 * num4 + num2 + num3, width - 64, height - 64 + num4 * 64), (Rectangle?)value, (Color)((r == -1) ? val : new Color((int)Utility.Lerp(r, Math.Min(255, r + 150), 0.65f), (int)Utility.Lerp(g, Math.Min(255, g + 150), 0.65f), (int)Utility.Lerp(b, Math.Min(255, b + 150), 0.65f))));
		value.Y = 0;
		value.X = 0;
		spriteBatch.Draw(val2, new Vector2((float)(x + num), (float)(y - 64 * num4 + num2 + num3)), (Rectangle?)value, val);
		value.X = 192;
		spriteBatch.Draw(val2, new Vector2((float)(x + width + num - 64), (float)(y - 64 * num4 + num2 + num3)), (Rectangle?)value, val);
		value.Y = 192;
		spriteBatch.Draw(val2, new Vector2((float)(x + width + num - 64), (float)(y + height + num2 - 64 + num3)), (Rectangle?)value, val);
		value.X = 0;
		spriteBatch.Draw(val2, new Vector2((float)(x + num), (float)(y + height + num2 - 64 + num3)), (Rectangle?)value, val);
		value.X = 128;
		value.Y = 0;
		spriteBatch.Draw(val2, new Rectangle(64 + x + num, y - 64 * num4 + num2 + num3, width - 128, 64), (Rectangle?)value, val);
		value.Y = 192;
		spriteBatch.Draw(val2, new Rectangle(64 + x + num, y + height + num2 - 64 + num3, width - 128, 64), (Rectangle?)value, val);
		value.Y = 128;
		value.X = 0;
		spriteBatch.Draw(val2, new Rectangle(x + num, y - 64 * num4 + num2 + 64 + num3, 64, height - 128 + num4 * 64), (Rectangle?)value, val);
		value.X = 192;
		spriteBatch.Draw(val2, new Rectangle(x + width + num - 64, y - 64 * num4 + num2 + 64 + num3, 64, height - 128 + num4 * 64), (Rectangle?)value, val);
		NPC nPC;
		string text;
		Rectangle sourceRectForStandardTileSheet = default(Rectangle);
		if ((objectDialogueWithPortrait && objectDialoguePortraitPerson != null) || (speaker && currentSpeaker != null && currentSpeaker.CurrentDialogue.Count > 0 && currentSpeaker.CurrentDialogue.Peek().showPortrait))
		{
			nPC = (objectDialogueWithPortrait ? objectDialoguePortraitPerson : currentSpeaker);
			text = ((!objectDialogueWithPortrait) ? nPC.CurrentDialogue.Peek().CurrentEmotion : ((objectDialoguePortraitPerson.Name == player.spouse) ? "$l" : "$neutral"));
			if (text != null)
			{
				int length = text.Length;
				if (length != 2)
				{
					if (length == 8 && text == "$neutral")
					{
						goto IL_0705;
					}
				}
				else
				{
					switch (text[1])
					{
					case 'h':
						break;
					case 's':
						goto IL_063e;
					case 'u':
						goto IL_0651;
					case 'l':
						goto IL_0664;
					case 'a':
						goto IL_0677;
					case 'k':
						goto IL_068a;
					default:
						goto IL_0714;
					}
					if (text == "$h")
					{
						((Rectangle)(ref sourceRectForStandardTileSheet))._002Ector(64, 0, 64, 64);
						goto IL_0740;
					}
				}
			}
			goto IL_0714;
		}
		goto IL_0a07;
		IL_0714:
		sourceRectForStandardTileSheet = getSourceRectForStandardTileSheet(nPC.Portrait, Convert.ToInt32(nPC.CurrentDialogue.Peek().CurrentEmotion.Substring(1)));
		goto IL_0740;
		IL_0651:
		if (!(text == "$u"))
		{
			goto IL_0714;
		}
		((Rectangle)(ref sourceRectForStandardTileSheet))._002Ector(64, 64, 64, 64);
		goto IL_0740;
		IL_0a07:
		if (drawOnlyBox)
		{
			return;
		}
		string text2 = "";
		if (currentSpeaker != null && currentSpeaker.CurrentDialogue.Count > 0)
		{
			if (currentSpeaker.CurrentDialogue.Peek() == null || currentSpeaker.CurrentDialogue.Peek().getCurrentDialogue().Length < currentDialogueCharacterIndex - 1)
			{
				dialogueUp = false;
				currentDialogueCharacterIndex = 0;
				playSound("dialogueCharacterClose");
				player.forceCanMove();
				return;
			}
			text2 = currentSpeaker.CurrentDialogue.Peek().getCurrentDialogue().Substring(0, currentDialogueCharacterIndex);
		}
		else if (message != null)
		{
			text2 = message;
		}
		else if (currentObjectDialogue.Count > 0)
		{
			text2 = ((currentObjectDialogue.Peek().Length <= 1) ? "" : currentObjectDialogue.Peek().Substring(0, currentDialogueCharacterIndex));
		}
		Vector2 val3 = default(Vector2);
		if (dialogueFont.MeasureString(text2).X > (float)(width2 - 256 - num))
		{
			((Vector2)(ref val3))._002Ector((float)(128 + num), (float)(height2 - 64 * num4 - 256 - 16 + num2 + num3));
		}
		else if (currentSpeaker != null && currentSpeaker.CurrentDialogue.Count > 0)
		{
			((Vector2)(ref val3))._002Ector((float)(width2 / 2) - dialogueFont.MeasureString(currentSpeaker.CurrentDialogue.Peek().getCurrentDialogue()).X / 2f + (float)num, (float)(height2 - 64 * num4 - 256 - 16 + num2 + num3));
		}
		else if (message != null)
		{
			((Vector2)(ref val3))._002Ector((float)(width2 / 2) - dialogueFont.MeasureString(text2).X / 2f + (float)num, (float)(y + 96 + 4));
		}
		else if (isQuestion)
		{
			((Vector2)(ref val3))._002Ector((float)(width2 / 2) - dialogueFont.MeasureString((currentObjectDialogue.Count == 0) ? "" : currentObjectDialogue.Peek()).X / 2f + (float)num, (float)(height2 - 64 * num4 - 256 - (16 + (questionChoices.Count - 2) * 64) + num2 + num3));
		}
		else
		{
			((Vector2)(ref val3))._002Ector((float)(width2 / 2) - dialogueFont.MeasureString((currentObjectDialogue.Count == 0) ? "" : currentObjectDialogue.Peek()).X / 2f + (float)num, (float)(y + 4 + num3));
		}
		if (!drawOnlyBox)
		{
			spriteBatch.DrawString(dialogueFont, text2, val3 + new Vector2(3f, 0f), textShadowColor);
			spriteBatch.DrawString(dialogueFont, text2, val3 + new Vector2(3f, 3f), textShadowColor);
			spriteBatch.DrawString(dialogueFont, text2, val3 + new Vector2(0f, 3f), textShadowColor);
			spriteBatch.DrawString(dialogueFont, text2, val3, textColor);
		}
		if (dialogueFont.MeasureString(text2).Y <= 64f)
		{
			num2 += 64;
		}
		if (isQuestion && !dialogueTyping)
		{
			for (int i = 0; i < questionChoices.Count; i++)
			{
				if (currentQuestionChoice == i)
				{
					val3.X = 80 + num + x;
					val3.Y = (float)(height2 - (5 + num4 + 1) * 64) + ((text2.Trim().Length > 0) ? dialogueFont.MeasureString(text2).Y : 0f) + 128f + (float)(48 * i) - (float)(16 + (questionChoices.Count - 2) * 64) + (float)num2 + (float)num3;
					spriteBatch.End();
					spriteBatch.Begin((SpriteSortMode)0, BlendState.NonPremultiplied, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
					spriteBatch.Draw(objectSpriteSheet, val3 + new Vector2((float)Math.Cos((double)currentGameTime.TotalGameTime.Milliseconds * Math.PI / 512.0) * 3f, 0f), (Rectangle?)GameLocation.getSourceRectForObject(26), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
					spriteBatch.End();
					spriteBatch.Begin((SpriteSortMode)0, (BlendState)null, (SamplerState)null, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
					val3.X = 160 + num + x;
					val3.Y = (float)(height2 - (5 + num4 + 1) * 64) + ((text2.Trim().Length > 1) ? dialogueFont.MeasureString(text2).Y : 0f) + 128f - (float)((questionChoices.Count - 2) * 64) + (float)(48 * i) + (float)num2 + (float)num3;
					spriteBatch.DrawString(dialogueFont, questionChoices[i].responseText, val3, textColor);
				}
				else
				{
					val3.X = 128 + num + x;
					val3.Y = (float)(height2 - (5 + num4 + 1) * 64) + ((text2.Trim().Length > 1) ? dialogueFont.MeasureString(text2).Y : 0f) + 128f - (float)((questionChoices.Count - 2) * 64) + (float)(48 * i) + (float)num2 + (float)num3;
					spriteBatch.DrawString(dialogueFont, questionChoices[i].responseText, val3, unselectedOptionColor);
				}
			}
		}
		if (!drawOnlyBox && !dialogueTyping && message == null)
		{
			spriteBatch.Draw(mouseCursors, new Vector2((float)(x + num + width - 96), (float)(y + height + num2 + num3 - 96) - dialogueButtonScale), (Rectangle?)getSourceRectForStandardTileSheet(mouseCursors, (!dialogueButtonShrinking && dialogueButtonScale < 8f) ? 3 : 2), Color.White, 0f, Vector2.Zero, 1f, (SpriteEffects)0, 0.9999999f);
		}
		return;
		IL_063e:
		if (!(text == "$s"))
		{
			goto IL_0714;
		}
		((Rectangle)(ref sourceRectForStandardTileSheet))._002Ector(0, 64, 64, 64);
		goto IL_0740;
		IL_0705:
		((Rectangle)(ref sourceRectForStandardTileSheet))._002Ector(0, 0, 64, 64);
		goto IL_0740;
		IL_0664:
		if (!(text == "$l"))
		{
			goto IL_0714;
		}
		((Rectangle)(ref sourceRectForStandardTileSheet))._002Ector(0, 128, 64, 64);
		goto IL_0740;
		IL_0740:
		spriteBatch.End();
		spriteBatch.Begin((SpriteSortMode)0, BlendState.NonPremultiplied, SamplerState.PointClamp, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
		if (nPC.Portrait != null)
		{
			spriteBatch.Draw(mouseCursors, new Vector2((float)(num + x + 768), (float)(height2 - 320 - 64 * num4 - 256 + num2 + 16 - 60 + num3)), (Rectangle?)new Rectangle(333, 305, 80, 87), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.98f);
			spriteBatch.Draw(nPC.Portrait, new Vector2((float)(num + x + 768 + 32), (float)(height2 - 320 - 64 * num4 - 256 + num2 + 16 - 60 + num3)), (Rectangle?)sourceRectForStandardTileSheet, Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.99f);
		}
		spriteBatch.End();
		spriteBatch.Begin((SpriteSortMode)0, (BlendState)null, (SamplerState)null, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
		if (isQuestion)
		{
			spriteBatch.DrawString(dialogueFont, nPC.displayName, new Vector2(928f - dialogueFont.MeasureString(nPC.displayName).X / 2f + (float)num + (float)x, (float)(height2 - 320 - 64 * num4) - dialogueFont.MeasureString(nPC.displayName).Y + (float)num2 + 21f + (float)num3) + new Vector2(2f, 2f), new Color(150, 150, 150));
		}
		spriteBatch.DrawString(dialogueFont, nPC.Name.Equals("Lewis") ? content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3756") : nPC.displayName, new Vector2((float)(num + x + 896 + 32) - dialogueFont.MeasureString(nPC.Name.Equals("Lewis") ? content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3756") : nPC.displayName).X / 2f, (float)(height2 - 320 - 64 * num4) - dialogueFont.MeasureString(nPC.Name.Equals("Lewis") ? content.LoadString("Strings\\StringsFromCSFiles:Game1.cs.3756") : nPC.displayName).Y + (float)num2 + 21f + 8f + (float)num3), textColor);
		goto IL_0a07;
		IL_068a:
		if (text == "$k")
		{
			goto IL_0705;
		}
		goto IL_0714;
		IL_0677:
		if (!(text == "$a"))
		{
			goto IL_0714;
		}
		((Rectangle)(ref sourceRectForStandardTileSheet))._002Ector(64, 128, 64, 64);
		goto IL_0740;
	}

	public static void drawPlayerHeldObject(Farmer f)
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		if ((!eventUp || (currentLocation.currentEvent != null && currentLocation.currentEvent.showActiveObject)) && !f.FarmerSprite.PauseForSingleAnimation && !f.isRidingHorse() && !f.bathingClothes.Value && !f.onBridge.Value)
		{
			float num = f.getLocalPosition(viewport).X + (float)((f.rotation < 0f) ? (-8) : ((f.rotation > 0f) ? 8 : 0)) + (float)(f.FarmerSprite.CurrentAnimationFrame.xOffset * 4);
			float num2 = f.getLocalPosition(viewport).Y - 128f + (float)(f.FarmerSprite.CurrentAnimationFrame.positionOffset * 4) + (float)(FarmerRenderer.featureYOffsetPerFrame[f.FarmerSprite.CurrentFrame] * 4);
			if (f.ActiveObject.bigCraftable.Value)
			{
				num2 -= 64f;
			}
			if (f.isEating)
			{
				num = f.getLocalPosition(viewport).X - 21f;
				num2 = f.getLocalPosition(viewport).Y - 128f + 12f;
			}
			if (!f.isEating || (f.isEating && f.Sprite.currentFrame <= 218))
			{
				f.ActiveObject.drawWhenHeld(spriteBatch, new Vector2((float)(int)num, (float)(int)num2), f);
			}
		}
	}

	public static void drawTool(Farmer f)
	{
		drawTool(f, f.CurrentTool.CurrentParentTileIndex);
	}

	public static void drawTool(Farmer f, int currentToolIndex)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0429: Unknown result type (might be due to invalid IL or missing references)
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04da: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0500: Unknown result type (might be due to invalid IL or missing references)
		//IL_0505: Unknown result type (might be due to invalid IL or missing references)
		//IL_050c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0513: Unknown result type (might be due to invalid IL or missing references)
		//IL_052c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0542: Unknown result type (might be due to invalid IL or missing references)
		//IL_0558: Unknown result type (might be due to invalid IL or missing references)
		//IL_055d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0564: Unknown result type (might be due to invalid IL or missing references)
		//IL_056b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0584: Unknown result type (might be due to invalid IL or missing references)
		//IL_059a: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_068c: Unknown result type (might be due to invalid IL or missing references)
		//IL_069c: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c73: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c12: Unknown result type (might be due to invalid IL or missing references)
		//IL_048e: Unknown result type (might be due to invalid IL or missing references)
		//IL_049e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_060e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0613: Unknown result type (might be due to invalid IL or missing references)
		//IL_061a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0621: Unknown result type (might be due to invalid IL or missing references)
		//IL_06dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0701: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d24: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d34: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d4a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d5b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d7b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d91: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dbf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e04: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e09: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e0e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e15: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f0f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f14: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f20: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f27: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c22: Unknown result type (might be due to invalid IL or missing references)
		//IL_1387: Unknown result type (might be due to invalid IL or missing references)
		//IL_138c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1394: Unknown result type (might be due to invalid IL or missing references)
		//IL_063a: Unknown result type (might be due to invalid IL or missing references)
		//IL_064a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0660: Unknown result type (might be due to invalid IL or missing references)
		//IL_0665: Unknown result type (might be due to invalid IL or missing references)
		//IL_066c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0673: Unknown result type (might be due to invalid IL or missing references)
		//IL_074f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0761: Unknown result type (might be due to invalid IL or missing references)
		//IL_0779: Unknown result type (might be due to invalid IL or missing references)
		//IL_077e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0785: Unknown result type (might be due to invalid IL or missing references)
		//IL_0799: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_081e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0830: Unknown result type (might be due to invalid IL or missing references)
		//IL_0848: Unknown result type (might be due to invalid IL or missing references)
		//IL_084d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0854: Unknown result type (might be due to invalid IL or missing references)
		//IL_0868: Unknown result type (might be due to invalid IL or missing references)
		//IL_0711: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0903: Unknown result type (might be due to invalid IL or missing references)
		//IL_0908: Unknown result type (might be due to invalid IL or missing references)
		//IL_090d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0914: Unknown result type (might be due to invalid IL or missing references)
		//IL_0941: Unknown result type (might be due to invalid IL or missing references)
		//IL_095a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0970: Unknown result type (might be due to invalid IL or missing references)
		//IL_0986: Unknown result type (might be due to invalid IL or missing references)
		//IL_098b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0990: Unknown result type (might be due to invalid IL or missing references)
		//IL_0997: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_09da: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a01: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a15: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a44: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a79: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a92: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0abe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0acf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0afc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b12: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b33: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b38: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b53: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b82: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b9e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0baf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cd3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cfd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d04: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e47: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e57: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e67: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e71: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e78: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f44: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f49: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f69: Unknown result type (might be due to invalid IL or missing references)
		//IL_1404: Unknown result type (might be due to invalid IL or missing references)
		//IL_1409: Unknown result type (might be due to invalid IL or missing references)
		//IL_141d: Unknown result type (might be due to invalid IL or missing references)
		//IL_13a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e98: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ea8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ebe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ecf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ed6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fb7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fc7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fdd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fe2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fe7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fee: Unknown result type (might be due to invalid IL or missing references)
		//IL_1002: Unknown result type (might be due to invalid IL or missing references)
		//IL_101b: Unknown result type (might be due to invalid IL or missing references)
		//IL_102b: Unknown result type (might be due to invalid IL or missing references)
		//IL_103b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1040: Unknown result type (might be due to invalid IL or missing references)
		//IL_1045: Unknown result type (might be due to invalid IL or missing references)
		//IL_104c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1060: Unknown result type (might be due to invalid IL or missing references)
		//IL_1086: Unknown result type (might be due to invalid IL or missing references)
		//IL_1096: Unknown result type (might be due to invalid IL or missing references)
		//IL_10ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_10b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_10b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_10bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_10d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f79: Unknown result type (might be due to invalid IL or missing references)
		//IL_110e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1139: Unknown result type (might be due to invalid IL or missing references)
		//IL_1164: Unknown result type (might be due to invalid IL or missing references)
		//IL_1169: Unknown result type (might be due to invalid IL or missing references)
		//IL_116e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1175: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_11bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_11cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_11e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_11e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_11eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_11f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1206: Unknown result type (might be due to invalid IL or missing references)
		//IL_121f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1235: Unknown result type (might be due to invalid IL or missing references)
		//IL_124b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1250: Unknown result type (might be due to invalid IL or missing references)
		//IL_1255: Unknown result type (might be due to invalid IL or missing references)
		//IL_125c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1270: Unknown result type (might be due to invalid IL or missing references)
		//IL_1289: Unknown result type (might be due to invalid IL or missing references)
		//IL_129f: Unknown result type (might be due to invalid IL or missing references)
		//IL_12b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_12ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_12bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_12c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_12da: Unknown result type (might be due to invalid IL or missing references)
		//IL_12f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1309: Unknown result type (might be due to invalid IL or missing references)
		//IL_1319: Unknown result type (might be due to invalid IL or missing references)
		//IL_131e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1323: Unknown result type (might be due to invalid IL or missing references)
		//IL_132a: Unknown result type (might be due to invalid IL or missing references)
		//IL_133e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1442: Unknown result type (might be due to invalid IL or missing references)
		//IL_1447: Unknown result type (might be due to invalid IL or missing references)
		//IL_173c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1746: Unknown result type (might be due to invalid IL or missing references)
		//IL_175c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1761: Unknown result type (might be due to invalid IL or missing references)
		//IL_1766: Unknown result type (might be due to invalid IL or missing references)
		//IL_176d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1781: Unknown result type (might be due to invalid IL or missing references)
		//IL_179a: Unknown result type (might be due to invalid IL or missing references)
		//IL_17a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_13bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_14fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_1507: Unknown result type (might be due to invalid IL or missing references)
		//IL_1519: Unknown result type (might be due to invalid IL or missing references)
		//IL_151e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1523: Unknown result type (might be due to invalid IL or missing references)
		//IL_152a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1531: Unknown result type (might be due to invalid IL or missing references)
		//IL_154a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1556: Unknown result type (might be due to invalid IL or missing references)
		//IL_1568: Unknown result type (might be due to invalid IL or missing references)
		//IL_156d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1572: Unknown result type (might be due to invalid IL or missing references)
		//IL_1579: Unknown result type (might be due to invalid IL or missing references)
		//IL_1580: Unknown result type (might be due to invalid IL or missing references)
		//IL_1819: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a7d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a87: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a9d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aa2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aa7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aae: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ac2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bad: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bb7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bcd: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bd7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bde: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bf2: Unknown result type (might be due to invalid IL or missing references)
		//IL_15a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_15b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_15c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_15c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_15cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_15d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_15db: Unknown result type (might be due to invalid IL or missing references)
		//IL_17c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_17ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_17cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_17d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_17ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_1934: Unknown result type (might be due to invalid IL or missing references)
		//IL_1944: Unknown result type (might be due to invalid IL or missing references)
		//IL_196f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1974: Unknown result type (might be due to invalid IL or missing references)
		//IL_1979: Unknown result type (might be due to invalid IL or missing references)
		//IL_1980: Unknown result type (might be due to invalid IL or missing references)
		//IL_1994: Unknown result type (might be due to invalid IL or missing references)
		//IL_18c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_18cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_18f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_18fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_1900: Unknown result type (might be due to invalid IL or missing references)
		//IL_1907: Unknown result type (might be due to invalid IL or missing references)
		//IL_191b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a19: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a29: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a3f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a44: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a49: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a50: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a64: Unknown result type (might be due to invalid IL or missing references)
		//IL_19b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_19c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_19db: Unknown result type (might be due to invalid IL or missing references)
		//IL_19e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_19e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_19ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a00: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ae6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1af0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b06: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b10: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b17: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b59: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b6f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b74: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b79: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b80: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b94: Unknown result type (might be due to invalid IL or missing references)
		//IL_165a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1666: Unknown result type (might be due to invalid IL or missing references)
		//IL_1678: Unknown result type (might be due to invalid IL or missing references)
		//IL_167d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1682: Unknown result type (might be due to invalid IL or missing references)
		//IL_1689: Unknown result type (might be due to invalid IL or missing references)
		//IL_1690: Unknown result type (might be due to invalid IL or missing references)
		//IL_1605: Unknown result type (might be due to invalid IL or missing references)
		//IL_1611: Unknown result type (might be due to invalid IL or missing references)
		//IL_161d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1622: Unknown result type (might be due to invalid IL or missing references)
		//IL_1627: Unknown result type (might be due to invalid IL or missing references)
		//IL_162e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1635: Unknown result type (might be due to invalid IL or missing references)
		//IL_1832: Unknown result type (might be due to invalid IL or missing references)
		//IL_14ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_14b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_14ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_14cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_14d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_14db: Unknown result type (might be due to invalid IL or missing references)
		//IL_14e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_16cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_16d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_16eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_16f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_16f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_16fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_1703: Unknown result type (might be due to invalid IL or missing references)
		//IL_1853: Unknown result type (might be due to invalid IL or missing references)
		//IL_1858: Unknown result type (might be due to invalid IL or missing references)
		//IL_185d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1864: Unknown result type (might be due to invalid IL or missing references)
		//IL_1878: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = f.getLocalPosition(viewport) + f.jitter + f.armOffset;
		FarmerSprite farmerSprite = (FarmerSprite)f.Sprite;
		if (f.CurrentTool is MeleeWeapon meleeWeapon)
		{
			meleeWeapon.drawDuringUse(farmerSprite.currentAnimationIndex, f.FacingDirection, spriteBatch, val, f);
			return;
		}
		if (f.FarmerSprite.isUsingWeapon())
		{
			MeleeWeapon.drawDuringUse(farmerSprite.currentAnimationIndex, f.FacingDirection, spriteBatch, val, f, f.FarmerSprite.CurrentToolIndex.ToString(), f.FarmerSprite.getWeaponTypeFromAnimation(), isOnSpecial: false);
			return;
		}
		Tool currentTool = f.CurrentTool;
		if (!(currentTool is Slingshot) && !(currentTool is Shears) && !(currentTool is MilkPail) && !(currentTool is Pan))
		{
			if (!(currentTool is FishingRod) && !(currentTool is WateringCan) && f != player)
			{
				if (farmerSprite.currentSingleAnimation < 160 || farmerSprite.currentSingleAnimation >= 192)
				{
					return;
				}
				if (f.CurrentTool != null)
				{
					f.CurrentTool.Update(f.FacingDirection, 0, f);
					currentToolIndex = f.CurrentTool.CurrentParentTileIndex;
				}
			}
			Texture2D val2 = ItemRegistry.GetData(f.CurrentTool?.QualifiedItemId)?.GetTexture() ?? toolSpriteSheet;
			Rectangle value = default(Rectangle);
			((Rectangle)(ref value))._002Ector(currentToolIndex * 16 % val2.Width, currentToolIndex * 16 / val2.Width * 16, 16, 32);
			float drawLayer = f.getDrawLayer();
			if (f.CurrentTool is FishingRod fishingRod)
			{
				if (fishingRod.fishCaught || fishingRod.showingTreasure)
				{
					f.CurrentTool.draw(spriteBatch);
					return;
				}
				((Rectangle)(ref value))._002Ector(farmerSprite.currentAnimationIndex * 48, 288, 48, 48);
				if (f.FacingDirection == 2 || f.FacingDirection == 0)
				{
					value.Y += 48;
				}
				else if (fishingRod.isFishing && (!fishingRod.isReeling || fishingRod.hit))
				{
					val.Y += 8f;
				}
				if (fishingRod.isFishing)
				{
					value.X += (5 - farmerSprite.currentAnimationIndex) * 48;
				}
				if (fishingRod.isReeling)
				{
					if (f.FacingDirection == 2 || f.FacingDirection == 0)
					{
						value.X = 288;
						if (f.IsLocalPlayer && didPlayerJustClickAtAll())
						{
							value.X = 0;
						}
					}
					else
					{
						value.X = 288;
						value.Y = 240;
						if (f.IsLocalPlayer && didPlayerJustClickAtAll())
						{
							value.Y += 48;
						}
					}
				}
				if (f.FarmerSprite.CurrentFrame == 57)
				{
					value.Height = 0;
				}
				if (f.FacingDirection == 0)
				{
					val.X += 16f;
				}
			}
			f.CurrentTool?.draw(spriteBatch);
			int num = 0;
			int num2 = 0;
			if (f.CurrentTool is WateringCan)
			{
				num += 80;
				num2 = ((f.FacingDirection == 1) ? 32 : ((f.FacingDirection == 3) ? (-32) : 0));
				if (farmerSprite.currentAnimationIndex == 0 || farmerSprite.currentAnimationIndex == 1)
				{
					num2 = num2 * 3 / 2;
				}
			}
			num += f.yJumpOffset;
			float num3 = FarmerRenderer.GetLayerDepth(drawLayer, f.FacingDirection switch
			{
				0 => FarmerRenderer.FarmerSpriteLayers.ToolUp, 
				2 => FarmerRenderer.FarmerSpriteLayers.ToolDown, 
				_ => FarmerRenderer.FarmerSpriteLayers.TOOL_IN_USE_SIDE, 
			});
			switch (f.FacingDirection)
			{
			case 1:
			{
				if (farmerSprite.currentAnimationIndex > 2)
				{
					Point tilePoint3 = f.TilePoint;
					tilePoint3.X++;
					tilePoint3.Y--;
					if (!(f.CurrentTool is WateringCan) && f.currentLocation.hasTileAt(tilePoint3, "Front"))
					{
						return;
					}
					tilePoint3.Y++;
				}
				currentTool = f.CurrentTool;
				if (!(currentTool is FishingRod fishingRod3))
				{
					if (currentTool is WateringCan)
					{
						if (farmerSprite.currentAnimationIndex == 1)
						{
							Point tilePoint4 = f.TilePoint;
							tilePoint4.X--;
							tilePoint4.Y--;
							if (f.currentLocation.hasTileAt(tilePoint4, "Front") && f.Position.Y % 64f < 32f)
							{
								return;
							}
						}
						switch (farmerSprite.currentAnimationIndex)
						{
						case 0:
						case 1:
							spriteBatch.Draw(val2, new Vector2((float)(int)(val.X + (float)num2 - 4f), (float)(int)(val.Y - 128f + 8f + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
							break;
						case 2:
							spriteBatch.Draw(val2, new Vector2((float)((int)val.X + num2 + 24), (float)(int)(val.Y - 128f - 8f + (float)num)), (Rectangle?)value, Color.White, (float)Math.PI / 12f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
							break;
						case 3:
							value.X += 16;
							spriteBatch.Draw(val2, new Vector2((float)(int)(val.X + (float)num2 + 8f), (float)(int)(val.Y - 128f - 24f + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
							break;
						}
						return;
					}
					switch (farmerSprite.currentAnimationIndex)
					{
					case 0:
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 32f - 4f + (float)num2 - (float)Math.Min(8, f.toolPower.Value * 4), val.Y - 128f + 24f + (float)num + (float)Math.Min(8, f.toolPower.Value * 4))), (Rectangle?)value, Color.White, -(float)Math.PI / 12f - (float)Math.Min(f.toolPower.Value, 2) * ((float)Math.PI / 64f), new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
						break;
					case 1:
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + 32f - 24f + (float)num2, val.Y - 124f + (float)num + 64f)), (Rectangle?)value, Color.White, (float)Math.PI / 12f, new Vector2(0f, 32f), 4f, (SpriteEffects)0, num3);
						break;
					case 2:
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + 32f + (float)num2 - 4f, val.Y - 132f + (float)num + 64f)), (Rectangle?)value, Color.White, (float)Math.PI / 4f, new Vector2(0f, 32f), 4f, (SpriteEffects)0, num3);
						break;
					case 3:
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + 32f + 28f + (float)num2, val.Y - 64f + (float)num)), (Rectangle?)value, Color.White, (float)Math.PI * 7f / 12f, new Vector2(0f, 32f), 4f, (SpriteEffects)0, num3);
						break;
					case 4:
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + 32f + 28f + (float)num2, val.Y - 64f + 4f + (float)num)), (Rectangle?)value, Color.White, (float)Math.PI * 7f / 12f, new Vector2(0f, 32f), 4f, (SpriteEffects)0, num3);
						break;
					case 5:
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + 64f + 12f + (float)num2, val.Y - 128f + 32f + (float)num + 128f)), (Rectangle?)value, Color.White, (float)Math.PI / 4f, new Vector2(0f, 32f), 4f, (SpriteEffects)0, num3);
						break;
					case 6:
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + 42f + 8f + (float)num2, val.Y - 64f + 24f + (float)num + 128f)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 128f), 4f, (SpriteEffects)0, num3);
						break;
					}
					return;
				}
				Color color2 = fishingRod3.getColor();
				switch (farmerSprite.currentAnimationIndex)
				{
				case 0:
					if (fishingRod3.isReeling || fishingRod3.isFishing || fishingRod3.doneWithAnimation || !fishingRod3.hasDoneFucntionYet || fishingRod3.pullingOutOfWater)
					{
						spriteBatch.Draw(val2, new Vector2(val.X - 64f + (float)num2, val.Y - 160f + (float)num), (Rectangle?)value, color2, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
					}
					break;
				case 1:
					spriteBatch.Draw(val2, new Vector2(val.X - 64f + (float)num2, val.Y - 160f + 8f + (float)num), (Rectangle?)value, color2, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
					break;
				case 2:
					spriteBatch.Draw(val2, new Vector2(val.X - 96f + 32f + (float)num2, val.Y - 128f - 24f + (float)num), (Rectangle?)value, color2, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
					break;
				case 3:
					spriteBatch.Draw(val2, new Vector2(val.X - 96f + 24f + (float)num2, val.Y - 128f - 32f + (float)num), (Rectangle?)value, color2, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
					break;
				case 4:
					if (fishingRod3.isFishing || fishingRod3.doneWithAnimation)
					{
						spriteBatch.Draw(val2, new Vector2(val.X - 64f + (float)num2, val.Y - 160f + (float)num), (Rectangle?)value, color2, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
					}
					else
					{
						spriteBatch.Draw(val2, new Vector2(val.X - 64f + (float)num2, val.Y - 160f + 4f + (float)num), (Rectangle?)value, color2, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
					}
					break;
				case 5:
					spriteBatch.Draw(val2, new Vector2(val.X - 64f + (float)num2, val.Y - 160f + (float)num), (Rectangle?)value, color2, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
					break;
				}
				return;
			}
			case 3:
			{
				if (farmerSprite.currentAnimationIndex > 2)
				{
					Point tilePoint = f.TilePoint;
					tilePoint.X--;
					tilePoint.Y--;
					if (!(f.CurrentTool is WateringCan) && f.currentLocation.hasTileAt(tilePoint, "Front") && f.Position.Y % 64f < 32f)
					{
						return;
					}
					tilePoint.Y++;
				}
				currentTool = f.CurrentTool;
				if (!(currentTool is FishingRod fishingRod2))
				{
					if (currentTool is WateringCan)
					{
						if (farmerSprite.currentAnimationIndex == 1)
						{
							Point tilePoint2 = f.TilePoint;
							tilePoint2.X--;
							tilePoint2.Y--;
							if (f.currentLocation.hasTileAt(tilePoint2, "Front") && f.Position.Y % 64f < 32f)
							{
								return;
							}
						}
						switch (farmerSprite.currentAnimationIndex)
						{
						case 0:
						case 1:
							spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2 - 4f, val.Y - 128f + 8f + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)1, num3);
							break;
						case 2:
							spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2 - 16f, val.Y - 128f + (float)num)), (Rectangle?)value, Color.White, -(float)Math.PI / 12f, new Vector2(0f, 16f), 4f, (SpriteEffects)1, num3);
							break;
						case 3:
							value.X += 16;
							spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2 - 16f, val.Y - 128f - 24f + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)1, num3);
							break;
						}
					}
					else
					{
						switch (farmerSprite.currentAnimationIndex)
						{
						case 0:
							spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + 32f + 8f + (float)num2 + (float)Math.Min(8, f.toolPower.Value * 4), val.Y - 128f + 8f + (float)num + (float)Math.Min(8, f.toolPower.Value * 4))), (Rectangle?)value, Color.White, (float)Math.PI / 12f + (float)Math.Min(f.toolPower.Value, 2) * ((float)Math.PI / 64f), new Vector2(0f, 16f), 4f, (SpriteEffects)1, num3);
							break;
						case 1:
							spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 16f + (float)num2, val.Y - 128f + 16f + (float)num)), (Rectangle?)value, Color.White, -(float)Math.PI / 12f, new Vector2(0f, 16f), 4f, (SpriteEffects)1, num3);
							break;
						case 2:
							spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f + 4f + (float)num2, val.Y - 128f + 60f + (float)num)), (Rectangle?)value, Color.White, -(float)Math.PI / 4f, new Vector2(0f, 16f), 4f, (SpriteEffects)1, num3);
							break;
						case 3:
							spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f + 20f + (float)num2, val.Y - 64f + 76f + (float)num)), (Rectangle?)value, Color.White, (float)Math.PI * -7f / 12f, new Vector2(0f, 16f), 4f, (SpriteEffects)1, num3);
							break;
						case 4:
							spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f + 24f + (float)num2, val.Y + 24f + (float)num)), (Rectangle?)value, Color.White, (float)Math.PI * -7f / 12f, new Vector2(0f, 16f), 4f, (SpriteEffects)1, num3);
							break;
						}
					}
					return;
				}
				Color color = fishingRod2.getColor();
				switch (farmerSprite.currentAnimationIndex)
				{
				case 0:
					if (fishingRod2.isReeling || fishingRod2.isFishing || fishingRod2.doneWithAnimation || !fishingRod2.hasDoneFucntionYet || fishingRod2.pullingOutOfWater)
					{
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f + (float)num2, val.Y - 160f + (float)num)), (Rectangle?)value, color, 0f, Vector2.Zero, 4f, (SpriteEffects)1, num3);
					}
					break;
				case 1:
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f + (float)num2, val.Y - 160f + 8f + (float)num)), (Rectangle?)value, color, 0f, Vector2.Zero, 4f, (SpriteEffects)1, num3);
					break;
				case 2:
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 96f + 32f + (float)num2, val.Y - 128f - 24f + (float)num)), (Rectangle?)value, color, 0f, Vector2.Zero, 4f, (SpriteEffects)1, num3);
					break;
				case 3:
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 96f + 24f + (float)num2, val.Y - 128f - 32f + (float)num)), (Rectangle?)value, color, 0f, Vector2.Zero, 4f, (SpriteEffects)1, num3);
					break;
				case 4:
					if (fishingRod2.isFishing || fishingRod2.doneWithAnimation)
					{
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f + (float)num2, val.Y - 160f + (float)num)), (Rectangle?)value, color, 0f, Vector2.Zero, 4f, (SpriteEffects)1, num3);
					}
					else
					{
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f + (float)num2, val.Y - 160f + 4f + (float)num)), (Rectangle?)value, color, 0f, Vector2.Zero, 4f, (SpriteEffects)1, num3);
					}
					break;
				case 5:
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f + (float)num2, val.Y - 160f + (float)num)), (Rectangle?)value, color, 0f, Vector2.Zero, 4f, (SpriteEffects)1, num3);
					break;
				}
				return;
			}
			}
			if (farmerSprite.currentAnimationIndex > 2 && !(f.CurrentTool is FishingRod { isCasting: false, castedButBobberStillInAir: false, isTimingCast: false }))
			{
				Point tilePoint5 = f.TilePoint;
				if (f.currentLocation.hasTileAt(tilePoint5, "Front") && f.Position.Y % 64f < 32f && f.Position.Y % 64f > 16f)
				{
					return;
				}
			}
			currentTool = f.CurrentTool;
			if (!(currentTool is FishingRod fishingRod5))
			{
				if (currentTool is WateringCan)
				{
					switch (farmerSprite.currentAnimationIndex)
					{
					case 0:
					case 1:
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2, val.Y - 128f + 16f + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
						break;
					case 2:
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2, val.Y - 128f - (float)((f.FacingDirection == 2) ? (-4) : 32) + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
						break;
					case 3:
						if (f.FacingDirection == 2)
						{
							value.X += 16;
						}
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2 - (float)((f.FacingDirection == 2) ? 4 : 0), val.Y - 128f - (float)((f.FacingDirection == 2) ? (-24) : 64) + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
						break;
					}
					return;
				}
				switch (farmerSprite.currentAnimationIndex)
				{
				case 0:
					if (f.FacingDirection == 0)
					{
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2, val.Y - 128f - 8f + (float)num + (float)Math.Min(8, f.toolPower.Value * 4))), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
					}
					else
					{
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2 - 20f, val.Y - 128f + 12f + (float)num + (float)Math.Min(8, f.toolPower.Value * 4))), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
					}
					break;
				case 1:
					if (f.FacingDirection == 0)
					{
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2 + 4f, val.Y - 128f + 40f + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
					}
					else
					{
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2 - 12f, val.Y - 128f + 32f + (float)num)), (Rectangle?)value, Color.White, -(float)Math.PI / 24f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
					}
					break;
				case 2:
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2, val.Y - 128f + 64f + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
					break;
				case 3:
					if (f.FacingDirection != 0)
					{
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2, val.Y - 64f + 44f + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
					}
					break;
				case 4:
					if (f.FacingDirection != 0)
					{
						spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2, val.Y - 64f + 48f + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
					}
					break;
				case 5:
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X + (float)num2, val.Y - 64f + 32f + (float)num)), (Rectangle?)value, Color.White, 0f, new Vector2(0f, 16f), 4f, (SpriteEffects)0, num3);
					break;
				}
				return;
			}
			if (farmerSprite.currentAnimationIndex <= 2)
			{
				Point tilePoint6 = f.TilePoint;
				tilePoint6.Y--;
				if (f.currentLocation.hasTileAt(tilePoint6, "Front"))
				{
					return;
				}
			}
			if (f.FacingDirection == 2)
			{
				num3 += 0.01f;
			}
			Color color3 = fishingRod5.getColor();
			switch (farmerSprite.currentAnimationIndex)
			{
			case 0:
				if (!fishingRod5.showingTreasure && !fishingRod5.fishCaught && (f.FacingDirection != 0 || !fishingRod5.isFishing || fishingRod5.isReeling))
				{
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f, val.Y - 128f + 4f)), (Rectangle?)value, color3, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
				}
				break;
			case 1:
				spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f, val.Y - 128f + 4f)), (Rectangle?)value, color3, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
				break;
			case 2:
				spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f, val.Y - 128f + 4f)), (Rectangle?)value, color3, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
				break;
			case 3:
				if (f.FacingDirection == 2)
				{
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f, val.Y - 128f + 4f)), (Rectangle?)value, color3, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
				}
				break;
			case 4:
				if (f.FacingDirection == 0 && fishingRod5.isFishing)
				{
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 80f, val.Y - 96f)), (Rectangle?)value, color3, 0f, Vector2.Zero, 4f, (SpriteEffects)2, num3);
				}
				else if (f.FacingDirection == 2)
				{
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f, val.Y - 128f + 4f)), (Rectangle?)value, color3, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
				}
				break;
			case 5:
				if (f.FacingDirection == 2 && !fishingRod5.showingTreasure && !fishingRod5.fishCaught)
				{
					spriteBatch.Draw(val2, Utility.snapToInt(new Vector2(val.X - 64f, val.Y - 128f + 4f)), (Rectangle?)value, color3, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num3);
				}
				break;
			}
		}
		else
		{
			f.CurrentTool.draw(spriteBatch);
		}
	}

	public static Vector2 GlobalToLocal(Rectangle viewport, Vector2 globalPosition)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2(globalPosition.X - (float)((Rectangle)(ref viewport)).X, globalPosition.Y - (float)((Rectangle)(ref viewport)).Y);
	}

	public static bool IsEnglish()
	{
		return content.GetCurrentLanguage() == LocalizedContentManager.LanguageCode.en;
	}

	public static Vector2 GlobalToLocal(Vector2 globalPosition)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		return new Vector2(globalPosition.X - (float)((Rectangle)(ref viewport)).X, globalPosition.Y - (float)((Rectangle)(ref viewport)).Y);
	}

	public static Rectangle GlobalToLocal(Rectangle viewport, Rectangle globalPosition)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		return new Rectangle(globalPosition.X - ((Rectangle)(ref viewport)).X, globalPosition.Y - ((Rectangle)(ref viewport)).Y, globalPosition.Width, globalPosition.Height);
	}

	public static string parseText(string text, SpriteFont whichFont, int width)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		if (text == null)
		{
			return "";
		}
		text = Dialogue.applyGenderSwitchBlocks(player.Gender, text);
		_ParseTextStringBuilder.Clear();
		_ParseTextStringBuilderLine.Clear();
		_ParseTextStringBuilderWord.Clear();
		float num = 0f;
		LocalizedContentManager.LanguageCode currentLanguageCode = LocalizedContentManager.CurrentLanguageCode;
		if (currentLanguageCode == LocalizedContentManager.LanguageCode.ja || currentLanguageCode == LocalizedContentManager.LanguageCode.zh || currentLanguageCode == LocalizedContentManager.LanguageCode.th)
		{
			foreach (object item in asianSpacingRegex.Matches(text))
			{
				string text2 = item.ToString();
				float num2 = whichFont.MeasureString(text2).X + whichFont.Spacing;
				if (num + num2 > (float)width || text2.Equals(Environment.NewLine) || text2.Equals("\n"))
				{
					_ParseTextStringBuilder.Append(_ParseTextStringBuilderLine);
					_ParseTextStringBuilder.Append(Environment.NewLine);
					_ParseTextStringBuilderLine.Clear();
					num = 0f;
				}
				if (!text2.Equals(Environment.NewLine) && !text2.Equals("\n"))
				{
					_ParseTextStringBuilderLine.Append(text2);
					num += num2;
				}
			}
			_ParseTextStringBuilder.Append(_ParseTextStringBuilderLine);
			return _ParseTextStringBuilder.ToString();
		}
		num = 0f;
		for (int i = 0; i < text.Length; i++)
		{
			char c = text[i];
			bool flag;
			if (c != '\n')
			{
				if (c == '\r')
				{
					continue;
				}
				if (c == ' ')
				{
					flag = true;
				}
				else
				{
					_ParseTextStringBuilderWord.Append(c);
					flag = i == text.Length - 1;
				}
			}
			else
			{
				flag = true;
			}
			if (!flag)
			{
				continue;
			}
			try
			{
				float num3 = whichFont.MeasureString(_ParseTextStringBuilderWord).X + whichFont.Spacing;
				if (num + num3 > (float)width)
				{
					_ParseTextStringBuilder.Append(_ParseTextStringBuilderLine);
					_ParseTextStringBuilder.Append(Environment.NewLine);
					_ParseTextStringBuilderLine.Clear();
					num = 0f;
				}
				if (c == '\n')
				{
					_ParseTextStringBuilderLine.Append(_ParseTextStringBuilderWord);
					_ParseTextStringBuilder.Append(_ParseTextStringBuilderLine);
					_ParseTextStringBuilder.Append(Environment.NewLine);
					_ParseTextStringBuilderLine.Clear();
					_ParseTextStringBuilderWord.Clear();
					num = 0f;
					continue;
				}
				_ParseTextStringBuilderLine.Append(_ParseTextStringBuilderWord);
				_ParseTextStringBuilderLine.Append(" ");
				float num4 = whichFont.MeasureString(" ").X + whichFont.Spacing;
				num += num3 + num4;
			}
			catch (Exception exception)
			{
				log.Error("Exception measuring string: ", exception);
			}
			_ParseTextStringBuilderWord.Clear();
		}
		_ParseTextStringBuilderLine.Append(_ParseTextStringBuilderWord);
		_ParseTextStringBuilder.Append(_ParseTextStringBuilderLine);
		return _ParseTextStringBuilder.ToString();
	}

	public static void UpdateHorseOwnership()
	{
		bool flag = false;
		Dictionary<long, Horse> dictionary = new Dictionary<long, Horse>();
		HashSet<Horse> hashSet = new HashSet<Horse>();
		List<Stable> stables = new List<Stable>();
		Utility.ForEachBuilding(delegate(Stable stable)
		{
			stables.Add(stable);
			return true;
		});
		foreach (Stable item in stables)
		{
			if (item.owner.Value == -6666666 && GetPlayer(-6666666L) == null)
			{
				item.owner.Value = player.UniqueMultiplayerID;
			}
			item.grabHorse();
		}
		foreach (Stable item2 in stables)
		{
			Horse stableHorse = item2.getStableHorse();
			if (stableHorse != null && !hashSet.Contains(stableHorse) && stableHorse.getOwner() != null && !dictionary.ContainsKey(stableHorse.getOwner().UniqueMultiplayerID) && stableHorse.getOwner().horseName.Value != null && stableHorse.getOwner().horseName.Value.Length > 0 && stableHorse.Name == stableHorse.getOwner().horseName.Value)
			{
				dictionary[stableHorse.getOwner().UniqueMultiplayerID] = stableHorse;
				hashSet.Add(stableHorse);
				if (flag)
				{
					log.Verbose("Assigned horse " + stableHorse.Name + " to " + stableHorse.getOwner().Name + " (Exact match)");
				}
			}
		}
		Dictionary<string, Farmer> dictionary2 = new Dictionary<string, Farmer>();
		foreach (Farmer allFarmer in getAllFarmers())
		{
			if (string.IsNullOrEmpty(allFarmer?.horseName.Value))
			{
				continue;
			}
			bool flag2 = false;
			foreach (Horse item3 in hashSet)
			{
				if (item3.getOwner() == allFarmer)
				{
					flag2 = true;
					break;
				}
			}
			if (!flag2)
			{
				dictionary2[allFarmer.horseName.Value] = allFarmer;
			}
		}
		foreach (Stable item4 in stables)
		{
			Horse stableHorse2 = item4.getStableHorse();
			if (stableHorse2 != null && !hashSet.Contains(stableHorse2) && stableHorse2.getOwner() != null && stableHorse2.Name != null && stableHorse2.Name.Length > 0 && dictionary2.TryGetValue(stableHorse2.Name, out var value) && !dictionary.ContainsKey(value.UniqueMultiplayerID))
			{
				item4.owner.Value = value.UniqueMultiplayerID;
				item4.updateHorseOwnership();
				dictionary[stableHorse2.getOwner().UniqueMultiplayerID] = stableHorse2;
				hashSet.Add(stableHorse2);
				if (flag)
				{
					log.Verbose("Assigned horse " + stableHorse2.Name + " to " + stableHorse2.getOwner().Name + " (Name match from different owner.)");
				}
			}
		}
		foreach (Stable item5 in stables)
		{
			Horse stableHorse3 = item5.getStableHorse();
			if (stableHorse3 != null && !hashSet.Contains(stableHorse3) && stableHorse3.getOwner() != null && !dictionary.ContainsKey(stableHorse3.getOwner().UniqueMultiplayerID))
			{
				dictionary[stableHorse3.getOwner().UniqueMultiplayerID] = stableHorse3;
				hashSet.Add(stableHorse3);
				item5.updateHorseOwnership();
				if (flag)
				{
					log.Verbose("Assigned horse " + stableHorse3.Name + " to " + stableHorse3.getOwner().Name + " (Owner's only stable)");
				}
			}
		}
		foreach (Stable item6 in stables)
		{
			Horse stableHorse4 = item6.getStableHorse();
			if (stableHorse4 == null || hashSet.Contains(stableHorse4))
			{
				continue;
			}
			foreach (Horse item7 in hashSet)
			{
				if (stableHorse4.ownerId == item7.ownerId)
				{
					item6.owner.Value = 0L;
					item6.updateHorseOwnership();
					if (flag)
					{
						log.Verbose("Unassigned horse (stable owner already has a horse).");
					}
					break;
				}
			}
		}
	}

	public static string LoadStringByGender(Gender npcGender, string key)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if ((int)npcGender == 0)
		{
			return content.LoadString(key).Split('/')[0];
		}
		return content.LoadString(key).Split('/').Last();
	}

	public static string LoadStringByGender(Gender npcGender, string key, params object[] substitutions)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		string text;
		if ((int)npcGender == 0)
		{
			text = content.LoadString(key).Split('/')[0];
			if (substitutions.Length != 0)
			{
				try
				{
					return string.Format(text, substitutions);
				}
				catch
				{
					return text;
				}
			}
		}
		text = content.LoadString(key).Split('/').Last();
		if (substitutions.Length != 0)
		{
			try
			{
				return string.Format(text, substitutions);
			}
			catch
			{
				return text;
			}
		}
		return text;
	}

	public static string parseText(string text)
	{
		return parseText(text, dialogueFont, dialogueWidth);
	}

	public static Rectangle getSourceRectForStandardTileSheet(Texture2D tileSheet, int tilePosition, int width = -1, int height = -1)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (width == -1)
		{
			width = 64;
		}
		if (height == -1)
		{
			height = 64;
		}
		return new Rectangle(tilePosition * width % tileSheet.Width, tilePosition * width / tileSheet.Width * height, width, height);
	}

	public static Rectangle getSquareSourceRectForNonStandardTileSheet(Texture2D tileSheet, int tileWidth, int tileHeight, int tilePosition)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		return new Rectangle(tilePosition * tileWidth % tileSheet.Width, tilePosition * tileWidth / tileSheet.Width * tileHeight, tileWidth, tileHeight);
	}

	public static Rectangle getArbitrarySourceRect(Texture2D tileSheet, int tileWidth, int tileHeight, int tilePosition)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		if (tileSheet != null)
		{
			return new Rectangle(tilePosition * tileWidth % tileSheet.Width, tilePosition * tileWidth / tileSheet.Width * tileHeight, tileWidth, tileHeight);
		}
		return Rectangle.Empty;
	}

	public static string getTimeOfDayString(int time)
	{
		string text = ((time % 100 == 0) ? "0" : string.Empty);
		string text2;
		switch (LocalizedContentManager.CurrentLanguageCode)
		{
		default:
			text2 = ((time / 100 % 12 == 0) ? "12" : (time / 100 % 12).ToString());
			break;
		case LocalizedContentManager.LanguageCode.ja:
			text2 = ((time / 100 % 12 == 0) ? "0" : (time / 100 % 12).ToString());
			break;
		case LocalizedContentManager.LanguageCode.zh:
			text2 = (time / 100 % 24).ToString();
			break;
		case LocalizedContentManager.LanguageCode.ru:
		case LocalizedContentManager.LanguageCode.pt:
		case LocalizedContentManager.LanguageCode.es:
		case LocalizedContentManager.LanguageCode.de:
		case LocalizedContentManager.LanguageCode.th:
		case LocalizedContentManager.LanguageCode.fr:
		case LocalizedContentManager.LanguageCode.tr:
		case LocalizedContentManager.LanguageCode.hu:
			text2 = (time / 100 % 24).ToString();
			text2 = ((time / 100 % 24 <= 9) ? ("0" + text2) : text2);
			break;
		}
		string text3 = text2 + ":" + time % 100 + text;
		switch (LocalizedContentManager.CurrentLanguageCode)
		{
		case LocalizedContentManager.LanguageCode.en:
			return text3 + " " + ((time < 1200 || time >= 2400) ? content.LoadString("Strings\\StringsFromCSFiles:DayTimeMoneyBox.cs.10370") : content.LoadString("Strings\\StringsFromCSFiles:DayTimeMoneyBox.cs.10371"));
		case LocalizedContentManager.LanguageCode.ja:
			if (time >= 1200 && time < 2400)
			{
				return content.LoadString("Strings\\StringsFromCSFiles:DayTimeMoneyBox.cs.10371") + " " + text3;
			}
			return content.LoadString("Strings\\StringsFromCSFiles:DayTimeMoneyBox.cs.10370") + " " + text3;
		case LocalizedContentManager.LanguageCode.fr:
			if (time % 100 != 0)
			{
				return text2 + "h" + time % 100;
			}
			return text2 + "h";
		case LocalizedContentManager.LanguageCode.mod:
			return LocalizedContentManager.FormatTimeString(time, LocalizedContentManager.CurrentModLanguage.TimeFormat).ToString();
		default:
			return text3;
		}
	}

	public static bool[,] getCircleOutlineGrid(int radius)
	{
		bool[,] array = new bool[radius * 2 + 1, radius * 2 + 1];
		int num = 1 - radius;
		int num2 = 1;
		int num3 = -2 * radius;
		int num4 = 0;
		int num5 = radius;
		array[radius, radius + radius] = true;
		array[radius, radius - radius] = true;
		array[radius + radius, radius] = true;
		array[radius - radius, radius] = true;
		while (num4 < num5)
		{
			if (num >= 0)
			{
				num5--;
				num3 += 2;
				num += num3;
			}
			num4++;
			num2 += 2;
			num += num2;
			array[radius + num4, radius + num5] = true;
			array[radius - num4, radius + num5] = true;
			array[radius + num4, radius - num5] = true;
			array[radius - num4, radius - num5] = true;
			array[radius + num5, radius + num4] = true;
			array[radius - num5, radius + num4] = true;
			array[radius + num5, radius - num4] = true;
			array[radius - num5, radius - num4] = true;
		}
		return array;
	}

	public static string GetFarmTypeID()
	{
		if (whichFarm != 7 || whichModFarm == null)
		{
			return whichFarm.ToString();
		}
		return whichModFarm.Id;
	}

	public static string GetFarmTypeKey()
	{
		return whichFarm switch
		{
			0 => "Standard", 
			1 => "Riverland", 
			2 => "Forest", 
			3 => "Hilltop", 
			4 => "Wilderness", 
			5 => "FourCorners", 
			6 => "Beach", 
			_ => GetFarmTypeID(), 
		};
	}

	public void _PerformRemoveNormalItemFromWorldOvernight(string itemId)
	{
		Utility.ForEachLocation(delegate(GameLocation location)
		{
			_RecursiveRemoveThisNormalItemLocation(location, itemId);
			return true;
		}, includeInteriors: true, includeGenerated: true);
		player.team.returnedDonations.RemoveWhere((Item item) => _RecursiveRemoveThisNormalItemItem(item, itemId));
		foreach (Inventory value in player.team.globalInventories.Values)
		{
			value.RemoveWhere((Item item) => _RecursiveRemoveThisNormalItemItem(item, itemId));
		}
		foreach (SpecialOrder specialOrder in player.team.specialOrders)
		{
			for (int num = 0; num < specialOrder.donatedItems.Count; num++)
			{
				Item this_item = specialOrder.donatedItems[num];
				if (_RecursiveRemoveThisNormalItemItem(this_item, itemId))
				{
					specialOrder.donatedItems[num] = null;
				}
			}
		}
	}

	protected virtual void _PerformRemoveNormalItemFromFarmerOvernight(Farmer farmer, string itemId)
	{
		for (int i = 0; i < farmer.Items.Count; i++)
		{
			if (_RecursiveRemoveThisNormalItemItem(farmer.Items[i], itemId))
			{
				farmer.Items[i] = null;
			}
		}
		farmer.itemsLostLastDeath.RemoveWhere((Item item) => _RecursiveRemoveThisNormalItemItem(item, itemId));
		if (farmer.recoveredItem != null && _RecursiveRemoveThisNormalItemItem(farmer.recoveredItem, itemId))
		{
			farmer.recoveredItem = null;
			farmer.mailbox.Remove("MarlonRecovery");
			farmer.mailForTomorrow.Remove("MarlonRecovery");
		}
		if (farmer.toolBeingUpgraded.Value != null && _RecursiveRemoveThisNormalItemItem(farmer.toolBeingUpgraded.Value, itemId))
		{
			farmer.toolBeingUpgraded.Value = null;
		}
	}

	protected virtual bool _RecursiveRemoveThisNormalItemItem(Item this_item, string itemId)
	{
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		if (this_item != null)
		{
			if (this_item is Object obj)
			{
				if (obj.heldObject.Value != null && _RecursiveRemoveThisNormalItemItem(obj.heldObject.Value, itemId))
				{
					obj.ResetParentSheetIndex();
					obj.heldObject.Value = null;
					obj.readyForHarvest.Value = false;
					obj.showNextIndex.Value = false;
				}
				if (!(obj is StorageFurniture storageFurniture))
				{
					if (!(obj is IndoorPot indoorPot))
					{
						if (obj is Chest chest)
						{
							bool flag = false;
							IInventory items = chest.Items;
							for (int i = 0; i < items.Count; i++)
							{
								Item item = items[i];
								if (item != null && _RecursiveRemoveThisNormalItemItem(item, itemId))
								{
									items[i] = null;
									flag = true;
								}
							}
							if (flag)
							{
								chest.clearNulls();
							}
						}
					}
					else if (indoorPot.hoeDirt.Value != null)
					{
						_RecursiveRemoveThisNormalItemDirt(indoorPot.hoeDirt.Value, null, Vector2.Zero, itemId);
					}
				}
				else
				{
					bool flag2 = false;
					for (int j = 0; j < storageFurniture.heldItems.Count; j++)
					{
						Item item2 = storageFurniture.heldItems[j];
						if (item2 != null && _RecursiveRemoveThisNormalItemItem(item2, itemId))
						{
							storageFurniture.heldItems[j] = null;
							flag2 = true;
						}
					}
					if (flag2)
					{
						storageFurniture.ClearNulls();
					}
				}
				if (obj.heldObject.Value != null && _RecursiveRemoveThisNormalItemItem(obj.heldObject.Value, itemId))
				{
					obj.heldObject.Value = null;
				}
			}
			return Utility.IsNormalObjectAtParentSheetIndex(this_item, itemId);
		}
		return false;
	}

	protected virtual void _RecursiveRemoveThisNormalItemDirt(HoeDirt dirt, GameLocation location, Vector2 coord, string itemId)
	{
		if (dirt.crop != null && dirt.crop.indexOfHarvest.Value == itemId)
		{
			dirt.destroyCrop(showAnimation: false);
		}
	}

	protected virtual void _RecursiveRemoveThisNormalItemLocation(GameLocation l, string itemId)
	{
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		if (l == null)
		{
			return;
		}
		List<Guid> list = new List<Guid>();
		foreach (Furniture item3 in l.furniture)
		{
			if (_RecursiveRemoveThisNormalItemItem(item3, itemId))
			{
				list.Add(l.furniture.GuidOf(item3));
			}
		}
		foreach (Guid item4 in list)
		{
			l.furniture.Remove(item4);
		}
		foreach (NPC character in l.characters)
		{
			if (character is Monster monster)
			{
				monster.objectsToDrop?.RemoveWhere((string id) => id == itemId);
			}
		}
		Chest fridge = l.GetFridge(onlyUnlocked: false);
		if (fridge != null)
		{
			IInventory items = fridge.Items;
			for (int num = 0; num < items.Count; num++)
			{
				Item item = items[num];
				if (item != null && _RecursiveRemoveThisNormalItemItem(item, itemId))
				{
					items[num] = null;
				}
			}
		}
		foreach (Vector2 key2 in l.terrainFeatures.Keys)
		{
			if (l.terrainFeatures[key2] is HoeDirt dirt)
			{
				_RecursiveRemoveThisNormalItemDirt(dirt, l, key2, itemId);
			}
		}
		foreach (Building building in l.buildings)
		{
			foreach (Chest buildingChest in building.buildingChests)
			{
				bool flag = false;
				for (int num2 = 0; num2 < buildingChest.Items.Count; num2++)
				{
					Item item2 = buildingChest.Items[num2];
					if (item2 != null && _RecursiveRemoveThisNormalItemItem(item2, itemId))
					{
						buildingChest.Items[num2] = null;
						flag = true;
					}
				}
				if (flag)
				{
					buildingChest.clearNulls();
				}
			}
		}
		Vector2[] array = l.objects.Keys.ToArray();
		foreach (Vector2 key in array)
		{
			Object obj = l.objects[key];
			if (obj != fridge && _RecursiveRemoveThisNormalItemItem(obj, itemId))
			{
				l.objects.Remove(key);
			}
		}
		l.debris.RemoveWhere((Debris debris) => debris.item != null && _RecursiveRemoveThisNormalItemItem(debris.item, itemId));
		if (l is ShopLocation shopLocation)
		{
			shopLocation.itemsFromPlayerToSell.RemoveWhere((Item this_item) => _RecursiveRemoveThisNormalItemItem(this_item, itemId));
			shopLocation.itemsToStartSellingTomorrow.RemoveWhere((Item this_item) => _RecursiveRemoveThisNormalItemItem(this_item, itemId));
		}
	}

	public static bool GetHasRoomAnotherFarm()
	{
		return true;
	}

	public virtual void ResetGameStateOnTitleScreen()
	{
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_0317: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0321: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_04db: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_051f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Unknown result type (might be due to invalid IL or missing references)
		//IL_0583: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0604: Unknown result type (might be due to invalid IL or missing references)
		//IL_0609: Unknown result type (might be due to invalid IL or missing references)
		//IL_0691: Unknown result type (might be due to invalid IL or missing references)
		//IL_0696: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ba: Unknown result type (might be due to invalid IL or missing references)
		LocalizedContentManager.localizedAssetNames.Clear();
		Event.invalidFestivals.Clear();
		NPC.invalidDialogueFiles.Clear();
		SaveGame.CancelToTitle = false;
		overlayMenu = null;
		multiplayer.cachedMultiplayerMaps.Clear();
		keyboardFocusInstance = null;
		BuildingPaintMenu.savedColors = null;
		startingGameSeed = null;
		UseLegacyRandom = false;
		_afterNewDayAction = null;
		_currentMinigame = null;
		gameMode = 0;
		_isSaving = false;
		_mouseCursorTransparency = 1f;
		_newDayTask = null;
		newDaySync.destroy();
		netReady.Reset();
		dedicatedServer.Reset();
		resetPlayer();
		afterDialogues = null;
		afterFade = null;
		afterPause = null;
		afterViewport = null;
		ambientLight = new Color(0, 0, 0, 0);
		background = null;
		chatBox = null;
		specialCurrencyDisplay?.Cleanup();
		GameLocation.PlayedNewLocationContextMusic = false;
		IsPlayingBackgroundMusic = false;
		IsPlayingNightAmbience = false;
		IsPlayingOutdoorsAmbience = false;
		IsPlayingMorningSong = false;
		IsPlayingTownMusic = false;
		specialCurrencyDisplay = null;
		conventionMode = false;
		currentCursorTile = Vector2.Zero;
		currentDialogueCharacterIndex = 0;
		currentLightSources.Clear();
		currentLoader = null;
		currentLocation = null;
		_PreviousNonNullLocation = null;
		currentObjectDialogue.Clear();
		currentQuestionChoice = 0;
		season = (Season)0;
		currentSpeaker = null;
		currentViewportTarget = Vector2.Zero;
		cursorTileHintCheckTimer = 0;
		CustomData = new SerializableDictionary<string, string>();
		player.team.sharedDailyLuck.Value = 0.001;
		dayOfMonth = 0;
		debrisSoundInterval = 0f;
		debrisWeather.Clear();
		debugMode = false;
		debugOutput = null;
		debugPresenceString = "In menus";
		delayedActions.Clear();
		morningSongPlayAction = null;
		dialogueButtonScale = 1f;
		dialogueButtonShrinking = false;
		dialogueTyping = false;
		dialogueTypingInterval = 0;
		dialogueUp = false;
		dialogueWidth = 1024;
		displayFarmer = true;
		displayHUD = true;
		downPolling = 0f;
		drawGrid = false;
		drawLighting = false;
		elliottBookName = "Blue Tower";
		endOfNightMenus.Clear();
		errorMessage = "";
		eveningColor = new Color(255, 255, 0, 255);
		eventOver = false;
		eventUp = false;
		exitToTitle = false;
		facingDirectionAfterWarp = 0;
		fadeIn = true;
		fadeToBlack = false;
		fadeToBlackAlpha = 1.02f;
		farmEvent = null;
		flashAlpha = 0f;
		freezeControls = false;
		gamePadAButtonPolling = 0;
		gameTimeInterval = 0;
		globalFade = false;
		globalFadeSpeed = 0f;
		haltAfterCheck = false;
		hasLoadedGame = false;
		hasStartedDay = false;
		hitShakeTimer = 0;
		hudMessages.Clear();
		isActionAtCurrentCursorTile = false;
		isDebrisWeather = false;
		isInspectionAtCurrentCursorTile = false;
		isLightning = false;
		isQuestion = false;
		isRaining = false;
		wasGreenRain = false;
		isSnowing = false;
		killScreen = false;
		lastCursorMotionWasMouse = true;
		lastCursorTile = Vector2.Zero;
		lastMousePositionBeforeFade = Point.Zero;
		leftPolling = 0f;
		loadingMessage = "";
		locationRequest = null;
		warpingForForcedRemoteEvent = false;
		locations.Clear();
		mailbox.Clear();
		mapDisplayDevice = CreateDisplayDevice((ContentManager)(object)content, base.GraphicsDevice);
		messageAfterPause = "";
		messagePause = false;
		mouseClickPolling = 0;
		mouseCursor = cursor_default;
		multiplayerMode = 0;
		netWorldState = new NetRoot<NetWorldState>(new NetWorldState());
		newDay = false;
		nonWarpFade = false;
		noteBlockTimer = 0f;
		npcDialogues = null;
		objectDialoguePortraitPerson = null;
		hasApplied1_3_UpdateChanges = false;
		hasApplied1_4_UpdateChanges = false;
		remoteEventQueue.Clear();
		bannedUsers?.Clear();
		nextClickableMenu.Clear();
		actionsWhenPlayerFree.Clear();
		onScreenMenus.Clear();
		onScreenMenus.Add(new Toolbar());
		dayTimeMoneyBox = new DayTimeMoneyBox();
		onScreenMenus.Add(dayTimeMoneyBox);
		buffsDisplay = new BuffsDisplay();
		onScreenMenus.Add(buffsDisplay);
		bool gamepadControls = options.gamepadControls;
		bool snappyMenus = options.snappyMenus;
		options = new Options();
		options.gamepadControls = gamepadControls;
		options.snappyMenus = snappyMenus;
		foreach (KeyValuePair<long, Farmer> otherFarmer in otherFarmers)
		{
			otherFarmer.Value.unload();
		}
		otherFarmers.Clear();
		outdoorLight = new Color(255, 255, 0, 255);
		overlayMenu = null;
		panFacingDirectionWait = false;
		panMode = false;
		panModeString = null;
		pauseAccumulator = 0f;
		paused = false;
		pauseThenDoFunctionTimer = 0;
		pauseTime = 0f;
		previousViewportPosition = Vector2.Zero;
		questionChoices.Clear();
		quit = false;
		rightClickPolling = 0;
		rightPolling = 0f;
		runThreshold = 0.5f;
		samBandName = "The Alfalfas";
		saveOnNewDay = true;
		startingCabins = 0;
		cabinsSeparate = false;
		screenGlow = false;
		screenGlowAlpha = 0f;
		screenGlowColor = new Color(0, 0, 0, 0);
		screenGlowHold = false;
		screenGlowMax = 0f;
		screenGlowRate = 0.005f;
		screenGlowUp = false;
		screenOverlayTempSprites.Clear();
		uiOverlayTempSprites.Clear();
		newGameSetupOptions.Clear();
		showingEndOfNightStuff = false;
		spawnMonstersAtNight = false;
		staminaShakeTimer = 0;
		textColor = new Color(34, 17, 34, 255);
		textShadowColor = new Color(206, 156, 95, 255);
		thumbstickMotionAccell = 1f;
		thumbstickMotionMargin = 0;
		thumbstickPollingTimer = 0;
		thumbStickSensitivity = 0.1f;
		timeOfDay = 600;
		timeOfDayAfterFade = -1;
		timerUntilMouseFade = 0;
		toggleFullScreen = false;
		ResetToolSpriteSheet();
		triggerPolling = 0;
		uniqueIDForThisGame = (ulong)(DateTime.UtcNow - new DateTime(2012, 6, 22)).TotalSeconds;
		upPolling = 0f;
		viewportFreeze = false;
		viewportHold = 0;
		viewportPositionLerp = Vector2.Zero;
		viewportReachedTarget = null;
		viewportSpeed = 2f;
		viewportTarget = new Vector2(-2.1474836E+09f, -2.1474836E+09f);
		wasMouseVisibleThisFrame = true;
		wasRainingYesterday = false;
		weatherForTomorrow = "Sun";
		elliottPiano = 0;
		weatherIcon = 0;
		weddingToday = false;
		whereIsTodaysFest = null;
		worldStateIDs.Clear();
		whichFarm = 0;
		whichModFarm = null;
		windGust = 0f;
		xLocationAfterWarp = 0;
		((ContentManager)game1.xTileContent).Dispose();
		game1.xTileContent = CreateContentManager(((ContentManager)content).ServiceProvider, ((ContentManager)content).RootDirectory);
		year = 1;
		yLocationAfterWarp = 0;
		mailDeliveredFromMailForTomorrow.Clear();
		bundleType = BundleType.Default;
		JojaMart.Morris = null;
		AmbientLocationSounds.onLocationLeave();
		WeatherDebris.globalWind = -0.25f;
		Utility.killAllStaticLoopingSoundCues();
		OptionsDropDown.selected = null;
		JunimoNoteMenu.tempSprites.Clear();
		JunimoNoteMenu.screenSwipe = null;
		JunimoNoteMenu.canClick = true;
		GameMenu.forcePreventClose = false;
		Club.timesPlayedCalicoJack = 0;
		MineShaft.activeMines.RemoveAll(delegate(MineShaft level)
		{
			level.OnRemoved();
			return true;
		});
		MineShaft.permanentMineChanges.Clear();
		MineShaft.numberOfCraftedStairsUsedThisRun = 0;
		MineShaft.mushroomLevelsGeneratedToday.Clear();
		VolcanoDungeon.activeLevels.RemoveAll(delegate(VolcanoDungeon level)
		{
			level.OnRemoved();
			return true;
		});
		ItemRegistry.ResetCache();
		Rumble.stopRumbling();
	}

	public virtual void CleanupReturningToTitle()
	{
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		if (game1.IsMainInstance)
		{
			foreach (Game1 gameInstance in GameRunner.instance.gameInstances)
			{
				if (gameInstance != this)
				{
					GameRunner.instance.RemoveGameInstance(gameInstance);
				}
			}
		}
		else
		{
			GameRunner.instance.RemoveGameInstance(this);
		}
		multiplayer.Disconnect(Multiplayer.DisconnectType.ExitedToMainMenu);
		ResetGameStateOnTitleScreen();
		serverHost = null;
		client = null;
		server = null;
		TitleMenu.subMenu = null;
		game1.refreshWindowSettings();
		if (activeClickableMenu is TitleMenu titleMenu)
		{
			titleMenu.applyPreferences();
			IClickableMenu clickableMenu = activeClickableMenu;
			Viewport val = graphics.GraphicsDevice.Viewport;
			Rectangle bounds = ((Viewport)(ref val)).Bounds;
			val = graphics.GraphicsDevice.Viewport;
			clickableMenu.gameWindowSizeChanged(bounds, ((Viewport)(ref val)).Bounds);
		}
	}

	public bool CanTakeScreenshots()
	{
		return true;
	}

	public string GetScreenshotFolder(bool createIfMissing = true)
	{
		return Program.GetLocalAppDataFolder("Screenshots", createIfMissing);
	}

	public bool CanBrowseScreenshots()
	{
		return Directory.Exists(GetScreenshotFolder(createIfMissing: false));
	}

	public bool CanZoomScreenshots()
	{
		return true;
	}

	public void BrowseScreenshots()
	{
		string screenshotFolder = GetScreenshotFolder(createIfMissing: false);
		if (Directory.Exists(screenshotFolder))
		{
			try
			{
				Process.Start(new ProcessStartInfo
				{
					FileName = screenshotFolder,
					UseShellExecute = true,
					Verb = "open"
				});
			}
			catch (Exception exception)
			{
				log.Error("Failed to open screenshot folder.", exception);
			}
		}
	}

	public string takeMapScreenshot(float? in_scale, string screenshot_name, Action onDone)
	{
		if (currentLocation == null)
		{
			return null;
		}
		float scale = 1f;
		if (in_scale.HasValue)
		{
			scale = in_scale.Value;
		}
		string screenshot_name2 = screenshot_name;
		if (string.IsNullOrWhiteSpace(screenshot_name))
		{
			DateTime utcNow = DateTime.UtcNow;
			screenshot_name2 = SaveGame.FilterFileName(player.name.Value) + $"_{utcNow.Month}-{utcNow.Day}-{utcNow.Year}_{(int)utcNow.TimeOfDay.TotalMilliseconds}";
		}
		return takeMapScreenshot(currentLocation, scale, screenshot_name2, onDone);
	}

	private unsafe string takeMapScreenshot(GameLocation screenshotLocation, float scale, string screenshot_name, Action onDone)
	{
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Expected O, but got Unknown
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Expected O, but got Unknown
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Expected O, but got Unknown
		//IL_0303: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Expected O, but got Unknown
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		string text = screenshot_name + ".png";
		GetScreenshotRegion(screenshotLocation, out var startX, out var startY, out var width, out var height);
		SKSurface val = null;
		bool flag;
		int num;
		int num2;
		do
		{
			flag = false;
			num = (int)((float)width * scale);
			num2 = (int)((float)height * scale);
			try
			{
				val = SKSurface.Create(num, num2, (SKColorType)5, (SKAlphaType)1);
			}
			catch (Exception exception)
			{
				log.Error("Map Screenshot: Error trying to create Bitmap.", exception);
				flag = true;
			}
			if (flag)
			{
				scale -= 0.25f;
			}
			if (scale <= 0f)
			{
				return null;
			}
		}
		while (flag);
		int num3 = 2048;
		int num4 = (int)((float)num3 * scale);
		Rectangle val2 = viewport;
		bool flag2 = displayHUD;
		takingMapScreenshot = true;
		float baseZoomLevel = options.baseZoomLevel;
		options.baseZoomLevel = 1f;
		RenderTarget2D val3 = _lightmap;
		_lightmap = null;
		bool flag3 = false;
		try
		{
			allocateLightmap(num3, num3);
			int num5 = (int)Math.Ceiling((float)num / (float)num4);
			int num6 = (int)Math.Ceiling((float)num2 / (float)num4);
			Rectangle val4 = default(Rectangle);
			for (int i = 0; i < num6; i++)
			{
				for (int j = 0; j < num5; j++)
				{
					int num7 = num4;
					int num8 = num4;
					int num9 = j * num4;
					int num10 = i * num4;
					if (num9 + num4 > num)
					{
						num7 += num - (num9 + num4);
					}
					if (num10 + num4 > num2)
					{
						num8 += num2 - (num10 + num4);
					}
					if (num8 <= 0 || num7 <= 0)
					{
						continue;
					}
					((Rectangle)(ref val4))._002Ector(num9, num10, num7, num8);
					RenderTarget2D val5 = new RenderTarget2D(graphics.GraphicsDevice, num3, num3, false, (SurfaceFormat)0, (DepthFormat)0, 0, (RenderTargetUsage)0);
					viewport = new Rectangle(j * num3 + startX, i * num3 + startY, num3, num3);
					_draw(currentGameTime, val5);
					RenderTarget2D val6 = new RenderTarget2D(graphics.GraphicsDevice, num7, num8, false, (SurfaceFormat)0, (DepthFormat)0, 0, (RenderTargetUsage)0);
					base.GraphicsDevice.SetRenderTarget(val6);
					spriteBatch.Begin((SpriteSortMode)0, BlendState.Opaque, SamplerState.PointClamp, DepthStencilState.Default, RasterizerState.CullNone, (Effect)null, (Matrix?)null);
					Color white = Color.White;
					spriteBatch.Draw((Texture2D)(object)val5, Vector2.Zero, (Rectangle?)((Texture2D)val5).Bounds, white, 0f, Vector2.Zero, scale, (SpriteEffects)0, 1f);
					spriteBatch.End();
					((GraphicsResource)val5).Dispose();
					base.GraphicsDevice.SetRenderTarget((RenderTarget2D)null);
					Color[] array = (Color[])(object)new Color[num7 * num8];
					((Texture2D)val6).GetData<Color>(array);
					SKBitmap val7 = new SKBitmap(val4.Width, val4.Height, (SKColorType)5, (SKAlphaType)1);
					byte* ptr = (byte*)val7.GetPixels().ToPointer();
					for (int k = 0; k < num8; k++)
					{
						for (int l = 0; l < num7; l++)
						{
							*(ptr++) = ((Color)(ref array[l + k * num7])).R;
							*(ptr++) = ((Color)(ref array[l + k * num7])).G;
							*(ptr++) = ((Color)(ref array[l + k * num7])).B;
							*(ptr++) = byte.MaxValue;
						}
					}
					SKPaint val8 = new SKPaint();
					val.Canvas.DrawBitmap(val7, SKRect.Create((float)val4.X, (float)val4.Y, (float)num7, (float)num8), val8);
					((SKNativeObject)val7).Dispose();
					((GraphicsResource)val6).Dispose();
				}
			}
			string path = Path.Combine(GetScreenshotFolder(), text);
			val.Snapshot().Encode((SKEncodedImageFormat)4, 100).SaveTo((Stream)new FileStream(path, FileMode.OpenOrCreate));
			((SKNativeObject)val).Dispose();
		}
		catch (Exception exception2)
		{
			log.Error("Map Screenshot: Error taking screenshot.", exception2);
			base.GraphicsDevice.SetRenderTarget((RenderTarget2D)null);
			flag3 = true;
		}
		if (_lightmap != null)
		{
			((GraphicsResource)_lightmap).Dispose();
			_lightmap = null;
		}
		_lightmap = val3;
		options.baseZoomLevel = baseZoomLevel;
		takingMapScreenshot = false;
		displayHUD = flag2;
		viewport = val2;
		if (flag3)
		{
			return null;
		}
		return text;
	}

	private static void GetScreenshotRegion(GameLocation screenshotLocation, out int startX, out int startY, out int width, out int height)
	{
		startX = 0;
		startY = 0;
		width = screenshotLocation.map.DisplayWidth;
		height = screenshotLocation.map.DisplayHeight;
		try
		{
			string[] mapPropertySplitBySpaces = screenshotLocation.GetMapPropertySplitBySpaces("ScreenshotRegion");
			if (mapPropertySplitBySpaces.Length != 0)
			{
				if (!ArgUtility.TryGetInt(mapPropertySplitBySpaces, 0, out var value, out var error, "int topLeftX") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces, 1, out var value2, out error, "int topLeftY") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces, 2, out var value3, out error, "int bottomRightX") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces, 3, out var value4, out error, "int bottomRightY"))
				{
					screenshotLocation.LogMapPropertyError("ScreenshotRegion", mapPropertySplitBySpaces, error);
					return;
				}
				startX = value * 64;
				startY = value2 * 64;
				width = (value3 + 1) * 64 - startX;
				height = (value4 + 1) * 64 - startY;
			}
		}
		catch (Exception exception)
		{
			log.Error("GetScreenshotRegion failed with exception:", exception);
		}
	}
}
