using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.BellsAndWhistles;
using StardewValley.Extensions;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Menus;

namespace StardewValley;

public class Torch : Object
{
	public const float yVelocity = 1f;

	public const float yDissapearLevel = -100f;

	public const double ashChance = 0.015;

	private float color;

	private Vector2[] ashes = (Vector2[])(object)new Vector2[3];

	private float smokePuffTimer;

	public Torch()
		: this(1)
	{
	}

	public Torch(int initialStack)
		: base("93", initialStack)
	{
	}

	public Torch(int initialStack, string itemId)
		: base(itemId, initialStack)
	{
	}

	public Torch(string index, bool bigCraftable)
		: base(Vector2.Zero, index)
	{
	}//IL_000d: Unknown result type (might be due to invalid IL or missing references)


	public override void RecalculateBoundingBox()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		boundingBox.Value = new Rectangle((int)tileLocation.X * 64, (int)tileLocation.Y * 64, 64, 64);
	}

	protected override void MigrateLegacyItemId()
	{
		base.ItemId = parentSheetIndex.Value.ToString();
	}

	protected override Item GetOneNew()
	{
		if (!bigCraftable.Value)
		{
			return new Torch(1, base.ItemId);
		}
		return new Torch(base.ItemId, bigCraftable: true);
	}

	public override void actionOnPlayerEntry()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		base.actionOnPlayerEntry();
		if (bigCraftable.Value && isOn.Value)
		{
			AmbientLocationSounds.addSound(tileLocation.Value, 1);
		}
	}

	public override bool checkForAction(Farmer who, bool justCheckingForActivity = false)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		if (bigCraftable.Value)
		{
			if (justCheckingForActivity)
			{
				return true;
			}
			if (base.QualifiedItemId == "(BC)278")
			{
				Vector2 topLeftPositionForCenteringOnScreen = Utility.getTopLeftPositionForCenteringOnScreen(800 + IClickableMenu.borderWidth * 2, 600 + IClickableMenu.borderWidth * 2);
				Game1.activeClickableMenu = new CraftingPage((int)topLeftPositionForCenteringOnScreen.X, (int)topLeftPositionForCenteringOnScreen.Y, 800 + IClickableMenu.borderWidth * 2, 600 + IClickableMenu.borderWidth * 2, cooking: true, standaloneMenu: true);
				return true;
			}
			isOn.Value = !isOn.Value;
			if (isOn.Value)
			{
				if (bigCraftable.Value)
				{
					if (who != null)
					{
						Game1.playSound("fireball");
					}
					initializeLightSource(tileLocation.Value);
					AmbientLocationSounds.addSound(tileLocation.Value, 1);
				}
			}
			else if (bigCraftable.Value)
			{
				performRemoveAction();
				if (who != null)
				{
					Game1.playSound("woodyHit");
				}
			}
			return true;
		}
		return base.checkForAction(who, justCheckingForActivity);
	}

	public override bool placementAction(GameLocation location, int x, int y, Farmer who)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		Vector2 key = default(Vector2);
		((Vector2)(ref key))._002Ector((float)(x / 64), (float)(y / 64));
		Torch torch = (bigCraftable.Value ? new Torch(base.ItemId, bigCraftable: true) : new Torch(1, base.ItemId));
		if (bigCraftable.Value)
		{
			torch.isOn.Value = false;
		}
		location.objects.Add(key, torch);
		torch.initializeLightSource(key);
		if (who != null)
		{
			Game1.playSound("woodyStep");
		}
		return true;
	}

	public override bool isPassable()
	{
		return !bigCraftable.Value;
	}

	public override void updateWhenCurrentLocation(GameTime time)
	{
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		base.updateWhenCurrentLocation(time);
		GameLocation location = Location;
		if (location == null)
		{
			return;
		}
		updateAshes((int)(tileLocation.X * 2000f + tileLocation.Y));
		smokePuffTimer -= (float)time.ElapsedGameTime.TotalMilliseconds;
		if (smokePuffTimer <= 0f)
		{
			smokePuffTimer = 1000f;
			if (base.QualifiedItemId == "(BC)278")
			{
				Utility.addSmokePuff(location, tileLocation.Value * 64f + new Vector2(32f, -32f));
			}
		}
	}

	private void updateAshes(int identifier)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		if (!Utility.isOnScreen(tileLocation.Value * 64f, 256))
		{
			return;
		}
		for (int num = ashes.Length - 1; num >= 0; num--)
		{
			Vector2 val = ashes[num];
			val.Y -= 1f * ((float)(num + 1) * 0.25f);
			if (num % 2 != 0)
			{
				val.X += (float)Math.Sin((double)ashes[num].Y / (Math.PI * 2.0)) / 2f;
			}
			ashes[num] = val;
			if (Game1.random.NextDouble() < 0.0075 && ashes[num].Y < -100f)
			{
				ashes[num] = new Vector2((float)(Game1.random.Next(-1, 3) * 4) * 0.75f, 0f);
			}
		}
		color = Math.Max(-0.8f, Math.Min(0.7f, color + ashes[0].Y / 1200f));
	}

	public override void performRemoveAction()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		AmbientLocationSounds.removeSound(TileLocation);
		if (bigCraftable.Value)
		{
			isOn.Value = false;
		}
		base.performRemoveAction();
	}

	public override void draw(SpriteBatch spriteBatch, int xNonTile, int yNonTile, float layerDepth, float alpha = 1f)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
		Rectangle value = dataOrErrorItem.GetSourceRect(0, base.ParentSheetIndex).Clone();
		value.Y += 8;
		value.Height /= 2;
		spriteBatch.Draw(dataOrErrorItem.GetTexture(), Game1.GlobalToLocal(Game1.viewport, new Vector2((float)xNonTile, (float)(yNonTile + 32))), (Rectangle?)value, Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, layerDepth);
		value.X = 276 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(xNonTile * 320) + (double)(yNonTile * 49)) % 700.0 / 100.0) * 8;
		value.Y = 1965;
		value.Width = 8;
		value.Height = 8;
		spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(xNonTile + 32 + 4), (float)(yNonTile + 16 + 4))), (Rectangle?)value, Color.White * 0.75f, 0f, new Vector2(4f, 4f), 3f, (SpriteEffects)0, layerDepth + 1E-05f);
		spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(xNonTile + 32 + 4), (float)(yNonTile + 16 + 4))), (Rectangle?)new Rectangle(88, 1779, 30, 30), Color.PaleGoldenrod * (Game1.currentLocation.IsOutdoors ? 0.35f : 0.43f), 0f, new Vector2(15f, 15f), 8f + (float)(32.0 * Math.Sin((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(xNonTile * 777) + (double)(yNonTile * 9746)) % 3140.0 / 1000.0) / 50.0), (SpriteEffects)0, 1f);
	}

	public static void drawBasicTorch(SpriteBatch spriteBatch, float x, float y, float layerDepth, float alpha = 1f)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		Rectangle value = default(Rectangle);
		((Rectangle)(ref value))._002Ector(336, 48, 16, 16);
		value.Y += 8;
		value.Height /= 2;
		spriteBatch.Draw(Game1.objectSpriteSheet, Game1.GlobalToLocal(Game1.viewport, new Vector2(x, y + 32f)), (Rectangle?)value, Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, layerDepth);
		spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2(x + 32f + 2f, y + 16f)), (Rectangle?)new Rectangle(88, 1779, 30, 30), Color.PaleGoldenrod * (Game1.currentLocation.IsOutdoors ? 0.35f : 0.43f), 0f, new Vector2(15f, 15f), 4f + (float)(64.0 * Math.Sin((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 777f) + (double)(y * 9746f)) % 3140.0 / 1000.0) / 50.0), (SpriteEffects)0, 1f);
		value.X = 276 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 3204f) + (double)(y * 49f)) % 700.0 / 100.0) * 8;
		value.Y = 1965;
		value.Width = 8;
		value.Height = 8;
		spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2(x + 32f + 4f, y + 16f + 4f)), (Rectangle?)value, Color.White * 0.75f, 0f, new Vector2(4f, 4f), 3f, (SpriteEffects)0, layerDepth + 0.0001f);
	}

	public override void draw(SpriteBatch spriteBatch, int x, int y, float alpha = 1f)
	{
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0727: Unknown result type (might be due to invalid IL or missing references)
		//IL_0740: Unknown result type (might be due to invalid IL or missing references)
		//IL_0745: Unknown result type (might be due to invalid IL or missing references)
		//IL_0793: Unknown result type (might be due to invalid IL or missing references)
		//IL_079d: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0418: Unknown result type (might be due to invalid IL or missing references)
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0433: Unknown result type (might be due to invalid IL or missing references)
		//IL_0481: Unknown result type (might be due to invalid IL or missing references)
		//IL_048b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0495: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_051b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0525: Unknown result type (might be due to invalid IL or missing references)
		//IL_052f: Unknown result type (might be due to invalid IL or missing references)
		//IL_054d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0565: Unknown result type (might be due to invalid IL or missing references)
		//IL_056a: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0614: Unknown result type (might be due to invalid IL or missing references)
		//IL_0619: Unknown result type (might be due to invalid IL or missing references)
		//IL_061e: Unknown result type (might be due to invalid IL or missing references)
		//IL_062e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0633: Unknown result type (might be due to invalid IL or missing references)
		//IL_0635: Unknown result type (might be due to invalid IL or missing references)
		//IL_063c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0641: Unknown result type (might be due to invalid IL or missing references)
		//IL_0643: Unknown result type (might be due to invalid IL or missing references)
		//IL_0658: Unknown result type (might be due to invalid IL or missing references)
		//IL_065d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0662: Unknown result type (might be due to invalid IL or missing references)
		//IL_0666: Unknown result type (might be due to invalid IL or missing references)
		//IL_066d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0695: Unknown result type (might be due to invalid IL or missing references)
		//IL_069c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_0327: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0377: Unknown result type (might be due to invalid IL or missing references)
		//IL_0381: Unknown result type (might be due to invalid IL or missing references)
		//IL_038e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0703: Unknown result type (might be due to invalid IL or missing references)
		//IL_070d: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.eventUp)
		{
			GameLocation currentLocation = Game1.currentLocation;
			if ((currentLocation == null || currentLocation.currentEvent?.showGroundObjects != true) && !Game1.currentLocation.IsFarm)
			{
				return;
			}
		}
		if (!bigCraftable.Value)
		{
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
			Rectangle value = dataOrErrorItem.GetSourceRect(0, base.ParentSheetIndex).Clone();
			Rectangle boundingBoxAt = GetBoundingBoxAt(x, y);
			value.Y += 8;
			value.Height /= 2;
			spriteBatch.Draw(dataOrErrorItem.GetTexture(), Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)(y * 64 + 32))), (Rectangle?)value, Color.White, 0f, Vector2.Zero, (scale.Y > 1f) ? getScale().Y : 4f, (SpriteEffects)0, (float)(((Rectangle)(ref boundingBoxAt)).Center.Y - 16) / 10000f);
			spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + 32 + 2), (float)(y * 64 + 16))), (Rectangle?)new Rectangle(88, 1779, 30, 30), Color.PaleGoldenrod * (Game1.currentLocation.IsOutdoors ? 0.35f : 0.43f), 0f, new Vector2(15f, 15f), 4f + (float)(64.0 * Math.Sin((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 64 * 777) + (double)(y * 64 * 9746)) % 3140.0 / 1000.0) / 50.0), (SpriteEffects)0, (float)(((Rectangle)(ref boundingBoxAt)).Center.Y - 15) / 10000f);
			value.X = 276 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 3204) + (double)(y * 49)) % 700.0 / 100.0) * 8;
			value.Y = 1965;
			value.Width = 8;
			value.Height = 8;
			spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + 32 + 4), (float)(y * 64 + 16 + 4))), (Rectangle?)value, Color.White * 0.75f, 0f, new Vector2(4f, 4f), 3f, (SpriteEffects)0, (float)(((Rectangle)(ref boundingBoxAt)).Center.Y - 16) / 10000f);
			for (int i = 0; i < ashes.Length; i++)
			{
				spriteBatch.Draw(Game1.objectSpriteSheet, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + 32) + ashes[i].X, (float)(y * 64 + 32) + ashes[i].Y)), (Rectangle?)new Rectangle(344 + i % 3, 53, 1, 1), Color.White * 0.5f * ((-100f - ashes[i].Y / 2f) / -100f), 0f, Vector2.Zero, 3f, (SpriteEffects)0, (float)(((Rectangle)(ref boundingBoxAt)).Center.Y - 16) / 10000f);
			}
			return;
		}
		base.draw(spriteBatch, x, y, alpha);
		float num = Math.Max(0f, (float)((y + 1) * 64 - 24) / 10000f) + (float)x * 1E-05f;
		if (!isOn.Value)
		{
			return;
		}
		if (ItemContextTagManager.HasBaseTag(base.QualifiedItemId, "campfire_item"))
		{
			spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + 16 - 4), (float)(y * 64 - 8))), (Rectangle?)new Rectangle(276 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 3047) + (double)(y * 88)) % 400.0 / 100.0) * 12, 1985, 12, 11), Color.White, 0f, Vector2.Zero, 3f, (SpriteEffects)0, num + 0.0008f);
			spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + 32 - 12), (float)(y * 64))), (Rectangle?)new Rectangle(276 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 2047) + (double)(y * 98)) % 400.0 / 100.0) * 12, 1985, 12, 11), Color.White, 0f, Vector2.Zero, 3f, (SpriteEffects)0, num + 0.0009f);
			spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + 32 - 20), (float)(y * 64 + 12))), (Rectangle?)new Rectangle(276 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 2077) + (double)(y * 98)) % 400.0 / 100.0) * 12, 1985, 12, 11), Color.White, 0f, Vector2.Zero, 3f, (SpriteEffects)0, num + 0.001f);
			if (base.QualifiedItemId == "(BC)278")
			{
				ParsedItemData dataOrErrorItem2 = ItemRegistry.GetDataOrErrorItem(base.QualifiedItemId);
				Rectangle value2 = dataOrErrorItem2.GetSourceRect(1, base.ParentSheetIndex).Clone();
				value2.Height -= 16;
				Vector2 val = getScale();
				val *= 4f;
				Vector2 val2 = Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)(y * 64 - 64 + 12)));
				Rectangle val3 = default(Rectangle);
				((Rectangle)(ref val3))._002Ector((int)(val2.X - val.X / 2f) + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0), (int)(val2.Y - val.Y / 2f) + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0), (int)(64f + val.X), (int)(64f + val.Y / 2f));
				spriteBatch.Draw(dataOrErrorItem2.GetTexture(), val3, (Rectangle?)value2, Color.White * alpha, 0f, Vector2.Zero, (SpriteEffects)0, num + 0.0028f);
			}
		}
		else
		{
			spriteBatch.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64 + 16 - 8), (float)(y * 64 - 64 + 8))), (Rectangle?)new Rectangle(276 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(x * 3047) + (double)(y * 88)) % 400.0 / 100.0) * 12, 1985, 12, 11), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num + 0.0008f);
		}
	}
}
