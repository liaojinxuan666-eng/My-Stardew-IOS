using System;
using Microsoft.Xna.Framework.Input;

namespace StardewValley;

public struct ButtonCollection
{
	public struct ButtonEnumerator
	{
		private readonly Buttons _pressed;

		private int _current;

		public Buttons Current
		{
			get
			{
				if (_current < 0 || _current > 32)
				{
					throw new InvalidOperationException();
				}
				return (Buttons)(1 << _current);
			}
		}

		public ButtonEnumerator(Buttons pressed)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			_pressed = pressed;
			_current = -1;
		}

		public bool MoveNext()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			if ((int)_pressed == 0)
			{
				return false;
			}
			while (_current < 31)
			{
				_current++;
				if ((_pressed & (1 << _current)) != 0)
				{
					return true;
				}
			}
			return false;
		}

		public void Reset()
		{
			_current = -1;
		}
	}

	private readonly Buttons _pressed;

	private readonly int _count;

	public int Count => _count;

	public ButtonCollection(ref GamePadState padState, ref GamePadState oldPadState)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0282: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_036a: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_0389: Unknown result type (might be due to invalid IL or missing references)
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0338: Unknown result type (might be due to invalid IL or missing references)
		//IL_043d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0442: Unknown result type (might be due to invalid IL or missing references)
		//IL_0445: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0346: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_045c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0461: Unknown result type (might be due to invalid IL or missing references)
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_0410: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_047c: Unknown result type (might be due to invalid IL or missing references)
		//IL_041e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0428: Unknown result type (might be due to invalid IL or missing references)
		//IL_0429: Unknown result type (might be due to invalid IL or missing references)
		//IL_048a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0494: Unknown result type (might be due to invalid IL or missing references)
		//IL_0495: Unknown result type (might be due to invalid IL or missing references)
		_count = 0;
		_pressed = (Buttons)0;
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)4096) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4096))
		{
			_pressed = (Buttons)(_pressed | 0x1000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)8192) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)8192))
		{
			_pressed = (Buttons)(_pressed | 0x2000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)16384) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)16384))
		{
			_pressed = (Buttons)(_pressed | 0x4000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)32768) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)32768))
		{
			_pressed = (Buttons)(_pressed | 0x8000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)16) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)16))
		{
			_pressed = (Buttons)(_pressed | 0x10);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)32) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)32))
		{
			_pressed = (Buttons)(_pressed | 0x20);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)4194304) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4194304))
		{
			_pressed = (Buttons)(_pressed | 0x400000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)8388608) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)8388608))
		{
			_pressed = (Buttons)(_pressed | 0x800000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)512) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)512))
		{
			_pressed = (Buttons)(_pressed | 0x200);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)256) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)256))
		{
			_pressed = (Buttons)(_pressed | 0x100);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)1) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)1))
		{
			_pressed = (Buttons)(_pressed | 1);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)8) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)8))
		{
			_pressed = (Buttons)(_pressed | 8);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)2) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)2))
		{
			_pressed = (Buttons)(_pressed | 2);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)4) && !((GamePadState)(ref oldPadState)).IsButtonDown((Buttons)4))
		{
			_pressed = (Buttons)(_pressed | 4);
			_count++;
		}
		GamePadThumbSticks thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y > 0.2)
		{
			thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
			if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y <= 0.2 && Utility.thumbstickIsInDirection(0, padState))
			{
				_pressed = (Buttons)(_pressed | 0x10000000);
				_count++;
			}
		}
		thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X > 0.2)
		{
			thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
			if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X <= 0.2 && Utility.thumbstickIsInDirection(1, padState))
			{
				_pressed = (Buttons)(_pressed | 0x40000000);
				_count++;
			}
		}
		thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y < -0.2)
		{
			thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
			if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.Y >= -0.2 && Utility.thumbstickIsInDirection(2, padState))
			{
				_pressed = (Buttons)(_pressed | 0x20000000);
				_count++;
			}
		}
		thumbSticks = ((GamePadState)(ref padState)).ThumbSticks;
		if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X < -0.2)
		{
			thumbSticks = ((GamePadState)(ref oldPadState)).ThumbSticks;
			if ((double)((GamePadThumbSticks)(ref thumbSticks)).Left.X >= -0.2 && Utility.thumbstickIsInDirection(3, padState))
			{
				_pressed = (Buttons)(_pressed | 0x200000);
				_count++;
			}
		}
	}

	public ButtonCollection(ref GamePadState padState)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		_count = 0;
		_pressed = (Buttons)0;
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)4096))
		{
			_pressed = (Buttons)(_pressed | 0x1000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)8192))
		{
			_pressed = (Buttons)(_pressed | 0x2000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)16384))
		{
			_pressed = (Buttons)(_pressed | 0x4000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)32768))
		{
			_pressed = (Buttons)(_pressed | 0x8000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)16))
		{
			_pressed = (Buttons)(_pressed | 0x10);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)32))
		{
			_pressed = (Buttons)(_pressed | 0x20);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)4194304))
		{
			_pressed = (Buttons)(_pressed | 0x400000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)8388608))
		{
			_pressed = (Buttons)(_pressed | 0x800000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)512))
		{
			_pressed = (Buttons)(_pressed | 0x200);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)256))
		{
			_pressed = (Buttons)(_pressed | 0x100);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)1))
		{
			_pressed = (Buttons)(_pressed | 1);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)8))
		{
			_pressed = (Buttons)(_pressed | 8);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)2))
		{
			_pressed = (Buttons)(_pressed | 2);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)4))
		{
			_pressed = (Buttons)(_pressed | 4);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)268435456))
		{
			_pressed = (Buttons)(_pressed | 0x10000000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)1073741824))
		{
			_pressed = (Buttons)(_pressed | 0x40000000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)536870912))
		{
			_pressed = (Buttons)(_pressed | 0x20000000);
			_count++;
		}
		if (((GamePadState)(ref padState)).IsButtonDown((Buttons)2097152))
		{
			_pressed = (Buttons)(_pressed | 0x200000);
			_count++;
		}
	}

	public ButtonEnumerator GetEnumerator()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return new ButtonEnumerator(_pressed);
	}
}
