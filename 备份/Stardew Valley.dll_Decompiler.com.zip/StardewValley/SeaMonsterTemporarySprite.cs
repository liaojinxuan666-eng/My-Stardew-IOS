using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace StardewValley;

public class SeaMonsterTemporarySprite : TemporaryAnimatedSprite
{
	public new Texture2D texture;

	public SeaMonsterTemporarySprite(float animationInterval, int animationLength, int numberOfLoops, Vector2 position)
		: base(-666, animationInterval, animationLength, numberOfLoops, position, flicker: false, flipped: false)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		texture = Game1.content.Load<Texture2D>("LooseSprites\\SeaMonster");
		Game1.playSound("pullItemFromWater");
		currentParentTileIndex = 0;
	}

	public override void draw(SpriteBatch spriteBatch, bool localPosition = false, int xOffset = 0, int yOffset = 0, float extraAlpha = 1f)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		spriteBatch.Draw(texture, Game1.GlobalToLocal(Game1.viewport, base.Position), (Rectangle?)new Rectangle(currentParentTileIndex * 16, 0, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (base.Position.Y + 32f) / 10000f);
	}

	public override bool update(GameTime time)
	{
		timer += time.ElapsedGameTime.Milliseconds;
		if (timer > interval)
		{
			currentParentTileIndex++;
			timer = 0f;
			if (currentParentTileIndex >= animationLength)
			{
				currentNumberOfLoops++;
				currentParentTileIndex = 2;
			}
		}
		if (currentNumberOfLoops >= totalNumberOfLoops)
		{
			position.Y += 2f;
			if (position.Y >= (float)Game1.currentLocation.Map.DisplayHeight)
			{
				return true;
			}
		}
		return false;
	}
}
