using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Extensions;
using StardewValley.Menus;
using xTile.Dimensions;

namespace StardewValley;

public class HUDMessage
{
	public const float defaultTime = 3500f;

	public const int achievement_type = 1;

	public const int newQuest_type = 2;

	public const int error_type = 3;

	public const int stamina_type = 4;

	public const int health_type = 5;

	public const int screenshot_type = 6;

	public string message;

	public string type;

	public float timeLeft;

	public float transparency = 1f;

	public int number = -1;

	public int whatType;

	public bool achievement;

	public bool noIcon;

	public Item messageSubject;

	public HUDMessage(string message)
		: this(message, 3500f)
	{
	}

	public HUDMessage(string message, int whatType)
		: this(message, 5250f)
	{
		achievement = true;
		this.whatType = whatType;
	}

	public HUDMessage(string message, float timeLeft, bool fadeIn = false)
	{
		this.message = message;
		this.timeLeft = timeLeft;
		if (fadeIn)
		{
			transparency = 0f;
		}
	}

	public static HUDMessage ForItemGained(Item item, int count, string type = null)
	{
		return new HUDMessage(item.DisplayName)
		{
			number = count,
			type = (type ?? item.Name),
			messageSubject = item
		};
	}

	public static HUDMessage ForCornerTextbox(string message)
	{
		message = Game1.parseText(message, Game1.dialogueFont, 384);
		return new HUDMessage(message)
		{
			noIcon = true,
			timeLeft = 5250f
		};
	}

	public static HUDMessage ForAchievement(string achievementName)
	{
		return new HUDMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:HUDMessage.cs.3824") + achievementName, 5250f)
		{
			achievement = true,
			whatType = 1
		};
	}

	public virtual bool update(GameTime time)
	{
		timeLeft -= time.ElapsedGameTime.Milliseconds;
		if (timeLeft < 0f)
		{
			transparency -= 0.02f;
			if (transparency < 0f)
			{
				return true;
			}
		}
		else if (transparency < 1f)
		{
			transparency = Math.Min(transparency + 0.02f, 1f);
		}
		return false;
	}

	public virtual void draw(SpriteBatch b, int i, ref int heightUsed)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_066a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0429: Unknown result type (might be due to invalid IL or missing references)
		//IL_0435: Unknown result type (might be due to invalid IL or missing references)
		//IL_043f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0444: Unknown result type (might be due to invalid IL or missing references)
		//IL_0457: Unknown result type (might be due to invalid IL or missing references)
		//IL_0461: Unknown result type (might be due to invalid IL or missing references)
		//IL_046c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0480: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0510: Unknown result type (might be due to invalid IL or missing references)
		//IL_054d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0559: Unknown result type (might be due to invalid IL or missing references)
		//IL_0563: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_0578: Unknown result type (might be due to invalid IL or missing references)
		//IL_0582: Unknown result type (might be due to invalid IL or missing references)
		//IL_058d: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05de: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0606: Unknown result type (might be due to invalid IL or missing references)
		//IL_0610: Unknown result type (might be due to invalid IL or missing references)
		//IL_061b: Unknown result type (might be due to invalid IL or missing references)
		//IL_062f: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_06db: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0725: Unknown result type (might be due to invalid IL or missing references)
		//IL_0727: Unknown result type (might be due to invalid IL or missing references)
		//IL_0732: Unknown result type (might be due to invalid IL or missing references)
		Rectangle titleSafeArea = Game1.graphics.GraphicsDevice.Viewport.GetTitleSafeArea();
		if (noIcon)
		{
			int overrideX = ((Rectangle)(ref titleSafeArea)).Left + 16;
			int num = (int)Game1.dialogueFont.MeasureString(message).Y + 64;
			int overrideY = ((((Rectangle)(ref Game1.uiViewport)).Width < 1400) ? (-64) : 0) + ((Rectangle)(ref titleSafeArea)).Bottom - num - heightUsed - 64;
			heightUsed += num;
			IClickableMenu.drawHoverText(b, message, Game1.dialogueFont, 0, 0, -1, null, -1, null, null, 0, null, -1, overrideX, overrideY, transparency);
			return;
		}
		int num2 = 112;
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(((Rectangle)(ref titleSafeArea)).Left + 16), (float)(((Rectangle)(ref titleSafeArea)).Bottom - num2 - heightUsed - 64));
		heightUsed += num2;
		if (Game1.isOutdoorMapSmallerThanViewport())
		{
			val.X = Math.Max(((Rectangle)(ref titleSafeArea)).Left + 16, -((Rectangle)(ref Game1.uiViewport)).X + 16);
		}
		if (((Rectangle)(ref Game1.uiViewport)).Width < 1400)
		{
			val.Y -= 48f;
		}
		b.Draw(Game1.mouseCursors, val, (Rectangle?)((messageSubject is Object obj && obj.sellToStorePrice(-1L) > 500) ? new Rectangle(163, 399, 26, 24) : new Rectangle(293, 360, 26, 24)), Color.White * transparency, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
		float x = Game1.smallFont.MeasureString(message ?? "").X;
		b.Draw(Game1.mouseCursors, new Vector2(val.X + 104f, val.Y), (Rectangle?)new Rectangle(319, 360, 1, 24), Color.White * transparency, 0f, Vector2.Zero, new Vector2(x, 4f), (SpriteEffects)0, 1f);
		b.Draw(Game1.mouseCursors, new Vector2(val.X + 104f + x, val.Y), (Rectangle?)new Rectangle(323, 360, 6, 24), Color.White * transparency, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
		val.X += 16f;
		val.Y += 16f;
		if (messageSubject == null)
		{
			switch (whatType)
			{
			case 1:
				b.Draw(Game1.mouseCursors, val + new Vector2(8f, 8f) * 4f, (Rectangle?)new Rectangle(294, 392, 16, 16), Color.White * transparency, 0f, new Vector2(8f, 8f), 4f + Math.Max(0f, (timeLeft - 3000f) / 900f), (SpriteEffects)0, 1f);
				break;
			case 2:
				b.Draw(Game1.mouseCursors, val + new Vector2(8f, 8f) * 4f, (Rectangle?)new Rectangle(403, 496, 5, 14), Color.White * transparency, 0f, new Vector2(3f, 7f), 4f + Math.Max(0f, (timeLeft - 3000f) / 900f), (SpriteEffects)0, 1f);
				break;
			case 3:
				b.Draw(Game1.mouseCursors, val + new Vector2(8f, 8f) * 4f, (Rectangle?)new Rectangle(268, 470, 16, 16), Color.White * transparency, 0f, new Vector2(8f, 8f), 4f + Math.Max(0f, (timeLeft - 3000f) / 900f), (SpriteEffects)0, 1f);
				break;
			case 4:
				b.Draw(Game1.mouseCursors, val + new Vector2(8f, 8f) * 4f, (Rectangle?)new Rectangle(0, 411, 16, 16), Color.White * transparency, 0f, new Vector2(8f, 8f), 4f + Math.Max(0f, (timeLeft - 3000f) / 900f), (SpriteEffects)0, 1f);
				break;
			case 5:
				b.Draw(Game1.mouseCursors, val + new Vector2(8f, 8f) * 4f, (Rectangle?)new Rectangle(16, 411, 16, 16), Color.White * transparency, 0f, new Vector2(8f, 8f), 4f + Math.Max(0f, (timeLeft - 3000f) / 900f), (SpriteEffects)0, 1f);
				break;
			case 6:
				b.Draw(Game1.mouseCursors2, val + new Vector2(8f, 8f) * 4f, (Rectangle?)new Rectangle(96, 32, 16, 16), Color.White * transparency, 0f, new Vector2(8f, 8f), 4f + Math.Max(0f, (timeLeft - 3000f) / 900f), (SpriteEffects)0, 1f);
				break;
			}
		}
		else
		{
			messageSubject.drawInMenu(b, val, 1f + Math.Max(0f, (timeLeft - 3000f) / 900f), transparency, 1f, StackDrawType.Hide);
		}
		val.X += 51f;
		val.Y += 51f;
		if (number > 1)
		{
			Utility.drawTinyDigits(number, b, val, 3f, 1f, Color.White * transparency);
		}
		val.X += 32f;
		val.Y -= 33f;
		Utility.drawTextWithShadow(b, message ?? "", Game1.smallFont, val, Game1.textColor * transparency, 1f, 1f, -1, -1, transparency);
	}

	public static void numbersEasterEgg(int number)
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		if (number > 100000 && !Game1.player.mailReceived.Contains("numbersEgg1"))
		{
			Game1.player.mailReceived.Add("numbersEgg1");
			Game1.chatBox.addMessage("...", new Color(255, 255, 255));
		}
		if (number > 200000 && !Game1.player.mailReceived.Contains("numbersEgg2"))
		{
			Game1.player.mailReceived.Add("numbersEgg2");
			Game1.chatBox.addMessage("......", new Color(255, 255, 255));
		}
		if (number > 250000 && !Game1.player.mailReceived.Contains("numbersEgg3"))
		{
			Game1.player.mailReceived.Add("numbersEgg3");
			Game1.chatBox.addMessage((Game1.content.GetCurrentLanguage() == LocalizedContentManager.LanguageCode.en) ? "Shooting for a million?" : "...........???", new Color(255, 255, 255));
		}
		if (number > 500000 && !Game1.player.mailReceived.Contains("numbersEgg1.5"))
		{
			Game1.player.mailReceived.Add("numbersEgg1.5");
			Game1.chatBox.addMessage(".......................", new Color(255, 255, 255));
		}
		if (number <= 1000000 || Game1.player.mailReceived.Contains("numbersEgg7"))
		{
			return;
		}
		Game1.player.mailReceived.Add("numbersEgg7");
		Game1.chatBox.addMessage((Game1.content.GetCurrentLanguage() == LocalizedContentManager.LanguageCode.en) ? "[196] Secret Iridium Stackmaster Trophy Achieved [196]" : "[196]", new Color(104, 214, 255));
		Game1.playSound("discoverMineral");
		if (Game1.content.GetCurrentLanguage() == LocalizedContentManager.LanguageCode.en)
		{
			DelayedAction.functionAfterDelay(delegate
			{
				//IL_0013: Unknown result type (might be due to invalid IL or missing references)
				Game1.chatBox.addMessage("Qi: *slow clap*... Congratulations, kid. Ya did it. Now, on to the next challenge!", new Color(100, 50, 255));
			}, 6000);
		}
	}
}
