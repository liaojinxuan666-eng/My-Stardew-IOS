using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Extensions;

namespace StardewValley;

[XmlInclude(typeof(BuildingPaintColor))]
public class BuildingPainter
{
	[XmlIgnore]
	public static Dictionary<string, List<List<int>>> paintMaskLookup = new Dictionary<string, List<List<int>>>(StringComparer.OrdinalIgnoreCase);

	public static Texture2D Apply(Texture2D base_texture, string mask_path, BuildingPaintColor color)
	{
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Expected O, but got Unknown
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		if (!paintMaskLookup.TryGetValue(mask_path, out var value))
		{
			try
			{
				Texture2D obj = Game1.content.Load<Texture2D>(mask_path);
				Color[] array = (Color[])(object)new Color[obj.GetElementCount()];
				obj.GetData<Color>(array);
				value = new List<List<int>>();
				for (int i = 0; i < 3; i++)
				{
					value.Add(new List<int>());
				}
				for (int j = 0; j < array.Length; j++)
				{
					if (array[j] == Color.Red)
					{
						value[0].Add(j);
					}
					else if (array[j] == Color.Lime)
					{
						value[1].Add(j);
					}
					else if (array[j] == Color.Blue)
					{
						value[2].Add(j);
					}
				}
				paintMaskLookup[mask_path] = value;
			}
			catch (Exception)
			{
				paintMaskLookup[mask_path] = null;
			}
		}
		if (value == null)
		{
			return null;
		}
		if (!color.RequiresRecolor())
		{
			return null;
		}
		Color[] array2 = (Color[])(object)new Color[base_texture.GetElementCount()];
		base_texture.GetData<Color>(array2);
		Texture2D val = new Texture2D(Game1.graphics.GraphicsDevice, base_texture.GetActualWidth(), base_texture.GetActualHeight())
		{
			Name = "@BuildingPainter.paintedTexture"
		};
		if (base_texture.Width != base_texture.GetActualWidth() || base_texture.Height != base_texture.GetActualHeight())
		{
			val.SetContentSize(base_texture.Width, base_texture.Height);
		}
		if (!color.Color1Default.Value)
		{
			_ApplyPaint(0, -100, 0, array2, value[0]);
			_ApplyPaint(color.Color1Hue.Value, color.Color1Saturation.Value, color.Color1Lightness.Value, array2, value[0]);
		}
		if (!color.Color2Default.Value)
		{
			_ApplyPaint(0, -100, 0, array2, value[1]);
			_ApplyPaint(color.Color2Hue.Value, color.Color2Saturation.Value, color.Color2Lightness.Value, array2, value[1]);
		}
		if (!color.Color3Default.Value)
		{
			_ApplyPaint(0, -100, 0, array2, value[2]);
			_ApplyPaint(color.Color3Hue.Value, color.Color3Saturation.Value, color.Color3Lightness.Value, array2, value[2]);
		}
		val.SetData<Color>(array2);
		return val;
	}

	protected static void _ApplyPaint(int h_shift, int s_shift, int l_shift, Color[] pixels, List<int> indices)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		foreach (int index in indices)
		{
			if (index < pixels.Length)
			{
				Color val = pixels[index];
				Utility.RGBtoHSL(((Color)(ref val)).R, ((Color)(ref val)).G, ((Color)(ref val)).B, out var h, out var s, out var l);
				h += (double)h_shift;
				s += (double)s_shift / 100.0;
				l += (double)l_shift / 100.0;
				while (h > 360.0)
				{
					h -= 360.0;
				}
				for (; h < 0.0; h += 360.0)
				{
				}
				if (s < 0.0)
				{
					s = 0.0;
				}
				if (s > 1.0)
				{
					s = 1.0;
				}
				if (l < 0.0)
				{
					l = 0.0;
				}
				if (l > 1.0)
				{
					l = 1.0;
				}
				Utility.HSLtoRGB(h, s, l, out var r, out var g, out var b);
				((Color)(ref val)).R = (byte)r;
				((Color)(ref val)).G = (byte)g;
				((Color)(ref val)).B = (byte)b;
				pixels[index] = val;
			}
		}
	}
}
