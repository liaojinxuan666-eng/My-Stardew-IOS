using System;
using System.Diagnostics;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace StardewValley;

public static class DebugTools
{
	private static int _mainThreadId;

	private const string CommentFormat = "#----------------------------------------------------------------------------#";

	public static DebugMetricsComponent _metrics;

	private static bool _noFpsCap;

	public static string FormatDivider(string label = null)
	{
		if (string.IsNullOrEmpty(label))
		{
			return "#----------------------------------------------------------------------------#";
		}
		label = " " + label + " ";
		int num = "#----------------------------------------------------------------------------#".Length / 2 - label.Length / 2;
		int startIndex = num + label.Length;
		return "#----------------------------------------------------------------------------#".Substring(0, num) + label + "#----------------------------------------------------------------------------#".Substring(startIndex);
	}

	[Conditional("VALIDATE_MAIN_THREAD_ENABLED")]
	public static void ValidateIsMainThread(bool req)
	{
		if (Thread.CurrentThread.ManagedThreadId == _mainThreadId != req)
		{
			Game1.log.Warn(FormatDivider("ERROR: CODE EXECUTED ON UNSAFE THREAD!"));
			Debugger.Break();
			Environment.Exit(1);
		}
	}

	public static bool IsMainThread()
	{
		return Thread.CurrentThread.ManagedThreadId == _mainThreadId;
	}

	public static void Assert(bool expression, string failureMessage)
	{
		if (!expression)
		{
			Game1.log.Error(failureMessage);
		}
	}

	public static void GameConstructed(Game game)
	{
		_mainThreadId = Thread.CurrentThread.ManagedThreadId;
	}

	public static void GameLoadContent(Game game)
	{
	}

	public static void BeforeGameInitialize(Game game)
	{
		ApplyNoFpsCap(_noFpsCap);
	}

	public static void BeforeGameUpdate(Game1 game, ref GameTime gameTime)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Expected O, but got Unknown
		if (!Program.releaseBuild)
		{
			CheckInput(game);
			if (_noFpsCap)
			{
				gameTime = new GameTime(gameTime.TotalGameTime, game.TargetElapsedTime, gameTime.IsRunningSlowly);
			}
		}
	}

	public static void BeforeGameDraw(Game1 game, ref GameTime time)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Expected O, but got Unknown
		if (_noFpsCap)
		{
			time = new GameTime(time.TotalGameTime, game.TargetElapsedTime, time.IsRunningSlowly);
		}
	}

	private static void CheckInput(Game1 game)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		GamePadState state = Game1.input.GetGamePadState();
		if (Game1.IsPressEvent(ref state, (Buttons)64))
		{
			if (_metrics != null)
			{
				((DrawableGameComponent)_metrics).Visible = !((DrawableGameComponent)_metrics).Visible;
			}
			Game1.log.Verbose("Toggling Metrics (" + ((_metrics == null) ? "[null]" : ((DrawableGameComponent)_metrics).Visible.ToString()) + ")");
		}
		if (Game1.IsPressEvent(ref state, (Buttons)128) && ((GamePadState)(ref state)).IsButtonDown((Buttons)64))
		{
			_noFpsCap = !_noFpsCap;
			ApplyNoFpsCap(_noFpsCap);
		}
	}

	private static void ApplyNoFpsCap(bool nocap)
	{
	}
}
