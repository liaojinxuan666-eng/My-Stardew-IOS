using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Netcode;

namespace StardewValley;

public class AnimatedSprite : INetObject<NetFields>
{
	public delegate void endOfAnimationBehavior(Farmer who);

	public Texture2D spriteTexture;

	public string loadedTexture;

	public string overrideTextureName;

	public readonly NetString textureName = new NetString();

	public float timer;

	public float interval = 175f;

	public int framesPerAnimation = 4;

	public int currentFrame;

	public readonly NetInt spriteWidth = new NetInt(16);

	public readonly NetInt spriteHeight = new NetInt(24);

	public int tempSpriteHeight = -1;

	public Rectangle sourceRect;

	public bool loop = true;

	public bool ignoreStopAnimation;

	public bool textureUsesFlippedRightForLeft;

	public endOfAnimationBehavior endOfAnimationFunction;

	public readonly List<FarmerSprite.AnimationFrame> currentAnimation = new List<FarmerSprite.AnimationFrame>(12);

	public int oldFrame;

	public int currentAnimationIndex;

	protected ContentManager contentManager;

	public bool ignoreSourceRectUpdates;

	public NetFields NetFields { get; } = new NetFields("AnimatedSprite");

	public Texture2D Texture
	{
		get
		{
			loadTexture();
			return spriteTexture;
		}
	}

	protected int textureWidth
	{
		get
		{
			Texture2D texture = Texture;
			if (texture == null)
			{
				return 96;
			}
			return texture.Width;
		}
	}

	protected int textureHeight
	{
		get
		{
			Texture2D texture = Texture;
			if (texture == null)
			{
				return 128;
			}
			return texture.Height;
		}
	}

	public int SpriteWidth
	{
		get
		{
			return spriteWidth.Get();
		}
		set
		{
			spriteWidth.Value = value;
		}
	}

	public int SpriteHeight
	{
		get
		{
			if (tempSpriteHeight != -1)
			{
				return tempSpriteHeight;
			}
			return spriteHeight.Get();
		}
		set
		{
			spriteHeight.Value = value;
			tempSpriteHeight = -1;
		}
	}

	public virtual int CurrentFrame
	{
		get
		{
			return currentFrame;
		}
		set
		{
			currentFrame = value;
			UpdateSourceRect();
		}
	}

	public List<FarmerSprite.AnimationFrame> CurrentAnimation
	{
		get
		{
			if (currentAnimation.Count == 0)
			{
				return null;
			}
			return currentAnimation;
		}
		set
		{
			currentAnimation.Clear();
			if (value != null)
			{
				currentAnimation.AddRange(value);
			}
		}
	}

	public Rectangle SourceRect
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return sourceRect;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			sourceRect = value;
		}
	}

	public virtual Character Owner { get; protected set; }

	public AnimatedSprite()
	{
		initNetFields();
		contentManager = (ContentManager)(object)Game1.content;
	}

	public AnimatedSprite(ContentManager contentManager, string textureName, int currentFrame, int spriteWidth, int spriteHeight)
		: this()
	{
		this.contentManager = contentManager;
		this.currentFrame = currentFrame;
		SpriteWidth = spriteWidth;
		SpriteHeight = spriteHeight;
		LoadTexture(textureName);
	}

	public AnimatedSprite(ContentManager contentManager, string textureName)
		: this()
	{
		this.contentManager = contentManager;
		LoadTexture(textureName);
	}

	public AnimatedSprite(string textureName, int currentFrame, int spriteWidth, int spriteHeight)
		: this((ContentManager)(object)Game1.content, textureName, currentFrame, spriteWidth, spriteHeight)
	{
	}

	public AnimatedSprite(string textureName)
		: this((ContentManager)(object)Game1.content, textureName)
	{
	}

	protected virtual void initNetFields()
	{
		NetFields.SetOwner(this).AddField(textureName, "textureName").AddField(spriteWidth, "spriteWidth")
			.AddField(spriteHeight, "spriteHeight");
	}

	public virtual void SetOwner(Character owner)
	{
		Owner = owner;
	}

	public virtual void LoadTexture(string textureName, bool syncTextureName = true)
	{
		if (Game1.content.DoesAssetExist<Texture2D>(textureName))
		{
			if (syncTextureName)
			{
				this.textureName.Value = textureName;
				overrideTextureName = null;
			}
			else
			{
				overrideTextureName = textureName;
			}
			loadTexture();
		}
	}

	private void loadTexture()
	{
		string text = overrideTextureName ?? textureName.Value;
		if (!(loadedTexture == text))
		{
			spriteTexture = ((text != null) ? contentManager.Load<Texture2D>(text) : null);
			loadedTexture = text;
			if (spriteTexture != null)
			{
				UpdateSourceRect();
			}
		}
	}

	public int getHeight()
	{
		return SpriteHeight;
	}

	public int getWidth()
	{
		return SpriteWidth;
	}

	public virtual void StopAnimation()
	{
		if (ignoreStopAnimation)
		{
			return;
		}
		if (CurrentAnimation != null)
		{
			CurrentAnimation = null;
			currentFrame = oldFrame;
			UpdateSourceRect();
			return;
		}
		if (this is FarmerSprite && currentFrame >= 232)
		{
			currentFrame -= 8;
		}
		if (currentFrame >= 64 && currentFrame <= 155)
		{
			currentFrame = (currentFrame - currentFrame % (textureWidth / SpriteWidth)) % 32 + 96;
		}
		else if (textureUsesFlippedRightForLeft && currentFrame >= textureWidth / SpriteWidth * 3)
		{
			if (currentFrame == 14 && textureWidth / SpriteWidth == 4)
			{
				currentFrame = 4;
			}
		}
		else
		{
			currentFrame = (currentFrame - currentFrame % (textureWidth / SpriteWidth)) % 32;
		}
		UpdateSourceRect();
	}

	public virtual void standAndFaceDirection(int direction)
	{
		switch (direction)
		{
		case 0:
			currentFrame = 12;
			break;
		case 1:
			currentFrame = 6;
			break;
		case 2:
			currentFrame = 0;
			break;
		case 3:
			currentFrame = 6;
			break;
		}
		UpdateSourceRect();
	}

	public virtual void faceDirectionStandard(int direction)
	{
		switch (direction)
		{
		case 0:
			direction = 2;
			break;
		case 2:
			direction = 0;
			break;
		}
		currentFrame = direction * 4;
		UpdateSourceRect();
	}

	public virtual void faceDirection(int direction)
	{
		if (ignoreStopAnimation || CurrentAnimation != null)
		{
			return;
		}
		try
		{
			switch (direction)
			{
			case 0:
				currentFrame = textureWidth / SpriteWidth * 2 + currentFrame % (textureWidth / SpriteWidth);
				break;
			case 1:
				currentFrame = textureWidth / SpriteWidth + currentFrame % (textureWidth / SpriteWidth);
				break;
			case 2:
				currentFrame %= textureWidth / SpriteWidth;
				break;
			case 3:
				if (textureUsesFlippedRightForLeft)
				{
					currentFrame = textureWidth / SpriteWidth + currentFrame % (textureWidth / SpriteWidth);
				}
				else
				{
					currentFrame = textureWidth / SpriteWidth * 3 + currentFrame % (textureWidth / SpriteWidth);
				}
				break;
			}
		}
		catch (Exception)
		{
		}
		UpdateSourceRect();
	}

	public virtual void AnimateRight(GameTime gameTime, int intervalOffset = 0, string soundForFootstep = "")
	{
		if (currentFrame >= framesPerAnimation * 2 || currentFrame < framesPerAnimation)
		{
			currentFrame = framesPerAnimation + currentFrame % framesPerAnimation;
		}
		timer += (float)gameTime.ElapsedGameTime.TotalMilliseconds;
		if (timer > interval + (float)intervalOffset)
		{
			currentFrame++;
			timer = 0f;
			if (currentFrame % 2 != 0 && soundForFootstep.Length > 0 && (Game1.currentSong == null || Game1.currentSong.IsStopped))
			{
				Game1.playSound(soundForFootstep);
			}
			if (currentFrame >= framesPerAnimation * 2 && loop)
			{
				currentFrame = framesPerAnimation;
			}
		}
		UpdateSourceRect();
	}

	public virtual void AnimateUp(GameTime gameTime, int intervalOffset = 0, string soundForFootstep = "")
	{
		if (currentFrame >= framesPerAnimation * 3 || currentFrame < framesPerAnimation * 2)
		{
			currentFrame = framesPerAnimation * 2 + currentFrame % framesPerAnimation;
		}
		timer += (float)gameTime.ElapsedGameTime.TotalMilliseconds;
		if (timer > interval + (float)intervalOffset)
		{
			currentFrame++;
			timer = 0f;
			if (currentFrame % 2 != 0 && soundForFootstep.Length > 0 && (Game1.currentSong == null || Game1.currentSong.IsStopped))
			{
				Game1.playSound(soundForFootstep);
			}
			if (currentFrame >= framesPerAnimation * 3 && loop)
			{
				currentFrame = framesPerAnimation * 2;
			}
		}
		UpdateSourceRect();
	}

	public virtual void AnimateDown(GameTime gameTime, int intervalOffset = 0, string soundForFootstep = "")
	{
		if (currentFrame >= framesPerAnimation || currentFrame < 0)
		{
			currentFrame %= framesPerAnimation;
		}
		timer += (float)gameTime.ElapsedGameTime.TotalMilliseconds;
		if (timer > interval + (float)intervalOffset)
		{
			currentFrame++;
			timer = 0f;
			if (currentFrame % 2 != 0 && soundForFootstep.Length > 0 && (Game1.currentSong == null || Game1.currentSong.IsStopped))
			{
				Game1.playSound(soundForFootstep);
			}
			if (currentFrame >= framesPerAnimation && loop)
			{
				currentFrame = 0;
			}
		}
		UpdateSourceRect();
	}

	public virtual void AnimateLeft(GameTime gameTime, int intervalOffset = 0, string soundForFootstep = "")
	{
		if (currentFrame >= framesPerAnimation * 4 || currentFrame < framesPerAnimation * 3)
		{
			currentFrame = framesPerAnimation * 3 + currentFrame % framesPerAnimation;
		}
		timer += (float)gameTime.ElapsedGameTime.TotalMilliseconds;
		if (timer > interval + (float)intervalOffset)
		{
			currentFrame++;
			timer = 0f;
			if (currentFrame % 2 != 0 && soundForFootstep.Length > 0 && (Game1.currentSong == null || Game1.currentSong.IsStopped))
			{
				Game1.playSound(soundForFootstep);
			}
			if (currentFrame >= framesPerAnimation * 4 && loop)
			{
				currentFrame = framesPerAnimation * 3;
			}
		}
		UpdateSourceRect();
	}

	public virtual bool Animate(GameTime gameTime, int startFrame, int numberOfFrames, float interval)
	{
		if (currentFrame >= startFrame + numberOfFrames || currentFrame < startFrame)
		{
			currentFrame = startFrame + currentFrame % numberOfFrames;
		}
		timer += (float)gameTime.ElapsedGameTime.TotalMilliseconds;
		if (timer > interval)
		{
			currentFrame++;
			timer = 0f;
			if (currentFrame >= startFrame + numberOfFrames)
			{
				if (loop)
				{
					currentFrame = startFrame;
				}
				UpdateSourceRect();
				return true;
			}
		}
		UpdateSourceRect();
		return false;
	}

	public virtual void ClearAnimation()
	{
		currentAnimation.Clear();
		oldFrame = currentFrame;
		currentAnimationIndex = 0;
	}

	public virtual void AddFrame(FarmerSprite.AnimationFrame frame)
	{
		if (currentAnimation.Count == 0)
		{
			timer = frame.milliseconds;
			currentFrame = frame.frame;
		}
		currentAnimation.Add(frame);
	}

	public virtual void setCurrentAnimation(List<FarmerSprite.AnimationFrame> animation)
	{
		currentAnimation.Clear();
		currentAnimation.AddRange(animation);
		oldFrame = currentFrame;
		currentAnimationIndex = 0;
		if (CurrentAnimation.Count > 0)
		{
			timer = CurrentAnimation[0].milliseconds;
			currentFrame = CurrentAnimation[0].frame;
		}
	}

	public virtual bool animateOnce(GameTime time)
	{
		if (CurrentAnimation != null)
		{
			timer -= time.ElapsedGameTime.Milliseconds;
			if (timer <= 0f)
			{
				if (CurrentAnimation[currentAnimationIndex].frameEndBehavior != null)
				{
					CurrentAnimation[currentAnimationIndex].frameEndBehavior(null);
					if (CurrentAnimation == null)
					{
						currentFrame = oldFrame;
						CurrentAnimation = null;
						UpdateSourceRect();
						return true;
					}
				}
				currentAnimationIndex++;
				if (currentAnimationIndex >= CurrentAnimation.Count)
				{
					if (!loop)
					{
						currentFrame = oldFrame;
						CurrentAnimation = null;
						UpdateSourceRect();
						return true;
					}
					currentAnimationIndex = 0;
				}
				if (CurrentAnimation[currentAnimationIndex].frameStartBehavior != null)
				{
					CurrentAnimation[currentAnimationIndex].frameStartBehavior(null);
				}
				if (CurrentAnimation != null)
				{
					timer = CurrentAnimation[currentAnimationIndex].milliseconds;
					currentFrame = CurrentAnimation[currentAnimationIndex].frame;
				}
			}
			UpdateSourceRect();
			return false;
		}
		UpdateSourceRect();
		return true;
	}

	public virtual void UpdateSourceRect()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		if (ignoreSourceRectUpdates)
		{
			return;
		}
		int num = SpriteWidth;
		int num2 = SpriteHeight;
		int num3 = textureWidth;
		int num4 = textureHeight;
		SourceRect = GetSourceRect(num3, num, num2, currentFrame);
		if (Texture == null)
		{
			return;
		}
		Rectangle val = SourceRect;
		if (((Rectangle)(ref val)).Right <= num3)
		{
			val = SourceRect;
			if (((Rectangle)(ref val)).Bottom <= num4)
			{
				return;
			}
		}
		currentFrame = 0;
		SourceRect = GetSourceRect(num3, num, num2, currentFrame);
	}

	public virtual void draw(SpriteBatch b, Vector2 screenPosition, float layerDepth)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (Texture != null)
		{
			b.Draw(Texture, screenPosition, (Rectangle?)sourceRect, Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)((CurrentAnimation != null && CurrentAnimation[currentAnimationIndex].flip) ? 1 : 0), layerDepth);
		}
	}

	public virtual void draw(SpriteBatch b, Vector2 screenPosition, float layerDepth, int xOffset, int yOffset, Color c, bool flip = false, float scale = 1f, float rotation = 0f, bool characterSourceRectOffset = false)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if (Texture != null)
		{
			b.Draw(Texture, screenPosition, (Rectangle?)new Rectangle(sourceRect.X + xOffset, sourceRect.Y + yOffset, sourceRect.Width, sourceRect.Height), c, rotation, (Vector2)(characterSourceRectOffset ? new Vector2((float)(SpriteWidth / 2), (float)SpriteHeight * 3f / 4f) : Vector2.Zero), scale, (SpriteEffects)((flip || (CurrentAnimation != null && CurrentAnimation[currentAnimationIndex].flip)) ? 1 : 0), layerDepth);
		}
	}

	public virtual void drawShadow(SpriteBatch b, Vector2 screenPosition, float scale = 4f, float alpha = 1f)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		Texture2D shadowTexture = Game1.shadowTexture;
		Vector2 val = screenPosition + new Vector2((float)(SpriteWidth / 2 * 4) - scale, (float)(SpriteHeight * 4) - scale);
		Rectangle? val2 = Game1.shadowTexture.Bounds;
		Color val3 = Color.White * alpha;
		Rectangle bounds = Game1.shadowTexture.Bounds;
		b.Draw(shadowTexture, val, val2, val3, 0f, Utility.PointToVector2(((Rectangle)(ref bounds)).Center), scale, (SpriteEffects)0, 1E-05f);
	}

	public virtual void drawShadow(SpriteBatch b, Vector2 screenPosition, float scale = 4f)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		drawShadow(b, screenPosition, scale, 1f);
	}

	public virtual AnimatedSprite Clone()
	{
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		AnimatedSprite animatedSprite = new AnimatedSprite();
		animatedSprite.spriteWidth.Set(spriteWidth.Value);
		animatedSprite.spriteHeight.Set(spriteHeight.Value);
		animatedSprite.spriteTexture = spriteTexture;
		animatedSprite.loadedTexture = loadedTexture;
		animatedSprite.textureName.Set(textureName.Value);
		animatedSprite.timer = timer;
		animatedSprite.interval = interval;
		animatedSprite.framesPerAnimation = framesPerAnimation;
		animatedSprite.currentFrame = currentFrame;
		animatedSprite.tempSpriteHeight = tempSpriteHeight;
		animatedSprite.sourceRect = new Rectangle(sourceRect.X, sourceRect.Y, sourceRect.Width, sourceRect.Height);
		animatedSprite.loop = loop;
		animatedSprite.ignoreStopAnimation = ignoreStopAnimation;
		animatedSprite.textureUsesFlippedRightForLeft = textureUsesFlippedRightForLeft;
		animatedSprite.CurrentAnimation = CurrentAnimation;
		animatedSprite.oldFrame = oldFrame;
		animatedSprite.currentAnimationIndex = currentAnimationIndex;
		animatedSprite.contentManager = contentManager;
		animatedSprite.UpdateSourceRect();
		return animatedSprite;
	}

	public static Rectangle GetSourceRect(int textureWidth, int spriteWidth, int spriteHeight, int frame)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		return new Rectangle(frame * spriteWidth % textureWidth, frame * spriteWidth / textureWidth * spriteHeight, spriteWidth, spriteHeight);
	}
}
