using Microsoft.Xna.Framework;

namespace StardewValley;

public struct RainDrop
{
	public int frame;

	public int accumulator;

	public Vector2 position;

	public RainDrop(int x, int y, int frame, int accumulator)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		position = new Vector2((float)x, (float)y);
		this.frame = frame;
		this.accumulator = accumulator;
	}
}
