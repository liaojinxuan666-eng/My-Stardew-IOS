using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Netcode;
using StardewValley.Buildings;
using StardewValley.Events;
using StardewValley.GameData.Buildings;
using StardewValley.GameData.FarmAnimals;
using StardewValley.GameData.Machines;
using StardewValley.TokenizableStrings;
using xTile.Dimensions;

namespace StardewValley;

public class AnimalHouse : GameLocation
{
	[XmlElement("animalLimit")]
	public readonly NetInt animalLimit = new NetInt(4);

	public readonly NetLongList animalsThatLiveHere = new NetLongList();

	[XmlIgnore]
	public bool hasShownIncubatorBuildingFullMessage;

	public AnimalHouse()
	{
	}

	public AnimalHouse(string mapPath, string name)
		: base(mapPath, name)
	{
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(animalLimit, "animalLimit").AddField(animalsThatLiveHere, "animalsThatLiveHere");
	}

	public override void OnParentBuildingUpgraded(Building building)
	{
		base.OnParentBuildingUpgraded(building);
		BuildingData data = building.GetData();
		if (data != null)
		{
			animalLimit.Value = data.MaxOccupants;
		}
		resetPositionsOfAllAnimals();
		loadLights();
	}

	public bool isFull()
	{
		return animalsThatLiveHere.Count >= animalLimit.Value;
	}

	public override bool checkAction(Location tileLocation, Rectangle viewport, Farmer who)
	{
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		if (who.ActiveObject?.QualifiedItemId == "(O)178" && doesTileHaveProperty(tileLocation.X, tileLocation.Y, "Trough", "Back") != null && !objects.ContainsKey(new Vector2((float)tileLocation.X, (float)tileLocation.Y)))
		{
			objects.Add(new Vector2((float)tileLocation.X, (float)tileLocation.Y), (Object)who.ActiveObject.getOne());
			who.reduceActiveItemByOne();
			who.currentLocation.playSound("coin");
			Game1.haltAfterCheck = false;
			return true;
		}
		return base.checkAction(tileLocation, viewport, who);
	}

	protected override void resetSharedState()
	{
		resetPositionsOfAllAnimals();
		foreach (Object value in objects.Values)
		{
			if (!value.bigCraftable.Value)
			{
				continue;
			}
			MachineData machineData = value.GetMachineData();
			if (machineData == null || !machineData.IsIncubator || value.heldObject.Value == null || value.MinutesUntilReady > 0)
			{
				continue;
			}
			if (!isFull())
			{
				string text = "??";
				FarmAnimalData animalDataFromEgg = FarmAnimal.GetAnimalDataFromEgg(value.heldObject.Value, this);
				if (animalDataFromEgg != null && animalDataFromEgg.BirthText != null)
				{
					text = TokenParser.ParseText(animalDataFromEgg.BirthText);
				}
				currentEvent = new Event("none/-1000 -1000/farmer 2 9 0/pause 250/message \"" + text + "\"/pause 500/animalNaming/pause 500/end");
				break;
			}
			if (!hasShownIncubatorBuildingFullMessage)
			{
				hasShownIncubatorBuildingFullMessage = true;
				Game1.showGlobalMessage(Game1.content.LoadString("Strings\\Locations:AnimalHouse_Incubator_HouseFull"));
			}
		}
		base.resetSharedState();
	}

	public void addNewHatchedAnimal(string name)
	{
		bool flag = false;
		foreach (Object value in objects.Values)
		{
			if (value.bigCraftable.Value)
			{
				MachineData machineData = value.GetMachineData();
				if (machineData != null && machineData.IsIncubator && value.heldObject.Value != null && value.MinutesUntilReady <= 0 && !isFull())
				{
					flag = true;
					string id;
					FarmAnimalData data;
					FarmAnimal farmAnimal = new FarmAnimal(FarmAnimal.TryGetAnimalDataFromEgg(value.heldObject.Value, this, out id, out data) ? id : "White Chicken", Game1.multiplayer.getNewID(), Game1.player.UniqueMultiplayerID);
					farmAnimal.Name = name;
					farmAnimal.displayName = name;
					value.heldObject.Value = null;
					adoptAnimal(farmAnimal);
					break;
				}
			}
		}
		if (!flag && Game1.farmEvent is QuestionEvent questionEvent)
		{
			FarmAnimal farmAnimal2 = new FarmAnimal(questionEvent.animal.type.Value, Game1.multiplayer.getNewID(), Game1.player.UniqueMultiplayerID);
			farmAnimal2.Name = name;
			farmAnimal2.displayName = name;
			farmAnimal2.parentId.Value = questionEvent.animal.myID.Value;
			adoptAnimal(farmAnimal2);
			questionEvent.forceProceed = true;
		}
		Game1.exitActiveMenu();
	}

	public void adoptAnimal(FarmAnimal animal)
	{
		animals.Add(animal.myID.Value, animal);
		animal.currentLocation = this;
		animalsThatLiveHere.Add(animal.myID.Value);
		animal.homeInterior = this;
		animal.setRandomPosition(this);
		foreach (Farmer allFarmer in Game1.getAllFarmers())
		{
			string text = animal.displayType;
			if (text == "White Chicken" || text == "Brown Chicken")
			{
				text = "Chicken";
			}
			allFarmer.autoGenerateActiveDialogueEvent("purchasedAnimal_" + text);
		}
	}

	public void resetPositionsOfAllAnimals()
	{
		foreach (KeyValuePair<long, FarmAnimal> pair in animals.Pairs)
		{
			pair.Value.setRandomPosition(this);
		}
	}

	public override bool dropObject(Object obj, Vector2 location, Rectangle viewport, bool initialPlacement, Farmer who = null)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(int)(location.X / 64f), (float)(int)(location.Y / 64f));
		if (obj.QualifiedItemId == "(O)178" && doesTileHaveProperty((int)val.X, (int)val.Y, "Trough", "Back") != null)
		{
			return objects.TryAdd(val, obj);
		}
		return base.dropObject(obj, location, viewport, initialPlacement);
	}

	public override void TransferDataFromSavedLocation(GameLocation l)
	{
		animalLimit.Value = ((AnimalHouse)l).animalLimit.Value;
		base.TransferDataFromSavedLocation(l);
	}

	public override void DayUpdate(int dayOfMonth)
	{
		base.DayUpdate(dayOfMonth);
		if (HasMapPropertyWithValue("AutoFeed"))
		{
			feedAllAnimals();
		}
	}

	public void feedAllAnimals()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		GameLocation rootLocation = GetRootLocation();
		int num = 0;
		Vector2 key = default(Vector2);
		for (int i = 0; i < map.Layers[0].LayerWidth; i++)
		{
			for (int j = 0; j < map.Layers[0].LayerHeight; j++)
			{
				if (doesTileHaveProperty(i, j, "Trough", "Back") == null)
				{
					continue;
				}
				((Vector2)(ref key))._002Ector((float)i, (float)j);
				if (!objects.ContainsKey(key))
				{
					Object hayFromAnySilo = GameLocation.GetHayFromAnySilo(rootLocation);
					if (hayFromAnySilo == null)
					{
						return;
					}
					objects.Add(key, hayFromAnySilo);
					num++;
				}
				if (num >= animalLimit.Value)
				{
					return;
				}
			}
		}
	}
}
