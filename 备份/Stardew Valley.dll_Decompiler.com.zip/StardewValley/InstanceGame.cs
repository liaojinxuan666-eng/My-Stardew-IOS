using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace StardewValley;

public class InstanceGame
{
	public object staticVarHolder;

	public bool IsMainInstance
	{
		get
		{
			if (GameRunner.instance.gameInstances.Count != 0)
			{
				return GameRunner.instance.gameInstances[0] == this;
			}
			return true;
		}
	}

	public GraphicsDevice GraphicsDevice => ((Game)GameRunner.instance).GraphicsDevice;

	public ContentManager Content => ((Game)GameRunner.instance).Content;

	public GameComponentCollection Components => ((Game)GameRunner.instance).Components;

	public GameWindow Window => ((Game)GameRunner.instance).Window;

	public bool IsFixedTimeStep
	{
		get
		{
			return ((Game)GameRunner.instance).IsFixedTimeStep;
		}
		set
		{
			((Game)GameRunner.instance).IsFixedTimeStep = value;
		}
	}

	public bool IsActive => ((Game)GameRunner.instance).IsActive;

	public bool IsMouseVisible
	{
		get
		{
			return ((Game)GameRunner.instance).IsMouseVisible;
		}
		set
		{
			((Game)GameRunner.instance).IsMouseVisible = value;
		}
	}

	public TimeSpan TargetElapsedTime
	{
		get
		{
			return ((Game)GameRunner.instance).TargetElapsedTime;
		}
		set
		{
			((Game)GameRunner.instance).TargetElapsedTime = value;
		}
	}

	protected virtual void Initialize()
	{
	}

	protected virtual void LoadContent()
	{
	}

	protected virtual void UnloadContent()
	{
	}

	protected virtual void Update(GameTime game_time)
	{
	}

	protected virtual void OnActivated(object sender, EventArgs args)
	{
	}

	protected virtual void Draw(GameTime game_time)
	{
	}

	protected virtual void BeginDraw()
	{
	}

	protected virtual void EndDraw()
	{
	}

	public void Exit()
	{
		((Game)GameRunner.instance).Exit();
	}
}
