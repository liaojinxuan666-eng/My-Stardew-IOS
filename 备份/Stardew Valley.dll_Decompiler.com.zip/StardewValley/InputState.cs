using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace StardewValley;

public class InputState
{
	protected Point _simulatedMousePosition = Point.Zero;

	protected List<Keys> _ignoredKeys = new List<Keys>();

	protected List<Keys> _pressedKeys = new List<Keys>();

	protected KeyboardState? _keyState;

	protected int _lastKeyStateTick = -1;

	protected KeyboardState _currentKeyboardState;

	protected MouseState _currentMouseState;

	protected GamePadState _currentGamepadState;

	public virtual void UpdateStates()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Invalid comparison between Unknown and I4
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		_currentKeyboardState = Keyboard.GetState();
		_currentMouseState = Mouse.GetState();
		if ((int)Game1.playerOneIndex >= 0)
		{
			_currentGamepadState = GamePad.GetState(Game1.playerOneIndex);
		}
		else
		{
			_currentGamepadState = default(GamePadState);
		}
	}

	public virtual void Update()
	{
	}

	public virtual void IgnoreKeys(Keys[] keys)
	{
		if (keys.Length != 0)
		{
			_ignoredKeys.AddRange(keys);
		}
	}

	public virtual KeyboardState GetKeyboardState()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		if (!Game1.game1.IsMainInstance || !Game1.game1.HasKeyboardFocus())
		{
			return default(KeyboardState);
		}
		if (_lastKeyStateTick != Game1.ticks || !_keyState.HasValue)
		{
			if (_ignoredKeys.Count == 0)
			{
				_keyState = _currentKeyboardState;
			}
			else
			{
				_pressedKeys.Clear();
				_pressedKeys.AddRange(((KeyboardState)(ref _currentKeyboardState)).GetPressedKeys());
				_ignoredKeys.RemoveAll((Keys key) => !_pressedKeys.Contains(key));
				_pressedKeys.RemoveAll((Keys key) => _ignoredKeys.Contains(key));
				_keyState = new KeyboardState(_pressedKeys.ToArray());
			}
			_lastKeyStateTick = Game1.ticks;
		}
		return _keyState.Value;
	}

	public virtual GamePadState GetGamePadState()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Invalid comparison between Unknown and I4
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.options.gamepadMode == Options.GamepadModes.ForceOff || (int)Game1.playerOneIndex == -1)
		{
			return default(GamePadState);
		}
		return _currentGamepadState;
	}

	public virtual MouseState GetMouseState()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (!Game1.game1.IsMainInstance)
		{
			return new MouseState(_simulatedMousePosition.X, _simulatedMousePosition.Y, 0, (ButtonState)0, (ButtonState)0, (ButtonState)0, (ButtonState)0, (ButtonState)0);
		}
		return _currentMouseState;
	}

	public virtual void SetMousePosition(int x, int y)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		if (!Game1.game1.IsMainInstance)
		{
			_simulatedMousePosition.X = x;
			_simulatedMousePosition.Y = y;
		}
		else
		{
			Mouse.SetPosition(x, y);
			_currentMouseState = new MouseState(x, y, ((MouseState)(ref _currentMouseState)).ScrollWheelValue, ((MouseState)(ref _currentMouseState)).LeftButton, ((MouseState)(ref _currentMouseState)).MiddleButton, ((MouseState)(ref _currentMouseState)).RightButton, ((MouseState)(ref _currentMouseState)).XButton1, ((MouseState)(ref _currentMouseState)).XButton2);
		}
	}
}
