using System;
using System.Collections.Generic;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using StardewValley.NativeClipboard;

namespace StardewValley;

public class KeyboardDispatcher
{
	protected string _enteredText;

	protected List<char> _commandInputs = new List<char>();

	protected List<Keys> _keysDown = new List<Keys>();

	protected List<char> _charsEntered = new List<char>();

	protected GameWindow _window;

	protected KeyboardState _oldKeyboardState;

	private IKeyboardSubscriber _subscriber;

	private string _pasteResult = "";

	public IKeyboardSubscriber Subscriber
	{
		get
		{
			return _subscriber;
		}
		set
		{
			if (_subscriber != value)
			{
				if (_subscriber != null)
				{
					_subscriber.Selected = false;
				}
				_subscriber = value;
				if (_subscriber != null)
				{
					_subscriber.Selected = true;
				}
			}
		}
	}

	public void Cleanup()
	{
		if (Environment.OSVersion.Platform == PlatformID.Unix || Environment.OSVersion.Platform == PlatformID.Win32NT)
		{
			_window.TextInput -= Event_TextInput;
		}
		else
		{
			KeyboardInput.CharEntered -= EventInput_CharEntered;
			KeyboardInput.KeyDown -= EventInput_KeyDown;
		}
		_window = null;
	}

	public KeyboardDispatcher(GameWindow window)
	{
		_commandInputs = new List<char>();
		_keysDown = new List<Keys>();
		_charsEntered = new List<char>();
		_window = window;
		if (Environment.OSVersion.Platform == PlatformID.Unix || Environment.OSVersion.Platform == PlatformID.Win32NT)
		{
			window.TextInput += Event_TextInput;
			return;
		}
		if (Game1.game1.IsMainInstance)
		{
			KeyboardInput.Initialize(window);
		}
		KeyboardInput.CharEntered += EventInput_CharEntered;
		KeyboardInput.KeyDown += EventInput_KeyDown;
	}

	private void Event_KeyDown(object sender, Keys key)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Invalid comparison between Unknown and I4
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Invalid comparison between Unknown and I4
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Invalid comparison between Unknown and I4
		if (_subscriber == null)
		{
			return;
		}
		if ((int)key != 8)
		{
			if ((int)key != 9)
			{
				if ((int)key == 13)
				{
					_commandInputs.Add('\r');
				}
			}
			else
			{
				_commandInputs.Add('\t');
			}
		}
		else
		{
			_commandInputs.Add('\b');
		}
		_keysDown.Add(key);
	}

	private void Event_TextInput(object sender, TextInputEventArgs e)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Invalid comparison between Unknown and I4
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Invalid comparison between Unknown and I4
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Invalid comparison between Unknown and I4
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		if (_subscriber == null)
		{
			return;
		}
		Keys key = e.Key;
		if ((int)key != 8)
		{
			if ((int)key != 9)
			{
				if ((int)key == 13)
				{
					_commandInputs.Add('\r');
				}
				else if (!char.IsControl(e.Character))
				{
					_charsEntered.Add(e.Character);
				}
			}
			else
			{
				_commandInputs.Add('\t');
			}
		}
		else
		{
			_commandInputs.Add('\b');
		}
	}

	private void EventInput_KeyDown(object sender, KeyEventArgs e)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		_keysDown.Add(e.KeyCode);
	}

	private void EventInput_CharEntered(object sender, CharacterEventArgs e)
	{
		if (_subscriber == null)
		{
			return;
		}
		if (char.IsControl(e.Character))
		{
			if (e.Character == '\u0016')
			{
				Thread thread = new Thread(PasteThread);
				thread.SetApartmentState(ApartmentState.STA);
				thread.Start();
				thread.Join();
				_enteredText = _pasteResult;
			}
			else
			{
				_commandInputs.Add(e.Character);
			}
		}
		else
		{
			_charsEntered.Add(e.Character);
		}
	}

	public bool ShouldSuppress()
	{
		return false;
	}

	public void Discard()
	{
		_enteredText = null;
		_charsEntered.Clear();
		_commandInputs.Clear();
		_keysDown.Clear();
	}

	public void Poll()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		KeyboardState keyboardState = Game1.input.GetKeyboardState();
		bool flag = ((SdlClipboard.Platform != ClipboardPlatformType.OSX) ? (((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)162) || ((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)163)) : (((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)91) || ((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)92)));
		if (((KeyboardState)(ref keyboardState)).IsKeyDown((Keys)86) && !((KeyboardState)(ref _oldKeyboardState)).IsKeyDown((Keys)86) && flag)
		{
			string output = null;
			DesktopClipboard.GetText(ref output);
			if (output != null)
			{
				_enteredText = output;
			}
		}
		_oldKeyboardState = keyboardState;
		if (_enteredText != null)
		{
			if (_subscriber != null && !ShouldSuppress())
			{
				_subscriber.RecieveTextInput(_enteredText);
			}
			_enteredText = null;
		}
		if (_charsEntered.Count > 0)
		{
			if (_subscriber != null && !ShouldSuppress())
			{
				foreach (char item in _charsEntered)
				{
					_subscriber.RecieveTextInput(item);
					if (_subscriber == null)
					{
						break;
					}
				}
			}
			_charsEntered.Clear();
		}
		if (_commandInputs.Count > 0)
		{
			if (_subscriber != null && !ShouldSuppress())
			{
				foreach (char commandInput in _commandInputs)
				{
					_subscriber.RecieveCommandInput(commandInput);
					if (_subscriber == null)
					{
						break;
					}
				}
			}
			_commandInputs.Clear();
		}
		if (_keysDown.Count <= 0)
		{
			return;
		}
		if (_subscriber != null && !ShouldSuppress())
		{
			foreach (Keys item2 in _keysDown)
			{
				_subscriber.RecieveSpecialInput(item2);
				if (_subscriber == null)
				{
					break;
				}
			}
		}
		_keysDown.Clear();
	}

	[STAThread]
	private void PasteThread()
	{
		_pasteResult = "";
	}
}
