using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Extensions;
using StardewValley.Locations;
using xTile.Dimensions;
using xTile.Layers;

namespace StardewValley;

public class Background
{
	public int defaultChunkIndex;

	public int numChunksInSheet;

	public double chanceForDeviationFromDefault;

	protected Texture2D backgroundImage;

	protected Texture2D cloudsTexture;

	protected Vector2 position = Vector2.Zero;

	protected int chunksWide;

	protected int chunksHigh;

	protected int chunkWidth;

	protected int chunkHeight;

	protected int[] chunks;

	protected float zoom;

	public Color c;

	protected bool summitBG;

	protected bool onlyMapBG;

	public int yOffset;

	public TemporaryAnimatedSpriteList tempSprites;

	protected int initialViewportY;

	public bool cursed;

	protected GameLocation location;

	public Background(Summit location)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		this.location = location;
		summitBG = true;
		c = Color.White;
		initialViewportY = ((Rectangle)(ref Game1.viewport)).Y;
		cloudsTexture = Game1.content.Load<Texture2D>("Minigames\\Clouds");
	}

	public Background(GameLocation location, Color color, bool onlyMapBG)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		this.location = location;
		c = color;
		this.onlyMapBG = onlyMapBG;
		tempSprites = new TemporaryAnimatedSpriteList();
	}

	public Background(GameLocation location, Texture2D bgImage, int seedValue, int chunksWide, int chunksHigh, int chunkWidth, int chunkHeight, float zoom, int defaultChunkIndex, int numChunksInSheet, double chanceForDeviation, Color c)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		this.location = location;
		backgroundImage = bgImage;
		this.chunksWide = chunksWide;
		this.chunksHigh = chunksHigh;
		this.zoom = zoom;
		this.chunkWidth = chunkWidth;
		this.chunkHeight = chunkHeight;
		this.defaultChunkIndex = defaultChunkIndex;
		this.numChunksInSheet = numChunksInSheet;
		chanceForDeviationFromDefault = chanceForDeviation;
		this.c = c;
		Random random = Utility.CreateRandom(seedValue);
		chunks = new int[chunksWide * chunksHigh];
		for (int i = 0; i < chunksHigh * chunksWide; i++)
		{
			if (random.NextDouble() < chanceForDeviationFromDefault)
			{
				chunks[i] = random.Next(numChunksInSheet);
			}
			else
			{
				chunks[i] = defaultChunkIndex;
			}
		}
	}

	public virtual void update(Rectangle viewport)
	{
		Layer val = Game1.currentLocation.map.RequireLayer("Back");
		position.X = 0f - (float)(((Rectangle)(ref viewport)).X + ((Rectangle)(ref viewport)).Width / 2) / ((float)val.LayerWidth * 64f) * ((float)(chunksWide * chunkWidth) * zoom - (float)((Rectangle)(ref viewport)).Width);
		position.Y = 0f - (float)(((Rectangle)(ref viewport)).Y + ((Rectangle)(ref viewport)).Height / 2) / ((float)val.LayerHeight * 64f) * ((float)(chunksHigh * chunkHeight) * zoom - (float)((Rectangle)(ref viewport)).Height);
	}

	public virtual void draw(SpriteBatch b)
	{
		//IL_0c29: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Invalid comparison between Unknown and I4
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Invalid comparison between Unknown and I4
		//IL_0b9d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0baf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bb9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Invalid comparison between Unknown and I4
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d67: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d69: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d71: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d7b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d01: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Invalid comparison between Unknown and I4
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0327: Unknown result type (might be due to invalid IL or missing references)
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0401: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0415: Unknown result type (might be due to invalid IL or missing references)
		//IL_052e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0537: Unknown result type (might be due to invalid IL or missing references)
		//IL_056e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0578: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0625: Unknown result type (might be due to invalid IL or missing references)
		//IL_0642: Unknown result type (might be due to invalid IL or missing references)
		//IL_064c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0656: Unknown result type (might be due to invalid IL or missing references)
		//IL_0660: Unknown result type (might be due to invalid IL or missing references)
		//IL_0693: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0712: Unknown result type (might be due to invalid IL or missing references)
		//IL_072f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0739: Unknown result type (might be due to invalid IL or missing references)
		//IL_0743: Unknown result type (might be due to invalid IL or missing references)
		//IL_074d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a52: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0abe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_083f: Unknown result type (might be due to invalid IL or missing references)
		//IL_085d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0867: Unknown result type (might be due to invalid IL or missing references)
		//IL_0871: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0931: Unknown result type (might be due to invalid IL or missing references)
		//IL_094f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0959: Unknown result type (might be due to invalid IL or missing references)
		//IL_0966: Unknown result type (might be due to invalid IL or missing references)
		//IL_0970: Unknown result type (might be due to invalid IL or missing references)
		if (summitBG)
		{
			if (((Rectangle)(ref Game1.viewport)).X <= -1000)
			{
				return;
			}
			Season seasonForLocation = Game1.GetSeasonForLocation(location);
			bool flag = (int)seasonForLocation == 3;
			int num = (((int)seasonForLocation == 2) ? 1 : (((int)seasonForLocation == 3) ? 2 : 0));
			int num2 = -((Rectangle)(ref Game1.viewport)).Y / 4 + initialViewportY / 4;
			float num3 = 1f;
			float num4 = 1f;
			Color val = Color.White;
			int num5 = (int)((float)(Game1.timeOfDay - Game1.timeOfDay % 100) + (float)(Game1.timeOfDay % 100 / 10) * 16.66f);
			int num6 = (flag ? 30 : 0);
			if (Game1.timeOfDay >= 1800)
			{
				c = new Color(255f, 255f - Math.Max(100f, (float)num5 + (float)Game1.gameTimeInterval / (float)Game1.realMilliSecondsPerGameTenMinutes * 16.6f - 1800f), 255f - Math.Max(100f, ((float)num5 + (float)Game1.gameTimeInterval / (float)Game1.realMilliSecondsPerGameTenMinutes * 16.6f - 1800f) / 2f));
				val = (flag ? (Color.Black * 0.5f) : (Color.Blue * 0.5f));
				num3 = Math.Max(0f, Math.Min(1f, (2000f - ((float)num5 + (float)Game1.gameTimeInterval / (float)Game1.realMilliSecondsPerGameTenMinutes * 16.6f)) / 200f));
				num4 = Math.Max(0f, Math.Min(1f, (2200f - ((float)num5 + (float)Game1.gameTimeInterval / (float)Game1.realMilliSecondsPerGameTenMinutes * 16.6f)) / 400f));
				Game1.ambientLight = new Color((int)Utility.Lerp(0f, 30f, 1f - num3), (int)Utility.Lerp(0f, 60f, 1f - num3), (int)Utility.Lerp(0f, 15f, 1f - num3));
			}
			b.Draw(Game1.mouseCursors, new Rectangle(0, 0, ((Rectangle)(ref Game1.viewport)).Width, ((Rectangle)(ref Game1.viewport)).Height), (Rectangle?)new Rectangle(639, 858, 1, 144), c * num4, 0f, Vector2.Zero, (SpriteEffects)0, 5E-08f);
			b.Draw(Game1.mouseCursors, new Rectangle(0, 0, ((Rectangle)(ref Game1.viewport)).Width, ((Rectangle)(ref Game1.viewport)).Height), (Rectangle?)(((int)seasonForLocation == 2) ? new Rectangle(639, 1051, 1, 400) : new Rectangle(639 + (num + 1), 1051, 1, 400)), c * num3, 0f, Vector2.Zero, (SpriteEffects)0, 1E-07f);
			if (Game1.timeOfDay >= 1800)
			{
				b.Draw(Game1.mouseCursors, new Vector2(0f, (float)(((Rectangle)(ref Game1.viewport)).Height / 2 - 780)), (Rectangle?)new Rectangle(0, 1453, 638, 195), Color.White * (1f - num3), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-05f);
			}
			if (Game1.dayOfMonth == 28 && Game1.timeOfDay > 1900)
			{
				b.Draw(Game1.mouseCursors, new Vector2(((float)num5 + (float)Game1.gameTimeInterval / (float)Game1.realMilliSecondsPerGameTenMinutes * 16.6f) / 2600f * (float)((Rectangle)(ref Game1.viewport)).Width / 4f, (float)(((Rectangle)(ref Game1.viewport)).Height / 2 + 176) - ((float)(num5 - 1900) + (float)Game1.gameTimeInterval / (float)Game1.realMilliSecondsPerGameTenMinutes * 16.6f) / 700f * (float)((Rectangle)(ref Game1.viewport)).Height / 2f), (Rectangle?)new Rectangle(642, 834, 43, 44), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 5E-08f);
			}
			if (!flag && (Game1.currentLocation.IsDebrisWeatherHere() || Game1.currentLocation.IsRainingHere()))
			{
				b.Draw(cloudsTexture, new Vector2((float)((Rectangle)(ref Game1.viewport)).Width - ((float)num5 + (float)Game1.gameTimeInterval / (float)Game1.realMilliSecondsPerGameTenMinutes * 16.6f) / 2600f * (float)(((Rectangle)(ref Game1.viewport)).Width + 2048), (float)(((Rectangle)(ref Game1.viewport)).Height - 584 - 600 + num2 / 2 + Game1.dayOfMonth * 6)), (Rectangle?)new Rectangle(0, 0, 512, 340), Color.White * num3, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 5.6E-08f);
			}
			if (!cursed)
			{
				b.Draw(Game1.staminaRect, new Rectangle(0, ((Rectangle)(ref Game1.viewport)).Height - 584 + num2 / 2, ((Rectangle)(ref Game1.viewport)).Width, ((Rectangle)(ref Game1.viewport)).Height / 2), (Rectangle?)new Rectangle(0, 0, 1, 1), new Color((int)((float)num6 + 60f * num4), (int)((float)(num6 + 10) + 170f * num4), (int)((float)(num6 + 20) + 205f * num4)), 0f, Vector2.Zero, (SpriteEffects)0, 2E-07f);
				b.Draw(Game1.mouseCursors, new Vector2(2556f, (float)(((Rectangle)(ref Game1.viewport)).Height - 596 + num2)), (Rectangle?)new Rectangle(0, 736 + num * 149, 639, 149), Color.White * Math.Max((int)((Color)(ref c)).A, 0.5f), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-06f);
				b.Draw(Game1.mouseCursors, new Vector2(2556f, (float)(((Rectangle)(ref Game1.viewport)).Height - 596 + num2)), (Rectangle?)new Rectangle(0, 736 + num * 149, 639, 149), val * (1f - num3), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 2E-06f);
				b.Draw(Game1.mouseCursors, new Vector2(0f, (float)(((Rectangle)(ref Game1.viewport)).Height - 596 + num2)), (Rectangle?)new Rectangle(0, 736 + num * 149, 639, 149), Color.White * Math.Max((int)((Color)(ref c)).A, 0.5f), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-06f);
				b.Draw(Game1.mouseCursors, new Vector2(0f, (float)(((Rectangle)(ref Game1.viewport)).Height - 596 + num2)), (Rectangle?)new Rectangle(0, 736 + num * 149, 639, 149), val * (1f - num3), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 2E-06f);
				foreach (TemporaryAnimatedSprite temporarySprite in Game1.currentLocation.temporarySprites)
				{
					temporarySprite.draw(b);
				}
				b.Draw(cloudsTexture, new Vector2(0f, (float)(((Rectangle)(ref Game1.viewport)).Height - 568) + (float)num2 * 2f), (Rectangle?)new Rectangle(0, 554 + num * 153, 164, 142), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.99f);
				b.Draw(cloudsTexture, new Vector2((float)(((Rectangle)(ref Game1.viewport)).Width - 488), (float)(((Rectangle)(ref Game1.viewport)).Height - 612) + (float)num2 * 2f), (Rectangle?)new Rectangle(390, 543 + num * 153, 122, 153), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.99f);
				b.Draw(cloudsTexture, new Vector2(0f, (float)(((Rectangle)(ref Game1.viewport)).Height - 568) + (float)num2 * 2f), (Rectangle?)new Rectangle(0, 554 + num * 153, 164, 142), Color.Black * (1f - num3), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
				b.Draw(cloudsTexture, new Vector2((float)(((Rectangle)(ref Game1.viewport)).Width - 488), (float)(((Rectangle)(ref Game1.viewport)).Height - 612) + (float)num2 * 2f), (Rectangle?)new Rectangle(390, 543 + num * 153, 122, 153), Color.Black * (1f - num3), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1f);
			}
			else if (Game1.options.screenFlash)
			{
				Random random = new Random((int)(Game1.currentGameTime.TotalGameTime.TotalMilliseconds - Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 1000.0));
				for (int i = 0; i < 20; i++)
				{
					Texture2D val2 = random.Choose((Texture2D[])(object)new Texture2D[8]
					{
						Game1.mouseCursors,
						Game1.mouseCursors2,
						Game1.objectSpriteSheet,
						Game1.menuTexture,
						Game1.uncoloredMenuTexture,
						Game1.mouseCursors_1_6,
						Game1.bigCraftableSpriteSheet,
						Game1.cropSpriteSheet
					});
					b.Draw(val2, new Vector2((float)(random.Next(((Rectangle)(ref Game1.viewport)).Width) - 100), (float)(random.Next(((Rectangle)(ref Game1.viewport)).Height) - 100)) + new Vector2((float)(int)(Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 1000.0) * 0.03f), (Rectangle?)new Rectangle(random.Next(val2.Width / 16) * 16, random.Next(val2.Height / 16) * 16, 16, 16), Utility.getRandomRainbowColor(random), 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-06f);
				}
			}
			return;
		}
		if (backgroundImage == null)
		{
			Rectangle val3 = default(Rectangle);
			((Rectangle)(ref val3))._002Ector(0, 0, ((Rectangle)(ref Game1.viewport)).Width, ((Rectangle)(ref Game1.viewport)).Height);
			if (onlyMapBG)
			{
				val3.X = Math.Max(0, -((Rectangle)(ref Game1.viewport)).X);
				val3.Y = Math.Max(0, -((Rectangle)(ref Game1.viewport)).Y);
				val3.Width = Math.Min(((Rectangle)(ref Game1.viewport)).Width, Game1.currentLocation.map.DisplayWidth);
				val3.Height = Math.Min(((Rectangle)(ref Game1.viewport)).Height, Game1.currentLocation.map.DisplayHeight);
			}
			b.Draw(Game1.staminaRect, val3, (Rectangle?)Game1.staminaRect.Bounds, c, 0f, Vector2.Zero, (SpriteEffects)0, 0f);
			for (int num7 = tempSprites.Count - 1; num7 >= 0; num7--)
			{
				if (tempSprites[num7].update(Game1.currentGameTime))
				{
					tempSprites.RemoveAt(num7);
				}
				else
				{
					tempSprites[num7].draw(b);
				}
			}
			return;
		}
		Vector2 zero = Vector2.Zero;
		Rectangle value = default(Rectangle);
		((Rectangle)(ref value))._002Ector(0, 0, chunkWidth, chunkHeight);
		for (int j = 0; j < chunks.Length; j++)
		{
			zero.X = position.X + (float)(j * chunkWidth % (chunksWide * chunkWidth)) * zoom;
			zero.Y = position.Y + (float)(j * chunkWidth / (chunksWide * chunkWidth) * chunkHeight) * zoom;
			if (backgroundImage == null)
			{
				b.Draw(Game1.staminaRect, new Rectangle((int)zero.X, (int)zero.Y, ((Rectangle)(ref Game1.viewport)).Width, ((Rectangle)(ref Game1.viewport)).Height), (Rectangle?)value, c, 0f, Vector2.Zero, (SpriteEffects)0, 0f);
				continue;
			}
			value.X = chunks[j] * chunkWidth % backgroundImage.Width;
			value.Y = chunks[j] * chunkWidth / backgroundImage.Width * chunkHeight;
			b.Draw(backgroundImage, zero, (Rectangle?)value, c, 0f, Vector2.Zero, zoom, (SpriteEffects)0, 0f);
		}
	}
}
