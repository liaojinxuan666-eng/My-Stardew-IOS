using System.Runtime.CompilerServices;
using Microsoft.Xna.Framework.Input;

namespace StardewValley;

public struct InputButton
{
	public Keys key;

	public bool mouseLeft;

	public bool mouseRight;

	public InputButton(Keys key)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		this.key = key;
		mouseLeft = false;
		mouseRight = false;
	}

	public InputButton(bool mouseLeft)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		key = (Keys)0;
		this.mouseLeft = mouseLeft;
		mouseRight = !mouseLeft;
	}

	public override string ToString()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Expected I4, but got Unknown
		if (mouseLeft)
		{
			return Game1.content.LoadString("Strings\\StringsFromCSFiles:Left-Click");
		}
		if (mouseRight)
		{
			return Game1.content.LoadString("Strings\\StringsFromCSFiles:Right-Click");
		}
		Keys val = key;
		switch (val - 48)
		{
		case 1:
			return "1";
		case 2:
			return "2";
		case 3:
			return "3";
		case 4:
			return "4";
		case 5:
			return "5";
		case 6:
			return "6";
		case 7:
			return "7";
		case 8:
			return "8";
		case 9:
			return "9";
		case 0:
			return "0";
		default:
		{
			string result = ((object)Unsafe.As<Keys, Keys>(ref key)/*cast due to .constrained prefix*/).ToString().Replace("Oem", "");
			if (Game1.content.LoadString("Strings\\StringsFromCSFiles:" + ((object)Unsafe.As<Keys, Keys>(ref key)/*cast due to .constrained prefix*/).ToString().Replace("Oem", "")) != "Strings\\StringsFromCSFiles:" + ((object)Unsafe.As<Keys, Keys>(ref key)/*cast due to .constrained prefix*/).ToString().Replace("Oem", ""))
			{
				result = Game1.content.LoadString("Strings\\StringsFromCSFiles:" + ((object)Unsafe.As<Keys, Keys>(ref key)/*cast due to .constrained prefix*/).ToString().Replace("Oem", ""));
			}
			return result;
		}
		}
	}
}
