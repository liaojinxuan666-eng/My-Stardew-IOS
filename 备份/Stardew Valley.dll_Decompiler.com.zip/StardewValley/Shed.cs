using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Locations;

namespace StardewValley;

public class Shed : DecoratableLocation
{
	private bool isRobinUpgrading;

	public Shed()
	{
	}

	public Shed(string m, string name)
		: base(m, name)
	{
	}

	protected override void resetLocalState()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		base.resetLocalState();
		if (Game1.isDarkOut(this))
		{
			Game1.ambientLight = new Color(180, 180, 0);
		}
		isRobinUpgrading = Game1.GetBuildingUnderConstruction()?.HasIndoorsName(base.NameOrUniqueName) ?? false;
	}

	public override void draw(SpriteBatch b)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		base.draw(b);
		if (isRobinUpgrading)
		{
			b.Draw(Game1.mouseCursors2, Game1.GlobalToLocal(Game1.viewport, new Vector2(64f, 64f)), (Rectangle?)new Rectangle(90, 0, 33, 6), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.01546f);
			b.Draw(Game1.mouseCursors2, Game1.GlobalToLocal(Game1.viewport, new Vector2(64f, 84f)), (Rectangle?)new Rectangle(90, 0, 33, 31), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 0.015360001f);
		}
	}
}
