namespace StardewValley;

public class NPCDialogueResponse : Response
{
	public int friendshipChange;

	public string id;

	public string extraArgument;

	public NPCDialogueResponse(string id, int friendshipChange, string keyToNPCresponse, string responseText, string extraArgument = null)
		: base(keyToNPCresponse, responseText)
	{
		this.friendshipChange = friendshipChange;
		this.id = id;
		this.extraArgument = extraArgument;
	}

	public NPCDialogueResponse(NPCDialogueResponse other)
		: this(other.id, other.friendshipChange, other.responseKey, other.responseText, other.extraArgument)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		if ((int)other.hotkey != 0)
		{
			SetHotKey(other.hotkey);
		}
	}
}
