using System;
using Microsoft.Xna.Framework.Input;

namespace StardewValley;

public class KeyEventArgs : EventArgs
{
	private Keys keyCode;

	public Keys KeyCode => keyCode;

	public KeyEventArgs(Keys keyCode)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		this.keyCode = keyCode;
	}
}
