using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;

namespace StardewValley;

public class IslandGemBird : INetObject<NetFields>
{
	public enum GemBirdType
	{
		Emerald,
		Aquamarine,
		Ruby,
		Amethyst,
		Topaz,
		MAX
	}

	[XmlIgnore]
	public Texture2D texture;

	[XmlElement("position")]
	public NetVector2 position = new NetVector2();

	[XmlIgnore]
	protected float _destroyTimer;

	[XmlElement("height")]
	public NetFloat height = new NetFloat();

	[XmlIgnore]
	public int[] idleAnimation = new int[1];

	[XmlIgnore]
	public int[] lookBackAnimation = new int[17]
	{
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
		1, 1, 1, 1, 1, 1, 1
	};

	[XmlIgnore]
	public int[] scratchAnimation = new int[19]
	{
		0, 1, 2, 3, 2, 3, 2, 3, 2, 3,
		2, 3, 2, 3, 2, 3, 2, 3, 2
	};

	[XmlIgnore]
	public int[] flyAnimation = new int[11]
	{
		4, 5, 6, 7, 7, 6, 6, 5, 5, 4,
		4
	};

	[XmlIgnore]
	public int[] currentAnimation;

	[XmlIgnore]
	public float frameTimer;

	[XmlIgnore]
	public int currentFrameIndex;

	[XmlIgnore]
	public float idleAnimationTime;

	[XmlElement("alpha")]
	public NetFloat alpha = new NetFloat(1f);

	[XmlElement("flying")]
	public NetBool flying = new NetBool();

	[XmlElement("color")]
	public NetColor color = new NetColor();

	[XmlElement("itemIndex")]
	public NetString itemIndex = new NetString("0");

	[XmlIgnore]
	public NetFields NetFields { get; } = new NetFields("IslandGemBird");

	public IslandGemBird()
	{
		texture = Game1.content.Load<Texture2D>("LooseSprites\\GemBird");
		InitNetFields();
	}

	public IslandGemBird(Vector2 tile_position, GemBirdType bird_type)
		: this()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		position.Value = (tile_position + new Vector2(0.5f, 0.5f)) * 64f;
		color.Value = GetColor(bird_type);
		itemIndex.Value = GetItemIndex(bird_type);
	}

	public static Color GetColor(GemBirdType bird_type)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		return (Color)(bird_type switch
		{
			GemBirdType.Emerald => new Color(67, 255, 83), 
			GemBirdType.Aquamarine => new Color(74, 243, 255), 
			GemBirdType.Ruby => new Color(255, 38, 38), 
			GemBirdType.Amethyst => new Color(255, 67, 251), 
			GemBirdType.Topaz => new Color(255, 156, 33), 
			_ => Color.White, 
		});
	}

	public static string GetItemIndex(GemBirdType bird_type)
	{
		return bird_type switch
		{
			GemBirdType.Emerald => "60", 
			GemBirdType.Aquamarine => "62", 
			GemBirdType.Ruby => "64", 
			GemBirdType.Amethyst => "66", 
			GemBirdType.Topaz => "68", 
			_ => "0", 
		};
	}

	public static GemBirdType GetBirdTypeForLocation(string location)
	{
		List<string> list = new List<string> { "IslandNorth", "IslandSouth", "IslandEast", "IslandWest" };
		if (!list.Contains(location))
		{
			return GemBirdType.Aquamarine;
		}
		Random rng = Utility.CreateRandom(Game1.uniqueIDForThisGame);
		List<GemBirdType> list2 = new List<GemBirdType>();
		for (int i = 0; i < 5; i++)
		{
			list2.Add((GemBirdType)i);
		}
		Utility.Shuffle(rng, list2);
		return list2[list.IndexOf(location)];
	}

	public void Draw(SpriteBatch b)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		if (currentAnimation != null)
		{
			int num = currentAnimation[Math.Min(currentFrameIndex, currentAnimation.Length - 1)];
			b.Draw(texture, Game1.GlobalToLocal(Game1.viewport, position.Value + new Vector2(0f, 0f - height.Value)), (Rectangle?)new Rectangle(num * 32, 0, 32, 32), Color.White * alpha.Value, 0f, new Vector2(16f, 32f), 4f, (SpriteEffects)0, (position.Value.Y - 1f) / 10000f);
			b.Draw(texture, Game1.GlobalToLocal(Game1.viewport, position.Value + new Vector2(0f, 0f - height.Value)), (Rectangle?)new Rectangle(num * 32, 32, 32, 32), color.Value * alpha.Value, 0f, new Vector2(16f, 32f), 4f, (SpriteEffects)0, position.Value.Y / 10000f);
			Texture2D shadowTexture = Game1.shadowTexture;
			Vector2 val = Game1.GlobalToLocal(Game1.viewport, position.Value);
			Rectangle? val2 = Game1.shadowTexture.Bounds;
			Color val3 = Color.White * alpha.Value;
			Rectangle bounds = Game1.shadowTexture.Bounds;
			float num2 = ((Rectangle)(ref bounds)).Center.X;
			bounds = Game1.shadowTexture.Bounds;
			b.Draw(shadowTexture, val, val2, val3, 0f, new Vector2(num2, (float)((Rectangle)(ref bounds)).Center.Y), 3f, (SpriteEffects)0, (position.Y - 2f) / 10000f);
		}
	}

	public void InitNetFields()
	{
		NetFields.SetOwner(this).AddField(position, "position").AddField(flying, "flying")
			.AddField(height, "height")
			.AddField(color, "color")
			.AddField(alpha, "alpha")
			.AddField(itemIndex, "itemIndex");
		position.Interpolated(interpolate: true, wait: true);
		height.Interpolated(interpolate: true, wait: true);
		alpha.Interpolated(interpolate: true, wait: true);
	}

	public bool Update(GameTime time, GameLocation location)
	{
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		if (currentAnimation == null)
		{
			currentAnimation = idleAnimation;
		}
		frameTimer += (float)time.ElapsedGameTime.TotalSeconds;
		float num = 0.15f;
		if (flying.Value)
		{
			num = 0.05f;
		}
		if (frameTimer >= num)
		{
			frameTimer = 0f;
			currentFrameIndex++;
			if (currentFrameIndex >= currentAnimation.Length)
			{
				currentFrameIndex = 0;
				if (currentAnimation == flyAnimation && location == Game1.currentLocation && Utility.isOnScreen(position.Value + new Vector2(0f, 0f - height.Value), 64))
				{
					Game1.playSound("batFlap");
				}
				if (currentAnimation == lookBackAnimation || currentAnimation == scratchAnimation)
				{
					currentAnimation = idleAnimation;
				}
			}
		}
		if (flying.Value)
		{
			currentAnimation = flyAnimation;
			if (Game1.IsMasterGame)
			{
				height.Value += 4f;
				position.X -= 3f;
				if (alpha.Value > 0f && height.Value >= 300f)
				{
					alpha.Value -= 0.01f;
					if (alpha.Value < 0f)
					{
						alpha.Value = 0f;
					}
				}
			}
		}
		else
		{
			if (currentAnimation == idleAnimation)
			{
				idleAnimationTime -= (float)time.ElapsedGameTime.TotalSeconds;
			}
			if (idleAnimationTime <= 0f)
			{
				currentFrameIndex = 0;
				if (Game1.random.NextDouble() < 0.75)
				{
					currentAnimation = lookBackAnimation;
				}
				else
				{
					currentAnimation = scratchAnimation;
				}
				idleAnimationTime = Utility.RandomFloat(1f, 3f);
			}
		}
		if (Game1.IsMasterGame && !flying.Value)
		{
			foreach (Farmer farmer in location.farmers)
			{
				Vector2 val = farmer.Position - position.Value;
				if (Math.Abs(val.X) <= 128f && Math.Abs(val.Y) <= 128f)
				{
					flying.Value = true;
					location.playSound("parrot");
					Game1.createObjectDebris(itemIndex.Value, (int)(position.X / 64f), (int)(position.Y / 64f), location);
				}
			}
		}
		if (alpha.Value <= 0f)
		{
			if (_destroyTimer == 0f)
			{
				_destroyTimer = 3f;
			}
			else if (_destroyTimer >= 0f)
			{
				_destroyTimer -= (float)time.ElapsedGameTime.TotalSeconds;
				if (_destroyTimer <= 0f)
				{
					return true;
				}
			}
		}
		return false;
	}
}
