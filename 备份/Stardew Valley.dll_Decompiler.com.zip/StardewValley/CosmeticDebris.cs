using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Extensions;

namespace StardewValley;

public class CosmeticDebris : TemporaryAnimatedSprite
{
	public const float gravity = 0.3f;

	public const float bounciness = 0.45f;

	private new Vector2 position;

	private new float rotation;

	private float rotationSpeed;

	private float xVelocity;

	private float yVelocity;

	private new Rectangle sourceRect;

	private int groundYLevel;

	private int disappearTimer;

	private int lightTailLength;

	private int timeToDisappearAfterReachingGround;

	private new int id;

	private new Color color;

	private ICue tapSound;

	private LightSource light;

	private Queue<Vector2> lightTail;

	private new Texture2D texture;

	public CosmeticDebris(Texture2D texture, Vector2 startingPosition, float rotationSpeed, float xVelocity, float yVelocity, int groundYLevel, Rectangle sourceRect, Color color, ICue tapSound, LightSource light, int lightTailLength, int disappearTime)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		timeToDisappearAfterReachingGround = disappearTime;
		disappearTimer = timeToDisappearAfterReachingGround;
		this.texture = texture;
		position = startingPosition;
		this.rotationSpeed = rotationSpeed;
		this.xVelocity = xVelocity;
		this.yVelocity = yVelocity;
		this.sourceRect = sourceRect;
		this.groundYLevel = groundYLevel;
		this.color = color;
		this.tapSound = tapSound;
		this.light = light;
		id = Game1.random.Next();
		Game1.currentLightSources.Add(light);
		if (lightTailLength > 0)
		{
			lightTail = new Queue<Vector2>();
			this.lightTailLength = lightTailLength;
		}
	}

	public override bool update(GameTime time)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		Utility.repositionLightSource(light?.Id, position);
		yVelocity += 0.3f;
		position += new Vector2(xVelocity, yVelocity);
		rotation += rotationSpeed;
		if (position.Y >= (float)groundYLevel)
		{
			position.Y = groundYLevel - 1;
			yVelocity = 0f - yVelocity;
			yVelocity *= 0.45f;
			xVelocity *= 0.45f;
			rotationSpeed *= 0.225f;
			if (!tapSound.IsPlaying)
			{
				Game1.playSound(tapSound.Name, out tapSound);
			}
			disappearTimer--;
		}
		if (disappearTimer < timeToDisappearAfterReachingGround)
		{
			disappearTimer -= time.ElapsedGameTime.Milliseconds;
			if (disappearTimer <= 0)
			{
				Utility.removeLightSource(light?.Id);
				return true;
			}
		}
		return false;
	}

	public override void draw(SpriteBatch spriteBatch, bool localPosition = false, int xOffset = 0, int yOffset = 0, float extraAlpha = 1f)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		spriteBatch.Draw(texture, Game1.GlobalToLocal(Game1.viewport, position), (Rectangle?)sourceRect, color, rotation, new Vector2(8f, 8f), 4f, (SpriteEffects)0, (float)(groundYLevel + 1) / 10000f);
	}
}
