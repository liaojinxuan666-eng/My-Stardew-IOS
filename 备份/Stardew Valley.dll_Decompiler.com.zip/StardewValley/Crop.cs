using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Characters;
using StardewValley.Extensions;
using StardewValley.GameData.Crops;
using StardewValley.GameData.GiantCrops;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Locations;
using StardewValley.Mods;
using StardewValley.Objects;
using StardewValley.TerrainFeatures;

namespace StardewValley;

public class Crop : INetObject<NetFields>, IHaveModData
{
	public const string mixedSeedsId = "770";

	public const string mixedSeedsQId = "(O)770";

	public const int seedPhase = 0;

	public const int rowOfWildSeeds = 23;

	public const int finalPhaseLength = 99999;

	public const int forageCrop_springOnion = 1;

	public const string forageCrop_springOnionID = "1";

	public const int forageCrop_ginger = 2;

	public const string forageCrop_gingerID = "2";

	public const int specialVariable_farmedForageCrop = 724519;

	private GameLocation currentLocationImpl;

	public readonly NetIntList phaseDays = new NetIntList();

	[XmlElement("rowInSpriteSheet")]
	public readonly NetInt rowInSpriteSheet = new NetInt();

	[XmlElement("phaseToShow")]
	public readonly NetInt phaseToShow = new NetInt(-1);

	[XmlElement("currentPhase")]
	public readonly NetInt currentPhase = new NetInt();

	[XmlElement("indexOfHarvest")]
	public readonly NetString indexOfHarvest = new NetString();

	[XmlElement("dayOfCurrentPhase")]
	public readonly NetInt dayOfCurrentPhase = new NetInt();

	[XmlElement("whichForageCrop")]
	public readonly NetString whichForageCrop = new NetString();

	[XmlElement("overrideHarvestItemId")]
	public readonly NetString replaceWithObjectOnFullGrown = new NetString();

	[XmlElement("tintColor")]
	public readonly NetColor tintColor = new NetColor();

	[XmlElement("flip")]
	public readonly NetBool flip = new NetBool();

	[XmlElement("fullGrown")]
	public readonly NetBool fullyGrown = new NetBool();

	[XmlElement("raisedSeeds")]
	public readonly NetBool raisedSeeds = new NetBool();

	[XmlElement("programColored")]
	public readonly NetBool programColored = new NetBool();

	[XmlElement("dead")]
	public readonly NetBool dead = new NetBool();

	[XmlElement("forageCrop")]
	public readonly NetBool forageCrop = new NetBool();

	[XmlElement("seedIndex")]
	public readonly NetString netSeedIndex = new NetString();

	[XmlElement("overrideTexturePath")]
	public readonly NetString overrideTexturePath = new NetString();

	protected Texture2D _drawnTexture;

	protected bool? _isErrorCrop;

	[XmlIgnore]
	public Vector2 drawPosition;

	[XmlIgnore]
	public Vector2 tilePosition;

	[XmlIgnore]
	public float layerDepth;

	[XmlIgnore]
	public float coloredLayerDepth;

	[XmlIgnore]
	public Rectangle sourceRect;

	[XmlIgnore]
	public Rectangle coloredSourceRect;

	private static Vector2 origin = new Vector2(8f, 24f);

	private static Vector2 smallestTileSizeOrigin = new Vector2(8f, 8f);

	[XmlIgnore]
	public GameLocation currentLocation
	{
		get
		{
			return currentLocationImpl;
		}
		set
		{
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			if (value != currentLocationImpl)
			{
				currentLocationImpl = value;
				updateDrawMath(tilePosition);
			}
		}
	}

	[XmlIgnore]
	public HoeDirt Dirt { get; set; }

	[XmlIgnore]
	public Texture2D DrawnCropTexture
	{
		get
		{
			if (dead.Value)
			{
				return Game1.cropSpriteSheet;
			}
			if (_drawnTexture == null)
			{
				if (overrideTexturePath.Value == null)
				{
					NetString netString = overrideTexturePath;
					CropData data = GetData();
					netString.Value = ((data != null) ? data.GetCustomTextureName("TileSheets\\crops") : null);
				}
				_drawnTexture = null;
				if (overrideTexturePath.Value != null)
				{
					try
					{
						_drawnTexture = Game1.content.Load<Texture2D>(overrideTexturePath.Value);
					}
					catch (Exception)
					{
						_drawnTexture = null;
					}
				}
				if (_drawnTexture == null)
				{
					_drawnTexture = Game1.cropSpriteSheet;
				}
			}
			return _drawnTexture;
		}
	}

	[XmlIgnore]
	public ModDataDictionary modData { get; } = new ModDataDictionary();

	[XmlElement("modData")]
	public ModDataDictionary modDataForSerialization
	{
		get
		{
			return modData.GetForSerialization();
		}
		set
		{
			modData.SetFromSerialization(value);
		}
	}

	public NetFields NetFields { get; } = new NetFields("Crop");

	public Crop()
	{
		NetFields.SetOwner(this).AddField(phaseDays, "phaseDays").AddField(rowInSpriteSheet, "rowInSpriteSheet")
			.AddField(phaseToShow, "phaseToShow")
			.AddField(currentPhase, "currentPhase")
			.AddField(indexOfHarvest, "indexOfHarvest")
			.AddField(dayOfCurrentPhase, "dayOfCurrentPhase")
			.AddField(whichForageCrop, "whichForageCrop")
			.AddField(replaceWithObjectOnFullGrown, "replaceWithObjectOnFullGrown")
			.AddField(tintColor, "tintColor")
			.AddField(flip, "flip")
			.AddField(fullyGrown, "fullyGrown")
			.AddField(raisedSeeds, "raisedSeeds")
			.AddField(programColored, "programColored")
			.AddField(dead, "dead")
			.AddField(forageCrop, "forageCrop")
			.AddField(netSeedIndex, "netSeedIndex")
			.AddField(overrideTexturePath, "overrideTexturePath")
			.AddField(modData, "modData");
		dayOfCurrentPhase.fieldChangeVisibleEvent += delegate
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			updateDrawMath(tilePosition);
		};
		fullyGrown.fieldChangeVisibleEvent += delegate
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			updateDrawMath(tilePosition);
		};
		currentLocation = Game1.currentLocation;
	}

	public Crop(bool forageCrop, string which, int tileX, int tileY, GameLocation location)
		: this()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		currentLocation = location;
		this.forageCrop.Value = forageCrop;
		whichForageCrop.Value = which;
		fullyGrown.Value = true;
		currentPhase.Value = 5;
		updateDrawMath(new Vector2((float)tileX, (float)tileY));
	}

	public Crop(string seedId, int tileX, int tileY, GameLocation location)
		: this()
	{
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		currentLocation = location;
		seedId = ResolveSeedId(seedId, location);
		if (TryGetData(seedId, out var data))
		{
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(data.HarvestItemId);
			if (!dataOrErrorItem.HasTypeObject())
			{
				Game1.log.Warn($"Crop seed {seedId} produces non-object item {dataOrErrorItem.QualifiedItemId}, which isn't valid.");
			}
			phaseDays.AddRange(data.DaysInPhase);
			phaseDays.Add(99999);
			rowInSpriteSheet.Value = data.SpriteIndex;
			indexOfHarvest.Value = dataOrErrorItem.ItemId;
			overrideTexturePath.Value = data.GetCustomTextureName("TileSheets\\crops");
			if (isWildSeedCrop())
			{
				whichForageCrop.Value = seedId;
				replaceWithObjectOnFullGrown.Value = getRandomWildCropForSeason(onlyDeterministic: true);
			}
			else
			{
				netSeedIndex.Value = seedId;
			}
			raisedSeeds.Value = data.IsRaised;
			List<string> tintColors = data.TintColors;
			if (tintColors != null && tintColors.Count > 0)
			{
				Color? val = Utility.StringToColor(Utility.CreateRandom((double)tileX * 1000.0, tileY, Game1.dayOfMonth).ChooseFrom(data.TintColors));
				if (val.HasValue)
				{
					tintColor.Value = val.Value;
					programColored.Value = true;
				}
			}
		}
		else
		{
			netSeedIndex.Value = seedId ?? "0";
			indexOfHarvest.Value = seedId ?? "0";
		}
		flip.Value = Game1.random.NextBool();
		updateDrawMath(new Vector2((float)tileX, (float)tileY));
	}

	public static string ResolveSeedId(string itemId, GameLocation location)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		if (!(itemId == "MixedFlowerSeeds"))
		{
			if (itemId == "770")
			{
				string text = getRandomLowGradeCropForThisSeason(location.GetSeason());
				if (text == "473")
				{
					text = "472";
				}
				if (location is IslandLocation)
				{
					text = Game1.random.Next(4) switch
					{
						0 => "479", 
						1 => "833", 
						2 => "481", 
						_ => "478", 
					};
				}
				return text;
			}
			return itemId;
		}
		return getRandomFlowerSeedForThisSeason(location.GetSeason());
	}

	public CropData GetData()
	{
		if (!TryGetData(isWildSeedCrop() ? whichForageCrop.Value : netSeedIndex.Value, out var data))
		{
			return null;
		}
		return data;
	}

	public static bool TryGetData(string seedId, out CropData data)
	{
		if (seedId == null)
		{
			data = null;
			return false;
		}
		return Game1.cropData.TryGetValue(seedId, out data);
	}

	public bool IsInSeason(GameLocation location)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		if (location.SeedsIgnoreSeasonsHere())
		{
			return true;
		}
		return GetData()?.Seasons?.Contains(location.GetSeason()) ?? false;
	}

	public static bool IsInSeason(GameLocation location, string seedId)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if (location.SeedsIgnoreSeasonsHere())
		{
			return true;
		}
		if (TryGetData(seedId, out var data))
		{
			return data.Seasons?.Contains(location.GetSeason()) ?? false;
		}
		return false;
	}

	public HarvestMethod GetHarvestMethod()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		return (HarvestMethod)(((_003F?)GetData()?.HarvestMethod) ?? 0);
	}

	public bool RegrowsAfterHarvest()
	{
		CropData data = GetData();
		if (data == null)
		{
			return false;
		}
		return data.RegrowDays > 0;
	}

	public virtual bool IsErrorCrop()
	{
		if (forageCrop.Value)
		{
			return false;
		}
		if (!_isErrorCrop.HasValue)
		{
			_isErrorCrop = GetData() == null;
		}
		return _isErrorCrop.Value;
	}

	public virtual void ResetPhaseDays()
	{
		CropData data = GetData();
		if (data != null)
		{
			phaseDays.Clear();
			phaseDays.AddRange(data.DaysInPhase);
			phaseDays.Add(99999);
		}
	}

	public static string getRandomLowGradeCropForThisSeason(Season season)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Invalid comparison between Unknown and I4
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Expected I4, but got Unknown
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if ((int)season == 3)
		{
			season = Game1.random.Choose<Season>((Season)0, (Season)1, (Season)2);
		}
		return (int)season switch
		{
			0 => Game1.random.Next(472, 476).ToString(), 
			1 => Game1.random.Next(4) switch
			{
				0 => "487", 
				1 => "483", 
				2 => "482", 
				_ => "484", 
			}, 
			2 => Game1.random.Next(487, 491).ToString(), 
			_ => null, 
		};
	}

	public static string getRandomFlowerSeedForThisSeason(Season season)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Invalid comparison between Unknown and I4
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Expected I4, but got Unknown
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if ((int)season == 3)
		{
			season = Game1.random.Choose<Season>((Season)0, (Season)1, (Season)2);
		}
		return (int)season switch
		{
			0 => Game1.random.Choose("427", "429"), 
			1 => Game1.random.Choose("455", "453", "431"), 
			2 => Game1.random.Choose("431", "425"), 
			_ => "-1", 
		};
	}

	public virtual void growCompletely()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		currentPhase.Value = phaseDays.Count - 1;
		dayOfCurrentPhase.Value = 0;
		if (RegrowsAfterHarvest())
		{
			fullyGrown.Value = true;
		}
		updateDrawMath(tilePosition);
	}

	public virtual bool hitWithHoe(int xTile, int yTile, GameLocation location, HoeDirt dirt)
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		if (forageCrop.Value && whichForageCrop.Value == "2")
		{
			dirt.state.Value = (location.IsRainingHere() ? 1 : 0);
			Object obj = ItemRegistry.Create<Object>("(O)829");
			Game1.multiplayer.broadcastSprites(location, new TemporaryAnimatedSprite(12, new Vector2((float)(xTile * 64), (float)(yTile * 64)), Color.White, 8, Game1.random.NextBool(), 50f));
			location.playSound("dirtyHit");
			Game1.createItemDebris(obj.getOne(), new Vector2((float)(xTile * 64 + 32), (float)(yTile * 64 + 32)), -1);
			return true;
		}
		return false;
	}

	public virtual bool harvest(int xTile, int yTile, HoeDirt soil, JunimoHarvester junimoHarvester = null, bool isForcedScytheHarvest = false)
	{
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0575: Unknown result type (might be due to invalid IL or missing references)
		//IL_0592: Unknown result type (might be due to invalid IL or missing references)
		//IL_0597: Unknown result type (might be due to invalid IL or missing references)
		//IL_0599: Unknown result type (might be due to invalid IL or missing references)
		//IL_059c: Invalid comparison between Unknown and I4
		//IL_0655: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0796: Unknown result type (might be due to invalid IL or missing references)
		//IL_0753: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_09cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0836: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0902: Unknown result type (might be due to invalid IL or missing references)
		//IL_090f: Unknown result type (might be due to invalid IL or missing references)
		//IL_091c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0921: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b89: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bda: Unknown result type (might be due to invalid IL or missing references)
		if (dead.Value)
		{
			if (junimoHarvester != null)
			{
				return true;
			}
			return false;
		}
		bool flag = false;
		if (forageCrop.Value)
		{
			Object obj = null;
			int howMuch = 3;
			Random random = Utility.CreateDaySaveRandom(xTile * 1000, yTile * 2000);
			string value = whichForageCrop.Value;
			if (!(value == "1"))
			{
				if (value == "2")
				{
					soil.shake((float)Math.PI / 48f, (float)Math.PI / 40f, (float)(xTile * 64) < Game1.player.Position.X);
					return false;
				}
			}
			else
			{
				obj = ItemRegistry.Create<Object>("(O)399");
			}
			if (Game1.player.professions.Contains(16))
			{
				obj.Quality = 4;
			}
			else if (random.NextDouble() < (double)((float)Game1.player.ForagingLevel / 30f))
			{
				obj.Quality = 2;
			}
			else if (random.NextDouble() < (double)((float)Game1.player.ForagingLevel / 15f))
			{
				obj.Quality = 1;
			}
			Game1.stats.ItemsForaged += (uint)obj.Stack;
			if (junimoHarvester != null)
			{
				junimoHarvester.tryToAddItemToHut(obj);
				return true;
			}
			if (isForcedScytheHarvest)
			{
				Vector2 val = default(Vector2);
				((Vector2)(ref val))._002Ector((float)xTile, (float)yTile);
				Game1.createItemDebris(obj, new Vector2(val.X * 64f + 32f, val.Y * 64f + 32f), -1);
				Game1.player.gainExperience(2, howMuch);
				Game1.player.currentLocation.playSound("moss_cut");
				return true;
			}
			if (Game1.player.addItemToInventoryBool(obj))
			{
				Vector2 val2 = default(Vector2);
				((Vector2)(ref val2))._002Ector((float)xTile, (float)yTile);
				Game1.player.animateOnce(279 + Game1.player.FacingDirection);
				Game1.player.canMove = false;
				Game1.player.currentLocation.playSound("harvest");
				DelayedAction.playSoundAfterDelay("coin", 260);
				if (!RegrowsAfterHarvest())
				{
					Game1.multiplayer.broadcastSprites(Game1.currentLocation, new TemporaryAnimatedSprite(17, new Vector2(val2.X * 64f, val2.Y * 64f), Color.White, 7, random.NextBool(), 125f));
					Game1.multiplayer.broadcastSprites(Game1.currentLocation, new TemporaryAnimatedSprite(14, new Vector2(val2.X * 64f, val2.Y * 64f), Color.White, 7, random.NextBool(), 50f));
				}
				Game1.player.gainExperience(2, howMuch);
				return true;
			}
			Game1.showRedMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:Crop.cs.588"));
		}
		else if (currentPhase.Value >= phaseDays.Count - 1 && (!fullyGrown.Value || dayOfCurrentPhase.Value <= 0))
		{
			if (string.IsNullOrWhiteSpace(indexOfHarvest.Value))
			{
				return true;
			}
			CropData data = GetData();
			Random random2 = Utility.CreateRandom((double)xTile * 7.0, (double)yTile * 11.0, Game1.stats.DaysPlayed, Game1.uniqueIDForThisGame);
			int fertilizerQualityBoostLevel = soil.GetFertilizerQualityBoostLevel();
			double num = 0.2 * ((double)Game1.player.FarmingLevel / 10.0) + 0.2 * (double)fertilizerQualityBoostLevel * (((double)Game1.player.FarmingLevel + 2.0) / 12.0) + 0.01;
			double num2 = Math.Min(0.75, num * 2.0);
			int num3 = 0;
			if (fertilizerQualityBoostLevel >= 3 && random2.NextDouble() < num / 2.0)
			{
				num3 = 4;
			}
			else if (random2.NextDouble() < num)
			{
				num3 = 2;
			}
			else if (random2.NextDouble() < num2 || fertilizerQualityBoostLevel >= 3)
			{
				num3 = 1;
			}
			num3 = MathHelper.Clamp(num3, data?.HarvestMinQuality ?? 0, data?.HarvestMaxQuality ?? num3);
			int num4 = 1;
			if (data != null)
			{
				int harvestMinStack = data.HarvestMinStack;
				int num5 = Math.Max(harvestMinStack, data.HarvestMaxStack);
				if (data.HarvestMaxIncreasePerFarmingLevel > 0f)
				{
					num5 += (int)((float)Game1.player.FarmingLevel * data.HarvestMaxIncreasePerFarmingLevel);
				}
				if (harvestMinStack > 1 || num5 > 1)
				{
					num4 = random2.Next(harvestMinStack, num5 + 1);
				}
			}
			if (data != null && data.ExtraHarvestChance > 0.0)
			{
				while (random2.NextDouble() < Math.Min(0.9, data.ExtraHarvestChance))
				{
					num4++;
				}
			}
			Item item = (programColored.Value ? new ColoredObject(indexOfHarvest.Value, 1, tintColor.Value)
			{
				Quality = num3
			} : ItemRegistry.Create(indexOfHarvest.Value, 1, num3));
			HarvestMethod val3 = (HarvestMethod)((data != null) ? ((int)data.HarvestMethod) : 0);
			if ((int)val3 == 1 || isForcedScytheHarvest)
			{
				if (junimoHarvester != null)
				{
					DelayedAction.playSoundAfterDelay("daggerswipe", 150, junimoHarvester.currentLocation);
					if (Utility.isOnScreen(junimoHarvester.TilePoint, 64, junimoHarvester.currentLocation))
					{
						junimoHarvester.currentLocation.playSound("harvest");
						DelayedAction.playSoundAfterDelay("coin", 260, junimoHarvester.currentLocation);
					}
					junimoHarvester.tryToAddItemToHut(item.getOne());
				}
				else
				{
					Game1.createItemDebris(item.getOne(), new Vector2((float)(xTile * 64 + 32), (float)(yTile * 64 + 32)), -1);
				}
				flag = true;
			}
			else if (junimoHarvester != null || (item != null && Game1.player.addItemToInventoryBool(item.getOne())))
			{
				Vector2 val4 = default(Vector2);
				((Vector2)(ref val4))._002Ector((float)xTile, (float)yTile);
				if (junimoHarvester == null)
				{
					Game1.player.animateOnce(279 + Game1.player.FacingDirection);
					Game1.player.canMove = false;
				}
				else
				{
					junimoHarvester.tryToAddItemToHut(item.getOne());
				}
				if (random2.NextDouble() < Game1.player.team.AverageLuckLevel() / 1500.0 + Game1.player.team.AverageDailyLuck() / 1200.0 + 9.999999747378752E-05)
				{
					num4 *= 2;
					if (junimoHarvester == null)
					{
						Game1.player.currentLocation.playSound("dwoop");
					}
					else if (Utility.isOnScreen(junimoHarvester.TilePoint, 64, junimoHarvester.currentLocation))
					{
						junimoHarvester.currentLocation.playSound("dwoop");
					}
				}
				else if ((int)val3 == 0)
				{
					if (junimoHarvester == null)
					{
						Game1.player.currentLocation.playSound("harvest");
					}
					else if (Utility.isOnScreen(junimoHarvester.TilePoint, 64, junimoHarvester.currentLocation))
					{
						junimoHarvester.currentLocation.playSound("harvest");
					}
					if (junimoHarvester == null)
					{
						DelayedAction.playSoundAfterDelay("coin", 260, Game1.player.currentLocation);
					}
					else if (Utility.isOnScreen(junimoHarvester.TilePoint, 64, junimoHarvester.currentLocation))
					{
						DelayedAction.playSoundAfterDelay("coin", 260, junimoHarvester.currentLocation);
					}
					if (!RegrowsAfterHarvest() && (junimoHarvester == null || junimoHarvester.currentLocation.Equals(Game1.currentLocation)))
					{
						Game1.multiplayer.broadcastSprites(Game1.currentLocation, new TemporaryAnimatedSprite(17, new Vector2(val4.X * 64f, val4.Y * 64f), Color.White, 7, Game1.random.NextBool(), 125f));
						Game1.multiplayer.broadcastSprites(Game1.currentLocation, new TemporaryAnimatedSprite(14, new Vector2(val4.X * 64f, val4.Y * 64f), Color.White, 7, Game1.random.NextBool(), 50f));
					}
				}
				flag = true;
			}
			else
			{
				Game1.showRedMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:Crop.cs.588"));
			}
			if (flag)
			{
				if (indexOfHarvest.Value == "421")
				{
					indexOfHarvest.Value = "431";
					num4 = random2.Next(1, 4);
				}
				item = (programColored.Value ? new ColoredObject(indexOfHarvest.Value, 1, tintColor.Value) : ItemRegistry.Create(indexOfHarvest.Value));
				int num6 = 0;
				if (item is Object obj2)
				{
					num6 = obj2.Price;
				}
				float num7 = (float)(16.0 * Math.Log(0.018 * (double)num6 + 1.0, Math.E));
				if (junimoHarvester == null)
				{
					Game1.player.gainExperience(0, (int)Math.Round(num7));
				}
				for (int i = 0; i < num4 - 1; i++)
				{
					if (junimoHarvester == null)
					{
						Game1.createItemDebris(item.getOne(), new Vector2((float)(xTile * 64 + 32), (float)(yTile * 64 + 32)), -1);
					}
					else
					{
						junimoHarvester.tryToAddItemToHut(item.getOne());
					}
				}
				string value = indexOfHarvest.Value;
				if (!(value == "262"))
				{
					if (value == "771")
					{
						soil?.Location?.playSound("cut");
						if (random2.NextDouble() < 0.1)
						{
							Item item2 = ItemRegistry.Create("(O)770");
							if (junimoHarvester == null)
							{
								Game1.createItemDebris(item2.getOne(), new Vector2((float)(xTile * 64 + 32), (float)(yTile * 64 + 32)), -1);
							}
							else
							{
								junimoHarvester.tryToAddItemToHut(item2.getOne());
							}
						}
					}
				}
				else if (random2.NextDouble() < 0.4)
				{
					Item item3 = ItemRegistry.Create("(O)178");
					if (junimoHarvester == null)
					{
						Game1.createItemDebris(item3.getOne(), new Vector2((float)(xTile * 64 + 32), (float)(yTile * 64 + 32)), -1);
					}
					else
					{
						junimoHarvester.tryToAddItemToHut(item3.getOne());
					}
				}
				int num8 = data?.RegrowDays ?? (-1);
				if (num8 <= 0)
				{
					return true;
				}
				fullyGrown.Value = true;
				if (dayOfCurrentPhase.Value == num8)
				{
					updateDrawMath(tilePosition);
				}
				dayOfCurrentPhase.Value = num8;
			}
		}
		return false;
	}

	public string getRandomWildCropForSeason(bool onlyDeterministic = false)
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		switch (whichForageCrop.Value)
		{
		case "495":
			return getRandomWildCropForSeason((Season)0);
		case "496":
			return getRandomWildCropForSeason((Season)1);
		case "497":
			return getRandomWildCropForSeason((Season)2);
		case "498":
			return getRandomWildCropForSeason((Season)3);
		default:
			if (onlyDeterministic && !currentLocation.SeedsIgnoreSeasonsHere())
			{
				return null;
			}
			return getRandomWildCropForSeason(currentLocation.GetSeason());
		}
	}

	public string getRandomWildCropForSeason(Season season)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Expected I4, but got Unknown
		return (int)season switch
		{
			0 => Game1.random.Choose("(O)16", "(O)18", "(O)20", "(O)22"), 
			1 => Game1.random.Choose("(O)396", "(O)398", "(O)402"), 
			2 => Game1.random.Choose("(O)404", "(O)406", "(O)408", "(O)410"), 
			3 => Game1.random.Choose("(O)412", "(O)414", "(O)416", "(O)418"), 
			_ => "(O)22", 
		};
	}

	public virtual Rectangle getSourceRect(int number)
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Invalid comparison between Unknown and I4
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Invalid comparison between Unknown and I4
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		if (dead.Value)
		{
			return new Rectangle(192 + number % 4 * 16, 384, 16, 32);
		}
		int num = rowInSpriteSheet.Value;
		Season seasonForLocation = Game1.GetSeasonForLocation(currentLocation);
		if (indexOfHarvest.Value == "771")
		{
			if ((int)seasonForLocation != 2)
			{
				if ((int)seasonForLocation == 3)
				{
					num = rowInSpriteSheet.Value + 2;
				}
			}
			else
			{
				num = rowInSpriteSheet.Value + 1;
			}
		}
		return new Rectangle(Math.Min(240, ((!fullyGrown.Value) ? (((phaseToShow.Value != -1) ? phaseToShow.Value : currentPhase.Value) + ((((phaseToShow.Value != -1) ? phaseToShow.Value : currentPhase.Value) == 0 && number % 2 == 0) ? (-1) : 0) + 1) : ((dayOfCurrentPhase.Value <= 0) ? 6 : 7)) * 16 + ((num % 2 != 0) ? 128 : 0)), num / 2 * 16 * 2, 16, 32);
	}

	public bool TryGetGiantCrops(out IReadOnlyList<KeyValuePair<string, GiantCropData>> giantCrops)
	{
		giantCrops = GiantCrop.GetGiantCropsFor("(O)" + indexOfHarvest.Value);
		return giantCrops.Count > 0;
	}

	public void Kill()
	{
		dead.Value = true;
		raisedSeeds.Value = false;
	}

	public virtual void newDay(int state)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fe: Unknown result type (might be due to invalid IL or missing references)
		GameLocation gameLocation = currentLocation;
		Vector2 val = tilePosition;
		Utility.Vector2ToPoint(val);
		if (gameLocation.isOutdoors.Value && (dead.Value || !IsInSeason(gameLocation)))
		{
			Kill();
			return;
		}
		if (state != 1)
		{
			CropData data = GetData();
			if (data == null || data.NeedsWatering)
			{
				goto IL_01f4;
			}
		}
		if (!fullyGrown.Value)
		{
			dayOfCurrentPhase.Value = Math.Min(dayOfCurrentPhase.Value + 1, (phaseDays.Count > 0) ? phaseDays[Math.Min(phaseDays.Count - 1, currentPhase.Value)] : 0);
		}
		else
		{
			dayOfCurrentPhase.Value--;
		}
		if (dayOfCurrentPhase.Value >= ((phaseDays.Count > 0) ? phaseDays[Math.Min(phaseDays.Count - 1, currentPhase.Value)] : 0) && currentPhase.Value < phaseDays.Count - 1)
		{
			currentPhase.Value++;
			dayOfCurrentPhase.Value = 0;
		}
		while (currentPhase.Value < phaseDays.Count - 1 && phaseDays.Count > 0 && phaseDays[currentPhase.Value] <= 0)
		{
			currentPhase.Value++;
		}
		if (isWildSeedCrop() && phaseToShow.Value == -1 && currentPhase.Value > 0)
		{
			phaseToShow.Value = Game1.random.Next(1, 7);
		}
		TryGrowGiantCrop();
		goto IL_01f4;
		IL_01f4:
		if ((!fullyGrown.Value || dayOfCurrentPhase.Value <= 0) && currentPhase.Value >= phaseDays.Count - 1)
		{
			if (replaceWithObjectOnFullGrown.Value != null || isWildSeedCrop())
			{
				if (gameLocation.objects.TryGetValue(val, out var value))
				{
					if (value is IndoorPot indoorPot)
					{
						indoorPot.heldObject.Value = ItemRegistry.Create<Object>(replaceWithObjectOnFullGrown.Value ?? getRandomWildCropForSeason());
						indoorPot.hoeDirt.Value.crop = null;
					}
					else
					{
						gameLocation.objects.Remove(val);
					}
				}
				if (!gameLocation.objects.ContainsKey(val))
				{
					Object obj = ItemRegistry.Create<Object>(replaceWithObjectOnFullGrown.Value ?? getRandomWildCropForSeason());
					obj.IsSpawnedObject = true;
					obj.CanBeGrabbed = true;
					obj.SpecialVariable = 724519;
					gameLocation.objects.Add(val, obj);
				}
				if (gameLocation.terrainFeatures.TryGetValue(val, out var value2) && value2 is HoeDirt hoeDirt)
				{
					hoeDirt.crop = null;
				}
			}
			if (indexOfHarvest.Value != null && indexOfHarvest.Value != null && indexOfHarvest.Value.Length > 0 && gameLocation.IsFarm)
			{
				foreach (Farmer allFarmer in Game1.getAllFarmers())
				{
					allFarmer.autoGenerateActiveDialogueEvent("cropMatured_" + indexOfHarvest.Value);
				}
			}
		}
		if (fullyGrown.Value && indexOfHarvest.Value != null && indexOfHarvest.Value != null && indexOfHarvest.Value == "595")
		{
			Game1.getFarm().hasMatureFairyRoseTonight = true;
		}
		updateDrawMath(val);
	}

	public virtual bool TryGrowGiantCrop(bool checkPreconditions = true, Random random = null)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		GameLocation gameLocation = currentLocation;
		Vector2 val = tilePosition;
		if (checkPreconditions)
		{
			if (!(gameLocation is Farm) && !gameLocation.HasMapPropertyWithValue("AllowGiantCrops"))
			{
				return false;
			}
			if (currentPhase.Value != phaseDays.Count - 1)
			{
				return false;
			}
		}
		if (!TryGetGiantCrops(out var giantCrops))
		{
			return false;
		}
		Vector2 key2 = default(Vector2);
		foreach (KeyValuePair<string, GiantCropData> item in giantCrops)
		{
			string key = item.Key;
			GiantCropData value = item.Value;
			if ((value.Chance < 1f && !(random ?? Utility.CreateDaySaveRandom(val.X, val.Y, Game1.hash.GetDeterministicHashCode(key))).NextBool(value.Chance)) || !GameStateQuery.CheckConditions(value.Condition, gameLocation))
			{
				continue;
			}
			bool flag = true;
			for (int i = (int)val.Y; (float)i < val.Y + (float)value.TileSize.Y; i++)
			{
				for (int j = (int)val.X; (float)j < val.X + (float)value.TileSize.X; j++)
				{
					if (!(gameLocation.terrainFeatures.GetValueOrDefault(new Vector2((float)j, (float)i)) is HoeDirt hoeDirt) || !(hoeDirt.crop?.indexOfHarvest.Value == indexOfHarvest.Value))
					{
						flag = false;
						break;
					}
				}
				if (!flag)
				{
					break;
				}
			}
			if (!flag)
			{
				continue;
			}
			for (int k = (int)val.Y; (float)k < val.Y + (float)value.TileSize.Y; k++)
			{
				for (int l = (int)val.X; (float)l < val.X + (float)value.TileSize.X; l++)
				{
					((Vector2)(ref key2))._002Ector((float)l, (float)k);
					((HoeDirt)gameLocation.terrainFeatures[key2]).crop = null;
				}
			}
			gameLocation.resourceClumps.Add(new GiantCrop(key, val));
			return true;
		}
		return false;
	}

	public virtual bool isPaddyCrop()
	{
		return GetData()?.IsPaddyCrop ?? false;
	}

	public virtual bool shouldDrawDarkWhenWatered()
	{
		if (isPaddyCrop())
		{
			return false;
		}
		return !raisedSeeds.Value;
	}

	public virtual bool isWildSeedCrop()
	{
		if (overrideTexturePath.Value == null || overrideTexturePath.Value == ((GraphicsResource)Game1.cropSpriteSheet).Name)
		{
			return rowInSpriteSheet.Value == 23;
		}
		return false;
	}

	public virtual void updateDrawMath(Vector2 tileLocation)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_037e: Unknown result type (might be due to invalid IL or missing references)
		//IL_037f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0314: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_031f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		if (((Vector2)(ref tileLocation)).Equals(Vector2.Zero))
		{
			return;
		}
		if (forageCrop.Value)
		{
			if (!int.TryParse(whichForageCrop.Value, out var result))
			{
				result = 1;
			}
			drawPosition = new Vector2(tileLocation.X * 64f + ((tileLocation.X * 11f + tileLocation.Y * 7f) % 10f - 5f) + 32f, tileLocation.Y * 64f + ((tileLocation.Y * 11f + tileLocation.X * 7f) % 10f - 5f) + 32f);
			layerDepth = (tileLocation.Y * 64f + 32f + ((tileLocation.Y * 11f + tileLocation.X * 7f) % 10f - 5f)) / 10000f;
			sourceRect = new Rectangle((int)(tileLocation.X * 51f + tileLocation.Y * 77f) % 3 * 16, 128 + result * 16, 16, 16);
		}
		else
		{
			drawPosition = new Vector2(tileLocation.X * 64f + ((!shouldDrawDarkWhenWatered() || currentPhase.Value >= phaseDays.Count - 1) ? 0f : ((tileLocation.X * 11f + tileLocation.Y * 7f) % 10f - 5f)) + 32f, tileLocation.Y * 64f + ((raisedSeeds.Value || currentPhase.Value >= phaseDays.Count - 1) ? 0f : ((tileLocation.Y * 11f + tileLocation.X * 7f) % 10f - 5f)) + 32f);
			layerDepth = (tileLocation.Y * 64f + 32f + ((!shouldDrawDarkWhenWatered() || currentPhase.Value >= phaseDays.Count - 1) ? 0f : ((tileLocation.Y * 11f + tileLocation.X * 7f) % 10f - 5f))) / 10000f / ((currentPhase.Value == 0 && shouldDrawDarkWhenWatered()) ? 2f : 1f);
			sourceRect = getSourceRect((int)tileLocation.X * 7 + (int)tileLocation.Y * 11);
			coloredSourceRect = new Rectangle(((!fullyGrown.Value) ? (currentPhase.Value + 1 + 1) : ((dayOfCurrentPhase.Value <= 0) ? 6 : 7)) * 16 + ((rowInSpriteSheet.Value % 2 != 0) ? 128 : 0), rowInSpriteSheet.Value / 2 * 16 * 2, 16, 32);
			coloredLayerDepth = (tileLocation.Y * 64f + 32f + ((tileLocation.Y * 11f + tileLocation.X * 7f) % 10f - 5f)) / 10000f / (float)((currentPhase.Value != 0 || !shouldDrawDarkWhenWatered()) ? 1 : 2);
		}
		tilePosition = tileLocation;
	}

	public virtual void draw(SpriteBatch b, Vector2 tileLocation, Color toTint, float rotation)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0265: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = Game1.GlobalToLocal(Game1.viewport, drawPosition);
		if (forageCrop.Value)
		{
			if (whichForageCrop.Value == "2")
			{
				b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2(tileLocation.X * 64f + ((tileLocation.X * 11f + tileLocation.Y * 7f) % 10f - 5f) + 32f, tileLocation.Y * 64f + ((tileLocation.Y * 11f + tileLocation.X * 7f) % 10f - 5f) + 64f)), (Rectangle?)new Rectangle(128 + (int)((Game1.currentGameTime.TotalGameTime.TotalMilliseconds + (double)(tileLocation.X * 111f + tileLocation.Y * 77f)) % 800.0 / 200.0) * 16, 128, 16, 16), Color.White, rotation, new Vector2(8f, 16f), 4f, (SpriteEffects)0, (tileLocation.Y * 64f + 32f + ((tileLocation.Y * 11f + tileLocation.X * 7f) % 10f - 5f)) / 10000f);
			}
			else
			{
				b.Draw(Game1.mouseCursors, val, (Rectangle?)sourceRect, Color.White, 0f, smallestTileSizeOrigin, 4f, (SpriteEffects)0, layerDepth);
			}
			return;
		}
		if (IsErrorCrop())
		{
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem("(O)" + indexOfHarvest.Value);
			b.Draw(dataOrErrorItem.GetTexture(), val, (Rectangle?)dataOrErrorItem.GetSourceRect(), toTint, rotation, new Vector2(8f, 8f), 4f, (SpriteEffects)0, layerDepth);
			return;
		}
		SpriteEffects val2 = (SpriteEffects)(flip.Value ? 1 : 0);
		b.Draw(DrawnCropTexture, val, (Rectangle?)sourceRect, toTint, rotation, origin, 4f, val2, layerDepth);
		Color value = tintColor.Value;
		if (!((Color)(ref value)).Equals(Color.White) && currentPhase.Value == phaseDays.Count - 1 && !dead.Value)
		{
			b.Draw(DrawnCropTexture, val, (Rectangle?)coloredSourceRect, value, rotation, origin, 4f, val2, coloredLayerDepth);
		}
	}

	public virtual void drawInMenu(SpriteBatch b, Vector2 screenPosition, Color toTint, float rotation, float scale, float layerDepth)
	{
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (IsErrorCrop())
		{
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem("(O)" + indexOfHarvest.Value);
			b.Draw(dataOrErrorItem.GetTexture(), screenPosition, (Rectangle?)dataOrErrorItem.GetSourceRect(), toTint, rotation, new Vector2(32f, 32f), scale, (SpriteEffects)(flip.Value ? 1 : 0), layerDepth);
		}
		else
		{
			b.Draw(DrawnCropTexture, screenPosition, (Rectangle?)getSourceRect(0), toTint, rotation, new Vector2(32f, 96f), scale, (SpriteEffects)(flip.Value ? 1 : 0), layerDepth);
		}
	}

	public virtual void drawWithOffset(SpriteBatch b, Vector2 tileLocation, Color toTint, float rotation, Vector2 offset)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		if (IsErrorCrop())
		{
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem("(O)" + indexOfHarvest.Value);
			b.Draw(dataOrErrorItem.GetTexture(), Game1.GlobalToLocal(Game1.viewport, offset + new Vector2(tileLocation.X * 64f, tileLocation.Y * 64f)), (Rectangle?)dataOrErrorItem.GetSourceRect(), toTint, rotation, new Vector2(8f, 8f), 4f, (SpriteEffects)(flip.Value ? 1 : 0), (tileLocation.Y + 0.66f) * 64f / 10000f + tileLocation.X * 1E-05f);
			return;
		}
		if (forageCrop.Value)
		{
			b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, offset + new Vector2(tileLocation.X * 64f, tileLocation.Y * 64f)), (Rectangle?)sourceRect, Color.White, 0f, new Vector2(8f, 8f), 4f, (SpriteEffects)0, (tileLocation.Y + 0.66f) * 64f / 10000f + tileLocation.X * 1E-05f);
			return;
		}
		b.Draw(DrawnCropTexture, Game1.GlobalToLocal(Game1.viewport, offset + new Vector2(tileLocation.X * 64f, tileLocation.Y * 64f)), (Rectangle?)sourceRect, toTint, rotation, new Vector2(8f, 24f), 4f, (SpriteEffects)(flip.Value ? 1 : 0), (tileLocation.Y + 0.66f) * 64f / 10000f + tileLocation.X * 1E-05f);
		if (!tintColor.Equals(Color.White) && currentPhase.Value == phaseDays.Count - 1 && !dead.Value)
		{
			b.Draw(DrawnCropTexture, Game1.GlobalToLocal(Game1.viewport, offset + new Vector2(tileLocation.X * 64f, tileLocation.Y * 64f)), (Rectangle?)coloredSourceRect, tintColor.Value, rotation, new Vector2(8f, 24f), 4f, (SpriteEffects)(flip.Value ? 1 : 0), (tileLocation.Y + 0.67f) * 64f / 10000f + tileLocation.X * 1E-05f);
		}
	}
}
