using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.GameData.Fences;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Tools;

namespace StardewValley;

public class Fence : Object
{
	public const int debrisPieces = 4;

	public static int fencePieceWidth = 16;

	public static int fencePieceHeight = 32;

	public const int gateClosedPosition = 0;

	public const int gateOpenedPosition = 88;

	public const int sourceRectForSoloGate = 17;

	public const int globalHealthMultiplier = 2;

	public const int N = 1000;

	public const int E = 100;

	public const int S = 500;

	public const int W = 10;

	public const string woodFenceId = "322";

	public const string stoneFenceId = "323";

	public const string ironFenceId = "324";

	public const string hardwoodFenceId = "298";

	public const string gateId = "325";

	[XmlIgnore]
	public Lazy<Texture2D> fenceTexture;

	public static Dictionary<int, int> fenceDrawGuide;

	[XmlElement("health")]
	public new readonly NetFloat health = new NetFloat();

	[XmlElement("maxHealth")]
	public readonly NetFloat maxHealth = new NetFloat();

	[XmlElement("whichType")]
	public int? obsolete_whichType;

	[XmlElement("gatePosition")]
	public readonly NetInt gatePosition = new NetInt();

	public int gateMotion;

	[XmlElement("isGate")]
	public readonly NetBool isGate = new NetBool();

	[XmlIgnore]
	public readonly NetBool repairQueued = new NetBool();

	protected static Dictionary<string, FenceData> _FenceLookup;

	protected FenceData _data;

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(health, "health").AddField(maxHealth, "maxHealth").AddField(gatePosition, "gatePosition")
			.AddField(isGate, "isGate")
			.AddField(repairQueued, "repairQueued");
		itemId.fieldChangeVisibleEvent += delegate
		{
			OnIdChanged();
		};
		isGate.fieldChangeVisibleEvent += delegate
		{
			OnIdChanged();
		};
	}

	public Fence(Vector2 tileLocation, string itemId, bool isGate)
		: base(itemId, 1)
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (fenceDrawGuide == null)
		{
			populateFenceDrawGuide();
		}
		base.Type = "Crafting";
		this.isGate.Value = isGate;
		TileLocation = tileLocation;
		canBeSetDown.Value = true;
		canBeGrabbed.Value = true;
		price.Value = 1;
		ResetHealth((float)Game1.random.Next(-100, 101) / 100f);
		if (isGate)
		{
			health.Value *= 2f;
		}
		OnIdChanged();
	}

	public Fence()
		: this(Vector2.Zero, "322", isGate: false)
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public virtual void ResetHealth(float amount_adjustment)
	{
		float num = GetData()?.Health ?? 100;
		if (isGate.Value)
		{
			amount_adjustment = 0f;
		}
		health.Value = num + amount_adjustment;
		health.Value *= 2f;
		maxHealth.Value = health.Value;
	}

	protected override void MigrateLegacyItemId()
	{
		switch (obsolete_whichType ?? 1)
		{
		case 2:
			base.ItemId = "323";
			break;
		case 3:
			base.ItemId = "324";
			break;
		case 4:
			base.ItemId = "325";
			break;
		case 5:
			base.ItemId = "298";
			break;
		default:
			base.ItemId = "322";
			break;
		}
		obsolete_whichType = null;
	}

	protected virtual void OnIdChanged()
	{
		if (fenceTexture == null || fenceTexture.IsValueCreated)
		{
			fenceTexture = new Lazy<Texture2D>((Func<Texture2D>)loadFenceTexture);
		}
		_data = null;
	}

	public virtual void repair()
	{
		ResetHealth((float)Game1.random.Next(-100, 101) / 100f);
	}

	public static void populateFenceDrawGuide()
	{
		fenceDrawGuide = new Dictionary<int, int>
		{
			[0] = 5,
			[10] = 9,
			[100] = 10,
			[1000] = 3,
			[500] = 5,
			[1010] = 8,
			[1100] = 6,
			[1500] = 3,
			[600] = 0,
			[510] = 2,
			[110] = 7,
			[1600] = 0,
			[1610] = 4,
			[1510] = 2,
			[1110] = 7,
			[610] = 4
		};
	}

	public virtual void PerformRepairIfNecessary()
	{
		if (Game1.IsMasterGame && repairQueued.Value)
		{
			ResetHealth(GetRepairHealthAdjustment());
			repairQueued.Value = false;
		}
	}

	public override void updateWhenCurrentLocation(GameTime time)
	{
		PerformRepairIfNecessary();
		int num = gatePosition.Get();
		num += gateMotion;
		if (num == 88)
		{
			int drawSum = getDrawSum();
			if (drawSum != 110 && drawSum != 1500 && drawSum != 1000 && drawSum != 500 && drawSum != 100 && drawSum != 10)
			{
				toggleGate(Game1.player, open: false);
			}
		}
		gatePosition.Set(num);
		if (num >= 88 || num <= 0)
		{
			gateMotion = 0;
		}
		heldObject.Get()?.updateWhenCurrentLocation(time);
	}

	public static Dictionary<string, FenceData> GetFenceLookup()
	{
		if (_FenceLookup == null)
		{
			_LoadFenceData();
		}
		return _FenceLookup;
	}

	public FenceData GetData()
	{
		if (_data == null)
		{
			TryGetData(base.ItemId, out _data);
		}
		return _data;
	}

	public static bool TryGetData(string itemId, out FenceData data)
	{
		if (itemId == null)
		{
			data = null;
			return false;
		}
		return GetFenceLookup().TryGetValue(itemId, out data);
	}

	protected static void _LoadFenceData()
	{
		_FenceLookup = DataLoader.Fences(Game1.content);
	}

	public int getDrawSum()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return 0;
		}
		int num = 0;
		Vector2 value = tileLocation.Value;
		value.X += 1f;
		if (location.objects.TryGetValue(value, out var value2) && value2 is Fence fence && fence.countsForDrawing(base.ItemId))
		{
			num += 100;
		}
		value.X -= 2f;
		if (location.objects.TryGetValue(value, out var value3) && value3 is Fence fence2 && fence2.countsForDrawing(base.ItemId))
		{
			num += 10;
		}
		value.X += 1f;
		value.Y += 1f;
		if (location.objects.TryGetValue(value, out var value4) && value4 is Fence fence3 && fence3.countsForDrawing(base.ItemId))
		{
			num += 500;
		}
		value.Y -= 2f;
		if (location.objects.TryGetValue(value, out var value5) && value5 is Fence fence4 && fence4.countsForDrawing(base.ItemId))
		{
			num += 1000;
		}
		return num;
	}

	public override bool checkForAction(Farmer who, bool justCheckingForActivity = false)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return false;
		}
		if (!justCheckingForActivity && who != null)
		{
			Point tilePoint = who.TilePoint;
			if (location.objects.TryGetValue(new Vector2((float)tilePoint.X, (float)(tilePoint.Y - 1)), out var value) && location.objects.TryGetValue(new Vector2((float)tilePoint.X, (float)(tilePoint.Y + 1)), out var value2) && location.objects.TryGetValue(new Vector2((float)(tilePoint.X + 1), (float)tilePoint.Y), out var value3) && location.objects.TryGetValue(new Vector2((float)(tilePoint.X - 1), (float)tilePoint.Y), out var value4) && !value.isPassable() && !value2.isPassable() && !value4.isPassable() && !value3.isPassable())
			{
				performToolAction(null);
			}
		}
		if (health.Value <= 1f)
		{
			return false;
		}
		if (isGate.Value)
		{
			if (justCheckingForActivity)
			{
				return true;
			}
			if (isGate.Value)
			{
				toggleGate(who, gatePosition.Value == 0);
			}
			return true;
		}
		if (justCheckingForActivity)
		{
			return false;
		}
		foreach (Vector2 adjacentTileLocation in Utility.getAdjacentTileLocations(tileLocation.Value))
		{
			if (location.objects.TryGetValue(adjacentTileLocation, out var value5) && value5 is Fence fence && fence.isGate.Value)
			{
				fence.checkForAction(who);
				return true;
			}
		}
		return health.Value <= 0f;
	}

	public virtual void toggleGate(bool open, bool is_toggling_counterpart = false, Farmer who = null)
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		if (health.Value <= 1f)
		{
			return;
		}
		GameLocation location = Location;
		if (location == null)
		{
			return;
		}
		int drawSum = getDrawSum();
		if (drawSum == 110 || drawSum == 1500 || drawSum == 1000 || drawSum == 500 || drawSum == 100 || drawSum == 10)
		{
			who?.TemporaryPassableTiles.Add(new Rectangle((int)tileLocation.X * 64, (int)tileLocation.Y * 64, 64, 64));
			if (open)
			{
				gatePosition.Value = 88;
			}
			else
			{
				gatePosition.Value = 0;
			}
			if (!is_toggling_counterpart)
			{
				location?.playSound("doorClose");
			}
		}
		else
		{
			who?.TemporaryPassableTiles.Add(new Rectangle((int)tileLocation.X * 64, (int)tileLocation.Y * 64, 64, 64));
			gatePosition.Value = 0;
		}
		if (is_toggling_counterpart)
		{
			return;
		}
		switch (drawSum)
		{
		case 100:
		{
			Vector2 key2 = tileLocation.Value + new Vector2(-1f, 0f);
			if (location.objects.TryGetValue(key2, out var value2) && value2 is Fence fence2 && fence2.isGate.Value && fence2.getDrawSum() == 10)
			{
				fence2.toggleGate(gatePosition.Value != 0, is_toggling_counterpart: true, who);
			}
			break;
		}
		case 10:
		{
			Vector2 key4 = tileLocation.Value + new Vector2(1f, 0f);
			if (location.objects.TryGetValue(key4, out var value4) && value4 is Fence fence4 && fence4.isGate.Value && fence4.getDrawSum() == 100)
			{
				fence4.toggleGate(gatePosition.Value != 0, is_toggling_counterpart: true, who);
			}
			break;
		}
		case 1000:
		{
			Vector2 key3 = tileLocation.Value + new Vector2(0f, 1f);
			if (location.objects.TryGetValue(key3, out var value3) && value3 is Fence fence3 && fence3.isGate.Value && fence3.getDrawSum() == 500)
			{
				fence3.toggleGate(gatePosition.Value != 0, is_toggling_counterpart: true, who);
			}
			break;
		}
		case 500:
		{
			Vector2 key = tileLocation.Value + new Vector2(0f, -1f);
			if (location.objects.TryGetValue(key, out var value) && value is Fence fence && fence.isGate.Value && fence.getDrawSum() == 1000)
			{
				fence.toggleGate(gatePosition.Value != 0, is_toggling_counterpart: true, who);
			}
			break;
		}
		}
	}

	public void toggleGate(Farmer who, bool open, bool is_toggling_counterpart = false)
	{
		toggleGate(open, is_toggling_counterpart, who);
	}

	public override void dropItem(GameLocation location, Vector2 origin, Vector2 destination)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		location.debris.Add(new Debris(base.ItemId, origin, destination));
	}

	public override bool performToolAction(Tool t)
	{
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0386: Unknown result type (might be due to invalid IL or missing references)
		//IL_038b: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (heldObject.Value != null && t != null && !(t is MeleeWeapon) && t.isHeavyHitter())
		{
			Object value = heldObject.Value;
			heldObject.Value.performRemoveAction();
			heldObject.Value = null;
			Game1.createItemDebris(value.getOne(), TileLocation * 64f, -1);
			playNearbySoundAll("axchop");
		}
		else if (isGate.Value && (t is Axe || t is Pickaxe))
		{
			playNearbySoundAll("axchop");
			Game1.createObjectDebris("(O)325", (int)tileLocation.X, (int)tileLocation.Y, Game1.player.UniqueMultiplayerID, location);
			location.objects.Remove(tileLocation.Value);
			Game1.createRadialDebris(location, 12, (int)tileLocation.X, (int)tileLocation.Y, 6, resource: false);
			Game1.multiplayer.broadcastSprites(location, new TemporaryAnimatedSprite(12, new Vector2(tileLocation.X * 64f, tileLocation.Y * 64f), Color.White, 8, Game1.random.NextDouble() < 0.5, 50f));
		}
		else if (!isGate.Value && IsValidRemovalTool(t))
		{
			FenceData data = GetData();
			string audioName = data?.RemovalSound ?? data?.PlacementSound ?? "hammer";
			int debrisType = data?.RemovalDebrisType ?? 14;
			playNearbySoundAll(audioName);
			location.objects.Remove(tileLocation.Value);
			for (int i = 0; i < 4; i++)
			{
				location.temporarySprites.Add(new CosmeticDebris(fenceTexture.Value, new Vector2(tileLocation.X * 64f + 32f, tileLocation.Y * 64f + 32f), (float)Game1.random.Next(-5, 5) / 100f, (float)Game1.random.Next(-64, 64) / 30f, (float)Game1.random.Next(-800, -100) / 100f, (int)((tileLocation.Y + 1f) * 64f), new Rectangle(32 + Game1.random.Next(2) * 16 / 2, 96 + Game1.random.Next(2) * 16 / 2, 8, 8), Color.White, Game1.soundBank.GetCue("shiny4"), null, 0, 200));
			}
			Game1.createRadialDebris(location, debrisType, (int)tileLocation.X, (int)tileLocation.Y, 6, resource: false);
			Game1.multiplayer.broadcastSprites(location, new TemporaryAnimatedSprite(12, new Vector2(tileLocation.X * 64f, tileLocation.Y * 64f), Color.White, 8, Game1.random.NextBool(), 50f));
			if (maxHealth.Value - health.Value < 0.5f)
			{
				location.debris.Add(new Debris(new Object(base.ItemId, 1), tileLocation.Value * 64f + new Vector2(32f, 32f)));
			}
		}
		return false;
	}

	public virtual bool IsValidRemovalTool(Tool tool)
	{
		if (tool == null)
		{
			return !isGate.Value;
		}
		FenceData data = GetData();
		List<string> list = data?.RemovalToolIds;
		List<string> list2 = data?.RemovalToolTypes;
		bool result = true;
		if (list != null && list.Count > 0)
		{
			result = false;
			string text = tool.Name;
			foreach (string item in list)
			{
				if (text == item)
				{
					return true;
				}
			}
		}
		if (list2 != null && list2.Count > 0)
		{
			result = false;
			string fullName = tool.GetType().FullName;
			foreach (string item2 in list2)
			{
				if (fullName == item2)
				{
					return true;
				}
			}
		}
		return result;
	}

	public override bool minutesElapsed(int minutes)
	{
		if (!Game1.IsMasterGame)
		{
			return false;
		}
		PerformRepairIfNecessary();
		if (!Game1.IsBuildingConstructed("Gold Clock") || Game1.netWorldState.Value.goldenClocksTurnedOff.Value)
		{
			health.Value -= (float)minutes / 1440f;
			if (health.Value <= -1f && (Game1.timeOfDay <= 610 || Game1.timeOfDay > 1800))
			{
				return true;
			}
		}
		return false;
	}

	public override void actionOnPlayerEntry()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		base.actionOnPlayerEntry();
		if (heldObject.Value != null)
		{
			heldObject.Value.TileLocation = tileLocation.Value;
			heldObject.Value.Location = Location;
			heldObject.Value.actionOnPlayerEntry();
			heldObject.Value.isOn.Value = true;
			heldObject.Value.initializeLightSource(tileLocation.Value);
		}
	}

	public override bool performObjectDropInAction(Item dropInItem, bool probe, Farmer who, bool returnFalseIfItemConsumed = false)
	{
		//IL_046d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_038e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0398: Unknown result type (might be due to invalid IL or missing references)
		GameLocation location = Location;
		if (location == null)
		{
			return false;
		}
		if (dropInItem.HasTypeObject() && dropInItem.ItemId == "325")
		{
			if (probe)
			{
				return false;
			}
			if (!isGate.Value)
			{
				int drawSum = getDrawSum();
				if (drawSum == 1500 || drawSum == 110 || drawSum == 1000 || drawSum == 10 || drawSum == 100 || drawSum == 500)
				{
					Vector2 val = default(Vector2);
					switch (drawSum)
					{
					case 10:
						val = tileLocation.Value + new Vector2(1f, 0f);
						if (location.objects.GetValueOrDefault(val) is Fence fence2 && fence2.isGate.Value)
						{
							int drawSum3 = fence2.getDrawSum();
							if (drawSum3 != 100 && drawSum3 != 110)
							{
								return false;
							}
						}
						break;
					case 100:
						val = tileLocation.Value + new Vector2(-1f, 0f);
						if (location.objects.GetValueOrDefault(val) is Fence fence4 && fence4.isGate.Value)
						{
							int drawSum5 = fence4.getDrawSum();
							if (drawSum5 != 10 && drawSum5 != 110)
							{
								return false;
							}
						}
						break;
					case 1000:
						val = tileLocation.Value + new Vector2(0f, 1f);
						if (location.objects.GetValueOrDefault(val) is Fence fence3 && fence3.isGate.Value)
						{
							int drawSum4 = fence3.getDrawSum();
							if (drawSum4 != 500 && drawSum4 != 1500)
							{
								return false;
							}
						}
						break;
					case 500:
						val = tileLocation.Value + new Vector2(0f, -1f);
						if (location.objects.GetValueOrDefault(val) is Fence fence && fence.isGate.Value)
						{
							int drawSum2 = fence.getDrawSum();
							if (drawSum2 != 1000 && drawSum2 != 1500)
							{
								return false;
							}
						}
						break;
					}
					Vector2[] array = (Vector2[])(object)new Vector2[4]
					{
						tileLocation.Value + new Vector2(1f, 0f),
						tileLocation.Value + new Vector2(-1f, 0f),
						tileLocation.Value + new Vector2(0f, -1f),
						tileLocation.Value + new Vector2(0f, 1f)
					};
					foreach (Vector2 val2 in array)
					{
						if (!(val2 == val) && location.objects.TryGetValue(val2, out var value) && value is Fence fence5 && fence5.isGate.Value && fence5.Type == base.Type)
						{
							return false;
						}
					}
					if (heldObject.Value != null)
					{
						Object value2 = heldObject.Value;
						heldObject.Value.performRemoveAction();
						heldObject.Value = null;
						Game1.createItemDebris(value2.getOne(), TileLocation * 64f, -1);
					}
					isGate.Value = true;
					if (TryGetData("325", out var data))
					{
						location.playSound(data.PlacementSound);
					}
					return true;
				}
			}
		}
		else if (dropInItem.QualifiedItemId == "(O)93" && heldObject.Value == null && !isGate.Value)
		{
			if (!probe)
			{
				heldObject.Value = new Torch();
				location.playSound("axe");
				heldObject.Value.Location = Location;
				heldObject.Value.initializeLightSource(tileLocation.Value);
			}
			return true;
		}
		if (health.Value <= 1f && !repairQueued.Value && CanRepairWithThisItem(dropInItem))
		{
			if (!probe)
			{
				string repairSound = GetRepairSound();
				if (!string.IsNullOrEmpty(repairSound))
				{
					location.playSound(repairSound);
				}
				repairQueued.Value = true;
			}
			return true;
		}
		return base.performObjectDropInAction(dropInItem, probe, who, returnFalseIfItemConsumed);
	}

	public virtual float GetRepairHealthAdjustment()
	{
		FenceData data = GetData();
		if (data == null)
		{
			return 0f;
		}
		return Utility.RandomFloat(data.RepairHealthAdjustmentMinimum, data.RepairHealthAdjustmentMaximum);
	}

	public virtual string GetRepairSound()
	{
		return GetData()?.PlacementSound ?? "";
	}

	public virtual bool CanRepairWithThisItem(Item item)
	{
		if (health.Value > 1f)
		{
			return false;
		}
		if (item == null)
		{
			return false;
		}
		return item.QualifiedItemId == base.QualifiedItemId;
	}

	public override bool performDropDownAction(Farmer who)
	{
		return false;
	}

	public virtual Texture2D loadFenceTexture()
	{
		if (base.ItemId == "325")
		{
			isGate.Value = true;
		}
		FenceData data = GetData();
		if (data == null)
		{
			return ItemRegistry.RequireTypeDefinition(TypeDefinitionId).GetErrorTexture();
		}
		return Game1.content.Load<Texture2D>(data.Texture);
	}

	public override void drawWhenHeld(SpriteBatch spriteBatch, Vector2 objectPosition, Farmer f)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		spriteBatch.Draw(fenceTexture.Value, objectPosition - new Vector2(0f, 64f), (Rectangle?)new Rectangle(5 * fencePieceWidth % fenceTexture.Value.Bounds.Width, 5 * fencePieceWidth / fenceTexture.Value.Bounds.Width * fencePieceHeight, fencePieceWidth, fencePieceHeight), Color.White, 0f, Vector2.Zero, 1f, (SpriteEffects)0, (float)(f.StandingPixel.Y + 1) / 10000f);
	}

	public override void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scale, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		location.Y -= 64f * scale;
		int drawSum = getDrawSum();
		int tilePosition = fenceDrawGuide[drawSum];
		if (isGate.Value)
		{
			switch (drawSum)
			{
			case 110:
				spriteBatch.Draw(fenceTexture.Value, location + new Vector2(6f, 6f), (Rectangle?)new Rectangle(0, 512, 88, 24), color, 0f, Vector2.Zero, scale, (SpriteEffects)0, layerDepth);
				return;
			case 1500:
				spriteBatch.Draw(fenceTexture.Value, location + new Vector2(6f, 6f), (Rectangle?)new Rectangle(112, 512, 16, 64), color, 0f, Vector2.Zero, scale, (SpriteEffects)0, layerDepth);
				return;
			}
		}
		spriteBatch.Draw(fenceTexture.Value, location + new Vector2(32f, 32f) * scale, (Rectangle?)Game1.getArbitrarySourceRect(fenceTexture.Value, 64, 128, tilePosition), color * transparency, 0f, new Vector2(32f, 32f) * scale, scale, (SpriteEffects)0, layerDepth);
	}

	public bool countsForDrawing(string otherItemId)
	{
		if ((health.Value > 1f || repairQueued.Value) && !isGate.Value)
		{
			if (!(otherItemId == base.ItemId))
			{
				return otherItemId == "325";
			}
			return true;
		}
		return false;
	}

	public override bool isPassable()
	{
		if (isGate.Value)
		{
			return gatePosition.Value >= 88;
		}
		return false;
	}

	public override void draw(SpriteBatch b, int x, int y, float alpha = 1f)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0571: Unknown result type (might be due to invalid IL or missing references)
		//IL_0583: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_059f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04db: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0519: Unknown result type (might be due to invalid IL or missing references)
		//IL_0520: Unknown result type (might be due to invalid IL or missing references)
		//IL_0525: Unknown result type (might be due to invalid IL or missing references)
		//IL_0537: Unknown result type (might be due to invalid IL or missing references)
		//IL_0544: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_035a: Unknown result type (might be due to invalid IL or missing references)
		//IL_035f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0408: Unknown result type (might be due to invalid IL or missing references)
		//IL_0412: Unknown result type (might be due to invalid IL or missing references)
		//IL_041c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0448: Unknown result type (might be due to invalid IL or missing references)
		//IL_044d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0462: Unknown result type (might be due to invalid IL or missing references)
		//IL_0467: Unknown result type (might be due to invalid IL or missing references)
		//IL_046c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0381: Unknown result type (might be due to invalid IL or missing references)
		//IL_038b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_048e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0498: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a2: Unknown result type (might be due to invalid IL or missing references)
		int num = 1;
		FenceData data = GetData();
		if (data == null)
		{
			IItemDataDefinition itemDataDefinition = ItemRegistry.RequireTypeDefinition(TypeDefinitionId);
			b.Draw(itemDataDefinition.GetErrorTexture(), Game1.GlobalToLocal(Game1.viewport, new Vector2(tileLocation.X * 64f, tileLocation.Y * 64f)), (Rectangle?)itemDataDefinition.GetErrorSourceRect(), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, 1E-09f);
			return;
		}
		if (health.Value > 1f || repairQueued.Value)
		{
			int drawSum = getDrawSum();
			num = fenceDrawGuide[drawSum];
			if (isGate.Value)
			{
				Vector2 val = default(Vector2);
				((Vector2)(ref val))._002Ector(0f, 0f);
				switch (drawSum)
				{
				case 10:
					b.Draw(fenceTexture.Value, Game1.GlobalToLocal(Game1.viewport, val + new Vector2((float)(x * 64 - 16), (float)(y * 64 - 128))), (Rectangle?)new Rectangle((gatePosition.Value == 88) ? 24 : 0, 192, 24, 48), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(y * 64 + 32 + 1) / 10000f);
					return;
				case 100:
					b.Draw(fenceTexture.Value, Game1.GlobalToLocal(Game1.viewport, val + new Vector2((float)(x * 64 - 16), (float)(y * 64 - 128))), (Rectangle?)new Rectangle((gatePosition.Value == 88) ? 24 : 0, 240, 24, 48), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(y * 64 + 32 + 1) / 10000f);
					return;
				case 1000:
					b.Draw(fenceTexture.Value, Game1.GlobalToLocal(Game1.viewport, val + new Vector2((float)(x * 64 + 20), (float)(y * 64 - 64 - 20))), (Rectangle?)new Rectangle((gatePosition.Value == 88) ? 24 : 0, 288, 24, 32), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(y * 64 - 32 + 2) / 10000f);
					return;
				case 500:
					b.Draw(fenceTexture.Value, Game1.GlobalToLocal(Game1.viewport, val + new Vector2((float)(x * 64 + 20), (float)(y * 64 - 64 - 20))), (Rectangle?)new Rectangle((gatePosition.Value == 88) ? 24 : 0, 320, 24, 32), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(y * 64 + 96 - 1) / 10000f);
					return;
				case 110:
					b.Draw(fenceTexture.Value, Game1.GlobalToLocal(Game1.viewport, val + new Vector2((float)(x * 64 - 16), (float)(y * 64 - 64))), (Rectangle?)new Rectangle((gatePosition.Value == 88) ? 24 : 0, 128, 24, 32), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(y * 64 + 32 + 1) / 10000f);
					return;
				case 1500:
					b.Draw(fenceTexture.Value, Game1.GlobalToLocal(Game1.viewport, val + new Vector2((float)(x * 64 + 20), (float)(y * 64 - 64 - 20))), (Rectangle?)new Rectangle((gatePosition.Value == 88) ? 16 : 0, 160, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(y * 64 - 32 + 2) / 10000f);
					b.Draw(fenceTexture.Value, Game1.GlobalToLocal(Game1.viewport, val + new Vector2((float)(x * 64 + 20), (float)(y * 64 - 64 + 44))), (Rectangle?)new Rectangle((gatePosition.Value == 88) ? 16 : 0, 176, 16, 16), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(y * 64 + 96 - 1) / 10000f);
					return;
				}
				num = 17;
			}
			else if (heldObject.Value != null)
			{
				Vector2 zero = Vector2.Zero;
				zero += data.HeldObjectDrawOffset;
				switch (drawSum)
				{
				case 10:
					zero.X = data.RightEndHeldObjectDrawX;
					break;
				case 100:
					zero.X = data.LeftEndHeldObjectDrawX;
					break;
				}
				zero *= 4f;
				heldObject.Value.draw(b, x * 64 + (int)zero.X, y * 64 + (int)zero.Y, (float)(y * 64 + 64) / 10000f, 1f);
			}
		}
		b.Draw(fenceTexture.Value, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)(y * 64 - 64))), (Rectangle?)new Rectangle(num * fencePieceWidth % fenceTexture.Value.Bounds.Width, num * fencePieceWidth / fenceTexture.Value.Bounds.Width * fencePieceHeight, fencePieceWidth, fencePieceHeight), Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, (float)(y * 64 + 32) / 10000f);
	}
}
