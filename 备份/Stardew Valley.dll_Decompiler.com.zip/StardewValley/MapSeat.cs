using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Network;

namespace StardewValley;

public class MapSeat : INetObject<NetFields>, ISittable
{
	[XmlIgnore]
	public static Texture2D mapChairTexture;

	[XmlIgnore]
	public NetLongDictionary<int, NetInt> sittingFarmers = new NetLongDictionary<int, NetInt>();

	[XmlIgnore]
	public NetVector2 tilePosition = new NetVector2();

	[XmlIgnore]
	public NetVector2 size = new NetVector2();

	[XmlIgnore]
	public NetInt direction = new NetInt();

	[XmlIgnore]
	public NetVector2 drawTilePosition = new NetVector2(new Vector2(-1f, -1f));

	[XmlIgnore]
	public NetBool seasonal = new NetBool();

	[XmlIgnore]
	public NetString seatType = new NetString();

	[XmlIgnore]
	public NetString textureFile = new NetString(null);

	[XmlIgnore]
	public string _loadedTextureFile;

	[XmlIgnore]
	public Texture2D overlayTexture;

	[XmlIgnore]
	public int localSittingDirection = 2;

	[XmlIgnore]
	public Vector3? customDrawValues;

	[XmlIgnore]
	public NetFields NetFields { get; } = new NetFields("MapSeat");

	public MapSeat()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		NetFields.SetOwner(this).AddField(sittingFarmers, "sittingFarmers").AddField(tilePosition, "tilePosition")
			.AddField(size, "size")
			.AddField(direction, "direction")
			.AddField(drawTilePosition, "drawTilePosition")
			.AddField(seasonal, "seasonal")
			.AddField(seatType, "seatType")
			.AddField(textureFile, "textureFile");
	}

	public static MapSeat FromData(string data, int x, int y)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		MapSeat mapSeat = new MapSeat();
		try
		{
			string[] array = data.Split('/');
			mapSeat.tilePosition.Set(new Vector2((float)x, (float)y));
			mapSeat.size.Set(new Vector2((float)int.Parse(array[0]), (float)int.Parse(array[1])));
			mapSeat.seatType.Value = array[3];
			int parsed;
			if (array[2] == "opposite")
			{
				mapSeat.direction.Value = -2;
			}
			else if (Utility.TryParseDirection(array[2], out parsed))
			{
				mapSeat.direction.Value = parsed;
			}
			else
			{
				mapSeat.direction.Value = 2;
			}
			mapSeat.drawTilePosition.Set(new Vector2((float)int.Parse(array[4]), (float)int.Parse(array[5])));
			mapSeat.seasonal.Value = array[6] == "true";
			if (array.Length > 7)
			{
				mapSeat.textureFile.Value = array[7];
			}
			else
			{
				mapSeat.textureFile.Value = null;
			}
		}
		catch (Exception)
		{
		}
		return mapSeat;
	}

	public bool IsBlocked(GameLocation location)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		Rectangle seatBounds = GetSeatBounds();
		seatBounds.X *= 64;
		seatBounds.Y *= 64;
		seatBounds.Width *= 64;
		seatBounds.Height *= 64;
		Rectangle val = seatBounds;
		switch (direction.Value)
		{
		case 0:
			val.Y -= 32;
			val.Height += 32;
			break;
		case 2:
			val.Height += 32;
			break;
		case 3:
			val.X -= 32;
			val.Width += 32;
			break;
		case 1:
			val.Width += 32;
			break;
		}
		foreach (NPC item in (Game1.CurrentEvent != null) ? Game1.CurrentEvent.actors : location.characters.ToList())
		{
			Rectangle boundingBox = item.GetBoundingBox();
			if (((Rectangle)(ref boundingBox)).Intersects(seatBounds))
			{
				return true;
			}
			if (!item.isMovingOnPathFindPath.Value && ((Rectangle)(ref boundingBox)).Intersects(val))
			{
				return true;
			}
		}
		return false;
	}

	public bool IsSittingHere(Farmer who)
	{
		return sittingFarmers.ContainsKey(who.UniqueMultiplayerID);
	}

	public bool HasSittingFarmers()
	{
		return sittingFarmers.Length > 0;
	}

	public List<Vector2> GetSeatPositions(bool ignore_offsets = false)
	{
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0349: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_032d: Unknown result type (might be due to invalid IL or missing references)
		customDrawValues = null;
		List<Vector2> list = new List<Vector2>();
		string value = seatType.Value;
		if (!(value == "playground"))
		{
			if (value == "ccdesk")
			{
				Vector2 item = default(Vector2);
				((Vector2)(ref item))._002Ector(tilePosition.X + 0.5f, tilePosition.Y);
				if (!ignore_offsets)
				{
					item.Y -= 0.4f;
				}
				list.Add(item);
			}
			else if (seatType.Value.StartsWith("custom "))
			{
				float num = 0f;
				float num2 = 0f;
				float num3 = 0f;
				string[] array = ArgUtility.SplitBySpace(seatType.Value);
				try
				{
					if (array.Length > 1)
					{
						num = float.Parse(array[1]);
					}
					if (array.Length > 2)
					{
						num2 = float.Parse(array[2]);
					}
					if (array.Length > 3)
					{
						num3 = float.Parse(array[3]);
					}
				}
				catch (Exception)
				{
				}
				customDrawValues = new Vector3(num, num2, num3);
				Vector2 item2 = default(Vector2);
				((Vector2)(ref item2))._002Ector(tilePosition.X + customDrawValues.Value.X, tilePosition.Y);
				if (!ignore_offsets)
				{
					item2.Y += customDrawValues.Value.Y;
				}
				list.Add(item2);
			}
			else
			{
				Vector2 zero = default(Vector2);
				for (int i = 0; (float)i < size.X; i++)
				{
					for (int j = 0; (float)j < size.Y; j++)
					{
						((Vector2)(ref zero))._002Ector(0f, 0f);
						if (seatType.Value.StartsWith("bench"))
						{
							if (direction.Value == 2)
							{
								zero.Y += 0.25f;
							}
							else if ((direction.Value == 3 || direction.Value == 1) && j == 0)
							{
								zero.Y += 0.5f;
							}
						}
						if (seatType.Value.StartsWith("picnic"))
						{
							switch (direction.Value)
							{
							case 2:
								zero.Y -= 0.25f;
								break;
							case 0:
								zero.Y += 0.25f;
								break;
							}
						}
						if (seatType.Value.EndsWith("swings"))
						{
							zero.Y -= 0.5f;
						}
						else if (seatType.Value.EndsWith("summitbench"))
						{
							zero.Y -= 0.2f;
						}
						else if (seatType.Value.EndsWith("tall"))
						{
							zero.Y -= 0.3f;
						}
						else if (seatType.Value.EndsWith("short"))
						{
							zero.Y += 0.3f;
						}
						if (ignore_offsets)
						{
							zero = Vector2.Zero;
						}
						list.Add(tilePosition.Value + new Vector2((float)i + zero.X, (float)j + zero.Y));
					}
				}
			}
		}
		else
		{
			Vector2 item3 = default(Vector2);
			((Vector2)(ref item3))._002Ector(tilePosition.X + 0.75f, tilePosition.Y);
			if (!ignore_offsets)
			{
				item3.Y -= 0.1f;
			}
			list.Add(item3);
		}
		return list;
	}

	public virtual void Draw(SpriteBatch b)
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		if (_loadedTextureFile != textureFile.Value)
		{
			_loadedTextureFile = textureFile.Value;
			try
			{
				overlayTexture = Game1.content.Load<Texture2D>(_loadedTextureFile);
			}
			catch (Exception)
			{
				overlayTexture = null;
			}
		}
		if (overlayTexture == null)
		{
			overlayTexture = mapChairTexture;
		}
		if (drawTilePosition.Value.X >= 0f && HasSittingFarmers())
		{
			float num = 0f;
			if (customDrawValues.HasValue)
			{
				num = customDrawValues.Value.Z;
			}
			else if (seatType.Value.StartsWith("highback_chair") || seatType.Value.StartsWith("ccdesk"))
			{
				num = 1f;
			}
			Vector2 val = Game1.GlobalToLocal(Game1.viewport, new Vector2(tilePosition.X * 64f, (tilePosition.Y - num) * 64f));
			float num2 = (float)(((double)((float)(int)tilePosition.Y + size.Y) + 0.1) * 64.0) / 10000f;
			Rectangle val2 = default(Rectangle);
			((Rectangle)(ref val2))._002Ector((int)drawTilePosition.Value.X * 16, (int)(drawTilePosition.Value.Y - num) * 16, (int)size.Value.X * 16, (int)(size.Value.Y + num) * 16);
			if (seasonal.Value)
			{
				val2.X += val2.Width * Game1.currentLocation.GetSeasonIndex();
			}
			b.Draw(overlayTexture, val, (Rectangle?)val2, Color.White, 0f, Vector2.Zero, 4f, (SpriteEffects)0, num2);
		}
	}

	public bool OccupiesTile(int x, int y)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		Rectangle seatBounds = GetSeatBounds();
		return ((Rectangle)(ref seatBounds)).Contains(x, y);
	}

	public virtual Vector2? AddSittingFarmer(Farmer who)
	{
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		if (who == Game1.player)
		{
			localSittingDirection = direction.Value;
			if (seatType.Value.StartsWith("stool"))
			{
				localSittingDirection = Game1.player.FacingDirection;
			}
			if (direction.Value == -2)
			{
				localSittingDirection = Utility.GetOppositeFacingDirection(Game1.player.FacingDirection);
			}
			if (seatType.Value.StartsWith("bathchair") && localSittingDirection == 0)
			{
				localSittingDirection = 2;
			}
		}
		List<Vector2> seatPositions = GetSeatPositions();
		if (seatPositions.Count == 0)
		{
			return null;
		}
		CheckSeatOccupancyIfTemporaryMap(who, seatPositions, out var seatsFilled);
		if (seatsFilled.All((bool occupied) => occupied))
		{
			return null;
		}
		int value = -1;
		Vector2? result = null;
		float num = 96f;
		for (int num2 = 0; num2 < seatPositions.Count; num2++)
		{
			if (!sittingFarmers.Values.Contains(num2) && !seatsFilled[num2])
			{
				Vector2 val = (seatPositions[num2] + new Vector2(0.5f, 0.5f)) * 64f - who.getStandingPosition();
				float num3 = ((Vector2)(ref val)).Length();
				if (num3 < num)
				{
					num = num3;
					result = seatPositions[num2];
					value = num2;
				}
			}
		}
		if (result.HasValue)
		{
			sittingFarmers[who.UniqueMultiplayerID] = value;
		}
		return result;
	}

	public bool IsSeatHere(GameLocation location)
	{
		return location.mapSeats.Contains(this);
	}

	public int GetSittingDirection()
	{
		return localSittingDirection;
	}

	public Vector2? GetSittingPosition(Farmer who, bool ignore_offsets = false)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if (sittingFarmers.TryGetValue(who.UniqueMultiplayerID, out var value))
		{
			return GetSeatPositions(ignore_offsets)[value];
		}
		return null;
	}

	public virtual Rectangle GetSeatBounds()
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		if (seatType.Value == "chair" && direction.Value == 0)
		{
			new Rectangle((int)tilePosition.X, (int)tilePosition.Y + 1, (int)size.X, (int)size.Y - 1);
		}
		return new Rectangle((int)tilePosition.X, (int)tilePosition.Y, (int)size.X, (int)size.Y);
	}

	public virtual void RemoveSittingFarmer(Farmer farmer)
	{
		sittingFarmers.Remove(farmer.UniqueMultiplayerID);
	}

	public virtual int GetSittingFarmerCount()
	{
		return sittingFarmers.Length;
	}

	private void CheckSeatOccupancyIfTemporaryMap(Farmer who, List<Vector2> seatPositions, out bool[] seatsFilled)
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		seatsFilled = new bool[seatPositions.Count];
		GameLocation currentLocation = who.currentLocation;
		if (currentLocation == null || !currentLocation.IsTemporary)
		{
			return;
		}
		FarmerCollection farmerCollection = currentLocation.farmers ?? Game1.getOnlineFarmers();
		if (farmerCollection.Count <= 1)
		{
			return;
		}
		List<Vector2> seatPositions2 = GetSeatPositions(ignore_offsets: true);
		Vector2 val = seatPositions2[0];
		Vector2 val2 = seatPositions2[0];
		for (int i = 1; i < seatPositions2.Count; i++)
		{
			Vector2 val3 = seatPositions2[i];
			Vector2.Min(ref val, ref val3, ref val);
			Vector2.Max(ref val2, ref val3, ref val2);
		}
		val -= new Vector2(1E-05f, 1E-05f);
		val2 += new Vector2(1E-05f, 1E-05f);
		int num = seatPositions2.Count;
		foreach (Farmer item in farmerCollection)
		{
			if (!item.isSitting.Value || item.uniqueMultiplayerID == who.uniqueMultiplayerID)
			{
				continue;
			}
			Vector2 value = item.mapChairSitPosition.Value;
			if (!(value.X > val.X) || !(value.X < val2.X) || !(value.Y > val.Y) || !(value.Y < val2.Y))
			{
				continue;
			}
			for (int j = 0; j < seatPositions2.Count; j++)
			{
				if (!seatsFilled[j])
				{
					Vector2 val4 = seatPositions2[j] - value;
					if (Math.Abs(val4.X) < 1E-05f && Math.Abs(val4.Y) < 1E-05f)
					{
						seatsFilled[j] = true;
						num--;
						break;
					}
				}
			}
			if (num == 0)
			{
				break;
			}
		}
	}
}
