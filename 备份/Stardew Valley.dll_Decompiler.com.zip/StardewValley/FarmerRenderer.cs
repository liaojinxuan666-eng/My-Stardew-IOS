using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Objects;
using StardewValley.Tools;

namespace StardewValley;

[InstanceStatics]
public class FarmerRenderer : INetObject<NetFields>
{
	public enum FarmerSpriteLayers
	{
		SlingshotUp,
		ToolUp,
		Base,
		Pants,
		FaceSkin,
		Eyes,
		Shirt,
		AccessoryUnderHair,
		ArmsUp,
		HatMaskUp,
		Hair,
		Accessory,
		Hat,
		Tool,
		Arms,
		ToolDown,
		Slingshot,
		PantsPassedOut,
		SwimWaterRing,
		MAX,
		TOOL_IN_USE_SIDE
	}

	public const int sleeveDarkestColorIndex = 256;

	public const int skinDarkestColorIndex = 260;

	public const int shoeDarkestColorIndex = 268;

	public const int eyeLightestColorIndex = 276;

	public const int accessoryDrawBelowHairThreshold = 8;

	public const int accessoryFacialHairThreshold = 6;

	protected bool _sickFrame;

	public static bool isDrawingForUI = false;

	public const int TransparentSkin = -12345;

	public const int pantsOffset = 288;

	public const int armOffset = 96;

	public const int shirtXOffset = 16;

	public const int shirtYOffset = 56;

	public static int[] featureYOffsetPerFrame = new int[126]
	{
		1, 2, 2, 0, 5, 6, 1, 2, 2, 1,
		0, 2, 0, 1, 1, 0, 2, 2, 3, 3,
		2, 2, 1, 1, 0, 0, 2, 2, 4, 4,
		0, 0, 1, 2, 1, 1, 1, 1, 0, 0,
		1, 1, 1, 0, 0, -2, -1, 1, 1, 0,
		-1, -2, -1, -1, 5, 4, 0, 0, 3, 2,
		-1, 0, 4, 2, 0, 0, 2, 1, 0, -1,
		1, -2, 0, 0, 1, 1, 1, 1, 1, 1,
		0, 0, 0, 0, 1, -1, -1, -1, -1, 1,
		1, 0, 0, 0, 0, 4, 1, 0, 1, 2,
		1, 0, 1, 0, 1, 2, -3, -4, -1, 0,
		0, 2, 1, -4, -1, 0, 0, -3, 0, 0,
		-1, 0, 0, 2, 1, 1
	};

	public static int[] featureXOffsetPerFrame = new int[126]
	{
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, -1, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, -1,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, -1, -1, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 4, 0, 0, 0, 0, -1, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, -1, 0, 0,
		0, 0, 0, 0, 0, 0
	};

	public static int[] hairstyleHatOffset = new int[16]
	{
		0, 0, 0, 4, 0, 0, 3, 0, 4, 0,
		0, 0, 0, 0, 0, 0
	};

	public static Texture2D hairStylesTexture;

	public static Texture2D shirtsTexture;

	public static Texture2D hatsTexture;

	public static Texture2D accessoriesTexture;

	public static Texture2D pantsTexture;

	public static Dictionary<string, Dictionary<int, List<int>>> recolorOffsets;

	[XmlElement("textureName")]
	public readonly NetString textureName = new NetString();

	[XmlIgnore]
	private LocalizedContentManager farmerTextureManager;

	[XmlIgnore]
	internal Texture2D baseTexture;

	[XmlElement("heightOffset")]
	public readonly NetInt heightOffset = new NetInt(0);

	[XmlIgnore]
	public readonly NetColor eyes = new NetColor();

	[XmlIgnore]
	public readonly NetInt skin = new NetInt();

	[XmlIgnore]
	public readonly NetString shoes = new NetString();

	[XmlIgnore]
	public readonly NetString shirt = new NetString();

	[XmlIgnore]
	public readonly NetString pants = new NetString();

	protected bool _spriteDirty;

	protected bool _baseTextureDirty;

	protected bool _eyesDirty;

	protected bool _skinDirty;

	protected bool _shoesDirty;

	protected bool _shirtDirty;

	protected bool _pantsDirty;

	public Rectangle shirtSourceRect;

	public Rectangle hairstyleSourceRect;

	public Rectangle hatSourceRect;

	public Rectangle accessorySourceRect;

	public Vector2 rotationAdjustment;

	public Vector2 positionOffset;

	[XmlIgnore]
	public NetFields NetFields { get; } = new NetFields("FarmerRenderer");

	public FarmerRenderer()
	{
		NetFields.SetOwner(this).AddField(textureName, "textureName").AddField(heightOffset, "heightOffset")
			.AddField(eyes, "eyes")
			.AddField(skin, "skin")
			.AddField(shoes, "shoes")
			.AddField(shirt, "shirt")
			.AddField(pants, "pants");
		farmerTextureManager = Game1.content.CreateTemporary();
		textureName.fieldChangeVisibleEvent += delegate
		{
			_spriteDirty = true;
			_baseTextureDirty = true;
		};
		eyes.fieldChangeVisibleEvent += delegate
		{
			_spriteDirty = true;
			_eyesDirty = true;
		};
		skin.fieldChangeVisibleEvent += delegate
		{
			_spriteDirty = true;
			_skinDirty = true;
			_shirtDirty = true;
		};
		shoes.fieldChangeVisibleEvent += delegate
		{
			_spriteDirty = true;
			_shoesDirty = true;
		};
		shirt.fieldChangeVisibleEvent += delegate
		{
			_spriteDirty = true;
			_shirtDirty = true;
		};
		pants.fieldChangeVisibleEvent += delegate
		{
			_spriteDirty = true;
			_pantsDirty = true;
		};
		_spriteDirty = true;
		_baseTextureDirty = true;
	}

	public FarmerRenderer(string textureName, Farmer farmer)
		: this()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		eyes.Set(farmer.newEyeColor.Value);
		this.textureName.Set(textureName);
		_spriteDirty = true;
		_baseTextureDirty = true;
	}

	public bool isAccessoryFacialHair(int which)
	{
		if (which >= 6)
		{
			if (which >= 19)
			{
				return which <= 22;
			}
			return false;
		}
		return true;
	}

	public bool drawAccessoryBelowHair(int which)
	{
		if (which >= 8)
		{
			return isAccessoryFacialHair(which);
		}
		return true;
	}

	private void executeRecolorActions(Farmer farmer)
	{
		if (_spriteDirty)
		{
			_spriteDirty = false;
			if (_baseTextureDirty)
			{
				_baseTextureDirty = false;
				textureChanged();
				_eyesDirty = true;
				_shoesDirty = true;
				_pantsDirty = true;
				_skinDirty = true;
				_shirtDirty = true;
			}
			if (recolorOffsets == null)
			{
				recolorOffsets = new Dictionary<string, Dictionary<int, List<int>>>();
			}
			if (!recolorOffsets.ContainsKey(textureName.Value))
			{
				recolorOffsets[textureName.Value] = new Dictionary<int, List<int>>();
				Texture2D val = farmerTextureManager.Load<Texture2D>(textureName.Value);
				Color[] array = (Color[])(object)new Color[val.Width * val.Height];
				val.GetData<Color>(array);
				_GeneratePixelIndices(256, textureName.Value, array);
				_GeneratePixelIndices(257, textureName.Value, array);
				_GeneratePixelIndices(258, textureName.Value, array);
				_GeneratePixelIndices(268, textureName.Value, array);
				_GeneratePixelIndices(269, textureName.Value, array);
				_GeneratePixelIndices(270, textureName.Value, array);
				_GeneratePixelIndices(271, textureName.Value, array);
				_GeneratePixelIndices(260, textureName.Value, array);
				_GeneratePixelIndices(261, textureName.Value, array);
				_GeneratePixelIndices(262, textureName.Value, array);
				_GeneratePixelIndices(276, textureName.Value, array);
				_GeneratePixelIndices(277, textureName.Value, array);
			}
			Color[] array2 = (Color[])(object)new Color[baseTexture.Width * baseTexture.Height];
			baseTexture.GetData<Color>(array2);
			if (_eyesDirty)
			{
				_eyesDirty = false;
				ApplyEyeColor(textureName.Value, array2);
			}
			if (_skinDirty)
			{
				_skinDirty = false;
				ApplySkinColor(textureName.Value, array2);
			}
			if (_shoesDirty)
			{
				_shoesDirty = false;
				ApplyShoeColor(textureName.Value, array2);
			}
			if (_shirtDirty)
			{
				_shirtDirty = false;
				ApplySleeveColor(textureName.Value, array2, farmer);
			}
			if (_pantsDirty)
			{
				_pantsDirty = false;
			}
			baseTexture.SetData<Color>(array2);
		}
	}

	protected void _GeneratePixelIndices(int source_color_index, string texture_name, Color[] pixels)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		Color val = pixels[source_color_index];
		List<int> list = new List<int>();
		for (int i = 0; i < pixels.Length; i++)
		{
			if (((Color)(ref pixels[i])).PackedValue == ((Color)(ref val)).PackedValue)
			{
				list.Add(i);
			}
		}
		recolorOffsets[texture_name][source_color_index] = list;
	}

	public void unload()
	{
		((ContentManager)farmerTextureManager).Unload();
		((ContentManager)farmerTextureManager).Dispose();
	}

	public void textureChanged()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Expected O, but got Unknown
		if (baseTexture != null)
		{
			((GraphicsResource)baseTexture).Dispose();
			baseTexture = null;
		}
		Texture2D val = farmerTextureManager.Load<Texture2D>(textureName.Value);
		baseTexture = new Texture2D(Game1.graphics.GraphicsDevice, val.GetActualWidth(), val.GetActualHeight())
		{
			Name = "@FarmerRenderer.baseTexture"
		};
		Color[] array = (Color[])(object)new Color[val.GetElementCount()];
		val.GetData<Color>(array, 0, array.Length);
		baseTexture.SetData<Color>(array);
	}

	public void recolorEyes(Color lightestColor)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		eyes.Set(lightestColor);
	}

	public void ApplyEyeColor(string texture_name, Color[] pixels)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		Color value = eyes.Value;
		Color val = changeBrightness(value, -75);
		if (((Color)(ref value)).Equals(val))
		{
			((Color)(ref value)).B = (byte)(((Color)(ref value)).B + 10);
		}
		_SwapColor(texture_name, pixels, 276, value);
		_SwapColor(texture_name, pixels, 277, val);
	}

	private void _SwapColor(string texture_name, Color[] pixels, int color_index, Color color)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		foreach (int item in recolorOffsets[texture_name][color_index])
		{
			pixels[item] = color;
		}
	}

	public void recolorShoes(string which)
	{
		shoes.Set(which);
	}

	private void ApplyShoeColor(string texture_name, Color[] pixels)
	{
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		int result = 12;
		Texture2D val = null;
		int num = shoes.Value.LastIndexOf(':');
		if (num > -1)
		{
			string assetName = shoes.Value.Substring(0, num);
			string s = shoes.Value.Substring(num + 1);
			try
			{
				val = farmerTextureManager.Load<Texture2D>(assetName);
				if (!int.TryParse(s, out result))
				{
					result = 12;
				}
			}
			catch (Exception)
			{
				val = farmerTextureManager.Load<Texture2D>("Characters\\Farmer\\shoeColors");
			}
		}
		else if (!int.TryParse(shoes.Value, out result))
		{
			result = 12;
		}
		if (val == null)
		{
			val = farmerTextureManager.Load<Texture2D>("Characters\\Farmer\\shoeColors");
		}
		Texture2D val2 = val;
		if (result >= val2.Height)
		{
			result = val2.Height - 1;
		}
		if (val2.Width >= 4)
		{
			Color[] array = (Color[])(object)new Color[val2.Width * val2.Height];
			val2.GetData<Color>(array);
			Color color = array[result * 4 % (val2.Height * 4)];
			Color color2 = array[result * 4 % (val2.Height * 4) + 1];
			Color color3 = array[result * 4 % (val2.Height * 4) + 2];
			Color color4 = array[result * 4 % (val2.Height * 4) + 3];
			_SwapColor(texture_name, pixels, 268, color);
			_SwapColor(texture_name, pixels, 269, color2);
			_SwapColor(texture_name, pixels, 270, color3);
			_SwapColor(texture_name, pixels, 271, color4);
		}
	}

	public int recolorSkin(int which, bool force = false)
	{
		if (force)
		{
			skin.Value = -1;
		}
		skin.Set(which);
		return which;
	}

	private void ApplySkinColor(string texture_name, Color[] pixels)
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		int num = skin.Value;
		Texture2D val = farmerTextureManager.Load<Texture2D>("Characters\\Farmer\\skinColors");
		Color[] array = (Color[])(object)new Color[val.Width * val.Height];
		if (num < 0)
		{
			num = val.Height - 1;
		}
		if (num > val.Height - 1)
		{
			num = 0;
		}
		val.GetData<Color>(array);
		Color color = array[num * 3 % (val.Height * 3)];
		Color color2 = array[num * 3 % (val.Height * 3) + 1];
		Color color3 = array[num * 3 % (val.Height * 3) + 2];
		if (skin.Value == -12345)
		{
			color = (color2 = (color3 = Color.Transparent));
		}
		_SwapColor(texture_name, pixels, 260, color);
		_SwapColor(texture_name, pixels, 261, color2);
		_SwapColor(texture_name, pixels, 262, color3);
	}

	public void changeShirt(string whichShirt)
	{
		shirt.Set(whichShirt);
	}

	public void changePants(string whichPants)
	{
		pants.Set(whichPants);
	}

	public void MarkSpriteDirty()
	{
		_spriteDirty = true;
		_shirtDirty = true;
		_pantsDirty = true;
		_eyesDirty = true;
		_shoesDirty = true;
		_baseTextureDirty = true;
	}

	public void ApplySleeveColor(string texture_name, Color[] pixels, Farmer who)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0303: Unknown result type (might be due to invalid IL or missing references)
		//IL_030d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		who.GetDisplayShirt(out var texture, out var spriteIndex);
		Color[] array = (Color[])(object)new Color[texture.Bounds.Width * texture.Bounds.Height];
		texture.GetData<Color>(array);
		int num = spriteIndex * 8 / 128 * 32 * texture.Bounds.Width + spriteIndex * 8 % 128 + texture.Width * 4;
		int num2 = num + 128;
		if (!who.ShirtHasSleeves() || num >= array.Length || (skin.Value == -12345 && who.shirtItem.Value == null))
		{
			Texture2D val = farmerTextureManager.Load<Texture2D>("Characters\\Farmer\\skinColors");
			Color[] array2 = (Color[])(object)new Color[val.Width * val.Height];
			int num3 = skin.Value;
			if (num3 < 0)
			{
				num3 = val.Height - 1;
			}
			if (num3 > val.Height - 1)
			{
				num3 = 0;
			}
			val.GetData<Color>(array2);
			Color color = array2[num3 * 3 % (val.Height * 3)];
			Color color2 = array2[num3 * 3 % (val.Height * 3) + 1];
			Color color3 = array2[num3 * 3 % (val.Height * 3) + 2];
			if (skin.Value == -12345)
			{
				color = pixels[260 + baseTexture.Width * 2];
				color2 = pixels[261 + baseTexture.Width * 2];
				color3 = pixels[262 + baseTexture.Width * 2];
			}
			if (_sickFrame)
			{
				color = pixels[260 + baseTexture.Width];
				color2 = pixels[261 + baseTexture.Width];
				color3 = pixels[262 + baseTexture.Width];
			}
			_SwapColor(texture_name, pixels, 256, color);
			_SwapColor(texture_name, pixels, 257, color2);
			_SwapColor(texture_name, pixels, 258, color3);
		}
		else
		{
			Color val2 = Utility.MakeCompletelyOpaque(who.GetShirtColor());
			Color val3 = array[num2];
			Color b = val2;
			if (((Color)(ref val3)).A < byte.MaxValue)
			{
				val3 = array[num];
				b = Color.White;
			}
			val3 = Utility.MultiplyColor(val3, b);
			_SwapColor(texture_name, pixels, 256, val3);
			val3 = array[num2 - texture.Width];
			if (((Color)(ref val3)).A < byte.MaxValue)
			{
				val3 = array[num - texture.Width];
				b = Color.White;
			}
			val3 = Utility.MultiplyColor(val3, b);
			_SwapColor(texture_name, pixels, 257, val3);
			val3 = array[num2 - texture.Width * 2];
			if (((Color)(ref val3)).A < byte.MaxValue)
			{
				val3 = array[num - texture.Width * 2];
				b = Color.White;
			}
			val3 = Utility.MultiplyColor(val3, b);
			_SwapColor(texture_name, pixels, 258, val3);
		}
	}

	public static Color changeBrightness(Color c, int brightness)
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		((Color)(ref c)).R = (byte)Math.Min(255, Math.Max(0, ((Color)(ref c)).R + brightness));
		((Color)(ref c)).G = (byte)Math.Min(255, Math.Max(0, ((Color)(ref c)).G + brightness));
		((Color)(ref c)).B = (byte)Math.Min(255, Math.Max(0, ((Color)(ref c)).B + ((brightness > 0) ? (brightness * 5 / 6) : (brightness * 8 / 7))));
		return c;
	}

	public void draw(SpriteBatch b, Farmer who, int whichFrame, Vector2 position, float layerDepth = 1f, bool flip = false)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		who.FarmerSprite.setCurrentSingleFrame(whichFrame, 32000, secondaryArm: false, flip);
		draw(b, who.FarmerSprite, who.FarmerSprite.SourceRect, position, Vector2.Zero, layerDepth, Color.White, 0f, who);
	}

	public void draw(SpriteBatch b, FarmerSprite farmerSprite, Rectangle sourceRect, Vector2 position, Vector2 origin, float layerDepth, Color overrideColor, float rotation, Farmer who)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		draw(b, farmerSprite.CurrentAnimationFrame, farmerSprite.CurrentFrame, sourceRect, position, origin, layerDepth, overrideColor, rotation, 1f, who);
	}

	public void drawMiniPortrat(SpriteBatch b, Vector2 position, float layerDepth, float scale, int facingDirection, Farmer who, float alpha = 1f)
	{
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		int hair = who.getHair(ignore_hat: true);
		executeRecolorActions(who);
		facingDirection = 2;
		bool flag = false;
		int num = 0;
		int num2 = 0;
		HairStyleMetadata hairStyleMetadata = Farmer.GetHairStyleMetadata(who.hair.Value);
		Texture2D val = hairStyleMetadata?.texture ?? hairStylesTexture;
		hairstyleSourceRect = ((hairStyleMetadata != null) ? new Rectangle(hairStyleMetadata.tileX * 16, hairStyleMetadata.tileY * 16, 16, 15) : new Rectangle(hair * 16 % hairStylesTexture.Width, hair * 16 / hairStylesTexture.Width * 96, 16, 15));
		if (facingDirection == 2)
		{
			num = 0;
			((Rectangle)(ref hairstyleSourceRect)).Offset(0, 0);
			num2 = featureYOffsetPerFrame[0];
		}
		b.Draw(baseTexture, position, (Rectangle?)new Rectangle(0, num, 16, who.IsMale ? 15 : 16), Color.White * alpha, 0f, Vector2.Zero, scale, (SpriteEffects)(flag ? 1 : 0), GetLayerDepth(layerDepth, FarmerSpriteLayers.Base));
		Color val2 = (who.prismaticHair.Value ? Utility.GetPrismaticColor() : who.hairstyleColor.Value);
		b.Draw(val, position + new Vector2(0f, (float)(num2 * 4 + ((who.IsMale && who.hair.Value >= 16) ? (-4) : ((!who.IsMale && who.hair.Value < 16) ? 4 : 0)))) * scale / 4f, (Rectangle?)hairstyleSourceRect, val2 * alpha, 0f, Vector2.Zero, scale, (SpriteEffects)(flag ? 1 : 0), GetLayerDepth(layerDepth, FarmerSpriteLayers.Hair));
	}

	public void draw(SpriteBatch b, FarmerSprite.AnimationFrame animationFrame, int currentFrame, Rectangle sourceRect, Vector2 position, Vector2 origin, float layerDepth, Color overrideColor, float rotation, float scale, Farmer who)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		draw(b, animationFrame, currentFrame, sourceRect, position, origin, layerDepth, who.FacingDirection, overrideColor, rotation, scale, who);
	}

	public void drawHairAndAccesories(SpriteBatch b, int facingDirection, Farmer who, Vector2 position, Vector2 origin, float scale, int currentFrame, float rotation, Color overrideColor, float layerDepth)
	{
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_043a: Unknown result type (might be due to invalid IL or missing references)
		//IL_043f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0707: Unknown result type (might be due to invalid IL or missing references)
		//IL_070c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0982: Unknown result type (might be due to invalid IL or missing references)
		//IL_0987: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_039e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08da: Unknown result type (might be due to invalid IL or missing references)
		//IL_08dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_08de: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_074d: Unknown result type (might be due to invalid IL or missing references)
		//IL_074f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0751: Unknown result type (might be due to invalid IL or missing references)
		//IL_0757: Unknown result type (might be due to invalid IL or missing references)
		//IL_075c: Unknown result type (might be due to invalid IL or missing references)
		//IL_077f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0784: Unknown result type (might be due to invalid IL or missing references)
		//IL_0789: Unknown result type (might be due to invalid IL or missing references)
		//IL_078e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0791: Unknown result type (might be due to invalid IL or missing references)
		//IL_079d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_0325: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		//IL_084f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0851: Unknown result type (might be due to invalid IL or missing references)
		//IL_0853: Unknown result type (might be due to invalid IL or missing references)
		//IL_0859: Unknown result type (might be due to invalid IL or missing references)
		//IL_085e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0864: Unknown result type (might be due to invalid IL or missing references)
		//IL_0869: Unknown result type (might be due to invalid IL or missing references)
		//IL_0886: Unknown result type (might be due to invalid IL or missing references)
		//IL_088b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0891: Unknown result type (might be due to invalid IL or missing references)
		//IL_089d: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		//IL_08bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03db: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0348: Unknown result type (might be due to invalid IL or missing references)
		//IL_035d: Unknown result type (might be due to invalid IL or missing references)
		//IL_035f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_0670: Unknown result type (might be due to invalid IL or missing references)
		//IL_0672: Unknown result type (might be due to invalid IL or missing references)
		//IL_0674: Unknown result type (might be due to invalid IL or missing references)
		//IL_067a: Unknown result type (might be due to invalid IL or missing references)
		//IL_067f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0601: Unknown result type (might be due to invalid IL or missing references)
		//IL_061c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0621: Unknown result type (might be due to invalid IL or missing references)
		//IL_0627: Unknown result type (might be due to invalid IL or missing references)
		//IL_0633: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0504: Unknown result type (might be due to invalid IL or missing references)
		//IL_050a: Unknown result type (might be due to invalid IL or missing references)
		//IL_050f: Unknown result type (might be due to invalid IL or missing references)
		//IL_053e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0543: Unknown result type (might be due to invalid IL or missing references)
		//IL_0548: Unknown result type (might be due to invalid IL or missing references)
		//IL_054d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0550: Unknown result type (might be due to invalid IL or missing references)
		//IL_055c: Unknown result type (might be due to invalid IL or missing references)
		//IL_092d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0932: Unknown result type (might be due to invalid IL or missing references)
		//IL_0938: Unknown result type (might be due to invalid IL or missing references)
		//IL_0944: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0379: Unknown result type (might be due to invalid IL or missing references)
		//IL_037e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_0652: Unknown result type (might be due to invalid IL or missing references)
		//IL_056c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_0954: Unknown result type (might be due to invalid IL or missing references)
		//IL_0950: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_0385: Unknown result type (might be due to invalid IL or missing references)
		//IL_065a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0656: Unknown result type (might be due to invalid IL or missing references)
		//IL_0573: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_058a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0593: Unknown result type (might be due to invalid IL or missing references)
		//IL_0958: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0beb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b5d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b5f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b67: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b72: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b93: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b98: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b9e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0baa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a75: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a80: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a85: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0abe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d30: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d35: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_06da: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_059f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ade: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d5d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d53: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bcd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0afe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b09: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d62: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c3b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c40: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c46: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c52: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b15: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e63: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e66: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e70: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e74: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b26: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c66: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0daf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dcb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e03: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e14: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e18: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e31: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e3f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e41: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e48: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e4c: Unknown result type (might be due to invalid IL or missing references)
		int num = who.getHair();
		float num2 = 4f * scale;
		int num3 = featureXOffsetPerFrame[currentFrame];
		int num4 = featureYOffsetPerFrame[currentFrame];
		HairStyleMetadata hairStyleMetadata = Farmer.GetHairStyleMetadata(num);
		Hat value = who.hat.Value;
		if (value != null && value.hairDrawType.Value == 1 && hairStyleMetadata != null && hairStyleMetadata.coveredIndex != -1)
		{
			num = hairStyleMetadata.coveredIndex;
			hairStyleMetadata = Farmer.GetHairStyleMetadata(num);
		}
		executeRecolorActions(who);
		who.GetDisplayShirt(out var texture, out var spriteIndex);
		Color val = (who.prismaticHair.Value ? Utility.GetPrismaticColor() : who.hairstyleColor.Value);
		shirtSourceRect = new Rectangle(spriteIndex * 8 % 128, spriteIndex * 8 / 128 * 32, 8, 8);
		Texture2D val2 = hairStyleMetadata?.texture ?? hairStylesTexture;
		hairstyleSourceRect = ((hairStyleMetadata != null) ? new Rectangle(hairStyleMetadata.tileX * 16, hairStyleMetadata.tileY * 16, 16, 32) : new Rectangle(num * 16 % hairStylesTexture.Width, num * 16 / hairStylesTexture.Width * 96, 16, 32));
		if (who.accessory.Value >= 0)
		{
			accessorySourceRect = new Rectangle(who.accessory.Value * 16 % accessoriesTexture.Width, who.accessory.Value * 16 / accessoriesTexture.Width * 32, 16, 16);
		}
		Texture2D texture2 = hatsTexture;
		bool flag = false;
		if (who.hat.Value != null)
		{
			ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(who.hat.Value.QualifiedItemId);
			int spriteIndex2 = dataOrErrorItem.SpriteIndex;
			texture2 = dataOrErrorItem.GetTexture();
			hatSourceRect = new Rectangle(20 * spriteIndex2 % texture2.Width, 20 * spriteIndex2 / texture2.Width * 20 * 4, 20, 20);
			if (dataOrErrorItem.IsErrorItem)
			{
				hatSourceRect = dataOrErrorItem.GetSourceRect();
				flag = true;
			}
		}
		FarmerSpriteLayers layer = FarmerSpriteLayers.Accessory;
		if (who.accessory.Value >= 0 && drawAccessoryBelowHair(who.accessory.Value))
		{
			layer = FarmerSpriteLayers.AccessoryUnderHair;
		}
		Rectangle value2;
		switch (facingDirection)
		{
		case 0:
			((Rectangle)(ref shirtSourceRect)).Offset(0, 24);
			((Rectangle)(ref hairstyleSourceRect)).Offset(0, 64);
			value2 = shirtSourceRect;
			((Rectangle)(ref value2)).Offset(128, 0);
			if (!flag && who.hat.Value != null)
			{
				((Rectangle)(ref hatSourceRect)).Offset(0, 60);
			}
			if (!who.bathingClothes.Value && (skin.Value != -12345 || who.shirtItem.Value != null))
			{
				Vector2 val5 = position + origin + positionOffset + new Vector2(16f * scale + (float)(num3 * 4), (float)(56 + num4 * 4) + (float)heightOffset.Value * scale);
				b.Draw(texture, val5, (Rectangle?)shirtSourceRect, ((Color)(ref overrideColor)).Equals(Color.White) ? Color.White : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Shirt));
				b.Draw(texture, val5, (Rectangle?)value2, ((Color)(ref overrideColor)).Equals(Color.White) ? Utility.MakeCompletelyOpaque(who.GetShirtColor()) : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Shirt, dyeLayer: true));
			}
			b.Draw(val2, position + origin + positionOffset + new Vector2((float)(num3 * 4), (float)(num4 * 4 + 4 + ((who.IsMale && num >= 16) ? (-4) : ((!who.IsMale && num < 16) ? 4 : 0)))), (Rectangle?)hairstyleSourceRect, ((Color)(ref overrideColor)).Equals(Color.White) ? val : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Hair));
			break;
		case 1:
			((Rectangle)(ref shirtSourceRect)).Offset(0, 8);
			((Rectangle)(ref hairstyleSourceRect)).Offset(0, 32);
			value2 = shirtSourceRect;
			((Rectangle)(ref value2)).Offset(128, 0);
			if (!flag && who.hat.Value != null)
			{
				((Rectangle)(ref hatSourceRect)).Offset(0, 20);
			}
			if (rotation != -(float)Math.PI / 32f)
			{
				if (rotation == (float)Math.PI / 32f)
				{
					rotationAdjustment.X = -6f;
					rotationAdjustment.Y = 1f;
				}
			}
			else
			{
				rotationAdjustment.X = 6f;
				rotationAdjustment.Y = -2f;
			}
			if (!who.bathingClothes.Value && (skin.Value != -12345 || who.shirtItem.Value != null))
			{
				Vector2 val6 = position + origin + positionOffset + rotationAdjustment + new Vector2(16f * scale + (float)(num3 * 4), 56f * scale + (float)(num4 * 4) + (float)heightOffset.Value * scale);
				b.Draw(texture, val6, (Rectangle?)shirtSourceRect, ((Color)(ref overrideColor)).Equals(Color.White) ? Color.White : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Shirt));
				b.Draw(texture, val6, (Rectangle?)value2, ((Color)(ref overrideColor)).Equals(Color.White) ? Utility.MakeCompletelyOpaque(who.GetShirtColor()) : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Shirt, dyeLayer: true));
			}
			if (who.accessory.Value >= 0)
			{
				((Rectangle)(ref accessorySourceRect)).Offset(0, 16);
				b.Draw(accessoriesTexture, position + origin + positionOffset + rotationAdjustment + new Vector2((float)(num3 * 4), (float)(4 + num4 * 4 + heightOffset.Value)), (Rectangle?)accessorySourceRect, (((Color)(ref overrideColor)).Equals(Color.White) && isAccessoryFacialHair(who.accessory.Value)) ? val : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, layer));
			}
			b.Draw(val2, position + origin + positionOffset + new Vector2((float)(num3 * 4), (float)(num4 * 4 + ((who.IsMale && who.hair.Value >= 16) ? (-4) : ((!who.IsMale && who.hair.Value < 16) ? 4 : 0)))), (Rectangle?)hairstyleSourceRect, ((Color)(ref overrideColor)).Equals(Color.White) ? val : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Hair));
			break;
		case 2:
			value2 = shirtSourceRect;
			((Rectangle)(ref value2)).Offset(128, 0);
			if (!who.bathingClothes.Value && (skin.Value != -12345 || who.shirtItem.Value != null))
			{
				Vector2 val4 = position + origin + positionOffset + new Vector2((float)(16 + num3 * 4), (float)(56 + num4 * 4) + (float)heightOffset.Value * scale);
				b.Draw(texture, val4, (Rectangle?)shirtSourceRect, ((Color)(ref overrideColor)).Equals(Color.White) ? Color.White : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Shirt));
				b.Draw(texture, val4, (Rectangle?)value2, ((Color)(ref overrideColor)).Equals(Color.White) ? Utility.MakeCompletelyOpaque(who.GetShirtColor()) : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Shirt, dyeLayer: true));
			}
			if (who.accessory.Value >= 0)
			{
				if (who.accessory.Value == 26)
				{
					switch (currentFrame)
					{
					case 24:
					case 25:
					case 26:
					case 70:
						positionOffset.Y += 4f;
						break;
					}
				}
				b.Draw(accessoriesTexture, position + origin + positionOffset + rotationAdjustment + new Vector2((float)(num3 * 4), (float)(8 + num4 * 4 + heightOffset.Value - 4)), (Rectangle?)accessorySourceRect, (((Color)(ref overrideColor)).Equals(Color.White) && isAccessoryFacialHair(who.accessory.Value)) ? val : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, layer));
			}
			b.Draw(val2, position + origin + positionOffset + new Vector2((float)(num3 * 4), (float)(num4 * 4 + ((who.IsMale && who.hair.Value >= 16) ? (-4) : ((!who.IsMale && who.hair.Value < 16) ? 4 : 0)))), (Rectangle?)hairstyleSourceRect, ((Color)(ref overrideColor)).Equals(Color.White) ? val : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Hair));
			break;
		case 3:
		{
			bool flag2 = true;
			((Rectangle)(ref shirtSourceRect)).Offset(0, 16);
			value2 = shirtSourceRect;
			((Rectangle)(ref value2)).Offset(128, 0);
			if (hairStyleMetadata != null && hairStyleMetadata.usesUniqueLeftSprite)
			{
				flag2 = false;
				((Rectangle)(ref hairstyleSourceRect)).Offset(0, 96);
			}
			else
			{
				((Rectangle)(ref hairstyleSourceRect)).Offset(0, 32);
			}
			if (!flag && who.hat.Value != null)
			{
				((Rectangle)(ref hatSourceRect)).Offset(0, 40);
			}
			if (rotation != -(float)Math.PI / 32f)
			{
				if (rotation == (float)Math.PI / 32f)
				{
					rotationAdjustment.X = -5f;
					rotationAdjustment.Y = 1f;
				}
			}
			else
			{
				rotationAdjustment.X = 6f;
				rotationAdjustment.Y = -2f;
			}
			if (!who.bathingClothes.Value && (skin.Value != -12345 || who.shirtItem.Value != null))
			{
				Vector2 val3 = position + origin + positionOffset + rotationAdjustment + new Vector2(16f * scale - (float)(num3 * 4), 56f * scale + (float)(num4 * 4) + (float)heightOffset.Value * scale);
				b.Draw(texture, val3, (Rectangle?)shirtSourceRect, ((Color)(ref overrideColor)).Equals(Color.White) ? Color.White : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Shirt));
				b.Draw(texture, val3, (Rectangle?)value2, ((Color)(ref overrideColor)).Equals(Color.White) ? Utility.MakeCompletelyOpaque(who.GetShirtColor()) : overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Shirt, dyeLayer: true));
			}
			if (who.accessory.Value >= 0)
			{
				((Rectangle)(ref accessorySourceRect)).Offset(0, 16);
				b.Draw(accessoriesTexture, position + origin + positionOffset + rotationAdjustment + new Vector2((float)(-num3 * 4), (float)(4 + num4 * 4 + heightOffset.Value)), (Rectangle?)accessorySourceRect, (((Color)(ref overrideColor)).Equals(Color.White) && isAccessoryFacialHair(who.accessory.Value)) ? val : overrideColor, rotation, origin, num2, (SpriteEffects)1, GetLayerDepth(layerDepth, layer));
			}
			b.Draw(val2, position + origin + positionOffset + new Vector2((float)(-num3 * 4), (float)(num4 * 4 + ((who.IsMale && who.hair.Value >= 16) ? (-4) : ((!who.IsMale && who.hair.Value < 16) ? 4 : 0)))), (Rectangle?)hairstyleSourceRect, ((Color)(ref overrideColor)).Equals(Color.White) ? val : overrideColor, rotation, origin, num2, (SpriteEffects)(flag2 ? 1 : 0), GetLayerDepth(layerDepth, FarmerSpriteLayers.Hair));
			break;
		}
		}
		if (who.hat.Value != null && !who.bathingClothes.Value)
		{
			bool flip = who.FarmerSprite.CurrentAnimationFrame.flip;
			int num5 = ((!who.hat.Value.ignoreHairstyleOffset.Value) ? hairstyleHatOffset[who.hair.Value % 16] : 0);
			Vector2 val7 = position + origin + positionOffset + new Vector2((0f - num2) * 2f + (float)(((!flip) ? 1 : (-1)) * num3) * num2, (0f - num2) * 4f + (float)(num4 * 4) + (float)num5 + 4f + (float)heightOffset.Value);
			Color val8 = (who.hat.Value.isPrismatic.Value ? Utility.GetPrismaticColor() : overrideColor);
			if (!flag && who.hat.Value.isMask && facingDirection == 0)
			{
				Rectangle value3 = hatSourceRect;
				value3.Height -= 11;
				value3.Y += 11;
				b.Draw(texture2, position + origin + positionOffset + new Vector2(0f, 11f * num2) + new Vector2((0f - num2) * 2f + (float)(((!flip) ? 1 : (-1)) * num3 * 4), (float)(-16 + num4 * 4 + num5 + 4 + heightOffset.Value)), (Rectangle?)value3, overrideColor, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Hat));
				value3 = hatSourceRect;
				value3.Height = 11;
				b.Draw(texture2, val7, (Rectangle?)value3, val8, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.HatMaskUp));
			}
			else
			{
				b.Draw(texture2, val7, (Rectangle?)hatSourceRect, val8, rotation, origin, num2, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Hat));
			}
		}
	}

	public static float GetLayerDepth(float baseLayerDepth, FarmerSpriteLayers layer, bool dyeLayer = false)
	{
		if (layer == FarmerSpriteLayers.TOOL_IN_USE_SIDE)
		{
			return baseLayerDepth + 0.0032f;
		}
		int num = ((!Game1.isUsingBackToFrontSorting) ? 1 : (-1));
		if (dyeLayer)
		{
			baseLayerDepth += 1E-07f * (float)num;
		}
		return baseLayerDepth + (float)layer * 1E-06f * (float)num;
	}

	public void draw(SpriteBatch b, FarmerSprite.AnimationFrame animationFrame, int currentFrame, Rectangle sourceRect, Vector2 position, Vector2 origin, float layerDepth, int facingDirection, Color overrideColor, float rotation, float scale, Farmer who)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_037c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_038a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0391: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_0404: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_040c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Unknown result type (might be due to invalid IL or missing references)
		//IL_041f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_0431: Unknown result type (might be due to invalid IL or missing references)
		//IL_0436: Unknown result type (might be due to invalid IL or missing references)
		//IL_042b: Unknown result type (might be due to invalid IL or missing references)
		//IL_043d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0660: Unknown result type (might be due to invalid IL or missing references)
		//IL_0662: Unknown result type (might be due to invalid IL or missing references)
		//IL_0669: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0717: Unknown result type (might be due to invalid IL or missing references)
		//IL_071c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0722: Unknown result type (might be due to invalid IL or missing references)
		//IL_0727: Unknown result type (might be due to invalid IL or missing references)
		//IL_072c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0748: Unknown result type (might be due to invalid IL or missing references)
		//IL_074d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0750: Unknown result type (might be due to invalid IL or missing references)
		//IL_075c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0806: Unknown result type (might be due to invalid IL or missing references)
		//IL_0823: Unknown result type (might be due to invalid IL or missing references)
		//IL_0830: Unknown result type (might be due to invalid IL or missing references)
		//IL_0835: Unknown result type (might be due to invalid IL or missing references)
		//IL_0847: Unknown result type (might be due to invalid IL or missing references)
		//IL_0851: Unknown result type (might be due to invalid IL or missing references)
		//IL_0865: Unknown result type (might be due to invalid IL or missing references)
		//IL_0882: Unknown result type (might be due to invalid IL or missing references)
		//IL_088e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0893: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_093c: Unknown result type (might be due to invalid IL or missing references)
		//IL_094e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0962: Unknown result type (might be due to invalid IL or missing references)
		//IL_0976: Unknown result type (might be due to invalid IL or missing references)
		//IL_0991: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b49: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b58: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b5d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b78: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b82: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b98: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c04: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c18: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c44: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c5b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c70: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c75: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c91: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ca5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_09bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_09cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_09eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a14: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a2c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a36: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ada: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b0c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b31: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_055b: Unknown result type (might be due to invalid IL or missing references)
		//IL_055d: Unknown result type (might be due to invalid IL or missing references)
		//IL_055f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0565: Unknown result type (might be due to invalid IL or missing references)
		//IL_056a: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0590: Unknown result type (might be due to invalid IL or missing references)
		//IL_0595: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05db: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0607: Unknown result type (might be due to invalid IL or missing references)
		//IL_060c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0637: Unknown result type (might be due to invalid IL or missing references)
		//IL_0641: Unknown result type (might be due to invalid IL or missing references)
		//IL_0648: Unknown result type (might be due to invalid IL or missing references)
		float num = 4f * scale;
		int num2 = featureXOffsetPerFrame[currentFrame];
		int num3 = featureYOffsetPerFrame[currentFrame];
		bool flag = currentFrame == 104 || currentFrame == 105;
		if (_sickFrame != flag)
		{
			_sickFrame = flag;
			_shirtDirty = true;
			_spriteDirty = true;
		}
		executeRecolorActions(who);
		((Vector2)(ref position))._002Ector((float)Math.Floor(position.X), (float)Math.Floor(position.Y));
		rotationAdjustment = Vector2.Zero;
		positionOffset.Y = animationFrame.positionOffset * 4;
		positionOffset.X = animationFrame.xOffset * 4;
		if (!isDrawingForUI && who.swimming.Value)
		{
			sourceRect.Height /= 2;
			sourceRect.Height -= (int)who.yOffset / 4;
			position.Y += 64f;
		}
		if (facingDirection == 3 || facingDirection == 1)
		{
			facingDirection = ((!animationFrame.flip) ? 1 : 3);
		}
		b.Draw(baseTexture, position + origin + positionOffset, (Rectangle?)sourceRect, overrideColor, rotation, origin, num, (SpriteEffects)(animationFrame.flip ? 1 : 0), GetLayerDepth(layerDepth, FarmerSpriteLayers.Base));
		if (!isDrawingForUI && who.swimming.Value)
		{
			if (who.currentEyes != 0 && who.FacingDirection != 0 && (Game1.timeOfDay < 2600 || (who.isInBed.Value && who.timeWentToBed.Value != 0)) && ((!who.FarmerSprite.PauseForSingleAnimation && !who.UsingTool) || (who.UsingTool && who.CurrentTool is FishingRod)))
			{
				Vector2 val = position + origin + positionOffset + new Vector2((float)(num2 * 4 + 20 + ((who.FacingDirection == 1) ? 12 : ((who.FacingDirection == 3) ? 4 : 0))), (float)(num3 * 4 + 40));
				b.Draw(baseTexture, val, (Rectangle?)new Rectangle(5, 16, (who.FacingDirection == 2) ? 6 : 2, 2), overrideColor, 0f, origin, num, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.FaceSkin));
				b.Draw(baseTexture, val, (Rectangle?)new Rectangle(264 + ((who.FacingDirection == 3) ? 4 : 0), 2 + (who.currentEyes - 1) * 2, (who.FacingDirection == 2) ? 6 : 2, 2), overrideColor, 0f, origin, num, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Eyes));
			}
			drawHairAndAccesories(b, facingDirection, who, position, origin, scale, currentFrame, rotation, overrideColor, layerDepth);
			b.Draw(Game1.staminaRect, new Rectangle((int)position.X + (int)who.yOffset + 8, (int)position.Y - 128 + sourceRect.Height * 4 + (int)origin.Y - (int)who.yOffset, sourceRect.Width * 4 - (int)who.yOffset * 2 - 16, 4), (Rectangle?)Game1.staminaRect.Bounds, Color.White * 0.75f, 0f, Vector2.Zero, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.SwimWaterRing));
			return;
		}
		who.GetDisplayPants(out var texture, out var spriteIndex);
		Rectangle value = default(Rectangle);
		((Rectangle)(ref value))._002Ector(sourceRect.X, sourceRect.Y, sourceRect.Width, sourceRect.Height);
		value.X += spriteIndex % 10 * 192;
		value.Y += spriteIndex / 10 * 688;
		if (!who.IsMale)
		{
			value.X += 96;
		}
		if (skin.Value != -12345 || who.pantsItem.Value != null)
		{
			b.Draw(texture, position + origin + positionOffset, (Rectangle?)value, (overrideColor == Color.White) ? Utility.MakeCompletelyOpaque(who.GetPantsColor()) : overrideColor, rotation, origin, num, (SpriteEffects)(animationFrame.flip ? 1 : 0), GetLayerDepth(layerDepth, (who.FarmerSprite.CurrentAnimationFrame.frame == 5) ? FarmerSpriteLayers.PantsPassedOut : FarmerSpriteLayers.Pants));
		}
		((Rectangle)(ref sourceRect)).Offset(288, 0);
		if (who.currentEyes != 0 && facingDirection != 0 && (Game1.timeOfDay < 2600 || (who.isInBed.Value && who.timeWentToBed.Value != 0)) && ((!who.FarmerSprite.PauseForSingleAnimation && !who.UsingTool) || (who.UsingTool && who.CurrentTool is FishingRod)) && (!who.UsingTool || !(who.CurrentTool is FishingRod { isFishing: false })))
		{
			int num4 = 5;
			num4 = (animationFrame.flip ? (num4 - num2) : (num4 + num2));
			switch (facingDirection)
			{
			case 1:
				num4 += 3;
				break;
			case 3:
				num4++;
				break;
			}
			num4 *= 4;
			b.Draw(baseTexture, position + origin + positionOffset + new Vector2((float)num4, (float)(num3 * 4 + ((who.IsMale && who.FacingDirection != 2) ? 36 : 40))), (Rectangle?)new Rectangle(5, 16, (facingDirection == 2) ? 6 : 2, 2), overrideColor, 0f, origin, num, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.FaceSkin));
			b.Draw(baseTexture, position + origin + positionOffset + new Vector2((float)num4, (float)(num3 * 4 + ((who.FacingDirection == 1 || who.FacingDirection == 3) ? 40 : 44))), (Rectangle?)new Rectangle(264 + ((facingDirection == 3) ? 4 : 0), 2 + (who.currentEyes - 1) * 2, (facingDirection == 2) ? 6 : 2, 2), overrideColor, 0f, origin, num, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Eyes));
		}
		drawHairAndAccesories(b, facingDirection, who, position, origin, scale, currentFrame, rotation, overrideColor, layerDepth);
		FarmerSpriteLayers layer = FarmerSpriteLayers.Arms;
		if (facingDirection == 0)
		{
			layer = FarmerSpriteLayers.ArmsUp;
		}
		if (animationFrame.armOffset > 0)
		{
			((Rectangle)(ref sourceRect)).Offset(-288 + animationFrame.armOffset * 16, 0);
			b.Draw(baseTexture, position + origin + positionOffset + who.armOffset, (Rectangle?)sourceRect, overrideColor, rotation, origin, num, (SpriteEffects)(animationFrame.flip ? 1 : 0), GetLayerDepth(layerDepth, layer));
		}
		if (!who.usingSlingshot || !(who.CurrentTool is Slingshot slingshot))
		{
			return;
		}
		Point val2 = Utility.Vector2ToPoint(slingshot.AdjustForHeight(Utility.PointToVector2(slingshot.aimPos.Value)));
		int x = val2.X;
		int y = val2.Y;
		int backArmDistance = slingshot.GetBackArmDistance(who);
		Vector2 shootOrigin = slingshot.GetShootOrigin(who);
		float num5 = (float)Math.Atan2((float)y - shootOrigin.Y, (float)x - shootOrigin.X) + (float)Math.PI;
		if (!Game1.options.useLegacySlingshotFiring)
		{
			num5 -= (float)Math.PI;
			if (num5 < 0f)
			{
				num5 += (float)Math.PI * 2f;
			}
		}
		switch (facingDirection)
		{
		case 0:
			b.Draw(baseTexture, position + new Vector2(4f + num5 * 8f, -44f), (Rectangle?)new Rectangle(173, 238, 9, 14), Color.White, 0f, new Vector2(4f, 11f), num, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.SlingshotUp));
			break;
		case 1:
		{
			b.Draw(baseTexture, position + new Vector2((float)(52 - backArmDistance), -32f), (Rectangle?)new Rectangle(147, 237, 10, 4), Color.White, 0f, new Vector2(8f, 3f), num, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Slingshot));
			b.Draw(baseTexture, position + new Vector2(36f, -44f), (Rectangle?)new Rectangle(156, 244, 9, 10), Color.White, num5, new Vector2(0f, 3f), num, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.SlingshotUp));
			int num6 = (int)(Math.Cos(num5 + (float)Math.PI / 2f) * (double)(20 - backArmDistance - 8) - Math.Sin(num5 + (float)Math.PI / 2f) * -68.0);
			int num7 = (int)(Math.Sin(num5 + (float)Math.PI / 2f) * (double)(20 - backArmDistance - 8) + Math.Cos(num5 + (float)Math.PI / 2f) * -68.0);
			Utility.drawLineWithScreenCoordinates((int)(position.X + 52f - (float)backArmDistance), (int)(position.Y - 32f - 4f), (int)(position.X + 32f + (float)(num6 / 2)), (int)(position.Y - 32f - 12f + (float)(num7 / 2)), b, Color.White);
			break;
		}
		case 3:
		{
			b.Draw(baseTexture, position + new Vector2((float)(40 + backArmDistance), -32f), (Rectangle?)new Rectangle(147, 237, 10, 4), Color.White, 0f, new Vector2(9f, 4f), num, (SpriteEffects)1, GetLayerDepth(layerDepth, FarmerSpriteLayers.Slingshot));
			b.Draw(baseTexture, position + new Vector2(24f, -40f), (Rectangle?)new Rectangle(156, 244, 9, 10), Color.White, num5 + (float)Math.PI, new Vector2(8f, 3f), num, (SpriteEffects)1, GetLayerDepth(layerDepth, FarmerSpriteLayers.SlingshotUp));
			int num6 = (int)(Math.Cos(num5 + (float)Math.PI * 2f / 5f) * (double)(20 + backArmDistance - 8) - Math.Sin(num5 + (float)Math.PI * 2f / 5f) * -68.0);
			int num7 = (int)(Math.Sin(num5 + (float)Math.PI * 2f / 5f) * (double)(20 + backArmDistance - 8) + Math.Cos(num5 + (float)Math.PI * 2f / 5f) * -68.0);
			Utility.drawLineWithScreenCoordinates((int)(position.X + 4f + (float)backArmDistance), (int)(position.Y - 32f - 8f), (int)(position.X + 26f + (float)num6 * 4f / 10f), (int)(position.Y - 32f - 8f + (float)num7 * 4f / 10f), b, Color.White);
			break;
		}
		case 2:
			b.Draw(baseTexture, position + new Vector2(4f, (float)(-32 - backArmDistance / 2)), (Rectangle?)new Rectangle(148, 244, 4, 4), Color.White, 0f, Vector2.Zero, num, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Arms));
			Utility.drawLineWithScreenCoordinates((int)(position.X + 16f), (int)(position.Y - 28f - (float)(backArmDistance / 2)), (int)(position.X + 44f - num5 * 10f), (int)(position.Y - 16f - 8f), b, Color.White);
			Utility.drawLineWithScreenCoordinates((int)(position.X + 16f), (int)(position.Y - 28f - (float)(backArmDistance / 2)), (int)(position.X + 56f - num5 * 10f), (int)(position.Y - 16f - 8f), b, Color.White);
			b.Draw(baseTexture, position + new Vector2(44f - num5 * 10f, -16f), (Rectangle?)new Rectangle(167, 235, 7, 9), Color.White, 0f, new Vector2(3f, 5f), num, (SpriteEffects)0, GetLayerDepth(layerDepth, FarmerSpriteLayers.Slingshot, dyeLayer: true));
			break;
		}
	}
}
