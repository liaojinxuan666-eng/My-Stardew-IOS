using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Netcode;
using Netcode.Validation;
using StardewValley.Audio;
using StardewValley.BellsAndWhistles;
using StardewValley.Buffs;
using StardewValley.Buildings;
using StardewValley.Characters;
using StardewValley.Constants;
using StardewValley.Enchantments;
using StardewValley.Extensions;
using StardewValley.GameData;
using StardewValley.GameData.Buildings;
using StardewValley.GameData.Characters;
using StardewValley.GameData.GarbageCans;
using StardewValley.GameData.LocationContexts;
using StardewValley.GameData.Locations;
using StardewValley.GameData.Minecarts;
using StardewValley.GameData.Movies;
using StardewValley.GameData.WildTrees;
using StardewValley.Internal;
using StardewValley.Inventories;
using StardewValley.ItemTypeDefinitions;
using StardewValley.Locations;
using StardewValley.Menus;
using StardewValley.Minigames;
using StardewValley.Mods;
using StardewValley.Monsters;
using StardewValley.Network;
using StardewValley.Network.NetEvents;
using StardewValley.Objects;
using StardewValley.Objects.Trinkets;
using StardewValley.Pathfinding;
using StardewValley.Projectiles;
using StardewValley.Quests;
using StardewValley.SpecialOrders;
using StardewValley.SpecialOrders.Objectives;
using StardewValley.TerrainFeatures;
using StardewValley.TokenizableStrings;
using StardewValley.Tools;
using StardewValley.Util;
using xTile;
using xTile.Dimensions;
using xTile.Layers;
using xTile.ObjectModel;
using xTile.Tiles;

namespace StardewValley;

[XmlInclude(typeof(AbandonedJojaMart))]
[XmlInclude(typeof(AdventureGuild))]
[XmlInclude(typeof(AnimalHouse))]
[XmlInclude(typeof(BathHousePool))]
[XmlInclude(typeof(Beach))]
[XmlInclude(typeof(BeachNightMarket))]
[XmlInclude(typeof(BoatTunnel))]
[XmlInclude(typeof(BugLand))]
[XmlInclude(typeof(BusStop))]
[XmlInclude(typeof(Cabin))]
[XmlInclude(typeof(Caldera))]
[XmlInclude(typeof(Cellar))]
[XmlInclude(typeof(Club))]
[XmlInclude(typeof(CommunityCenter))]
[XmlInclude(typeof(DecoratableLocation))]
[XmlInclude(typeof(Desert))]
[XmlInclude(typeof(DesertFestival))]
[XmlInclude(typeof(Farm))]
[XmlInclude(typeof(FarmCave))]
[XmlInclude(typeof(FarmHouse))]
[XmlInclude(typeof(FishShop))]
[XmlInclude(typeof(Forest))]
[XmlInclude(typeof(IslandEast))]
[XmlInclude(typeof(IslandFarmCave))]
[XmlInclude(typeof(IslandFarmHouse))]
[XmlInclude(typeof(IslandFieldOffice))]
[XmlInclude(typeof(IslandForestLocation))]
[XmlInclude(typeof(IslandHut))]
[XmlInclude(typeof(IslandLocation))]
[XmlInclude(typeof(IslandNorth))]
[XmlInclude(typeof(IslandSecret))]
[XmlInclude(typeof(IslandShrine))]
[XmlInclude(typeof(IslandSouth))]
[XmlInclude(typeof(IslandSouthEast))]
[XmlInclude(typeof(IslandSouthEastCave))]
[XmlInclude(typeof(IslandWest))]
[XmlInclude(typeof(IslandWestCave1))]
[XmlInclude(typeof(JojaMart))]
[XmlInclude(typeof(LibraryMuseum))]
[XmlInclude(typeof(ManorHouse))]
[XmlInclude(typeof(MermaidHouse))]
[XmlInclude(typeof(Mine))]
[XmlInclude(typeof(MineShaft))]
[XmlInclude(typeof(Mountain))]
[XmlInclude(typeof(MovieTheater))]
[XmlInclude(typeof(Railroad))]
[XmlInclude(typeof(SeedShop))]
[XmlInclude(typeof(Sewer))]
[XmlInclude(typeof(Shed))]
[XmlInclude(typeof(ShopLocation))]
[XmlInclude(typeof(SlimeHutch))]
[XmlInclude(typeof(Submarine))]
[XmlInclude(typeof(Summit))]
[XmlInclude(typeof(Town))]
[XmlInclude(typeof(WizardHouse))]
[XmlInclude(typeof(Woods))]
[InstanceStatics]
[NotImplicitNetField]
public class GameLocation : INetObject<NetFields>, IEquatable<GameLocation>, IAnimalLocation, IHaveModData
{
	public delegate void afterQuestionBehavior(Farmer who, string whichAnswer);

	private struct DamagePlayersEventArg : NetEventArg
	{
		public Rectangle Area;

		public int Damage;

		public bool IsBomb;

		public void Read(BinaryReader reader)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			Area = reader.ReadRectangle();
			Damage = reader.ReadInt32();
			IsBomb = reader.ReadBoolean();
		}

		public void Write(BinaryWriter writer)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			writer.WriteRectangle(Area);
			writer.Write(Damage);
			writer.Write(IsBomb);
		}
	}

	public const int maxTriesForDebrisPlacement = 3;

	public const string DefaultTileSheetId = "untitled tile sheet";

	public const string OVERRIDE_MAP_TILESHEET_PREFIX = "zzzzz";

	public const string PHONE_DIAL_SOUND = "telephone_buttonPush";

	public const int PHONE_RING_DURATION = 4950;

	public const string PHONE_PICKUP_SOUND = "bigSelect";

	public const string PHONE_HANGUP_SOUND = "openBox";

	public static readonly IList<string> OceanCrabPotFishTypes = new string[1] { "ocean" };

	public static readonly IList<string> DefaultCrabPotFishTypes = new string[1] { "freshwater" };

	[XmlIgnore]
	private Lazy<Season?> seasonOverride;

	[XmlIgnore]
	public bool? isMusicTownMusic;

	[XmlIgnore]
	public string locationContextId;

	public readonly NetCollection<Building> buildings = new NetCollection<Building>
	{
		InterpolationWait = false
	};

	[XmlElement("animals")]
	public readonly NetLongDictionary<FarmAnimal, NetRef<FarmAnimal>> animals = new NetLongDictionary<FarmAnimal, NetRef<FarmAnimal>>();

	[XmlElement("piecesOfHay")]
	public readonly NetInt piecesOfHay = new NetInt(0);

	private readonly List<KeyValuePair<long, FarmAnimal>> tempAnimals = new List<KeyValuePair<long, FarmAnimal>>();

	[XmlIgnore]
	public readonly NetString parentLocationName = new NetString();

	[XmlIgnore]
	public Building ParentBuilding;

	[XmlIgnore]
	public List<KeyValuePair<Layer, int>> backgroundLayers = new List<KeyValuePair<Layer, int>>();

	[XmlIgnore]
	public List<KeyValuePair<Layer, int>> buildingLayers = new List<KeyValuePair<Layer, int>>();

	[XmlIgnore]
	public List<KeyValuePair<Layer, int>> frontLayers = new List<KeyValuePair<Layer, int>>();

	[XmlIgnore]
	public List<KeyValuePair<Layer, int>> alwaysFrontLayers = new List<KeyValuePair<Layer, int>>();

	[NonInstancedStatic]
	[XmlIgnore]
	protected static Dictionary<string, Action<GameLocation, string[], Farmer, Vector2>> registeredTouchActions = new Dictionary<string, Action<GameLocation, string[], Farmer, Vector2>>();

	[NonInstancedStatic]
	[XmlIgnore]
	protected static Dictionary<string, Func<GameLocation, string[], Farmer, Point, bool>> registeredTileActions = new Dictionary<string, Func<GameLocation, string[], Farmer, Point, bool>>();

	[XmlIgnore]
	public NetBool isAlwaysActive = new NetBool();

	[XmlIgnore]
	public afterQuestionBehavior afterQuestion;

	[XmlIgnore]
	public Map map;

	[XmlIgnore]
	public readonly NetString mapPath = new NetString().Interpolated(interpolate: false, wait: false);

	[XmlIgnore]
	protected string loadedMapPath;

	public readonly NetCollection<NPC> characters = new NetCollection<NPC>();

	[XmlIgnore]
	public readonly NetVector2Dictionary<Object, NetRef<Object>> netObjects = new NetVector2Dictionary<Object, NetRef<Object>>();

	[XmlIgnore]
	public readonly OverlayDictionary<Vector2, Object> overlayObjects = new OverlayDictionary<Vector2, Object>(tilePositionComparer);

	[XmlElement("objects")]
	public readonly OverlaidDictionary objects;

	[XmlIgnore]
	public NetList<MapSeat, NetRef<MapSeat>> mapSeats = new NetList<MapSeat, NetRef<MapSeat>>();

	protected bool _mapSeatsDirty;

	[XmlIgnore]
	public TemporaryAnimatedSpriteList temporarySprites = new TemporaryAnimatedSpriteList();

	[XmlIgnore]
	public List<Action> postFarmEventOvernightActions = new List<Action>();

	[XmlIgnore]
	public readonly NetObjectList<Warp> warps = new NetObjectList<Warp>();

	[XmlIgnore]
	public readonly NetPointDictionary<string, NetString> doors = new NetPointDictionary<string, NetString>();

	[XmlIgnore]
	public readonly InteriorDoorDictionary interiorDoors;

	[XmlIgnore]
	public readonly FarmerCollection farmers;

	[XmlIgnore]
	public readonly NetCollection<Projectile> projectiles = new NetCollection<Projectile>();

	public readonly NetCollection<ResourceClump> resourceClumps = new NetCollection<ResourceClump>();

	public readonly NetCollection<LargeTerrainFeature> largeTerrainFeatures = new NetCollection<LargeTerrainFeature>();

	[XmlIgnore]
	public List<TerrainFeature> _activeTerrainFeatures = new List<TerrainFeature>();

	[XmlIgnore]
	public List<Critter> critters;

	[XmlElement("terrainFeatures")]
	public readonly NetVector2Dictionary<TerrainFeature, NetRef<TerrainFeature>> terrainFeatures = new NetVector2Dictionary<TerrainFeature, NetRef<TerrainFeature>>();

	[XmlIgnore]
	public readonly NetCollection<Debris> debris = new NetCollection<Debris>();

	[XmlIgnore]
	public readonly NetPoint fishSplashPoint = new NetPoint(Point.Zero);

	private int fishSplashPointTime;

	[XmlIgnore]
	public readonly NetString fishFrenzyFish = new NetString();

	[XmlIgnore]
	public readonly NetPoint orePanPoint = new NetPoint(Point.Zero);

	[XmlIgnore]
	public TemporaryAnimatedSprite fishSplashAnimation;

	[XmlIgnore]
	public TemporaryAnimatedSprite orePanAnimation;

	[XmlIgnore]
	public WaterTiles waterTiles;

	[XmlIgnore]
	protected HashSet<string> _appliedMapOverrides;

	[XmlElement("uniqueName")]
	public readonly NetString uniqueName = new NetString();

	[XmlIgnore]
	protected string _displayName;

	[XmlElement("name")]
	public readonly NetString name = new NetString();

	[XmlElement("waterColor")]
	public readonly NetColor waterColor = new NetColor(Color.White * 0.33f);

	[XmlIgnore]
	public string lastQuestionKey;

	[XmlIgnore]
	public Vector2 lastTouchActionLocation = Vector2.Zero;

	[XmlElement("lightLevel")]
	protected readonly NetFloat lightLevel = new NetFloat(0f);

	[XmlElement("isFarm")]
	public readonly NetBool isFarm = new NetBool();

	[XmlElement("isOutdoors")]
	public readonly NetBool isOutdoors = new NetBool();

	[XmlIgnore]
	public readonly NetBool isGreenhouse = new NetBool();

	[XmlElement("isStructure")]
	public readonly NetBool isStructure = new NetBool();

	[XmlElement("ignoreDebrisWeather")]
	public readonly NetBool ignoreDebrisWeather = new NetBool();

	[XmlElement("ignoreOutdoorLighting")]
	public readonly NetBool ignoreOutdoorLighting = new NetBool();

	[XmlElement("ignoreLights")]
	public readonly NetBool ignoreLights = new NetBool();

	[XmlElement("treatAsOutdoors")]
	public readonly NetBool treatAsOutdoors = new NetBool();

	[XmlIgnore]
	public bool wasUpdated;

	public int numberOfSpawnedObjectsOnMap;

	[XmlIgnore]
	public bool showDropboxIndicator;

	[XmlIgnore]
	public Vector2 dropBoxIndicatorLocation;

	[XmlElement("miniJukeboxCount")]
	public readonly NetInt miniJukeboxCount = new NetInt();

	[XmlElement("miniJukeboxTrack")]
	public readonly NetString miniJukeboxTrack = new NetString("");

	[XmlIgnore]
	public readonly NetString randomMiniJukeboxTrack = new NetString();

	[XmlIgnore]
	public Event currentEvent;

	[XmlIgnore]
	public Object actionObjectForQuestionDialogue;

	[XmlIgnore]
	public int waterAnimationIndex;

	[XmlIgnore]
	public int waterAnimationTimer;

	[XmlIgnore]
	public bool waterTileFlip;

	[XmlIgnore]
	public bool forceViewportPlayerFollow;

	[XmlIgnore]
	public bool forceLoadPathLayerLights;

	[XmlIgnore]
	public float waterPosition;

	[XmlIgnore]
	public readonly NetAudio netAudio;

	[XmlIgnore]
	public readonly NetStringDictionary<LightSource, NetRef<LightSource>> sharedLights = new NetStringDictionary<LightSource, NetRef<LightSource>>();

	private readonly NetEvent1Field<int, NetInt> removeTemporarySpritesWithIDEvent = new NetEvent1Field<int, NetInt>();

	private readonly NetEvent1Field<int, NetInt> rumbleAndFadeEvent = new NetEvent1Field<int, NetInt>();

	private readonly NetEvent1<DamagePlayersEventArg> damagePlayersEvent = new NetEvent1<DamagePlayersEventArg>();

	[XmlIgnore]
	public NetVector2HashSet lightGlows = new NetVector2HashSet();

	public static readonly int JOURNAL_INDEX = 1000;

	public static readonly float FIRST_SECRET_NOTE_CHANCE = 0.8f;

	public static readonly float LAST_SECRET_NOTE_CHANCE = 0.12f;

	public static readonly int NECKLACE_SECRET_NOTE_INDEX = 25;

	public static readonly string CAROLINES_NECKLACE_ITEM_QID = "(O)191";

	public static readonly string CAROLINES_NECKLACE_MAIL = "carolinesNecklace";

	public static TilePositionComparer tilePositionComparer = new TilePositionComparer();

	protected List<Vector2> _startingCabinLocations = new List<Vector2>();

	[XmlIgnore]
	public bool wasInhabited;

	[XmlIgnore]
	protected bool _madeMapModifications;

	public readonly NetCollection<Furniture> furniture = new NetCollection<Furniture>
	{
		InterpolationWait = false
	};

	protected readonly NetMutexQueue<Guid> furnitureToRemove = new NetMutexQueue<Guid>();

	protected bool _mapPathDirty = true;

	protected LocalizedContentManager _structureMapLoader;

	protected bool ignoreWarps;

	protected HashSet<Vector2> _visitedCollisionTiles = new HashSet<Vector2>();

	protected bool _looserBuildRestrictions;

	protected Rectangle? _buildableTileRect;

	private bool showedBuildableButNotAlwaysActiveWarning;

	public static bool PlayedNewLocationContextMusic = false;

	private const int fireIDBase = 944468;

	protected Color indoorLightingColor = new Color(100, 120, 30);

	protected Color indoorLightingNightColor = new Color(150, 150, 30);

	protected static List<KeyValuePair<string, string>> _PagedResponses = new List<KeyValuePair<string, string>>();

	protected static int _PagedResponsePage = 0;

	protected static int _PagedResponseItemsPerPage;

	public static bool _PagedResponseAddCancel;

	protected static string _PagedResponsePrompt;

	protected static Action<string> _OnPagedResponse;

	protected string _constructLocationBuilderName;

	protected List<Farmer> _currentLocationFarmersForDisambiguating = new List<Farmer>();

	[XmlIgnore]
	public Dictionary<Vector2, float> lightGlowLayerCache = new Dictionary<Vector2, float>();

	public NetLongDictionary<FarmAnimal, NetRef<FarmAnimal>> Animals => animals;

	[XmlIgnore]
	public NetFields NetFields { get; }

	[XmlIgnore]
	public NetRoot<GameLocation> Root => NetFields.Root as NetRoot<GameLocation>;

	[XmlIgnore]
	public int ExtraMillisecondsPerInGameMinute { get; set; }

	[XmlIgnore]
	public string DisplayName
	{
		get
		{
			if (_displayName == null)
			{
				_displayName = GetDisplayName();
			}
			if (_displayName == null)
			{
				string text = GetParentLocation()?.DisplayName;
				if (text != null)
				{
					return text;
				}
				return Name;
			}
			return _displayName;
		}
		set
		{
			_displayName = value;
		}
	}

	[XmlIgnore]
	public string NameOrUniqueName
	{
		get
		{
			if (uniqueName.Value != null)
			{
				return uniqueName.Value;
			}
			return name.Value;
		}
	}

	[XmlIgnore]
	public bool IsTemporary { get; protected set; }

	[XmlIgnore]
	public float LightLevel
	{
		get
		{
			return lightLevel.Value;
		}
		set
		{
			lightLevel.Value = value;
		}
	}

	[XmlIgnore]
	public Map Map
	{
		get
		{
			updateMap();
			return map;
		}
		set
		{
			map = value;
		}
	}

	[XmlIgnore]
	public OverlaidDictionary Objects => objects;

	[XmlIgnore]
	public TemporaryAnimatedSpriteList TemporarySprites => temporarySprites;

	public string Name => name.Value;

	[XmlIgnore]
	public bool IsFarm
	{
		get
		{
			return isFarm.Value;
		}
		set
		{
			isFarm.Value = value;
		}
	}

	[XmlIgnore]
	public bool IsOutdoors
	{
		get
		{
			return isOutdoors.Value;
		}
		set
		{
			isOutdoors.Value = value;
		}
	}

	public bool IsGreenhouse
	{
		get
		{
			return isGreenhouse.Value;
		}
		set
		{
			isGreenhouse.Value = value;
		}
	}

	[XmlIgnore]
	public ModDataDictionary modData { get; } = new ModDataDictionary();

	[XmlElement("modData")]
	public ModDataDictionary modDataForSerialization
	{
		get
		{
			return modData.GetForSerialization();
		}
		set
		{
			modData.SetFromSerialization(value);
		}
	}

	public virtual string GetDisplayName()
	{
		string text = GetData()?.DisplayName;
		if (text == null)
		{
			return null;
		}
		return TokenParser.ParseText(text);
	}

	public virtual bool SeedsIgnoreSeasonsHere()
	{
		return IsGreenhouse;
	}

	public virtual bool CanPlantSeedsHere(string itemId, int tileX, int tileY, bool isGardenPot, out string deniedMessage)
	{
		return CheckItemPlantRules(itemId, isGardenPot, GetData()?.CanPlantHere ?? IsFarm, out deniedMessage);
	}

	public virtual bool CanPlantTreesHere(string itemId, int tileX, int tileY, out string deniedMessage)
	{
		int defaultAllowed;
		if (!IsGreenhouse && !IsFarm && !(GetData()?.CanPlantHere ?? false) && (!Object.isWildTreeSeed(itemId) || !IsOutdoors || !(doesTileHavePropertyNoNull(tileX, tileY, "Type", "Back") == "Dirt")))
		{
			Map obj = map;
			defaultAllowed = ((((obj != null) ? new bool?(((IDictionary<string, PropertyValue>)((Component)obj).Properties).ContainsKey("ForceAllowTreePlanting")) : ((bool?)null)) ?? false) ? 1 : 0);
		}
		else
		{
			defaultAllowed = 1;
		}
		return CheckItemPlantRules(itemId, isGardenPot: false, (byte)defaultAllowed != 0, out deniedMessage);
	}

	public bool CheckItemPlantRules(string itemId, bool isGardenPot, bool defaultAllowed, out string deniedMessage)
	{
		ItemMetadata metadata = ItemRegistry.GetMetadata(itemId);
		if (metadata != null && metadata.TypeIdentifier == "(O)")
		{
			itemId = metadata.LocalItemId;
			if (Crop.TryGetData(itemId, out var data))
			{
				return CheckItemPlantRules(data.PlantableLocationRules, isGardenPot, defaultAllowed, out deniedMessage);
			}
			string text = Tree.ResolveTreeTypeFromSeed(metadata.QualifiedItemId);
			if (text != null && Tree.TryGetData(text, out var data2))
			{
				return CheckItemPlantRules(data2.PlantableLocationRules, isGardenPot, defaultAllowed, out deniedMessage);
			}
			if (FruitTree.TryGetData(itemId, out var data3))
			{
				return CheckItemPlantRules(data3.PlantableLocationRules, isGardenPot, defaultAllowed, out deniedMessage);
			}
		}
		deniedMessage = null;
		return defaultAllowed;
	}

	private bool CheckItemPlantRules(List<PlantableRule> rules, bool isGardenPot, bool defaultAllowed, out string deniedMessage)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Invalid comparison between Unknown and I4
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Invalid comparison between Unknown and I4
		if (rules != null && rules.Count > 0)
		{
			foreach (PlantableRule rule in rules)
			{
				if (rule.ShouldApplyWhen(isGardenPot) && GameStateQuery.CheckConditions(rule.Condition, this))
				{
					PlantableResult result = rule.Result;
					if ((int)result != 1)
					{
						if ((int)result == 2)
						{
							deniedMessage = TokenParser.ParseText(rule.DeniedMessage);
							return false;
						}
						deniedMessage = ((!defaultAllowed) ? TokenParser.ParseText(rule.DeniedMessage) : null);
						return defaultAllowed;
					}
					deniedMessage = null;
					return true;
				}
			}
		}
		deniedMessage = null;
		return defaultAllowed;
	}

	protected virtual void initNetFields()
	{
		NetFields.SetOwner(this).AddField(mapPath, "mapPath").AddField(uniqueName, "uniqueName")
			.AddField(name, "name")
			.AddField(lightLevel, "lightLevel")
			.AddField(sharedLights, "sharedLights")
			.AddField(isFarm, "isFarm")
			.AddField(isOutdoors, "isOutdoors")
			.AddField(isStructure, "isStructure")
			.AddField(ignoreDebrisWeather, "ignoreDebrisWeather")
			.AddField(ignoreOutdoorLighting, "ignoreOutdoorLighting")
			.AddField(ignoreLights, "ignoreLights")
			.AddField(treatAsOutdoors, "treatAsOutdoors")
			.AddField(warps, "warps")
			.AddField(doors, "doors")
			.AddField(interiorDoors, "interiorDoors")
			.AddField(waterColor, "waterColor")
			.AddField(netObjects, "netObjects")
			.AddField(projectiles, "projectiles")
			.AddField(largeTerrainFeatures, "largeTerrainFeatures")
			.AddField(terrainFeatures, "terrainFeatures")
			.AddField(characters, "characters")
			.AddField(debris, "debris")
			.AddField(netAudio.NetFields, "netAudio.NetFields")
			.AddField(removeTemporarySpritesWithIDEvent, "removeTemporarySpritesWithIDEvent")
			.AddField(rumbleAndFadeEvent, "rumbleAndFadeEvent")
			.AddField(damagePlayersEvent, "damagePlayersEvent")
			.AddField(lightGlows, "lightGlows")
			.AddField(fishSplashPoint, "fishSplashPoint")
			.AddField(fishFrenzyFish, "fishFrenzyFish")
			.AddField(orePanPoint, "orePanPoint")
			.AddField(isGreenhouse, "isGreenhouse")
			.AddField(miniJukeboxCount, "miniJukeboxCount")
			.AddField(miniJukeboxTrack, "miniJukeboxTrack")
			.AddField(randomMiniJukeboxTrack, "randomMiniJukeboxTrack")
			.AddField(resourceClumps, "resourceClumps")
			.AddField(isAlwaysActive, "isAlwaysActive")
			.AddField(furniture, "furniture")
			.AddField(furnitureToRemove.NetFields, "furnitureToRemove.NetFields")
			.AddField(parentLocationName, "parentLocationName")
			.AddField(buildings, "buildings")
			.AddField(animals, "animals")
			.AddField(piecesOfHay, "piecesOfHay")
			.AddField(mapSeats, "mapSeats")
			.AddField(modData, "modData");
		mapPath.fieldChangeVisibleEvent += delegate
		{
			_mapPathDirty = true;
		};
		name.fieldChangeVisibleEvent += delegate
		{
			OnNameChanged();
		};
		uniqueName.fieldChangeVisibleEvent += delegate
		{
			OnNameChanged();
		};
		parentLocationName.fieldChangeVisibleEvent += delegate
		{
			OnParentLocationChanged();
		};
		buildings.OnValueAdded += delegate(Building b)
		{
			if (b != null)
			{
				b.parentLocationName.Value = NameOrUniqueName;
				b.updateInteriorWarps();
			}
			if (Game1.IsMasterGame)
			{
				Game1.netWorldState.Value.UpdateBuildingCache(this);
			}
		};
		buildings.OnValueRemoved += delegate(Building b)
		{
			if (b != null)
			{
				b.parentLocationName.Value = null;
			}
			if (Game1.IsMasterGame)
			{
				Game1.netWorldState.Value.UpdateBuildingCache(this);
			}
		};
		isStructure.fieldChangeVisibleEvent += delegate
		{
			if (mapPath.Value != null)
			{
				InvalidateCachedMultiplayerMap(Game1.multiplayer.cachedMultiplayerMaps);
				reloadMap();
			}
		};
		sharedLights.OnValueAdded += delegate(string identifier, LightSource light)
		{
			if (Game1.currentLocation == this)
			{
				Game1.currentLightSources.Add(light);
			}
		};
		sharedLights.OnValueRemoved += delegate(string identifier, LightSource light)
		{
			if (Game1.currentLocation == this)
			{
				Game1.currentLightSources.Remove(light?.Id);
			}
		};
		netObjects.OnConflictResolve += delegate(Vector2 pos, NetRef<Object> rejected, NetRef<Object> accepted)
		{
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			if (Game1.IsMasterGame)
			{
				Object value = rejected.Value;
				if (value != null)
				{
					value.onDetachedFromParent();
					value.dropItem(this, pos * 64f, pos * 64f);
				}
			}
		};
		netObjects.OnValueAdded += OnObjectAdded;
		overlayObjects.onValueAdded += OnObjectAdded;
		removeTemporarySpritesWithIDEvent.onEvent += removeTemporarySpritesWithIDLocal;
		rumbleAndFadeEvent.onEvent += performRumbleAndFade;
		damagePlayersEvent.onEvent += performDamagePlayers;
		fishSplashPoint.fieldChangeVisibleEvent += delegate
		{
			updateFishSplashAnimation();
		};
		orePanPoint.fieldChangeVisibleEvent += delegate
		{
			updateOrePanAnimation();
		};
		characters.OnValueRemoved += delegate(NPC npc)
		{
			npc.Removed();
		};
		terrainFeatures.OnValueAdded += delegate(Vector2 tile, TerrainFeature feature)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			OnTerrainFeatureAdded(feature, tile);
		};
		terrainFeatures.OnValueRemoved += delegate(Vector2 tile, TerrainFeature feature)
		{
			OnTerrainFeatureRemoved(feature);
		};
		largeTerrainFeatures.OnValueAdded += delegate(LargeTerrainFeature feature)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			OnTerrainFeatureAdded(feature, feature.Tile);
		};
		largeTerrainFeatures.OnValueRemoved += OnTerrainFeatureRemoved;
		resourceClumps.OnValueAdded += OnResourceClumpAdded;
		resourceClumps.OnValueRemoved += OnResourceClumpRemoved;
		furniture.OnValueAdded += delegate(Furniture f)
		{
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			f.Location = this;
			f.OnAdded(this, f.TileLocation);
		};
		furniture.OnValueRemoved += delegate(Furniture f)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			f.OnRemoved(this, f.TileLocation);
		};
		furnitureToRemove.Processor = removeQueuedFurniture;
	}

	public virtual void InvalidateCachedMultiplayerMap(Dictionary<string, CachedMultiplayerMap> cached_data)
	{
		if (!Game1.IsMasterGame)
		{
			cached_data.Remove(NameOrUniqueName);
		}
	}

	public virtual void MakeMapModifications(bool force = false)
	{
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_0619: Unknown result type (might be due to invalid IL or missing references)
		//IL_063d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0647: Unknown result type (might be due to invalid IL or missing references)
		//IL_0679: Unknown result type (might be due to invalid IL or missing references)
		//IL_0683: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04be: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e1: Expected O, but got Unknown
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0270: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d24: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d33: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d5d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c89: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c98: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cbc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ced: Unknown result type (might be due to invalid IL or missing references)
		//IL_0890: Unknown result type (might be due to invalid IL or missing references)
		//IL_077c: Unknown result type (might be due to invalid IL or missing references)
		//IL_078b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b95: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0baf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0910: Unknown result type (might be due to invalid IL or missing references)
		//IL_08bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_08cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0990: Unknown result type (might be due to invalid IL or missing references)
		//IL_093c: Unknown result type (might be due to invalid IL or missing references)
		//IL_094b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0955: Unknown result type (might be due to invalid IL or missing references)
		//IL_0960: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a10: Unknown result type (might be due to invalid IL or missing references)
		//IL_09bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_09cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a9a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a4b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a55: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a60: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ad5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0adf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af4: Unknown result type (might be due to invalid IL or missing references)
		if (force)
		{
			_appliedMapOverrides.Clear();
		}
		interiorDoors.MakeMapModifications();
		string value = name.Value;
		if (value == null)
		{
			return;
		}
		switch (value.Length)
		{
		case 10:
			switch (value[0])
			{
			case 'W':
				if (value == "WitchSwamp")
				{
					if (Game1.MasterPlayer.mailReceived.Contains("henchmanGone"))
					{
						removeTile(20, 29, "Buildings");
					}
					else
					{
						setMapTile(20, 29, 10, "Buildings", "wt");
					}
				}
				break;
			case 'H':
				if (value == "HaleyHouse" && Game1.player.eventsSeen.Contains("463391") && Game1.player.spouse != "Emily")
				{
					setMapTile(14, 4, 2173, "Buildings", "1");
					setMapTile(14, 3, 2141, "Buildings", "1");
					setMapTile(14, 3, 219, "Back", "1");
				}
				break;
			}
			break;
		case 9:
			switch (value[0])
			{
			case 'B':
				if (!(value == "Backwoods"))
				{
					break;
				}
				if (Game1.netWorldState.Value.hasWorldStateID("golemGrave"))
				{
					ApplyMapOverride("Backwoods_GraveSite");
				}
				if (Game1.MasterPlayer.mailReceived.Contains("communityUpgradeShortcuts") && !_appliedMapOverrides.Contains("Backwoods_Staircase"))
				{
					ApplyMapOverride("Backwoods_Staircase");
					LargeTerrainFeature largeTerrainFeature = null;
					foreach (LargeTerrainFeature largeTerrainFeature2 in largeTerrainFeatures)
					{
						if (largeTerrainFeature2.Tile == new Vector2(37f, 16f))
						{
							largeTerrainFeature = largeTerrainFeature2;
							break;
						}
					}
					if (largeTerrainFeature != null)
					{
						largeTerrainFeatures.Remove(largeTerrainFeature);
					}
				}
				if (!Game1.player.mailReceived.Contains("asdlkjfg1") || Game1.random.NextDouble() < 0.01)
				{
					setTileProperty(13, 29, "Back", "TouchAction", "asdlfkjg");
					setTileProperty(14, 29, "Back", "TouchAction", "asdlfkjg");
					setTileProperty(15, 29, "Back", "TouchAction", "asdlfkjg");
				}
				else if (Utility.doesAnyFarmerHaveMail("asdlkjfg1") && Utility.CreateDaySaveRandom(1244.0).NextDouble() < 0.02)
				{
					if (!IsTileOccupiedBy(new Vector2(13f, 26f)))
					{
						temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors_1_6", new Rectangle(495, 412, 16, 16), new Vector2(13f, 26f) * 64f, flipped: false, 0.003f, Color.White)
						{
							scale = 4f,
							layerDepth = 0f
						});
					}
					if (!IsTileOccupiedBy(new Vector2(12f, 25f)))
					{
						temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors_1_6", new Rectangle(495, 412, 16, 16), new Vector2(12f, 25f) * 64f, flipped: true, 0.003f, Color.White)
						{
							scale = 4f,
							layerDepth = 0f
						});
					}
					if (!IsTileOccupiedBy(new Vector2(13f, 24f)))
					{
						temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors_1_6", new Rectangle(495, 412, 16, 16), new Vector2(13f, 24f) * 64f, flipped: false, 0.003f, Color.White)
						{
							scale = 4f,
							layerDepth = 0f
						});
					}
					if (!IsTileOccupiedBy(new Vector2(13f, 23f)))
					{
						temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors_1_6", new Rectangle(495, 412, 16, 16), new Vector2(12f, 23f) * 64f, flipped: true, 0.003f, Color.White * 0.66f)
						{
							scale = 4f,
							layerDepth = 0f
						});
					}
					if (!IsTileOccupiedBy(new Vector2(13f, 22f)))
					{
						temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors_1_6", new Rectangle(495, 412, 16, 16), new Vector2(13f, 22f) * 64f, flipped: false, 0.003f, Color.White * 0.33f)
						{
							scale = 4f,
							layerDepth = 0f
						});
					}
				}
				if (Game1.timeOfDay >= 2400)
				{
					Random random = Utility.CreateDaySaveRandom(124.0);
					int num = Utility.ModifyTime(2400, random.Next(12) * 10);
					if (Game1.timeOfDay == num && random.NextDouble() < 0.33)
					{
						temporarySprites.Add(new TemporaryAnimatedSprite("Characters\\asldkfjsquaskutanfsldk", new Rectangle(0, 48, 32, 48), new Vector2(60f, -260f), flipped: true, 0f, Color.White)
						{
							animationLength = 8,
							totalNumberOfLoops = 99,
							interval = 120f,
							scale = 4f,
							motion = new Vector2(0.5f, 1f),
							yStopCoordinate = 256,
							xStopCoordinate = 256,
							delayBeforeAnimationStart = 1000
						});
					}
				}
				break;
			case 'S':
				if (value == "SkullCave")
				{
					bool flag = Game1.player.team.skullShrineActivated.Value || Game1.player.team.SpecialOrderRuleActive("SC_HARD");
					if (Game1.player.team.toggleSkullShrineOvernight.Value)
					{
						flag = !flag;
					}
					if (flag)
					{
						_appliedMapOverrides.Remove("SkullCaveAltarDeactivated");
						ApplyMapOverride("SkullCaveAltar", (Rectangle?)new Rectangle(0, 0, 5, 4), (Rectangle?)new Rectangle(10, 1, 5, 4));
						Game1.currentLightSources.Add(new LightSource("SkullCaveAltar", 4, new Vector2(12f, 3f) * 64f, 1f, LightSource.LightContext.MapLight, 0L, NameOrUniqueName));
						AmbientLocationSounds.addSound(new Vector2(12f, 3f), 1);
					}
					else
					{
						_appliedMapOverrides.Remove("SkullCaveAltar");
						ApplyMapOverride(Game1.temporaryContent.Load<Map>("Maps\\SkullCave"), "SkullCaveAltarDeactivated", (Rectangle?)new Rectangle(10, 1, 5, 4), (Rectangle?)new Rectangle(10, 1, 5, 4), (Action<Point>)null);
						Game1.currentLightSources.Remove("SkullCaveAltar");
						AmbientLocationSounds.removeSound(new Vector2(12f, 3f));
					}
				}
				break;
			}
			break;
		case 16:
			if (value == "IslandNorthCave1" && Game1.player.mailReceived.Contains("FizzIntro"))
			{
				if (getCharacterFromName("Fizz") == null)
				{
					characters.Add(new NPC(new AnimatedSprite("Characters\\Fizz", 0, 16, 32), new Vector2(6f, 3f) * 64f, 2, "Fizz")
					{
						SimpleNonVillagerNPC = true,
						Portrait = Game1.content.Load<Texture2D>("Portraits\\Fizz"),
						displayName = Game1.content.LoadString("Strings\\NPCNames:Fizz")
					});
					removeObjectsAndSpawned(6, 3, 1, 1);
				}
				else
				{
					getCharacterFromName("Fizz").SimpleNonVillagerNPC = true;
					getCharacterFromName("Fizz").Sprite.SpriteHeight = 32;
					getCharacterFromName("Fizz").Sprite.UpdateSourceRect();
				}
				Game1.currentLightSources.Add(new LightSource("IslandNorthCave1", 1, new Vector2(6f, 3f) * 64f + new Vector2(32f), 2f, LightSource.LightContext.None, 0L, NameOrUniqueName));
			}
			break;
		case 11:
			if (value == "MasteryCave")
			{
				Game1.stats.Get("MasteryExp");
				int currentMasteryLevel = MasteryTrackerMenu.getCurrentMasteryLevel();
				int levelsNotSpent = currentMasteryLevel - (int)Game1.stats.Get("masteryLevelsSpent");
				ShowSkillMastery(4, new Vector2(54f, 98f));
				ShowSkillMastery(2, new Vector2(84f, 82f));
				ShowSkillMastery(0, new Vector2(116f, 82f));
				ShowSkillMastery(0, new Vector2(116f, 82f));
				ShowSkillMastery(1, new Vector2(148f, 82f));
				ShowSkillMastery(3, new Vector2(179f, 98f));
				if (MasteryTrackerMenu.hasCompletedAllMasteryPlaques())
				{
					MasteryTrackerMenu.addSpiritCandles(instant: true);
					Game1.changeMusicTrack("grandpas_theme", track_interruptable: false, (MusicContext)0);
				}
			}
			break;
		case 19:
			if (value == "WizardHouseBasement" && Game1.player.mailReceived.Contains("hasActivatedForestPylon"))
			{
				temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\terraria_cat", new Rectangle(0, 106, 14, 22), new Vector2(16.6f, 2.5f) * 64f, flipped: false, 0f, Color.White)
				{
					animationLength = 8,
					interval = 100f,
					totalNumberOfLoops = 9999,
					scale = 4f
				});
			}
			break;
		case 7:
			if (value == "Sunroom")
			{
				TileSheet obj = map.RequireTileSheet(1, "2");
				string text = Path.GetDirectoryName(obj.ImageSource);
				if (string.IsNullOrWhiteSpace(text))
				{
					text = "Maps";
				}
				obj.ImageSource = Path.Combine(text, "CarolineGreenhouseTiles" + ((IsRainingHere() || Game1.timeOfDay > Game1.getTrulyDarkTime(this)) ? "_rainy" : ""));
				map.DisposeTileSheets(Game1.mapDisplayDevice);
				map.LoadTileSheets(Game1.mapDisplayDevice);
			}
			break;
		case 17:
			if (value == "AbandonedJojaMart")
			{
				if (!Game1.MasterPlayer.hasOrWillReceiveMail("ccMovieTheater"))
				{
					StaticTile[] junimoNoteTileFrames = CommunityCenter.getJunimoNoteTileFrames(0, map);
					string layerId = "Buildings";
					Point val = default(Point);
					((Point)(ref val))._002Ector(8, 8);
					map.RequireLayer(layerId).Tiles[val.X, val.Y] = (Tile)new AnimatedTile(map.RequireLayer(layerId), junimoNoteTileFrames, 70L);
				}
				else
				{
					removeTile(8, 8, "Buildings");
				}
			}
			break;
		case 8:
			if (value == "WitchHut" && Game1.player.mailReceived.Contains("hasPickedUpMagicInk"))
			{
				((IDictionary<string, PropertyValue>)((Component)setMapTile(4, 11, 113, "Buildings", "untitled tile sheet")).Properties).Remove("Action");
			}
			break;
		case 6:
			if (value == "Saloon" && NetWorldState.checkAnywhereForWorldStateID("saloonSportsRoom"))
			{
				ApplyMapOverride("RefurbishedSaloonRoom", (Rectangle?)null, (Rectangle?)new Rectangle(32, 1, 6, 8));
				Game1.currentLightSources.Add(new LightSource("Saloon_1", 1, new Vector2(33f, 7f) * 64f, 4f, LightSource.LightContext.None, 0L, NameOrUniqueName));
				Game1.currentLightSources.Add(new LightSource("Saloon_2", 1, new Vector2(36f, 7f) * 64f, 4f, LightSource.LightContext.None, 0L, NameOrUniqueName));
				Game1.currentLightSources.Add(new LightSource("Saloon_3", 1, new Vector2(34f, 5f) * 64f, 4f, LightSource.LightContext.None, 0L, NameOrUniqueName));
			}
			break;
		case 12:
		case 13:
		case 14:
		case 15:
		case 18:
			break;
		}
	}

	public virtual bool ApplyCachedMultiplayerMap(Dictionary<string, CachedMultiplayerMap> cached_data, string requested_map_path)
	{
		if (Game1.IsMasterGame)
		{
			return false;
		}
		if (cached_data.TryGetValue(NameOrUniqueName, out var value))
		{
			if (value.mapPath == requested_map_path)
			{
				_appliedMapOverrides = value.appliedMapOverrides;
				map = value.map;
				loadedMapPath = value.loadedMapPath;
				return true;
			}
			cached_data.Remove(NameOrUniqueName);
			return false;
		}
		return false;
	}

	public virtual void StoreCachedMultiplayerMap(Dictionary<string, CachedMultiplayerMap> cached_data)
	{
		if (!Game1.IsMasterGame && !(this is VolcanoDungeon) && !(this is MineShaft))
		{
			CachedMultiplayerMap cachedMultiplayerMap = new CachedMultiplayerMap();
			cachedMultiplayerMap.map = map;
			cachedMultiplayerMap.appliedMapOverrides = _appliedMapOverrides;
			cachedMultiplayerMap.mapPath = mapPath.Value;
			cachedMultiplayerMap.loadedMapPath = loadedMapPath;
			cached_data[NameOrUniqueName] = cachedMultiplayerMap;
		}
	}

	public virtual void TransferDataFromSavedLocation(GameLocation l)
	{
		modData.Clear();
		if (l.modData != null)
		{
			foreach (string key in l.modData.Keys)
			{
				modData[key] = l.modData[key];
			}
		}
		miniJukeboxCount.Value = l.miniJukeboxCount.Value;
		miniJukeboxTrack.Value = l.miniJukeboxTrack.Value;
		SelectRandomMiniJukeboxTrack();
		UpdateMapSeats();
	}

	private void OnNameChanged()
	{
		IsTemporary = IsTemporaryName(Name);
	}

	private void OnParentLocationChanged()
	{
		locationContextId = null;
		if (seasonOverride == null || seasonOverride.IsValueCreated)
		{
			seasonOverride = new Lazy<Season?>(LoadSeasonOverride);
		}
	}

	public virtual void OnParentBuildingUpgraded(Building building)
	{
	}

	public virtual void OnRemoved()
	{
		for (int num = characters.Count - 1; num >= 0; num--)
		{
			characters[num].OnLocationRemoved();
		}
	}

	protected virtual void OnObjectAdded(Vector2 tile, Object obj)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		obj.Location = this;
		obj.TileLocation = tile;
	}

	public virtual void OnResourceClumpAdded(ResourceClump resourceClump)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		resourceClump.Location = this;
		resourceClump.OnAddedToLocation(this, resourceClump.Tile);
	}

	public virtual void OnResourceClumpRemoved(ResourceClump resourceClump)
	{
		resourceClump.Location = null;
	}

	public virtual void OnTerrainFeatureAdded(TerrainFeature feature, Vector2 location)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (feature == null)
		{
			return;
		}
		if (!(feature is Flooring flooring))
		{
			if (feature is HoeDirt hoeDirt)
			{
				hoeDirt.OnAdded(this, location);
			}
		}
		else
		{
			flooring.OnAdded(this, location);
		}
		feature.Location = this;
		feature.Tile = location;
		feature.OnAddedToLocation(this, location);
		UpdateTerrainFeatureUpdateSubscription(feature);
	}

	public virtual void OnTerrainFeatureRemoved(TerrainFeature feature)
	{
		if (feature == null)
		{
			return;
		}
		if (!(feature is Flooring flooring))
		{
			if (!(feature is HoeDirt hoeDirt))
			{
				if (feature is LargeTerrainFeature largeTerrainFeature)
				{
					largeTerrainFeature.onDestroy();
				}
			}
			else
			{
				hoeDirt.OnRemoved();
			}
		}
		else
		{
			flooring.OnRemoved();
		}
		if (feature.NeedsUpdate)
		{
			_activeTerrainFeatures.Remove(feature);
		}
		feature.Location = null;
	}

	public virtual void UpdateTerrainFeatureUpdateSubscription(TerrainFeature feature)
	{
		if (feature.NeedsUpdate)
		{
			_activeTerrainFeatures.Add(feature);
		}
		else
		{
			_activeTerrainFeatures.Remove(feature);
		}
	}

	public int GetSeasonIndex()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Expected I4, but got Unknown
		return (int)GetSeason();
	}

	private Season? LoadSeasonOverride()
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		if (map == null && mapPath.Value != null)
		{
			reloadMap();
		}
		if (map != null && ((Component)map).Properties.TryGetValue("SeasonOverride", out var value) && !string.IsNullOrWhiteSpace(value))
		{
			if (Utility.TryParseEnum<Season>(value, out Season parsed))
			{
				return parsed;
			}
			Game1.log.Error($"Unable to read SeasonOverride map property value '{value}' for location '{NameOrUniqueName}', not a valid season name.");
		}
		return GetLocationContext()?.SeasonOverride;
	}

	public Season GetSeason()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		return (Season)(((_003F?)seasonOverride.Value) ?? GetParentLocation()?.GetSeason() ?? Game1.season);
	}

	public string GetSeasonKey()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return Utility.getSeasonKey(GetSeason());
	}

	public bool IsSpringHere()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		return (int)GetSeason() == 0;
	}

	public bool IsSummerHere()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		return (int)GetSeason() == 1;
	}

	public bool IsFallHere()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		return (int)GetSeason() == 2;
	}

	public bool IsWinterHere()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		return (int)GetSeason() == 3;
	}

	public LocationWeather GetWeather()
	{
		return Game1.netWorldState.Value.GetWeatherForLocation(GetLocationContextId());
	}

	public bool IsRainingHere()
	{
		return GetWeather().IsRaining;
	}

	public bool IsGreenRainingHere()
	{
		if (IsRainingHere())
		{
			return GetWeather().IsGreenRain;
		}
		return false;
	}

	public bool IsLightningHere()
	{
		return GetWeather().IsLightning;
	}

	public bool IsSnowingHere()
	{
		return GetWeather().IsSnowing;
	}

	public bool IsDebrisWeatherHere()
	{
		return GetWeather().IsDebrisWeather;
	}

	public static bool IsTemporaryName(string name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return false;
		}
		if (!name.StartsWith("Temp", StringComparison.Ordinal) && !(name == "fishingGame"))
		{
			return name == "tent";
		}
		return true;
	}

	private void updateFishSplashAnimation()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		if (fishSplashPoint.Value == Point.Zero)
		{
			fishSplashAnimation = null;
			return;
		}
		fishSplashAnimation = new TemporaryAnimatedSprite(51, new Vector2((float)(fishSplashPoint.X * 64), (float)(fishSplashPoint.Y * 64)), Color.White, 10, flipped: false, 80f, 999999)
		{
			layerDepth = (float)(fishSplashPoint.Y * 64 - 64 - 1) / 10000f
		};
	}

	private void updateOrePanAnimation()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		if (orePanPoint.Value == Point.Zero)
		{
			orePanAnimation = null;
			return;
		}
		orePanAnimation = new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(432, 1435, 16, 16), new Vector2((float)(orePanPoint.X * 64 + 32), (float)(orePanPoint.Y * 64 + 32)), flipped: false, 0f, Color.White)
		{
			totalNumberOfLoops = 9999999,
			interval = 100f,
			scale = 3f,
			animationLength = 6
		};
	}

	public GameLocation()
	{
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		NetFields = new NetFields(NetFields.GetNameForInstance(this));
		farmers = new FarmerCollection(this);
		interiorDoors = new InteriorDoorDictionary(this);
		netAudio = new NetAudio(this);
		objects = new OverlaidDictionary(netObjects, overlayObjects);
		_appliedMapOverrides = new HashSet<string>();
		terrainFeatures.SetEqualityComparer(tilePositionComparer);
		netObjects.SetEqualityComparer(tilePositionComparer);
		objects.SetEqualityComparer(tilePositionComparer, ref netObjects, ref overlayObjects);
		seasonOverride = new Lazy<Season?>(LoadSeasonOverride);
		initNetFields();
	}

	public GameLocation(string mapPath, string name)
		: this()
	{
		this.mapPath.Set(mapPath);
		this.name.Value = name;
		if (name.Contains("Farm") || name.Contains("Coop") || name.Contains("Barn") || name.Equals("SlimeHutch"))
		{
			isFarm.Value = true;
		}
		if (name == "Greenhouse")
		{
			IsGreenhouse = true;
		}
		reloadMap();
		loadObjects();
	}

	public virtual void AddDefaultBuildings(bool load = true)
	{
	}

	public virtual void AddDefaultBuilding(string id, Vector2 tile, bool load = true)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		foreach (Building building2 in buildings)
		{
			if (building2.buildingType.Value == id)
			{
				return;
			}
		}
		Building building = Building.CreateInstanceFromId(id, tile);
		if (load)
		{
			building.load();
		}
		buildings.Add(building);
	}

	public void playSound(string audioName, Vector2? position = null, int? pitch = null, SoundContext context = SoundContext.Default)
	{
		Game1.sounds.PlayAll(audioName, this, position, pitch, context);
	}

	public void localSound(string audioName, Vector2? position = null, int? pitch = null, SoundContext context = SoundContext.Default)
	{
		Game1.sounds.PlayLocal(audioName, this, position, pitch, context, out var _);
	}

	protected virtual LocalizedContentManager getMapLoader()
	{
		if (isStructure.Value)
		{
			if (_structureMapLoader == null)
			{
				_structureMapLoader = Game1.game1.xTileContent.CreateTemporary();
			}
			return _structureMapLoader;
		}
		return Game1.game1.xTileContent;
	}

	public void cleanUpTileForMapOverride(Point tile)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		cleanUpTileForMapOverride(tile, null);
	}

	public void cleanUpTileForMapOverride(Point tile, string exceptItemId)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = Utility.PointToVector2(tile);
		Point tileCenterPoint = Utility.Vector2ToPoint(val * new Vector2(64f) + new Vector2(32f, 32f));
		NetCollection<Item> lostAndFound = Game1.player.team.returnedDonations;
		if (Objects.TryGetValue(val, out var value) && (exceptItemId == null || !ItemRegistry.HasItemId(value, exceptItemId)))
		{
			if (value != null && (value.HasBeenInInventory || (!value.isDebrisOrForage() && value.QualifiedItemId != "(O)590" && value.QualifiedItemId != "(O)SeedSpot")))
			{
				if (value is Chest chest)
				{
					foreach (Item item in chest.Items)
					{
						lostAndFound.Add(item);
					}
					chest.Items.Clear();
				}
				else if (value.readyForHarvest.Value && value.heldObject != null)
				{
					lostAndFound.Add(value.heldObject.Value);
					value.heldObject.Value = null;
				}
				lostAndFound.Add(value);
				Game1.player.team.newLostAndFoundItems.Value = true;
			}
			objects.Remove(val);
		}
		furniture.RemoveWhere(delegate(Furniture item)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			Rectangle boundingBox = item.GetBoundingBox();
			if (!((Rectangle)(ref boundingBox)).Contains(tileCenterPoint) || (exceptItemId != null && ItemRegistry.HasItemId(item, exceptItemId)))
			{
				return false;
			}
			if (item.heldObject.Value != null)
			{
				lostAndFound.Add(item.heldObject.Value);
				item.heldObject.Value = null;
			}
			lostAndFound.Add(item);
			return true;
		});
		terrainFeatures.Remove(val);
		largeTerrainFeatures.RemoveWhere(delegate(LargeTerrainFeature feature)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			Rectangle boundingBox = feature.getBoundingBox();
			return ((Rectangle)(ref boundingBox)).Contains(tileCenterPoint);
		});
		resourceClumps.RemoveWhere(delegate(ResourceClump clump)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			Rectangle boundingBox = clump.getBoundingBox();
			return ((Rectangle)(ref boundingBox)).Contains(tileCenterPoint);
		});
	}

	public void ApplyMapOverride(Map override_map, string override_key, Rectangle? source_rect = null, Rectangle? dest_rect = null, Action<Point> perTileCustomAction = null)
	{
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Expected O, but got Unknown
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Expected O, but got Unknown
		//IL_0327: Unknown result type (might be due to invalid IL or missing references)
		//IL_0335: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03da: Unknown result type (might be due to invalid IL or missing references)
		//IL_041e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0403: Unknown result type (might be due to invalid IL or missing references)
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0431: Unknown result type (might be due to invalid IL or missing references)
		//IL_044b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0452: Unknown result type (might be due to invalid IL or missing references)
		//IL_0487: Unknown result type (might be due to invalid IL or missing references)
		//IL_048e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0467: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04de: Expected O, but got Unknown
		//IL_056b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0572: Unknown result type (might be due to invalid IL or missing references)
		//IL_0516: Unknown result type (might be due to invalid IL or missing references)
		//IL_0522: Unknown result type (might be due to invalid IL or missing references)
		//IL_0528: Expected O, but got Unknown
		//IL_0546: Unknown result type (might be due to invalid IL or missing references)
		//IL_054d: Expected O, but got Unknown
		if (_appliedMapOverrides.Contains(override_key))
		{
			return;
		}
		_appliedMapOverrides.Add(override_key);
		updateSeasonalTileSheets(override_map);
		Dictionary<TileSheet, TileSheet> dictionary = new Dictionary<TileSheet, TileSheet>();
		foreach (TileSheet tileSheet in override_map.TileSheets)
		{
			TileSheet val = map.GetTileSheet(((Component)tileSheet).Id);
			string text = "";
			string text2 = "";
			if (val != null)
			{
				text = val.ImageSource;
			}
			if (text2 != null)
			{
				text2 = tileSheet.ImageSource;
			}
			if (val == null || text2 != text)
			{
				val = new TileSheet(GetAddedMapOverrideTilesheetId(override_key, ((Component)tileSheet).Id), map, tileSheet.ImageSource, tileSheet.SheetSize, tileSheet.TileSize);
				for (int i = 0; i < tileSheet.TileCount; i++)
				{
					val.TileIndexProperties[i].CopyFrom(tileSheet.TileIndexProperties[i]);
				}
				map.AddTileSheet(val);
			}
			else if (val.TileCount < tileSheet.TileCount)
			{
				int tileCount = val.TileCount;
				val.SheetWidth = tileSheet.SheetWidth;
				val.SheetHeight = tileSheet.SheetHeight;
				for (int j = tileCount; j < tileSheet.TileCount; j++)
				{
					val.TileIndexProperties[j].CopyFrom(tileSheet.TileIndexProperties[j]);
				}
			}
			dictionary[tileSheet] = val;
		}
		Dictionary<Layer, Layer> dictionary2 = new Dictionary<Layer, Layer>();
		int num = 0;
		int num2 = 0;
		for (int k = 0; k < override_map.Layers.Count; k++)
		{
			num = Math.Max(num, override_map.Layers[k].LayerWidth);
			num2 = Math.Max(num2, override_map.Layers[k].LayerHeight);
		}
		if (!source_rect.HasValue)
		{
			source_rect = new Rectangle(0, 0, num, num2);
		}
		num = 0;
		num2 = 0;
		for (int l = 0; l < map.Layers.Count; l++)
		{
			num = Math.Max(num, map.Layers[l].LayerWidth);
			num2 = Math.Max(num2, map.Layers[l].LayerHeight);
		}
		bool flag = false;
		for (int m = 0; m < override_map.Layers.Count; m++)
		{
			Layer val2 = map.GetLayer(((Component)override_map.Layers[m]).Id);
			if (val2 == null)
			{
				val2 = new Layer(((Component)override_map.Layers[m]).Id, map, new Size(num, num2), override_map.Layers[m].TileSize);
				map.AddLayer(val2);
				flag = true;
			}
			dictionary2[override_map.Layers[m]] = val2;
		}
		if (flag)
		{
			SortLayers();
		}
		if (!dest_rect.HasValue)
		{
			dest_rect = new Rectangle(0, 0, num, num2);
		}
		int x = source_rect.Value.X;
		int y = source_rect.Value.Y;
		int x2 = dest_rect.Value.X;
		int y2 = dest_rect.Value.Y;
		Point val3 = default(Point);
		Point val4 = default(Point);
		for (int n = 0; n < source_rect.Value.Width; n++)
		{
			for (int num3 = 0; num3 < source_rect.Value.Height; num3++)
			{
				((Point)(ref val3))._002Ector(x + n, y + num3);
				((Point)(ref val4))._002Ector(x2 + n, y2 + num3);
				perTileCustomAction?.Invoke(val4);
				bool flag2 = false;
				for (int num4 = 0; num4 < override_map.Layers.Count; num4++)
				{
					Layer val5 = override_map.Layers[num4];
					Layer val6 = dictionary2[val5];
					if (val6 == null || val4.X >= val6.LayerWidth || val4.Y >= val6.LayerHeight || (!flag2 && override_map.Layers[num4].Tiles[val3.X, val3.Y] == null))
					{
						continue;
					}
					flag2 = true;
					if (val3.X >= val5.LayerWidth || val3.Y >= val5.LayerHeight)
					{
						continue;
					}
					if (val5.Tiles[val3.X, val3.Y] == null)
					{
						val6.Tiles[val4.X, val4.Y] = null;
						continue;
					}
					Tile val7 = val5.Tiles[val3.X, val3.Y];
					Tile val8 = null;
					if (!(val7 is StaticTile))
					{
						AnimatedTile val9 = (AnimatedTile)(object)((val7 is AnimatedTile) ? val7 : null);
						if (val9 != null)
						{
							StaticTile[] array = (StaticTile[])(object)new StaticTile[val9.TileFrames.Length];
							for (int num5 = 0; num5 < val9.TileFrames.Length; num5++)
							{
								StaticTile val10 = val9.TileFrames[num5];
								array[num5] = new StaticTile(val6, dictionary[((Tile)val10).TileSheet], ((Tile)val10).BlendMode, ((Tile)val10).TileIndex);
							}
							val8 = (Tile)new AnimatedTile(val6, array, val9.FrameInterval);
						}
					}
					else
					{
						val8 = (Tile)new StaticTile(val6, dictionary[val7.TileSheet], val7.BlendMode, val7.TileIndex);
					}
					if (val8 != null)
					{
						((Component)val8).Properties.CopyFrom(((Component)val7).Properties);
					}
					val6.Tiles[val4.X, val4.Y] = val8;
				}
			}
		}
		map.LoadTileSheets(Game1.mapDisplayDevice);
		if (Game1.IsMasterGame || IsTemporary)
		{
			_mapSeatsDirty = true;
		}
	}

	public static string GetAddedMapOverrideTilesheetId(string overrideKey, string tilesheetId)
	{
		return $"{"zzzzz"}_{overrideKey}_{tilesheetId}";
	}

	public virtual bool RunLocationSpecificEventCommand(Event current_event, string command_string, bool first_run, params string[] args)
	{
		return true;
	}

	public bool hasActiveFireplace()
	{
		for (int i = 0; i < furniture.Count; i++)
		{
			if (furniture[i].furniture_type.Value == 14 && furniture[i].isOn.Value)
			{
				return true;
			}
		}
		return false;
	}

	public void ApplyMapOverride(string map_name, Rectangle? source_rect = null, Rectangle? destination_rect = null)
	{
		if (!_appliedMapOverrides.Contains(map_name))
		{
			Map override_map = Game1.game1.xTileContent.Load<Map>("Maps\\" + map_name);
			ApplyMapOverride(override_map, map_name, source_rect, destination_rect);
		}
	}

	public void ApplyMapOverride(string map_name, string override_key_name, Rectangle? source_rect = null, Rectangle? destination_rect = null)
	{
		if (!_appliedMapOverrides.Contains(override_key_name))
		{
			Map override_map = Game1.game1.xTileContent.Load<Map>("Maps\\" + map_name);
			ApplyMapOverride(override_map, override_key_name, source_rect, destination_rect);
		}
	}

	public virtual void UpdateMapSeats()
	{
		_mapSeatsDirty = false;
		if (!Game1.IsMasterGame && !IsTemporary)
		{
			return;
		}
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		Dictionary<string, string> dictionary2 = DataLoader.ChairTiles(Game1.content);
		mapSeats.Clear();
		Layer layer = map.GetLayer("Buildings");
		if (layer == null)
		{
			return;
		}
		for (int i = 0; i < layer.LayerWidth; i++)
		{
			for (int j = 0; j < layer.LayerHeight; j++)
			{
				Tile val = layer.Tiles[i, j];
				if (val == null)
				{
					continue;
				}
				string text = Path.GetFileNameWithoutExtension(val.TileSheet.ImageSource);
				if (dictionary.TryGetValue(text, out var value))
				{
					text = value;
				}
				else
				{
					if (text.StartsWith("summer_") || text.StartsWith("winter_") || text.StartsWith("fall_"))
					{
						text = "spring_" + text.Substring(text.IndexOf('_') + 1);
					}
					dictionary[text] = text;
				}
				int sheetWidth = val.TileSheet.SheetWidth;
				int num = val.TileIndex % sheetWidth;
				int num2 = val.TileIndex / sheetWidth;
				string key = text + "/" + num + "/" + num2;
				if (dictionary2.TryGetValue(key, out var value2))
				{
					MapSeat mapSeat = MapSeat.FromData(value2, i, j);
					if (mapSeat != null)
					{
						mapSeats.Add(mapSeat);
					}
				}
			}
		}
	}

	public virtual void SortLayers()
	{
		backgroundLayers.Clear();
		buildingLayers.Clear();
		frontLayers.Clear();
		alwaysFrontLayers.Clear();
		Dictionary<string, List<KeyValuePair<Layer, int>>> dictionary = new Dictionary<string, List<KeyValuePair<Layer, int>>>();
		dictionary["Back"] = backgroundLayers;
		dictionary["Buildings"] = buildingLayers;
		dictionary["Front"] = frontLayers;
		dictionary["AlwaysFront"] = alwaysFrontLayers;
		foreach (Layer layer in map.Layers)
		{
			foreach (string key in dictionary.Keys)
			{
				if (((Component)layer).Id.StartsWith(key))
				{
					int result = 0;
					string text = ((Component)layer).Id.Substring(key.Length);
					if (text.Length <= 0 || int.TryParse(text, out result))
					{
						dictionary[key].Add(new KeyValuePair<Layer, int>(layer, result));
						break;
					}
				}
			}
		}
		foreach (List<KeyValuePair<Layer, int>> value in dictionary.Values)
		{
			value.Sort((KeyValuePair<Layer, int> a, KeyValuePair<Layer, int> b) => a.Value.CompareTo(b.Value));
		}
	}

	public virtual void OnMapLoad(Map map)
	{
	}

	public void loadMap(string mapPath, bool force_reload = false)
	{
		if (force_reload)
		{
			LocalizedContentManager localizedContentManager = Program.gamePtr.CreateContentManager(((ContentManager)Game1.content).ServiceProvider, ((ContentManager)Game1.content).RootDirectory);
			map = localizedContentManager.Load<Map>(mapPath);
			((ContentManager)localizedContentManager).Unload();
			InvalidateCachedMultiplayerMap(Game1.multiplayer.cachedMultiplayerMaps);
		}
		else if (!ApplyCachedMultiplayerMap(Game1.multiplayer.cachedMultiplayerMaps, mapPath))
		{
			map = getMapLoader().Load<Map>(mapPath);
		}
		loadedMapPath = mapPath;
		OnMapLoad(map);
		SortLayers();
		if (((IDictionary<string, PropertyValue>)((Component)map).Properties).ContainsKey("Outdoors"))
		{
			isOutdoors.Value = true;
		}
		if (((IDictionary<string, PropertyValue>)((Component)map).Properties).ContainsKey("IsFarm"))
		{
			isFarm.Value = true;
		}
		if (((IDictionary<string, PropertyValue>)((Component)map).Properties).ContainsKey("IsGreenhouse"))
		{
			isGreenhouse.Value = true;
		}
		if (HasMapPropertyWithValue("forceLoadPathLayerLights"))
		{
			forceLoadPathLayerLights = true;
		}
		if (HasMapPropertyWithValue("TreatAsOutdoors"))
		{
			treatAsOutdoors.Value = true;
		}
		updateSeasonalTileSheets(map);
		map.LoadTileSheets(Game1.mapDisplayDevice);
		if (Game1.IsMasterGame || IsTemporary)
		{
			_mapSeatsDirty = true;
		}
		if ((isOutdoors.Value || HasMapPropertyWithValue("indoorWater") || this is Sewer || this is Submarine) && !(this is Desert))
		{
			waterTiles = new WaterTiles(map.Layers[0].LayerWidth, map.Layers[0].LayerHeight);
			bool flag = false;
			for (int i = 0; i < map.Layers[0].LayerWidth; i++)
			{
				for (int j = 0; j < map.Layers[0].LayerHeight; j++)
				{
					string text = doesTileHaveProperty(i, j, "Water", "Back");
					if (text != null)
					{
						flag = true;
						if (text == "I")
						{
							waterTiles.waterTiles[i, j] = new WaterTiles.WaterTileData(is_water: true, is_visible: false);
						}
						else
						{
							waterTiles[i, j] = true;
						}
					}
				}
			}
			if (!flag)
			{
				waterTiles = null;
			}
		}
		if (isOutdoors.Value)
		{
			critters = new List<Critter>();
		}
		loadLights();
	}

	public virtual void HandleGrassGrowth(int dayOfMonth)
	{
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		if (dayOfMonth == 1)
		{
			if (this is Farm || HasMapPropertyWithValue("ClearEmptyDirtOnNewMonth"))
			{
				terrainFeatures.RemoveWhere((KeyValuePair<Vector2, TerrainFeature> pair) => pair.Value is HoeDirt { crop: null } && Game1.random.NextDouble() < 0.8);
			}
			if (this is Farm || HasMapPropertyWithValue("SpawnDebrisOnNewMonth"))
			{
				spawnWeedsAndStones(20, weedsOnly: false, spawnFromOldWeeds: false);
			}
			if (Game1.IsSpring && Game1.stats.DaysPlayed > 1)
			{
				if (this is Farm || HasMapPropertyWithValue("SpawnDebrisOnNewYear"))
				{
					spawnWeedsAndStones(40, weedsOnly: false, spawnFromOldWeeds: false);
					spawnWeedsAndStones(40, weedsOnly: true, spawnFromOldWeeds: false);
				}
				if (this is Farm || HasMapPropertyWithValue("SpawnRandomGrassOnNewYear"))
				{
					Vector2 val = default(Vector2);
					for (int num = 0; num < 15; num++)
					{
						int num2 = Game1.random.Next(map.DisplayWidth / 64);
						int num3 = Game1.random.Next(map.DisplayHeight / 64);
						((Vector2)(ref val))._002Ector((float)num2, (float)num3);
						objects.TryGetValue(val, out var value);
						if (value == null && doesTileHaveProperty(num2, num3, "Diggable", "Back") != null && !IsNoSpawnTile(val) && this.isTileLocationOpen(new Location(num2, num3)) && !IsTileOccupiedBy(val) && !isWaterTile(num2, num3))
						{
							int which = 1;
							if (Game1.GetFarmTypeID() == "MeadowlandsFarm" && Game1.random.NextDouble() < 0.2)
							{
								which = 7;
							}
							terrainFeatures.Add(val, new Grass(which, 4));
						}
					}
					growWeedGrass(40);
				}
				if (HasMapPropertyWithValue("SpawnGrassFromPathsOnNewYear"))
				{
					Layer layer = map.GetLayer("Paths");
					if (layer != null)
					{
						Vector2 val2 = default(Vector2);
						for (int num4 = 0; num4 < layer.LayerWidth; num4++)
						{
							for (int num5 = 0; num5 < layer.LayerHeight; num5++)
							{
								((Vector2)(ref val2))._002Ector((float)num4, (float)num5);
								objects.TryGetValue(val2, out var value2);
								if (value2 == null && getTileIndexAt(num4, num5, "Paths") == 22 && isTileLocationOpen(val2) && !IsTileOccupiedBy(val2))
								{
									terrainFeatures.Add(val2, new Grass(1, 4));
								}
							}
						}
					}
				}
			}
		}
		if ((this is Farm || HasMapPropertyWithValue("EnableGrassSpread")) && (!IsWinterHere() || HasMapPropertyWithValue("AllowGrassGrowInWinter")))
		{
			growWeedGrass(1);
		}
	}

	public void reloadMap()
	{
		if (mapPath.Value != null)
		{
			loadMap(mapPath.Value);
		}
		else
		{
			map = null;
		}
		loadedMapPath = mapPath.Value;
	}

	public virtual bool canSlimeMateHere()
	{
		return true;
	}

	public virtual bool canSlimeHatchHere()
	{
		return true;
	}

	public void addCharacter(NPC character)
	{
		characters.Add(character);
	}

	public static Rectangle getSourceRectForObject(int tileIndex)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		return new Rectangle(tileIndex * 16 % Game1.objectSpriteSheet.Width, tileIndex * 16 / Game1.objectSpriteSheet.Width * 16, 16, 16);
	}

	public Warp isCollidingWithWarp(Rectangle position, Character character)
	{
		if (ignoreWarps)
		{
			return null;
		}
		foreach (Warp warp in warps)
		{
			if ((!(character is NPC) && warp.npcOnly.Value) || (warp.X != (int)Math.Floor((double)((Rectangle)(ref position)).Left / 64.0) && warp.X != (int)Math.Floor((double)((Rectangle)(ref position)).Right / 64.0)) || (warp.Y != (int)Math.Floor((double)((Rectangle)(ref position)).Top / 64.0) && warp.Y != (int)Math.Floor((double)((Rectangle)(ref position)).Bottom / 64.0)))
			{
				continue;
			}
			string targetName = warp.TargetName;
			if (!(targetName == "BoatTunnel"))
			{
				if (targetName == "VolcanoEntrance")
				{
					return new Warp(warp.X, warp.Y, VolcanoDungeon.GetLevelName(0), warp.TargetX, warp.TargetY, flipFarmer: false);
				}
			}
			else if (character is NPC)
			{
				return new Warp(warp.X, warp.Y, "IslandSouth", 17, 43, flipFarmer: false);
			}
			return warp;
		}
		return null;
	}

	public Warp isCollidingWithWarpOrDoor(Rectangle position, Character character = null)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		Warp warp = isCollidingWithWarp(position, character);
		if (warp == null)
		{
			warp = isCollidingWithDoors(position, character);
		}
		return warp;
	}

	public virtual Warp isCollidingWithDoors(Rectangle position, Character character = null)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		Point val = default(Point);
		for (int i = 0; i < 4; i++)
		{
			Vector2 cornersOfThisRectangle = Utility.getCornersOfThisRectangle(ref position, i);
			((Point)(ref val))._002Ector((int)cornersOfThisRectangle.X / 64, (int)cornersOfThisRectangle.Y / 64);
			foreach (KeyValuePair<Point, string> pair in doors.Pairs)
			{
				Point key = pair.Key;
				if (val == key)
				{
					Warp warpFromDoor = getWarpFromDoor(key, character);
					if (warpFromDoor != null)
					{
						return warpFromDoor;
					}
				}
			}
			foreach (Building building in buildings)
			{
				if (!building.HasIndoors())
				{
					continue;
				}
				Point pointForHumanDoor = building.getPointForHumanDoor();
				if (val == pointForHumanDoor)
				{
					Warp warpFromDoor2 = getWarpFromDoor(pointForHumanDoor, character);
					if (warpFromDoor2 != null)
					{
						return warpFromDoor2;
					}
				}
			}
		}
		return null;
	}

	public virtual Warp getWarpFromDoor(Point door, Character character = null)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0303: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		foreach (Building building in buildings)
		{
			if (door == building.getPointForHumanDoor())
			{
				GameLocation indoors = building.GetIndoors();
				if (indoors != null)
				{
					return new Warp(door.X, door.Y, indoors.NameOrUniqueName, indoors.warps[0].X, indoors.warps[0].Y - 1, flipFarmer: false);
				}
			}
		}
		string[] tilePropertySplitBySpaces = GetTilePropertySplitBySpaces("Action", "Buildings", door.X, door.Y);
		string text = ArgUtility.Get(tilePropertySplitBySpaces, 0, "");
		switch (text)
		{
		case "WarpCommunityCenter":
			return new Warp(door.X, door.Y, "CommunityCenter", 32, 23, flipFarmer: false);
		case "Warp_Sunroom_Door":
			return new Warp(door.X, door.Y, "Sunroom", 5, 13, flipFarmer: false);
		case "WarpBoatTunnel":
			if (!(character is NPC))
			{
				return new Warp(door.X, door.Y, "BoatTunnel", 6, 11, flipFarmer: false);
			}
			return new Warp(door.X, door.Y, "IslandSouth", 17, 43, flipFarmer: false);
		case "WarpMensLocker":
		case "LockedDoorWarp":
		case "Warp":
		case "WarpWomensLocker":
		{
			if (!ArgUtility.TryGetPoint(tilePropertySplitBySpaces, 1, out var value, out var error, "Point tile") || !ArgUtility.TryGet(tilePropertySplitBySpaces, 3, out var value2, out error, allowBlank: true, "string locationName"))
			{
				LogTileActionError(tilePropertySplitBySpaces, door.X, door.Y, error);
				return null;
			}
			if (!(value2 == "BoatTunnel") || !(character is NPC))
			{
				return new Warp(door.X, door.Y, value2, value.X, value.Y, flipFarmer: false);
			}
			return new Warp(door.X, door.Y, "IslandSouth", 17, 43, flipFarmer: false);
		}
		default:
			if (text.Contains("Warp"))
			{
				Game1.log.Warn($"Door in {NameOrUniqueName} ({door}) has unknown warp property '{string.Join(" ", tilePropertySplitBySpaces)}', parsing with legacy logic.");
				goto case "WarpMensLocker";
			}
			return null;
		}
	}

	public Warp GetFirstPlayerWarp()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		Warp warp = null;
		foreach (Warp warp2 in warps)
		{
			if (!warp2.npcOnly.Value)
			{
				if (!WarpPathfindingCache.GenderRestrictions.TryGetValue(warp2.TargetName, out var value) || value == Game1.player.Gender)
				{
					return warp2;
				}
				if (warp == null)
				{
					warp = warp2;
				}
			}
		}
		return warp ?? warps.FirstOrDefault();
	}

	public void addResourceClumpAndRemoveUnderlyingTerrain(int resourceClumpIndex, int width, int height, Vector2 tile)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		removeObjectsAndSpawned((int)tile.X, (int)tile.Y, width, height);
		resourceClumps.Add(new ResourceClump(resourceClumpIndex, width, height, tile));
	}

	public virtual bool canFishHere()
	{
		return true;
	}

	public virtual bool CanWakeUpHere(Farmer who, Point? tile = null)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		Point val = (Point)(((_003F?)tile) ?? who.lastSleepPoint.Value);
		bool parsed;
		if (!BedFurniture.IsBedHere(this, val.X, val.Y) && !who.sleptInTemporaryBed.Value && !(this is IslandFarmHouse))
		{
			return TryGetMapPropertyAs("AllowWakeUpWithoutBed", out parsed, required: false) && parsed;
		}
		return true;
	}

	public virtual bool CanRefillWateringCanOnTile(int tileX, int tileY)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		Vector2 tile = default(Vector2);
		((Vector2)(ref tile))._002Ector((float)tileX, (float)tileY);
		Building buildingAt = getBuildingAt(tile);
		if (buildingAt != null && buildingAt.CanRefillWateringCan())
		{
			return true;
		}
		if (!isWaterTile(tileX, tileY) && doesTileHaveProperty(tileX, tileY, "WaterSource", "Back") == null)
		{
			if (!isOutdoors.Value && doesTileHaveProperty(tileX, tileY, "Action", "Buildings") == "kitchen")
			{
				if (getTileIndexAt(tileX, tileY, "Buildings", "untitled tile sheet") != 172)
				{
					return getTileIndexAt(tileX, tileY, "Buildings", "untitled tile sheet") == 257;
				}
				return true;
			}
			return false;
		}
		return true;
	}

	public virtual bool isTileBuildingFishable(int tileX, int tileY)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		Vector2 tile = default(Vector2);
		((Vector2)(ref tile))._002Ector((float)tileX, (float)tileY);
		foreach (Building building in buildings)
		{
			if (building.isTileFishable(tile))
			{
				return true;
			}
		}
		return false;
	}

	public virtual bool isTileFishable(int tileX, int tileY)
	{
		if (isTileBuildingFishable(tileX, tileY))
		{
			return true;
		}
		if (!isWaterTile(tileX, tileY) || doesTileHaveProperty(tileX, tileY, "NoFishing", "Back") != null || hasTileAt(tileX, tileY, "Buildings"))
		{
			return doesTileHaveProperty(tileX, tileY, "Water", "Buildings") != null;
		}
		return true;
	}

	public bool isFarmerCollidingWithAnyCharacter()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		if (characters.Count > 0)
		{
			Rectangle boundingBox = Game1.player.GetBoundingBox();
			foreach (NPC character in characters)
			{
				if (character != null && ((Rectangle)(ref boundingBox)).Intersects(character.GetBoundingBox()))
				{
					return true;
				}
			}
		}
		return false;
	}

	public bool isCollidingPosition(Rectangle position, Rectangle viewport, Character character)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		return isCollidingPosition(position, viewport, character is Farmer, 0, glider: false, character, pathfinding: false);
	}

	public virtual bool isCollidingPosition(Rectangle position, Rectangle viewport, bool isFarmer, int damagesFarmer, bool glider, Character character)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		return isCollidingPosition(position, viewport, character is Farmer, damagesFarmer, glider, character, pathfinding: false);
	}

	protected bool _TestCornersWorld(int top, int bottom, int left, int right, Func<int, int, bool> action)
	{
		if (action(right, top))
		{
			return true;
		}
		if (action(right, bottom))
		{
			return true;
		}
		if (action(left, top))
		{
			return true;
		}
		if (action(left, bottom))
		{
			return true;
		}
		return false;
	}

	protected bool _TestCornersTiles(Vector2 top_right, Vector2 top_left, Vector2 bottom_right, Vector2 bottom_left, Vector2 top_mid, Vector2 bottom_mid, Vector2? player_top_right, Vector2? player_top_left, Vector2? player_bottom_right, Vector2? player_bottom_left, Vector2? player_top_mid, Vector2? player_bottom_mid, bool bigger_than_tile, Func<Vector2, bool> action)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		_visitedCollisionTiles.Clear();
		Vector2? val = player_top_right;
		Vector2 val2 = top_right;
		if ((!val.HasValue || val.GetValueOrDefault() != val2) && _visitedCollisionTiles.Add(top_right) && action(top_right))
		{
			return true;
		}
		val = player_top_left;
		val2 = top_left;
		if ((!val.HasValue || val.GetValueOrDefault() != val2) && _visitedCollisionTiles.Add(top_left) && action(top_left))
		{
			return true;
		}
		val2 = bottom_left;
		val = player_bottom_left;
		if ((!val.HasValue || val2 != val.GetValueOrDefault()) && _visitedCollisionTiles.Add(bottom_left) && action(bottom_left))
		{
			return true;
		}
		val2 = bottom_right;
		val = player_bottom_right;
		if ((!val.HasValue || val2 != val.GetValueOrDefault()) && _visitedCollisionTiles.Add(bottom_right) && action(bottom_right))
		{
			return true;
		}
		if (bigger_than_tile)
		{
			val = player_top_mid;
			val2 = top_mid;
			if ((!val.HasValue || val.GetValueOrDefault() != val2) && _visitedCollisionTiles.Add(top_mid) && action(top_mid))
			{
				return true;
			}
			val = player_bottom_mid;
			val2 = bottom_mid;
			if ((!val.HasValue || val.GetValueOrDefault() != val2) && _visitedCollisionTiles.Add(bottom_mid) && action(bottom_mid))
			{
				return true;
			}
		}
		return false;
	}

	public Furniture GetFurnitureAt(Vector2 tile_position)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		Point val = new Point
		{
			X = (int)((float)(int)tile_position.X + 0.5f) * 64,
			Y = (int)((float)(int)tile_position.Y + 0.5f) * 64
		};
		Rectangle boundingBox;
		foreach (Furniture item in furniture)
		{
			if (!item.isPassable())
			{
				boundingBox = item.GetBoundingBox();
				if (((Rectangle)(ref boundingBox)).Contains(val))
				{
					return item;
				}
			}
		}
		foreach (Furniture item2 in furniture)
		{
			if (item2.isPassable())
			{
				boundingBox = item2.GetBoundingBox();
				if (((Rectangle)(ref boundingBox)).Contains(val))
				{
					return item2;
				}
			}
		}
		return null;
	}

	public virtual Rectangle GetBuildableRectangle()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		if (!_buildableTileRect.HasValue)
		{
			_buildableTileRect = (TryGetMapPropertyAs("ValidBuildRect", out Rectangle parsed, required: false) ? parsed : Rectangle.Empty);
			_looserBuildRestrictions = HasMapPropertyWithValue("LooserBuildRestrictions");
		}
		return _buildableTileRect.Value;
	}

	public virtual bool IsBuildableLocation()
	{
		if (HasMapPropertyWithValue("CanBuildHere"))
		{
			if (!Game1.multiplayer.isAlwaysActiveLocation(this))
			{
				if (!showedBuildableButNotAlwaysActiveWarning)
				{
					Game1.log.Warn($"Location {NameOrUniqueName} has the CanBuildHere map property set, but its {"AlwaysActive"} option is disabled, so building is disabled here.");
					showedBuildableButNotAlwaysActiveWarning = true;
				}
				return false;
			}
			string mapProperty = getMapProperty("BuildConditions");
			if (string.IsNullOrEmpty(mapProperty) || GameStateQuery.CheckConditions(mapProperty, this))
			{
				return true;
			}
		}
		return false;
	}

	public virtual bool IsOutOfBounds(Rectangle pixelPosition)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (((Rectangle)(ref pixelPosition)).Right < 0 || ((Rectangle)(ref pixelPosition)).Bottom < 0)
		{
			return true;
		}
		Layer val = map.Layers[0];
		if (pixelPosition.X <= val.DisplayWidth)
		{
			return ((Rectangle)(ref pixelPosition)).Top > val.DisplayHeight;
		}
		return true;
	}

	public virtual bool isCollidingPosition(Rectangle position, Rectangle viewport, bool isFarmer, int damagesFarmer, bool glider, Character character, bool pathfinding, bool projectile = false, bool ignoreCharacterRequirement = false, bool skipCollisionEffects = false)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_033f: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_0375: Unknown result type (might be due to invalid IL or missing references)
		//IL_037a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0389: Unknown result type (might be due to invalid IL or missing references)
		//IL_0397: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0821: Unknown result type (might be due to invalid IL or missing references)
		//IL_0822: Unknown result type (might be due to invalid IL or missing references)
		//IL_0823: Unknown result type (might be due to invalid IL or missing references)
		//IL_0825: Unknown result type (might be due to invalid IL or missing references)
		//IL_0827: Unknown result type (might be due to invalid IL or missing references)
		//IL_0829: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_084f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0850: Unknown result type (might be due to invalid IL or missing references)
		//IL_0851: Unknown result type (might be due to invalid IL or missing references)
		//IL_0853: Unknown result type (might be due to invalid IL or missing references)
		//IL_0855: Unknown result type (might be due to invalid IL or missing references)
		//IL_0857: Unknown result type (might be due to invalid IL or missing references)
		//IL_08aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0902: Unknown result type (might be due to invalid IL or missing references)
		//IL_0911: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b15: Unknown result type (might be due to invalid IL or missing references)
		//IL_0921: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_04db: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05de: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0501: Unknown result type (might be due to invalid IL or missing references)
		//IL_0505: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c63: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c67: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c69: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_09bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_072e: Unknown result type (might be due to invalid IL or missing references)
		//IL_051d: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_062f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0634: Unknown result type (might be due to invalid IL or missing references)
		//IL_0646: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c01: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c02: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c03: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c05: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c07: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c09: Unknown result type (might be due to invalid IL or missing references)
		//IL_0747: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e8f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e90: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e91: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e93: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e95: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e97: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d17: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d18: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a80: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e02: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e34: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e5a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e68: Unknown result type (might be due to invalid IL or missing references)
		bool flag = Game1.eventUp;
		if (flag && Game1.CurrentEvent != null && !Game1.CurrentEvent.ignoreObjectCollisions)
		{
			flag = false;
		}
		updateMap();
		if (IsOutOfBounds(position))
		{
			if (isFarmer && Game1.eventUp)
			{
				bool? flag2 = currentEvent?.isFestival;
				if (flag2.HasValue && flag2 == true && currentEvent.checkForCollision(position, (character as Farmer) ?? Game1.player))
				{
					return true;
				}
			}
			return false;
		}
		if (character == null && !ignoreCharacterRequirement)
		{
			return true;
		}
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(((Rectangle)(ref position)).Right / 64), (float)(((Rectangle)(ref position)).Top / 64));
		Vector2 val2 = default(Vector2);
		((Vector2)(ref val2))._002Ector((float)(((Rectangle)(ref position)).Left / 64), (float)(((Rectangle)(ref position)).Top / 64));
		Vector2 val3 = default(Vector2);
		((Vector2)(ref val3))._002Ector((float)(((Rectangle)(ref position)).Right / 64), (float)(((Rectangle)(ref position)).Bottom / 64));
		Vector2 val4 = default(Vector2);
		((Vector2)(ref val4))._002Ector((float)(((Rectangle)(ref position)).Left / 64), (float)(((Rectangle)(ref position)).Bottom / 64));
		bool bigger_than_tile = position.Width > 64;
		Vector2 bottom_mid = default(Vector2);
		((Vector2)(ref bottom_mid))._002Ector((float)(((Rectangle)(ref position)).Center.X / 64), (float)(((Rectangle)(ref position)).Bottom / 64));
		Vector2 top_mid = default(Vector2);
		((Vector2)(ref top_mid))._002Ector((float)(((Rectangle)(ref position)).Center.X / 64), (float)(((Rectangle)(ref position)).Top / 64));
		BoundingBoxGroup passableTiles = null;
		Farmer farmer = character as Farmer;
		Rectangle? val5;
		if (farmer != null)
		{
			isFarmer = true;
			val5 = farmer.GetBoundingBox();
			passableTiles = farmer.TemporaryPassableTiles;
		}
		else
		{
			farmer = null;
			isFarmer = false;
			val5 = null;
		}
		Vector2? player_top_right = null;
		Vector2? player_top_left = null;
		Vector2? player_bottom_right = null;
		Vector2? player_bottom_left = null;
		Vector2? player_bottom_mid = null;
		Vector2? player_top_mid = null;
		Rectangle val6;
		if (val5.HasValue)
		{
			val6 = val5.Value;
			float num = (((Rectangle)(ref val6)).Right - 1) / 64;
			val6 = val5.Value;
			player_top_right = new Vector2(num, (float)(((Rectangle)(ref val6)).Top / 64));
			val6 = val5.Value;
			float num2 = ((Rectangle)(ref val6)).Left / 64;
			val6 = val5.Value;
			player_top_left = new Vector2(num2, (float)(((Rectangle)(ref val6)).Top / 64));
			val6 = val5.Value;
			float num3 = (((Rectangle)(ref val6)).Right - 1) / 64;
			val6 = val5.Value;
			player_bottom_right = new Vector2(num3, (float)((((Rectangle)(ref val6)).Bottom - 1) / 64));
			val6 = val5.Value;
			float num4 = ((Rectangle)(ref val6)).Left / 64;
			val6 = val5.Value;
			player_bottom_left = new Vector2(num4, (float)((((Rectangle)(ref val6)).Bottom - 1) / 64));
			val6 = val5.Value;
			float num5 = ((Rectangle)(ref val6)).Center.X / 64;
			val6 = val5.Value;
			player_bottom_mid = new Vector2(num5, (float)((((Rectangle)(ref val6)).Bottom - 1) / 64));
			val6 = val5.Value;
			float num6 = ((Rectangle)(ref val6)).Center.X / 64;
			val6 = val5.Value;
			player_top_mid = new Vector2(num6, (float)(((Rectangle)(ref val6)).Top / 64));
		}
		if (farmer?.bridge != null && farmer.onBridge.Value && ((Rectangle)(ref position)).Right >= farmer.bridge.bridgeBounds.X && ((Rectangle)(ref position)).Left <= ((Rectangle)(ref farmer.bridge.bridgeBounds)).Right)
		{
			if (_TestCornersWorld(((Rectangle)(ref position)).Top, ((Rectangle)(ref position)).Bottom, ((Rectangle)(ref position)).Left, ((Rectangle)(ref position)).Right, (int x, int y) => (y > ((Rectangle)(ref farmer.bridge.bridgeBounds)).Bottom || y < ((Rectangle)(ref farmer.bridge.bridgeBounds)).Top) ? true : false))
			{
				return true;
			}
			return false;
		}
		if (!glider)
		{
			if (character != null && animals.FieldDict.Count > 0 && !(character is FarmAnimal))
			{
				foreach (FarmAnimal value2 in animals.Values)
				{
					Rectangle boundingBox = value2.GetBoundingBox();
					if (!((Rectangle)(ref position)).Intersects(boundingBox))
					{
						continue;
					}
					if (val5.HasValue)
					{
						val6 = val5.Value;
						if (((Rectangle)(ref val6)).Intersects(boundingBox))
						{
							continue;
						}
					}
					if (passableTiles == null || !passableTiles.Intersects(position))
					{
						if (!skipCollisionEffects)
						{
							value2.farmerPushing();
						}
						return true;
					}
				}
			}
			if (buildings.Count > 0)
			{
				foreach (Building building in buildings)
				{
					if (!building.intersects(position) || (val5.HasValue && building.intersects(val5.Value)))
					{
						continue;
					}
					if (!(character is FarmAnimal) && !(character is JunimoHarvester))
					{
						if (!(character is NPC))
						{
							return true;
						}
						Rectangle rectForHumanDoor = building.getRectForHumanDoor();
						rectForHumanDoor.Height += 64;
						if (!((Rectangle)(ref rectForHumanDoor)).Contains(position))
						{
							return true;
						}
					}
					else
					{
						Rectangle rectForAnimalDoor = building.getRectForAnimalDoor();
						rectForAnimalDoor.Height += 64;
						if (!((Rectangle)(ref rectForAnimalDoor)).Contains(position))
						{
							return true;
						}
						if (character is FarmAnimal farmAnimal && !farmAnimal.CanLiveIn(building))
						{
							return true;
						}
					}
				}
			}
			if (resourceClumps.Count > 0)
			{
				foreach (ResourceClump resourceClump in resourceClumps)
				{
					Rectangle boundingBox2 = resourceClump.getBoundingBox();
					if (((Rectangle)(ref boundingBox2)).Intersects(position) && (!val5.HasValue || !((Rectangle)(ref boundingBox2)).Intersects(val5.Value)))
					{
						return true;
					}
				}
			}
			if (!flag && furniture.Count > 0)
			{
				foreach (Furniture item in furniture)
				{
					if (item.furniture_type.Value != 12 && item.IntersectsForCollision(position) && (!val5.HasValue || !item.IntersectsForCollision(val5.Value)))
					{
						return true;
					}
				}
			}
			NetCollection<LargeTerrainFeature> netCollection = largeTerrainFeatures;
			if (netCollection != null && netCollection.Count > 0)
			{
				foreach (LargeTerrainFeature largeTerrainFeature in largeTerrainFeatures)
				{
					Rectangle boundingBox3 = largeTerrainFeature.getBoundingBox();
					if (((Rectangle)(ref boundingBox3)).Intersects(position) && (!val5.HasValue || !((Rectangle)(ref boundingBox3)).Intersects(val5.Value)))
					{
						return true;
					}
				}
			}
		}
		if (!glider)
		{
			if ((!flag || (character != null && !isFarmer && (!pathfinding || !character.willDestroyObjectsUnderfoot))) && _TestCornersTiles(val, val2, val3, val4, top_mid, bottom_mid, player_top_right, player_top_left, player_bottom_right, player_bottom_left, player_top_mid, player_bottom_mid, bigger_than_tile, delegate(Vector2 corner)
			{
				//IL_000b: Unknown result type (might be due to invalid IL or missing references)
				//IL_0023: Unknown result type (might be due to invalid IL or missing references)
				//IL_0028: Unknown result type (might be due to invalid IL or missing references)
				//IL_002c: Unknown result type (might be due to invalid IL or missing references)
				//IL_0073: Unknown result type (might be due to invalid IL or missing references)
				if (objects.TryGetValue(corner, out var value) && value != null)
				{
					if (value.isPassable())
					{
						return false;
					}
					Rectangle boundingBox5 = value.GetBoundingBox();
					if (((Rectangle)(ref boundingBox5)).Intersects(position) && (character == null || character.collideWith(value)))
					{
						if (character is FarmAnimal && value.isAnimalProduct())
						{
							return false;
						}
						if (passableTiles != null && passableTiles.Intersects(boundingBox5))
						{
							return false;
						}
						return true;
					}
				}
				return false;
			}))
			{
				return true;
			}
			_TestCornersTiles(val, val2, val3, val4, top_mid, bottom_mid, null, null, null, null, null, null, bigger_than_tile, delegate(Vector2 corner)
			{
				//IL_000b: Unknown result type (might be due to invalid IL or missing references)
				//IL_0019: Unknown result type (might be due to invalid IL or missing references)
				//IL_001e: Unknown result type (might be due to invalid IL or missing references)
				//IL_0022: Unknown result type (might be due to invalid IL or missing references)
				//IL_0048: Unknown result type (might be due to invalid IL or missing references)
				//IL_0066: Unknown result type (might be due to invalid IL or missing references)
				if (terrainFeatures.TryGetValue(corner, out var value) && value != null)
				{
					Rectangle boundingBox5 = value.getBoundingBox();
					if (((Rectangle)(ref boundingBox5)).Intersects(position) && !pathfinding && character != null && !skipCollisionEffects)
					{
						value.doCollisionAction(position, (int)((float)character.speed + character.addedSpeed), corner, character);
					}
				}
				return false;
			});
			if (_TestCornersTiles(val, val2, val3, val4, top_mid, bottom_mid, player_top_right, player_top_left, player_bottom_right, player_bottom_left, player_top_mid, player_bottom_mid, bigger_than_tile, delegate(Vector2 corner)
			{
				//IL_000b: Unknown result type (might be due to invalid IL or missing references)
				//IL_0019: Unknown result type (might be due to invalid IL or missing references)
				//IL_001e: Unknown result type (might be due to invalid IL or missing references)
				//IL_0022: Unknown result type (might be due to invalid IL or missing references)
				if (terrainFeatures.TryGetValue(corner, out var value) && value != null)
				{
					Rectangle boundingBox5 = value.getBoundingBox();
					if (((Rectangle)(ref boundingBox5)).Intersects(position) && !value.isPassable(character))
					{
						return true;
					}
				}
				return false;
			}))
			{
				return true;
			}
		}
		if (character != null && character.hasSpecialCollisionRules() && (character.isColliding(this, val) || character.isColliding(this, val2) || character.isColliding(this, val3) || character.isColliding(this, val4)))
		{
			return true;
		}
		if (((isFarmer && (currentEvent == null || currentEvent.playerControlSequence)) || (character != null && character.collidesWithOtherCharacters.Value)) && !pathfinding)
		{
			for (int num7 = characters.Count - 1; num7 >= 0; num7--)
			{
				NPC nPC = characters[num7];
				if (nPC == null || (character != null && character.Equals(nPC)))
				{
					continue;
				}
				Rectangle boundingBox4 = nPC.GetBoundingBox();
				if (nPC.layingDown)
				{
					boundingBox4.Y -= 64;
					boundingBox4.Height += 64;
				}
				if (((Rectangle)(ref boundingBox4)).Intersects(position) && !Game1.player.temporarilyInvincible && !skipCollisionEffects)
				{
					nPC.behaviorOnFarmerPushing();
				}
				if (isFarmer)
				{
					if (flag || nPC.farmerPassesThrough || !((Rectangle)(ref boundingBox4)).Intersects(position) || Game1.player.temporarilyInvincible || !Game1.player.TemporaryPassableTiles.IsEmpty())
					{
						continue;
					}
					if (nPC.IsMonster)
					{
						if (((Monster)nPC).isGlider.Value)
						{
							continue;
						}
						val6 = Game1.player.GetBoundingBox();
						if (((Rectangle)(ref val6)).Intersects(nPC.GetBoundingBox()))
						{
							continue;
						}
					}
					if (!nPC.IsInvisible)
					{
						val6 = Game1.player.GetBoundingBox();
						if (!((Rectangle)(ref val6)).Intersects(boundingBox4))
						{
							return true;
						}
					}
				}
				else if (((Rectangle)(ref boundingBox4)).Intersects(position))
				{
					return true;
				}
			}
		}
		Layer back_layer = map.RequireLayer("Back");
		Layer buildings_layer = map.RequireLayer("Buildings");
		Tile t;
		if (isFarmer)
		{
			Event obj = currentEvent;
			if (obj != null && obj.checkForCollision(position, (character as Farmer) ?? Game1.player))
			{
				return true;
			}
		}
		else
		{
			if (!pathfinding && !(character is Monster) && damagesFarmer == 0 && !glider)
			{
				foreach (Farmer farmer2 in farmers)
				{
					if (((Rectangle)(ref position)).Intersects(farmer2.GetBoundingBox()))
					{
						return true;
					}
				}
			}
			if ((isFarm.Value || MineShaft.IsGeneratedLevel(this) || this is IslandLocation) && character != null && !character.Name.Contains("NPC") && !character.EventActor && !glider)
			{
				if (_TestCornersTiles(val, val2, val3, val4, top_mid, bottom_mid, player_top_right, player_top_left, player_bottom_right, player_bottom_left, player_top_mid, player_bottom_mid, bigger_than_tile, delegate(Vector2 tile)
				{
					//IL_0011: Unknown result type (might be due to invalid IL or missing references)
					//IL_0018: Unknown result type (might be due to invalid IL or missing references)
					t = back_layer.Tiles[(int)tile.X, (int)tile.Y];
					return (t != null && ((IDictionary<string, PropertyValue>)((Component)t).Properties).ContainsKey("NPCBarrier")) ? true : false;
				}))
				{
					return true;
				}
			}
			if (glider && !projectile)
			{
				return false;
			}
		}
		if (!isFarmer || !Game1.player.isRafting)
		{
			if (_TestCornersTiles(val, val2, val3, val4, top_mid, bottom_mid, player_top_right, player_top_left, player_bottom_right, player_bottom_left, player_top_mid, player_bottom_mid, bigger_than_tile, delegate(Vector2 tile)
			{
				//IL_0011: Unknown result type (might be due to invalid IL or missing references)
				//IL_0018: Unknown result type (might be due to invalid IL or missing references)
				t = back_layer.Tiles[(int)tile.X, (int)tile.Y];
				return (t != null && ((IDictionary<string, PropertyValue>)((Component)t).Properties).ContainsKey("TemporaryBarrier")) ? true : false;
			}))
			{
				return true;
			}
		}
		if (!isFarmer || !Game1.player.isRafting)
		{
			if ((!(character is FarmAnimal farmAnimal2) || !farmAnimal2.IsActuallySwimming()) && _TestCornersTiles(val, val2, val3, val4, top_mid, bottom_mid, player_top_right, player_top_left, player_bottom_right, player_bottom_left, player_top_mid, player_bottom_mid, bigger_than_tile, delegate(Vector2 tile)
			{
				//IL_000b: Unknown result type (might be due to invalid IL or missing references)
				//IL_0012: Unknown result type (might be due to invalid IL or missing references)
				//IL_0058: Unknown result type (might be due to invalid IL or missing references)
				//IL_005f: Unknown result type (might be due to invalid IL or missing references)
				Tile val9 = back_layer.Tiles[(int)tile.X, (int)tile.Y];
				if (val9 != null)
				{
					bool flag3 = ((IDictionary<string, PropertyValue>)val9.TileIndexProperties).ContainsKey("Passable");
					if (!flag3)
					{
						flag3 = ((IDictionary<string, PropertyValue>)((Component)val9).Properties).ContainsKey("Passable");
					}
					if (flag3)
					{
						if (passableTiles != null && passableTiles.Contains((int)tile.X, (int)tile.Y))
						{
							return false;
						}
						return true;
					}
				}
				return false;
			}))
			{
				return true;
			}
			if (character == null || character.shouldCollideWithBuildingLayer(this))
			{
				Tile tmp;
				if (_TestCornersTiles(val, val2, val3, val4, top_mid, bottom_mid, player_top_right, player_top_left, player_bottom_right, player_bottom_left, player_top_mid, player_bottom_mid, bigger_than_tile, delegate(Vector2 tile)
				{
					//IL_0011: Unknown result type (might be due to invalid IL or missing references)
					//IL_0018: Unknown result type (might be due to invalid IL or missing references)
					//IL_0063: Unknown result type (might be due to invalid IL or missing references)
					//IL_006a: Unknown result type (might be due to invalid IL or missing references)
					//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
					//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
					tmp = buildings_layer.Tiles[(int)tile.X, (int)tile.Y];
					if (tmp != null)
					{
						if (projectile && this is VolcanoDungeon)
						{
							Tile val9 = back_layer.Tiles[(int)tile.X, (int)tile.Y];
							if (val9 != null)
							{
								if (((IDictionary<string, PropertyValue>)val9.TileIndexProperties).ContainsKey("Water"))
								{
									return false;
								}
								if (((IDictionary<string, PropertyValue>)((Component)val9).Properties).ContainsKey("Water"))
								{
									return false;
								}
							}
						}
						if (!((IDictionary<string, PropertyValue>)tmp.TileIndexProperties).ContainsKey("Shadow") && !((IDictionary<string, PropertyValue>)tmp.TileIndexProperties).ContainsKey("Passable") && !((IDictionary<string, PropertyValue>)((Component)tmp).Properties).ContainsKey("Passable") && (!projectile || (!((IDictionary<string, PropertyValue>)tmp.TileIndexProperties).ContainsKey("ProjectilePassable") && !((IDictionary<string, PropertyValue>)((Component)tmp).Properties).ContainsKey("ProjectilePassable"))))
						{
							if (isFarmer)
							{
								goto IL_01c9;
							}
							if (!((IDictionary<string, PropertyValue>)tmp.TileIndexProperties).ContainsKey("NPCPassable") && !((IDictionary<string, PropertyValue>)((Component)tmp).Properties).ContainsKey("NPCPassable"))
							{
								bool? flag3 = character?.canPassThroughActionTiles();
								if (!flag3.HasValue || flag3 != true || !((IDictionary<string, PropertyValue>)((Component)tmp).Properties).ContainsKey("Action"))
								{
									goto IL_01c9;
								}
							}
						}
					}
					return false;
					IL_01c9:
					if (passableTiles != null)
					{
						return !passableTiles.Contains((int)tile.X, (int)tile.Y);
					}
					return true;
				}))
				{
					return true;
				}
			}
			if (!isFarmer && character?.controller != null && !skipCollisionEffects)
			{
				Point val7 = default(Point);
				((Point)(ref val7))._002Ector(((Rectangle)(ref position)).Center.X / 64, ((Rectangle)(ref position)).Bottom / 64);
				Tile val8 = buildings_layer.Tiles[val7.X, val7.Y];
				if (val8 != null && ((IDictionary<string, PropertyValue>)((Component)val8).Properties).ContainsKey("Action"))
				{
					openDoor(new Location(val7.X, val7.Y), Game1.currentLocation.Equals(this));
				}
				else
				{
					((Point)(ref val7))._002Ector(((Rectangle)(ref position)).Center.X / 64, ((Rectangle)(ref position)).Top / 64);
					val8 = buildings_layer.Tiles[val7.X, val7.Y];
					if (val8 != null && ((IDictionary<string, PropertyValue>)((Component)val8).Properties).ContainsKey("Action"))
					{
						openDoor(new Location(val7.X, val7.Y), Game1.currentLocation.Equals(this));
					}
				}
			}
			return false;
		}
		if (_TestCornersTiles(val, val2, val3, val4, top_mid, bottom_mid, player_top_right, player_top_left, player_bottom_right, player_bottom_left, player_top_mid, player_bottom_mid, bigger_than_tile, delegate(Vector2 tile)
		{
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0068: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Unknown result type (might be due to invalid IL or missing references)
			//IL_0087: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
			t = back_layer.Tiles[(int)tile.X, (int)tile.Y];
			Tile obj2 = t;
			if ((!((obj2 != null) ? new bool?(((IDictionary<string, PropertyValue>)obj2.TileIndexProperties).ContainsKey("Water")) : ((bool?)null))) ?? true)
			{
				int num8 = (int)tile.X;
				int num9 = (int)tile.Y;
				if (IsTileBlockedBy(new Vector2((float)num8, (float)num9)))
				{
					Game1.player.isRafting = false;
					Game1.player.Position = new Vector2((float)(num8 * 64), (float)(num9 * 64 - 32));
					Game1.player.setTrajectory(0, 0);
				}
				return true;
			}
			return false;
		}))
		{
			return true;
		}
		return false;
	}

	public bool isTilePassable(Vector2 tileLocation)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		Tile val = map.RequireLayer("Back").Tiles[(int)tileLocation.X, (int)tileLocation.Y];
		if (val != null && ((IDictionary<string, PropertyValue>)val.TileIndexProperties).ContainsKey("Passable"))
		{
			return false;
		}
		Tile val2 = map.RequireLayer("Buildings").Tiles[(int)tileLocation.X, (int)tileLocation.Y];
		if (val2 != null && !((IDictionary<string, PropertyValue>)val2.TileIndexProperties).ContainsKey("Shadow") && !((IDictionary<string, PropertyValue>)val2.TileIndexProperties).ContainsKey("Passable"))
		{
			return false;
		}
		return true;
	}

	public bool isTilePassable(Location tileLocation, Rectangle viewport)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		return isTilePassable(new Vector2((float)tileLocation.X, (float)tileLocation.Y));
	}

	public bool isPointPassable(Location location, Rectangle viewport)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		return this.isTilePassable(new Location(location.X / 64, location.Y / 64), viewport);
	}

	public bool isTilePassable(Rectangle nextPosition, Rectangle viewport)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (isPointPassable(new Location(((Rectangle)(ref nextPosition)).Left, ((Rectangle)(ref nextPosition)).Top), viewport) && isPointPassable(new Location(((Rectangle)(ref nextPosition)).Right, ((Rectangle)(ref nextPosition)).Bottom), viewport) && isPointPassable(new Location(((Rectangle)(ref nextPosition)).Left, ((Rectangle)(ref nextPosition)).Bottom), viewport))
		{
			return isPointPassable(new Location(((Rectangle)(ref nextPosition)).Right, ((Rectangle)(ref nextPosition)).Top), viewport);
		}
		return false;
	}

	public bool isTileOnMap(Vector2 position)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (position.X >= 0f && position.X < (float)map.Layers[0].LayerWidth && position.Y >= 0f)
		{
			return position.Y < (float)map.Layers[0].LayerHeight;
		}
		return false;
	}

	public bool isTileOnMap(Point tile)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return isTileOnMap(tile.X, tile.Y);
	}

	public bool isTileOnMap(int x, int y)
	{
		if (x >= 0 && x < map.Layers[0].LayerWidth && y >= 0)
		{
			return y < map.Layers[0].LayerHeight;
		}
		return false;
	}

	public int numberOfObjectsWithName(string name)
	{
		int num = 0;
		foreach (Object value in objects.Values)
		{
			if (value.Name.Equals(name))
			{
				num++;
			}
		}
		return num;
	}

	public virtual Point getWarpPointTo(string location, Character character = null)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		foreach (Building building in buildings)
		{
			if (building.HasIndoorsName(location))
			{
				return building.getPointForHumanDoor();
			}
		}
		foreach (Warp warp in warps)
		{
			if (warp.TargetName.Equals(location))
			{
				return new Point(warp.X, warp.Y);
			}
			if (warp.TargetName.Equals("BoatTunnel") && location == "IslandSouth")
			{
				return new Point(warp.X, warp.Y);
			}
		}
		foreach (KeyValuePair<Point, string> pair in doors.Pairs)
		{
			if (pair.Value.Equals("BoatTunnel") && location == "IslandSouth")
			{
				return pair.Key;
			}
			if (pair.Value.Equals(location))
			{
				return pair.Key;
			}
		}
		return Point.Zero;
	}

	public Point getWarpPointTarget(Point warpPointLocation, Character character = null)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0335: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		foreach (Warp warp in warps)
		{
			if (warp.X == warpPointLocation.X && warp.Y == warpPointLocation.Y)
			{
				return new Point(warp.TargetX, warp.TargetY);
			}
		}
		foreach (KeyValuePair<Point, string> pair in doors.Pairs)
		{
			Point key = pair.Key;
			if (!((Point)(ref key)).Equals(warpPointLocation))
			{
				continue;
			}
			string[] tilePropertySplitBySpaces = GetTilePropertySplitBySpaces("Action", "Buildings", warpPointLocation.X, warpPointLocation.Y);
			string text = ArgUtility.Get(tilePropertySplitBySpaces, 0, "");
			switch (text)
			{
			case "WarpCommunityCenter":
				return new Point(32, 23);
			case "Warp_Sunroom_Door":
				return new Point(5, 13);
			case "WarpBoatTunnel":
				return new Point(17, 43);
			case "WarpMensLocker":
			case "LockedDoorWarp":
			case "Warp":
			case "WarpWomensLocker":
				break;
			default:
				if (!text.Contains("Warp"))
				{
					continue;
				}
				Game1.log.Warn($"Door in {NameOrUniqueName} ({pair.Key}) has unknown warp property '{string.Join(" ", tilePropertySplitBySpaces)}', parsing with legacy logic.");
				break;
			}
			if (!ArgUtility.TryGetPoint(tilePropertySplitBySpaces, 1, out var value, out var error, "Point tile") || !ArgUtility.TryGet(tilePropertySplitBySpaces, 3, out var value2, out error, allowBlank: true, "string locationName"))
			{
				LogTileActionError(tilePropertySplitBySpaces, warpPointLocation.X, warpPointLocation.Y, error);
				continue;
			}
			if (!(value2 == "BoatTunnel"))
			{
				if (value2 == "Trailer" && Game1.MasterPlayer.mailReceived.Contains("pamHouseUpgrade"))
				{
					return new Point(13, 24);
				}
				return new Point(value.X, value.Y);
			}
			return new Point(17, 43);
		}
		return Point.Zero;
	}

	public virtual bool HasLocationOverrideDialogue(NPC character)
	{
		return false;
	}

	public virtual string GetLocationOverrideDialogue(NPC character)
	{
		if (!HasLocationOverrideDialogue(character))
		{
			return null;
		}
		return "";
	}

	public NPC doesPositionCollideWithCharacter(Rectangle r, bool ignoreMonsters = false)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		foreach (NPC character in characters)
		{
			Rectangle boundingBox = character.GetBoundingBox();
			if (((Rectangle)(ref boundingBox)).Intersects(r) && (!character.IsMonster || !ignoreMonsters))
			{
				return character;
			}
		}
		return null;
	}

	public void switchOutNightTiles()
	{
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces("NightTiles");
		for (int i = 0; i < mapPropertySplitBySpaces.Length; i += 4)
		{
			if (!ArgUtility.TryGet(mapPropertySplitBySpaces, i, out var value, out var error, allowBlank: true, "string layerId") || !ArgUtility.TryGetPoint(mapPropertySplitBySpaces, i + 1, out var value2, out error, "Point position") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces, i + 3, out var value3, out error, "int tileIndex"))
			{
				LogMapPropertyError("NightTiles", mapPropertySplitBySpaces, error);
			}
			else if ((value3 != 726 && value3 != 720) || !Game1.MasterPlayer.mailReceived.Contains("pamHouseUpgrade"))
			{
				Tile val = map.RequireLayer(value).Tiles[value2.X, value2.Y];
				if (val == null)
				{
					LogMapPropertyError("NightTiles", mapPropertySplitBySpaces, $"there's no tile at position ({value2})");
				}
				else
				{
					val.TileIndex = value3;
				}
			}
		}
		if (!(this is MineShaft) && !(this is Woods))
		{
			lightGlows.Clear();
		}
	}

	public string GetMorningSong()
	{
		LocationWeather weather = GetWeather();
		if (weather.IsRaining)
		{
			return "rain";
		}
		List<string> list = new List<string>();
		List<LocationMusicData> list2 = GetLocationContext().Music;
		if (list2 == null || list2.Count <= 0)
		{
			list2 = LocationContexts.Default.Music ?? new List<LocationMusicData>();
		}
		foreach (LocationMusicData item in list2)
		{
			if (GameStateQuery.CheckConditions(item.Condition, this))
			{
				list.Add(item.Track);
			}
		}
		if (list.Count == 0)
		{
			return "none";
		}
		int num = weather.monthlyNonRainyDayCount.Value - 1;
		if (num < 0)
		{
			num = 0;
		}
		return list[num % list.Count];
	}

	public static void HandleMusicChange(GameLocation oldLocation, GameLocation newLocation)
	{
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		string musicTrackName = Game1.getMusicTrackName((MusicContext)0);
		if (!newLocation.IsOutdoors && Game1.IsPlayingOutdoorsAmbience)
		{
			Game1.changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
		}
		if (musicTrackName == "rain")
		{
			if (!Game1.IsRainingHere(newLocation))
			{
				Game1.stopMusicTrack((MusicContext)0);
			}
			else if (newLocation is MineShaft && !(oldLocation is MineShaft))
			{
				Game1.stopMusicTrack((MusicContext)0);
			}
		}
		if (Game1.getMusicTrackName((MusicContext)0) == "sam_acoustic1")
		{
			Game1.stopMusicTrack((MusicContext)0);
		}
		if (newLocation is MineShaft)
		{
			return;
		}
		string text = oldLocation?.GetLocationContextId();
		LocationContextData val = oldLocation?.GetLocationContext();
		LocationData val2 = newLocation?.GetData();
		string text2 = newLocation?.GetLocationContextId();
		LocationContextData val3 = newLocation?.GetLocationContext();
		string text3 = newLocation?.GetLocationSpecificMusic();
		MusicContext val4 = (MusicContext)((val2 != null) ? ((int)val2.MusicContext) : 0);
		bool flag = false;
		if (newLocation != null)
		{
			if (text3 != null)
			{
				flag = val2?.MusicIsTownTheme ?? false;
				newLocation.isMusicTownMusic = flag;
			}
			else
			{
				newLocation.isMusicTownMusic = false;
			}
		}
		if (text3 == null || (int)val4 == 0)
		{
			Game1.stopMusicTrack((MusicContext)1);
		}
		if (text3 == null && Game1.IsRainingHere(newLocation))
		{
			text3 = "rain";
		}
		else if (Game1.IsPlayingMorningSong && oldLocation != null && oldLocation.GetMorningSong() != newLocation.GetMorningSong() && Game1.shouldPlayMorningSong(loading_game: true))
		{
			Game1.playMorningSong(ignoreDelay: true);
			return;
		}
		if (text3 == null && !Game1.IsPlayingBackgroundMusic && newLocation.isOutdoors.Value && Game1.shouldPlayMorningSong())
		{
			Game1.playMorningSong();
			return;
		}
		if (text != text2)
		{
			PlayedNewLocationContextMusic = false;
		}
		if (!val3.DefaultMusicDelayOneScreen)
		{
			PlayedNewLocationContextMusic = false;
		}
		if (Game1.IsPlayingTownMusic && newLocation.IsOutdoors && (!flag || text3 != musicTrackName))
		{
			Game1.IsPlayingTownMusic = false;
			Game1.changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
		}
		if (flag)
		{
			if (text3 == musicTrackName)
			{
				return;
			}
			text3 = null;
		}
		if (text3 == null)
		{
			if (val != null && val3.DefaultMusic != val.DefaultMusic)
			{
				Game1.stopMusicTrack((MusicContext)0);
			}
			if (!PlayedNewLocationContextMusic)
			{
				if (val3.DefaultMusic != null)
				{
					if (Game1.isDarkOut(newLocation) || Game1.isStartingToGetDarkOut(newLocation) || Game1.IsRainingHere(newLocation))
					{
						PlayedNewLocationContextMusic = true;
					}
					else if (val3.DefaultMusicCondition == null || GameStateQuery.CheckConditions(val3.DefaultMusicCondition, newLocation))
					{
						Game1.changeMusicTrack(val3.DefaultMusic, track_interruptable: true, (MusicContext)0);
						Game1.IsPlayingBackgroundMusic = true;
						PlayedNewLocationContextMusic = true;
					}
				}
				else
				{
					PlayedNewLocationContextMusic = true;
					if (!flag && Game1.shouldPlayMorningSong(loading_game: true))
					{
						Game1.playMorningSong();
						return;
					}
				}
			}
		}
		if (!(musicTrackName != text3))
		{
			return;
		}
		if (text3 == null)
		{
			if (!Game1.IsPlayingBackgroundMusic && !Game1.IsPlayingOutdoorsAmbience)
			{
				Game1.stopMusicTrack((MusicContext)0);
			}
		}
		else
		{
			Game1.changeMusicTrack(text3, track_interruptable: true, val4);
		}
	}

	public virtual void checkForMusic(GameTime time)
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Expected I4, but got Unknown
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Expected I4, but got Unknown
		if (Game1.getMusicTrackName((MusicContext)0) == "sam_acoustic1" && Game1.isMusicContextActiveButNotPlaying((MusicContext)0))
		{
			Game1.changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
		}
		if (isMusicTownMusic.HasValue && isMusicTownMusic.Value && !Game1.eventUp && Game1.timeOfDay < 1800 && (Game1.isMusicContextActiveButNotPlaying((MusicContext)0) || Game1.IsPlayingOutdoorsAmbience))
		{
			string locationSpecificMusic = GetLocationSpecificMusic();
			if (locationSpecificMusic != null)
			{
				LocationData data = GetData();
				MusicContext music_context = (MusicContext)((data != null) ? ((int)data.MusicContext) : 0);
				Game1.changeMusicTrack(locationSpecificMusic, track_interruptable: false, music_context);
				Game1.IsPlayingBackgroundMusic = true;
				Game1.IsPlayingTownMusic = true;
			}
		}
		if (IsOutdoors && !IsRainingHere() && !Game1.eventUp)
		{
			bool flag = Game1.isDarkOut(this);
			if (flag && Game1.IsPlayingOutdoorsAmbience && !Game1.IsPlayingNightAmbience)
			{
				Game1.changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
			}
			if (!Game1.isMusicContextActiveButNotPlaying((MusicContext)0))
			{
				return;
			}
			if (!flag)
			{
				LocationContextData locationContext = GetLocationContext();
				if (locationContext.DayAmbience != null)
				{
					Game1.changeMusicTrack(locationContext.DayAmbience, track_interruptable: true, (MusicContext)0);
				}
				else
				{
					Season season = GetSeason();
					switch ((int)season)
					{
					case 0:
						Game1.changeMusicTrack("spring_day_ambient", track_interruptable: true, (MusicContext)0);
						break;
					case 1:
						Game1.changeMusicTrack("summer_day_ambient", track_interruptable: true, (MusicContext)0);
						break;
					case 2:
						Game1.changeMusicTrack("fall_day_ambient", track_interruptable: true, (MusicContext)0);
						break;
					case 3:
						Game1.changeMusicTrack("winter_day_ambient", track_interruptable: true, (MusicContext)0);
						break;
					}
				}
				Game1.IsPlayingOutdoorsAmbience = true;
			}
			else
			{
				if (Game1.timeOfDay >= 2500)
				{
					return;
				}
				LocationContextData locationContext2 = GetLocationContext();
				if (locationContext2.NightAmbience != null)
				{
					Game1.changeMusicTrack(locationContext2.NightAmbience, track_interruptable: true, (MusicContext)0);
				}
				else
				{
					Season season = GetSeason();
					switch ((int)season)
					{
					case 0:
						Game1.changeMusicTrack("spring_night_ambient", track_interruptable: true, (MusicContext)0);
						break;
					case 1:
						Game1.changeMusicTrack("spring_night_ambient", track_interruptable: true, (MusicContext)0);
						break;
					case 2:
						Game1.changeMusicTrack("spring_night_ambient", track_interruptable: true, (MusicContext)0);
						break;
					case 3:
						Game1.changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
						break;
					}
				}
				Game1.IsPlayingNightAmbience = true;
				Game1.IsPlayingOutdoorsAmbience = true;
			}
		}
		else if (IsRainingHere() && !Game1.showingEndOfNightStuff && Game1.isMusicContextActiveButNotPlaying((MusicContext)0))
		{
			Game1.changeMusicTrack("rain", track_interruptable: true, (MusicContext)0);
		}
	}

	public virtual string GetLocationSpecificMusic()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Expected I4, but got Unknown
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Invalid comparison between Unknown and I4
		LocationData data = GetData();
		if (data != null)
		{
			if (data.MusicIgnoredInRain && IsRainingHere())
			{
				return null;
			}
			Season season = GetSeason();
			bool flag = false;
			switch ((int)season)
			{
			case 0:
				flag = data.MusicIgnoredInSpring;
				break;
			case 1:
				flag = data.MusicIgnoredInSummer;
				break;
			case 2:
				flag = data.MusicIgnoredInFall;
				break;
			case 3:
				flag = data.MusicIgnoredInWinter;
				break;
			}
			if (flag)
			{
				return null;
			}
			if ((int)season == 2 && IsDebrisWeatherHere() && data.MusicIgnoredInFallDebris)
			{
				return null;
			}
			List<LocationMusicData> music = data.Music;
			if (music != null && music.Count > 0)
			{
				foreach (LocationMusicData item in data.Music)
				{
					if (GameStateQuery.CheckConditions(item.Condition, this))
					{
						return item.Track;
					}
				}
			}
			if (data.MusicDefault != null)
			{
				return data.MusicDefault;
			}
		}
		string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces("Music");
		if (mapPropertySplitBySpaces.Length != 0)
		{
			if (mapPropertySplitBySpaces.Length > 1)
			{
				if (!ArgUtility.TryGetInt(mapPropertySplitBySpaces, 0, out var value, out var error, "int startTime") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces, 1, out var value2, out error, "int endTime") || !ArgUtility.TryGet(mapPropertySplitBySpaces, 2, out var value3, out error, allowBlank: true, "string musicId"))
				{
					LogMapPropertyError("Music", mapPropertySplitBySpaces, error);
					return null;
				}
				if (Game1.timeOfDay < value || (value2 != 0 && Game1.timeOfDay >= value2))
				{
					return null;
				}
				return value3;
			}
			return mapPropertySplitBySpaces[0];
		}
		return null;
	}

	public NPC isCollidingWithCharacter(Rectangle box)
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		Rectangle boundingBox;
		if (Game1.isFestival() && currentEvent != null)
		{
			foreach (NPC actor in currentEvent.actors)
			{
				boundingBox = actor.GetBoundingBox();
				if (((Rectangle)(ref boundingBox)).Intersects(box))
				{
					return actor;
				}
			}
		}
		foreach (NPC character in characters)
		{
			boundingBox = character.GetBoundingBox();
			if (((Rectangle)(ref boundingBox)).Intersects(box))
			{
				return character;
			}
		}
		return null;
	}

	public virtual void drawAboveAlwaysFrontLayer(SpriteBatch b)
	{
		if (critters != null && Game1.farmEvent == null)
		{
			for (int i = 0; i < critters.Count; i++)
			{
				critters[i].drawAboveFrontLayer(b);
			}
		}
		foreach (NPC character in characters)
		{
			character.drawAboveAlwaysFrontLayer(b);
		}
		if (!(this is MineShaft))
		{
			foreach (NPC character2 in characters)
			{
				(character2 as Monster)?.drawAboveAllLayers(b);
			}
		}
		if (TemporarySprites.Count > 0)
		{
			foreach (TemporaryAnimatedSprite temporarySprite in TemporarySprites)
			{
				if (temporarySprite.drawAboveAlwaysFront)
				{
					temporarySprite.draw(b);
				}
			}
		}
		if (projectiles.Count <= 0)
		{
			return;
		}
		foreach (Projectile projectile in projectiles)
		{
			projectile.draw(b);
		}
	}

	public bool moveContents(int oldX, int oldY, int newX, int newY, string unlessItemId)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)oldX, (float)oldY);
		Vector2 val2 = default(Vector2);
		((Vector2)(ref val2))._002Ector((float)newX, (float)newY);
		Rectangle val3 = default(Rectangle);
		((Rectangle)(ref val3))._002Ector(oldX * 64, oldY * 64, 64, 64);
		Rectangle newPixelArea = new Rectangle(newX * 64, newY * 64, 64, 64);
		bool result = false;
		if (objects.TryGetValue(val, out var value) && !objects.ContainsKey(val2) && (unlessItemId == null || !ItemRegistry.HasItemId(value, unlessItemId)))
		{
			objects.Remove(val);
			objects.Add(val2, value);
			result = true;
		}
		for (int num = this.furniture.Count - 1; num >= 0; num--)
		{
			Furniture furniture = this.furniture[num];
			Rectangle value2 = furniture.boundingBox.Value;
			if (((Rectangle)(ref value2)).Intersects(val3) && (unlessItemId == null || !ItemRegistry.HasItemId(furniture, unlessItemId)) && !this.furniture.Any(delegate(Furniture p)
			{
				//IL_0006: Unknown result type (might be due to invalid IL or missing references)
				//IL_000b: Unknown result type (might be due to invalid IL or missing references)
				//IL_000f: Unknown result type (might be due to invalid IL or missing references)
				Rectangle value3 = p.boundingBox.Value;
				return ((Rectangle)(ref value3)).Intersects(newPixelArea);
			}))
			{
				Vector2 val4 = furniture.TileLocation - val;
				this.furniture.RemoveAt(num);
				furniture.TileLocation = val2 + val4;
				this.furniture.Add(furniture);
				result = true;
			}
		}
		return result;
	}

	private void getGalaxySword()
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		Item item = ItemRegistry.Create("(W)4");
		Game1.flashAlpha = 1f;
		Game1.player.holdUpItemThenMessage(item);
		Game1.player.reduceActiveItemByOne();
		if (!Game1.player.addItemToInventoryBool(item))
		{
			Game1.createItemDebris(item, Game1.player.getStandingPosition(), 1);
		}
		Game1.player.mailReceived.Add("galaxySword");
		Game1.player.jitterStrength = 0f;
		Game1.screenGlowHold = false;
		Game1.multiplayer.globalChatInfoMessage("GalaxySword", Game1.player.Name);
	}

	public static void RegisterTouchAction(string key, Action<GameLocation, string[], Farmer, Vector2> action)
	{
		if (action == null)
		{
			registeredTouchActions.Remove(key);
		}
		else
		{
			registeredTouchActions[key] = action;
		}
	}

	public static void RegisterTileAction(string key, Func<GameLocation, string[], Farmer, Point, bool> action)
	{
		if (action == null)
		{
			registeredTileActions.Remove(key);
		}
		else
		{
			registeredTileActions[key] = action;
		}
	}

	public virtual bool IgnoreTouchActions()
	{
		return Game1.eventUp;
	}

	public virtual void performTouchAction(string fullActionString, Vector2 playerStandingPosition)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		string[] action = ArgUtility.SplitBySpace(fullActionString);
		performTouchAction(action, playerStandingPosition);
	}

	public virtual void performTouchAction(string[] action, Vector2 playerStandingPosition)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0460: Unknown result type (might be due to invalid IL or missing references)
		//IL_046a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0474: Unknown result type (might be due to invalid IL or missing references)
		//IL_0479: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1445: Unknown result type (might be due to invalid IL or missing references)
		//IL_13d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_13df: Unknown result type (might be due to invalid IL or missing references)
		//IL_13ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_140f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1414: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c26: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c30: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c35: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c72: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_057e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0633: Unknown result type (might be due to invalid IL or missing references)
		//IL_0649: Unknown result type (might be due to invalid IL or missing references)
		//IL_0653: Unknown result type (might be due to invalid IL or missing references)
		//IL_066d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0672: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_070f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0725: Unknown result type (might be due to invalid IL or missing references)
		//IL_072f: Unknown result type (might be due to invalid IL or missing references)
		//IL_074a: Unknown result type (might be due to invalid IL or missing references)
		//IL_074f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0783: Unknown result type (might be due to invalid IL or missing references)
		//IL_0788: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_0528: Unknown result type (might be due to invalid IL or missing references)
		//IL_1188: Unknown result type (might be due to invalid IL or missing references)
		//IL_11d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_11de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ceb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cfa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c83: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dc1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dcb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e07: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0937: Unknown result type (might be due to invalid IL or missing references)
		//IL_093e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0420: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cdf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0afd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b04: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b2d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b32: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b34: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc6: Unknown result type (might be due to invalid IL or missing references)
		//IL_089c: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b56: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b68: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bad: Unknown result type (might be due to invalid IL or missing references)
		if (IgnoreTouchActions())
		{
			return;
		}
		try
		{
			Action<GameLocation, string[], Farmer, Vector2> value2;
			if (!ArgUtility.TryGet(action, 0, out var value, out var error, allowBlank: true, "string actionType"))
			{
				LogError(error);
			}
			else if (registeredTouchActions.TryGetValue(value, out value2))
			{
				value2(this, action, Game1.player, playerStandingPosition);
			}
			else
			{
				if (value == null)
				{
					return;
				}
				switch (value.Length)
				{
				case 9:
					switch (value[0])
					{
					case 'P':
						if (value == "PlayEvent")
						{
							if (!ArgUtility.TryGet(action, 1, out var value4, out error, allowBlank: true, "string eventId") || !ArgUtility.TryGetOptionalBool(action, 2, out var value5, out error, defaultValue: true, "bool checkPreconditions") || !ArgUtility.TryGetOptionalBool(action, 3, out var value6, out error, defaultValue: true, "bool checkSeen") || !ArgUtility.TryGetOptionalRemainder(action, 4, out var value7))
							{
								LogError(error);
							}
							else if (!Game1.PlayEvent(value4, value5, value6) && value7 != null)
							{
								performAction(value7, Game1.player, new Location((int)playerStandingPosition.X, (int)playerStandingPosition.Y));
							}
						}
						break;
					case 'M':
					{
						if (!(value == "MagicWarp"))
						{
							break;
						}
						if (!ArgUtility.TryGet(action, 1, out var locationToWarp, out error, allowBlank: true, "string locationToWarp") || !ArgUtility.TryGetPoint(action, 2, out var tile, out error, "Point tile") || !ArgUtility.TryGetOptional(action, 4, out var value3, out error, null, allowBlank: true, "string mailRequired"))
						{
							LogError(error);
						}
						else if (value3 == null || Game1.player.mailReceived.Contains(value3))
						{
							for (int j = 0; j < 12; j++)
							{
								Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(354, Game1.random.Next(25, 75), 6, 1, new Vector2((float)Game1.random.Next((int)Game1.player.position.X - 256, (int)Game1.player.position.X + 192), (float)Game1.random.Next((int)Game1.player.position.Y - 256, (int)Game1.player.position.Y + 192)), flicker: false, Game1.random.NextBool()));
							}
							playSound("wand");
							Game1.freezeControls = true;
							Game1.displayFarmer = false;
							Game1.player.CanMove = false;
							Game1.flashAlpha = 1f;
							DelayedAction.fadeAfterDelay(delegate
							{
								Game1.warpFarmer(locationToWarp, tile.X, tile.Y, flip: false);
								Game1.fadeToBlackAlpha = 0.99f;
								Game1.screenGlow = false;
								Game1.displayFarmer = true;
								Game1.player.CanMove = true;
								Game1.freezeControls = false;
							}, 1000);
							Rectangle boundingBox = Game1.player.GetBoundingBox();
							Rectangle val = default(Rectangle);
							((Rectangle)(ref val))._002Ector(boundingBox.X, boundingBox.Y, 64, 64);
							((Rectangle)(ref val)).Inflate(192, 192);
							int num = 0;
							Point tilePoint = Game1.player.TilePoint;
							for (int num2 = tilePoint.X + 8; num2 >= tilePoint.X - 8; num2--)
							{
								Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(6, new Vector2((float)num2, (float)tilePoint.Y) * 64f, Color.White, 8, flipped: false, 50f)
								{
									layerDepth = 1f,
									delayBeforeAnimationStart = num * 25,
									motion = new Vector2(-0.25f, 0f)
								});
								num++;
							}
						}
						break;
					}
					}
					break;
				case 4:
					switch (value[0])
					{
					case 'W':
						if (value == "Warp")
						{
							if (!ArgUtility.TryGet(action, 1, out var value8, out error, allowBlank: true, "string locationToWarp") || !ArgUtility.TryGetPoint(action, 2, out var value9, out error, "Point tile") || !ArgUtility.TryGetOptional(action, 4, out var value10, out error, null, allowBlank: true, "string mailRequired"))
							{
								LogError(error);
							}
							else if (value10 == null || Game1.player.mailReceived.Contains(value10))
							{
								Game1.warpFarmer(value8, value9.X, value9.Y, flip: false);
							}
						}
						break;
					case 'D':
					{
						if (!(value == "Door"))
						{
							break;
						}
						for (int num3 = 1; num3 < action.Length && (!(action[num3] == "Sebastian") || !IsGreenRainingHere() || Game1.year != 1); num3++)
						{
							if (Game1.player.getFriendshipHeartLevelForNPC(action[num3]) < 2 && num3 == action.Length - 1)
							{
								Farmer player3 = Game1.player;
								player3.Position -= Game1.player.getMostRecentMovementVector() * 2f;
								Game1.player.yVelocity = 0f;
								Game1.player.Halt();
								Game1.player.TemporaryPassableTiles.Clear();
								if (Game1.player.Tile == lastTouchActionLocation)
								{
									if (Game1.player.Position.Y > lastTouchActionLocation.Y * 64f + 32f)
									{
										Game1.player.position.Y += 4f;
									}
									else
									{
										Game1.player.position.Y -= 4f;
									}
									lastTouchActionLocation = Vector2.Zero;
								}
								if ((!Game1.player.mailReceived.Contains("doorUnlock" + action[1]) || (action.Length != 2 && !Game1.player.mailReceived.Contains("doorUnlock" + action[2]))) && (action.Length != 3 || !Game1.player.mailReceived.Contains("doorUnlock" + action[2])))
								{
									ShowLockedDoorMessage(action);
								}
								break;
							}
							if (num3 != action.Length - 1 && Game1.player.getFriendshipHeartLevelForNPC(action[num3]) >= 2)
							{
								Game1.player.mailReceived.Add("doorUnlock" + action[num3]);
								break;
							}
							if (num3 == action.Length - 1 && Game1.player.getFriendshipHeartLevelForNPC(action[num3]) >= 2)
							{
								Game1.player.mailReceived.Add("doorUnlock" + action[num3]);
								break;
							}
						}
						break;
					}
					}
					break;
				case 5:
					switch (value[0])
					{
					case 'S':
						if (value == "Sleep" && !Game1.newDay && Game1.shouldTimePass() && Game1.player.hasMoved && !Game1.player.passedOut)
						{
							createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:FarmHouse_Bed_GoToSleep"), createYesNoResponses(), "Sleep", null);
						}
						break;
					case 'E':
						if (value == "Emote")
						{
							if (!ArgUtility.TryGet(action, 1, out var value11, out error, allowBlank: true, "string npcName") || !ArgUtility.TryGetInt(action, 2, out var value12, out error, "int emote"))
							{
								LogError(error);
							}
							else
							{
								getCharacterFromName(value11)?.doEmote(value12);
							}
						}
						break;
					}
					break;
				case 12:
					switch (value[0])
					{
					case 'W':
						if (value == "WomensLocker" && Game1.player.IsMale)
						{
							Game1.player.position.Y += ((float)Game1.player.Speed + Game1.player.addedSpeed) * 2f;
							Game1.player.Halt();
							Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:WomensLocker_WrongGender"));
						}
						break;
					case 'P':
						if (value == "PoolEntrance")
						{
							if (!Game1.player.swimming.Value)
							{
								Game1.player.swimTimer = 800;
								Game1.player.swimming.Value = true;
								Game1.player.position.Y += 16f;
								Game1.player.yVelocity = -8f;
								playSound("pullItemFromWater");
								Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(27, 100f, 4, 0, new Vector2(Game1.player.Position.X, (float)(Game1.player.StandingPixel.Y - 40)), flicker: false, flipped: false)
								{
									layerDepth = 1f,
									motion = new Vector2(0f, 2f)
								});
							}
							else
							{
								Game1.player.jump();
								Game1.player.swimTimer = 800;
								Game1.player.position.X = playerStandingPosition.X * 64f;
								playSound("pullItemFromWater");
								Game1.player.yVelocity = 8f;
								Game1.player.swimming.Value = false;
							}
							Game1.player.noMovementPause = 500;
						}
						break;
					}
					break;
				case 8:
					if (value == "asdlfkjg")
					{
						removeTileProperty(13, 29, "Back", "TouchAction");
						removeTileProperty(14, 29, "Back", "TouchAction");
						removeTileProperty(15, 29, "Back", "TouchAction");
						if (Game1.timeOfDay >= 1920 && Game1.timeOfDay < 2020 && farmers.Count == 1 && Game1.stats.DaysPlayed > 3 && !Game1.isRaining && Game1.random.NextDouble() < 0.025)
						{
							Game1.player.mailReceived.Add("asdlkjfg1");
							playSound("shadowDie");
							DelayedAction.playSoundAfterDelay("grassyStep", 500, this);
							DelayedAction.playSoundAfterDelay("grassyStep", 1000, this);
							DelayedAction.playSoundAfterDelay("grassyStep", 1500, this);
							temporarySprites.Add(new TemporaryAnimatedSprite("Characters\\asldkfjsquaskutanfsldk", new Rectangle(0, 0, 32, 48), new Vector2(390f, 1980f), flipped: true, 0f, Color.White)
							{
								animationLength = 8,
								totalNumberOfLoops = 99,
								interval = 100f,
								motion = new Vector2(-5f, -1f),
								scale = 5.5f
							});
						}
					}
					break;
				case 11:
				{
					if (!(value == "MagicalSeal") || Game1.player.mailReceived.Contains("krobusUnseal"))
					{
						break;
					}
					Farmer player = Game1.player;
					player.Position -= Game1.player.getMostRecentMovementVector() * 2f;
					Game1.player.yVelocity = 0f;
					Game1.player.Halt();
					Game1.player.TemporaryPassableTiles.Clear();
					if (Game1.player.Tile == lastTouchActionLocation)
					{
						if (Game1.player.position.Y > lastTouchActionLocation.Y * 64f + 32f)
						{
							Game1.player.position.Y += 4f;
						}
						else
						{
							Game1.player.position.Y -= 4f;
						}
						lastTouchActionLocation = Vector2.Zero;
					}
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_MagicSeal"));
					for (int i = 0; i < 40; i++)
					{
						Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(666, 1851, 8, 8), 25f, 4, 2, new Vector2(3f, 19f) * 64f + new Vector2((float)(-8 + i % 4 * 16), (float)(-(i / 4) * 64 / 4)), flicker: false, flipped: false)
						{
							layerDepth = 0.1152f + (float)i / 10000f,
							color = new Color(100 + i * 4, i * 5, 120 + i * 4),
							pingPong = true,
							delayBeforeAnimationStart = i * 10,
							scale = 4f,
							alphaFade = 0.01f
						});
						Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(666, 1851, 8, 8), 25f, 4, 2, new Vector2(3f, 17f) * 64f + new Vector2((float)(-8 + i % 4 * 16), (float)(i / 4 * 64 / 4)), flicker: false, flipped: false)
						{
							layerDepth = 0.1152f + (float)i / 10000f,
							color = new Color(232 - i * 4, 192 - i * 6, 255 - i * 4),
							pingPong = true,
							delayBeforeAnimationStart = 320 + i * 10,
							scale = 4f,
							alphaFade = 0.01f
						});
						Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(666, 1851, 8, 8), 25f, 4, 2, new Vector2(3f, 19f) * 64f + new Vector2((float)(-8 + i % 4 * 16), (float)(-(i / 4) * 64 / 4)), flicker: false, flipped: false)
						{
							layerDepth = 0.1152f + (float)i / 10000f,
							color = new Color(100 + i * 4, i * 6, 120 + i * 4),
							pingPong = true,
							delayBeforeAnimationStart = 640 + i * 10,
							scale = 4f,
							alphaFade = 0.01f
						});
					}
					Game1.player.jitterStrength = 2f;
					Game1.player.freezePause = 500;
					playSound("debuffHit");
					break;
				}
				case 15:
				{
					if (!(value == "ConditionalDoor") || action.Length <= 1 || Game1.eventUp || GameStateQuery.CheckConditions(ArgUtility.UnsplitQuoteAware(action, ' ', 1)))
					{
						break;
					}
					Farmer player2 = Game1.player;
					player2.Position -= Game1.player.getMostRecentMovementVector() * 2f;
					Game1.player.yVelocity = 0f;
					Game1.player.Halt();
					Game1.player.TemporaryPassableTiles.Clear();
					if (Game1.player.Tile == lastTouchActionLocation)
					{
						if (Game1.player.Position.Y > lastTouchActionLocation.Y * 64f + 32f)
						{
							Game1.player.position.Y += 4f;
						}
						else
						{
							Game1.player.position.Y -= 4f;
						}
						lastTouchActionLocation = Vector2.Zero;
					}
					string text = doesTileHaveProperty((int)playerStandingPosition.X / 64, (int)playerStandingPosition.Y / 64, "LockedDoorMessage", "Back");
					if (text != null)
					{
						Game1.drawObjectDialogue(Game1.content.LoadString(TokenParser.ParseText(text)));
					}
					else
					{
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:LockedDoor"));
					}
					break;
				}
				case 13:
					if (value == "FaceDirection")
					{
						if (!ArgUtility.TryGet(action, 1, out var value13, out error, allowBlank: true, "string npcName") || !ArgUtility.TryGetInt(action, 2, out var value14, out error, "int direction"))
						{
							LogError(error);
						}
						else
						{
							getCharacterFromName(value13)?.faceDirection(value14);
						}
					}
					break;
				case 14:
					if (!(value == "legendarySword"))
					{
						break;
					}
					if (Game1.player.ActiveObject?.QualifiedItemId == "(O)74" && !Game1.player.mailReceived.Contains("galaxySword"))
					{
						Game1.player.Halt();
						Game1.player.faceDirection(2);
						Game1.player.showCarrying();
						Game1.player.jitterStrength = 1f;
						Game1.pauseThenDoFunction(7000, getGalaxySword);
						Game1.changeMusicTrack("none", track_interruptable: false, (MusicContext)3);
						playSound("crit");
						Game1.screenGlowOnce(new Color(30, 0, 150), hold: true, 0.01f, 0.999f);
						DelayedAction.playSoundAfterDelay("stardrop", 1500);
						Game1.screenOverlayTempSprites.AddRange(Utility.sparkleWithinArea(new Rectangle(0, 0, ((Rectangle)(ref Game1.viewport)).Width, ((Rectangle)(ref Game1.viewport)).Height), 500, Color.White, 10, 2000));
						Game1.afterDialogues = (Game1.afterFadeFunction)Delegate.Combine(Game1.afterDialogues, (Game1.afterFadeFunction)delegate
						{
							Game1.stopMusicTrack((MusicContext)3);
						});
					}
					else if (!Game1.player.mailReceived.Contains("galaxySword"))
					{
						localSound("SpringBirds");
					}
					break;
				case 10:
					if (value == "MensLocker" && !Game1.player.IsMale)
					{
						Game1.player.position.Y += ((float)Game1.player.Speed + Game1.player.addedSpeed) * 2f;
						Game1.player.Halt();
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:MensLocker_WrongGender"));
					}
					break;
				case 18:
					if (value == "ChangeIntoSwimsuit")
					{
						Game1.player.changeIntoSwimsuit();
					}
					break;
				case 19:
					if (value == "ChangeOutOfSwimsuit")
					{
						Game1.player.changeOutOfSwimSuit();
					}
					break;
				case 6:
				case 7:
				case 16:
				case 17:
					break;
				}
			}
		}
		catch (Exception)
		{
		}
		void LogError(string errorPhrase)
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			LogTileTouchActionError(action, playerStandingPosition, errorPhrase);
		}
	}

	public virtual void updateMap()
	{
		if (_mapPathDirty)
		{
			_mapPathDirty = false;
			if (!string.Equals(mapPath.Value, loadedMapPath, StringComparison.Ordinal))
			{
				reloadMap();
				updateLayout();
			}
		}
	}

	public virtual void updateLayout()
	{
		if (Game1.IsMasterGame)
		{
			updateDoors();
			updateWarps();
		}
	}

	public LargeTerrainFeature getLargeTerrainFeatureAt(int tileX, int tileY)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		foreach (LargeTerrainFeature largeTerrainFeature in largeTerrainFeatures)
		{
			Rectangle boundingBox = largeTerrainFeature.getBoundingBox();
			if (((Rectangle)(ref boundingBox)).Contains(tileX * 64 + 32, tileY * 64 + 32))
			{
				return largeTerrainFeature;
			}
		}
		return null;
	}

	public virtual void UpdateWhenCurrentLocation(GameTime time)
	{
		//IL_052e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0539: Unknown result type (might be due to invalid IL or missing references)
		//IL_055c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0561: Unknown result type (might be due to invalid IL or missing references)
		//IL_056c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0576: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0655: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0448: Unknown result type (might be due to invalid IL or missing references)
		//IL_044d: Unknown result type (might be due to invalid IL or missing references)
		//IL_045d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0462: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_093c: Unknown result type (might be due to invalid IL or missing references)
		//IL_08fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0904: Unknown result type (might be due to invalid IL or missing references)
		//IL_091f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0921: Unknown result type (might be due to invalid IL or missing references)
		//IL_0946: Unknown result type (might be due to invalid IL or missing references)
		//IL_094b: Unknown result type (might be due to invalid IL or missing references)
		//IL_092d: Unknown result type (might be due to invalid IL or missing references)
		//IL_096a: Unknown result type (might be due to invalid IL or missing references)
		//IL_096f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0981: Unknown result type (might be due to invalid IL or missing references)
		//IL_0986: Unknown result type (might be due to invalid IL or missing references)
		//IL_0988: Unknown result type (might be due to invalid IL or missing references)
		//IL_098a: Unknown result type (might be due to invalid IL or missing references)
		//IL_098c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0991: Unknown result type (might be due to invalid IL or missing references)
		//IL_0999: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a20: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a39: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a41: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a49: Unknown result type (might be due to invalid IL or missing references)
		updateMap();
		if (wasUpdated)
		{
			return;
		}
		wasUpdated = true;
		if (_mapSeatsDirty)
		{
			UpdateMapSeats();
		}
		furnitureToRemove.Update(this);
		if (Game1.player.currentLocation.Equals(this))
		{
			_updateAmbientLighting();
		}
		for (int i = 0; i < furniture.Count; i++)
		{
			furniture[i].updateWhenCurrentLocation(time);
		}
		AmbientLocationSounds.update(time);
		critters?.RemoveAll((Critter critter) => critter.update(time, this));
		if (fishSplashAnimation != null)
		{
			fishSplashAnimation.update(time);
			bool flag = fishFrenzyFish.Value != null && !fishFrenzyFish.Value.Equals("");
			double num = (flag ? 0.1 : 0.02);
			ICue cue;
			if (Game1.random.NextDouble() < num)
			{
				temporarySprites.Add(new TemporaryAnimatedSprite(0, fishSplashAnimation.position + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-32, 32)), Color.White * 0.3f)
				{
					layerDepth = (fishSplashAnimation.position.Y - 64f) / 10000f
				});
				if (flag)
				{
					temporarySprites.Add(new TemporaryAnimatedSprite(0, fishSplashAnimation.position + new Vector2((float)Game1.random.Next(-64, 64), (float)Game1.random.Next(-64, 64)), Color.White * 0.3f)
					{
						layerDepth = (fishSplashAnimation.position.Y - 64f) / 10000f
					});
					if (Game1.random.NextDouble() < 0.1)
					{
						Game1.sounds.PlayLocal("slosh", this, fishSplashAnimation.Position / 64f, null, SoundContext.Default, out cue);
					}
				}
			}
			if (flag && Game1.random.NextDouble() < 0.005)
			{
				Vector2 position = fishSplashAnimation.position + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-32, 32));
				Action<Vector2> splashAnimation = delegate(Vector2 pos)
				{
					//IL_0014: Unknown result type (might be due to invalid IL or missing references)
					//IL_0024: Unknown result type (might be due to invalid IL or missing references)
					TemporarySprites.Add(new TemporaryAnimatedSprite(28, 100f, 2, 1, pos, flicker: false, flipped: false)
					{
						delayBeforeAnimationStart = 0,
						layerDepth = (pos.Y + 1f) / 10000f
					});
				};
				Game1.sounds.PlayLocal("slosh", this, fishSplashAnimation.Position / 64f, null, SoundContext.Default, out cue);
				splashAnimation(position);
				ParsedItemData data = ItemRegistry.GetData(fishFrenzyFish.Value);
				int spriteID = 982648 + Game1.random.Next(99999);
				bool flag2 = Game1.random.NextDouble() < 0.5;
				float num2 = (float)Game1.random.Next(10, 20) / 10f;
				if (Game1.random.NextDouble() < 0.9)
				{
					num2 *= 0.75f;
				}
				TemporarySprites.Add(new TemporaryAnimatedSprite(data.GetTextureName(), data.GetSourceRect(), position, flag2, 0f, Color.White)
				{
					scale = 4f,
					motion = new Vector2((float)((!flag2) ? 1 : (-1)) * ((float)Game1.random.Next(11) * num2 + num2 * 5f) / 20f, (0f - (float)Game1.random.Next(30, 41) * num2) / 10f),
					acceleration = new Vector2(0f, 0.1f),
					rotationChange = (float)((!flag2) ? 1 : (-1)) * ((float)Game1.random.Next(5, 10) * num2) / 800f,
					yStopCoordinate = (int)position.Y + 1,
					id = spriteID,
					layerDepth = position.Y / 10000f,
					reachedStopCoordinateSprite = delegate(TemporaryAnimatedSprite x)
					{
						//IL_002c: Unknown result type (might be due to invalid IL or missing references)
						//IL_0036: Unknown result type (might be due to invalid IL or missing references)
						//IL_0059: Unknown result type (might be due to invalid IL or missing references)
						removeTemporarySpritesWithID(spriteID);
						Game1.sounds.PlayLocal("dropItemInWater", this, position / 64f, null, SoundContext.Default, out var _);
						splashAnimation(x.Position);
					}
				});
			}
		}
		if (orePanAnimation != null)
		{
			orePanAnimation.update(time);
			if (Game1.random.NextDouble() < 0.05)
			{
				temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(432, 1435, 16, 16), orePanAnimation.position + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-32, 32)), flipped: false, 0.02f, Color.White * 0.8f)
				{
					scale = 2f,
					animationLength = 6,
					interval = 100f
				});
			}
		}
		interiorDoors.Update(time);
		updateWater(time);
		Map.Update((long)time.ElapsedGameTime.Milliseconds);
		debris.RemoveWhere((Debris d) => d.updateChunks(time, this));
		if (Game1.shouldTimePass() || Game1.isFestival())
		{
			projectiles.RemoveWhere((Projectile projectile) => projectile.update(time, this));
		}
		for (int num3 = _activeTerrainFeatures.Count - 1; num3 >= 0; num3--)
		{
			TerrainFeature terrainFeature = _activeTerrainFeatures[num3];
			if (terrainFeature.tickUpdate(time))
			{
				terrainFeatures.Remove(terrainFeature.Tile);
			}
		}
		largeTerrainFeatures?.RemoveWhere((LargeTerrainFeature feature) => feature.tickUpdate(time));
		foreach (ResourceClump resourceClump in resourceClumps)
		{
			resourceClump.tickUpdate(time);
		}
		if (currentEvent != null)
		{
			bool flag3;
			do
			{
				int currentCommand = currentEvent.CurrentCommand;
				currentEvent.Update(this, time);
				if (currentEvent != null)
				{
					flag3 = currentEvent.simultaneousCommand;
					if (currentCommand == currentEvent.CurrentCommand)
					{
						flag3 = false;
					}
				}
				else
				{
					flag3 = false;
				}
			}
			while (flag3);
		}
		objects.Lock();
		foreach (Object value4 in objects.Values)
		{
			value4.updateWhenCurrentLocation(time);
		}
		objects.Unlock();
		Vector2 player_position;
		if (Game1.gameMode == 3 && this == Game1.currentLocation)
		{
			if (Game1.currentLocation.GetLocationContext().PlayRandomAmbientSounds && isOutdoors.Value)
			{
				if (!IsRainingHere())
				{
					if (Game1.timeOfDay < 2000)
					{
						if (Game1.isMusicContextActiveButNotPlaying((MusicContext)0) && !IsWinterHere() && Game1.random.NextDouble() < 0.002)
						{
							localSound("SpringBirds");
						}
					}
					else if (Game1.timeOfDay > 2100 && !(this is Beach) && IsSummerHere() && !IsTemporary && Game1.random.NextDouble() < 0.0005)
					{
						localSound("crickets");
					}
				}
				else if (!Game1.eventUp && Game1.options.musicVolumeLevel > 0f && Game1.random.NextDouble() < 0.00015 && !name.Equals("Town"))
				{
					localSound("rainsound");
				}
			}
			Vector2 tile = Game1.player.Tile;
			if (((Vector2)(ref lastTouchActionLocation)).Equals(Vector2.Zero))
			{
				string text = doesTileHaveProperty((int)tile.X, (int)tile.Y, "TouchAction", "Back");
				lastTouchActionLocation = tile;
				if (text != null)
				{
					performTouchAction(text, tile);
				}
			}
			else if (!((Vector2)(ref lastTouchActionLocation)).Equals(tile))
			{
				lastTouchActionLocation = Vector2.Zero;
			}
			foreach (Farmer farmer in farmers)
			{
				Vector2 tile2 = farmer.Tile;
				Vector2[] directionsTileVectorsWithDiagonals = Utility.DirectionsTileVectorsWithDiagonals;
				foreach (Vector2 val in directionsTileVectorsWithDiagonals)
				{
					Vector2 key = tile2 + val;
					if (objects.TryGetValue(key, out var value))
					{
						value.farmerAdjacentAction(farmer, val.X != 0f && val.Y != 0f);
					}
				}
			}
			if (Game1.player != null)
			{
				int value2 = Game1.player.facingDirection.Value;
				player_position = Game1.player.Tile;
				Object obj = null;
				if (value2 >= 0 && value2 < 4)
				{
					Vector2 val2 = Utility.DirectionsTileVectors[value2];
					obj = CheckForSign((int)val2.X, (int)val2.Y);
				}
				if (obj == null)
				{
					obj = CheckForSign(0, -1) ?? CheckForSign(0, 1) ?? CheckForSign(-1, 0) ?? CheckForSign(1, 0) ?? CheckForSign(-1, -1) ?? CheckForSign(1, -1) ?? CheckForSign(-1, 1) ?? CheckForSign(1, 1);
				}
				if (obj != null)
				{
					obj.shouldShowSign = true;
				}
			}
		}
		foreach (KeyValuePair<long, FarmAnimal> pair in animals.Pairs)
		{
			tempAnimals.Add(pair);
		}
		foreach (KeyValuePair<long, FarmAnimal> tempAnimal in tempAnimals)
		{
			if (tempAnimal.Value.updateWhenCurrentLocation(time, this))
			{
				animals.Remove(tempAnimal.Key);
			}
		}
		tempAnimals.Clear();
		foreach (Building building in buildings)
		{
			building.Update(time);
		}
		Object CheckForSign(int offsetX, int offsetY)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			if (!objects.TryGetValue(player_position + new Vector2((float)offsetX, (float)offsetY), out var value3) || !value3.IsTextSign())
			{
				return null;
			}
			return value3;
		}
	}

	public void updateWater(GameTime time)
	{
		waterAnimationTimer -= time.ElapsedGameTime.Milliseconds;
		if (waterAnimationTimer <= 0)
		{
			waterAnimationIndex = (waterAnimationIndex + 1) % 10;
			waterAnimationTimer = 200;
		}
		waterPosition += ((!isFarm.Value) ? ((float)((Math.Sin((float)time.TotalGameTime.Milliseconds / 1000f) + 1.0) * 0.15000000596046448)) : 0.1f);
		if (waterPosition >= 64f)
		{
			waterPosition -= 64f;
			waterTileFlip = !waterTileFlip;
		}
	}

	public NPC getCharacterFromName(string name)
	{
		NPC result = null;
		foreach (NPC character in characters)
		{
			if (character.Name.Equals(name))
			{
				return character;
			}
		}
		return result;
	}

	protected virtual void updateCharacters(GameTime time)
	{
		bool flag = Game1.shouldTimePass();
		for (int num = characters.Count - 1; num >= 0; num--)
		{
			NPC nPC = characters[num];
			if (nPC != null && (flag || nPC is Horse || nPC.forceUpdateTimer > 0))
			{
				nPC.currentLocation = this;
				nPC.update(time, this);
				if (num < characters.Count && nPC is Monster monster && monster.ShouldMonsterBeRemoved())
				{
					characters.RemoveAt(num);
				}
			}
			else if (nPC != null)
			{
				if (nPC.hasJustStartedFacingPlayer)
				{
					nPC.updateFaceTowardsFarmer(time, this);
				}
				nPC.updateEmote(time);
			}
		}
	}

	public Projectile getProjectileFromID(int uniqueID)
	{
		foreach (Projectile projectile in projectiles)
		{
			if (projectile.uniqueID.Value == uniqueID)
			{
				return projectile;
			}
		}
		return null;
	}

	public virtual void updateEvenIfFarmerIsntHere(GameTime time, bool ignoreWasUpdatedFlush = false)
	{
		netAudio.Update();
		removeTemporarySpritesWithIDEvent.Poll();
		rumbleAndFadeEvent.Poll();
		damagePlayersEvent.Poll();
		if (!ignoreWasUpdatedFlush)
		{
			wasUpdated = false;
		}
		updateCharacters(time);
		for (int num = temporarySprites.Count - 1; num >= 0; num--)
		{
			TemporaryAnimatedSprite temporaryAnimatedSprite = ((num < temporarySprites.Count) ? temporarySprites[num] : null);
			if (num < temporarySprites.Count && temporaryAnimatedSprite != null && temporaryAnimatedSprite.update(time) && num < temporarySprites.Count)
			{
				temporarySprites.RemoveAt(num);
			}
		}
		foreach (Building building in buildings)
		{
			building.updateWhenFarmNotCurrentLocation(time);
		}
		if (!Game1.currentLocation.Equals(this) && animals.Length > 0)
		{
			Building parentBuilding = ParentBuilding;
			FarmAnimal[] array = animals.Values.ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				array[i].updateWhenNotCurrentLocation(parentBuilding, time, this);
			}
		}
	}

	public GameLocation GetParentLocation()
	{
		if (parentLocationName.Value == null)
		{
			return null;
		}
		return Game1.getLocationFromName(parentLocationName.Value);
	}

	public GameLocation GetRootLocation()
	{
		return GetParentLocation() ?? this;
	}

	public Response[] createYesNoResponses()
	{
		return new Response[2]
		{
			new Response("Yes", Game1.content.LoadString("Strings\\Lexicon:QuestionDialogue_Yes")).SetHotKey((Keys)89),
			new Response("No", Game1.content.LoadString("Strings\\Lexicon:QuestionDialogue_No")).SetHotKey((Keys)27)
		};
	}

	public virtual void customQuestCompleteBehavior(string questId)
	{
	}

	public void createQuestionDialogue(string question, Response[] answerChoices, string dialogKey)
	{
		lastQuestionKey = dialogKey;
		Game1.drawObjectQuestionDialogue(question, answerChoices);
	}

	public void createQuestionDialogueWithCustomWidth(string question, Response[] answerChoices, string dialogKey)
	{
		int width = SpriteText.getWidthOfString(question) + 64;
		lastQuestionKey = dialogKey;
		Game1.drawObjectQuestionDialogue(question, answerChoices, width);
	}

	public void createQuestionDialogue(string question, Response[] answerChoices, afterQuestionBehavior afterDialogueBehavior, NPC speaker = null)
	{
		lastQuestionKey = null;
		afterQuestion = afterDialogueBehavior;
		Game1.drawObjectQuestionDialogue(question, answerChoices);
		if (speaker != null)
		{
			Game1.objectDialoguePortraitPerson = speaker;
		}
	}

	public void createQuestionDialogue(string question, Response[] answerChoices, string dialogKey, Object actionObject)
	{
		lastQuestionKey = dialogKey;
		Game1.drawObjectQuestionDialogue(question, answerChoices);
		actionObjectForQuestionDialogue = actionObject;
	}

	public virtual void monsterDrop(Monster monster, int x, int y, Farmer who)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0392: Unknown result type (might be due to invalid IL or missing references)
		//IL_0378: Unknown result type (might be due to invalid IL or missing references)
		//IL_041c: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0577: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		IList<string> objectsToDrop = monster.objectsToDrop;
		Vector2 val = Utility.PointToVector2(who.StandingPixel);
		List<Item> extraDropItems = monster.getExtraDropItems();
		if (who.isWearingRing("526") && DataLoader.Monsters(Game1.content).TryGetValue(monster.Name, out var value))
		{
			string[] array = ArgUtility.SplitBySpace(value.Split('/')[6]);
			for (int i = 0; i < array.Length; i += 2)
			{
				if (Game1.random.NextDouble() < Convert.ToDouble(array[i + 1]))
				{
					objectsToDrop.Add(array[i]);
				}
			}
		}
		List<Debris> list = new List<Debris>();
		for (int j = 0; j < objectsToDrop.Count; j++)
		{
			string text = objectsToDrop[j];
			if (text != null && text.StartsWith('-') && int.TryParse(text, out var result))
			{
				list.Add(monster.ModifyMonsterLoot(new Debris(Math.Abs(result), Game1.random.Next(1, 4), new Vector2((float)x, (float)y), val)));
			}
			else
			{
				list.Add(monster.ModifyMonsterLoot(new Debris(text, new Vector2((float)x, (float)y), val)));
			}
		}
		for (int k = 0; k < extraDropItems.Count; k++)
		{
			list.Add(monster.ModifyMonsterLoot(new Debris(extraDropItems[k], new Vector2((float)x, (float)y), val)));
		}
		Trinket.TrySpawnTrinket(this, monster, monster.getStandingPosition());
		if (who.isWearingRing("526"))
		{
			extraDropItems = monster.getExtraDropItems();
			for (int l = 0; l < extraDropItems.Count; l++)
			{
				Item one = extraDropItems[l].getOne();
				one.Stack = extraDropItems[l].Stack;
				one.HasBeenInInventory = false;
				list.Add(monster.ModifyMonsterLoot(new Debris(one, new Vector2((float)x, (float)y), val)));
			}
		}
		foreach (Debris item2 in list)
		{
			debris.Add(item2);
		}
		if (who.stats.Get("Book_Void") != 0 && Game1.random.NextDouble() < 0.03 && list != null && monster != null)
		{
			foreach (Debris item3 in list)
			{
				if (item3.item != null)
				{
					Item one2 = item3.item.getOne();
					if (one2 != null)
					{
						one2.Stack = item3.item.Stack;
						one2.HasBeenInInventory = false;
						debris.Add(monster.ModifyMonsterLoot(new Debris(one2, new Vector2((float)x, (float)y), val)));
					}
				}
				else if (item3.itemId.Value != null && item3.itemId.Value.Length > 0)
				{
					Item item = ItemRegistry.Create(item3.itemId.Value);
					item.HasBeenInInventory = false;
					debris.Add(monster.ModifyMonsterLoot(new Debris(item, new Vector2((float)x, (float)y), val)));
				}
			}
		}
		if (HasUnlockedAreaSecretNotes(who) && Game1.random.NextDouble() < 0.033)
		{
			Object obj = tryToCreateUnseenSecretNote(who);
			if (obj != null)
			{
				monster.ModifyMonsterLoot(Game1.createItemDebris(obj, new Vector2((float)x, (float)y), -1, this));
			}
		}
		Utility.trySpawnRareObject(who, new Vector2((float)x, (float)y), this, 1.5);
		if (Utility.tryRollMysteryBox(0.01 + who.team.AverageDailyLuck() / 10.0 + (double)who.LuckLevel * 0.008))
		{
			monster.ModifyMonsterLoot(Game1.createItemDebris(ItemRegistry.Create((who.stats.Get(StatKeys.Mastery(2)) != 0) ? "(O)GoldenMysteryBox" : "(O)MysteryBox"), new Vector2((float)x, (float)y), -1, this));
		}
		if (who.stats.MonstersKilled > 10 && Game1.random.NextDouble() < 0.0001 + ((!who.mailReceived.Contains("voidBookDropped")) ? ((double)who.stats.MonstersKilled * 1.5E-05) : 0.0004))
		{
			monster.ModifyMonsterLoot(Game1.createItemDebris(ItemRegistry.Create("(O)Book_Void"), new Vector2((float)x, (float)y), -1, this));
			who.mailReceived.Add("voidBookDropped");
		}
		if (this is Woods && Game1.random.NextDouble() < 0.1)
		{
			monster.ModifyMonsterLoot(Game1.createItemDebris(ItemRegistry.Create("(O)292"), new Vector2((float)x, (float)y), -1, this));
		}
		if (Game1.netWorldState.Value.GoldenWalnutsFound >= 100)
		{
			if (monster.isHardModeMonster.Value && Game1.stats.Get("hardModeMonstersKilled") > 50 && Game1.random.NextDouble() < 0.001 + (double)((float)who.LuckLevel * 0.0002f))
			{
				monster.ModifyMonsterLoot(Game1.createItemDebris(ItemRegistry.Create("(O)896"), new Vector2((float)x, (float)y), -1, this));
			}
			else if (monster.isHardModeMonster.Value && Game1.random.NextDouble() < 0.008 + (double)((float)who.LuckLevel * 0.002f))
			{
				monster.ModifyMonsterLoot(Game1.createItemDebris(ItemRegistry.Create("(O)858"), new Vector2((float)x, (float)y), -1, this));
			}
		}
	}

	public virtual bool HasUnlockedAreaSecretNotes(Farmer who)
	{
		if (!InIslandContext())
		{
			return who.hasMagnifyingGlass;
		}
		return true;
	}

	public bool damageMonster(Rectangle areaOfEffect, int minDamage, int maxDamage, bool isBomb, Farmer who, bool isProjectile = false)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return damageMonster(areaOfEffect, minDamage, maxDamage, isBomb, 1f, 0, 0f, 1f, triggerMonsterInvincibleTimer: false, who, isProjectile);
	}

	private bool isMonsterDamageApplicable(Farmer who, Monster monster, bool horizontalBias = true)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		if (!monster.isGlider.Value && !(who.CurrentTool is Slingshot) && !monster.ignoreDamageLOS.Value)
		{
			Point tilePoint = who.TilePoint;
			Point tilePoint2 = monster.TilePoint;
			if (Math.Abs(tilePoint.X - tilePoint2.X) + Math.Abs(tilePoint.Y - tilePoint2.Y) > 1)
			{
				int num = tilePoint2.X - tilePoint.X;
				int num2 = tilePoint2.Y - tilePoint.Y;
				Vector2 val = default(Vector2);
				((Vector2)(ref val))._002Ector((float)tilePoint.X, (float)tilePoint.Y);
				while (num != 0 || num2 != 0)
				{
					if (horizontalBias)
					{
						if (Math.Abs(num) >= Math.Abs(num2))
						{
							val.X += Math.Sign(num);
							num -= Math.Sign(num);
						}
						else
						{
							val.Y += Math.Sign(num2);
							num2 -= Math.Sign(num2);
						}
					}
					else if (Math.Abs(num2) >= Math.Abs(num))
					{
						val.Y += Math.Sign(num2);
						num2 -= Math.Sign(num2);
					}
					else
					{
						val.X += Math.Sign(num);
						num -= Math.Sign(num);
					}
					if ((objects.TryGetValue(val, out var value) && !value.isPassable()) || BlocksDamageLOS((int)val.X, (int)val.Y))
					{
						return false;
					}
				}
			}
		}
		return true;
	}

	public virtual bool BlocksDamageLOS(int x, int y)
	{
		if (hasTileAt(x, y, "Buildings") && doesTileHaveProperty(x, y, "Passable", "Buildings") == null)
		{
			return true;
		}
		return false;
	}

	public bool damageMonster(Rectangle areaOfEffect, int minDamage, int maxDamage, bool isBomb, float knockBackModifier, int addedPrecision, float critChance, float critMultiplier, bool triggerMonsterInvincibleTimer, Farmer who, bool isProjectile = false)
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0567: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0606: Unknown result type (might be due to invalid IL or missing references)
		//IL_0625: Unknown result type (might be due to invalid IL or missing references)
		//IL_0655: Unknown result type (might be due to invalid IL or missing references)
		//IL_065a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0680: Unknown result type (might be due to invalid IL or missing references)
		//IL_068c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0691: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_071a: Unknown result type (might be due to invalid IL or missing references)
		//IL_071f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0390: Unknown result type (might be due to invalid IL or missing references)
		//IL_0398: Unknown result type (might be due to invalid IL or missing references)
		//IL_0787: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0462: Unknown result type (might be due to invalid IL or missing references)
		//IL_0472: Unknown result type (might be due to invalid IL or missing references)
		//IL_047d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_0423: Unknown result type (might be due to invalid IL or missing references)
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0433: Unknown result type (might be due to invalid IL or missing references)
		//IL_081d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0846: Unknown result type (might be due to invalid IL or missing references)
		//IL_084b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0498: Unknown result type (might be due to invalid IL or missing references)
		//IL_0491: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08df: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e4: Unknown result type (might be due to invalid IL or missing references)
		bool result = false;
		for (int num = characters.Count - 1; num >= 0; num--)
		{
			if (num < characters.Count && characters[num] is Monster { IsMonster: not false, Health: >0 } monster && monster.TakesDamageFromHitbox(areaOfEffect))
			{
				if (monster.currentLocation == null)
				{
					monster.currentLocation = this;
				}
				if (!monster.IsInvisible && !monster.isInvincible() && (isBomb || isProjectile || isMonsterDamageApplicable(who, monster) || isMonsterDamageApplicable(who, monster, horizontalBias: false)))
				{
					bool flag = !isBomb && who?.CurrentTool is MeleeWeapon meleeWeapon && meleeWeapon.type.Value == 1;
					bool flag2 = false;
					if (flag && MeleeWeapon.daggerHitsLeft > 1)
					{
						flag2 = true;
					}
					if (flag2)
					{
						triggerMonsterInvincibleTimer = false;
					}
					result = true;
					if (Game1.currentLocation == this)
					{
						Rumble.rumble(0.1f + (float)(Game1.random.NextDouble() / 8.0), 200 + Game1.random.Next(-50, 50));
					}
					Rectangle boundingBox = monster.GetBoundingBox();
					Vector2 val = Utility.getAwayFromPlayerTrajectory(boundingBox, who);
					if (knockBackModifier > 0f)
					{
						val *= knockBackModifier;
					}
					else
					{
						((Vector2)(ref val))._002Ector(monster.xVelocity, monster.yVelocity);
					}
					if (monster.Slipperiness == -1)
					{
						val = Vector2.Zero;
					}
					bool flag3 = false;
					if (who?.CurrentTool != null && monster.hitWithTool(who.CurrentTool))
					{
						return false;
					}
					if (who.hasBuff("statue_of_blessings_5"))
					{
						critChance += 0.1f;
					}
					if (who.professions.Contains(25))
					{
						critChance += critChance * 0.5f;
					}
					int num2;
					if (maxDamage >= 0)
					{
						num2 = Game1.random.Next(minDamage, maxDamage + 1);
						if (who != null && Game1.random.NextDouble() < (double)(critChance + (float)who.LuckLevel * (critChance / 40f)))
						{
							flag3 = true;
							playSound("crit");
							if (who.hasTrinketWithID("IridiumSpur"))
							{
								BuffEffects buffEffects = new BuffEffects();
								buffEffects.Speed.Value = 1f;
								who.applyBuff(new Buff("iridiumspur", null, Game1.content.LoadString("Strings\\1_6_Strings:IridiumSpur_Name"), who.getFirstTrinketWithID("IridiumSpur").GetEffect().GeneralStat * 1000, Game1.objectSpriteSheet_2, 76, buffEffects, false));
							}
						}
						num2 = (flag3 ? ((int)((float)num2 * critMultiplier)) : num2);
						num2 = Math.Max(1, num2 + ((who != null) ? (who.Attack * 3) : 0));
						if (who != null && who.professions.Contains(24))
						{
							num2 = (int)Math.Ceiling((float)num2 * 1.1f);
						}
						if (who != null && who.professions.Contains(26))
						{
							num2 = (int)Math.Ceiling((float)num2 * 1.15f);
						}
						if (who != null && flag3 && who.professions.Contains(29))
						{
							num2 = (int)((float)num2 * 2f);
						}
						if (who != null)
						{
							foreach (BaseEnchantment enchantment in who.enchantments)
							{
								enchantment.OnCalculateDamage(monster, this, who, isBomb, ref num2);
							}
						}
						num2 = monster.takeDamage(num2, (int)val.X, (int)val.Y, isBomb, (double)addedPrecision / 10.0, who);
						if (flag2)
						{
							if (monster.stunTime.Value < 50)
							{
								monster.stunTime.Value = 50;
							}
						}
						else if (monster.stunTime.Value < 50)
						{
							monster.stunTime.Value = 0;
						}
						if (num2 == -1)
						{
							string message = Game1.content.LoadString("Strings\\StringsFromCSFiles:Attack_Miss");
							debris.Add(new Debris(message, 1, new Vector2((float)((Rectangle)(ref boundingBox)).Center.X, (float)((Rectangle)(ref boundingBox)).Center.Y), Color.LightGray, 1f, 0f));
						}
						else
						{
							removeDamageDebris(monster);
							debris.Add(new Debris(num2, new Vector2((float)(((Rectangle)(ref boundingBox)).Center.X + 16), (float)((Rectangle)(ref boundingBox)).Center.Y), (Color)(flag3 ? Color.Yellow : new Color(255, 130, 0)), flag3 ? (1f + (float)num2 / 300f) : 1f, monster));
							if (who != null)
							{
								foreach (BaseEnchantment enchantment2 in who.enchantments)
								{
									enchantment2.OnDealtDamage(monster, this, who, isBomb, num2);
								}
							}
						}
						if (triggerMonsterInvincibleTimer)
						{
							monster.setInvincibleCountdown(450 / (flag ? 3 : 2));
						}
						if (who != null)
						{
							foreach (Trinket trinketItem in who.trinketItems)
							{
								trinketItem?.OnDamageMonster(who, monster, num2, isBomb, flag3);
							}
						}
					}
					else
					{
						num2 = -2;
						monster.setTrajectory(val);
						if (monster.Slipperiness > 10)
						{
							monster.xVelocity /= 2f;
							monster.yVelocity /= 2f;
						}
					}
					if (who?.CurrentTool?.QualifiedItemId == "(W)4")
					{
						Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(362, Game1.random.Next(50, 120), 6, 1, new Vector2((float)(((Rectangle)(ref boundingBox)).Center.X - 32), (float)(((Rectangle)(ref boundingBox)).Center.Y - 32)), flicker: false, flipped: false));
					}
					if (monster.Health <= 0)
					{
						onMonsterKilled(who, monster, boundingBox, isBomb);
					}
					else if (num2 > 0)
					{
						monster.shedChunks(Game1.random.Next(1, 3));
						if (flag3)
						{
							Vector2 standingPosition = monster.getStandingPosition();
							Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(362, Game1.random.Next(15, 50), 6, 1, standingPosition - new Vector2(32f, 32f), flicker: false, Game1.random.NextBool())
							{
								scale = 0.75f,
								alpha = (flag3 ? 0.75f : 0.5f)
							});
							Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(362, Game1.random.Next(15, 50), 6, 1, standingPosition - new Vector2((float)(32 + Game1.random.Next(-21, 21) + 32), (float)(32 + Game1.random.Next(-21, 21))), flicker: false, Game1.random.NextBool())
							{
								scale = 0.5f,
								delayBeforeAnimationStart = 50,
								alpha = (flag3 ? 0.75f : 0.5f)
							});
							Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(362, Game1.random.Next(15, 50), 6, 1, standingPosition - new Vector2((float)(32 + Game1.random.Next(-21, 21) - 32), (float)(32 + Game1.random.Next(-21, 21))), flicker: false, Game1.random.NextBool())
							{
								scale = 0.5f,
								delayBeforeAnimationStart = 100,
								alpha = (flag3 ? 0.75f : 0.5f)
							});
							Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(362, Game1.random.Next(15, 50), 6, 1, standingPosition - new Vector2((float)(32 + Game1.random.Next(-21, 21) + 32), (float)(32 + Game1.random.Next(-21, 21))), flicker: false, Game1.random.NextBool())
							{
								scale = 0.5f,
								delayBeforeAnimationStart = 150,
								alpha = (flag3 ? 0.75f : 0.5f)
							});
							Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(362, Game1.random.Next(15, 50), 6, 1, standingPosition - new Vector2((float)(32 + Game1.random.Next(-21, 21) - 32), (float)(32 + Game1.random.Next(-21, 21))), flicker: false, Game1.random.NextBool())
							{
								scale = 0.5f,
								delayBeforeAnimationStart = 200,
								alpha = (flag3 ? 0.75f : 0.5f)
							});
						}
					}
				}
			}
		}
		return result;
	}

	private void onMonsterKilled(Farmer who, Monster monster, Rectangle monsterBox, bool killedByBomb)
	{
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		bool isHutchSlime = false;
		bool flag = false;
		if (monster is GreenSlime greenSlime)
		{
			isHutchSlime = this is SlimeHutch;
			flag = !greenSlime.firstGeneration.Value;
		}
		who.NotifyQuests((Quest quest) => quest.OnMonsterSlain(this, monster, killedByBomb, isHutchSlime));
		if (!isHutchSlime && Game1.player.team.specialOrders != null)
		{
			foreach (SpecialOrder specialOrder in Game1.player.team.specialOrders)
			{
				specialOrder.onMonsterSlain?.Invoke(Game1.player, monster);
			}
		}
		if (who != null)
		{
			foreach (BaseEnchantment enchantment in who.enchantments)
			{
				enchantment.OnMonsterSlay(monster, this, who, killedByBomb);
			}
		}
		who?.leftRing.Value?.onMonsterSlay(monster, this, who);
		who?.rightRing.Value?.onMonsterSlay(monster, this, who);
		if (who != null && !isHutchSlime && !flag)
		{
			if (who.IsLocalPlayer)
			{
				Game1.stats.monsterKilled(monster.Name);
			}
			else if (Game1.IsMasterGame)
			{
				who.queueMessage(25, Game1.player, monster.Name);
			}
		}
		if (monster.isHardModeMonster.Value)
		{
			Game1.stats.Increment("hardModeMonstersKilled");
		}
		Game1.stats.MonstersKilled++;
		monsterDrop(monster, ((Rectangle)(ref monsterBox)).Center.X, ((Rectangle)(ref monsterBox)).Center.Y, who);
		if (!isHutchSlime)
		{
			who?.gainExperience(4, isFarm.Value ? Math.Max(1, monster.ExperienceGained / 3) : monster.ExperienceGained);
		}
		if (monster.ShouldMonsterBeRemoved())
		{
			characters.Remove(monster);
		}
		removeTemporarySpritesWithID((int)(monster.position.X * 777f + monster.position.Y * 77777f));
		if (who?.CurrentTool is MeleeWeapon meleeWeapon && (meleeWeapon.QualifiedItemId == "(W)65" || (meleeWeapon.appearance.Value != null && meleeWeapon.appearance.Value.Equals("(W)65"))))
		{
			Utility.addRainbowStarExplosion(this, new Vector2((float)(((Rectangle)(ref monsterBox)).Center.X - 32), (float)(((Rectangle)(ref monsterBox)).Center.Y - 32)), Game1.random.Next(6, 9));
		}
	}

	public void growWeedGrass(int iterations)
	{
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < iterations; i++)
		{
			KeyValuePair<Vector2, TerrainFeature>[] array = terrainFeatures.Pairs.ToArray();
			for (int j = 0; j < array.Length; j++)
			{
				KeyValuePair<Vector2, TerrainFeature> keyValuePair = array[j];
				if (!(keyValuePair.Value is Grass grass) || !(Game1.random.NextDouble() < 0.65))
				{
					continue;
				}
				if (grass.numberOfWeeds.Value < 4)
				{
					grass.numberOfWeeds.Value = Math.Max(0, Math.Min(4, grass.numberOfWeeds.Value + Game1.random.Next(3)));
				}
				else
				{
					if (grass.numberOfWeeds.Value < 4)
					{
						continue;
					}
					int x = (int)keyValuePair.Key.X;
					int y = (int)keyValuePair.Key.Y;
					Vector2[] adjacentTileLocationsArray = Utility.getAdjacentTileLocationsArray(keyValuePair.Key);
					foreach (Vector2 val in adjacentTileLocationsArray)
					{
						if (isTileOnMap(x, y) && !IsTileBlockedBy(val) && doesTileHaveProperty((int)val.X, (int)val.Y, "Diggable", "Back") != null && !IsNoSpawnTile(val) && Game1.random.NextDouble() < 0.25)
						{
							terrainFeatures.Add(val, new Grass(grass.grassType.Value, Game1.random.Next(1, 3)));
						}
					}
				}
			}
		}
	}

	public bool tryPlaceObject(Vector2 tile, Object o)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if (CanItemBePlacedHere(tile))
		{
			o.initializeLightSource(tile);
			objects.Add(tile, o);
			return true;
		}
		return false;
	}

	public void removeDamageDebris(Monster monster)
	{
		debris.RemoveWhere((Debris d) => d.toHover != null && d.toHover.Equals(monster) && !d.nonSpriteChunkColor.Equals(Color.Yellow) && d.timeSinceDoneBouncing > 900f);
	}

	public void spawnWeeds(bool weedsOnly)
	{
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Invalid comparison between Unknown and I4
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		LocationData data = GetData();
		int num = Game1.random.Next(data?.MinDailyWeeds ?? 1, (data?.MaxDailyWeeds ?? 5) + 1);
		if (Game1.dayOfMonth == 1 && Game1.IsSpring)
		{
			num *= data?.FirstDayWeedMultiplier ?? 15;
		}
		Vector2 val = default(Vector2);
		for (int i = 0; i < num; i++)
		{
			int num2 = 0;
			while (num2 < 3)
			{
				int num3 = Game1.random.Next(map.DisplayWidth / 64);
				int num4 = Game1.random.Next(map.DisplayHeight / 64);
				((Vector2)(ref val))._002Ector((float)num3, (float)num4);
				objects.TryGetValue(val, out var value);
				int num5 = -1;
				int num6 = -1;
				if (Game1.random.NextDouble() < 0.15 + (weedsOnly ? 0.05 : 0.0))
				{
					num5 = 1;
				}
				else if (!weedsOnly)
				{
					if (Game1.random.NextDouble() < 0.35)
					{
						num6 = 1;
					}
					else if (!isFarm.Value && Game1.random.NextDouble() < 0.35)
					{
						num6 = 2;
					}
				}
				if (num6 != -1)
				{
					if (this is Farm && Game1.random.NextDouble() < 0.25)
					{
						return;
					}
				}
				else if (value == null && doesTileHaveProperty(num3, num4, "Diggable", "Back") != null && this.isTileLocationOpen(new Location(num3, num4)) && !IsTileOccupiedBy(val) && !isWaterTile(num3, num4))
				{
					if (IsNoSpawnTile(val, "Grass"))
					{
						continue;
					}
					if (num5 != -1 && (int)GetSeason() != 3 && name.Value == "Farm")
					{
						if (Game1.GetFarmTypeID() == "MeadowlandsFarm" && Game1.random.NextDouble() < 0.1)
						{
							num5 = 7;
						}
						int numberOfWeeds = Game1.random.Next(1, 3);
						terrainFeatures.Add(val, new Grass(num5, numberOfWeeds));
					}
				}
				num2++;
			}
		}
	}

	public virtual void OnMiniJukeboxAdded()
	{
		miniJukeboxCount.Value += 1;
		UpdateMiniJukebox();
	}

	public virtual void OnMiniJukeboxRemoved()
	{
		miniJukeboxCount.Value -= 1;
		UpdateMiniJukebox();
	}

	public virtual void UpdateMiniJukebox()
	{
		if (miniJukeboxCount.Value <= 0)
		{
			miniJukeboxCount.Set(0);
			miniJukeboxTrack.Set("");
		}
	}

	public virtual bool IsMiniJukeboxPlaying()
	{
		if (miniJukeboxCount.Value > 0 && miniJukeboxTrack.Value != "" && (!IsOutdoors || !IsRainingHere()))
		{
			return !Game1.isGreenRain;
		}
		return false;
	}

	public virtual void DayUpdate(int dayOfMonth)
	{
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_039d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0650: Unknown result type (might be due to invalid IL or missing references)
		//IL_0655: Unknown result type (might be due to invalid IL or missing references)
		//IL_0477: Unknown result type (might be due to invalid IL or missing references)
		//IL_075d: Unknown result type (might be due to invalid IL or missing references)
		//IL_076d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0486: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0495: Unknown result type (might be due to invalid IL or missing references)
		//IL_0728: Unknown result type (might be due to invalid IL or missing references)
		//IL_0712: Unknown result type (might be due to invalid IL or missing references)
		//IL_049f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b2: Unknown result type (might be due to invalid IL or missing references)
		isMusicTownMusic = null;
		netAudio.StopPlaying("fuse");
		SelectRandomMiniJukeboxTrack();
		critters?.Clear();
		characters.RemoveWhere((NPC npc) => npc is JunimoHarvester || (npc is Monster monster && monster.wildernessFarmMonster));
		FarmAnimal[] array = animals.Values.ToArray();
		for (int num = 0; num < array.Length; num++)
		{
			array[num].dayUpdate(this);
		}
		for (int num2 = this.debris.Count - 1; num2 >= 0; num2--)
		{
			Debris debris = this.debris[num2];
			if (debris.isEssentialItem() && Game1.IsMasterGame)
			{
				if (debris.item?.QualifiedItemId == "(O)73")
				{
					debris.collect(Game1.player);
				}
				else
				{
					Item item = debris.item;
					debris.item = null;
					Game1.player.team.returnedDonations.Add(item);
					Game1.player.team.newLostAndFoundItems.Value = true;
				}
				this.debris.RemoveAt(num2);
			}
		}
		updateMap();
		temporarySprites.Clear();
		KeyValuePair<Vector2, TerrainFeature>[] array2 = terrainFeatures.Pairs.ToArray();
		KeyValuePair<Vector2, TerrainFeature>[] array3 = array2;
		for (int num = 0; num < array3.Length; num++)
		{
			KeyValuePair<Vector2, TerrainFeature> keyValuePair = array3[num];
			if (!isTileOnMap(keyValuePair.Key))
			{
				terrainFeatures.Remove(keyValuePair.Key);
			}
			else
			{
				keyValuePair.Value.dayUpdate();
			}
		}
		array3 = array2;
		foreach (KeyValuePair<Vector2, TerrainFeature> keyValuePair2 in array3)
		{
			if (keyValuePair2.Value is HoeDirt hoeDirt)
			{
				hoeDirt.updateNeighbors();
			}
		}
		if (largeTerrainFeatures != null)
		{
			LargeTerrainFeature[] array4 = largeTerrainFeatures.ToArray();
			for (int num = 0; num < array4.Length; num++)
			{
				array4[num].dayUpdate();
			}
		}
		objects.Lock();
		foreach (KeyValuePair<Vector2, Object> pair in objects.Pairs)
		{
			pair.Value.DayUpdate();
			if (pair.Value.destroyOvernight)
			{
				pair.Value.performRemoveAction();
				objects.Remove(pair.Key);
			}
		}
		objects.Unlock();
		RespawnStumpsFromMapProperty();
		if (!(this is FarmHouse))
		{
			this.debris.RemoveWhere((Debris d) => d.item == null && d.itemId.Value == null);
		}
		if (map != null && (isOutdoors.Value || ((IDictionary<string, PropertyValue>)((Component)map).Properties).ContainsKey("ForceSpawnForageables")) && !((IDictionary<string, PropertyValue>)((Component)map).Properties).ContainsKey("skipWeedGrowth"))
		{
			if (Game1.dayOfMonth % 7 == 0 && !(this is Farm))
			{
				Rectangle val = default(Rectangle);
				((Rectangle)(ref val))._002Ector(0, 0, 0, 0);
				if (this is IslandWest)
				{
					((Rectangle)(ref val))._002Ector(31, 3, 77, 70);
				}
				KeyValuePair<Vector2, Object>[] array5 = objects.Pairs.ToArray();
				for (int num = 0; num < array5.Length; num++)
				{
					KeyValuePair<Vector2, Object> keyValuePair3 = array5[num];
					if (keyValuePair3.Value.isSpawnedObject.Value && keyValuePair3.Value.SpecialVariable != 724519 && !((Rectangle)(ref val)).Contains(Utility.Vector2ToPoint(keyValuePair3.Key)))
					{
						objects.Remove(keyValuePair3.Key);
					}
				}
				numberOfSpawnedObjectsOnMap = 0;
				spawnObjects();
				spawnObjects();
			}
			spawnObjects();
			if (Game1.dayOfMonth == 1)
			{
				spawnObjects();
			}
			if (Game1.stats.DaysPlayed < 4)
			{
				spawnObjects();
			}
			Layer layer = map.GetLayer("Paths");
			if (layer != null && !(this is Farm))
			{
				Vector2 val2 = default(Vector2);
				for (int num3 = 0; num3 < map.Layers[0].LayerWidth; num3++)
				{
					for (int num4 = 0; num4 < map.Layers[0].LayerHeight; num4++)
					{
						if (!TryGetTreeIdForTile(layer.Tiles[num3, num4], out var treeId, out var _, out var growthStageOnRegrow, out var isFruitTree) || !Game1.random.NextBool())
						{
							continue;
						}
						((Vector2)(ref val2))._002Ector((float)num3, (float)num4);
						if (GetFurnitureAt(val2) == null && !terrainFeatures.ContainsKey(val2) && !objects.ContainsKey(val2) && getBuildingAt(val2) == null)
						{
							if (isFruitTree)
							{
								terrainFeatures.Add(val2, new FruitTree(treeId, growthStageOnRegrow ?? 2));
							}
							else
							{
								terrainFeatures.Add(val2, new Tree(treeId, growthStageOnRegrow ?? 2));
							}
						}
					}
				}
			}
		}
		terrainFeatures.RemoveWhere((KeyValuePair<Vector2, TerrainFeature> pair) => pair.Value is HoeDirt hoeDirt2 && (hoeDirt2.crop == null || hoeDirt2.crop.forageCrop.Value) && (!objects.TryGetValue(pair.Key, out var value) || value == null || !value.IsSpawnedObject || !value.isForage()) && Game1.random.NextBool(GetDirtDecayChance(pair.Key)));
		lightLevel.Value = 0f;
		foreach (Furniture item2 in furniture)
		{
			item2.minutesElapsed(Utility.CalculateMinutesUntilMorning(Game1.timeOfDay));
			item2.DayUpdate();
		}
		addLightGlows();
		if (!(this is Farm))
		{
			HandleGrassGrowth(dayOfMonth);
		}
		foreach (Building building in buildings)
		{
			building.dayUpdate(dayOfMonth);
		}
		foreach (string item3 in new List<string>(Game1.netWorldState.Value.Builders.Keys))
		{
			BuilderData builderData = Game1.netWorldState.Value.Builders[item3];
			if (builderData.buildingLocation.Value == NameOrUniqueName)
			{
				Building buildingAt = getBuildingAt(Utility.PointToVector2(builderData.buildingTile.Value));
				if (buildingAt == null || (buildingAt.daysUntilUpgrade.Value == 0 && buildingAt.daysOfConstructionLeft.Value == 0))
				{
					Game1.netWorldState.Value.Builders.Remove(item3);
				}
				else
				{
					Game1.netWorldState.Value.MarkUnderConstruction(item3, buildingAt);
				}
			}
		}
		if (dayOfMonth == 9 && Name.Equals("Backwoods"))
		{
			if (terrainFeatures.GetValueOrDefault(new Vector2(18f, 18f)) is HoeDirt)
			{
				terrainFeatures.Remove(new Vector2(18f, 18f));
			}
			tryPlaceObject(new Vector2(18f, 18f), ItemRegistry.Create<Object>("(O)SeedSpot"));
		}
		fishSplashPointTime = 0;
		fishFrenzyFish.Value = "";
		fishSplashPoint.Value = Point.Zero;
		orePanPoint.Value = Point.Zero;
	}

	public virtual double GetDirtDecayChance(Vector2 tile)
	{
		if (TryGetMapPropertyAs("DirtDecayChance", out double parsed, required: false))
		{
			return parsed;
		}
		if (IsGreenhouse)
		{
			return 0.0;
		}
		if (this is Farm || this is IslandWest || isFarm.Value)
		{
			return 0.1;
		}
		return 1.0;
	}

	public void RespawnStumpsFromMapProperty()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces("Stumps");
		for (int i = 0; i < mapPropertySplitBySpaces.Length; i += 3)
		{
			if (!ArgUtility.TryGetVector2(mapPropertySplitBySpaces, i, out var value, out var error, integerOnly: false, "Vector2 tile"))
			{
				LogMapPropertyError("Stumps", mapPropertySplitBySpaces, error);
				continue;
			}
			bool flag = false;
			foreach (ResourceClump resourceClump in resourceClumps)
			{
				if (resourceClump.Tile == value)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				resourceClumps.Add(new ResourceClump(600, 2, 2, value));
				removeObject(value, showDestroyedObject: false);
				removeObject(value + new Vector2(1f, 0f), showDestroyedObject: false);
				removeObject(value + new Vector2(1f, 1f), showDestroyedObject: false);
				removeObject(value + new Vector2(0f, 1f), showDestroyedObject: false);
			}
		}
	}

	public void addLightGlows()
	{
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		int num = Game1.getTrulyDarkTime(this) - 100;
		if (isOutdoors.Value || (Game1.timeOfDay >= num && !Game1.newDay))
		{
			return;
		}
		lightGlows.Clear();
		string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces("DayTiles");
		for (int i = 0; i < mapPropertySplitBySpaces.Length; i += 4)
		{
			if (!ArgUtility.TryGet(mapPropertySplitBySpaces, i, out var value, out var error, allowBlank: true, "string layerId") || !ArgUtility.TryGetVector2(mapPropertySplitBySpaces, i + 1, out var value2, out error, integerOnly: false, "Vector2 position") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces, i + 3, out var value3, out error, "int tileIndex"))
			{
				LogMapPropertyError("DayTiles", mapPropertySplitBySpaces, error);
				continue;
			}
			Tile val = map.RequireLayer(value).Tiles[(int)value2.X, (int)value2.Y];
			if (val != null)
			{
				val.TileIndex = value3;
				switch (value3)
				{
				case 257:
					lightGlows.Add(value2 * 64f + new Vector2(32f, -4f));
					break;
				case 256:
					lightGlows.Add(value2 * 64f + new Vector2(32f, 64f));
					break;
				case 405:
					lightGlows.Add(value2 * 64f + new Vector2(32f, 32f));
					lightGlows.Add(value2 * 64f + new Vector2(96f, 32f));
					break;
				case 469:
					lightGlows.Add(value2 * 64f + new Vector2(32f, 36f));
					break;
				case 1224:
					lightGlows.Add(value2 * 64f + new Vector2(32f, 32f));
					break;
				}
			}
		}
	}

	public NPC isCharacterAtTile(Vector2 tileLocation)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		NPC result = null;
		tileLocation.X = (int)tileLocation.X;
		tileLocation.Y = (int)tileLocation.Y;
		Rectangle val = default(Rectangle);
		((Rectangle)(ref val))._002Ector((int)tileLocation.X * 64, (int)tileLocation.Y * 64, 64, 64);
		Rectangle boundingBox;
		if (currentEvent == null)
		{
			foreach (NPC character in characters)
			{
				boundingBox = character.GetBoundingBox();
				if (((Rectangle)(ref boundingBox)).Intersects(val))
				{
					return character;
				}
			}
		}
		else
		{
			foreach (NPC actor in currentEvent.actors)
			{
				boundingBox = actor.GetBoundingBox();
				if (((Rectangle)(ref boundingBox)).Intersects(val))
				{
					return actor;
				}
			}
		}
		return result;
	}

	public void ResetCharacterDialogues()
	{
		for (int num = characters.Count - 1; num >= 0; num--)
		{
			characters[num].resetCurrentDialogue();
		}
	}

	public string getMapProperty(string propertyName)
	{
		if (!TryGetMapProperty(propertyName, out var propertyValue))
		{
			return null;
		}
		return propertyValue;
	}

	public bool TryGetMapProperty(string propertyName, out string propertyValue)
	{
		Map val = Map;
		if (val == null)
		{
			Game1.log.Warn($"Can't read map property '{propertyName}' for location '{NameOrUniqueName}' because the map is null.");
			propertyValue = null;
			return false;
		}
		if (((Component)val).Properties.TryGetValue(propertyName, out propertyValue))
		{
			return propertyValue != null;
		}
		return false;
	}

	public string[] GetMapPropertySplitBySpaces(string propertyName)
	{
		if (!TryGetMapProperty(propertyName, out var propertyValue) || propertyValue == null)
		{
			return LegacyShims.EmptyArray<string>();
		}
		return ArgUtility.SplitBySpace(propertyValue);
	}

	public bool TryGetMapPropertyAs(string key, out bool parsed, bool required = false)
	{
		if (!TryGetMapProperty(key, out var propertyValue))
		{
			if (required)
			{
				LogMapPropertyError(key, "", "required map property isn't defined");
			}
			parsed = false;
			return false;
		}
		switch (propertyValue)
		{
		case "T":
		case "t":
			parsed = true;
			return true;
		case "F":
		case "f":
			parsed = false;
			return true;
		default:
			if (bool.TryParse(propertyValue, out parsed))
			{
				return true;
			}
			LogMapPropertyError(key, propertyValue, "not a valid boolean value");
			return false;
		}
	}

	public bool TryGetMapPropertyAs(string key, out double parsed, bool required = false)
	{
		if (!TryGetMapProperty(key, out var propertyValue))
		{
			if (required)
			{
				LogMapPropertyError(key, "", "required map property isn't defined");
			}
			parsed = 0.0;
			return false;
		}
		if (!double.TryParse(propertyValue, out parsed))
		{
			LogMapPropertyError(key, propertyValue, "value '" + propertyValue + "' can't be parsed as a decimal value");
			return false;
		}
		return true;
	}

	public bool TryGetMapPropertyAs(string key, out Point parsed, bool required = false)
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces(key);
		if (mapPropertySplitBySpaces.Length == 0)
		{
			if (required)
			{
				LogMapPropertyError(key, "", "required map property isn't defined");
			}
			parsed = Point.Zero;
			return false;
		}
		if (!ArgUtility.TryGetPoint(mapPropertySplitBySpaces, 0, out parsed, out var error, "parsed"))
		{
			LogMapPropertyError(key, mapPropertySplitBySpaces, error);
			parsed = Point.Zero;
			return false;
		}
		return true;
	}

	public bool TryGetMapPropertyAs(string key, out Vector2 parsed, bool required = false)
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces(key);
		if (mapPropertySplitBySpaces.Length == 0)
		{
			if (required)
			{
				LogMapPropertyError(key, "", "required map property isn't defined");
			}
			parsed = Vector2.Zero;
			return false;
		}
		if (!ArgUtility.TryGetVector2(mapPropertySplitBySpaces, 0, out parsed, out var error, integerOnly: false, "parsed"))
		{
			LogMapPropertyError(key, mapPropertySplitBySpaces, error);
			parsed = Vector2.Zero;
			return false;
		}
		return true;
	}

	public bool TryGetMapPropertyAs(string key, out Rectangle parsed, bool required = false)
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces(key);
		if (mapPropertySplitBySpaces.Length == 0)
		{
			if (required)
			{
				LogMapPropertyError(key, "", "required map property isn't defined");
			}
			parsed = Rectangle.Empty;
			return false;
		}
		if (!ArgUtility.TryGetRectangle(mapPropertySplitBySpaces, 0, out parsed, out var error, "parsed"))
		{
			LogMapPropertyError(key, mapPropertySplitBySpaces, error);
			parsed = Rectangle.Empty;
			return false;
		}
		return true;
	}

	public bool HasMapPropertyWithValue(string propertyName)
	{
		if (map != null && ((Component)Map).Properties.TryGetValue(propertyName, out var value))
		{
			if (value == null)
			{
				return false;
			}
			return value.Length > 0;
		}
		return false;
	}

	public virtual void tryToAddCritters(bool onlyIfOnScreen = false)
	{
		if (Game1.CurrentEvent != null)
		{
			return;
		}
		double num = map.Layers[0].LayerWidth * map.Layers[0].LayerHeight;
		double num2 = Math.Max(0.15, Math.Min(0.5, num / 15000.0));
		double chance = num2;
		double chance2 = num2;
		double chance3 = num2 / 2.0;
		double chance4 = num2 / 2.0;
		double chance5 = num2 / 8.0;
		double num3 = num2 * 2.0;
		if (IsRainingHere())
		{
			return;
		}
		addClouds(num3 / (double)(onlyIfOnScreen ? 2f : 1f), onlyIfOnScreen);
		if (!(this is Beach) && critters != null && critters.Count <= (IsSummerHere() ? 20 : 10))
		{
			addBirdies(chance, onlyIfOnScreen);
			addButterflies(chance2, onlyIfOnScreen);
			addBunnies(chance3, onlyIfOnScreen);
			addSquirrels(chance4, onlyIfOnScreen);
			addWoodpecker(chance5, onlyIfOnScreen);
			if (Game1.isDarkOut(this) && Game1.random.NextDouble() < 0.01)
			{
				addOwl();
			}
			if (Game1.isDarkOut(this))
			{
				addOpossums(num2 / 10.0, onlyIfOnScreen);
			}
		}
	}

	public void addClouds(double chance, bool onlyIfOnScreen = false)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		if (!IsSummerHere() || IsRainingHere() || Game1.weatherIcon == 4 || Game1.timeOfDay >= Game1.getStartingToGetDarkTime(this) - 100)
		{
			return;
		}
		while (Game1.random.NextDouble() < Math.Min(0.9, chance))
		{
			Vector2 val = getRandomTile();
			if (onlyIfOnScreen)
			{
				val = (Game1.random.NextBool() ? new Vector2((float)map.Layers[0].LayerWidth, (float)Game1.random.Next(map.Layers[0].LayerHeight)) : new Vector2((float)Game1.random.Next(map.Layers[0].LayerWidth), (float)map.Layers[0].LayerHeight));
			}
			if (!onlyIfOnScreen && Utility.isOnScreen(val * 64f, 1280))
			{
				continue;
			}
			Cloud cloud = new Cloud(val);
			bool flag = true;
			if (critters != null)
			{
				foreach (Critter critter in critters)
				{
					if (critter is Cloud)
					{
						Rectangle boundingBox = critter.getBoundingBox(0, 0);
						if (((Rectangle)(ref boundingBox)).Intersects(cloud.getBoundingBox(0, 0)))
						{
							flag = false;
							break;
						}
					}
				}
			}
			if (flag)
			{
				addCritter(cloud);
			}
		}
	}

	public void addOwl()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		critters.Add(new Owl(new Vector2((float)Game1.random.Next(64, map.Layers[0].LayerWidth * 64 - 64), -128f)));
	}

	public void setFireplace(bool on, int tileLocationX, int tileLocationY, bool playSound = true, int xOffset = 0, int yOffset = 0)
	{
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		int id = 944468 + tileLocationX * 1000 + tileLocationY;
		string text = $"{NameOrUniqueName}_Fireplace_{tileLocationX}_{tileLocationY}";
		if (on)
		{
			if (getTemporarySpriteByID(id) == null)
			{
				temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(276, 1985, 12, 11), new Vector2((float)tileLocationX, (float)tileLocationY) * 64f + new Vector2(32f, -32f) + new Vector2((float)xOffset, (float)yOffset), flipped: false, 0f, Color.White)
				{
					interval = 50f,
					totalNumberOfLoops = 99999,
					animationLength = 4,
					lightId = text + "_1",
					id = id,
					lightRadius = 2f,
					scale = 4f,
					layerDepth = ((float)tileLocationY + 1.1f) * 64f / 10000f
				});
				temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(276, 1985, 12, 11), new Vector2((float)(tileLocationX + 1), (float)tileLocationY) * 64f + new Vector2(-16f, -32f) + new Vector2((float)xOffset, (float)yOffset), flipped: false, 0f, Color.White)
				{
					delayBeforeAnimationStart = 10,
					interval = 50f,
					totalNumberOfLoops = 99999,
					animationLength = 4,
					lightId = text + "_2",
					id = id,
					lightRadius = 2f,
					scale = 4f,
					layerDepth = ((float)tileLocationY + 1.1f) * 64f / 10000f
				});
				if (playSound && Game1.gameMode != 6)
				{
					localSound("fireball");
				}
				AmbientLocationSounds.addSound(new Vector2((float)tileLocationX, (float)tileLocationY), 1);
			}
		}
		else
		{
			removeTemporarySpritesWithID(id);
			Game1.currentLightSources.Remove(text + "_1");
			Game1.currentLightSources.Remove(text + "_2");
			if (playSound)
			{
				localSound("fireball");
			}
			AmbientLocationSounds.removeSound(new Vector2((float)tileLocationX, (float)tileLocationY));
		}
	}

	public void addWoodpecker(double chance, bool onlyIfOnScreen = false)
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.isStartingToGetDarkOut(this) || onlyIfOnScreen || this is Town || this is Desert || !(Game1.random.NextDouble() < chance) || terrainFeatures.Length <= 0)
		{
			return;
		}
		for (int i = 0; i < 3; i++)
		{
			if (Utility.TryGetRandom(terrainFeatures, out var key, out var value) && value is Tree tree)
			{
				WildTreeData data = tree.GetData();
				if (data != null && data.AllowWoodpeckers && tree.growthStage.Value >= 5)
				{
					critters.Add(new Woodpecker(tree, key));
					break;
				}
			}
		}
	}

	public void addSquirrels(double chance, bool onlyIfOnScreen = false)
	{
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.isStartingToGetDarkOut(this) || onlyIfOnScreen || this is Farm || this is Town || this is Desert || !(Game1.random.NextDouble() < chance) || terrainFeatures.Length <= 0)
		{
			return;
		}
		for (int i = 0; i < 3; i++)
		{
			if (!Utility.TryGetRandom(terrainFeatures, out var key, out var value) || !(value is Tree tree) || tree.growthStage.Value < 5 || tree.stump.Value)
			{
				continue;
			}
			int num = Game1.random.Next(4, 7);
			bool flag = Game1.random.NextBool();
			bool flag2 = true;
			for (int j = 0; j < num; j++)
			{
				key.X += (flag ? 1 : (-1));
				if (!CanSpawnCharacterHere(key))
				{
					flag2 = false;
					break;
				}
			}
			if (flag2)
			{
				critters.Add(new Squirrel(key, flag));
				break;
			}
		}
	}

	public void addBunnies(double chance, bool onlyIfOnScreen = false)
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		if (onlyIfOnScreen || this is Farm || this is Desert || !(Game1.random.NextDouble() < chance) || largeTerrainFeatures == null)
		{
			return;
		}
		for (int i = 0; i < 3; i++)
		{
			int index = Game1.random.Next(largeTerrainFeatures.Count);
			if (largeTerrainFeatures.Count <= 0 || !(largeTerrainFeatures[index] is Bush))
			{
				continue;
			}
			Vector2 tile = largeTerrainFeatures[index].Tile;
			int num = Game1.random.Next(5, 12);
			bool flag = Game1.random.NextBool();
			bool flag2 = true;
			for (int j = 0; j < num; j++)
			{
				tile.X += (flag ? 1 : (-1));
				Rectangle boundingBox = largeTerrainFeatures[index].getBoundingBox();
				if (!((Rectangle)(ref boundingBox)).Intersects(new Rectangle((int)tile.X * 64, (int)tile.Y * 64, 64, 64)) && !CanSpawnCharacterHere(tile))
				{
					flag2 = false;
					break;
				}
			}
			if (flag2)
			{
				critters.Add(new Rabbit(this, tile, flag));
				break;
			}
		}
	}

	public void addOpossums(double chance, bool onlyIfOnScreen = false)
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		if (onlyIfOnScreen || this is Farm || this is Desert || !(Game1.random.NextDouble() < chance) || largeTerrainFeatures == null)
		{
			return;
		}
		for (int i = 0; i < 3; i++)
		{
			int index = Game1.random.Next(largeTerrainFeatures.Count);
			if (largeTerrainFeatures.Count <= 0 || !(largeTerrainFeatures[index] is Bush))
			{
				continue;
			}
			Vector2 tile = largeTerrainFeatures[index].Tile;
			int num = Game1.random.Next(5, 12);
			bool flag = Game1.player.Position.X > (float)((this is BusStop) ? 704 : 64);
			bool flag2 = true;
			for (int j = 0; j < num; j++)
			{
				tile.X += (flag ? 1 : (-1));
				Rectangle boundingBox = largeTerrainFeatures[index].getBoundingBox();
				if (!((Rectangle)(ref boundingBox)).Intersects(new Rectangle((int)tile.X * 64, (int)tile.Y * 64, 64, 64)) && !CanSpawnCharacterHere(tile))
				{
					flag2 = false;
					break;
				}
			}
			if (flag2)
			{
				if (this is BusStop && Game1.random.NextDouble() < 0.5)
				{
					((Vector2)(ref tile))._002Ector((float)((Game1.player.Tile.X < 26f) ? 36 : 16), (float)(23 + Game1.random.Next(2)));
				}
				critters.Add(new Opossum(this, tile, flag));
				break;
			}
		}
	}

	public void instantiateCrittersList()
	{
		if (critters == null)
		{
			critters = new List<Critter>();
		}
	}

	public void addCritter(Critter c)
	{
		critters?.Add(c);
	}

	public void addButterflies(double chance, bool onlyIfOnScreen = false)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Invalid comparison between Unknown and I4
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Invalid comparison between Unknown and I4
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Invalid comparison between Unknown and I4
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Invalid comparison between Unknown and I4
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		Season season = GetSeason();
		bool islandButterfly = InIslandContext();
		bool flag = (int)season == 1 && Game1.isDarkOut(this);
		if (Game1.timeOfDay >= 1500 && !flag && (int)season != 3)
		{
			return;
		}
		if ((int)season == 0 || (int)season == 1 || ((int)season == 3 && Game1.dayOfMonth % 7 == 0 && Game1.isDarkOut(this)))
		{
			chance = Math.Min(0.8, chance * 1.5);
			while (Game1.random.NextDouble() < chance)
			{
				Vector2 randomTile = getRandomTile();
				if (onlyIfOnScreen && Utility.isOnScreen(randomTile * 64f, 64))
				{
					continue;
				}
				if (flag)
				{
					critters.Add(new Firefly(randomTile));
				}
				else
				{
					critters.Add(new Butterfly(this, randomTile, islandButterfly));
				}
				while (Game1.random.NextDouble() < 0.4)
				{
					if (flag)
					{
						critters.Add(new Firefly(randomTile + new Vector2((float)Game1.random.Next(-2, 3), (float)Game1.random.Next(-2, 3))));
					}
					else
					{
						critters.Add(new Butterfly(this, randomTile + new Vector2((float)Game1.random.Next(-2, 3), (float)Game1.random.Next(-2, 3)), islandButterfly));
					}
				}
			}
		}
		if (Game1.timeOfDay < 1700)
		{
			tryAddPrismaticButterfly();
		}
	}

	public void tryAddPrismaticButterfly()
	{
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		if (!Game1.player.hasBuff("statue_of_blessings_6"))
		{
			return;
		}
		foreach (Critter critter in critters)
		{
			if (critter is Butterfly { isPrismatic: not false })
			{
				return;
			}
		}
		Random random = Utility.CreateDaySaveRandom(Game1.player.UniqueMultiplayerID % 10000);
		string[] array = new string[7] { "Forest", "Town", "Beach", "Mountain", "Woods", "BusStop", "Backwoods" };
		string text = array[random.Next(array.Length)];
		if (text.Equals("Beach") && Name.Equals("BeachNightMarket"))
		{
			text = "BeachNightMarket";
		}
		if (!Name.Equals(text))
		{
			return;
		}
		Vector2 randomTile = getRandomTile(random);
		for (int i = 0; i < 32; i++)
		{
			if (isTileLocationOpen(randomTile))
			{
				break;
			}
			randomTile = getRandomTile(random);
		}
		critters.Add(new Butterfly(this, randomTile, islandButterfly: false, forceSummerButterfly: false, 394, prismatic: true)
		{
			stayInbounds = true
		});
	}

	public void addBirdies(double chance, bool onlyIfOnScreen = false)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Invalid comparison between Unknown and I4
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Invalid comparison between Unknown and I4
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Invalid comparison between Unknown and I4
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.timeOfDay >= 1500 || this is Desert || this is Railroad || this is Farm)
		{
			return;
		}
		Season season = GetSeason();
		if ((int)season == 1)
		{
			return;
		}
		Rectangle area = default(Rectangle);
		while (Game1.random.NextDouble() < chance)
		{
			int num = Game1.random.Next(1, 4);
			bool flag = false;
			int num2 = 0;
			while (!flag && num2 < 5)
			{
				Vector2 randomTile = getRandomTile();
				if (!onlyIfOnScreen || !Utility.isOnScreen(randomTile * 64f, 64))
				{
					((Rectangle)(ref area))._002Ector((int)randomTile.X - 2, (int)randomTile.Y - 2, 5, 5);
					if (isAreaClear(area))
					{
						List<Critter> list = new List<Critter>();
						int num3 = (((int)season == 2) ? 45 : 25);
						if (Game1.random.NextBool() && Game1.MasterPlayer.mailReceived.Contains("Farm_Eternal"))
						{
							num3 = (((int)season == 2) ? 135 : 125);
						}
						if (num3 == 25 && Game1.random.NextDouble() < 0.05)
						{
							num3 = 165;
						}
						for (int i = 0; i < num; i++)
						{
							list.Add(new Birdie(-100, -100, num3));
						}
						addCrittersStartingAtTile(randomTile, list);
						flag = true;
					}
				}
				num2++;
			}
		}
	}

	public void addJumperFrog(Vector2 tileLocation)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		critters?.Add(new Frog(tileLocation));
	}

	public void addFrog()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		if (!IsRainingHere() || IsWinterHere())
		{
			return;
		}
		for (int i = 0; i < 3; i++)
		{
			Vector2 randomTile = getRandomTile();
			if (!isWaterTile((int)randomTile.X, (int)randomTile.Y) || !isWaterTile((int)randomTile.X, (int)randomTile.Y - 1) || doesTileHaveProperty((int)randomTile.X, (int)randomTile.Y, "Passable", "Buildings") != null)
			{
				continue;
			}
			int num = 10;
			bool flag = Game1.random.NextBool();
			for (int j = 0; j < num; j++)
			{
				randomTile.X += (flag ? 1 : (-1));
				if (isTileOnMap((int)randomTile.X, (int)randomTile.Y) && !isWaterTile((int)randomTile.X, (int)randomTile.Y))
				{
					critters.Add(new Frog(randomTile, waterLeaper: true, flag));
					return;
				}
			}
		}
	}

	public void checkForSpecialCharacterIconAtThisTile(Vector2 tileLocation)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		currentEvent?.checkForSpecialCharacterIconAtThisTile(tileLocation);
	}

	private void addCrittersStartingAtTile(Vector2 tile, List<Critter> crittersToAdd)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		if (crittersToAdd == null)
		{
			return;
		}
		int num = 0;
		HashSet<Vector2> hashSet = new HashSet<Vector2>();
		while (crittersToAdd.Count > 0 && num < 20)
		{
			if (hashSet.Contains(tile))
			{
				tile = Utility.getTranslatedVector2(tile, Game1.random.Next(4), 1f);
			}
			else
			{
				if (CanItemBePlacedHere(tile))
				{
					Critter critter = crittersToAdd.Last();
					critter.position = tile * 64f;
					critter.startingPosition = tile * 64f;
					critters.Add(critter);
					crittersToAdd.RemoveAt(crittersToAdd.Count - 1);
				}
				tile = Utility.getTranslatedVector2(tile, Game1.random.Next(4), 1f);
				hashSet.Add(tile);
			}
			num++;
		}
	}

	public bool isAreaClear(Rectangle area)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		foreach (Vector2 vector in area.GetVectors())
		{
			if (!CanItemBePlacedHere(vector))
			{
				return false;
			}
		}
		return true;
	}

	public void performGreenRainUpdate()
	{
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0327: Unknown result type (might be due to invalid IL or missing references)
		//IL_032c: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_035d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0369: Unknown result type (might be due to invalid IL or missing references)
		//IL_036e: Unknown result type (might be due to invalid IL or missing references)
		//IL_037f: Unknown result type (might be due to invalid IL or missing references)
		//IL_038b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0390: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d4: Unknown result type (might be due to invalid IL or missing references)
		if (!IsGreenRainingHere() || !IsOutdoors || !(GetData()?.CanHaveGreenRainSpawns ?? true))
		{
			return;
		}
		Layer layer = map.GetLayer("Paths");
		if (layer != null)
		{
			Vector2 val2 = default(Vector2);
			for (int i = 0; i < layer.LayerWidth; i++)
			{
				for (int j = 0; j < layer.LayerHeight; j++)
				{
					Tile val = layer.Tiles[i, j];
					if (val != null && ((IDictionary<string, PropertyValue>)val.TileIndexProperties).ContainsKey("GreenRain"))
					{
						((Vector2)(ref val2))._002Ector((float)i, (float)j);
						if (!IsTileOccupiedBy(val2))
						{
							terrainFeatures.Add(val2, (this is Forest) ? new Tree("12", 5, isGreenRainTemporaryTree: true) : new Tree((10 + (Game1.random.NextBool(0.1) ? 2 : Game1.random.Choose(1, 0))).ToString(), 5, isGreenRainTemporaryTree: true));
						}
					}
				}
			}
		}
		if (this is Town)
		{
			return;
		}
		string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces("Trees");
		for (int k = 0; k < mapPropertySplitBySpaces.Length; k += 3)
		{
			if (!ArgUtility.TryGetVector2(mapPropertySplitBySpaces, k, out var value, out var error, integerOnly: false, "Vector2 position") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces, k + 2, out var value2, out error, "int treeType"))
			{
				LogMapPropertyError("Trees", mapPropertySplitBySpaces, error);
				continue;
			}
			float chance = (IsFarm ? 0.5f : 1f);
			if (Game1.random.NextBool(chance) && !IsTileOccupiedBy(value))
			{
				terrainFeatures.Add(value, new Tree((value2 + 1).ToString(), 5));
			}
		}
		TerrainFeature[] array = terrainFeatures.Values.ToArray();
		for (int l = 0; l < array.Length; l++)
		{
			if (array[l] is Tree tree)
			{
				tree.onGreenRainDay();
			}
		}
		int num = map.Layers[0].LayerWidth * map.Layers[0].LayerHeight;
		spawnWeedsAndStones(num / 16, weedsOnly: true, spawnFromOldWeeds: false);
		spawnWeedsAndStones(num / 8, weedsOnly: true);
		for (int m = 0; m < num / 4; m++)
		{
			Vector2 randomTile = getRandomTile();
			if (objects.TryGetValue(randomTile, out var value3) && value3.IsWeeds() && objects.TryGetValue(randomTile + new Vector2(1f, 0f), out var value4) && value4.IsWeeds() && objects.TryGetValue(randomTile + new Vector2(1f, 1f), out var value5) && value5.IsWeeds() && objects.TryGetValue(randomTile + new Vector2(0f, 1f), out var value6) && value6.IsWeeds())
			{
				objects.Remove(randomTile);
				objects.Remove(randomTile + new Vector2(1f, 0f));
				objects.Remove(randomTile + new Vector2(1f, 1f));
				objects.Remove(randomTile + new Vector2(0f, 1f));
				resourceClumps.Add(new ResourceClump(44 + Game1.random.Choose(2, 0), 2, 2, randomTile, 4, "TileSheets\\Objects_2"));
			}
		}
	}

	public void performDayAfterGreenRainUpdate()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		KeyValuePair<Vector2, Object>[] array = objects.Pairs.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			KeyValuePair<Vector2, Object> keyValuePair = array[i];
			if (keyValuePair.Value.Name.Contains("GreenRainWeeds"))
			{
				objects.Remove(keyValuePair.Key);
			}
		}
		resourceClumps.RemoveWhere((ResourceClump clump) => clump.IsGreenRainBush());
		KeyValuePair<Vector2, TerrainFeature>[] array2 = terrainFeatures.Pairs.ToArray();
		for (int i = 0; i < array2.Length; i++)
		{
			KeyValuePair<Vector2, TerrainFeature> keyValuePair2 = array2[i];
			if (!(keyValuePair2.Value is Tree tree))
			{
				continue;
			}
			if (this is Town)
			{
				if (tree.isTemporaryGreenRainTree.Value)
				{
					terrainFeatures.Remove(keyValuePair2.Key);
				}
			}
			else
			{
				tree.onGreenRainDay(undo: true);
			}
		}
	}

	public Vector2 getRandomTile(Random r = null)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		if (r == null)
		{
			r = Game1.random;
		}
		return new Vector2((float)r.Next(Map.Layers[0].LayerWidth), (float)r.Next(Map.Layers[0].LayerHeight));
	}

	public void setUpLocationSpecificFlair()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_050c: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0805: Unknown result type (might be due to invalid IL or missing references)
		//IL_080a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0845: Unknown result type (might be due to invalid IL or missing references)
		//IL_084a: Unknown result type (might be due to invalid IL or missing references)
		//IL_085a: Unknown result type (might be due to invalid IL or missing references)
		//IL_085f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0870: Unknown result type (might be due to invalid IL or missing references)
		//IL_087e: Unknown result type (might be due to invalid IL or missing references)
		//IL_088c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0891: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_08dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_090a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0918: Unknown result type (might be due to invalid IL or missing references)
		//IL_0926: Unknown result type (might be due to invalid IL or missing references)
		//IL_092b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0966: Unknown result type (might be due to invalid IL or missing references)
		//IL_096b: Unknown result type (might be due to invalid IL or missing references)
		//IL_097b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0980: Unknown result type (might be due to invalid IL or missing references)
		//IL_0999: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_09af: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_09fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a0f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a14: Unknown result type (might be due to invalid IL or missing references)
		//IL_0514: Unknown result type (might be due to invalid IL or missing references)
		//IL_0519: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bb0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_14c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_14cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_044e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0468: Unknown result type (might be due to invalid IL or missing references)
		//IL_0472: Unknown result type (might be due to invalid IL or missing references)
		//IL_0483: Unknown result type (might be due to invalid IL or missing references)
		//IL_053b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0576: Unknown result type (might be due to invalid IL or missing references)
		//IL_0585: Unknown result type (might be due to invalid IL or missing references)
		//IL_0590: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0602: Unknown result type (might be due to invalid IL or missing references)
		//IL_065a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0669: Unknown result type (might be due to invalid IL or missing references)
		//IL_0674: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a49: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a53: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bfe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c0c: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1741: Unknown result type (might be due to invalid IL or missing references)
		//IL_1746: Unknown result type (might be due to invalid IL or missing references)
		//IL_0520: Unknown result type (might be due to invalid IL or missing references)
		//IL_0525: Unknown result type (might be due to invalid IL or missing references)
		//IL_1867: Unknown result type (might be due to invalid IL or missing references)
		//IL_186c: Unknown result type (might be due to invalid IL or missing references)
		//IL_14a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0743: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cbd: Unknown result type (might be due to invalid IL or missing references)
		//IL_17ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_17b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f84: Unknown result type (might be due to invalid IL or missing references)
		//IL_1954: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f6e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f73: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f79: Unknown result type (might be due to invalid IL or missing references)
		//IL_1eb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1eb9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ed0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ed5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1efb: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f05: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f14: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f23: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f28: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0abf: Unknown result type (might be due to invalid IL or missing references)
		//IL_1180: Unknown result type (might be due to invalid IL or missing references)
		//IL_1185: Unknown result type (might be due to invalid IL or missing references)
		//IL_119c: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_11c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_11d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_11e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_11f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_10a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_10ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_10c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_10c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_10ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_10f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1106: Unknown result type (might be due to invalid IL or missing references)
		//IL_1110: Unknown result type (might be due to invalid IL or missing references)
		//IL_1115: Unknown result type (might be due to invalid IL or missing references)
		//IL_111a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d22: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d27: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a8d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a92: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aa9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aae: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ad4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ade: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aed: Unknown result type (might be due to invalid IL or missing references)
		//IL_1af7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1afc: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b01: Unknown result type (might be due to invalid IL or missing references)
		//IL_0767: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fa1: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fbb: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fc5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fd4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fde: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fe3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ff4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aed: Unknown result type (might be due to invalid IL or missing references)
		//IL_125a: Unknown result type (might be due to invalid IL or missing references)
		//IL_125f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1276: Unknown result type (might be due to invalid IL or missing references)
		//IL_127b: Unknown result type (might be due to invalid IL or missing references)
		//IL_12a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_12ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_12ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_12c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_12c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_12ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e51: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e56: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e72: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e98: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ea2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eb1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ebb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b11: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1334: Unknown result type (might be due to invalid IL or missing references)
		//IL_1339: Unknown result type (might be due to invalid IL or missing references)
		//IL_1350: Unknown result type (might be due to invalid IL or missing references)
		//IL_1355: Unknown result type (might be due to invalid IL or missing references)
		//IL_137b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1385: Unknown result type (might be due to invalid IL or missing references)
		//IL_1394: Unknown result type (might be due to invalid IL or missing references)
		//IL_139e: Unknown result type (might be due to invalid IL or missing references)
		//IL_13a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_13a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b89: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ba5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1baa: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bd0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bda: Unknown result type (might be due to invalid IL or missing references)
		//IL_1be9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bf3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bf8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bfd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b44: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b4e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b71: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b76: Unknown result type (might be due to invalid IL or missing references)
		//IL_158e: Unknown result type (might be due to invalid IL or missing references)
		indoorLightingColor = new Color(100, 120, 30);
		indoorLightingNightColor = new Color(150, 150, 30);
		if (TryGetAmbientLightFromMap(out var color))
		{
			if (color == Color.White)
			{
				color = Color.Black;
			}
			indoorLightingColor = color;
			if (TryGetAmbientLightFromMap(out var color2, "AmbientNightLight"))
			{
				indoorLightingNightColor = color2;
			}
			else
			{
				indoorLightingNightColor = indoorLightingColor;
			}
		}
		if (!isOutdoors.Value && !(this is FarmHouse) && !(this is IslandFarmHouse))
		{
			Game1.ambientLight = indoorLightingColor;
		}
		Game1.screenGlow = false;
		if (!IsOutdoors && IsGreenRainingHere() && !InIslandContext() && IsRainingHere())
		{
			indoorLightingColor = new Color(123, 0, 96);
			indoorLightingNightColor = new Color(185, 40, 119);
			Game1.screenGlowOnce(new Color(0, 255, 50) * 0.5f, hold: true, 1f);
		}
		string value = name.Value;
		if (value == null)
		{
			return;
		}
		switch (value.Length)
		{
		case 9:
			switch (value[0])
			{
			case 'J':
				if (value == "JoshHouse" && Game1.isGreenRain)
				{
					temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors_1_6", new Rectangle(386, 334, 36, 28), 40f, 3, 999999, new Vector2(246.5f, 317f) * 4f, flicker: false, flipped: false, 0.136001f, 0f, Color.White, 2f, 0f, 0f, 0f));
				}
				break;
			case 'Q':
				if (value == "QiNutRoom")
				{
					Game1.ambientLight = indoorLightingColor;
				}
				break;
			case 'L':
				if (value == "LeahHouse")
				{
					NPC characterFromName10 = Game1.getCharacterFromName("Leah");
					if (IsFallHere() || IsWinterHere() || IsRainingHere())
					{
						setFireplace(on: true, 11, 4, playSound: false);
					}
					if (characterFromName10 != null && characterFromName10.currentLocation == this && !characterFromName10.isDivorcedFrom(Game1.player))
					{
						string path7 = Game1.random.Next(3) switch
						{
							0 => "Strings\\SpeechBubbles:LeahHouse_Leah_Greeting1", 
							1 => "Strings\\SpeechBubbles:LeahHouse_Leah_Greeting2", 
							_ => "Strings\\SpeechBubbles:LeahHouse_Leah_Greeting3", 
						};
						characterFromName10.faceTowardFarmerForPeriod(3000, 15, faceAway: false, Game1.player);
						characterFromName10.showTextAboveHead(Game1.content.LoadString(path7, Game1.player.Name));
					}
				}
				break;
			}
			break;
		case 6:
			switch (value[1])
			{
			case 'u':
				if (value == "Summit")
				{
					Game1.ambientLight = Color.Black;
				}
				break;
			case 'a':
				if (!(value == "Saloon"))
				{
					break;
				}
				if (Game1.timeOfDay >= 1700 || IsGreenRainingHere())
				{
					setFireplace(on: true, 22, 17, playSound: false);
				}
				if (Game1.random.NextDouble() < 0.25)
				{
					NPC characterFromName12 = Game1.getCharacterFromName("Gus");
					if (characterFromName12 != null && characterFromName12.TilePoint.Y == 18 && characterFromName12.currentLocation == this)
					{
						string text4 = Game1.random.Next(5) switch
						{
							0 => "Greeting", 
							1 => IsSummerHere() ? "Summer" : "NotSummer", 
							2 => IsSnowingHere() ? "Snowing1" : "NotSnowing1", 
							3 => IsRainingHere() ? "Raining" : "NotRaining", 
							_ => IsSnowingHere() ? "Snowing2" : "NotSnowing2", 
						};
						if (Game1.random.NextDouble() < 0.001)
						{
							text4 = "RareGreeting";
						}
						characterFromName12.showTextAboveHead(Game1.content.LoadString("Strings\\SpeechBubbles:Saloon_Gus_" + text4));
					}
				}
				if (getCharacterFromName("Gus") == null && Game1.IsVisitingIslandToday("Gus"))
				{
					temporarySprites.Add(new TemporaryAnimatedSprite
					{
						texture = Game1.mouseCursors2,
						sourceRect = new Rectangle(129, 210, 13, 16),
						animationLength = 1,
						sourceRectStartingPos = new Vector2(129f, 210f),
						interval = 50000f,
						totalNumberOfLoops = 9999,
						position = new Vector2(11f, 18f) * 64f + new Vector2(3f, 0f) * 4f,
						scale = 4f,
						layerDepth = 0.1281f,
						id = 777
					});
				}
				if (Game1.dayOfMonth % 7 == 0 && NetWorldState.checkAnywhereForWorldStateID("saloonSportsRoom") && Game1.timeOfDay < 1500)
				{
					Texture2D texture = Game1.temporaryContent.Load<Texture2D>("LooseSprites\\temporary_sprites_1");
					TemporarySprites.Add(new TemporaryAnimatedSprite
					{
						texture = texture,
						sourceRect = new Rectangle(368, 336, 19, 14),
						animationLength = 7,
						sourceRectStartingPos = new Vector2(368f, 336f),
						interval = 5000f,
						totalNumberOfLoops = 99999,
						position = new Vector2(34f, 3f) * 64f + new Vector2(7f, 13f) * 4f,
						scale = 4f,
						layerDepth = 0.0401f,
						id = 2400
					});
				}
				break;
			}
			break;
		case 12:
			switch (value[0])
			{
			case 'L':
				if (value == "LeoTreeHouse")
				{
					temporarySprites.Add(new EmilysParrot(new Vector2(88f, 224f))
					{
						layerDepth = 1f,
						id = 5858585
					});
					temporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\critters", new Rectangle(71, 334, 12, 11), new Vector2(304f, 32f), flipped: false, 0f, Color.White)
					{
						layerDepth = 0.001f,
						interval = 700f,
						animationLength = 3,
						totalNumberOfLoops = 999999,
						scale = 4f
					});
					temporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\critters", new Rectangle(47, 334, 12, 11), new Vector2(112f, -25.6f), flipped: true, 0f, Color.White)
					{
						layerDepth = 0.001f,
						interval = 300f,
						animationLength = 3,
						totalNumberOfLoops = 999999,
						scale = 4f
					});
					temporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\critters", new Rectangle(71, 334, 12, 11), new Vector2(224f, -25.6f), flipped: false, 0f, Color.White)
					{
						layerDepth = 0.001f,
						interval = 800f,
						animationLength = 3,
						totalNumberOfLoops = 999999,
						scale = 4f
					});
				}
				break;
			case 'S':
				if (!(value == "ScienceHouse"))
				{
					break;
				}
				if (Game1.random.NextBool() && Game1.player.currentLocation != null && Game1.player.currentLocation.isOutdoors.Value)
				{
					NPC characterFromName3 = Game1.getCharacterFromName("Robin");
					if (characterFromName3 != null && characterFromName3.TilePoint.Y == 18)
					{
						string path2 = Game1.random.Next(5) switch
						{
							0 => IsRainingHere() ? "Strings\\SpeechBubbles:ScienceHouse_Robin_Raining1" : "Strings\\SpeechBubbles:ScienceHouse_Robin_NotRaining1", 
							1 => IsSnowingHere() ? "Strings\\SpeechBubbles:ScienceHouse_Robin_Snowing" : "Strings\\SpeechBubbles:ScienceHouse_Robin_NotSnowing", 
							2 => (Game1.player.getFriendshipHeartLevelForNPC("Robin") > 4) ? "Strings\\SpeechBubbles:ScienceHouse_Robin_CloseFriends" : "Strings\\SpeechBubbles:ScienceHouse_Robin_NotCloseFriends", 
							3 => IsRainingHere() ? "Strings\\SpeechBubbles:ScienceHouse_Robin_Raining2" : "Strings\\SpeechBubbles:ScienceHouse_Robin_NotRaining2", 
							_ => "Strings\\SpeechBubbles:ScienceHouse_Robin_Greeting", 
						};
						if (Game1.random.NextDouble() < 0.001)
						{
							path2 = "Strings\\SpeechBubbles:ScienceHouse_Robin_RareGreeting";
						}
						characterFromName3.showTextAboveHead(Game1.content.LoadString(path2, Game1.player.Name));
					}
				}
				if (getCharacterFromName("Robin") == null && Game1.IsVisitingIslandToday("Robin"))
				{
					temporarySprites.Add(new TemporaryAnimatedSprite
					{
						texture = Game1.mouseCursors2,
						sourceRect = new Rectangle(129, 210, 13, 16),
						animationLength = 1,
						sourceRectStartingPos = new Vector2(129f, 210f),
						interval = 50000f,
						totalNumberOfLoops = 9999,
						position = new Vector2(7f, 18f) * 64f + new Vector2(3f, 0f) * 4f,
						scale = 4f,
						layerDepth = 0.1281f,
						id = 777
					});
				}
				break;
			case 'E':
				if (value == "ElliottHouse")
				{
					NPC characterFromName2 = Game1.getCharacterFromName("Elliott");
					if (characterFromName2 != null && characterFromName2.currentLocation == this && !characterFromName2.isDivorcedFrom(Game1.player))
					{
						string path = Game1.random.Next(3) switch
						{
							0 => "Strings\\SpeechBubbles:ElliottHouse_Elliott_Greeting1", 
							1 => "Strings\\SpeechBubbles:ElliottHouse_Elliott_Greeting2", 
							_ => "Strings\\SpeechBubbles:ElliottHouse_Elliott_Greeting3", 
						};
						characterFromName2.faceTowardFarmerForPeriod(3000, 15, faceAway: false, Game1.player);
						characterFromName2.showTextAboveHead(Game1.content.LoadString(path, Game1.player.Name));
					}
				}
				break;
			}
			break;
		case 7:
			switch (value[0])
			{
			case 'S':
				if (!(value == "Sunroom"))
				{
					break;
				}
				indoorLightingColor = new Color(0, 0, 0);
				AmbientLocationSounds.addSound(new Vector2(3f, 4f), 0);
				if (largeTerrainFeatures.Count == 0)
				{
					Bush bush = new Bush(new Vector2(6f, 7f), 3, this, -999);
					bush.loadSprite();
					bush.health = 99f;
					largeTerrainFeatures.Add(bush);
				}
				if (!IsRainingHere())
				{
					critters = new List<Critter>();
					critters.Add(new Butterfly(this, getRandomTile()).setStayInbounds(stayInbounds: true));
					while (Game1.random.NextBool())
					{
						critters.Add(new Butterfly(this, getRandomTile()).setStayInbounds(stayInbounds: true));
					}
				}
				break;
			case 'B':
				if (!(value == "BugLand"))
				{
					break;
				}
				if (!Game1.player.hasDarkTalisman && CanItemBePlacedHere(new Vector2(31f, 5f)))
				{
					overlayObjects.Add(new Vector2(31f, 5f), new Chest(new List<Item>
					{
						new SpecialItem(6)
					}, new Vector2(31f, 5f))
					{
						Tint = Color.Gray
					});
				}
				{
					foreach (NPC character in characters)
					{
						if (!(character is Grub grub))
						{
							if (character is Fly fly)
							{
								fly.setHard();
							}
						}
						else
						{
							grub.setHard();
						}
					}
					break;
				}
			}
			break;
		case 8:
			switch (value[0])
			{
			case 'W':
				if (value == "WitchHut" && Game1.player.mailReceived.Contains("cursed_doll") && !farmers.Any())
				{
					characters.Clear();
					uint num = Game1.stats.Get("childrenTurnedToDoves");
					addCharacter(new Bat(new Vector2(7f, 6f) * 64f, -666));
					if (num > 1)
					{
						addCharacter(new Bat(new Vector2(4f, 7f) * 64f, -666));
					}
					if (num > 2)
					{
						addCharacter(new Bat(new Vector2(10f, 7f) * 64f, -666));
					}
					for (int i = 4; i <= num; i++)
					{
						addCharacter(new Bat(Utility.getRandomPositionInThisRectangle(new Rectangle(1, 4, 13, 4), Game1.random) * 64f + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-32, 32)), -666));
					}
				}
				break;
			case 'H':
			{
				if (!(value == "Hospital"))
				{
					break;
				}
				indoorLightingColor = new Color(100, 100, 60);
				if (!Game1.random.NextBool())
				{
					break;
				}
				NPC characterFromName8 = Game1.getCharacterFromName("Maru");
				if (characterFromName8 != null && characterFromName8.currentLocation == this && !characterFromName8.isDivorcedFrom(Game1.player))
				{
					string path5 = Game1.random.Next(5) switch
					{
						0 => "Strings\\SpeechBubbles:Hospital_Maru_Greeting1", 
						1 => "Strings\\SpeechBubbles:Hospital_Maru_Greeting2", 
						2 => "Strings\\SpeechBubbles:Hospital_Maru_Greeting3", 
						3 => "Strings\\SpeechBubbles:Hospital_Maru_Greeting4", 
						_ => "Strings\\SpeechBubbles:Hospital_Maru_Greeting5", 
					};
					if (Game1.player.spouse == "Maru")
					{
						path5 = "Strings\\SpeechBubbles:Hospital_Maru_Spouse";
						characterFromName8.showTextAboveHead(Game1.content.LoadString(path5), SpriteText.color_Red);
					}
					else
					{
						characterFromName8.showTextAboveHead(Game1.content.LoadString(path5));
					}
				}
				break;
			}
			case 'J':
				if (!(value == "JojaMart"))
				{
					break;
				}
				indoorLightingColor = new Color(0, 0, 0);
				if (Game1.random.NextBool())
				{
					NPC characterFromName9 = Game1.getCharacterFromName("Morris");
					if (characterFromName9 != null && characterFromName9.currentLocation == this)
					{
						string path6 = "Strings\\SpeechBubbles:JojaMart_Morris_Greeting";
						characterFromName9.showTextAboveHead(Game1.content.LoadString(path6));
					}
				}
				break;
			case 'S':
				if (!(value == "SeedShop"))
				{
					break;
				}
				setFireplace(on: true, 25, 13, playSound: false);
				if (Game1.random.NextBool() && Game1.player.TilePoint.Y > 10)
				{
					NPC characterFromName7 = Game1.getCharacterFromName("Pierre");
					if (characterFromName7 != null && characterFromName7.TilePoint.Y == 17 && characterFromName7.currentLocation == this)
					{
						string text3 = Game1.random.Next(5) switch
						{
							0 => IsWinterHere() ? "Winter" : "NotWinter", 
							1 => IsSummerHere() ? "Summer" : "NotSummer", 
							2 => "Greeting1", 
							3 => "Greeting2", 
							_ => IsRainingHere() ? "Raining" : "NotRaining", 
						};
						if (Game1.random.NextDouble() < 0.001)
						{
							text3 = "RareGreeting";
						}
						string format = Game1.content.LoadString("Strings\\SpeechBubbles:SeedShop_Pierre_" + text3);
						characterFromName7.showTextAboveHead(string.Format(format, Game1.player.Name));
					}
				}
				if (getCharacterFromName("Pierre") == null && Game1.IsVisitingIslandToday("Pierre"))
				{
					temporarySprites.Add(new TemporaryAnimatedSprite
					{
						texture = Game1.mouseCursors2,
						sourceRect = new Rectangle(129, 210, 13, 16),
						animationLength = 1,
						sourceRectStartingPos = new Vector2(129f, 210f),
						interval = 50000f,
						totalNumberOfLoops = 9999,
						position = new Vector2(5f, 17f) * 64f + new Vector2(3f, 0f) * 4f,
						scale = 4f,
						layerDepth = 0.1217f,
						id = 777
					});
				}
				if (getCharacterFromName("Abigail") != null)
				{
					Point tilePoint = getCharacterFromName("Abigail").TilePoint;
					if (((Point)(ref tilePoint)).Equals(new Point(3, 6)))
					{
						temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(167, 1714, 19, 14), 100f, 3, 999999, new Vector2(2f, 3f) * 64f + new Vector2(7f, 12f) * 4f, flicker: false, flipped: false, 0.0002f, 0f, Color.White, 4f, 0f, 0f, 0f)
						{
							id = 688
						});
					}
				}
				break;
			}
			break;
		case 10:
			switch (value[0])
			{
			case 'H':
				if (value == "HaleyHouse" && Game1.player.eventsSeen.Contains("463391") && Game1.player.spouse != "Emily")
				{
					temporarySprites.Add(new EmilysParrot(new Vector2(912f, 160f)));
				}
				break;
			case 'A':
				if (!(value == "AnimalShop"))
				{
					break;
				}
				setFireplace(on: true, 3, 14, playSound: false);
				if (Game1.random.NextBool())
				{
					NPC characterFromName6 = Game1.getCharacterFromName("Marnie");
					if (characterFromName6 != null && characterFromName6.TilePoint.Y == 14)
					{
						string path4 = Game1.random.Next(5) switch
						{
							0 => "Strings\\SpeechBubbles:AnimalShop_Marnie_Greeting1", 
							1 => "Strings\\SpeechBubbles:AnimalShop_Marnie_Greeting2", 
							2 => (Game1.player.getFriendshipHeartLevelForNPC("Marnie") > 4) ? "Strings\\SpeechBubbles:AnimalShop_Marnie_CloseFriends" : "Strings\\SpeechBubbles:AnimalShop_Marnie_NotCloseFriends", 
							3 => IsRainingHere() ? "Strings\\SpeechBubbles:AnimalShop_Marnie_Raining" : "Strings\\SpeechBubbles:AnimalShop_Marnie_NotRaining", 
							_ => "Strings\\SpeechBubbles:AnimalShop_Marnie_Greeting3", 
						};
						if (Game1.random.NextDouble() < 0.001)
						{
							path4 = "Strings\\SpeechBubbles:AnimalShop_Marnie_RareGreeting";
						}
						characterFromName6.showTextAboveHead(Game1.content.LoadString(path4, Game1.player.Name, Game1.player.farmName));
					}
				}
				if (getCharacterFromName("Marnie") == null && Game1.IsVisitingIslandToday("Marnie"))
				{
					temporarySprites.Add(new TemporaryAnimatedSprite
					{
						texture = Game1.mouseCursors2,
						sourceRect = new Rectangle(129, 210, 13, 16),
						animationLength = 1,
						sourceRectStartingPos = new Vector2(129f, 210f),
						interval = 50000f,
						totalNumberOfLoops = 9999,
						position = new Vector2(13f, 14f) * 64f + new Vector2(3f, 0f) * 4f,
						scale = 4f,
						layerDepth = 0.1025f,
						id = 777
					});
				}
				if (Game1.netWorldState.Value.hasWorldStateID("m_painting0"))
				{
					temporarySprites.Add(new TemporaryAnimatedSprite
					{
						texture = Game1.mouseCursors,
						sourceRect = new Rectangle(25, 1925, 25, 23),
						animationLength = 1,
						sourceRectStartingPos = new Vector2(25f, 1925f),
						interval = 5000f,
						totalNumberOfLoops = 9999,
						position = new Vector2(16f, 1f) * 64f + new Vector2(3f, 1f) * 4f,
						scale = 4f,
						layerDepth = 0.1f,
						id = 777
					});
				}
				else if (Game1.netWorldState.Value.hasWorldStateID("m_painting1"))
				{
					temporarySprites.Add(new TemporaryAnimatedSprite
					{
						texture = Game1.mouseCursors,
						sourceRect = new Rectangle(0, 1925, 25, 23),
						animationLength = 1,
						sourceRectStartingPos = new Vector2(0f, 1925f),
						interval = 5000f,
						totalNumberOfLoops = 9999,
						position = new Vector2(16f, 1f) * 64f + new Vector2(3f, 1f) * 4f,
						scale = 4f,
						layerDepth = 0.1f,
						id = 777
					});
				}
				else if (Game1.netWorldState.Value.hasWorldStateID("m_painting2"))
				{
					temporarySprites.Add(new TemporaryAnimatedSprite
					{
						texture = Game1.mouseCursors,
						sourceRect = new Rectangle(0, 1948, 25, 24),
						animationLength = 1,
						sourceRectStartingPos = new Vector2(0f, 1948f),
						interval = 5000f,
						totalNumberOfLoops = 9999,
						position = new Vector2(16f, 1f) * 64f + new Vector2(3f, 1f) * 4f,
						scale = 4f,
						layerDepth = 0.1f,
						id = 777
					});
				}
				break;
			case 'B':
				if (value == "Blacksmith")
				{
					AmbientLocationSounds.addSound(new Vector2(9f, 10f), 2);
					AmbientLocationSounds.changeSpecificVariable("Frequency", 2f, 2);
				}
				break;
			case 'S':
				if (!(value == "SandyHouse"))
				{
					break;
				}
				indoorLightingColor = new Color(0, 0, 0);
				if (Game1.random.NextBool())
				{
					NPC characterFromName4 = Game1.getCharacterFromName("Sandy");
					if (characterFromName4 != null && characterFromName4.currentLocation == this)
					{
						string path3 = Game1.random.Next(5) switch
						{
							0 => "Strings\\SpeechBubbles:SandyHouse_Sandy_Greeting1", 
							1 => "Strings\\SpeechBubbles:SandyHouse_Sandy_Greeting2", 
							2 => "Strings\\SpeechBubbles:SandyHouse_Sandy_Greeting3", 
							3 => "Strings\\SpeechBubbles:SandyHouse_Sandy_Greeting4", 
							_ => "Strings\\SpeechBubbles:SandyHouse_Sandy_Greeting5", 
						};
						characterFromName4.showTextAboveHead(Game1.content.LoadString(path3));
					}
				}
				break;
			case 'M':
				if (value == "ManorHouse")
				{
					indoorLightingColor = new Color(150, 120, 50);
					NPC characterFromName5 = Game1.getCharacterFromName("Lewis");
					if (characterFromName5 != null && characterFromName5.currentLocation == this)
					{
						string text2 = ((Game1.timeOfDay < 1200) ? "Morning" : ((Game1.timeOfDay < 1700) ? "Afternoon" : "Evening"));
						characterFromName5.faceTowardFarmerForPeriod(3000, 15, faceAway: false, Game1.player);
						characterFromName5.showTextAboveHead(Game1.content.LoadString("Strings\\SpeechBubbles:ManorHouse_Lewis_" + text2));
					}
				}
				break;
			case 'G':
				if (value == "Greenhouse" && Game1.isDarkOut(this))
				{
					Game1.ambientLight = Game1.outdoorLight;
				}
				break;
			}
			break;
		case 13:
			if (value == "LewisBasement")
			{
				if (farmers.Count == 0)
				{
					characters.Clear();
				}
				Vector2 val2 = default(Vector2);
				((Vector2)(ref val2))._002Ector(17f, 15f);
				overlayObjects.Remove(val2);
				Object obj = ItemRegistry.Create<Object>("(O)789");
				obj.questItem.Value = true;
				obj.TileLocation = val2;
				obj.IsSpawnedObject = true;
				overlayObjects.Add(val2, obj);
			}
			break;
		case 17:
			if (value == "AbandonedJojaMart" && !Game1.MasterPlayer.hasOrWillReceiveMail("ccMovieTheater"))
			{
				Point val = default(Point);
				((Point)(ref val))._002Ector(8, 8);
				Game1.currentLightSources.Add(new LightSource("AbandonedJojaMart", 4, new Vector2((float)(val.X * 64), (float)(val.Y * 64)), 1f, LightSource.LightContext.None, 0L, NameOrUniqueName));
				temporarySprites.Add(new TemporaryAnimatedSprite(6, new Vector2((float)(val.X * 64), (float)(val.Y * 64)), Color.White)
				{
					layerDepth = 1f,
					interval = 50f,
					motion = new Vector2(1f, 0f),
					acceleration = new Vector2(-0.005f, 0f)
				});
				temporarySprites.Add(new TemporaryAnimatedSprite(6, new Vector2((float)(val.X * 64 - 12), (float)(val.Y * 64 - 12)), Color.White)
				{
					scale = 0.75f,
					layerDepth = 1f,
					interval = 50f,
					motion = new Vector2(1f, 0f),
					acceleration = new Vector2(-0.005f, 0f),
					delayBeforeAnimationStart = 50
				});
				temporarySprites.Add(new TemporaryAnimatedSprite(6, new Vector2((float)(val.X * 64 - 12), (float)(val.Y * 64 + 12)), Color.White)
				{
					layerDepth = 1f,
					interval = 50f,
					motion = new Vector2(1f, 0f),
					acceleration = new Vector2(-0.005f, 0f),
					delayBeforeAnimationStart = 100
				});
				temporarySprites.Add(new TemporaryAnimatedSprite(6, new Vector2((float)(val.X * 64), (float)(val.Y * 64)), Color.White)
				{
					layerDepth = 1f,
					scale = 0.75f,
					interval = 50f,
					motion = new Vector2(1f, 0f),
					acceleration = new Vector2(-0.005f, 0f),
					delayBeforeAnimationStart = 150
				});
				if (characters.Count == 0)
				{
					characters.Add(new Junimo(new Vector2(8f, 7f) * 64f, 6));
				}
			}
			break;
		case 15:
			if (value == "CommunityCenter" && this is CommunityCenter && (Game1.isLocationAccessible("CommunityCenter") || currentEvent?.id == "191393"))
			{
				setFireplace(on: true, 31, 8, playSound: false);
				setFireplace(on: true, 32, 8, playSound: false);
				setFireplace(on: true, 33, 8, playSound: false);
			}
			break;
		case 14:
			if (!(value == "AdventureGuild"))
			{
				break;
			}
			setFireplace(on: true, 9, 11, playSound: false);
			if (Game1.random.NextBool())
			{
				NPC characterFromName11 = Game1.getCharacterFromName("Marlon");
				if (characterFromName11 != null)
				{
					string path8 = Game1.random.Next(5) switch
					{
						0 => "Strings\\SpeechBubbles:AdventureGuild_Marlon_Greeting_" + (Game1.player.IsMale ? "Male" : "Female"), 
						1 => "Strings\\SpeechBubbles:AdventureGuild_Marlon_Greeting1", 
						2 => "Strings\\SpeechBubbles:AdventureGuild_Marlon_Greeting2", 
						3 => "Strings\\SpeechBubbles:AdventureGuild_Marlon_Greeting3", 
						_ => "Strings\\SpeechBubbles:AdventureGuild_Marlon_Greeting4", 
					};
					characterFromName11.showTextAboveHead(Game1.content.LoadString(path8));
				}
			}
			break;
		case 16:
		{
			if (!(value == "ArchaeologyHouse"))
			{
				break;
			}
			setFireplace(on: true, 43, 4, playSound: false);
			if (!Game1.random.NextBool() || !Game1.player.hasOrWillReceiveMail("artifactFound"))
			{
				break;
			}
			NPC characterFromName = Game1.getCharacterFromName("Gunther");
			if (characterFromName != null && characterFromName.currentLocation == this)
			{
				string text = Game1.random.Next(5) switch
				{
					0 => "Greeting1", 
					1 => "Greeting2", 
					2 => "Greeting3", 
					3 => "Greeting4", 
					_ => "Greeting5", 
				};
				if (Game1.random.NextDouble() < 0.001)
				{
					text = "RareGreeting";
				}
				characterFromName.showTextAboveHead(Game1.content.LoadString("Strings\\SpeechBubbles:ArchaeologyHouse_Gunther_" + text));
			}
			break;
		}
		case 11:
			break;
		}
	}

	public virtual void hostSetup()
	{
		if (Game1.IsMasterGame && !farmers.Any() && !HasFarmerWatchingBroadcastEventReturningHere())
		{
			interiorDoors.ResetSharedState();
		}
	}

	public virtual void ResetForEvent(Event ev)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		ev.eventPositionTileOffset = Vector2.Zero;
		if (IsOutdoors)
		{
			Game1.ambientLight = (Color)(IsRainingHere() ? new Color(255, 200, 80) : Color.White);
		}
	}

	public virtual bool HasFarmerWatchingBroadcastEventReturningHere()
	{
		foreach (Farmer allFarmer in Game1.getAllFarmers())
		{
			if (allFarmer.locationBeforeForcedEvent.Value != null && allFarmer.locationBeforeForcedEvent.Value == NameOrUniqueName)
			{
				return true;
			}
		}
		return false;
	}

	public void resetForPlayerEntry()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		Game1.updateWeatherIcon();
		Game1.hooks.OnGameLocation_ResetForPlayerEntry(this, delegate
		{
			_madeMapModifications = false;
			if ((!farmers.Any() && !HasFarmerWatchingBroadcastEventReturningHere()) || Game1.player.sleptInTemporaryBed.Value)
			{
				resetSharedState();
			}
			resetLocalState();
			if (!_madeMapModifications)
			{
				_madeMapModifications = true;
				MakeMapModifications();
			}
		});
		Rectangle boundingBox = Game1.player.GetBoundingBox();
		foreach (Furniture item in furniture)
		{
			Rectangle boundingBox2 = item.GetBoundingBox();
			if (((Rectangle)(ref boundingBox2)).Intersects(boundingBox) && item.IntersectsForCollision(boundingBox) && !item.isPassable())
			{
				Game1.player.TemporaryPassableTiles.Add(boundingBox2);
			}
		}
	}

	protected virtual void resetLocalState()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0657: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_050c: Unknown result type (might be due to invalid IL or missing references)
		//IL_054e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0553: Unknown result type (might be due to invalid IL or missing references)
		//IL_057f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0599: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0843: Unknown result type (might be due to invalid IL or missing references)
		//IL_084a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a31: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a4a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bb9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bbe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bfd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c44: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c53: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c58: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c63: Unknown result type (might be due to invalid IL or missing references)
		bool flag = Game1.newDaySync.hasInstance();
		if (TryGetMapProperty("ViewportClamp", out var propertyValue))
		{
			try
			{
				int[] array = Utility.parseStringToIntArray(propertyValue);
				Game1.viewportClampArea = new Rectangle(array[0] * 64, array[1] * 64, array[2] * 64, array[3] * 64);
			}
			catch (Exception)
			{
				Game1.viewportClampArea = Rectangle.Empty;
			}
		}
		else
		{
			Game1.viewportClampArea = Rectangle.Empty;
		}
		Game1.elliottPiano = 0;
		Game1.crabPotOverlayTiles.Clear();
		Utility.killAllStaticLoopingSoundCues();
		Game1.player.bridge = null;
		Game1.player.SetOnBridge(val: false);
		if (Game1.CurrentEvent == null && !Name.ContainsIgnoreCase("bath"))
		{
			Game1.player.canOnlyWalk = false;
		}
		if (!(this is Farm))
		{
			temporarySprites.RemoveWhere((TemporaryAnimatedSprite sprite) => sprite.clearOnAreaEntry());
		}
		if (Game1.options != null)
		{
			if (Game1.isOneOfTheseKeysDown(Game1.GetKeyboardState(), Game1.options.runButton))
			{
				Game1.player.setRunning(!Game1.options.autoRun, force: true);
			}
			else
			{
				Game1.player.setRunning(Game1.options.autoRun, force: true);
			}
		}
		Game1.player.mount?.SyncPositionToRider();
		Game1.UpdateViewPort(overrideFreeze: false, Game1.player.StandingPixel);
		Game1.previousViewportPosition = new Vector2((float)((Rectangle)(ref Game1.viewport)).X, (float)((Rectangle)(ref Game1.viewport)).Y);
		Game1.PushUIMode();
		foreach (IClickableMenu onScreenMenu in Game1.onScreenMenus)
		{
			onScreenMenu.gameWindowSizeChanged(new Rectangle(((Rectangle)(ref Game1.uiViewport)).X, ((Rectangle)(ref Game1.uiViewport)).Y, ((Rectangle)(ref Game1.uiViewport)).Width, ((Rectangle)(ref Game1.uiViewport)).Height), new Rectangle(((Rectangle)(ref Game1.uiViewport)).X, ((Rectangle)(ref Game1.uiViewport)).Y, ((Rectangle)(ref Game1.uiViewport)).Width, ((Rectangle)(ref Game1.uiViewport)).Height));
		}
		Game1.PopUIMode();
		ignoreWarps = false;
		if (!flag || Game1.newDaySync.hasFinished())
		{
			if (Game1.player.rightRing.Value != null)
			{
				Game1.player.rightRing.Value.onNewLocation(Game1.player, this);
			}
			if (Game1.player.leftRing.Value != null)
			{
				Game1.player.leftRing.Value.onNewLocation(Game1.player, this);
			}
		}
		forceViewportPlayerFollow = ((IDictionary<string, PropertyValue>)((Component)Map).Properties).ContainsKey("ViewportFollowPlayer");
		lastTouchActionLocation = Game1.player.Tile;
		Game1.player.NotifyQuests((Quest quest) => quest.OnWarped(this));
		if (!isOutdoors.Value)
		{
			Game1.player.FarmerSprite.currentStep = "thudStep";
		}
		setUpLocationSpecificFlair();
		_updateAmbientLighting();
		if (!ignoreLights.Value)
		{
			string lightIdPrefix = NameOrUniqueName + "_MapLight_";
			Game1.currentLightSources.RemoveWhere((KeyValuePair<string, LightSource> p) => p.Key.StartsWith(lightIdPrefix));
			string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces("Light");
			for (int num = 0; num < mapPropertySplitBySpaces.Length; num += 3)
			{
				if (!ArgUtility.TryGetPoint(mapPropertySplitBySpaces, num, out var value, out var error, "Point tile") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces, num + 2, out var value2, out error, "int textureIndex"))
				{
					LogMapPropertyError("Light", mapPropertySplitBySpaces, error);
					continue;
				}
				Game1.currentLightSources.Add(new LightSource($"{lightIdPrefix}_{value.X}_{value.Y}", value2, new Vector2((float)(value.X * 64 + 32), (float)(value.Y * 64 + 32)), 1f, LightSource.LightContext.MapLight, 0L, NameOrUniqueName));
			}
			if (!Game1.isTimeToTurnOffLighting(this) && !Game1.isRaining)
			{
				string[] mapPropertySplitBySpaces2 = GetMapPropertySplitBySpaces("WindowLight");
				for (int num2 = 0; num2 < mapPropertySplitBySpaces2.Length; num2 += 3)
				{
					if (!ArgUtility.TryGetPoint(mapPropertySplitBySpaces2, num2, out var value3, out var error2, "Point tile") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces2, num2 + 2, out var value4, out error2, "int textureIndex"))
					{
						LogMapPropertyError("WindowLight", mapPropertySplitBySpaces2, error2);
						continue;
					}
					Game1.currentLightSources.Add(new LightSource($"{lightIdPrefix}_{value3.X}_{value3.Y}_Window", value4, new Vector2((float)(value3.X * 64 + 32), (float)(value3.Y * 64 + 32)), 1f, LightSource.LightContext.WindowLight, 0L, NameOrUniqueName));
				}
				foreach (Vector2 lightGlow in lightGlows)
				{
					Game1.currentLightSources.Add(new LightSource($"{lightIdPrefix}_{lightGlow.X}_{lightGlow.Y}_Glow", 6, lightGlow, 1f, LightSource.LightContext.WindowLight, 0L, NameOrUniqueName));
				}
			}
		}
		if (isOutdoors.Value || treatAsOutdoors.Value)
		{
			string[] mapPropertySplitBySpaces3 = GetMapPropertySplitBySpaces("BrookSounds");
			for (int num3 = 0; num3 < mapPropertySplitBySpaces3.Length; num3 += 3)
			{
				if (!ArgUtility.TryGetVector2(mapPropertySplitBySpaces3, num3, out var value5, out var error3, integerOnly: false, "Vector2 tile") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces3, num3 + 2, out var value6, out error3, "int soundId"))
				{
					LogMapPropertyError("BrookSounds", mapPropertySplitBySpaces3, error3);
				}
				else
				{
					AmbientLocationSounds.addSound(value5, value6);
				}
			}
			Game1.randomizeRainPositions();
			Game1.randomizeDebrisWeatherPositions(Game1.debrisWeather);
		}
		foreach (KeyValuePair<Vector2, TerrainFeature> pair in terrainFeatures.Pairs)
		{
			pair.Value.performPlayerEntryAction();
		}
		if (largeTerrainFeatures != null)
		{
			foreach (LargeTerrainFeature largeTerrainFeature in largeTerrainFeatures)
			{
				largeTerrainFeature.performPlayerEntryAction();
			}
		}
		foreach (KeyValuePair<Vector2, Object> pair2 in objects.Pairs)
		{
			pair2.Value.actionOnPlayerEntry();
		}
		if (isOutdoors.Value)
		{
			((FarmerSprite)Game1.player.Sprite).currentStep = "sandyStep";
			tryToAddCritters();
		}
		interiorDoors.ResetLocalState();
		int num4 = Game1.getTrulyDarkTime(this) - 100;
		if (Game1.timeOfDay < num4 && (!IsRainingHere() || name.Equals("SandyHouse")))
		{
			string[] mapPropertySplitBySpaces4 = GetMapPropertySplitBySpaces("DayTiles");
			for (int num5 = 0; num5 < mapPropertySplitBySpaces4.Length; num5 += 4)
			{
				if (!ArgUtility.TryGet(mapPropertySplitBySpaces4, num5, out var value7, out var error4, allowBlank: true, "string layerId") || !ArgUtility.TryGetPoint(mapPropertySplitBySpaces4, num5 + 1, out var value8, out error4, "Point position") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces4, num5 + 3, out var value9, out error4, "int tileIndex"))
				{
					LogMapPropertyError("DayTiles", mapPropertySplitBySpaces4, error4);
				}
				else if (value9 != 720 || !Game1.MasterPlayer.mailReceived.Contains("pamHouseUpgrade"))
				{
					Tile val = map.RequireLayer(value7).Tiles[value8.X, value8.Y];
					if (val != null)
					{
						val.TileIndex = value9;
					}
				}
			}
		}
		else if (Game1.timeOfDay >= num4 || (IsRainingHere() && !name.Equals("SandyHouse")))
		{
			switchOutNightTiles();
		}
		if (Game1.killScreen && Game1.activeClickableMenu != null && !Game1.dialogueUp)
		{
			Game1.activeClickableMenu.emergencyShutDown();
			Game1.exitActiveMenu();
		}
		if (Game1.activeClickableMenu == null && !Game1.warpingForForcedRemoteEvent && !flag)
		{
			checkForEvents();
		}
		foreach (KeyValuePair<string, LightSource> pair3 in sharedLights.Pairs)
		{
			Game1.currentLightSources[pair3.Key] = pair3.Value;
		}
		foreach (NPC character in characters)
		{
			character.behaviorOnLocalFarmerLocationEntry(this);
		}
		foreach (Furniture item in furniture)
		{
			item.actionOnPlayerEntry();
		}
		updateFishSplashAnimation();
		updateOrePanAnimation();
		showDropboxIndicator = false;
		foreach (SpecialOrder specialOrder in Game1.player.team.specialOrders)
		{
			if (specialOrder.ShouldDisplayAsComplete())
			{
				continue;
			}
			foreach (OrderObjective objective in specialOrder.objectives)
			{
				if (objective is DonateObjective donateObjective && !string.IsNullOrEmpty(donateObjective.dropBoxGameLocation.Value) && donateObjective.GetDropboxLocationName() == Name)
				{
					showDropboxIndicator = true;
					dropBoxIndicatorLocation = donateObjective.dropBoxTileLocation.Value * 64f + new Vector2(7f, 0f) * 4f;
				}
			}
		}
		if (Game1.timeOfDay >= 1830)
		{
			FarmAnimal[] array2 = animals.Values.ToArray();
			for (int num6 = 0; num6 < array2.Length; num6++)
			{
				array2[num6].warpHome();
			}
		}
		foreach (Building building in buildings)
		{
			building.resetLocalState();
		}
		if (isThereABuildingUnderConstruction())
		{
			foreach (string key in Game1.netWorldState.Value.Builders.Keys)
			{
				BuilderData builderData = Game1.netWorldState.Value.Builders[key];
				if (builderData.buildingLocation.Value == NameOrUniqueName && builderData.daysUntilBuilt.Value > 0)
				{
					NPC characterFromName = Game1.getCharacterFromName(key);
					if (characterFromName != null && characterFromName.currentLocation.Equals(this))
					{
						Building buildingAt = getBuildingAt(Utility.PointToVector2(builderData.buildingTile.Value));
						if (buildingAt != null)
						{
							temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(399, 262, (buildingAt.daysOfConstructionLeft.Value == 1) ? 29 : 9, 43), new Vector2((float)(buildingAt.tileX.Value + buildingAt.tilesWide.Value / 2), (float)(buildingAt.tileY.Value + buildingAt.tilesHigh.Value / 2)) * 64f + new Vector2(-16f, -144f), flipped: false, 0f, Color.White)
							{
								id = 16846,
								scale = 4f,
								interval = 999999f,
								animationLength = 1,
								totalNumberOfLoops = 99999,
								layerDepth = (float)((buildingAt.tileY.Value + buildingAt.tilesHigh.Value / 2) * 64 + 32) / 10000f
							});
						}
					}
				}
			}
			return;
		}
		removeTemporarySpritesWithIDLocal(16846);
	}

	protected virtual void _updateAmbientLighting()
	{
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.eventUp || (Game1.player.viewingLocation.Value != null && !Game1.player.viewingLocation.Value.Equals(Name)))
		{
			return;
		}
		if (!isOutdoors.Value || ignoreOutdoorLighting.Value)
		{
			if (Game1.isStartingToGetDarkOut(this) || lightLevel.Value > 0f)
			{
				int startTime = Game1.timeOfDay + Game1.gameTimeInterval / (Game1.realMilliSecondsPerGameMinute + ExtraMillisecondsPerInGameMinute);
				float t = 1f - Utility.Clamp((float)Utility.CalculateMinutesBetweenTimes(startTime, Game1.getTrulyDarkTime(this)) / 120f, 0f, 1f);
				Game1.ambientLight = new Color((int)(byte)Utility.Lerp((int)((Color)(ref indoorLightingColor)).R, (int)((Color)(ref indoorLightingNightColor)).R, t), (int)(byte)Utility.Lerp((int)((Color)(ref indoorLightingColor)).G, (int)((Color)(ref indoorLightingNightColor)).G, t), (int)(byte)Utility.Lerp((int)((Color)(ref indoorLightingColor)).B, (int)((Color)(ref indoorLightingNightColor)).B, t));
			}
			else
			{
				Game1.ambientLight = indoorLightingColor;
			}
		}
		else
		{
			Game1.ambientLight = (Color)(IsRainingHere() ? new Color(255, 200, 80) : Color.White);
		}
	}

	private bool TryGetAmbientLightFromMap(out Color color, string propertyName = "AmbientLight")
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces(propertyName);
		if (mapPropertySplitBySpaces.Length != 0)
		{
			if (ArgUtility.TryGetInt(mapPropertySplitBySpaces, 0, out var value, out var error, "int r") && ArgUtility.TryGetInt(mapPropertySplitBySpaces, 1, out var value2, out error, "int g") && ArgUtility.TryGetInt(mapPropertySplitBySpaces, 2, out var value3, out error, "int b"))
			{
				color = new Color(value, value2, value3);
				return true;
			}
			LogMapPropertyError(propertyName, mapPropertySplitBySpaces, error);
		}
		color = Color.White;
		return false;
	}

	public void SelectRandomMiniJukeboxTrack()
	{
		if (!(miniJukeboxTrack.Value != "random"))
		{
			Farmer player = Game1.player;
			if (this is FarmHouse { HasOwner: not false } farmHouse)
			{
				player = farmHouse.owner;
			}
			List<string> jukeboxTracks = Utility.GetJukeboxTracks(player, this);
			string value = Game1.random.ChooseFrom(jukeboxTracks);
			randomMiniJukeboxTrack.Value = value;
		}
	}

	protected virtual void resetSharedState()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Expected I4, but got Unknown
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		SelectRandomMiniJukeboxTrack();
		for (int num = characters.Count - 1; num >= 0; num--)
		{
			characters[num].behaviorOnFarmerLocationEntry(this, Game1.player);
		}
		if (!(this is MineShaft))
		{
			Season season = GetSeason();
			switch ((int)season)
			{
			case 0:
				waterColor.Value = new Color(120, 200, 255) * 0.5f;
				break;
			case 1:
				waterColor.Value = new Color(60, 240, 255) * 0.5f;
				break;
			case 2:
				waterColor.Value = new Color(255, 130, 200) * 0.5f;
				break;
			case 3:
				waterColor.Value = new Color(130, 80, 255) * 0.5f;
				break;
			}
		}
	}

	public LightSource getLightSource([NotNullWhen(true)] string identifier)
	{
		if (identifier == null || !sharedLights.TryGetValue(identifier, out var value))
		{
			return null;
		}
		return value;
	}

	public bool hasLightSource([NotNullWhen(true)] string identifier)
	{
		if (identifier != null)
		{
			return sharedLights.ContainsKey(identifier);
		}
		return false;
	}

	public void removeLightSource([NotNullWhen(true)] string identifier)
	{
		if (identifier != null)
		{
			sharedLights.Remove(identifier);
		}
	}

	public void repositionLightSource([NotNullWhen(true)] string identifier, Vector2 position)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		if (identifier != null && sharedLights.TryGetValue(identifier, out var value))
		{
			value.position.Value = position;
		}
	}

	public virtual bool CanSpawnCharacterHere(Vector2 tileLocation)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		if (isTileOnMap(tileLocation) && isTilePlaceable(tileLocation))
		{
			return !IsTileBlockedBy(tileLocation);
		}
		return false;
	}

	public virtual bool CanItemBePlacedHere(Vector2 tile, bool itemIsPassable = false, CollisionMask collisionMask = CollisionMask.All, CollisionMask ignorePassables = ~CollisionMask.Objects, bool useFarmerTile = false, bool ignorePassablesExactly = false)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		if (!ignorePassablesExactly)
		{
			ignorePassables &= ~CollisionMask.Objects;
			if (!itemIsPassable)
			{
				ignorePassables &= ~(CollisionMask.Characters | CollisionMask.Farmers);
			}
		}
		if (!isTileOnMap(tile))
		{
			return false;
		}
		if (!isTilePlaceable(tile, itemIsPassable))
		{
			return false;
		}
		if (GetHoeDirtAtTile(tile)?.crop != null)
		{
			return false;
		}
		if (IsTileBlockedBy(tile, collisionMask, ignorePassables, useFarmerTile))
		{
			return false;
		}
		if (itemIsPassable && getBuildingAt(tile) != null && getBuildingAt(tile).GetData() != null && !getBuildingAt(tile).GetData().AllowsFlooringUnderneath)
		{
			return false;
		}
		return true;
	}

	public virtual bool IsTileBlockedBy(Vector2 tile, CollisionMask collisionMask = CollisionMask.All, CollisionMask ignorePassables = CollisionMask.None, bool useFarmerTile = false)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if (!IsTileOccupiedBy(tile, collisionMask, ignorePassables, useFarmerTile))
		{
			return !isTilePassable(tile);
		}
		return true;
	}

	public virtual bool IsTileOccupiedBy(Vector2 tile, CollisionMask collisionMask = CollisionMask.All, CollisionMask ignorePassables = CollisionMask.None, bool useFarmerTile = false)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_034a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_035b: Unknown result type (might be due to invalid IL or missing references)
		//IL_035e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0420: Unknown result type (might be due to invalid IL or missing references)
		//IL_0415: Unknown result type (might be due to invalid IL or missing references)
		Rectangle val = default(Rectangle);
		((Rectangle)(ref val))._002Ector((int)tile.X * 64, (int)tile.Y * 64, 64, 64);
		Rectangle boundingBox;
		if (collisionMask.HasFlag(CollisionMask.Farmers) && !ignorePassables.HasFlag(CollisionMask.Farmers))
		{
			foreach (Farmer farmer in farmers)
			{
				bool num;
				if (!useFarmerTile)
				{
					boundingBox = farmer.GetBoundingBox();
					num = ((Rectangle)(ref boundingBox)).Intersects(val);
				}
				else
				{
					num = farmer.Tile == tile;
				}
				if (num)
				{
					return true;
				}
			}
		}
		if (collisionMask.HasFlag(CollisionMask.Objects) && objects.TryGetValue(tile, out var value) && (!ignorePassables.HasFlag(CollisionMask.Objects) || !value.isPassable()))
		{
			return true;
		}
		if (collisionMask.HasFlag(CollisionMask.Furniture))
		{
			Furniture furnitureAt = GetFurnitureAt(tile);
			if (furnitureAt != null && (!ignorePassables.HasFlag(CollisionMask.Furniture) || !furnitureAt.isPassable()))
			{
				return true;
			}
		}
		if (collisionMask.HasFlag(CollisionMask.Characters))
		{
			foreach (NPC character in characters)
			{
				if (character != null)
				{
					boundingBox = character.GetBoundingBox();
					if (((Rectangle)(ref boundingBox)).Intersects(val) && !character.IsInvisible && (!ignorePassables.HasFlag(CollisionMask.Characters) || !character.farmerPassesThrough))
					{
						return true;
					}
				}
			}
			if (animals.Length > 0)
			{
				foreach (FarmAnimal value3 in animals.Values)
				{
					if (value3.Tile == tile && (!ignorePassables.HasFlag(CollisionMask.Characters) || !value3.farmerPassesThrough))
					{
						return true;
					}
				}
			}
		}
		if (collisionMask.HasFlag(CollisionMask.TerrainFeatures))
		{
			foreach (ResourceClump resourceClump in resourceClumps)
			{
				if (resourceClump.occupiesTile((int)tile.X, (int)tile.Y) && (!ignorePassables.HasFlag(CollisionMask.TerrainFeatures) || !resourceClump.isPassable()))
				{
					return true;
				}
			}
			if (largeTerrainFeatures != null)
			{
				foreach (LargeTerrainFeature largeTerrainFeature in largeTerrainFeatures)
				{
					boundingBox = largeTerrainFeature.getBoundingBox();
					if (((Rectangle)(ref boundingBox)).Intersects(val) && (!ignorePassables.HasFlag(CollisionMask.TerrainFeatures) || !largeTerrainFeature.isPassable()))
					{
						return true;
					}
				}
			}
		}
		if ((collisionMask.HasFlag(CollisionMask.TerrainFeatures) || collisionMask.HasFlag(CollisionMask.Flooring)) && terrainFeatures.TryGetValue(tile, out var value2))
		{
			boundingBox = value2.getBoundingBox();
			if (((Rectangle)(ref boundingBox)).Intersects(val))
			{
				CollisionMask collisionMask2 = ((value2 is Flooring) ? CollisionMask.Flooring : CollisionMask.TerrainFeatures);
				if (collisionMask.HasFlag(collisionMask2) && (!ignorePassables.HasFlag(collisionMask2) || !value2.isPassable()))
				{
					return true;
				}
			}
		}
		if (collisionMask.HasFlag(CollisionMask.LocationSpecific) && IsLocationSpecificOccupantOnTile(tile))
		{
			return true;
		}
		if (collisionMask.HasFlag(CollisionMask.Buildings))
		{
			foreach (Building building in buildings)
			{
				if (!building.isMoving && (ignorePassables.HasFlag(CollisionMask.Buildings) ? (!building.isTilePassable(tile)) : building.occupiesTile(tile)))
				{
					return true;
				}
			}
		}
		return false;
	}

	public virtual bool IsLocationSpecificOccupantOnTile(Vector2 tileLocation)
	{
		return false;
	}

	public virtual bool IsLocationSpecificPlacementRestriction(Vector2 tileLocation)
	{
		return false;
	}

	public Farmer isTileOccupiedByFarmer(Vector2 tileLocation)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		foreach (Farmer farmer in farmers)
		{
			if (farmer.Tile == tileLocation)
			{
				return farmer;
			}
		}
		return null;
	}

	public HoeDirt GetHoeDirtAtTile(Vector2 tile)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		if (objects.TryGetValue(tile, out var value) && value is IndoorPot indoorPot)
		{
			return indoorPot.hoeDirt.Value;
		}
		if (terrainFeatures.TryGetValue(tile, out var value2) && value2 is HoeDirt result)
		{
			return result;
		}
		return null;
	}

	public bool isTileHoeDirt(Vector2 tile)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return GetHoeDirtAtTile(tile) != null;
	}

	public bool isTileLocationOpen(Location location)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		return this.isTileLocationOpen(new Vector2((float)location.X, (float)location.Y));
	}

	public bool isTileLocationOpen(Vector2 location)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		if (map.RequireLayer("Buildings").Tiles[(int)location.X, (int)location.Y] == null && !isWaterTile((int)location.X, (int)location.Y) && map.RequireLayer("Front").Tiles[(int)location.X, (int)location.Y] == null)
		{
			Layer layer = map.GetLayer("AlwaysFront");
			return ((layer != null) ? layer.Tiles[(int)location.X, (int)location.Y] : null) == null;
		}
		return false;
	}

	public virtual bool CanPlaceThisFurnitureHere(Furniture furniture)
	{
		if (furniture == null)
		{
			return false;
		}
		bool flag = this is DecoratableLocation || !IsOutdoors;
		if (furniture.furniture_type.Value == 15)
		{
			if (!TryGetMapPropertyAs("AllowBeds", out bool parsed, required: false))
			{
				parsed = this is FarmHouse || this is IslandFarmHouse || (flag && ParentBuilding != null);
			}
			if (!parsed)
			{
				return false;
			}
		}
		switch (furniture.placementRestriction)
		{
		case 0:
			return flag;
		case 1:
			return !flag;
		case 2:
			if (!flag)
			{
				return !flag;
			}
			return true;
		default:
			return false;
		}
	}

	public virtual bool isTilePlaceable(Vector2 v, bool itemIsPassable = false)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if (IsLocationSpecificPlacementRestriction(v))
		{
			return false;
		}
		if (!hasTileAt((int)v.X, (int)v.Y, "Back"))
		{
			return false;
		}
		if (isWaterTile((int)v.X, (int)v.Y))
		{
			return false;
		}
		string text = doesTileHaveProperty((int)v.X, (int)v.Y, "NoFurniture", "Back");
		if (text != null)
		{
			if (text == "total")
			{
				return false;
			}
			if (!itemIsPassable || !Game1.currentLocation.IsOutdoors)
			{
				return false;
			}
		}
		return true;
	}

	public void playTerrainSound(Vector2 tileLocation, Character who = null, bool showTerrainDisturbAnimation = true)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Invalid comparison between Unknown and I4
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Invalid comparison between Unknown and I4
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		string text = "thudStep";
		if (IsOutdoors || treatAsOutdoors.Value || Name.ContainsIgnoreCase("mine"))
		{
			switch (doesTileHaveProperty((int)tileLocation.X, (int)tileLocation.Y, "Type", "Back"))
			{
			case "Dirt":
				text = "sandyStep";
				break;
			case "Stone":
				text = "stoneStep";
				break;
			case "Grass":
				text = (((int)GetSeason() == 3) ? "snowyStep" : "grassyStep");
				break;
			case "Wood":
				text = "woodyStep";
				break;
			case null:
				if (isWaterTile((int)tileLocation.X, (int)tileLocation.Y))
				{
					text = "waterSlosh";
				}
				break;
			}
		}
		if (terrainFeatures.TryGetValue(tileLocation, out var value) && value is Flooring)
		{
			text = ((Flooring)terrainFeatures[tileLocation]).getFootstepSound();
		}
		if (who != null && showTerrainDisturbAnimation && text == "sandyStep")
		{
			Vector2 val = Vector2.Zero;
			if (who.shouldShadowBeOffset)
			{
				val = who.drawOffset;
			}
			temporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 64, 64, 64), 50f, 4, 1, new Vector2(who.Position.X + (float)Game1.random.Next(-8, 8), who.Position.Y + (float)Game1.random.Next(-16, 0)) + val, flicker: false, Game1.random.NextBool(), 0.0001f, 0f, Color.White, 1f, 0.01f, 0f, (float)Game1.random.Next(-5, 6) * (float)Math.PI / 128f));
		}
		else if (who != null && showTerrainDisturbAnimation && (int)GetSeason() == 3 && text == "grassyStep")
		{
			Vector2 val2 = Vector2.Zero;
			if (who.shouldShadowBeOffset)
			{
				val2 = who.drawOffset;
			}
			temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(247, 407, 6, 6), 2000f, 1, 10000, new Vector2(who.Position.X, who.Position.Y) + val2, flicker: false, flipped: false, 0.0001f, 0.001f, Color.White, 1f, 0.01f, 0f, 0f));
		}
		if ((who as Farmer)?.boots.Value?.ItemId == "853")
		{
			localSound("jingleBell");
		}
		if (text.Length > 0)
		{
			localSound(text);
		}
	}

	public bool checkTileIndexAction(int tileIndex)
	{
		if ((tileIndex == 1799 || (uint)(tileIndex - 1824) <= 9u) && Name.Equals("AbandonedJojaMart"))
		{
			Game1.RequireLocation<AbandonedJojaMart>("AbandonedJojaMart").checkBundle();
			return true;
		}
		return false;
	}

	public bool checkForTerrainFeaturesAndObjectsButDestroyNonPlayerItems(int x, int y)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		Vector2 key = default(Vector2);
		((Vector2)(ref key))._002Ector((float)x, (float)y);
		if (objects.TryGetValue(key, out var value))
		{
			if (!value.IsSpawnedObject || value is Chest || value.Type == "Crafting")
			{
				return false;
			}
			objects.Remove(key);
		}
		terrainFeatures.Remove(key);
		return true;
	}

	public virtual bool checkAction(Location tileLocation, Rectangle viewport, Farmer who)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0408: Unknown result type (might be due to invalid IL or missing references)
		//IL_040f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_0445: Unknown result type (might be due to invalid IL or missing references)
		//IL_044c: Unknown result type (might be due to invalid IL or missing references)
		//IL_045e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_092f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0934: Unknown result type (might be due to invalid IL or missing references)
		//IL_0938: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0949: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a0e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0605: Unknown result type (might be due to invalid IL or missing references)
		//IL_0559: Unknown result type (might be due to invalid IL or missing references)
		//IL_050c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0512: Unknown result type (might be due to invalid IL or missing references)
		//IL_0517: Unknown result type (might be due to invalid IL or missing references)
		//IL_052b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a34: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_070b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0577: Unknown result type (might be due to invalid IL or missing references)
		//IL_057d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0582: Unknown result type (might be due to invalid IL or missing references)
		//IL_0596: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6a: Unknown result type (might be due to invalid IL or missing references)
		//IL_099e: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aff: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b35: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b3b: Unknown result type (might be due to invalid IL or missing references)
		//IL_08de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b7d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0803: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bc8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bcc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c58: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c5d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cd8: Unknown result type (might be due to invalid IL or missing references)
		who.ignoreItemConsumptionThisFrame = false;
		Rectangle val = default(Rectangle);
		((Rectangle)(ref val))._002Ector(tileLocation.X * 64, tileLocation.Y * 64, 64, 64);
		if (!objects.ContainsKey(new Vector2((float)tileLocation.X, (float)tileLocation.Y)) && CheckPetAnimal(val, who))
		{
			return true;
		}
		foreach (Building building in buildings)
		{
			if (building.doAction(new Vector2((float)tileLocation.X, (float)tileLocation.Y), who))
			{
				return true;
			}
		}
		if (who.IsSitting())
		{
			who.StopSitting();
			return true;
		}
		Rectangle val2;
		foreach (Farmer farmer in farmers)
		{
			if (farmer != Game1.player)
			{
				val2 = farmer.GetBoundingBox();
				if (((Rectangle)(ref val2)).Intersects(val) && farmer.checkAction(who, this))
				{
					return true;
				}
			}
		}
		if (currentEvent != null && currentEvent.isFestival)
		{
			return currentEvent.checkAction(tileLocation, viewport, who);
		}
		foreach (NPC character in characters)
		{
			if (character == null || character.IsMonster || (who.isRidingHorse() && character is Horse))
			{
				continue;
			}
			val2 = character.GetBoundingBox();
			if (((Rectangle)(ref val2)).Intersects(val) && character.checkAction(who, this))
			{
				if (who.FarmerSprite.IsPlayingBasicAnimation(who.FacingDirection, carrying: false) || who.FarmerSprite.IsPlayingBasicAnimation(who.FacingDirection, carrying: true))
				{
					who.faceGeneralDirection(character.getStandingPosition(), 0, opposite: false, useTileCalculations: false);
				}
				return true;
			}
		}
		int tileIndexAt = getTileIndexAt(tileLocation, "Buildings", "untitled tile sheet");
		if (NameOrUniqueName == "SkullCave" && (tileIndexAt == 344 || tileIndexAt == 349))
		{
			if (Game1.player.team.SpecialOrderActive("QiChallenge10"))
			{
				who.doEmote(40);
				return false;
			}
			if (!Game1.player.team.completedSpecialOrders.Contains("QiChallenge10"))
			{
				who.doEmote(8);
				return false;
			}
			if (!Game1.player.team.toggleSkullShrineOvernight.Value)
			{
				if (!Game1.player.team.skullShrineActivated.Value)
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:ChallengeShrine_NotYetHard"), createYesNoResponses(), "ShrineOfSkullChallenge");
				}
				else
				{
					Game1.player.team.toggleSkullShrineOvernight.Value = true;
					Game1.showGlobalMessage(Game1.content.LoadString("Strings\\Locations:ChallengeShrine_Activated"));
					Game1.multiplayer.globalChatInfoMessage(Game1.player.team.skullShrineActivated.Value ? "HardModeSkullCaveDeactivated" : "HardModeSkullCaveActivated", who.name.Value);
					playSound(Game1.player.team.skullShrineActivated.Value ? "skeletonStep" : "serpentDie");
				}
			}
			else if (Game1.player.team.toggleSkullShrineOvernight.Value && Game1.player.team.skullShrineActivated.Value)
			{
				Game1.player.team.toggleSkullShrineOvernight.Value = false;
				Game1.showGlobalMessage(Game1.content.LoadString("Strings\\UI:PendingProposal_Canceling"));
				playSound("skeletonStep");
			}
			return true;
		}
		foreach (ResourceClump resourceClump in resourceClumps)
		{
			val2 = resourceClump.getBoundingBox();
			if (((Rectangle)(ref val2)).Intersects(val) && resourceClump.performUseAction(new Vector2((float)tileLocation.X, (float)tileLocation.Y)))
			{
				return true;
			}
		}
		Vector2 val3 = default(Vector2);
		((Vector2)(ref val3))._002Ector((float)tileLocation.X, (float)tileLocation.Y);
		if (objects.TryGetValue(val3, out var value))
		{
			bool isErrorItem = ItemRegistry.GetDataOrErrorItem(value.QualifiedItemId).IsErrorItem;
			if (value.Type != null || isErrorItem)
			{
				if (who.isRidingHorse() && !(value is Fence))
				{
					return false;
				}
				if (val3 == who.Tile && !value.isPassable() && (!(value is Fence fence) || !fence.isGate.Value))
				{
					Tool tool = ItemRegistry.Create<Tool>("(T)Pickaxe");
					tool.DoFunction(Game1.currentLocation, -1, -1, 0, who);
					if (value.performToolAction(tool))
					{
						value.performRemoveAction();
						value.dropItem(this, who.GetToolLocation(), Utility.PointToVector2(who.StandingPixel));
						Game1.currentLocation.Objects.Remove(val3);
						return true;
					}
					tool = ItemRegistry.Create<Tool>("(T)Axe");
					tool.DoFunction(Game1.currentLocation, -1, -1, 0, who);
					if (objects.TryGetValue(val3, out value) && value.performToolAction(tool))
					{
						value.performRemoveAction();
						value.dropItem(this, who.GetToolLocation(), Utility.PointToVector2(who.StandingPixel));
						Game1.currentLocation.Objects.Remove(val3);
						return true;
					}
					if (!objects.TryGetValue(val3, out value))
					{
						return true;
					}
				}
				if (objects.TryGetValue(val3, out value) && (value.Type == "Crafting" || value.Type == "interactive"))
				{
					if (who.ActiveObject == null && value.checkForAction(who))
					{
						return true;
					}
					if (objects.TryGetValue(val3, out value))
					{
						if (who.CurrentItem != null)
						{
							Object value2 = value.heldObject.Value;
							value.heldObject.Value = null;
							bool flag = value.performObjectDropInAction(who.CurrentItem, probe: true, who);
							value.heldObject.Value = value2;
							bool flag2 = value.performObjectDropInAction(who.CurrentItem, probe: false, who, returnFalseIfItemConsumed: true);
							if ((flag || flag2) && who.isMoving())
							{
								Game1.haltAfterCheck = false;
							}
							if (who.ignoreItemConsumptionThisFrame)
							{
								return true;
							}
							if (flag2)
							{
								who.reduceActiveItemByOne();
								return true;
							}
							return value.checkForAction(who) || flag;
						}
						return value.checkForAction(who);
					}
				}
				else if (objects.TryGetValue(val3, out value) && (value.isSpawnedObject.Value || isErrorItem))
				{
					int value3 = value.quality.Value;
					Random random = Utility.CreateDaySaveRandom(val3.X, val3.Y * 777f);
					if (value.isForage())
					{
						value.Quality = GetHarvestSpawnedObjectQuality(who, value.isForage(), value.TileLocation, random);
					}
					if (value.questItem.Value && value.questId.Value != null && value.questId.Value != "0" && !who.hasQuest(value.questId.Value))
					{
						return false;
					}
					if (who.couldInventoryAcceptThisItem(value))
					{
						if (who.IsLocalPlayer)
						{
							localSound("pickUpItem");
							DelayedAction.playSoundAfterDelay("coin", 300);
						}
						who.animateOnce(279 + who.FacingDirection);
						if (!isFarmBuildingInterior())
						{
							if (value.isForage())
							{
								OnHarvestedForage(who, value);
							}
							if (value.ItemId.Equals("789") && Name.Equals("LewisBasement"))
							{
								Bat bat = new Bat(Vector2.Zero, -789);
								bat.focusedOnFarmers = true;
								Game1.changeMusicTrack("none", track_interruptable: false, (MusicContext)0);
								playSound("cursed_mannequin");
								characters.Add(bat);
							}
						}
						else
						{
							who.gainExperience(0, 5);
						}
						who.addItemToInventoryBool(value.getOne());
						Game1.stats.ItemsForaged++;
						if (who.professions.Contains(13) && random.NextDouble() < 0.2 && !value.questItem.Value && who.couldInventoryAcceptThisItem(value) && !isFarmBuildingInterior())
						{
							who.addItemToInventoryBool(value.getOne());
							who.gainExperience(2, 7);
						}
						objects.Remove(val3);
						return true;
					}
					value.Quality = value3;
				}
			}
		}
		if (who.isRidingHorse())
		{
			who.mount.checkAction(who, this);
			return true;
		}
		foreach (KeyValuePair<Vector2, TerrainFeature> pair in terrainFeatures.Pairs)
		{
			val2 = pair.Value.getBoundingBox();
			if (((Rectangle)(ref val2)).Intersects(val) && pair.Value.performUseAction(pair.Key))
			{
				Game1.haltAfterCheck = false;
				return true;
			}
		}
		if (largeTerrainFeatures != null)
		{
			foreach (LargeTerrainFeature largeTerrainFeature in largeTerrainFeatures)
			{
				val2 = largeTerrainFeature.getBoundingBox();
				if (((Rectangle)(ref val2)).Intersects(val) && largeTerrainFeature.performUseAction(largeTerrainFeature.Tile))
				{
					Game1.haltAfterCheck = false;
					return true;
				}
			}
		}
		Tile val4 = map.RequireLayer("Buildings").PickTile(new Location(tileLocation.X * 64, tileLocation.Y * 64), viewport.Size);
		if (val4 == null || !((Component)val4).Properties.TryGetValue("Action", out var value4))
		{
			value4 = doesTileHaveProperty(tileLocation.X, tileLocation.Y, "Action", "Buildings");
		}
		if (value4 != null)
		{
			NPC nPC = isCharacterAtTile(val3 + new Vector2(0f, 1f));
			if (currentEvent == null && nPC != null && !nPC.IsInvisible && !nPC.IsMonster && (!who.isRidingHorse() || !(nPC is Horse)))
			{
				Point standingPixel = nPC.StandingPixel;
				if (Utility.withinRadiusOfPlayer(standingPixel.X, standingPixel.Y, 1, who) && nPC.checkAction(who, this))
				{
					if (who.FarmerSprite.IsPlayingBasicAnimation(who.FacingDirection, who.IsCarrying()))
					{
						who.faceGeneralDirection(Utility.PointToVector2(standingPixel), 0, opposite: false, useTileCalculations: false);
					}
					return true;
				}
			}
			return performAction(value4, who, tileLocation);
		}
		if (val4 != null && checkTileIndexAction(val4.TileIndex))
		{
			return true;
		}
		foreach (MapSeat mapSeat in mapSeats)
		{
			if (mapSeat.OccupiesTile(tileLocation.X, tileLocation.Y) && !mapSeat.IsBlocked(this))
			{
				who.BeginSitting(mapSeat);
				return true;
			}
		}
		Point val5 = default(Point);
		((Point)(ref val5))._002Ector(tileLocation.X * 64, (tileLocation.Y - 1) * 64);
		bool flag3 = Game1.didPlayerJustRightClick();
		Furniture furniture = null;
		foreach (Furniture item in this.furniture)
		{
			val2 = item.boundingBox.Value;
			if (((Rectangle)(ref val2)).Contains((int)(val3.X * 64f), (int)(val3.Y * 64f)) && item.furniture_type.Value != 12)
			{
				if (flag3)
				{
					if (who.ActiveObject != null && item.performObjectDropInAction(who.ActiveObject, probe: false, who))
					{
						return true;
					}
					return item.checkForAction(who);
				}
				return item.clicked(who);
			}
			if (item.furniture_type.Value == 6)
			{
				val2 = item.boundingBox.Value;
				if (((Rectangle)(ref val2)).Contains(val5))
				{
					furniture = item;
				}
			}
		}
		if (furniture != null)
		{
			if (flag3)
			{
				if (who.ActiveObject != null && furniture.performObjectDropInAction(who.ActiveObject, probe: false, who))
				{
					return true;
				}
				return furniture.checkForAction(who);
			}
			return furniture.clicked(who);
		}
		if (Game1.didPlayerJustRightClick(ignoreNonMouseHeldInput: true) && animals.Length > 0 && CheckInspectAnimal(val, who))
		{
			return true;
		}
		return false;
	}

	public int GetHarvestSpawnedObjectQuality(Farmer who, bool isForage, Vector2 tile, Random random = null)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		if (who.professions.Contains(16) && isForage)
		{
			return 4;
		}
		if (isForage)
		{
			if (random == null)
			{
				random = Utility.CreateDaySaveRandom(tile.X, tile.Y * 777f);
			}
			if (random.NextBool((float)who.ForagingLevel / 30f))
			{
				return 2;
			}
			if (random.NextBool((float)who.ForagingLevel / 15f))
			{
				return 1;
			}
		}
		return 0;
	}

	public void OnHarvestedForage(Farmer who, Object forage)
	{
		if (forage.SpecialVariable == 724519)
		{
			who.gainExperience(2, 2);
			who.gainExperience(0, 3);
		}
		else
		{
			who.gainExperience(2, 7);
		}
	}

	public virtual bool CanFreePlaceFurniture()
	{
		return false;
	}

	public virtual bool LowPriorityLeftClick(int x, int y, Farmer who)
	{
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.activeClickableMenu != null)
		{
			return false;
		}
		Rectangle value;
		for (int num = this.furniture.Count - 1; num >= 0; num--)
		{
			Furniture furniture = this.furniture[num];
			if (CanFreePlaceFurniture() || furniture.IsCloseEnoughToFarmer(who))
			{
				if (!furniture.isPassable())
				{
					value = furniture.boundingBox.Value;
					if (((Rectangle)(ref value)).Contains(x, y) && furniture.canBeRemoved(who))
					{
						furniture.AttemptRemoval(delegate(Furniture f)
						{
							Guid job = this.furniture.GuidOf(f);
							if (!furnitureToRemove.Contains(job))
							{
								furnitureToRemove.Add(job);
							}
						});
						return true;
					}
				}
				value = furniture.boundingBox.Value;
				if (((Rectangle)(ref value)).Contains(x, y) && furniture.heldObject.Value != null)
				{
					furniture.clicked(who);
					return true;
				}
				if (!furniture.isGroundFurniture() && furniture.canBeRemoved(who))
				{
					int num2 = y;
					if (this is DecoratableLocation decoratableLocation)
					{
						num2 = decoratableLocation.GetWallTopY(x / 64, y / 64);
						num2 = ((num2 != -1) ? (num2 * 64) : (y * 64));
					}
					value = furniture.boundingBox.Value;
					if (((Rectangle)(ref value)).Contains(x, num2))
					{
						furniture.AttemptRemoval(delegate(Furniture f)
						{
							Guid job = this.furniture.GuidOf(f);
							if (!furnitureToRemove.Contains(job))
							{
								furnitureToRemove.Add(job);
							}
						});
						return true;
					}
				}
			}
		}
		for (int num3 = this.furniture.Count - 1; num3 >= 0; num3--)
		{
			Furniture furniture2 = this.furniture[num3];
			if ((CanFreePlaceFurniture() || furniture2.IsCloseEnoughToFarmer(who)) && furniture2.isPassable())
			{
				value = furniture2.boundingBox.Value;
				if (((Rectangle)(ref value)).Contains(x, y) && furniture2.canBeRemoved(who))
				{
					furniture2.AttemptRemoval(delegate(Furniture f)
					{
						Guid job = this.furniture.GuidOf(f);
						if (!furnitureToRemove.Contains(job))
						{
							furnitureToRemove.Add(job);
						}
					});
					return true;
				}
			}
		}
		Rectangle rect = default(Rectangle);
		((Rectangle)(ref rect))._002Ector(x * 64, y * 64, 64, 64);
		if (Game1.didPlayerJustRightClick(ignoreNonMouseHeldInput: true) && CheckInspectAnimal(rect, who))
		{
			return true;
		}
		return false;
	}

	[Obsolete("These values returned by this function are no longer used by the game (except for rare, backwards compatibility related cases.) Check DecoratableLocation's wallpaper/flooring related functionality instead.")]
	public virtual List<Rectangle> getWalls()
	{
		return new List<Rectangle>();
	}

	protected virtual void removeQueuedFurniture(Guid guid)
	{
		Farmer player = Game1.player;
		if (!furniture.TryGetValue(guid, out var value) || !player.couldInventoryAcceptThisItem(value))
		{
			return;
		}
		value.performRemoveAction();
		furniture.Remove(guid);
		bool flag = false;
		for (int i = 0; i < 12; i++)
		{
			if (player.Items[i] == null)
			{
				player.Items[i] = value;
				player.CurrentToolIndex = i;
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			Item item = player.addItemToInventory(value, 11);
			player.addItemToInventory(item);
			player.CurrentToolIndex = 11;
		}
		localSound("coin");
	}

	public virtual bool leftClick(int x, int y, Farmer who)
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		Vector2 key = default(Vector2);
		((Vector2)(ref key))._002Ector((float)(x / 64), (float)(y / 64));
		foreach (Building building in buildings)
		{
			if (building.CanLeftClick(x, y) && building.leftClicked())
			{
				return true;
			}
		}
		if (objects.TryGetValue(key, out var value) && value.clicked(who))
		{
			objects.Remove(key);
			return true;
		}
		return false;
	}

	public virtual bool shouldShadowBeDrawnAboveBuildingsLayer(Vector2 p)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		if (doesTileHaveProperty((int)p.X, (int)p.Y, "Passable", "Buildings") != null)
		{
			return true;
		}
		if (terrainFeatures.TryGetValue(p, out var value) && value is HoeDirt)
		{
			return true;
		}
		if (isWaterTile((int)p.X, (int)p.Y))
		{
			int tileIndexAt = getTileIndexAt((int)p.X, (int)p.Y, "Buildings", "Town");
			if (tileIndexAt < 1004 || tileIndexAt > 1013)
			{
				return true;
			}
		}
		foreach (Building building in buildings)
		{
			if (building.occupiesTile(p) && building.isTilePassable(p))
			{
				return true;
			}
		}
		return false;
	}

	public virtual Chest GetFridge(bool onlyUnlocked = true)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		if (!(this is FarmHouse farmHouse))
		{
			if (this is IslandFarmHouse islandFarmHouse && (!onlyUnlocked || islandFarmHouse.fridgePosition != Point.Zero))
			{
				return islandFarmHouse.fridge.Value;
			}
		}
		else if (!onlyUnlocked || farmHouse.fridgePosition != Point.Zero)
		{
			return farmHouse.fridge.Value;
		}
		return null;
	}

	public virtual Point? GetFridgePosition()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if (!(this is FarmHouse farmHouse))
		{
			if (this is IslandFarmHouse islandFarmHouse && islandFarmHouse.fridgePosition != Point.Zero)
			{
				return islandFarmHouse.fridgePosition;
			}
		}
		else if (farmHouse.fridgePosition != Point.Zero)
		{
			return farmHouse.fridgePosition;
		}
		return null;
	}

	public void ActivateKitchen()
	{
		List<NetMutex> list = new List<NetMutex>();
		List<Chest> mini_fridges = new List<Chest>();
		foreach (Object value in objects.Values)
		{
			if (value != null && value.bigCraftable.Value && value is Chest chest && chest.fridge.Value)
			{
				mini_fridges.Add(chest);
				list.Add(chest.mutex);
			}
		}
		Chest fridge = GetFridge();
		if (fridge != null)
		{
			list.Add(fridge.mutex);
		}
		new MultipleMutexRequest(list, delegate(MultipleMutexRequest request)
		{
			//IL_0076: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0083: Unknown result type (might be due to invalid IL or missing references)
			List<IInventory> list2 = new List<IInventory>();
			if (fridge != null)
			{
				list2.Add(fridge.Items);
			}
			foreach (Chest item in mini_fridges)
			{
				list2.Add(item.Items);
			}
			Vector2 topLeftPositionForCenteringOnScreen = Utility.getTopLeftPositionForCenteringOnScreen(800 + IClickableMenu.borderWidth * 2, 600 + IClickableMenu.borderWidth * 2);
			Game1.activeClickableMenu = new CraftingPage((int)topLeftPositionForCenteringOnScreen.X, (int)topLeftPositionForCenteringOnScreen.Y, 800 + IClickableMenu.borderWidth * 2, 600 + IClickableMenu.borderWidth * 2, cooking: true, standaloneMenu: true, list2);
			Game1.activeClickableMenu.exitFunction = request.ReleaseLocks;
		}, delegate
		{
			Game1.showRedMessage(Game1.content.LoadString("Strings\\UI:Kitchen_InUse"));
		});
	}

	public void openDoor(Location tileLocation, bool playSound)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			int tileIndexAt = getTileIndexAt(tileLocation.X, tileLocation.Y, "Buildings", "1");
			Point key = default(Point);
			((Point)(ref key))._002Ector(tileLocation.X, tileLocation.Y);
			if (!interiorDoors.ContainsKey(key))
			{
				return;
			}
			interiorDoors[key] = true;
			if (playSound)
			{
				Vector2 value = default(Vector2);
				((Vector2)(ref value))._002Ector((float)tileLocation.X, (float)tileLocation.Y);
				if (tileIndexAt == 120)
				{
					this.playSound("doorOpen", value);
				}
				else
				{
					this.playSound("doorCreak", value);
				}
			}
		}
		catch (Exception)
		{
		}
	}

	public void doStarpoint(string which)
	{
		if (!(which == "3"))
		{
			if (which == "4" && Game1.player.ActiveObject != null && Game1.player.ActiveObject.QualifiedItemId == "(O)203")
			{
				Object obj = ItemRegistry.Create<Object>("(BC)162");
				if (!Game1.player.couldInventoryAcceptThisItem(obj) && Game1.player.ActiveObject.stack.Value > 1)
				{
					Game1.showRedMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:Crop.cs.588"));
					return;
				}
				Game1.player.reduceActiveItemByOne();
				Game1.player.makeThisTheActiveObject(obj);
				localSound("croak");
				Game1.flashAlpha = 1f;
			}
		}
		else if (Game1.player.ActiveObject != null && Game1.player.ActiveObject.QualifiedItemId == "(O)307")
		{
			Object obj2 = ItemRegistry.Create<Object>("(BC)161");
			if (!Game1.player.couldInventoryAcceptThisItem(obj2) && Game1.player.ActiveObject.stack.Value > 1)
			{
				Game1.showRedMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:Crop.cs.588"));
				return;
			}
			Game1.player.reduceActiveItemByOne();
			Game1.player.makeThisTheActiveObject(obj2);
			localSound("discoverMineral");
			Game1.flashAlpha = 1f;
		}
	}

	public virtual string FormatCompletionLine(Func<Farmer, float> check)
	{
		KeyValuePair<Farmer, float> farmCompletion = Utility.GetFarmCompletion(check);
		if (farmCompletion.Key == Game1.player)
		{
			return farmCompletion.Value.ToString();
		}
		return "(" + farmCompletion.Key.Name + ") " + farmCompletion.Value;
	}

	public virtual string FormatCompletionLine(Func<Farmer, bool> check, string true_value, string false_value)
	{
		KeyValuePair<Farmer, bool> farmCompletion = Utility.GetFarmCompletion(check);
		if (farmCompletion.Key == Game1.player)
		{
			if (!farmCompletion.Value)
			{
				return false_value;
			}
			return true_value;
		}
		return "(" + farmCompletion.Key.Name + ") " + (farmCompletion.Value ? true_value : false_value);
	}

	public virtual void ShowQiCat()
	{
		if (Game1.MasterPlayer.mailReceived.Contains("Farm_Eternal") && !Game1.MasterPlayer.mailReceived.Contains("GotPerfectionStatue"))
		{
			Game1.player.team.RequestSetMail(PlayerActionTarget.Host, "GotPerfectionStatue", MailType.Received, add: true);
			Game1.player.addItemByMenuIfNecessaryElseHoldUp(ItemRegistry.Create("(BC)280"));
			return;
		}
		if (!Game1.player.hasOrWillReceiveMail("FizzIntro"))
		{
			Game1.addMailForTomorrow("FizzIntro", noLetter: false, sendToEveryone: true);
		}
		Game1.playSound("qi_shop");
		int perfectionWaivers = Game1.netWorldState.Value.PerfectionWaivers;
		double num = Math.Floor(Utility.percentGameComplete() * 100f);
		if (Game1.content.GetCurrentLanguage() == LocalizedContentManager.LanguageCode.ja || Game1.content.GetCurrentLanguage() == LocalizedContentManager.LanguageCode.ko || Game1.content.GetCurrentLanguage() == LocalizedContentManager.LanguageCode.zh)
		{
			num += (double)perfectionWaivers;
		}
		string text = perfectionWaivers switch
		{
			0 => Game1.content.LoadString("Strings\\UI:PT_Total_Value", num), 
			1 => Game1.content.LoadString("Strings\\UI:PT_Total_ValueWithWaiver", num), 
			_ => Game1.content.LoadString("Strings\\UI:PT_Total_ValueWithWaivers", num, perfectionWaivers), 
		};
		List<string> stringBrokenIntoSectionsOfHeight = SpriteText.getStringBrokenIntoSectionsOfHeight(string.Concat(Utility.loadStringShort("UI", "PT_Title") + "^", "----------------^", Utility.loadStringShort("UI", "PT_Shipped") + ": " + FormatCompletionLine((Farmer farmer) => (float)Math.Floor(Utility.getFarmerItemsShippedPercent(farmer) * 100f)) + "%^", Utility.loadStringShort("UI", "PT_Obelisks") + ": " + Math.Min(Utility.GetObeliskTypesBuilt(), 4) + "/4^", Utility.loadStringShort("UI", "PT_GoldClock") + ": " + (Game1.IsBuildingConstructed("Gold Clock") ? Game1.content.LoadString("Strings\\Lexicon:QuestionDialogue_Yes") : Game1.content.LoadString("Strings\\Lexicon:QuestionDialogue_No")) + "^", Utility.loadStringShort("UI", "PT_MonsterSlayer") + ": " + FormatCompletionLine((Farmer farmer) => farmer.hasCompletedAllMonsterSlayerQuests.Value, Game1.content.LoadString("Strings\\Lexicon:QuestionDialogue_Yes"), Game1.content.LoadString("Strings\\Lexicon:QuestionDialogue_No")) + "^", Utility.loadStringShort("UI", "PT_GreatFriends") + ": " + FormatCompletionLine((Farmer farmer) => (float)Math.Floor(Utility.getMaxedFriendshipPercent(farmer) * 100f)) + "%^", Utility.loadStringShort("UI", "PT_FarmerLevel") + ": " + FormatCompletionLine((Farmer farmer) => Math.Min(farmer.Level, 25)) + "/25^", Utility.loadStringShort("UI", "PT_Stardrops") + ": " + FormatCompletionLine((Farmer farmer) => Utility.foundAllStardrops(farmer), Game1.content.LoadString("Strings\\Lexicon:QuestionDialogue_Yes"), Game1.content.LoadString("Strings\\Lexicon:QuestionDialogue_No")) + "^", Utility.loadStringShort("UI", "PT_Cooking") + ": " + FormatCompletionLine((Farmer farmer) => (float)Math.Floor(Utility.getCookedRecipesPercent(farmer) * 100f)) + "%^", Utility.loadStringShort("UI", "PT_Crafting") + ": " + FormatCompletionLine((Farmer farmer) => (float)Math.Floor(Utility.getCraftedRecipesPercent(farmer) * 100f)) + "%^", Utility.loadStringShort("UI", "PT_Fish") + ": " + FormatCompletionLine((Farmer farmer) => (float)Math.Floor(Utility.getFishCaughtPercent(farmer) * 100f)) + "%^", Utility.loadStringShort("UI", "PT_GoldenWalnut") + ": " + Math.Min(Game1.netWorldState.Value.GoldenWalnutsFound, 130) + "/" + 130 + "^", "----------------^", Utility.loadStringShort("UI", "PT_Total") + ": " + text), 9999, ((Rectangle)(ref Game1.uiViewport)).Height - 100);
		for (int num2 = 0; num2 < stringBrokenIntoSectionsOfHeight.Count - 1; num2++)
		{
			stringBrokenIntoSectionsOfHeight[num2] += "...\n";
		}
		Game1.drawDialogueNoTyping(stringBrokenIntoSectionsOfHeight);
	}

	public virtual bool CheckGarbage(string id, Vector2 tile, Farmer who, bool playAnimations = true, bool reactNpcs = true, Action<string> logError = null)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_050e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_070a: Unknown result type (might be due to invalid IL or missing references)
		//IL_070e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_032c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_035f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0403: Unknown result type (might be due to invalid IL or missing references)
		//IL_0409: Unknown result type (might be due to invalid IL or missing references)
		//IL_0413: Unknown result type (might be due to invalid IL or missing references)
		//IL_0434: Unknown result type (might be due to invalid IL or missing references)
		//IL_043e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0443: Unknown result type (might be due to invalid IL or missing references)
		//IL_044e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0478: Unknown result type (might be due to invalid IL or missing references)
		//IL_047d: Unknown result type (might be due to invalid IL or missing references)
		//IL_048d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0492: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c8: Unknown result type (might be due to invalid IL or missing references)
		if (string.IsNullOrWhiteSpace(id))
		{
			logError?.Invoke("must specify a garbage can ID");
			return false;
		}
		switch (id)
		{
		case "0":
			id = "JodiAndKent";
			break;
		case "1":
			id = "EmilyAndHaley";
			break;
		case "2":
			id = "Mayor";
			break;
		case "3":
			id = "Museum";
			break;
		case "4":
			id = "Blacksmith";
			break;
		case "5":
			id = "Saloon";
			break;
		case "6":
			id = "Evelyn";
			break;
		case "7":
			id = "JojaMart";
			break;
		}
		if (!Game1.netWorldState.Value.CheckedGarbage.Add(id))
		{
			Game1.haltAfterCheck = false;
			return true;
		}
		TryGetGarbageItem(id, who.DailyLuck, out var item, out var selected, out var garbageRandom, logError);
		if (playAnimations)
		{
			bool flag = selected != null && selected.IsDoubleMegaSuccess;
			bool flag2 = !flag && selected != null && selected.IsMegaSuccess;
			if (flag)
			{
				playSound("explosion");
			}
			else if (flag2)
			{
				playSound("crit");
			}
			playSound("trashcan");
			int tileY = (int)tile.Y;
			int num = GetSeasonIndex() * 17;
			TemporaryAnimatedSprite temporaryAnimatedSprite = new TemporaryAnimatedSprite("LooseSprites\\Cursors2", new Rectangle(22 + num, 0, 16, 10), tile * 64f + new Vector2(0f, -6f) * 4f, flipped: false, 0f, Color.White)
			{
				interval = (flag ? 4000 : 1000),
				motion = (flag ? new Vector2(4f, -20f) : new Vector2(0f, -8f + (flag2 ? (-7f) : ((float)(garbageRandom.Next(-1, 3) + ((garbageRandom.NextDouble() < 0.1) ? (-2) : 0)))))),
				rotationChange = (flag ? 0.4f : 0f),
				acceleration = new Vector2(0f, 0.7f),
				yStopCoordinate = tileY * 64 + -24,
				layerDepth = (flag ? 1f : ((float)((tileY + 1) * 64 + 2) / 10000f)),
				scale = 4f,
				Parent = this,
				shakeIntensity = (flag ? 0f : 1f),
				reachedStopCoordinate = delegate
				{
					//IL_0058: Unknown result type (might be due to invalid IL or missing references)
					//IL_005e: Unknown result type (might be due to invalid IL or missing references)
					//IL_0068: Unknown result type (might be due to invalid IL or missing references)
					//IL_0081: Unknown result type (might be due to invalid IL or missing references)
					//IL_008b: Unknown result type (might be due to invalid IL or missing references)
					//IL_0090: Unknown result type (might be due to invalid IL or missing references)
					//IL_009b: Unknown result type (might be due to invalid IL or missing references)
					//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
					//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
					//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
					//IL_00de: Unknown result type (might be due to invalid IL or missing references)
					removeTemporarySpritesWithID(97654);
					playSound("thudStep");
					for (int i = 0; i < 3; i++)
					{
						temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(372, 1956, 10, 10), tile * 64f + new Vector2((float)(i * 6), (float)(-3 + garbageRandom.Next(3))) * 4f, flipped: false, 0.02f, Color.DimGray)
						{
							alpha = 0.85f,
							motion = new Vector2(-0.6f + (float)i * 0.3f, -1f),
							acceleration = new Vector2(0.002f, 0f),
							interval = 99999f,
							layerDepth = (float)((tileY + 1) * 64 + 3) / 10000f,
							scale = 3f,
							scaleChange = 0.02f,
							rotationChange = (float)garbageRandom.Next(-5, 6) * (float)Math.PI / 256f,
							delayBeforeAnimationStart = 50
						});
					}
				},
				id = 97654
			};
			TemporaryAnimatedSprite item2 = new TemporaryAnimatedSprite("LooseSprites\\Cursors2", new Rectangle(22 + num, 11, 16, 16), tile * 64f + new Vector2(0f, -5f) * 4f, flipped: false, 0f, Color.White)
			{
				interval = (flag ? 999999 : 1000),
				layerDepth = (float)((tileY + 1) * 64 + 1) / 10000f,
				scale = 4f,
				id = 97654
			};
			if (flag)
			{
				temporaryAnimatedSprite.reachedStopCoordinate = temporaryAnimatedSprite.bounce;
			}
			TemporaryAnimatedSpriteList temporaryAnimatedSpriteList = new TemporaryAnimatedSpriteList { temporaryAnimatedSprite, item2 };
			for (int num2 = 0; num2 < 5; num2++)
			{
				TemporaryAnimatedSprite item3 = new TemporaryAnimatedSprite("LooseSprites\\Cursors2", new Rectangle(22 + garbageRandom.Next(4) * 4, 32, 4, 4), tile * 64f + new Vector2((float)Game1.random.Next(13), (float)(-3 + Game1.random.Next(3))) * 4f, flipped: false, 0f, Color.White)
				{
					interval = 500f,
					motion = new Vector2((float)garbageRandom.Next(-2, 3), -5f),
					acceleration = new Vector2(0f, 0.4f),
					layerDepth = (float)((tileY + 1) * 64 + 3) / 10000f,
					scale = 4f,
					color = Utility.getRandomRainbowColor(garbageRandom),
					delayBeforeAnimationStart = garbageRandom.Next(100)
				};
				temporaryAnimatedSpriteList.Add(item3);
			}
			Game1.multiplayer.broadcastSprites(this, temporaryAnimatedSpriteList);
		}
		if (reactNpcs)
		{
			foreach (NPC item4 in Utility.GetNpcsWithinDistance(tile, 7, this))
			{
				if (!(item4 is Horse))
				{
					Game1.multiplayer.globalChatInfoMessage("TrashCan", who.Name, item4.GetTokenizedDisplayName());
					if (item4.Name == "Linus")
					{
						Game1.multiplayer.globalChatInfoMessage("LinusTrashCan");
					}
					CharacterData data = item4.GetData();
					int amount = data?.DumpsterDiveFriendshipEffect ?? (-25);
					int? num3 = data?.DumpsterDiveEmote;
					Dialogue dialogue = item4.TryGetDialogue("DumpsterDiveComment");
					switch (item4.Age)
					{
					case 2:
						num3 = num3 ?? 28;
						dialogue = dialogue ?? new Dialogue(item4, "Data\\ExtraDialogue:Town_DumpsterDiveComment_Child");
						break;
					case 1:
						num3 = num3 ?? 8;
						dialogue = dialogue ?? new Dialogue(item4, "Data\\ExtraDialogue:Town_DumpsterDiveComment_Teen");
						break;
					default:
						num3 = num3 ?? 12;
						dialogue = dialogue ?? new Dialogue(item4, "Data\\ExtraDialogue:Town_DumpsterDiveComment_Adult");
						break;
					}
					item4.doEmote(num3.Value);
					who.changeFriendship(amount, item4);
					item4.setNewDialogue(dialogue, add: true, clearOnMovement: true);
					Game1.drawDialogue(item4);
					break;
				}
			}
		}
		Game1.stats.Increment("trashCansChecked");
		if (selected != null)
		{
			if (selected.AddToInventoryDirectly)
			{
				who.addItemByMenuIfNecessary(item);
			}
			else
			{
				Vector2 val = new Vector2(tile.X + 0.5f, tile.Y - 1f) * 64f;
				if (selected.CreateMultipleDebris)
				{
					Game1.createMultipleItemDebris(item, val, 2, this, (int)val.Y + 64);
				}
				else
				{
					Game1.createItemDebris(item, val, 2, this, (int)val.Y + 64);
				}
			}
		}
		return true;
	}

	public virtual bool TryGetGarbageItem(string id, double dailyLuck, out Item item, out GarbageCanItemData selected, out Random garbageRandom, Action<string> logError = null)
	{
		GarbageCanData val = DataLoader.GarbageCans(Game1.content);
		GarbageCanEntryData valueOrDefault = val.GarbageCans.GetValueOrDefault(id);
		float num = ((valueOrDefault != null && valueOrDefault.BaseChance > 0f) ? valueOrDefault.BaseChance : val.DefaultBaseChance);
		num += (float)dailyLuck;
		if (Game1.player.stats.Get("Book_Trash") != 0)
		{
			num += 0.2f;
		}
		garbageRandom = Utility.CreateDaySaveRandom(777 + Game1.hash.GetDeterministicHashCode(id));
		int num2 = garbageRandom.Next(0, 100);
		for (int i = 0; i < num2; i++)
		{
			garbageRandom.NextDouble();
		}
		num2 = garbageRandom.Next(0, 100);
		for (int j = 0; j < num2; j++)
		{
			garbageRandom.NextDouble();
		}
		selected = null;
		item = null;
		bool flag = garbageRandom.NextDouble() < (double)num;
		ItemQueryContext context = new ItemQueryContext(this, Game1.player, garbageRandom, "garbage data '" + id + "'");
		List<GarbageCanItemData>[] array = new List<GarbageCanItemData>[3]
		{
			val.BeforeAll,
			valueOrDefault?.Items,
			val.AfterAll
		};
		foreach (List<GarbageCanItemData> list in array)
		{
			if (list == null)
			{
				continue;
			}
			foreach (GarbageCanItemData item3 in list)
			{
				if (string.IsNullOrWhiteSpace(((GenericSpawnItemData)item3).Id))
				{
					logError("ignored item entry with no Id field.");
				}
				else if ((flag || item3.IgnoreBaseChance) && GameStateQuery.CheckConditions(((GenericSpawnItemDataWithCondition)item3).Condition, this, null, null, null, garbageRandom))
				{
					bool error = false;
					Item item2 = ItemQueryResolver.TryResolveRandomItem((ISpawnItemData)(object)item3, context, avoidRepeat: false, null, null, null, delegate(string query, string message)
					{
						error = true;
						logError("failed parsing item query '" + query + "': " + message);
					});
					if (!error)
					{
						selected = item3;
						item = item2;
						break;
					}
				}
			}
			if (selected != null)
			{
				break;
			}
		}
		return item != null;
	}

	public virtual bool performAction(string fullActionString, Farmer who, Location tileLocation)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (fullActionString == null)
		{
			return false;
		}
		string[] action = ArgUtility.SplitBySpace(fullActionString);
		return performAction(action, who, tileLocation);
	}

	public virtual bool ShouldIgnoreAction(string[] action, Farmer who, Location tileLocation)
	{
		string text = ArgUtility.Get(action, 0);
		if (string.IsNullOrWhiteSpace(text))
		{
			return true;
		}
		if (!(text == "DropBox"))
		{
			if (text == "MonsterGrave")
			{
				return !who.eventsSeen.Contains("6963327");
			}
			return false;
		}
		if (Game1.player.team.specialOrders != null)
		{
			string text2 = ArgUtility.Get(action, 1);
			if (text2 != null)
			{
				foreach (SpecialOrder specialOrder in Game1.player.team.specialOrders)
				{
					if (specialOrder.UsesDropBox(text2))
					{
						return false;
					}
				}
			}
		}
		return true;
	}

	public virtual void ShowLockedDoorMessage(string[] action)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		Gender value = (Gender)1;
		string text = null;
		string[] array = new string[(action.Length == 2) ? 1 : 2];
		for (int i = 0; i < array.Length; i++)
		{
			string text2 = action[i + 1];
			NPC characterFromName = Game1.getCharacterFromName(text2);
			if (characterFromName != null)
			{
				text = characterFromName.Name;
				value = characterFromName.Gender;
				array[i] = characterFromName.displayName;
				continue;
			}
			if (NPC.TryGetData(text2, out var data))
			{
				text = text2;
				value = data.Gender;
				array[i] = TokenParser.ParseText(data.DisplayName);
				continue;
			}
			return;
		}
		string dialogue;
		if (array.Length > 1)
		{
			dialogue = Game1.content.LoadString("Strings\\Locations:DoorUnlock_NotFriend_Couple", array[0], array[1]);
		}
		else
		{
			string sub = array[0];
			dialogue = Game1.content.LoadStringReturnNullIfNotFound("Strings\\Locations:DoorUnlock_NotFriend_" + text) ?? Game1.content.LoadStringReturnNullIfNotFound($"Strings\\Locations:DoorUnlock_NotFriend_{value}", sub) ?? Game1.content.LoadString("Strings\\Locations:DoorUnlock_NotFriend_Female", sub);
		}
		Game1.drawObjectDialogue(dialogue);
	}

	public virtual bool performAction(string[] action, Farmer who, Location tileLocation)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_46fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_3bd5: Unknown result type (might be due to invalid IL or missing references)
		//IL_3b2c: Unknown result type (might be due to invalid IL or missing references)
		//IL_45d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_3b45: Unknown result type (might be due to invalid IL or missing references)
		//IL_4103: Unknown result type (might be due to invalid IL or missing references)
		//IL_235d: Unknown result type (might be due to invalid IL or missing references)
		//IL_2362: Unknown result type (might be due to invalid IL or missing references)
		//IL_2366: Unknown result type (might be due to invalid IL or missing references)
		//IL_236f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2385: Unknown result type (might be due to invalid IL or missing references)
		//IL_2248: Unknown result type (might be due to invalid IL or missing references)
		//IL_2cba: Unknown result type (might be due to invalid IL or missing references)
		//IL_3ad4: Unknown result type (might be due to invalid IL or missing references)
		//IL_197d: Unknown result type (might be due to invalid IL or missing references)
		//IL_3b00: Unknown result type (might be due to invalid IL or missing references)
		//IL_3b58: Unknown result type (might be due to invalid IL or missing references)
		//IL_3abf: Unknown result type (might be due to invalid IL or missing references)
		//IL_3260: Unknown result type (might be due to invalid IL or missing references)
		//IL_3aed: Unknown result type (might be due to invalid IL or missing references)
		//IL_3e2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_3b19: Unknown result type (might be due to invalid IL or missing references)
		//IL_3b71: Unknown result type (might be due to invalid IL or missing references)
		//IL_459e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ad4: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ade: Unknown result type (might be due to invalid IL or missing references)
		//IL_2b08: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e57: Unknown result type (might be due to invalid IL or missing references)
		//IL_152a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1539: Unknown result type (might be due to invalid IL or missing references)
		//IL_153e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1556: Unknown result type (might be due to invalid IL or missing references)
		//IL_155b: Unknown result type (might be due to invalid IL or missing references)
		//IL_156b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1570: Unknown result type (might be due to invalid IL or missing references)
		//IL_2d6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2d76: Unknown result type (might be due to invalid IL or missing references)
		//IL_3487: Unknown result type (might be due to invalid IL or missing references)
		//IL_3493: Unknown result type (might be due to invalid IL or missing references)
		//IL_2f77: Unknown result type (might be due to invalid IL or missing references)
		//IL_2f81: Unknown result type (might be due to invalid IL or missing references)
		//IL_30ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_3376: Unknown result type (might be due to invalid IL or missing references)
		//IL_2dcd: Unknown result type (might be due to invalid IL or missing references)
		//IL_2dd4: Unknown result type (might be due to invalid IL or missing references)
		//IL_2db1: Unknown result type (might be due to invalid IL or missing references)
		//IL_2fcb: Unknown result type (might be due to invalid IL or missing references)
		//IL_2fd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_2faf: Unknown result type (might be due to invalid IL or missing references)
		//IL_3fc0: Unknown result type (might be due to invalid IL or missing references)
		//IL_3f40: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b64: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b6b: Unknown result type (might be due to invalid IL or missing references)
		//IL_406f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e78: Unknown result type (might be due to invalid IL or missing references)
		//IL_2e82: Unknown result type (might be due to invalid IL or missing references)
		//IL_31ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_1862: Unknown result type (might be due to invalid IL or missing references)
		//IL_1871: Unknown result type (might be due to invalid IL or missing references)
		//IL_187b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1886: Unknown result type (might be due to invalid IL or missing references)
		//IL_3098: Unknown result type (might be due to invalid IL or missing references)
		//IL_30a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_30af: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ecc: Unknown result type (might be due to invalid IL or missing references)
		//IL_2ed3: Unknown result type (might be due to invalid IL or missing references)
		//IL_2eb0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c01: Unknown result type (might be due to invalid IL or missing references)
		//IL_322b: Unknown result type (might be due to invalid IL or missing references)
		//IL_16e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_1702: Unknown result type (might be due to invalid IL or missing references)
		//IL_1711: Unknown result type (might be due to invalid IL or missing references)
		//IL_1716: Unknown result type (might be due to invalid IL or missing references)
		//IL_172d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1732: Unknown result type (might be due to invalid IL or missing references)
		//IL_1742: Unknown result type (might be due to invalid IL or missing references)
		//IL_1747: Unknown result type (might be due to invalid IL or missing references)
		//IL_1789: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d23: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dab: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dca: Unknown result type (might be due to invalid IL or missing references)
		if (ShouldIgnoreAction(action, who, tileLocation))
		{
			return false;
		}
		if (!ArgUtility.TryGet(action, 0, out var value, out var error, allowBlank: true, "string actionType"))
		{
			return LogError(error);
		}
		if (who.IsLocalPlayer)
		{
			if (registeredTileActions.TryGetValue(value, out var value2))
			{
				return value2(this, action, who, new Point(tileLocation.X, tileLocation.Y));
			}
			switch (value)
			{
			case "None":
				return true;
			case "BuildingGoldClock":
			{
				bool flag = !Game1.netWorldState.Value.goldenClocksTurnedOff.Value;
				who.currentLocation.createQuestionDialogue(Game1.content.LoadString("Strings\\1_6_Strings:GoldClock_" + (flag ? "Off" : "On")), who.currentLocation.createYesNoResponses(), "GoldClock");
				break;
			}
			case "Bobbers":
				Game1.activeClickableMenu = new ChooseFromIconsMenu("bobbers");
				break;
			case "GrandpaMasteryNote":
				Game1.activeClickableMenu = new LetterViewerMenu(Game1.content.LoadString("Strings\\1_6_Strings:GrandpaMasteryNote", Game1.player.Name, Game1.player.farmName));
				break;
			case "Bookseller":
				if (Utility.getDaysOfBooksellerThisSeason().Contains(Game1.dayOfMonth))
				{
					if (Game1.player.mailReceived.Contains("read_a_book"))
					{
						createQuestionDialogue(Game1.content.LoadString("Strings\\1_6_Strings:books_welcome"), new Response[3]
						{
							new Response("Buy", Game1.content.LoadString("Strings\\1_6_Strings:buy_books")),
							new Response("Trade", Game1.content.LoadString("Strings\\1_6_Strings:trade_books")),
							new Response("Leave", Game1.content.LoadString("Strings\\1_6_Strings:Leave"))
						}, "Bookseller");
					}
					else
					{
						Utility.TryOpenShopMenu("Bookseller", null, playOpenSound: true);
					}
				}
				break;
			case "MasteryCave_Pedestal":
				Game1.activeClickableMenu = new MasteryTrackerMenu();
				break;
			case "MasteryCave_Farming":
				if (Game1.player.stats.Get(StatKeys.Mastery(0)) >= 0)
				{
					Game1.activeClickableMenu = new MasteryTrackerMenu(0);
				}
				break;
			case "MasteryCave_Fishing":
				if (Game1.player.stats.Get(StatKeys.Mastery(1)) >= 0)
				{
					Game1.activeClickableMenu = new MasteryTrackerMenu(1);
				}
				break;
			case "MasteryCave_Foraging":
				if (Game1.player.stats.Get(StatKeys.Mastery(2)) >= 0)
				{
					Game1.activeClickableMenu = new MasteryTrackerMenu(2);
				}
				break;
			case "MasteryCave_Combat":
				if (Game1.player.stats.Get(StatKeys.Mastery(4)) >= 0)
				{
					Game1.activeClickableMenu = new MasteryTrackerMenu(4);
				}
				break;
			case "MasteryCave_Mining":
				if (Game1.player.stats.Get(StatKeys.Mastery(3)) >= 0)
				{
					Game1.activeClickableMenu = new MasteryTrackerMenu(3);
				}
				break;
			case "MasteryRoom":
			{
				int num2 = Game1.player.farmingLevel.Value / 10 + Game1.player.fishingLevel.Value / 10 + Game1.player.foragingLevel.Value / 10 + Game1.player.miningLevel.Value / 10 + Game1.player.combatLevel.Value / 10;
				if (num2 >= 5)
				{
					Game1.playSound("doorClose");
					Game1.warpFarmer("MasteryCave", 7, 11, 0);
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\1_6_Strings:MasteryCave", num2));
				}
				break;
			}
			case "PrizeMachine":
				Game1.activeClickableMenu = new PrizeTicketMenu();
				break;
			case "SquidFestBooth":
				createQuestionDialogue(Game1.content.LoadString("Strings\\1_6_Strings:SquidFestBooth_Intro"), new Response[3]
				{
					new Response("Rewards", Game1.content.LoadString("Strings\\1_6_Strings:GetRewards")),
					new Response("Explanation", Game1.content.LoadString("Strings\\1_6_Strings:Explanation")),
					new Response("Leave", Game1.content.LoadString("Strings\\1_6_Strings:Leave"))
				}, "SquidFestBooth");
				break;
			case "TroutDerbyBooth":
				createQuestionDialogue(Game1.content.LoadString("Strings\\1_6_Strings:FishingDerbyBooth_Intro"), new Response[3]
				{
					new Response("Rewards", Game1.content.LoadString("Strings\\1_6_Strings:GetRewards")),
					new Response("Explanation", Game1.content.LoadString("Strings\\1_6_Strings:Explanation")),
					new Response("Leave", Game1.content.LoadString("Strings\\1_6_Strings:Leave"))
				}, "TroutDerbyBooth");
				break;
			case "FishingDerbySign":
				Game1.activeClickableMenu = new LetterViewerMenu(Game1.content.LoadString(Game1.IsSummer ? "Strings\\1_6_Strings:FishingDerbySign" : "Strings\\1_6_Strings:SquidFestSign"));
				break;
			case "SpecialWaterDroppable":
				if (!(this is MineShaft) || (this as MineShaft).mineLevel == 100)
				{
					if (who?.ActiveObject?.QualifiedItemId == "(O)103")
					{
						localSound("throwDownITem");
						who.reduceActiveItemByOne();
						TemporaryAnimatedSprite tempSprite = new TemporaryAnimatedSprite(103, 9999f, 1, 1, who.position.Value + new Vector2(0f, -128f), flicker: false, bigCraftable: false, flipped: false)
						{
							motion = new Vector2(4f, -4f),
							acceleration = new Vector2(0f, 0.3f),
							yStopCoordinate = (int)who.position.Y,
							id = 777
						};
						who.freezePause = 4000;
						tempSprite.reachedStopCoordinate = delegate
						{
							//IL_0034: Unknown result type (might be due to invalid IL or missing references)
							//IL_0041: Unknown result type (might be due to invalid IL or missing references)
							//IL_0046: Unknown result type (might be due to invalid IL or missing references)
							removeTemporarySpritesWithID(777);
							temporarySprites.Add(new TemporaryAnimatedSprite(28, 300f, 2, 1, tempSprite.position, flicker: false, flipped: false)
							{
								color = Color.OrangeRed
							});
							localSound("dropItemInWater");
							DelayedAction.functionAfterDelay(delegate
							{
								//IL_0048: Unknown result type (might be due to invalid IL or missing references)
								//IL_005a: Unknown result type (might be due to invalid IL or missing references)
								//IL_0069: Unknown result type (might be due to invalid IL or missing references)
								//IL_0073: Unknown result type (might be due to invalid IL or missing references)
								//IL_0078: Unknown result type (might be due to invalid IL or missing references)
								//IL_0089: Unknown result type (might be due to invalid IL or missing references)
								//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
								//IL_00df: Unknown result type (might be due to invalid IL or missing references)
								//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
								//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
								//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
								//IL_010e: Unknown result type (might be due to invalid IL or missing references)
								//IL_0151: Unknown result type (might be due to invalid IL or missing references)
								//IL_0163: Unknown result type (might be due to invalid IL or missing references)
								//IL_0174: Unknown result type (might be due to invalid IL or missing references)
								//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
								//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
								//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
								//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
								//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
								//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
								//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
								//IL_02fb: Unknown result type (might be due to invalid IL or missing references)
								//IL_0300: Unknown result type (might be due to invalid IL or missing references)
								//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
								//IL_020c: Unknown result type (might be due to invalid IL or missing references)
								//IL_0226: Unknown result type (might be due to invalid IL or missing references)
								//IL_027d: Unknown result type (might be due to invalid IL or missing references)
								//IL_0282: Unknown result type (might be due to invalid IL or missing references)
								localSound("terraria_boneSerpent");
								temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\terraria_cat", new Rectangle(128, 96, 32, 32), 70f, 4, 5, tempSprite.position + new Vector2(-5f, -3f) * 4f, flicker: false, flipped: true, 0.99f, 0f, Color.White, 4f, 0f, 0f, 0f));
								temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\terraria_cat", new Rectangle(128, 96, 32, 32), 60f, 4, 5, tempSprite.position + new Vector2(-5f, 7f) * 4f, flicker: false, flipped: false, 1f, 0f, Color.White, 4f, 0f, 0f, 0f));
								temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\terraria_cat", new Rectangle(134, 2, 21, 38), 9999f, 1, 1, tempSprite.position, flicker: false, flipped: false, 0.98f, 0f, Color.White, 4f, 0f, 0f, 0f)
								{
									xPeriodic = true,
									xPeriodicLoopTime = 500f,
									xPeriodicRange = 2f,
									motion = new Vector2(0f, -8f)
								});
								for (int i = 0; i < 13; i++)
								{
									temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\terraria_cat", new Rectangle(134, (i == 12) ? 54 : 41, 21, 12), 9999f, 1, 1, tempSprite.position, flicker: false, flipped: false, 0.97f - (float)i * 0.01f, 0f, Color.White, 4f, 0f, 0f, 0f)
									{
										xPeriodic = true,
										xPeriodicLoopTime = 500 + Game1.random.Next(-50, 50),
										xPeriodicRange = 2f,
										motion = new Vector2(0f, -8f),
										delayBeforeAnimationStart = 220 + 80 * i
									});
								}
								TemporaryAnimatedSprite temporaryAnimatedSprite = new TemporaryAnimatedSprite(935, 9999f, 1, 1, tempSprite.position + new Vector2(0f, -128f), flicker: false, bigCraftable: false, flipped: false)
								{
									motion = new Vector2(-4f, -4f),
									acceleration = new Vector2(0f, 0.3f),
									yStopCoordinate = (int)(who.position.Y - 128f + 12f),
									id = 888
								};
								temporaryAnimatedSprite.reachedStopCoordinate = delegate
								{
									who.addItemByMenuIfNecessary(new Object("FarAwayStone", 1));
									who.currentLocation.removeTemporarySpritesWithID(888);
									localSound("coin");
								};
								who.currentLocation.temporarySprites.Add(temporaryAnimatedSprite);
							}, 1000);
						};
						temporarySprites.Add(tempSprite);
						return true;
					}
					if (who?.ActiveObject != null && !who.ActiveObject.questItem.Value && who.ActiveObject.QualifiedItemId != "(O)FarAwayStone" && who.ActiveObject.Edibility <= 0 && !who.ActiveObject.Name.Contains("Totem"))
					{
						ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(who?.ActiveObject.QualifiedItemId);
						if (dataOrErrorItem != null)
						{
							localSound("throwDownITem");
							int _id = Game1.random.Next();
							TemporaryAnimatedSprite tempSprite2 = new TemporaryAnimatedSprite(dataOrErrorItem.GetTextureName(), dataOrErrorItem.GetSourceRect(), 9999f, 1, 1, who.position.Value + new Vector2(0f, -128f), flicker: false, flipped: false)
							{
								motion = new Vector2(4f, -4f),
								acceleration = new Vector2(0f, 0.3f),
								yStopCoordinate = (int)who.position.Y,
								id = _id,
								scale = 4f * ((dataOrErrorItem.GetSourceRect().Height > 32) ? 0.5f : 1f)
							};
							who.reduceActiveItemByOne();
							tempSprite2.reachedStopCoordinate = delegate
							{
								//IL_0035: Unknown result type (might be due to invalid IL or missing references)
								//IL_0042: Unknown result type (might be due to invalid IL or missing references)
								//IL_0047: Unknown result type (might be due to invalid IL or missing references)
								//IL_0074: Unknown result type (might be due to invalid IL or missing references)
								//IL_007f: Unknown result type (might be due to invalid IL or missing references)
								//IL_008e: Unknown result type (might be due to invalid IL or missing references)
								//IL_0098: Unknown result type (might be due to invalid IL or missing references)
								//IL_009d: Unknown result type (might be due to invalid IL or missing references)
								//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
								//IL_011d: Unknown result type (might be due to invalid IL or missing references)
								//IL_0128: Unknown result type (might be due to invalid IL or missing references)
								//IL_0137: Unknown result type (might be due to invalid IL or missing references)
								//IL_0141: Unknown result type (might be due to invalid IL or missing references)
								//IL_0146: Unknown result type (might be due to invalid IL or missing references)
								//IL_0151: Unknown result type (might be due to invalid IL or missing references)
								//IL_0176: Unknown result type (might be due to invalid IL or missing references)
								//IL_017b: Unknown result type (might be due to invalid IL or missing references)
								//IL_0199: Unknown result type (might be due to invalid IL or missing references)
								//IL_019e: Unknown result type (might be due to invalid IL or missing references)
								removeTemporarySpritesWithID(_id);
								temporarySprites.Add(new TemporaryAnimatedSprite(28, 300f, 2, 1, tempSprite2.position, flicker: false, flipped: false)
								{
									color = Color.OrangeRed
								});
								temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(276, 1985, 12, 11), tempSprite2.position + new Vector2(2f, 0f) * 4f, flipped: false, 0f, Color.White)
								{
									interval = 50f,
									totalNumberOfLoops = 99999,
									animationLength = 4,
									scale = 4f,
									layerDepth = 0.99f,
									alphaFade = 0.02f
								});
								for (int i = 0; i < 4; i++)
								{
									temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(276, 1965, 8, 8), tempSprite2.position + new Vector2(2f, 0f) * 4f, flipped: false, 0f, Color.White)
									{
										motion = new Vector2((float)Game1.random.Next(-15, 26) / 10f, -4f),
										acceleration = new Vector2(0f, (float)Game1.random.Next(3, 7) / 30f),
										interval = 50f,
										totalNumberOfLoops = 99999,
										animationLength = 7,
										scale = 4f,
										layerDepth = 0.99f,
										alphaFade = 0.02f,
										delayBeforeAnimationStart = i * 30
									});
								}
								localSound("dropItemInWater");
								localSound("fireball");
							};
							temporarySprites.Add(tempSprite2);
						}
						return true;
					}
				}
				return false;
			case "ForestPylon":
				if (who?.ActiveObject?.QualifiedItemId == "(O)FarAwayStone")
				{
					who.reduceActiveItemByOne();
					Game1.playSound("openBox");
					Game1.player.mailReceived.Add("hasActivatedForestPylon");
					temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\terraria_cat", new Rectangle(0, 106, 14, 22), new Vector2(16.6f, 2.5f) * 64f, flipped: false, 0f, Color.White)
					{
						animationLength = 8,
						interval = 100f,
						totalNumberOfLoops = 9999,
						scale = 4f
					});
					Game1.player.freezePause = 3000;
					DelayedAction.functionAfterDelay(delegate
					{
						Game1.globalFadeToBlack(delegate
						{
							startEvent(new Event(Game1.content.LoadString("Strings\\1_6_Strings:ForestPylonEvent")));
						});
					}, 1000);
				}
				else if (who.mailReceived.Contains("hasActivatedForestPylon"))
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\1_6_Strings:ForestPylonActivated"));
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\1_6_Strings:ForestPylon"));
				}
				break;
			case "Garbage":
			{
				if (!ArgUtility.TryGet(action, 1, out var id, out error, allowBlank: true, "string id"))
				{
					return LogError(error);
				}
				CheckGarbage(id, new Vector2((float)tileLocation.X, (float)tileLocation.Y), who, playAnimations: true, reactNpcs: true, delegate(string garbageError)
				{
					Game1.log.Warn($"Ignored invalid 'Action Garbage {id}' property: {garbageError}.");
				});
				Game1.haltAfterCheck = false;
				return true;
			}
			case "kitchen":
			case "Kitchen":
				ActivateKitchen();
				return true;
			case "Forge":
				Game1.activeClickableMenu = new ForgeMenu();
				return true;
			case "SummitBoulder":
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:SummitBoulder"));
				break;
			case "QiCat":
				ShowQiCat();
				break;
			case "QiGemShop":
				return Utility.TryOpenShopMenu("QiGemShop", null, playOpenSound: true);
			case "QiChallengeBoard":
				Game1.player.team.qiChallengeBoardMutex.RequestLock(delegate
				{
					Game1.activeClickableMenu = new SpecialOrdersBoard("Qi")
					{
						behaviorBeforeCleanup = delegate
						{
							Game1.player.team.qiChallengeBoardMutex.ReleaseLock();
						}
					};
				});
				break;
			case "SpecialOrdersPrizeTickets":
				if (Game1.player.stats.Get("specialOrderPrizeTickets") != 0)
				{
					if (Game1.player.couldInventoryAcceptThisItem(ItemRegistry.Create("(O)PrizeTicket")))
					{
						Game1.player.addItemToInventoryBool(ItemRegistry.Create("(O)PrizeTicket"));
						Game1.player.stats.Decrement("specialOrderPrizeTickets");
						Game1.playSound("coin");
					}
					else
					{
						Game1.showRedMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:Crop.cs.588"));
					}
				}
				break;
			case "SpecialOrders":
				Game1.player.team.ordersBoardMutex.RequestLock(delegate
				{
					Game1.activeClickableMenu = new SpecialOrdersBoard
					{
						behaviorBeforeCleanup = delegate
						{
							Game1.player.team.ordersBoardMutex.ReleaseLock();
						}
					};
				});
				break;
			case "MonsterGrave":
				Game1.multipleDialogues(Game1.content.LoadString("Strings\\Locations:Backwoods_MonsterGrave").Split('#'));
				break;
			case "ObeliskWarp":
			{
				if (!ArgUtility.TryGet(action, 1, out var value39, out error, allowBlank: true, "string targetLocation") || !ArgUtility.TryGetPoint(action, 2, out var value40, out error, "Point targetTile") || !ArgUtility.TryGetOptionalBool(action, 4, out var value41, out error, defaultValue: false, "bool forceDismount"))
				{
					return LogError(error);
				}
				Building.PerformObeliskWarp(value39, value40.X, value40.Y, value41, who);
				return true;
			}
			case "PlayEvent":
			{
				if (!ArgUtility.TryGet(action, 1, out var value15, out error, allowBlank: true, "string eventId") || !ArgUtility.TryGetOptionalBool(action, 2, out var value16, out error, defaultValue: true, "bool checkPreconditions") || !ArgUtility.TryGetOptionalBool(action, 3, out var value17, out error, defaultValue: true, "bool checkSeen") || !ArgUtility.TryGetOptionalRemainder(action, 4, out var value18))
				{
					return LogError(error);
				}
				if (Game1.PlayEvent(value15, value16, value17))
				{
					return true;
				}
				if (value18 != null)
				{
					return performAction(value18, who, tileLocation);
				}
				return false;
			}
			case "OpenShop":
			{
				if (!ArgUtility.TryGet(action, 1, out var value22, out error, allowBlank: true, "string shopId") || !ArgUtility.TryGetOptional(action, 2, out var value23, out error, null, allowBlank: true, "string direction") || !ArgUtility.TryGetOptionalInt(action, 3, out var value24, out error, -1, "int openTime") || !ArgUtility.TryGetOptionalInt(action, 4, out var value25, out error, -1, "int closeTime") || !ArgUtility.TryGetOptionalInt(action, 5, out var value26, out error, -1, "int shopAreaX") || !ArgUtility.TryGetOptionalInt(action, 6, out var value27, out error, -1, "int shopAreaY") || !ArgUtility.TryGetOptionalInt(action, 7, out var value28, out error, -1, "int shopAreaWidth") || !ArgUtility.TryGetOptionalInt(action, 8, out var value29, out error, -1, "int shopAreaHeight"))
				{
					return LogError(error);
				}
				Rectangle? val = null;
				if (value26 != -1 || value27 != -1 || value28 != -1 || value29 != -1)
				{
					if (value26 == -1 || value27 == -1 || value28 == -1 || value29 == -1)
					{
						return LogError("when specifying any of the shop area 'x y width height' arguments (indexes 5-8), all four must be specified");
					}
					val = new Rectangle(value26, value27, value28, value29);
				}
				switch (value23)
				{
				case "down":
					if (who.TilePoint.Y < tileLocation.Y)
					{
						return false;
					}
					break;
				case "up":
					if (who.TilePoint.Y > tileLocation.Y)
					{
						return false;
					}
					break;
				case "left":
					if (who.TilePoint.X > tileLocation.X)
					{
						return false;
					}
					break;
				case "right":
					if (who.TilePoint.X < tileLocation.X)
					{
						return false;
					}
					break;
				}
				if ((value24 >= 0 && Game1.timeOfDay < value24) || (value25 >= 0 && Game1.timeOfDay >= value25))
				{
					return false;
				}
				string shopId = value22;
				Rectangle? ownerArea = val;
				bool forceOpen = !val.HasValue;
				return Utility.TryOpenShopMenu(shopId, this, ownerArea, null, forceOpen);
			}
			case "Warp_Sunroom_Door":
				if (who.getFriendshipHeartLevelForNPC("Caroline") >= 2)
				{
					playSound("doorClose", (Vector2?)new Vector2((float)tileLocation.X, (float)tileLocation.Y), (int?)null, SoundContext.Default);
					Game1.warpFarmer("Sunroom", 5, 13, flip: false);
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Caroline_Sunroom_Door"));
				}
				break;
			case "DogStatue":
			{
				if (canRespec(0) || canRespec(3) || canRespec(2) || canRespec(4) || canRespec(1))
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatue"), createYesNoResponses(), "dogStatue");
					break;
				}
				string text = Game1.content.LoadString("Strings\\Locations:Sewer_DogStatue");
				text = text.Substring(0, text.LastIndexOf('^'));
				Game1.drawObjectDialogue(text);
				break;
			}
			case "WizardBook":
				if (who.mailReceived.Contains("hasPickedUpMagicInk") || who.hasMagicInk)
				{
					ShowConstructOptions("Wizard");
				}
				break;
			case "EvilShrineLeft":
				if (who.getChildrenCount() == 0)
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:WitchHut_EvilShrineLeftInactive"));
				}
				else
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:WitchHut_EvilShrineLeft"), createYesNoResponses(), "evilShrineLeft");
				}
				break;
			case "EvilShrineCenter":
				if (who.isDivorced())
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:WitchHut_EvilShrineCenter"), createYesNoResponses(), "evilShrineCenter");
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:WitchHut_EvilShrineCenterInactive"));
				}
				break;
			case "EvilShrineRight":
				if (Game1.spawnMonstersAtNight)
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:WitchHut_EvilShrineRightDeActivate"), createYesNoResponses(), "evilShrineRightDeActivate");
				}
				else
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:WitchHut_EvilShrineRightActivate"), createYesNoResponses(), "evilShrineRightActivate");
				}
				break;
			case "Tailoring":
				if (who.eventsSeen.Contains("992559"))
				{
					Game1.activeClickableMenu = new TailoringMenu();
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:HaleyHouse_SewingMachine"));
				}
				break;
			case "DyePot":
				if (who.eventsSeen.Contains("992559"))
				{
					if (!DyeMenu.IsWearingDyeable())
					{
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:DyePot_NoDyeable"));
					}
					else
					{
						Game1.activeClickableMenu = new DyeMenu();
					}
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:HaleyHouse_DyePot"));
				}
				break;
			case "MagicInk":
				if (who.mailReceived.Add("hasPickedUpMagicInk"))
				{
					who.hasMagicInk = true;
					setMapTile(4, 11, 113, "Buildings", "untitled tile sheet");
					who.addItemByMenuIfNecessaryElseHoldUp(new SpecialItem(7));
				}
				break;
			case "LeoParrot":
				(getTemporarySpriteByID(5858585) as EmilysParrot)?.doAction();
				break;
			case "EmilyRoomObject":
				if (Game1.player.eventsSeen.Contains("463391") && Game1.player.spouse != "Emily")
				{
					(getTemporarySpriteByID(5858585) as EmilysParrot)?.doAction();
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:HaleyHouse_EmilyRoomObject"));
				}
				break;
			case "Starpoint":
			{
				if (!ArgUtility.TryGet(action, 1, out var value37, out error, allowBlank: true, "string which"))
				{
					return LogError(error);
				}
				doStarpoint(value37);
				break;
			}
			case "JojaShop":
				Utility.TryOpenShopMenu("Joja", null, playOpenSound: true);
				break;
			case "ColaMachine":
				createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:Saloon_ColaMachine_Question"), createYesNoResponses(), "buyJojaCola");
				break;
			case "IceCreamStand":
			{
				Rectangle value34 = default(Rectangle);
				((Rectangle)(ref value34))._002Ector(tileLocation.X, tileLocation.Y - 3, 1, 3);
				Utility.TryOpenShopMenu("IceCreamStand", this, value34);
				break;
			}
			case "WizardShrine":
				createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:WizardTower_WizardShrine").Replace('\n', '^'), createYesNoResponses(), "WizardShrine");
				break;
			case "HMTGF":
				if (who.ActiveObject != null && who.ActiveObject.QualifiedItemId == "(O)155")
				{
					Object obj = ItemRegistry.Create<Object>("(BC)155");
					if (!Game1.player.couldInventoryAcceptThisItem(obj) && Game1.player.ActiveObject.stack.Value > 1)
					{
						Game1.showRedMessage(Game1.content.LoadString("Strings\\StringsFromCSFiles:Crop.cs.588"));
						break;
					}
					Game1.player.reduceActiveItemByOne();
					Game1.player.makeThisTheActiveObject(obj);
					localSound("discoverMineral");
					Game1.flashAlpha = 1f;
				}
				break;
			case "HospitalShop":
			{
				Point tilePoint = who.TilePoint;
				Rectangle value13 = default(Rectangle);
				((Rectangle)(ref value13))._002Ector(tilePoint.X - 1, tilePoint.Y - 2, 2, 1);
				Utility.TryOpenShopMenu("Hospital", this, value13);
				break;
			}
			case "BuyBackpack":
			{
				Response response = new Response("Purchase", Game1.content.LoadString("Strings\\Locations:SeedShop_BuyBackpack_Response2000"));
				Response response2 = new Response("Purchase", Game1.content.LoadString("Strings\\Locations:SeedShop_BuyBackpack_Response10000"));
				Response response3 = new Response("Not", Game1.content.LoadString("Strings\\Locations:SeedShop_BuyBackpack_ResponseNo"));
				if (Game1.player.maxItems.Value == 12)
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:SeedShop_BuyBackpack_Question24"), new Response[2] { response, response3 }, "Backpack");
				}
				else if (Game1.player.maxItems.Value < 36)
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:SeedShop_BuyBackpack_Question36"), new Response[2] { response2, response3 }, "Backpack");
				}
				break;
			}
			case "BuyQiCoins":
				createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:Club_Buy100Coins"), createYesNoResponses(), "BuyQiCoins");
				break;
			case "LumberPile":
				if (!who.hasOrWillReceiveMail("TH_LumberPile") && who.hasOrWillReceiveMail("TH_SandDragon"))
				{
					Game1.player.hasClubCard = true;
					Game1.player.CanMove = false;
					Game1.player.mailReceived.Add("TH_LumberPile");
					Game1.player.addItemByMenuIfNecessaryElseHoldUp(new SpecialItem(2));
					Game1.player.removeQuest("5");
				}
				break;
			case "SandDragon":
				if (who.ActiveObject?.QualifiedItemId == "(O)768" && !who.hasOrWillReceiveMail("TH_SandDragon") && who.hasOrWillReceiveMail("TH_MayorFridge"))
				{
					who.reduceActiveItemByOne();
					Game1.player.CanMove = false;
					localSound("eat");
					Game1.player.mailReceived.Add("TH_SandDragon");
					Game1.multipleDialogues(new string[2]
					{
						Game1.content.LoadString("Strings\\Locations:Desert_SandDragon_ConsumeEssence"),
						Game1.content.LoadString("Strings\\Locations:Desert_SandDragon_MrQiNote")
					});
					Game1.player.removeQuest("4");
					Game1.player.addQuest("5");
				}
				else if (who.hasOrWillReceiveMail("TH_SandDragon"))
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Desert_SandDragon_MrQiNote"));
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Desert_SandDragon_Initial"));
				}
				break;
			case "RailroadBox":
				if (who.ActiveObject?.QualifiedItemId == "(O)394" && !who.hasOrWillReceiveMail("TH_Railroad") && who.hasOrWillReceiveMail("TH_Tunnel"))
				{
					who.reduceActiveItemByOne();
					Game1.player.CanMove = false;
					localSound("Ship");
					Game1.player.mailReceived.Add("TH_Railroad");
					Game1.multipleDialogues(new string[2]
					{
						Game1.content.LoadString("Strings\\Locations:Railroad_Box_ConsumeShell"),
						Game1.content.LoadString("Strings\\Locations:Railroad_Box_MrQiNote")
					});
					Game1.player.removeQuest("2");
					Game1.player.addQuest("3");
				}
				else if (who.hasOrWillReceiveMail("TH_Railroad"))
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Railroad_Box_MrQiNote"));
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Railroad_Box_Initial"));
				}
				break;
			case "TunnelSafe":
				if (who.ActiveObject?.QualifiedItemId == "(O)787" && !who.hasOrWillReceiveMail("TH_Tunnel"))
				{
					who.reduceActiveItemByOne();
					Game1.player.CanMove = false;
					playSound("openBox");
					DelayedAction.playSoundAfterDelay("doorCreakReverse", 500);
					Game1.player.mailReceived.Add("TH_Tunnel");
					Game1.multipleDialogues(new string[2]
					{
						Game1.content.LoadString("Strings\\Locations:Tunnel_TunnelSafe_ConsumeBattery"),
						Game1.content.LoadString("Strings\\Locations:Tunnel_TunnelSafe_MrQiNote")
					});
					Game1.player.addQuest("2");
				}
				else if (who.hasOrWillReceiveMail("TH_Tunnel"))
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Tunnel_TunnelSafe_MrQiNote"));
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Tunnel_TunnelSafe_Initial"));
				}
				break;
			case "SkullDoor":
				if (who.hasSkullKey || Utility.IsPassiveFestivalDay("DesertFestival"))
				{
					if (!who.hasUnlockedSkullDoor && !Utility.IsPassiveFestivalDay("DesertFestival"))
					{
						Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:SkullCave_SkullDoor_Unlock")));
						DelayedAction.playSoundAfterDelay("openBox", 500);
						DelayedAction.playSoundAfterDelay("openBox", 700);
						Game1.addMailForTomorrow("skullCave");
						who.hasUnlockedSkullDoor = true;
						who.completeQuest("19");
					}
					else
					{
						who.completelyStopAnimatingOrDoingAction();
						playSound("doorClose");
						DelayedAction.playSoundAfterDelay("stairsdown", 500, this);
						Game1.enterMine(121);
						MineShaft.numberOfCraftedStairsUsedThisRun = 0;
					}
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:SkullCave_SkullDoor_Locked"));
				}
				break;
			case "Crib":
				foreach (NPC character in characters)
				{
					if (!(character is Child child))
					{
						continue;
					}
					switch (child.Age)
					{
					case 1:
						child.toss(who);
						return true;
					case 0:
						Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:FarmHouse_Crib_NewbornSleeping", character.displayName)));
						return true;
					case 2:
						if (child.isInCrib())
						{
							return character.checkAction(who, this);
						}
						break;
					}
				}
				return false;
			case "WarpGreenhouse":
				if (Game1.MasterPlayer.mailReceived.Contains("ccPantry"))
				{
					who.faceGeneralDirection(new Vector2((float)tileLocation.X, (float)tileLocation.Y) * 64f);
					playSound("doorClose", (Vector2?)new Vector2((float)tileLocation.X, (float)tileLocation.Y), (int?)null, SoundContext.Default);
					GameLocation locationFromName = Game1.getLocationFromName("Greenhouse");
					int tileX = 10;
					int tileY = 23;
					if (locationFromName != null)
					{
						foreach (Warp warp in locationFromName.warps)
						{
							if (warp.TargetName == "Farm")
							{
								tileX = warp.X;
								tileY = warp.Y - 1;
								break;
							}
						}
					}
					Game1.warpFarmer("Greenhouse", tileX, tileY, flip: false);
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Farm_GreenhouseRuins"));
				}
				break;
			case "Arcade_Prairie":
				showPrairieKingMenu();
				break;
			case "Arcade_Minecart":
				if (who.hasSkullKey)
				{
					Response[] answerChoices2 = new Response[3]
					{
						new Response("Progress", Game1.content.LoadString("Strings\\Locations:Saloon_Arcade_Minecart_ProgressMode")),
						new Response("Endless", Game1.content.LoadString("Strings\\Locations:Saloon_Arcade_Minecart_EndlessMode")),
						new Response("Exit", Game1.content.LoadString("Strings\\Locations:Saloon_Arcade_Minecart_Exit"))
					};
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:Saloon_Arcade_Minecart_Menu"), answerChoices2, "MinecartGame");
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Saloon_Arcade_Minecart_Inactive"));
				}
				break;
			case "WarpCommunityCenter":
				if (Game1.MasterPlayer.mailReceived.Contains("ccDoorUnlock") || Game1.MasterPlayer.mailReceived.Contains("JojaMember"))
				{
					playSound("doorClose", (Vector2?)new Vector2((float)tileLocation.X, (float)tileLocation.Y), (int?)null, SoundContext.Default);
					Game1.warpFarmer("CommunityCenter", 32, 23, flip: false);
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\StringsFromCSFiles:GameLocation.cs.8175"));
				}
				break;
			case "AdventureShop":
				adventureShop();
				break;
			case "Warp":
			{
				if (!ArgUtility.TryGetPoint(action, 1, out var value10, out error, "Point tile") || !ArgUtility.TryGet(action, 3, out var value11, out error, allowBlank: true, "string locationName"))
				{
					return LogError(error);
				}
				bool num3 = action.Length < 5;
				who.faceGeneralDirection(new Vector2((float)tileLocation.X, (float)tileLocation.Y) * 64f);
				Rumble.rumble(0.15f, 200f);
				if (num3)
				{
					playSound("doorClose", (Vector2?)new Vector2((float)tileLocation.X, (float)tileLocation.Y), (int?)null, SoundContext.Default);
				}
				Game1.warpFarmer(value11, value10.X, value10.Y, flip: false);
				break;
			}
			case "WarpWomensLocker":
			{
				if (!ArgUtility.TryGetPoint(action, 1, out var value5, out error, "Point tile") || !ArgUtility.TryGet(action, 3, out var value6, out error, allowBlank: true, "string locationName"))
				{
					return LogError(error);
				}
				bool flag2 = action.Length < 5;
				if (who.IsMale)
				{
					if (who.IsLocalPlayer)
					{
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:WomensLocker_WrongGender"));
					}
					return true;
				}
				who.faceGeneralDirection(new Vector2((float)tileLocation.X, (float)tileLocation.Y) * 64f);
				if (flag2)
				{
					playSound("doorClose", (Vector2?)new Vector2((float)tileLocation.X, (float)tileLocation.Y), (int?)null, SoundContext.Default);
				}
				Game1.warpFarmer(value6, value5.X, value5.Y, flip: false);
				break;
			}
			case "WarpMensLocker":
			{
				if (!ArgUtility.TryGetPoint(action, 1, out var value50, out error, "Point tile") || !ArgUtility.TryGet(action, 3, out var value51, out error, allowBlank: true, "string locationName"))
				{
					return LogError(error);
				}
				bool flag3 = action.Length < 5;
				if (!who.IsMale)
				{
					if (who.IsLocalPlayer)
					{
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:MensLocker_WrongGender"));
					}
					return true;
				}
				who.faceGeneralDirection(new Vector2((float)tileLocation.X, (float)tileLocation.Y) * 64f);
				if (flag3)
				{
					playSound("doorClose", (Vector2?)new Vector2((float)tileLocation.X, (float)tileLocation.Y), (int?)null, SoundContext.Default);
				}
				Game1.warpFarmer(value51, value50.X, value50.Y, flip: false);
				break;
			}
			case "LockedDoorWarp":
			{
				if (!ArgUtility.TryGetPoint(action, 1, out var value44, out error, "Point tile") || !ArgUtility.TryGet(action, 3, out var value45, out error, allowBlank: true, "string locationName") || !ArgUtility.TryGetInt(action, 4, out var value46, out error, "int openTime") || !ArgUtility.TryGetInt(action, 5, out var value47, out error, "int closeTime") || !ArgUtility.TryGetOptional(action, 6, out var value48, out error, null, allowBlank: true, "string npcName") || !ArgUtility.TryGetOptionalInt(action, 7, out var value49, out error, 0, "int minFriendship"))
				{
					return LogError(error);
				}
				who.faceGeneralDirection(new Vector2((float)tileLocation.X, (float)tileLocation.Y) * 64f);
				lockedDoorWarp(value44, value45, value46, value47, value48, value49);
				break;
			}
			case "ConditionalDoor":
				if (action.Length > 1 && !Game1.eventUp)
				{
					if (GameStateQuery.CheckConditions(ArgUtility.UnsplitQuoteAware(action, ' ', 1)))
					{
						openDoor(tileLocation, playSound: true);
						return true;
					}
					string text7 = doesTileHaveProperty(tileLocation.X, tileLocation.Y, "LockedDoorMessage", "Buildings");
					if (text7 != null)
					{
						Game1.drawObjectDialogue(TokenParser.ParseText(Game1.content.LoadString(text7)));
					}
					else
					{
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:LockedDoor"));
					}
				}
				break;
			case "Door":
				if (action.Length > 1 && !Game1.eventUp)
				{
					for (int num4 = 1; num4 < action.Length; num4++)
					{
						string text6 = action[num4];
						string item = "doorUnlock" + text6;
						if (who.getFriendshipHeartLevelForNPC(text6) >= 2 || Game1.player.mailReceived.Contains(item))
						{
							Rumble.rumble(0.1f, 100f);
							Game1.player.mailReceived.Add(item);
							openDoor(tileLocation, playSound: true);
							return true;
						}
						if (text6 == "Sebastian" && IsGreenRainingHere() && Game1.year == 1)
						{
							Rumble.rumble(0.1f, 100f);
							openDoor(tileLocation, playSound: true);
							return true;
						}
					}
					ShowLockedDoorMessage(action);
					break;
				}
				openDoor(tileLocation, playSound: true);
				return true;
			case "Tutorial":
				Game1.activeClickableMenu = new TutorialMenu();
				break;
			case "Message":
			case "MessageSpeech":
			{
				if (!ArgUtility.TryGet(action, 1, out var value36, out error, allowBlank: true, "string translationKey"))
				{
					return LogError(error);
				}
				string text5 = null;
				try
				{
					text5 = Game1.content.LoadStringReturnNullIfNotFound(value36);
				}
				catch (Exception)
				{
					text5 = null;
				}
				if (text5 != null)
				{
					Game1.drawDialogueNoTyping(text5);
				}
				else
				{
					Game1.drawDialogueNoTyping(Game1.content.LoadString("Strings\\StringsFromMaps:" + value36.Replace("\"", "")));
				}
				break;
			}
			case "Dialogue":
			{
				if (!ArgUtility.TryGetRemainder(action, 1, out var value35, out error, ' ', "string dialogue"))
				{
					return LogError(error);
				}
				value35 = TokenParser.ParseText(value35);
				Game1.drawDialogueNoTyping(value35);
				break;
			}
			case "NPCSpeechMessageNoRadius":
			{
				if (!ArgUtility.TryGet(action, 1, out var value30, out error, allowBlank: true, "string npcName") || !ArgUtility.TryGet(action, 2, out var value31, out error, allowBlank: true, "string translationKey"))
				{
					return LogError(error);
				}
				NPC nPC2 = Game1.getCharacterFromName(value30);
				if (nPC2 == null)
				{
					try
					{
						nPC2 = new NPC(null, Vector2.Zero, "", 0, value30, datable: false, Game1.temporaryContent.Load<Texture2D>("Portraits\\" + value30));
					}
					catch (Exception)
					{
						return LogError("couldn't find or create a matching NPC");
					}
				}
				try
				{
					nPC2.setNewDialogue("Strings\\StringsFromMaps:" + value31, add: true);
					Game1.drawDialogue(nPC2);
					return true;
				}
				catch (Exception value32)
				{
					return LogError($"unhandled exception drawing dialogue: {value32}");
				}
			}
			case "NPCMessage":
			{
				if (!ArgUtility.TryGet(action, 1, out var value20, out error, allowBlank: true, "string npcName") || !ArgUtility.TryGetRemainder(action, 2, out var value21, out error, ' ', "string rawMessage"))
				{
					return LogError(error);
				}
				string text2 = value21.Replace("\"", "");
				NPC characterFromName = Game1.getCharacterFromName(value20);
				if (characterFromName != null && characterFromName.currentLocation == who.currentLocation && Utility.tileWithinRadiusOfPlayer(characterFromName.TilePoint.X, characterFromName.TilePoint.Y, 14, who))
				{
					try
					{
						string text3 = text2.Split('/')[0];
						string text4 = text3.Substring(text3.IndexOf(':') + 1);
						characterFromName.setNewDialogue(text3, add: true);
						Game1.drawDialogue(characterFromName);
						switch (text4)
						{
						case "AnimalShop.20":
						case "JoshHouse_Alex_Trash":
						case "SamHouse_Sam_Trash":
						case "SeedShop_Abigail_Drawers":
							if (who != null)
							{
								Game1.multiplayer.globalChatInfoMessage("Caught_Snooping", who.name.Value, characterFromName.GetTokenizedDisplayName());
							}
							break;
						}
						return true;
					}
					catch (Exception)
					{
						return false;
					}
				}
				try
				{
					Game1.drawDialogueNoTyping(Game1.content.LoadString(text2.Split('/')[1]));
					return false;
				}
				catch (Exception)
				{
					return false;
				}
			}
			case "ElliottPiano":
			{
				if (!ArgUtility.TryGetInt(action, 1, out var value14, out error, "int key"))
				{
					return LogError(error);
				}
				playElliottPiano(value14);
				break;
			}
			case "DropBox":
			{
				if (!ArgUtility.TryGet(action, 1, out var value12, out error, allowBlank: true, "string box_id"))
				{
					return LogError(error);
				}
				int minimum_capacity = 0;
				foreach (SpecialOrder specialOrder in Game1.player.team.specialOrders)
				{
					if (specialOrder.UsesDropBox(value12))
					{
						minimum_capacity = Math.Max(minimum_capacity, specialOrder.GetMinimumDropBoxCapacity(value12));
					}
				}
				foreach (SpecialOrder order in Game1.player.team.specialOrders)
				{
					if (!order.UsesDropBox(value12))
					{
						continue;
					}
					order.donateMutex.RequestLock(delegate
					{
						while (order.donatedItems.Count < minimum_capacity)
						{
							order.donatedItems.Add(null);
						}
						Game1.activeClickableMenu = new QuestContainerMenu(order.donatedItems, 3, order.HighlightAcceptableItems, order.GetAcceptCount, order.UpdateDonationCounts, order.ConfirmCompleteDonations);
					});
					return true;
				}
				return false;
			}
			case "playSound":
			{
				if (!ArgUtility.TryGet(action, 1, out var value19, out error, allowBlank: true, "string audioName"))
				{
					return LogError(error);
				}
				localSound(value19);
				break;
			}
			case "Letter":
			{
				if (!ArgUtility.TryGet(action, 1, out var value9, out error, allowBlank: true, "string translationKey"))
				{
					return LogError(error);
				}
				Game1.drawLetterMessage(Game1.content.LoadString("Strings\\StringsFromMaps:" + value9.Replace("\"", "")));
				break;
			}
			case "MessageOnce":
			{
				if (!ArgUtility.TryGet(action, 1, out var value7, out error, allowBlank: true, "string eventFlag") || !ArgUtility.TryGetRemainder(action, 2, out var value8, out error, ' ', "string dialogue"))
				{
					return LogError(error);
				}
				if (who.eventsSeen.Add(value7))
				{
					Game1.drawObjectDialogue(Game1.parseText(value8));
				}
				break;
			}
			case "Lamp":
				if (lightLevel.Value == 0f)
				{
					lightLevel.Value = 0.6f;
				}
				else
				{
					lightLevel.Value = 0f;
				}
				playSound("openBox");
				break;
			case "Billboard":
				Game1.activeClickableMenu = new Billboard(ArgUtility.Get(action, 1) == "3");
				break;
			case "MinecartTransport":
			{
				string networkId = ArgUtility.Get(action, 1) ?? "Default";
				string excludeDestinationId = ArgUtility.Get(action, 2);
				ShowMineCartMenu(networkId, excludeDestinationId);
				return true;
			}
			case "MineElevator":
				if (MineShaft.lowestLevelReached < 5)
				{
					Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:Mines_MineElevator_NotWorking")));
				}
				else
				{
					Game1.activeClickableMenu = new MineElevatorMenu();
				}
				break;
			case "Mine":
			case "NextMineLevel":
			{
				if (!ArgUtility.TryGetOptionalInt(action, 1, out var value3, out error, 1, "int mineLevel"))
				{
					return LogError(error);
				}
				playSound("stairsdown");
				Game1.enterMine(value3);
				break;
			}
			case "ExitMine":
			{
				Response[] answerChoices = new Response[3]
				{
					new Response("Leave", Game1.content.LoadString("Strings\\Locations:Mines_LeaveMine")),
					new Response("Go", Game1.content.LoadString("Strings\\Locations:Mines_GoUp")),
					new Response("Do", Game1.content.LoadString("Strings\\Locations:Mines_DoNothing"))
				};
				createQuestionDialogue(" ", answerChoices, "ExitMine");
				break;
			}
			case "GoldenScythe":
				if (!Game1.player.mailReceived.Contains("gotGoldenScythe"))
				{
					if (!Game1.player.isInventoryFull())
					{
						Game1.playSound("parry");
						Game1.player.mailReceived.Add("gotGoldenScythe");
						setMapTile(29, 4, 245, "Front", "mine");
						setMapTile(30, 4, 246, "Front", "mine");
						setMapTile(29, 5, 261, "Front", "mine");
						setMapTile(30, 5, 262, "Front", "mine");
						setMapTile(29, 6, 277, "Buildings", "mine");
						setMapTile(30, 56, 278, "Buildings", "mine");
						Game1.player.addItemByMenuIfNecessaryElseHoldUp(ItemRegistry.Create("(W)53"));
					}
					else
					{
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\StringsFromCSFiles:Crop.cs.588"));
					}
				}
				else
				{
					Game1.changeMusicTrack("silence", track_interruptable: false, (MusicContext)0);
					performTouchAction("MagicWarp Mine 67 10", Game1.player.getStandingPosition());
				}
				break;
			case "Saloon":
				if (who.TilePoint.Y > tileLocation.Y)
				{
					return saloon(tileLocation);
				}
				return false;
			case "Carpenter":
				if (who.TilePoint.Y > tileLocation.Y)
				{
					return carpenters(tileLocation);
				}
				return false;
			case "AnimalShop":
				if (who.TilePoint.Y > tileLocation.Y)
				{
					return animalShop(tileLocation);
				}
				return false;
			case "Blacksmith":
				if (who.TilePoint.Y > tileLocation.Y)
				{
					return blacksmith(tileLocation);
				}
				return false;
			case "Jukebox":
				Game1.activeClickableMenu = new ChooseFromListMenu(Utility.GetJukeboxTracks(Game1.player, Game1.player.currentLocation), ChooseFromListMenu.playSongAction, isJukebox: true);
				break;
			case "Buy":
			{
				if (!ArgUtility.TryGet(action, 1, out var value43, out error, allowBlank: true, "string which"))
				{
					return LogError(error);
				}
				if (who.TilePoint.Y >= tileLocation.Y)
				{
					return HandleBuyAction(value43);
				}
				return false;
			}
			case "Craft":
				openCraftingMenu();
				break;
			case "MineSign":
			{
				if (!ArgUtility.TryGetRemainder(action, 1, out var value42, out error, ' ', "string dialogue"))
				{
					return LogError(error);
				}
				Game1.drawObjectDialogue(Game1.parseText(value42));
				break;
			}
			case "ClubSlots":
				Game1.currentMinigame = new Slots();
				break;
			case "ClubShop":
				Utility.TryOpenShopMenu("Casino", null, playOpenSound: true);
				break;
			case "ClubCards":
			case "BlackJack":
				if (ArgUtility.Get(action, 1) == "1000")
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:Club_CalicoJack_HS"), new Response[2]
					{
						new Response("Play", Game1.content.LoadString("Strings\\Locations:Club_CalicoJack_Play")),
						new Response("Leave", Game1.content.LoadString("Strings\\Locations:Club_CalicoJack_Leave"))
					}, "CalicoJackHS");
				}
				else
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:Club_CalicoJack"), new Response[3]
					{
						new Response("Play", Game1.content.LoadString("Strings\\Locations:Club_CalicoJack_Play")),
						new Response("Leave", Game1.content.LoadString("Strings\\Locations:Club_CalicoJack_Leave")),
						new Response("Rules", Game1.content.LoadString("Strings\\Locations:Club_CalicoJack_Rules"))
					}, "CalicoJack");
				}
				break;
			case "QiCoins":
				if (who.clubCoins > 0)
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Club_QiCoins", who.clubCoins));
				}
				else
				{
					createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:Club_QiCoins_BuyStarter"), createYesNoResponses(), "BuyClubCoins");
				}
				break;
			case "FarmerFile":
			case "ClubComputer":
				farmerFile();
				break;
			case "ClubSeller":
				createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:Club_ClubSeller"), new Response[2]
				{
					new Response("I'll", Game1.content.LoadString("Strings\\Locations:Club_ClubSeller_Yes")),
					new Response("No", Game1.content.LoadString("Strings\\Locations:Club_ClubSeller_No"))
				}, "ClubSeller");
				break;
			case "Mailbox":
				if (this is Farm && getBuildingAt(new Vector2((float)tileLocation.X, (float)tileLocation.Y))?.GetIndoors() is FarmHouse { IsOwnedByCurrentPlayer: false })
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Farm_OtherPlayerMailbox"));
				}
				else
				{
					mailbox();
				}
				break;
			case "Notes":
			{
				if (!ArgUtility.TryGetInt(action, 1, out var value38, out error, "int noteId"))
				{
					return LogError(error);
				}
				readNote(value38);
				break;
			}
			case "SpiritAltar":
				if (who.ActiveObject != null && Game1.player.team.sharedDailyLuck.Value != -0.12 && Game1.player.team.sharedDailyLuck.Value != 0.12)
				{
					if (who.ActiveObject.Price >= 60)
					{
						temporarySprites.Add(new TemporaryAnimatedSprite(352, 70f, 2, 2, new Vector2((float)(tileLocation.X * 64), (float)(tileLocation.Y * 64)), flicker: false, flipped: false));
						Game1.player.team.sharedDailyLuck.Value = 0.12;
						playSound("money");
					}
					else
					{
						temporarySprites.Add(new TemporaryAnimatedSprite(362, 50f, 6, 1, new Vector2((float)(tileLocation.X * 64), (float)(tileLocation.Y * 64)), flicker: false, flipped: false));
						Game1.player.team.sharedDailyLuck.Value = -0.12;
						playSound("thunder");
					}
					who.ActiveObject = null;
					who.showNotCarrying();
				}
				break;
			case "WizardHatch":
			{
				if (who.friendshipData.TryGetValue("Wizard", out var value33) && value33.Points >= 1000)
				{
					playSound("doorClose", (Vector2?)new Vector2((float)tileLocation.X, (float)tileLocation.Y), (int?)null, SoundContext.Default);
					Game1.warpFarmer("WizardHouseBasement", 4, 4, flip: true);
				}
				else
				{
					NPC nPC3 = characters[0];
					nPC3.CurrentDialogue.Push(new Dialogue(nPC3, "Data\\ExtraDialogue:Wizard_Hatch"));
					Game1.drawDialogue(nPC3);
				}
				break;
			}
			case "EnterSewer":
				if (who.mailReceived.Contains("OpenedSewer"))
				{
					playSound("stairsdown", (Vector2?)new Vector2((float)tileLocation.X, (float)tileLocation.Y), (int?)null, SoundContext.Default);
					Game1.warpFarmer("Sewer", 16, 11, 2);
				}
				else if (who.hasRustyKey)
				{
					playSound("openBox");
					Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:Forest_OpenedSewer")));
					who.mailReceived.Add("OpenedSewer");
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:LockedDoor"));
				}
				break;
			case "DwarfGrave":
				if (who.canUnderstandDwarves)
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Town_DwarfGrave_Translated").Replace('\n', '^'));
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\StringsFromCSFiles:GameLocation.cs.8214"));
				}
				break;
			case "Yoba":
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:SeedShop_Yoba"));
				break;
			case "ElliottBook":
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:ElliottHouse_ElliottBook_Blank"));
				break;
			case "Theater_Poster":
				if (Game1.MasterPlayer.hasOrWillReceiveMail("ccMovieTheater"))
				{
					MovieData movieToday = MovieTheater.GetMovieToday();
					if (movieToday != null)
					{
						Game1.multipleDialogues(new string[2]
						{
							Game1.content.LoadString("Strings\\Locations:Theater_Poster_0", TokenParser.ParseText(movieToday.Title)),
							Game1.content.LoadString("Strings\\Locations:Theater_Poster_1", TokenParser.ParseText(movieToday.Description))
						});
					}
				}
				break;
			case "Theater_PosterComingSoon":
				if (Game1.MasterPlayer.hasOrWillReceiveMail("ccMovieTheater"))
				{
					MovieData upcomingMovie = MovieTheater.GetUpcomingMovie();
					if (upcomingMovie != null)
					{
						Game1.multipleDialogues(new string[1] { Game1.content.LoadString("Strings\\Locations:Theater_Poster_Coming_Soon", TokenParser.ParseText(upcomingMovie.Title)) });
					}
				}
				break;
			case "Theater_Entrance":
			{
				if (!Game1.MasterPlayer.hasOrWillReceiveMail("ccMovieTheater"))
				{
					break;
				}
				if (Game1.player.team.movieMutex.IsLocked())
				{
					Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Characters:MovieTheater_CurrentlyShowing")));
					break;
				}
				if (Game1.isFestival())
				{
					Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Characters:MovieTheater_ClosedFestival")));
					break;
				}
				if (Game1.timeOfDay > 2100 || Game1.timeOfDay < 900)
				{
					string sub = Game1.getTimeOfDayString(900).Replace(" ", "");
					string sub2 = Game1.getTimeOfDayString(2100).Replace(" ", "");
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:LockedDoor_OpenRange", sub, sub2));
					break;
				}
				if (Game1.player.lastSeenMovieWeek.Value >= Game1.Date.TotalWeeks)
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Characters:MovieTheater_AlreadySeen"));
					break;
				}
				NPC nPC = null;
				foreach (MovieInvitation movieInvitation in Game1.player.team.movieInvitations)
				{
					if (movieInvitation.farmer == Game1.player && !movieInvitation.fulfilled && MovieTheater.GetFirstInvitedPlayer(movieInvitation.invitedNPC) == Game1.player)
					{
						nPC = movieInvitation.invitedNPC;
						break;
					}
				}
				if (Game1.player.Items.ContainsId("(O)809"))
				{
					string question = ((nPC != null) ? Game1.content.LoadString("Strings\\Characters:MovieTheater_WatchWithFriendPrompt", nPC.displayName) : Game1.content.LoadString("Strings\\Characters:MovieTheater_WatchAlonePrompt"));
					Game1.currentLocation.createQuestionDialogue(question, Game1.currentLocation.createYesNoResponses(), "EnterTheaterSpendTicket");
				}
				else
				{
					Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Characters:MovieTheater_NoTicket")));
				}
				break;
			}
			case "Theater_BoxOffice":
				if (Game1.MasterPlayer.hasOrWillReceiveMail("ccMovieTheater"))
				{
					if (Game1.isFestival())
					{
						Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Characters:MovieTheater_ClosedFestival")));
					}
					else if (Game1.timeOfDay > 2100)
					{
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Characters:MovieTheater_BoxOfficeClosed"));
					}
					else if (MovieTheater.GetMovieToday() != null)
					{
						Utility.TryOpenShopMenu("BoxOffice", null, playOpenSound: true);
					}
				}
				break;
			case "BuildingChest":
			{
				if (!ArgUtility.TryGet(action, 1, out var value4, out error, allowBlank: true, "string buildingAction"))
				{
					return LogError(error);
				}
				_ = getBuildingAt(new Vector2((float)tileLocation.X, (float)tileLocation.Y))?.PerformBuildingChestAction(value4, who) ?? false;
				return true;
			}
			case "BuildingToggleAnimalDoor":
			{
				Building buildingAt = getBuildingAt(new Vector2((float)tileLocation.X, (float)tileLocation.Y));
				if (buildingAt != null)
				{
					if (Game1.didPlayerJustRightClick(ignoreNonMouseHeldInput: true))
					{
						buildingAt.ToggleAnimalDoor(who);
					}
					return true;
				}
				break;
			}
			case "BuildingSilo":
			{
				if (!who.IsLocalPlayer)
				{
					break;
				}
				Object activeObject = who.ActiveObject;
				if (activeObject?.QualifiedItemId == "(O)178")
				{
					activeObject.FixStackSize();
					int num = activeObject.Stack - tryToAddHay(activeObject.Stack);
					if (num > 0)
					{
						if (activeObject.ConsumeStack(num) == null)
						{
							who.ActiveObject = null;
						}
						Game1.playSound("Ship");
						DelayedAction.playSoundAfterDelay("grassyStep", 100);
						Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Buildings:AddedHay", num));
					}
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Buildings:PiecesOfHay", piecesOfHay, GetHayCapacity()));
				}
				break;
			}
			default:
				return false;
			}
			return true;
		}
		if (value == "Door")
		{
			openDoor(tileLocation, playSound: true);
		}
		return false;
		bool LogError(string errorPhrase)
		{
			LogTileActionError(action, tileLocation.X, tileLocation.Y, errorPhrase);
			return false;
		}
	}

	public void showPrairieKingMenu()
	{
		if (Game1.player.jotpkProgress.Value == null)
		{
			Game1.currentMinigame = new AbigailGame();
			return;
		}
		Response[] answerChoices = new Response[3]
		{
			new Response("Continue", Game1.content.LoadString("Strings\\Locations:Saloon_Arcade_Cowboy_Continue")),
			new Response("NewGame", Game1.content.LoadString("Strings\\Locations:Saloon_Arcade_Cowboy_NewGame")),
			new Response("Exit", Game1.content.LoadString("Strings\\Locations:Saloon_Arcade_Minecart_Exit"))
		};
		createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:Saloon_Arcade_Cowboy_Menu"), answerChoices, "CowboyGame");
	}

	public void ShowMineCartMenu(string networkId, string excludeDestinationId)
	{
		if (Game1.player.mount != null)
		{
			return;
		}
		Dictionary<string, MinecartNetworkData> dictionary = DataLoader.Minecarts(Game1.content);
		if (networkId == null || !dictionary.TryGetValue(networkId, out var network))
		{
			Game1.log.Warn("Can't show minecart menu for unknown network ID '" + networkId + "'.");
			return;
		}
		if (!GameStateQuery.CheckConditions(network.UnlockCondition, this))
		{
			Game1.drawObjectDialogue(TokenParser.ParseText(network.LockedMessage) ?? Game1.content.LoadString("Strings\\Locations:MineCart_OutOfOrder"));
			return;
		}
		MinecartNetworkData obj = network;
		if (obj == null || !(obj.Destinations?.Count > 0))
		{
			Game1.log.Warn("Can't show minecart menu for network ID '" + networkId + "' with missing destination data.");
			return;
		}
		List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
		Dictionary<string, MinecartDestinationData> destinationLookup = new Dictionary<string, MinecartDestinationData>();
		foreach (MinecartDestinationData destination2 in network.Destinations)
		{
			if (string.IsNullOrWhiteSpace(destination2?.Id) || string.IsNullOrWhiteSpace(destination2?.TargetLocation))
			{
				Game1.log.Warn($"Ignored invalid minecart destination '{destination2?.Id}' in network '{networkId}' because its ID or location isn't specified.");
			}
			else
			{
				if (destination2.Id.EqualsIgnoreCase(excludeDestinationId) || !GameStateQuery.CheckConditions(destination2.Condition, this))
				{
					continue;
				}
				if (destinationLookup.TryAdd(destination2.Id, destination2))
				{
					string text = TokenParser.ParseText(destination2.DisplayName) ?? destination2.TargetLocation;
					if (destination2.Price > 0)
					{
						text = Game1.content.LoadString("Strings\\Locations:MineCart_DestinationWithPrice", text, destination2.Price);
					}
					list.Add(new KeyValuePair<string, string>(destination2.Id, text));
				}
				else
				{
					Game1.log.Warn($"Ignored minecart destination with duplicate ID '{destination2.Id}' in network '{networkId}'.");
				}
			}
		}
		ShowPagedResponses(TokenParser.ParseText(network.ChooseDestinationMessage) ?? Game1.content.LoadString("Strings\\Locations:MineCart_ChooseDestination"), list, delegate(string destinationId)
		{
			if (destinationLookup.TryGetValue(destinationId, out var destination))
			{
				int price = destination.Price;
				if (price < 1)
				{
					MinecartWarp(destination);
				}
				else
				{
					string numberWithCommas = Utility.getNumberWithCommas(price);
					string text2 = destination.BuyTicketMessage ?? network.BuyTicketMessage;
					text2 = ((text2 != null) ? string.Format(TokenParser.ParseText(network.BuyTicketMessage), numberWithCommas) : Game1.content.LoadString("Strings\\Locations:BuyTicket", numberWithCommas));
					createQuestionDialogue(text2, createYesNoResponses(), delegate(Farmer who, string whichAnswer)
					{
						if (whichAnswer == "Yes")
						{
							if (who.Money >= price)
							{
								who.Money -= price;
								MinecartWarp(destination);
							}
							else
							{
								Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney1"));
							}
						}
					});
				}
			}
		});
	}

	public void MinecartWarp(MinecartDestinationData destination)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		GameLocation gameLocation = Game1.RequireLocation(destination.TargetLocation);
		Point targetTile = destination.TargetTile;
		if (!Utility.TryParseDirection(destination.TargetDirection, out var parsed))
		{
			parsed = 2;
		}
		Game1.player.Halt();
		Game1.player.freezePause = 700;
		Game1.warpFarmer(gameLocation.NameOrUniqueName, targetTile.X, targetTile.Y, parsed);
		if (Game1.IsPlayingTownMusic && !gameLocation.IsOutdoors)
		{
			Game1.changeMusicTrack("none", track_interruptable: false, (MusicContext)0);
		}
	}

	public void lockedDoorWarp(Point tile, string locationName, int openTime, int closeTime, string npcName, int minFriendship)
	{
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		bool flag = Game1.player.HasTownKey;
		if (AreStoresClosedForFestival() && InValleyContext())
		{
			Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:FestivalDay_DoorLocked")));
			return;
		}
		if (locationName == "SeedShop" && Game1.shortDayNameFromDayOfSeason(Game1.dayOfMonth).Equals("Wed") && !Utility.HasAnyPlayerSeenEvent("191393") && !flag)
		{
			Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:SeedShop_LockedWed")));
			return;
		}
		if (locationName == "FishShop" && Game1.player.mailReceived.Contains("willyHours"))
		{
			openTime = 800;
		}
		if (flag)
		{
			if (flag && !InValleyContext())
			{
				flag = false;
			}
			if (flag && this is BeachNightMarket && locationName != "FishShop")
			{
				flag = false;
			}
		}
		Friendship value;
		bool flag2 = (flag || (Game1.timeOfDay >= openTime && Game1.timeOfDay < closeTime)) && (minFriendship <= 0 || IsWinterHere() || (Game1.player.friendshipData.TryGetValue(npcName, out value) && value.Points >= minFriendship));
		if (IsGreenRainingHere() && Game1.year == 1 && !(this is Beach) && !(this is Forest) && !locationName.Equals("AdventureGuild"))
		{
			flag2 = true;
		}
		if (flag2)
		{
			Rumble.rumble(0.15f, 200f);
			Game1.player.completelyStopAnimatingOrDoingAction();
			playSound("doorClose", Game1.player.Tile);
			Game1.warpFarmer(locationName, tile.X, tile.Y, flip: false);
		}
		else if (minFriendship <= 0)
		{
			string sub = Game1.getTimeOfDayString(openTime).Replace(" ", "");
			if (locationName == "FishShop" && Game1.player.mailReceived.Contains("willyHours"))
			{
				sub = Game1.getTimeOfDayString(800).Replace(" ", "");
			}
			string sub2 = Game1.getTimeOfDayString(closeTime).Replace(" ", "");
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:LockedDoor_OpenRange", sub, sub2));
		}
		else if (Game1.timeOfDay < openTime || Game1.timeOfDay >= closeTime)
		{
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:LockedDoor"));
		}
		else
		{
			NPC characterFromName = Game1.getCharacterFromName(npcName);
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:LockedDoor_FriendsOnly", characterFromName.displayName));
		}
	}

	public void playElliottPiano(int key)
	{
		if (Game1.IsMultiplayer && Game1.player.UniqueMultiplayerID % 111 == 0L)
		{
			switch (key)
			{
			case 1:
			{
				int? pitch = 500;
				playSound("toyPiano", null, pitch);
				break;
			}
			case 2:
			{
				int? pitch = 1200;
				playSound("toyPiano", null, pitch);
				break;
			}
			case 3:
			{
				int? pitch = 1400;
				playSound("toyPiano", null, pitch);
				break;
			}
			case 4:
			{
				int? pitch = 2000;
				playSound("toyPiano", null, pitch);
				break;
			}
			}
			return;
		}
		switch (key)
		{
		case 1:
		{
			int? pitch = 1100;
			playSound("toyPiano", null, pitch);
			break;
		}
		case 2:
		{
			int? pitch = 1500;
			playSound("toyPiano", null, pitch);
			break;
		}
		case 3:
		{
			int? pitch = 1600;
			playSound("toyPiano", null, pitch);
			break;
		}
		case 4:
		{
			int? pitch = 1800;
			playSound("toyPiano", null, pitch);
			break;
		}
		}
		switch (Game1.elliottPiano)
		{
		case 0:
			if (key == 2)
			{
				Game1.elliottPiano++;
			}
			else
			{
				Game1.elliottPiano = 0;
			}
			break;
		case 1:
			if (key == 4)
			{
				Game1.elliottPiano++;
			}
			else
			{
				Game1.elliottPiano = 0;
			}
			break;
		case 2:
			if (key == 3)
			{
				Game1.elliottPiano++;
			}
			else
			{
				Game1.elliottPiano = 0;
			}
			break;
		case 3:
			if (key == 2)
			{
				Game1.elliottPiano++;
			}
			else
			{
				Game1.elliottPiano = 0;
			}
			break;
		case 4:
			if (key == 3)
			{
				Game1.elliottPiano++;
			}
			else
			{
				Game1.elliottPiano = 0;
			}
			break;
		case 5:
			if (key == 4)
			{
				Game1.elliottPiano++;
			}
			else
			{
				Game1.elliottPiano = 0;
			}
			break;
		case 6:
			if (key == 2)
			{
				Game1.elliottPiano++;
			}
			else
			{
				Game1.elliottPiano = 0;
			}
			break;
		case 7:
			if (key == 1)
			{
				Game1.elliottPiano = 0;
				NPC characterFromName = getCharacterFromName("Elliott");
				if (!Game1.eventUp && characterFromName != null && !characterFromName.isMoving())
				{
					characterFromName.faceTowardFarmerForPeriod(1000, 100, faceAway: false, Game1.player);
					characterFromName.doEmote(20);
				}
			}
			else
			{
				Game1.elliottPiano = 0;
			}
			break;
		}
	}

	public void readNote(int which)
	{
		if (Game1.netWorldState.Value.LostBooksFound >= which)
		{
			string message = Game1.content.LoadString("Strings\\Notes:" + which).Replace('\n', '^');
			Game1.player.mailReceived.Add("lb_" + which);
			removeTemporarySpritesWithIDLocal(which);
			Game1.drawLetterMessage(message);
		}
		else
		{
			Game1.drawObjectDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Notes:Missing")));
		}
	}

	public void mailbox()
	{
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.mailbox.Count > 0)
		{
			string text = Game1.mailbox[0];
			if (!text.Contains("passedOut") && !text.Contains("Cooking"))
			{
				Game1.player.mailReceived.Add(text);
			}
			Game1.mailbox.RemoveAt(0);
			Dictionary<string, string> dictionary = DataLoader.Mail(Game1.content);
			string text2 = dictionary.GetValueOrDefault(text, "");
			if (text.StartsWith("passedOut"))
			{
				if (text.StartsWith("passedOut "))
				{
					string[] array = ArgUtility.SplitBySpace(text);
					int num = ((array.Length > 1) ? Convert.ToInt32(array[1]) : 0);
					text2 = Dialogue.applyGenderSwitchBlocks(str: dictionary[Utility.CreateDaySaveRandom(num).Next((Game1.player.getSpouse() != null && Game1.player.getSpouse().Name.Equals("Harvey")) ? 2 : 3) switch
					{
						0 => (Game1.MasterPlayer.hasCompletedCommunityCenter() && !Game1.MasterPlayer.mailReceived.Contains("JojaMember")) ? "passedOut4" : ("passedOut1_" + ((num > 0) ? "Billed" : "NotBilled") + "_" + (Game1.player.IsMale ? "Male" : "Female")), 
						1 => "passedOut2", 
						_ => "passedOut3_" + ((num > 0) ? "Billed" : "NotBilled"), 
					}], gender: Game1.player.Gender);
					text2 = string.Format(text2, num);
				}
				else
				{
					string[] array2 = ArgUtility.SplitBySpace(text);
					if (array2.Length > 1)
					{
						int num2 = Convert.ToInt32(array2[1]);
						text2 = Dialogue.applyGenderSwitchBlocks(Game1.player.Gender, dictionary[array2[0]]);
						text2 = string.Format(text2, num2);
					}
				}
			}
			if (text2.Length > 0)
			{
				Game1.activeClickableMenu = new LetterViewerMenu(text2, text);
			}
		}
		else if (Game1.mailbox.Count == 0)
		{
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\StringsFromCSFiles:GameLocation.cs.8429"));
		}
	}

	public void farmerFile()
	{
		Game1.multipleDialogues(new string[2]
		{
			Game1.content.LoadString("Strings\\UI:FarmerFile_1", Game1.player.Name, Game1.stats.StepsTaken, Game1.stats.GiftsGiven, Game1.stats.DaysPlayed, Game1.stats.DirtHoed, Game1.stats.ItemsCrafted, Game1.stats.ItemsCooked, Game1.stats.PiecesOfTrashRecycled).Replace('\n', '^'),
			Game1.content.LoadString("Strings\\UI:FarmerFile_2", Game1.stats.MonstersKilled, Game1.stats.FishCaught, Game1.stats.TimesFished, Game1.stats.SeedsSown, Game1.stats.ItemsShipped).Replace('\n', '^')
		});
	}

	public int getTotalCrops()
	{
		int num = 0;
		foreach (TerrainFeature value in terrainFeatures.Values)
		{
			if (value is HoeDirt { crop: not null } hoeDirt && !hoeDirt.crop.dead.Value)
			{
				num++;
			}
		}
		return num;
	}

	public int getTotalCropsReadyForHarvest()
	{
		int num = 0;
		foreach (TerrainFeature value in terrainFeatures.Values)
		{
			if (value is HoeDirt hoeDirt && hoeDirt.readyForHarvest())
			{
				num++;
			}
		}
		return num;
	}

	public int getTotalUnwateredCrops()
	{
		int num = 0;
		foreach (TerrainFeature value in terrainFeatures.Values)
		{
			if (value is HoeDirt { crop: not null } hoeDirt && hoeDirt.needsWatering() && !hoeDirt.isWatered())
			{
				num++;
			}
		}
		return num;
	}

	public int? getTotalGreenhouseCropsReadyForHarvest()
	{
		if (Game1.MasterPlayer.mailReceived.Contains("ccPantry"))
		{
			int num = 0;
			foreach (TerrainFeature value in Game1.RequireLocation("Greenhouse").terrainFeatures.Values)
			{
				if (value is HoeDirt hoeDirt && hoeDirt.readyForHarvest())
				{
					num++;
				}
			}
			return num;
		}
		return null;
	}

	public int getTotalOpenHoeDirt()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		foreach (TerrainFeature value in terrainFeatures.Values)
		{
			if (value is HoeDirt { crop: null } && !objects.ContainsKey(value.Tile))
			{
				num++;
			}
		}
		return num;
	}

	public int getTotalForageItems()
	{
		int num = 0;
		foreach (Object value in objects.Values)
		{
			if (value.isSpawnedObject.Value)
			{
				num++;
			}
		}
		return num;
	}

	public int getNumberOfMachinesReadyForHarvest()
	{
		int num = 0;
		foreach (Object value in objects.Values)
		{
			if (value.IsConsideredReadyMachineForComputer())
			{
				num++;
			}
		}
		string text = null;
		if (!(this is Farm))
		{
			if (this is IslandWest islandWest && islandWest.farmhouseRestored.Value)
			{
				text = "IslandFarmHouse";
			}
		}
		else
		{
			text = "FarmHouse";
		}
		if (text != null)
		{
			foreach (Object value2 in Game1.RequireLocation(text).objects.Values)
			{
				if (value2.IsConsideredReadyMachineForComputer())
				{
					num++;
				}
			}
		}
		foreach (Building building in buildings)
		{
			GameLocation indoors = building.GetIndoors();
			if (indoors == null)
			{
				continue;
			}
			foreach (Object value3 in indoors.objects.Values)
			{
				if (value3.IsConsideredReadyMachineForComputer())
				{
					num++;
				}
			}
		}
		return num;
	}

	public static void openCraftingMenu()
	{
		Game1.activeClickableMenu = new GameMenu(GameMenu.craftingTab);
	}

	public virtual bool HandleBuyAction(string which)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		if (which.Equals("Fish"))
		{
			int? maxOwnerY = Game1.player.TilePoint.Y - 1;
			return Utility.TryOpenShopMenu("FishShop", this, null, maxOwnerY);
		}
		if (this is SeedShop)
		{
			if (getCharacterFromName("Pierre") == null && Game1.IsVisitingIslandToday("Pierre"))
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:SeedShop_MoneyBox"));
				Game1.afterDialogues = delegate
				{
					Utility.TryOpenShopMenu("SeedShop", null, playOpenSound: true);
				};
			}
			else
			{
				Utility.TryOpenShopMenu("SeedShop", this, (Rectangle?)new Rectangle(4, 17, 1, 1), (int?)(Game1.player.TilePoint.Y - 1), forceOpen: false, playOpenSound: true, (Action<string>)null);
			}
			return true;
		}
		if (name.Equals("SandyHouse"))
		{
			Utility.TryOpenShopMenu("Sandy", this);
			return true;
		}
		return false;
	}

	public virtual bool isObjectAt(int x, int y)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		Vector2 key = default(Vector2);
		((Vector2)(ref key))._002Ector((float)(x / 64), (float)(y / 64));
		foreach (Furniture item in furniture)
		{
			Rectangle value = item.boundingBox.Value;
			if (((Rectangle)(ref value)).Contains(x, y))
			{
				return true;
			}
		}
		return objects.ContainsKey(key);
	}

	public virtual bool isObjectAtTile(int tileX, int tileY)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		Vector2 key = default(Vector2);
		((Vector2)(ref key))._002Ector((float)tileX, (float)tileY);
		foreach (Furniture item in furniture)
		{
			Rectangle value = item.boundingBox.Value;
			if (((Rectangle)(ref value)).Contains(tileX * 64, tileY * 64))
			{
				return true;
			}
		}
		return objects.ContainsKey(key);
	}

	public virtual Object getObjectAt(int x, int y, bool ignorePassables = false)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		Vector2 key = default(Vector2);
		((Vector2)(ref key))._002Ector((float)(x / 64), (float)(y / 64));
		foreach (Furniture item in furniture)
		{
			Rectangle value = item.boundingBox.Value;
			if (((Rectangle)(ref value)).Contains(x, y) && (!ignorePassables || !item.isPassable()))
			{
				return item;
			}
		}
		Object value2 = null;
		objects.TryGetValue(key, out value2);
		if (ignorePassables && value2 != null && value2.isPassable())
		{
			value2 = null;
		}
		return value2;
	}

	public Object getObjectAtTile(int x, int y, bool ignorePassables = false)
	{
		return getObjectAt(x * 64, y * 64, ignorePassables);
	}

	public virtual bool saloon(Location tileLocation)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		NPC characterFromName = getCharacterFromName("Gus");
		Rectangle value = default(Rectangle);
		((Rectangle)(ref value))._002Ector(9, 17, 10, 2);
		if (Utility.TryOpenShopMenu("Saloon", this, value))
		{
			characterFromName?.facePlayer(Game1.player);
			return true;
		}
		if (characterFromName == null && Game1.IsVisitingIslandToday("Gus"))
		{
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Saloon_MoneyBox"));
			Game1.afterDialogues = delegate
			{
				Utility.TryOpenShopMenu("Saloon", null, playOpenSound: true);
			};
			return true;
		}
		return false;
	}

	private void adventureShop()
	{
		if (Game1.player.itemsLostLastDeath.Count > 0)
		{
			List<Response> list = new List<Response>
			{
				new Response("Shop", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_Shop")),
				new Response("Recovery", Game1.content.LoadString("Strings\\Locations:AdventureGuild_ItemRecovery")),
				new Response("Leave", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_Leave"))
			};
			createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:AdventureGuild_Greeting"), list.ToArray(), "adventureGuild");
		}
		else
		{
			Utility.TryOpenShopMenu("AdventureShop", "Marlon");
		}
	}

	public virtual bool carpenters(Location tileLocation)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		foreach (NPC character in characters)
		{
			if (!character.Name.Equals("Robin"))
			{
				continue;
			}
			if (Vector2.Distance(character.Tile, new Vector2((float)tileLocation.X, (float)tileLocation.Y)) > 3f)
			{
				return false;
			}
			character.faceDirection(2);
			if (Game1.player.daysUntilHouseUpgrade.Value < 0 && !Game1.IsThereABuildingUnderConstruction())
			{
				List<Response> list = new List<Response>();
				list.Add(new Response("Shop", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_Shop")));
				if (Game1.IsMasterGame)
				{
					if (Game1.player.houseUpgradeLevel.Value < 3)
					{
						list.Add(new Response("Upgrade", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_UpgradeHouse")));
					}
					else if ((Game1.MasterPlayer.mailReceived.Contains("ccIsComplete") || Game1.MasterPlayer.mailReceived.Contains("JojaMember") || Game1.MasterPlayer.hasCompletedCommunityCenter()) && Game1.RequireLocation<Town>("Town").daysUntilCommunityUpgrade.Value <= 0)
					{
						if (!Game1.MasterPlayer.mailReceived.Contains("pamHouseUpgrade"))
						{
							list.Add(new Response("CommunityUpgrade", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_CommunityUpgrade")));
						}
						else if (!Game1.MasterPlayer.mailReceived.Contains("communityUpgradeShortcuts"))
						{
							list.Add(new Response("CommunityUpgrade", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_CommunityUpgrade")));
						}
					}
				}
				else if (Game1.player.houseUpgradeLevel.Value < 3)
				{
					list.Add(new Response("Upgrade", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_UpgradeCabin")));
				}
				if (Game1.player.houseUpgradeLevel.Value >= 2)
				{
					if (Game1.IsMasterGame)
					{
						list.Add(new Response("Renovate", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_RenovateHouse")));
					}
					else
					{
						list.Add(new Response("Renovate", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_RenovateCabin")));
					}
				}
				list.Add(new Response("Construct", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_Construct")));
				list.Add(new Response("Leave", Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu_Leave")));
				createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:ScienceHouse_CarpenterMenu"), list.ToArray(), "carpenter");
			}
			else
			{
				Utility.TryOpenShopMenu("Carpenter", "Robin");
			}
			return true;
		}
		if (getCharacterFromName("Robin") == null && Game1.IsVisitingIslandToday("Robin"))
		{
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:ScienceHouse_MoneyBox"));
			Game1.afterDialogues = delegate
			{
				Utility.TryOpenShopMenu("Carpenter", null, playOpenSound: true);
			};
			return true;
		}
		if (Game1.shortDayNameFromDayOfSeason(Game1.dayOfMonth).Equals("Tue"))
		{
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:ScienceHouse_RobinAbsent").Replace('\n', '^'));
			return true;
		}
		return false;
	}

	public virtual bool blacksmith(Location tileLocation)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		foreach (NPC character in characters)
		{
			if (!character.Name.Equals("Clint"))
			{
				continue;
			}
			if (character.Tile != new Vector2((float)tileLocation.X, (float)(tileLocation.Y - 1)))
			{
				_ = character.Tile != new Vector2((float)(tileLocation.X - 1), (float)(tileLocation.Y - 1));
			}
			character.faceDirection(2);
			if (Game1.player.toolBeingUpgraded.Value != null && Game1.player.daysLeftForToolUpgrade.Value <= 0)
			{
				if (Game1.player.freeSpotsInInventory() > 0 || Game1.player.toolBeingUpgraded.Value is GenericTool)
				{
					Tool value = Game1.player.toolBeingUpgraded.Value;
					Game1.player.toolBeingUpgraded.Value = null;
					Game1.player.hasReceivedToolUpgradeMessageYet = false;
					Game1.player.holdUpItemThenMessage(value);
					if (value is GenericTool)
					{
						value.actionWhenClaimed();
					}
					else
					{
						Game1.player.addItemToInventoryBool(value);
					}
					if (Game1.player.team.useSeparateWallets.Value && value.UpgradeLevel == 4)
					{
						Game1.multiplayer.globalChatInfoMessage("IridiumToolUpgrade", Game1.player.Name, TokenStringBuilder.ToolName(value.QualifiedItemId, value.UpgradeLevel));
					}
				}
				else
				{
					Game1.DrawDialogue(character, "Data\\ExtraDialogue:Clint_NoInventorySpace");
				}
			}
			else
			{
				bool flag = false;
				foreach (Item item in Game1.player.Items)
				{
					if (Utility.IsGeode(item))
					{
						flag = true;
						break;
					}
				}
				Response[] answerChoices = ((!flag) ? new Response[3]
				{
					new Response("Shop", Game1.content.LoadString("Strings\\Locations:Blacksmith_Clint_Shop")),
					new Response("Upgrade", Game1.content.LoadString("Strings\\Locations:Blacksmith_Clint_Upgrade")),
					new Response("Leave", Game1.content.LoadString("Strings\\Locations:Blacksmith_Clint_Leave"))
				} : new Response[4]
				{
					new Response("Shop", Game1.content.LoadString("Strings\\Locations:Blacksmith_Clint_Shop")),
					new Response("Upgrade", Game1.content.LoadString("Strings\\Locations:Blacksmith_Clint_Upgrade")),
					new Response("Process", Game1.content.LoadString("Strings\\Locations:Blacksmith_Clint_Geodes")),
					new Response("Leave", Game1.content.LoadString("Strings\\Locations:Blacksmith_Clint_Leave"))
				});
				createQuestionDialogue("", answerChoices, "Blacksmith");
			}
			return true;
		}
		return false;
	}

	public virtual bool animalShop(Location tileLocation)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		foreach (NPC character in characters)
		{
			if (!character.Name.Equals("Marnie"))
			{
				continue;
			}
			if (character.Tile != new Vector2((float)tileLocation.X, (float)(tileLocation.Y - 1)) && character.Tile != new Vector2((float)(tileLocation.X - 1), (float)(tileLocation.Y - 1)))
			{
				if (Game1.player.stats.Get("Book_AnimalCatalogue") != 0)
				{
					break;
				}
				return false;
			}
			character.faceDirection(2);
			List<Response> list = new List<Response>
			{
				new Response("Supplies", Game1.content.LoadString("Strings\\Locations:AnimalShop_Marnie_Supplies")),
				new Response("Purchase", Game1.content.LoadString("Strings\\Locations:AnimalShop_Marnie_Animals")),
				new Response("Leave", Game1.content.LoadString("Strings\\Locations:AnimalShop_Marnie_Leave"))
			};
			if ((Utility.getAllPets().Count == 0 && Game1.year >= 2) || Game1.player.mailReceived.Contains("MarniePetAdoption") || Game1.player.mailReceived.Contains("MarniePetRejectedAdoption"))
			{
				list.Insert(2, new Response("Adopt", Game1.content.LoadString("Strings\\1_6_Strings:AdoptPets")));
			}
			createQuestionDialogue("", list.ToArray(), "Marnie");
			return true;
		}
		if (getCharacterFromName("Marnie") == null && Game1.IsVisitingIslandToday("Marnie"))
		{
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:AnimalShop_MoneyBox"));
			Game1.afterDialogues = delegate
			{
				Utility.TryOpenShopMenu("AnimalShop", null, playOpenSound: true);
			};
			return true;
		}
		if (Game1.player.stats.Get("Book_AnimalCatalogue") != 0)
		{
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\1_6_Strings:Marnie_Counter"));
			Game1.afterDialogues = delegate
			{
				List<Response> list2 = new List<Response>
				{
					new Response("Supplies", Game1.content.LoadString("Strings\\Locations:AnimalShop_Marnie_Supplies")),
					new Response("Purchase", Game1.content.LoadString("Strings\\Locations:AnimalShop_Marnie_Animals")),
					new Response("Leave", Game1.content.LoadString("Strings\\Locations:AnimalShop_Marnie_Leave"))
				};
				if ((Utility.getAllPets().Count == 0 && Game1.year >= 2) || Game1.player.mailReceived.Contains("MarniePetAdoption") || Game1.player.mailReceived.Contains("MarniePetRejectedAdoption"))
				{
					list2.Insert(2, new Response("Adopt", Game1.content.LoadString("Strings\\1_6_Strings:AdoptPets")));
				}
				createQuestionDialogue("", list2.ToArray(), "Marnie");
			};
			return true;
		}
		if (Game1.shortDayNameFromDayOfSeason(Game1.dayOfMonth).Equals("Tue"))
		{
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:AnimalShop_Marnie_Absent").Replace('\n', '^'));
			return true;
		}
		return false;
	}

	public void removeTile(Location tileLocation, string layer)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		Map.RequireLayer(layer).Tiles[tileLocation.X, tileLocation.Y] = null;
	}

	public void removeTile(int x, int y, string layer)
	{
		Map.RequireLayer(layer).Tiles[x, y] = null;
	}

	public void characterTrampleTile(Vector2 tile)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		if (!(this is FarmHouse) && !(this is IslandFarmHouse) && !(this is Farm))
		{
			terrainFeatures.TryGetValue(tile, out var value);
			if (value is Tree tree && tree.growthStage.Value < 1 && tree.instantDestroy(tile))
			{
				terrainFeatures.Remove(tile);
			}
		}
	}

	public bool characterDestroyObjectWithinRectangle(Rectangle rect, bool showDestroyedObject)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		if (this is FarmHouse || this is IslandFarmHouse)
		{
			return false;
		}
		foreach (Farmer farmer in farmers)
		{
			if (((Rectangle)(ref rect)).Intersects(farmer.GetBoundingBox()))
			{
				return false;
			}
		}
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(rect.X / 64), (float)(rect.Y / 64));
		objects.TryGetValue(val, out var value);
		if (checkDestroyItem(value, val, showDestroyedObject))
		{
			return true;
		}
		terrainFeatures.TryGetValue(val, out var value2);
		if (checkDestroyTerrainFeature(value2, val))
		{
			return true;
		}
		val.X = ((Rectangle)(ref rect)).Right / 64;
		objects.TryGetValue(val, out value);
		if (checkDestroyItem(value, val, showDestroyedObject))
		{
			return true;
		}
		terrainFeatures.TryGetValue(val, out value2);
		if (checkDestroyTerrainFeature(value2, val))
		{
			return true;
		}
		val.X = rect.X / 64;
		val.Y = ((Rectangle)(ref rect)).Bottom / 64;
		objects.TryGetValue(val, out value);
		if (checkDestroyItem(value, val, showDestroyedObject))
		{
			return true;
		}
		terrainFeatures.TryGetValue(val, out value2);
		if (checkDestroyTerrainFeature(value2, val))
		{
			return true;
		}
		val.X = ((Rectangle)(ref rect)).Right / 64;
		objects.TryGetValue(val, out value);
		if (checkDestroyItem(value, val, showDestroyedObject))
		{
			return true;
		}
		terrainFeatures.TryGetValue(val, out value2);
		if (checkDestroyTerrainFeature(value2, val))
		{
			return true;
		}
		Rectangle boundingBox;
		for (int num = largeTerrainFeatures.Count - 1; num >= 0; num--)
		{
			LargeTerrainFeature largeTerrainFeature = largeTerrainFeatures[num];
			if (largeTerrainFeature.isDestroyedByNPCTrample)
			{
				boundingBox = largeTerrainFeature.getBoundingBox();
				if (((Rectangle)(ref boundingBox)).Intersects(rect))
				{
					largeTerrainFeature.onDestroy();
					largeTerrainFeatures.RemoveAt(num);
					return true;
				}
			}
		}
		for (int num2 = resourceClumps.Count - 1; num2 >= 0; num2--)
		{
			ResourceClump resourceClump = resourceClumps[num2];
			if (resourceClump.IsGreenRainBush())
			{
				boundingBox = resourceClump.getBoundingBox();
				if (((Rectangle)(ref boundingBox)).Intersects(rect) && resourceClump.destroy(null, this, resourceClump.Tile))
				{
					resourceClumps.RemoveAt(num2);
				}
			}
		}
		return false;
	}

	private bool checkDestroyTerrainFeature(TerrainFeature tf, Vector2 tilePositionToTry)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		if (tf is Tree tree && tree.instantDestroy(tilePositionToTry))
		{
			terrainFeatures.Remove(tilePositionToTry);
		}
		return false;
	}

	private bool checkDestroyItem(Object o, Vector2 tilePositionToTry, bool showDestroyedObject)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		if (o != null && !o.isPassable() && !((IDictionary<string, PropertyValue>)((Component)map.RequireLayer("Back").Tiles[(int)tilePositionToTry.X, (int)tilePositionToTry.Y]).Properties).ContainsKey("NPCBarrier"))
		{
			if (o.IsSpawnedObject)
			{
				numberOfSpawnedObjectsOnMap--;
			}
			if (showDestroyedObject && !o.bigCraftable.Value)
			{
				TemporaryAnimatedSprite temporaryAnimatedSprite = new TemporaryAnimatedSprite(0, 150f, 1, 3, new Vector2(tilePositionToTry.X * 64f, tilePositionToTry.Y * 64f), flicker: false, o.flipped.Value)
				{
					alphaFade = 0.01f
				};
				temporaryAnimatedSprite.CopyAppearanceFromItemId(o.QualifiedItemId);
				Game1.multiplayer.broadcastSprites(this, temporaryAnimatedSprite);
			}
			o.performToolAction(null);
			if (objects.ContainsKey(tilePositionToTry))
			{
				if (o is Chest chest)
				{
					if (chest.TryMoveToSafePosition())
					{
						return true;
					}
					chest.destroyAndDropContents(tilePositionToTry * 64f);
				}
				objects.Remove(tilePositionToTry);
			}
			return true;
		}
		return false;
	}

	public Object removeObject(Vector2 location, bool showDestroyedObject)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		objects.TryGetValue(location, out var value);
		if (value != null && (value.CanBeGrabbed || showDestroyedObject))
		{
			if (value.IsSpawnedObject)
			{
				numberOfSpawnedObjectsOnMap--;
			}
			Object obj = objects[location];
			objects.Remove(location);
			if (showDestroyedObject)
			{
				TemporaryAnimatedSprite temporaryAnimatedSprite = new TemporaryAnimatedSprite(0, 150f, 1, 3, new Vector2(location.X * 64f, location.Y * 64f), flicker: true, obj.bigCraftable.Value, obj.flipped.Value);
				temporaryAnimatedSprite.CopyAppearanceFromItemId(obj.QualifiedItemId, (!(obj.Type == "Crafting")) ? 1 : 0);
				Game1.multiplayer.broadcastSprites(this, temporaryAnimatedSprite);
			}
			if (value.IsWeeds())
			{
				Game1.stats.WeedsEliminated++;
			}
			return obj;
		}
		return null;
	}

	public void removeTileProperty(int tileX, int tileY, string layer, string key)
	{
		try
		{
			Map obj = map;
			object obj2;
			if (obj == null)
			{
				obj2 = null;
			}
			else
			{
				Layer layer2 = obj.GetLayer(layer);
				obj2 = ((layer2 != null) ? layer2.Tiles[tileX, tileY] : null);
			}
			Tile val = (Tile)obj2;
			if (val != null)
			{
				((IDictionary<string, PropertyValue>)((Component)val).Properties).Remove(key);
			}
		}
		catch (Exception)
		{
		}
	}

	public void setTileProperty(int tileX, int tileY, string layer, string key, string value)
	{
		try
		{
			Map obj = map;
			object obj2;
			if (obj == null)
			{
				obj2 = null;
			}
			else
			{
				Layer layer2 = obj.GetLayer(layer);
				obj2 = ((layer2 != null) ? layer2.Tiles[tileX, tileY] : null);
			}
			Tile val = (Tile)obj2;
			if (val != null)
			{
				((IDictionary<string, PropertyValue>)((Component)val).Properties)[key] = PropertyValue.op_Implicit(value);
			}
		}
		catch (Exception)
		{
		}
	}

	public void setObjectAt(float x, float y, Object o)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		Vector2 key = default(Vector2);
		((Vector2)(ref key))._002Ector(x, y);
		objects[key] = o;
	}

	public virtual void cleanupBeforeSave()
	{
		characters.RemoveWhere((NPC npc) => npc is Junimo);
		if (name.Equals("WitchHut"))
		{
			characters.Clear();
		}
		largeTerrainFeatures.RemoveWhere((LargeTerrainFeature feature) => feature is Tent);
		foreach (Building building in buildings)
		{
			building.indoors.Value?.cleanupBeforeSave();
		}
	}

	public virtual void cleanupForVacancy()
	{
		if (Game1.IsMasterGame)
		{
			debris.RemoveWhere((Debris d) => d.isEssentialItem() && d.collect(Game1.player));
		}
	}

	public virtual void cleanupBeforePlayerExit()
	{
		debris.RemoveWhere((Debris d) => d.isEssentialItem() && d.player.Value != null && d.player.Value == Game1.player && d.collect(d.player.Value));
		Game1.currentLightSources.Clear();
		critters?.Clear();
		Game1.onScreenMenus.RemoveWhere(delegate(IClickableMenu menu)
		{
			if (menu.destroy)
			{
				(menu as IDisposable)?.Dispose();
				return true;
			}
			return false;
		});
		AmbientLocationSounds.onLocationLeave();
		Game1.player.rightRing.Value?.onLeaveLocation(Game1.player, this);
		Game1.player.leftRing.Value?.onLeaveLocation(Game1.player, this);
		if (name.Equals("AbandonedJojaMart") && farmers.Count <= 1)
		{
			characters.RemoveWhere((NPC npc) => npc is Junimo);
		}
		furnitureToRemove.Clear();
		interiorDoors.CleanUpLocalState();
		((ContentManager)Game1.temporaryContent).Unload();
		Utility.CollectGarbage();
	}

	public static string getWeedForSeason(Random r, Season season)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Expected I4, but got Unknown
		return (int)season switch
		{
			0 => r.Choose("(O)784", "(O)674", "(O)675"), 
			1 => r.Choose("(O)785", "(O)676", "(O)677"), 
			2 => r.Choose("(O)786", "(O)678", "(O)679"), 
			_ => "(O)674", 
		};
	}

	private void startSleep()
	{
		Game1.player.timeWentToBed.Value = Game1.timeOfDay;
		if (Game1.IsMultiplayer)
		{
			Game1.netReady.SetLocalReady("sleep", ready: true);
			Game1.dialogueUp = false;
			Game1.activeClickableMenu = new ReadyCheckDialog("sleep", allowCancel: true, delegate
			{
				doSleep();
			}, delegate(Farmer who)
			{
				if (Game1.activeClickableMenu is ReadyCheckDialog readyCheckDialog)
				{
					readyCheckDialog.closeDialog(who);
				}
				who.timeWentToBed.Value = 0;
			});
		}
		else
		{
			doSleep();
		}
		if (Game1.IsDedicatedHost || Game1.player.team.announcedSleepingFarmers.Contains(Game1.player))
		{
			return;
		}
		Game1.player.team.announcedSleepingFarmers.Add(Game1.player);
		if (!Game1.IsMultiplayer || (Game1.player.team.sleepAnnounceMode.Value != FarmerTeam.SleepAnnounceModes.All && (Game1.player.team.sleepAnnounceMode.Value != FarmerTeam.SleepAnnounceModes.First || Game1.player.team.announcedSleepingFarmers.Count != 1)))
		{
			return;
		}
		string text = "GoneToBed";
		if (Game1.random.NextDouble() < 0.75)
		{
			if (Game1.timeOfDay < 1800)
			{
				text += "Early";
			}
			else if (Game1.timeOfDay > 2530)
			{
				text += "Late";
			}
		}
		int num = 0;
		for (int num2 = 0; num2 < 2; num2++)
		{
			if (Game1.random.NextDouble() < 0.25)
			{
				num++;
			}
		}
		Game1.multiplayer.globalChatInfoMessage(text + num, Game1.player.displayName);
	}

	protected virtual void _CleanupPagedResponses()
	{
		_PagedResponses.Clear();
		_OnPagedResponse = null;
		_PagedResponsePrompt = null;
	}

	public virtual void ShowPagedResponses(string prompt, List<KeyValuePair<string, string>> responses, Action<string> on_response, bool auto_select_single_choice = false, bool addCancel = true, int itemsPerPage = 5)
	{
		_PagedResponses.Clear();
		_PagedResponses.AddRange(responses);
		_PagedResponsePage = 0;
		_PagedResponseAddCancel = addCancel;
		_PagedResponseItemsPerPage = itemsPerPage;
		_PagedResponsePrompt = prompt;
		_OnPagedResponse = on_response;
		if (_PagedResponses.Count == 1 && auto_select_single_choice)
		{
			on_response(_PagedResponses[0].Key);
		}
		else if (_PagedResponses.Count > 0)
		{
			_ShowPagedResponses(_PagedResponsePage);
		}
	}

	protected virtual void _ShowPagedResponses(int page = -1)
	{
		_PagedResponsePage = page;
		int pagedResponseItemsPerPage = _PagedResponseItemsPerPage;
		int num = (_PagedResponses.Count - 1) / pagedResponseItemsPerPage;
		int num2 = pagedResponseItemsPerPage;
		if (_PagedResponsePage == num - 1 && _PagedResponses.Count % pagedResponseItemsPerPage == 1)
		{
			num2++;
			num--;
		}
		List<Response> list = new List<Response>();
		for (int i = 0; i < num2; i++)
		{
			int num3 = i + _PagedResponsePage * pagedResponseItemsPerPage;
			if (num3 < _PagedResponses.Count)
			{
				KeyValuePair<string, string> keyValuePair = _PagedResponses[num3];
				list.Add(new Response(keyValuePair.Key, keyValuePair.Value));
			}
		}
		if (_PagedResponsePage < num)
		{
			list.Add(new Response("nextPage", Game1.content.LoadString("Strings\\UI:NextPage")));
		}
		if (_PagedResponsePage > 0)
		{
			list.Add(new Response("previousPage", Game1.content.LoadString("Strings\\UI:PreviousPage")));
		}
		if (_PagedResponseAddCancel)
		{
			list.Add(new Response("cancel", Game1.content.LoadString("Strings\\Locations:MineCart_Destination_Cancel")));
		}
		createQuestionDialogue(_PagedResponsePrompt, list.ToArray(), "pagedResponse");
	}

	public virtual void ShowConstructOptions(string builder, int page = -1)
	{
		if (builder != null)
		{
			_constructLocationBuilderName = builder;
		}
		List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
		foreach (GameLocation location in Game1.locations)
		{
			if (location.IsBuildableLocation())
			{
				list.Add(new KeyValuePair<string, string>(location.NameOrUniqueName, location.DisplayName));
			}
		}
		if (!list.Any())
		{
			Farm farm = Game1.getFarm();
			list.Add(new KeyValuePair<string, string>(farm.NameOrUniqueName, farm.DisplayName));
		}
		ShowPagedResponses(Game1.content.LoadString("Strings\\Buildings:Construction_ChooseLocation"), list, delegate(string value)
		{
			GameLocation locationFromName = Game1.getLocationFromName(value);
			if (locationFromName != null)
			{
				Game1.activeClickableMenu = new CarpenterMenu(_constructLocationBuilderName, locationFromName);
			}
			else
			{
				Game1.log.Error("Can't find location '" + value + "' for construct menu.");
			}
		}, auto_select_single_choice: true);
	}

	public void ShowAnimalShopMenu(Action<PurchaseAnimalsMenu> onMenuOpened = null)
	{
		List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>();
		foreach (GameLocation location in Game1.locations)
		{
			if (location.buildings.Any((Building p) => p.GetIndoors() is AnimalHouse) && (!Game1.IsClient || location.CanBeRemotedlyViewed()))
			{
				list.Add(new KeyValuePair<string, string>(location.NameOrUniqueName, location.DisplayName));
			}
		}
		if (!list.Any())
		{
			Farm farm = Game1.getFarm();
			list.Add(new KeyValuePair<string, string>(farm.NameOrUniqueName, farm.DisplayName));
		}
		Game1.currentLocation.ShowPagedResponses(Game1.content.LoadString("Strings\\StringsFromCSFiles:PurchaseAnimalsMenu.ChooseLocation"), list, delegate(string value)
		{
			GameLocation locationFromName = Game1.getLocationFromName(value);
			if (locationFromName != null)
			{
				PurchaseAnimalsMenu purchaseAnimalsMenu = new PurchaseAnimalsMenu(Utility.getPurchaseAnimalStock(locationFromName), locationFromName);
				onMenuOpened?.Invoke(purchaseAnimalsMenu);
				Game1.activeClickableMenu = purchaseAnimalsMenu;
			}
			else
			{
				Game1.log.Error("Can't find location '" + value + "' for animal purchase menu.");
			}
		}, auto_select_single_choice: true);
	}

	private void doSleep()
	{
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		if (lightLevel.Value == 0f && Game1.timeOfDay < 2000)
		{
			if (!isOutdoors.Value)
			{
				lightLevel.Value = 0.6f;
				localSound("openBox");
			}
			if (Game1.IsMasterGame)
			{
				Game1.NewDay(600f);
			}
		}
		else if (lightLevel.Value > 0f && Game1.timeOfDay >= 2000)
		{
			if (!isOutdoors.Value)
			{
				lightLevel.Value = 0f;
				localSound("openBox");
			}
			if (Game1.IsMasterGame)
			{
				Game1.NewDay(600f);
			}
		}
		else if (Game1.IsMasterGame)
		{
			Game1.NewDay(0f);
		}
		Game1.player.lastSleepLocation.Value = Game1.currentLocation.NameOrUniqueName;
		Game1.player.lastSleepPoint.Value = Game1.player.TilePoint;
		Game1.player.mostRecentBed = Game1.player.Position;
		Game1.player.doEmote(24);
		Game1.player.freezePause = 2000;
	}

	public virtual bool answerDialogueAction(string questionAndAnswer, string[] questionParams)
	{
		//IL_197a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1720: Unknown result type (might be due to invalid IL or missing references)
		//IL_1993: Unknown result type (might be due to invalid IL or missing references)
		//IL_1555: Unknown result type (might be due to invalid IL or missing references)
		//IL_15a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_184a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1739: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aaa: Unknown result type (might be due to invalid IL or missing references)
		//IL_3536: Unknown result type (might be due to invalid IL or missing references)
		//IL_353b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1daf: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dbe: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dc9: Unknown result type (might be due to invalid IL or missing references)
		//IL_21c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_21d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_21db: Unknown result type (might be due to invalid IL or missing references)
		//IL_1863: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bd7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ac3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bf0: Unknown result type (might be due to invalid IL or missing references)
		//IL_17dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a57: Unknown result type (might be due to invalid IL or missing references)
		//IL_25bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_25ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_25d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_2900: Unknown result type (might be due to invalid IL or missing references)
		//IL_290f: Unknown result type (might be due to invalid IL or missing references)
		//IL_291a: Unknown result type (might be due to invalid IL or missing references)
		//IL_354d: Unknown result type (might be due to invalid IL or missing references)
		//IL_3552: Unknown result type (might be due to invalid IL or missing references)
		//IL_3554: Unknown result type (might be due to invalid IL or missing references)
		//IL_3556: Unknown result type (might be due to invalid IL or missing references)
		//IL_3558: Unknown result type (might be due to invalid IL or missing references)
		//IL_355d: Unknown result type (might be due to invalid IL or missing references)
		//IL_3565: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e35: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e44: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e4e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e6f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e74: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e9f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ea4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1eb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1eb9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f99: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fa3: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fde: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fe3: Unknown result type (might be due to invalid IL or missing references)
		//IL_22e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_22f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_22ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_2320: Unknown result type (might be due to invalid IL or missing references)
		//IL_2325: Unknown result type (might be due to invalid IL or missing references)
		//IL_2330: Unknown result type (might be due to invalid IL or missing references)
		//IL_2350: Unknown result type (might be due to invalid IL or missing references)
		//IL_2355: Unknown result type (might be due to invalid IL or missing references)
		//IL_2365: Unknown result type (might be due to invalid IL or missing references)
		//IL_236a: Unknown result type (might be due to invalid IL or missing references)
		//IL_190c: Unknown result type (might be due to invalid IL or missing references)
		//IL_17f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b69: Unknown result type (might be due to invalid IL or missing references)
		//IL_201f: Unknown result type (might be due to invalid IL or missing references)
		//IL_2039: Unknown result type (might be due to invalid IL or missing references)
		//IL_2043: Unknown result type (might be due to invalid IL or missing references)
		//IL_2054: Unknown result type (might be due to invalid IL or missing references)
		//IL_207e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2083: Unknown result type (might be due to invalid IL or missing references)
		//IL_1927: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c99: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b84: Unknown result type (might be due to invalid IL or missing references)
		//IL_2681: Unknown result type (might be due to invalid IL or missing references)
		//IL_2690: Unknown result type (might be due to invalid IL or missing references)
		//IL_269a: Unknown result type (might be due to invalid IL or missing references)
		//IL_26bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_26c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_26cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_26eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_26f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_2700: Unknown result type (might be due to invalid IL or missing references)
		//IL_2705: Unknown result type (might be due to invalid IL or missing references)
		//IL_29a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_29b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_29bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_29e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_29e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_29f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a10: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a15: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a25: Unknown result type (might be due to invalid IL or missing references)
		//IL_2a2a: Unknown result type (might be due to invalid IL or missing references)
		//IL_2401: Unknown result type (might be due to invalid IL or missing references)
		//IL_240c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_27c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_27dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_27e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_27f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_285c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2861: Unknown result type (might be due to invalid IL or missing references)
		//IL_2424: Unknown result type (might be due to invalid IL or missing references)
		//IL_2429: Unknown result type (might be due to invalid IL or missing references)
		//IL_2453: Unknown result type (might be due to invalid IL or missing references)
		//IL_2460: Unknown result type (might be due to invalid IL or missing references)
		//IL_2467: Unknown result type (might be due to invalid IL or missing references)
		//IL_2476: Unknown result type (might be due to invalid IL or missing references)
		//IL_247b: Unknown result type (might be due to invalid IL or missing references)
		//IL_24c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_24c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_24e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_24e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_2502: Unknown result type (might be due to invalid IL or missing references)
		//IL_2507: Unknown result type (might be due to invalid IL or missing references)
		//IL_2511: Unknown result type (might be due to invalid IL or missing references)
		//IL_2516: Unknown result type (might be due to invalid IL or missing references)
		//IL_2526: Unknown result type (might be due to invalid IL or missing references)
		//IL_252b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fb2: Unknown result type (might be due to invalid IL or missing references)
		switch (questionAndAnswer)
		{
		case null:
			return false;
		case "GoldClock_Yes":
			Game1.netWorldState.Value.goldenClocksTurnedOff.Value = !Game1.netWorldState.Value.goldenClocksTurnedOff.Value;
			Game1.playSound("yoba");
			break;
		case "Bookseller_Buy":
			Utility.TryOpenShopMenu("Bookseller", null, playOpenSound: true);
			break;
		case "Bookseller_Trade":
			Utility.TryOpenShopMenu("BooksellerTrade", null, playOpenSound: true);
			break;
		case "SquidFestBooth_Rewards":
		{
			if (Game1.player.mailReceived.Contains("GotSquidFestReward_" + Game1.year + "_" + Game1.dayOfMonth + "_3") || Game1.player.mailReceived.Contains("GotSquidFestReward_" + Game1.year + "_" + Game1.dayOfMonth + "_3"))
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\1_6_Strings:SquidFest_GotAllRewardsToday"));
				break;
			}
			List<string> list = new List<string>();
			int[] array = ((Game1.dayOfMonth != 12) ? new int[4] { 2, 5, 7, 10 } : new int[4] { 1, 3, 5, 8 });
			int num4 = (int)Game1.stats.Get(StatKeys.SquidFestScore(Game1.dayOfMonth, Game1.year));
			bool flag = false;
			bool flag2 = Game1.player.mailReceived.Contains("GotCrabbingBook");
			for (int num5 = 0; num5 < array.Length; num5++)
			{
				if (num4 < array[num5])
				{
					continue;
				}
				if (!Game1.player.mailReceived.Contains("GotSquidFestReward_" + Game1.year + "_" + Game1.dayOfMonth + "_" + num5))
				{
					list.Add(Game1.dayOfMonth + "_" + num5);
					Game1.player.mailReceived.Add("GotSquidFestReward_" + Game1.year + "_" + Game1.dayOfMonth + "_" + num5);
					flag = false;
					if (!flag2 && num5 >= 3)
					{
						Game1.player.mailReceived.Add("GotCrabbingBook");
					}
				}
				else
				{
					flag = true;
				}
			}
			if (list.Count > 0)
			{
				List<Item> list2 = new List<Item>();
				Random random = Utility.CreateDaySaveRandom(Game1.year * 2000, Game1.dayOfMonth * 10);
				using (List<string>.Enumerator enumerator = list.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						switch (enumerator.Current)
						{
						case "12_0":
							list2.Add(ItemRegistry.Create("(O)DeluxeBait", 20));
							break;
						case "12_1":
							list2.Add((random.NextDouble() < 0.5) ? ItemRegistry.Create("(O)498", 10) : ItemRegistry.Create("(O)MysteryBox", 2));
							list2.Add(ItemRegistry.Create("(O)242"));
							break;
						case "12_2":
							list2.Add(ItemRegistry.Create("(O)797"));
							list2.Add(ItemRegistry.Create("(O)395", 3));
							break;
						case "12_3":
							list2.Add(new Furniture("SquidKid_Painting", Vector2.Zero));
							if (!flag2)
							{
								list2.Add(ItemRegistry.Create("(O)Book_Crabbing"));
								break;
							}
							list2.Add(ItemRegistry.Create("(O)MysteryBox", 3));
							list2.Add(ItemRegistry.Create("(O)265"));
							break;
						case "13_0":
							list2.Add(ItemRegistry.Create("(O)694"));
							break;
						case "13_1":
							list2.Add((random.NextDouble() < 0.5) ? ItemRegistry.Create("(O)498", 15) : ItemRegistry.Create("(O)MysteryBox", 3));
							list2.Add(ItemRegistry.Create("(O)242"));
							break;
						case "13_2":
							list2.Add(ItemRegistry.Create("(O)166"));
							list2.Add(ItemRegistry.Create("(O)253", 3));
							break;
						case "13_3":
							list2.Add(new Hat("SquidHat"));
							if (!flag2)
							{
								list2.Add(ItemRegistry.Create("(O)Book_Crabbing"));
								break;
							}
							list2.Add(ItemRegistry.Create("(O)MysteryBox", 3));
							list2.Add(ItemRegistry.Create("(O)265"));
							break;
						}
					}
				}
				if (list2.Count > 0)
				{
					ItemGrabMenu itemGrabMenu = new ItemGrabMenu(list2).setEssential(essential: true, superEssential: true);
					itemGrabMenu.inventory.showGrayedOutSlots = true;
					itemGrabMenu.source = 2;
					Game1.activeClickableMenu = itemGrabMenu;
				}
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString(flag ? "Strings\\1_6_Strings:SquidFest_AlreadyGotAvailableRewards" : "Strings\\1_6_Strings:SquidFestBooth_NoRewards"));
			}
			break;
		}
		case "SquidFestBooth_Explanation":
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\1_6_Strings:SquidFestBooth_Explanation"));
			break;
		case "TroutDerbyBooth_Rewards":
			if (Game1.player.Items.CountId("TroutDerbyTag") > 0)
			{
				Item item2 = null;
				int num16 = (int)(Utility.CreateRandom(Game1.uniqueIDForThisGame).Next(10) + Game1.stats.Get("GoldenTagsTurnedIn")) % 10;
				if (Game1.stats.Get("GoldenTagsTurnedIn") == 0)
				{
					item2 = ItemRegistry.Create("(O)TentKit");
				}
				else
				{
					switch (num16)
					{
					case 0:
						item2 = ItemRegistry.Create("(H)BucketHat");
						break;
					case 1:
						item2 = ItemRegistry.Create("(O)710");
						break;
					case 2:
						item2 = ItemRegistry.Create("(O)MysteryBox", 3);
						break;
					case 3:
						item2 = ItemRegistry.Create("(O)72");
						break;
					case 4:
						item2 = ItemRegistry.Create("(F)MountedTrout_Painting");
						break;
					case 5:
						item2 = ItemRegistry.Create("(O)DeluxeBait", 20);
						break;
					case 6:
						item2 = ItemRegistry.Create("(O)253", 2);
						break;
					case 7:
						item2 = ItemRegistry.Create("(O)621");
						break;
					case 8:
						item2 = ItemRegistry.Create("(O)688", 3);
						break;
					case 9:
						item2 = ItemRegistry.Create("(O)749", 3);
						break;
					}
				}
				if (item2 != null && (Game1.player.couldInventoryAcceptThisItem(item2) || Game1.player.Items.CountId("TroutDerbyTag") == 1))
				{
					Game1.stats.Increment("GoldenTagsTurnedIn");
					Game1.player.Items.ReduceId("TroutDerbyTag", 1);
					Game1.player.holdUpItemThenMessage(item2);
					Game1.player.addItemToInventoryBool(item2);
				}
				else
				{
					Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\1_6_Strings:FishingDerbyBooth_BagFull"));
				}
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\1_6_Strings:FishingDerbyBooth_NoTags"));
			}
			break;
		case "TroutDerbyBooth_Explanation":
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\1_6_Strings:FishingDerbyBooth_Explanation"));
			break;
		case "pagedResponse_cancel":
			_CleanupPagedResponses();
			break;
		case "pagedResponse_nextPage":
			_ShowPagedResponses(_PagedResponsePage + 1);
			break;
		case "pagedResponse_previousPage":
			_ShowPagedResponses(_PagedResponsePage - 1);
			break;
		case "Fizz_Yes":
			if (Game1.player.Money >= 500000)
			{
				Game1.player.Money -= 500000;
				Game1.netWorldState.Value.PerfectionWaivers++;
				DelayedAction.playSoundAfterDelay("qi_shop_purchase", 500);
				getCharacterFromName("Fizz")?.showTextAboveHead(Game1.content.LoadString("Strings\\1_6_Strings:Fizz_Sweet"));
				getCharacterFromName("Fizz")?.shake(500);
				if (Game1.IsMultiplayer)
				{
					Game1.Multiplayer.broadcastGlobalMessage("Strings\\1_6_Strings:Waiver_Note_Multiplayer", false, null, Game1.player.Name);
				}
				else
				{
					Game1.showGlobalMessage(string.Format(Game1.content.LoadString("Strings\\1_6_Strings:Waiver_Note", Game1.netWorldState.Value.PerfectionWaivers.ToString() ?? "")));
				}
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney1"));
			}
			break;
		case "EnterTheaterSpendTicket_Yes":
			Game1.player.Items.ReduceId("(O)809", 1);
			Rumble.rumble(0.15f, 200f);
			Game1.player.completelyStopAnimatingOrDoingAction();
			playSound("doorClose", Game1.player.Tile);
			Game1.warpFarmer("MovieTheater", 13, 15, 0);
			break;
		case "EnterTheater_Yes":
			Rumble.rumble(0.15f, 200f);
			Game1.player.completelyStopAnimatingOrDoingAction();
			playSound("doorClose", Game1.player.Tile);
			Game1.warpFarmer("MovieTheater", 13, 15, 0);
			break;
		case "dogStatue_Yes":
		{
			if (Game1.player.Money < 10000)
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:BusStop_NotEnoughMoneyForTicket"));
				break;
			}
			List<Response> list3 = new List<Response>();
			if (canRespec(0))
			{
				list3.Add(new Response("farming", Game1.content.LoadString("Strings\\StringsFromCSFiles:SkillsPage.cs.11604")));
			}
			if (canRespec(3))
			{
				list3.Add(new Response("mining", Game1.content.LoadString("Strings\\StringsFromCSFiles:SkillsPage.cs.11605")));
			}
			if (canRespec(2))
			{
				list3.Add(new Response("foraging", Game1.content.LoadString("Strings\\StringsFromCSFiles:SkillsPage.cs.11606")));
			}
			if (canRespec(1))
			{
				list3.Add(new Response("fishing", Game1.content.LoadString("Strings\\StringsFromCSFiles:SkillsPage.cs.11607")));
			}
			if (canRespec(4))
			{
				list3.Add(new Response("combat", Game1.content.LoadString("Strings\\StringsFromCSFiles:SkillsPage.cs.11608")));
			}
			list3.Add(new Response("cancel", Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueCancel")));
			createQuestionDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueQuestion"), list3.ToArray(), "professionForget");
			break;
		}
		case "professionForget_farming":
		{
			if (Game1.player.newLevels.Contains(new Point(0, 5)) || Game1.player.newLevels.Contains(new Point(0, 10)))
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueAlready"));
				break;
			}
			Game1.player.Money = Math.Max(0, Game1.player.Money - 10000);
			RemoveProfession(0);
			RemoveProfession(1);
			RemoveProfession(3);
			RemoveProfession(5);
			RemoveProfession(2);
			RemoveProfession(4);
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueFinished"));
			int num17 = Farmer.checkForLevelGain(0, Game1.player.experiencePoints[0]);
			if (num17 >= 5)
			{
				Game1.player.newLevels.Add(new Point(0, 5));
			}
			if (num17 >= 10)
			{
				Game1.player.newLevels.Add(new Point(0, 10));
			}
			DelayedAction.playSoundAfterDelay("dog_bark", 300);
			DelayedAction.playSoundAfterDelay("dog_bark", 900);
			break;
		}
		case "professionForget_mining":
		{
			if (Game1.player.newLevels.Contains(new Point(3, 5)) || Game1.player.newLevels.Contains(new Point(3, 10)))
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueAlready"));
				break;
			}
			Game1.player.Money = Math.Max(0, Game1.player.Money - 10000);
			RemoveProfession(23);
			RemoveProfession(21);
			RemoveProfession(18);
			RemoveProfession(19);
			RemoveProfession(22);
			RemoveProfession(20);
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueFinished"));
			int num6 = Farmer.checkForLevelGain(0, Game1.player.experiencePoints[3]);
			if (num6 >= 5)
			{
				Game1.player.newLevels.Add(new Point(3, 5));
			}
			if (num6 >= 10)
			{
				Game1.player.newLevels.Add(new Point(3, 10));
			}
			DelayedAction.playSoundAfterDelay("dog_bark", 300);
			DelayedAction.playSoundAfterDelay("dog_bark", 900);
			break;
		}
		case "professionForget_foraging":
		{
			if (Game1.player.newLevels.Contains(new Point(2, 5)) || Game1.player.newLevels.Contains(new Point(2, 10)))
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueAlready"));
				break;
			}
			Game1.player.Money = Math.Max(0, Game1.player.Money - 10000);
			RemoveProfession(16);
			RemoveProfession(14);
			RemoveProfession(17);
			RemoveProfession(12);
			RemoveProfession(13);
			RemoveProfession(15);
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueFinished"));
			int num18 = Farmer.checkForLevelGain(0, Game1.player.experiencePoints[2]);
			if (num18 >= 5)
			{
				Game1.player.newLevels.Add(new Point(2, 5));
			}
			if (num18 >= 10)
			{
				Game1.player.newLevels.Add(new Point(2, 10));
			}
			DelayedAction.playSoundAfterDelay("dog_bark", 300);
			DelayedAction.playSoundAfterDelay("dog_bark", 900);
			break;
		}
		case "professionForget_fishing":
		{
			if (Game1.player.newLevels.Contains(new Point(1, 5)) || Game1.player.newLevels.Contains(new Point(1, 10)))
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueAlready"));
				break;
			}
			Game1.player.Money = Math.Max(0, Game1.player.Money - 10000);
			RemoveProfession(8);
			RemoveProfession(11);
			RemoveProfession(10);
			RemoveProfession(6);
			RemoveProfession(9);
			RemoveProfession(7);
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueFinished"));
			int num9 = Farmer.checkForLevelGain(0, Game1.player.experiencePoints[1]);
			if (num9 >= 5)
			{
				Game1.player.newLevels.Add(new Point(1, 5));
			}
			if (num9 >= 10)
			{
				Game1.player.newLevels.Add(new Point(1, 10));
			}
			DelayedAction.playSoundAfterDelay("dog_bark", 300);
			DelayedAction.playSoundAfterDelay("dog_bark", 900);
			break;
		}
		case "professionForget_combat":
		{
			if (Game1.player.newLevels.Contains(new Point(4, 5)) || Game1.player.newLevels.Contains(new Point(4, 10)))
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueAlready"));
				break;
			}
			Game1.player.Money = Math.Max(0, Game1.player.Money - 10000);
			RemoveProfession(26);
			RemoveProfession(27);
			RemoveProfession(29);
			RemoveProfession(25);
			RemoveProfession(28);
			RemoveProfession(24);
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Sewer_DogStatueFinished"));
			int num = Farmer.checkForLevelGain(0, Game1.player.experiencePoints[4]);
			if (num >= 5)
			{
				Game1.player.newLevels.Add(new Point(4, 5));
			}
			if (num >= 10)
			{
				Game1.player.newLevels.Add(new Point(4, 10));
			}
			DelayedAction.playSoundAfterDelay("dog_bark", 300);
			DelayedAction.playSoundAfterDelay("dog_bark", 900);
			break;
		}
		case "specialCharmQuestion_Yes":
			if (Game1.player.Items.ContainsId("(O)446"))
			{
				Game1.player.holdUpItemThenMessage(new SpecialItem(3));
				Game1.player.removeFirstOfThisItemFromInventory("446");
				Game1.player.hasSpecialCharm = true;
				Game1.player.mailReceived.Add("SecretNote20_done");
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Town_specialCharmNoFoot"));
			}
			break;
		case "evilShrineLeft_Yes":
			if (Game1.player.Items.ReduceId("(O)74", 1) > 0)
			{
				Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(536, 1945, 8, 8), new Vector2(156f, 388f), flipped: false, 0f, Color.White)
				{
					interval = 50f,
					totalNumberOfLoops = 99999,
					animationLength = 7,
					layerDepth = 0.038500004f,
					scale = 4f
				});
				for (int num15 = 0; num15 < 20; num15++)
				{
					Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(372, 1956, 10, 10), new Vector2(2f, 6f) * 64f + new Vector2((float)Game1.random.Next(-32, 64), (float)Game1.random.Next(16)), flipped: false, 0.002f, Color.LightGray)
					{
						alpha = 0.75f,
						motion = new Vector2(1f, -0.5f),
						acceleration = new Vector2(-0.002f, 0f),
						interval = 99999f,
						layerDepth = 0.0384f + (float)Game1.random.Next(100) / 10000f,
						scale = 3f,
						scaleChange = 0.01f,
						rotationChange = (float)Game1.random.Next(-5, 6) * (float)Math.PI / 256f,
						delayBeforeAnimationStart = num15 * 25
					});
				}
				playSound("fireball");
				Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(388, 1894, 24, 22), 100f, 6, 9999, new Vector2(2f, 5f) * 64f, flicker: false, flipped: true, 1f, 0f, Color.White, 4f, 0f, 0f, 0f)
				{
					motion = new Vector2(4f, -2f)
				});
				if (Game1.player.getChildrenCount() > 1)
				{
					Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(388, 1894, 24, 22), 100f, 6, 9999, new Vector2(2f, 5f) * 64f, flicker: false, flipped: true, 1f, 0f, Color.White, 4f, 0f, 0f, 0f)
					{
						motion = new Vector2(4f, -1.5f),
						delayBeforeAnimationStart = 50
					});
				}
				string text3 = "";
				foreach (Child child in Game1.player.getChildren())
				{
					text3 += Game1.content.LoadString("Strings\\Locations:WitchHut_Goodbye", child.getName());
				}
				Game1.showGlobalMessage(text3);
				Game1.player.getRidOfChildren();
				Game1.multiplayer.globalChatInfoMessage("EvilShrine", Game1.player.name.Value);
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:WitchHut_NoOffering"));
			}
			break;
		case "evilShrineCenter_Yes":
			if (Game1.player.Money >= 30000)
			{
				Game1.player.Money -= 30000;
				Game1.player.wipeExMemories();
				Game1.multiplayer.globalChatInfoMessage("EvilShrine", Game1.player.name.Value);
				Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(536, 1945, 8, 8), new Vector2(468f, 328f), flipped: false, 0f, Color.White)
				{
					interval = 50f,
					totalNumberOfLoops = 99999,
					animationLength = 7,
					layerDepth = 0.038500004f,
					scale = 4f
				});
				playSound("fireball");
				DelayedAction.playSoundAfterDelay("debuffHit", 500, this);
				int num10 = 0;
				Game1.player.faceDirection(2);
				Game1.player.FarmerSprite.animateOnce(new FarmerSprite.AnimationFrame[2]
				{
					new FarmerSprite.AnimationFrame(94, 1500),
					new FarmerSprite.AnimationFrame(0, 1)
				});
				Game1.player.freezePause = 1500;
				Game1.player.jitterStrength = 1f;
				for (int num11 = 0; num11 < 20; num11++)
				{
					Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(372, 1956, 10, 10), new Vector2(7f, 5f) * 64f + new Vector2((float)Game1.random.Next(-32, 64), (float)Game1.random.Next(16)), flipped: false, 0.002f, Color.SlateGray)
					{
						alpha = 0.75f,
						motion = new Vector2(0f, -0.5f),
						acceleration = new Vector2(-0.002f, 0f),
						interval = 99999f,
						layerDepth = 0.032f + (float)Game1.random.Next(100) / 10000f,
						scale = 3f,
						scaleChange = 0.01f,
						rotationChange = (float)Game1.random.Next(-5, 6) * (float)Math.PI / 256f,
						delayBeforeAnimationStart = num11 * 25
					});
				}
				for (int num12 = 0; num12 < 16; num12++)
				{
					foreach (Vector2 item3 in Utility.getBorderOfThisRectangle(Utility.getRectangleCenteredAt(new Vector2(7f, 5f), 2 + num12 * 2)))
					{
						if (num10 % 2 == 0)
						{
							Multiplayer multiplayer = Game1.multiplayer;
							TemporaryAnimatedSprite[] array2 = new TemporaryAnimatedSprite[1];
							TemporaryAnimatedSprite obj4 = new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(692, 1853, 4, 4), 25f, 1, 16, item3 * 64f + new Vector2(32f, 32f), flicker: false, flipped: false)
							{
								layerDepth = 1f,
								delayBeforeAnimationStart = num12 * 50,
								scale = 4f,
								scaleChange = 1f
							};
							Color redToGreenLerpColor = Utility.getRedToGreenLerpColor(1f / (float)(num12 + 1));
							int num13 = 255 - ((Color)(ref redToGreenLerpColor)).R;
							redToGreenLerpColor = Utility.getRedToGreenLerpColor(1f / (float)(num12 + 1));
							int num14 = 255 - ((Color)(ref redToGreenLerpColor)).G;
							redToGreenLerpColor = Utility.getRedToGreenLerpColor(1f / (float)(num12 + 1));
							obj4.color = new Color(num13, num14, 255 - ((Color)(ref redToGreenLerpColor)).B);
							obj4.acceleration = new Vector2(-0.1f, 0f);
							array2[0] = obj4;
							multiplayer.broadcastSprites(this, array2);
						}
						num10++;
					}
				}
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:WitchHut_NoOffering"));
			}
			break;
		case "evilShrineRightActivate_Yes":
			if (Game1.player.Items.ReduceId("(O)203", 1) > 0)
			{
				Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(536, 1945, 8, 8), new Vector2(780f, 388f), flipped: false, 0f, Color.White)
				{
					interval = 50f,
					totalNumberOfLoops = 99999,
					animationLength = 7,
					layerDepth = 0.038500004f,
					scale = 4f
				});
				playSound("fireball");
				DelayedAction.playSoundAfterDelay("batScreech", 500, this);
				for (int num2 = 0; num2 < 20; num2++)
				{
					Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(372, 1956, 10, 10), new Vector2(12f, 6f) * 64f + new Vector2((float)Game1.random.Next(-32, 64), (float)Game1.random.Next(16)), flipped: false, 0.002f, Color.DarkSlateBlue)
					{
						alpha = 0.75f,
						motion = new Vector2(-0.1f, -0.5f),
						acceleration = new Vector2(-0.002f, 0f),
						interval = 99999f,
						layerDepth = 0.0384f + (float)Game1.random.Next(100) / 10000f,
						scale = 3f,
						scaleChange = 0.01f,
						rotationChange = (float)Game1.random.Next(-5, 6) * (float)Math.PI / 256f,
						delayBeforeAnimationStart = num2 * 60
					});
				}
				Game1.player.freezePause = 1501;
				for (int num3 = 0; num3 < 28; num3++)
				{
					Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(540, 347, 13, 13), 50f, 4, 9999, new Vector2(12f, 5f) * 64f, flicker: false, flipped: true, 1f, 0f, Color.White, 4f, 0f, 0f, 0f)
					{
						delayBeforeAnimationStart = 500 + num3 * 25,
						motion = new Vector2((float)(Game1.random.Next(1, 5) * Game1.random.Choose(-1, 1)), (float)(Game1.random.Next(1, 5) * Game1.random.Choose(-1, 1)))
					});
				}
				Game1.spawnMonstersAtNight = true;
				Game1.multiplayer.globalChatInfoMessage("MonstersActivated", Game1.player.name.Value);
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:WitchHut_NoOffering"));
			}
			break;
		case "evilShrineRightDeActivate_Yes":
			if (Game1.player.Items.ReduceId("(O)203", 1) > 0)
			{
				Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(536, 1945, 8, 8), new Vector2(780f, 388f), flipped: false, 0f, Color.White)
				{
					interval = 50f,
					totalNumberOfLoops = 99999,
					animationLength = 7,
					layerDepth = 0.038500004f,
					scale = 4f
				});
				playSound("fireball");
				for (int num19 = 0; num19 < 20; num19++)
				{
					Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(372, 1956, 10, 10), new Vector2(12f, 6f) * 64f + new Vector2((float)Game1.random.Next(-32, 64), (float)Game1.random.Next(16)), flipped: false, 0.002f, Color.DarkSlateBlue)
					{
						alpha = 0.75f,
						motion = new Vector2(0f, -0.5f),
						acceleration = new Vector2(-0.002f, 0f),
						interval = 99999f,
						layerDepth = 0.0384f + (float)Game1.random.Next(100) / 10000f,
						scale = 3f,
						scaleChange = 0.01f,
						rotationChange = (float)Game1.random.Next(-5, 6) * (float)Math.PI / 256f,
						delayBeforeAnimationStart = num19 * 25
					});
				}
				Game1.spawnMonstersAtNight = false;
				Game1.multiplayer.globalChatInfoMessage("MonstersDeActivated", Game1.player.name.Value);
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:WitchHut_NoOffering"));
			}
			break;
		case "buyJojaCola_Yes":
			if (Game1.player.Money >= 75)
			{
				Game1.player.Money -= 75;
				Game1.player.addItemByMenuIfNecessary(ItemRegistry.Create("(O)167"));
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney1"));
			}
			break;
		case "WizardShrine_Yes":
			if (Game1.player.Money >= 500)
			{
				Game1.activeClickableMenu = new CharacterCustomization(CharacterCustomization.Source.Wizard);
				Game1.player.Money -= 500;
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney2"));
			}
			break;
		case "Backpack_Purchase":
			if (Game1.player.maxItems.Value == 12 && Game1.player.Money >= 2000)
			{
				Game1.player.Money -= 2000;
				Game1.player.increaseBackpackSize(12);
				Game1.player.holdUpItemThenMessage(new SpecialItem(99, Game1.content.LoadString("Strings\\StringsFromCSFiles:GameLocation.cs.8708")));
				Game1.multiplayer.globalChatInfoMessage("BackpackLarge", Game1.player.Name);
			}
			else if (Game1.player.maxItems.Value < 36 && Game1.player.Money >= 10000)
			{
				Game1.player.Money -= 10000;
				Game1.player.maxItems.Value += 12;
				Game1.player.holdUpItemThenMessage(new SpecialItem(99, Game1.content.LoadString("Strings\\StringsFromCSFiles:GameLocation.cs.8709")));
				for (int num8 = 0; num8 < Game1.player.maxItems.Value; num8++)
				{
					if (Game1.player.Items.Count <= num8)
					{
						Game1.player.Items.Add(null);
					}
				}
				Game1.multiplayer.globalChatInfoMessage("BackpackDeluxe", Game1.player.Name);
			}
			else if (Game1.player.maxItems.Value != 36)
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney2"));
			}
			break;
		case "ClubSeller_I'll":
			if (Game1.player.Money >= 1000000)
			{
				Game1.player.Money -= 1000000;
				Game1.exitActiveMenu();
				Game1.player.forceCanMove();
				Game1.player.addItemByMenuIfNecessaryElseHoldUp(ItemRegistry.Create("(BC)127"));
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Club_ClubSeller_NotEnoughMoney"));
			}
			break;
		case "BuyQiCoins_Yes":
			if (Game1.player.Money >= 1000)
			{
				Game1.player.Money -= 1000;
				localSound("Pickup_Coin15");
				Game1.player.clubCoins += 100;
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\StringsFromCSFiles:GameLocation.cs.8715"));
			}
			break;
		case "Shaft_Jump":
			if (this is MineShaft mineShaft)
			{
				mineShaft.enterMineShaft();
			}
			break;
		case "mariner_Buy":
			if (Game1.player.Money >= 5000)
			{
				Game1.player.Money -= 5000;
				Item item = ItemRegistry.Create("(O)460");
				item.specialItem = true;
				Game1.player.addItemByMenuIfNecessary(item);
				if (Game1.activeClickableMenu == null)
				{
					Game1.player.holdUpItemThenMessage(ItemRegistry.Create("(O)460"));
				}
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney1"));
			}
			break;
		case "upgrade_Yes":
			houseUpgradeAccept();
			break;
		case "communityUpgrade_Yes":
			communityUpgradeAccept();
			break;
		case "adventureGuild_Shop":
			Game1.player.forceCanMove();
			Utility.TryOpenShopMenu("AdventureShop", "Marlon");
			break;
		case "adventureGuild_Recovery":
			Game1.player.forceCanMove();
			Utility.TryOpenShopMenu("AdventureGuildRecovery", "Marlon");
			break;
		case "carpenter_Shop":
			Game1.player.forceCanMove();
			Utility.TryOpenShopMenu("Carpenter", "Robin");
			break;
		case "carpenter_Upgrade":
			houseUpgradeOffer();
			break;
		case "carpenter_Renovate":
			Game1.player.forceCanMove();
			HouseRenovation.ShowRenovationMenu();
			break;
		case "carpenter_CommunityUpgrade":
			communityUpgradeOffer();
			break;
		case "carpenter_Construct":
			ShowConstructOptions("Robin");
			break;
		case "Eat_Yes":
			Game1.player.isEating = false;
			Game1.player.eatHeldObject();
			break;
		case "Eat_No":
			Game1.player.isEating = false;
			Game1.player.completelyStopAnimatingOrDoingAction();
			break;
		case "Marnie_Supplies":
			Utility.TryOpenShopMenu("AnimalShop", "Marnie");
			break;
		case "Marnie_Adopt":
			Utility.TryOpenShopMenu("PetAdoption", "Marnie");
			break;
		case "Marnie_Purchase":
			Game1.player.forceCanMove();
			Game1.currentLocation.ShowAnimalShopMenu();
			break;
		case "Blacksmith_Shop":
			Utility.TryOpenShopMenu("Blacksmith", "Clint");
			break;
		case "Blacksmith_Upgrade":
			if (Game1.player.daysLeftForToolUpgrade.Value > 0)
			{
				NPC characterFromName3 = getCharacterFromName("Clint");
				if (characterFromName3 != null)
				{
					Game1.DrawDialogue(characterFromName3, "Data\\ExtraDialogue:Clint_StillWorking", Game1.player.toolBeingUpgraded.Value.DisplayName);
				}
			}
			else
			{
				Utility.TryOpenShopMenu("ClintUpgrade", "Clint");
			}
			break;
		case "Blacksmith_Process":
			Game1.activeClickableMenu = new GeodeMenu();
			break;
		case "Dungeon_Go":
			Game1.enterMine(Game1.CurrentMineLevel + 1);
			break;
		case "Mine_Return":
			Game1.enterMine(Game1.player.deepestMineLevel);
			break;
		case "Mine_Enter":
			Game1.enterMine(1);
			break;
		case "Sleep_Yes":
			startSleep();
			break;
		case "SleepTent_Yes":
			Game1.player.isInBed.Value = true;
			Game1.player.sleptInTemporaryBed.Value = true;
			Game1.displayFarmer = false;
			Game1.playSound("sandyStep");
			DelayedAction.playSoundAfterDelay("sandyStep", 500);
			startSleep();
			break;
		case "Mine_Yes":
			if (Game1.CurrentMineLevel > 120)
			{
				Game1.warpFarmer("SkullCave", 3, 4, 2);
			}
			else
			{
				Game1.warpFarmer("UndergroundMine", 16, 16, flip: false);
			}
			break;
		case "Mine_No":
		{
			Response[] answerChoices = new Response[2]
			{
				new Response("No", Game1.content.LoadString("Strings\\Lexicon:QuestionDialogue_No")),
				new Response("Yes", Game1.content.LoadString("Strings\\Lexicon:QuestionDialogue_Yes"))
			};
			createQuestionDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:Mines_ResetMine")), answerChoices, "ResetMine");
			break;
		}
		case "ExitMine_Leave":
		case "ExitMine_Yes":
			if (Game1.CurrentMineLevel == 77377)
			{
				Game1.warpFarmer("Mine", 67, 10, flip: true);
			}
			else if (Game1.CurrentMineLevel > 120)
			{
				Game1.warpFarmer("SkullCave", 3, 4, 2);
			}
			else
			{
				Game1.warpFarmer("Mine", 23, 8, flip: false);
			}
			break;
		case "ExitMine_Go":
			Game1.enterMine(Game1.CurrentMineLevel - 1);
			break;
		case "MinecartGame_Endless":
			Game1.currentMinigame = new MineCart(0, 2);
			break;
		case "MinecartGame_Progress":
			Game1.currentMinigame = new MineCart(0, 3);
			break;
		case "CowboyGame_NewGame":
			Game1.player.jotpkProgress.Value = null;
			Game1.currentMinigame = new AbigailGame();
			break;
		case "CowboyGame_Continue":
			Game1.currentMinigame = new AbigailGame();
			break;
		case "ClubCard_Yes.":
		case "ClubCard_That's":
		{
			Game1.addMail("bouncerGone", noLetter: true, sendToEveryone: true);
			playSound("explosion");
			Game1.flashAlpha = 5f;
			characters.Remove(getCharacterFromName("Bouncer"));
			NPC characterFromName2 = getCharacterFromName("Sandy");
			if (characterFromName2 != null)
			{
				characterFromName2.faceDirection(1);
				characterFromName2.setNewDialogue("Data\\ExtraDialogue:Sandy_PlayerClubMember");
				characterFromName2.doEmote(16);
			}
			Game1.pauseThenMessage(500, Game1.content.LoadString("Strings\\Locations:Club_Bouncer_PlayerClubMember"));
			Game1.player.Halt();
			Game1.getCharacterFromName("Mister Qi")?.setNewDialogue("Data\\ExtraDialogue:MisterQi_PlayerClubMember");
			break;
		}
		case "CalicoJack_Rules":
			Game1.multipleDialogues(new string[2]
			{
				Game1.content.LoadString("Strings\\Locations:Club_CalicoJack_Rules1"),
				Game1.content.LoadString("Strings\\Locations:Club_CalicoJack_Rules2")
			});
			break;
		case "CalicoJackHS_Play":
			if (Game1.player.clubCoins >= 1000)
			{
				Game1.currentMinigame = new CalicoJack(-1, highStakes: true);
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Club_CalicoJackHS_NotEnoughCoins"));
			}
			break;
		case "CalicoJack_Play":
			if (Game1.player.clubCoins >= 100)
			{
				Game1.currentMinigame = new CalicoJack();
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:Club_CalicoJack_NotEnoughCoins"));
			}
			break;
		case "BuyClubCoins_Yes":
			if (Game1.player.Money >= 1000)
			{
				Game1.player.Money -= 1000;
				Game1.player.clubCoins += 10;
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney1"));
			}
			break;
		case "Bouquet_Yes":
			if (Game1.player.Money >= 500)
			{
				if (Game1.player.ActiveObject == null)
				{
					Game1.player.Money -= 500;
					Object obj3 = ItemRegistry.Create<Object>("(O)458");
					obj3.CanBeSetDown = false;
					Game1.player.grabObject(obj3);
					return true;
				}
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney1"));
			}
			break;
		case "Mariner_Buy":
			if (Game1.player.Money >= 5000)
			{
				Game1.player.Money -= 5000;
				Object obj2 = ItemRegistry.Create<Object>("(O)460");
				obj2.CanBeSetDown = false;
				Game1.player.grabObject(obj2);
				return true;
			}
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney1"));
			break;
		case "ClearHouse_Yes":
		{
			Vector2 tile = Game1.player.Tile;
			Vector2[] adjacentTilesOffsets = Character.AdjacentTilesOffsets;
			foreach (Vector2 val in adjacentTilesOffsets)
			{
				Vector2 key = tile + val;
				objects.Remove(key);
			}
			break;
		}
		case "ExitToTitle_Yes":
			Game1.fadeScreenToBlack();
			Game1.exitToTitle = true;
			break;
		case "telephone_Carpenter_HouseCost":
		{
			NPC characterFromName = Game1.getCharacterFromName("Robin");
			string text = "Strings\\Locations:ScienceHouse_Carpenter_UpgradeHouse" + (Game1.player.houseUpgradeLevel.Value + 1);
			string text2 = Game1.content.LoadString(text, "65,000", "100");
			if (text2.Contains('.'))
			{
				text2 = text2.Substring(0, text2.LastIndexOf('.') + 1);
			}
			else if (text2.Contains('。'))
			{
				text2 = text2.Substring(0, text2.LastIndexOf('。') + 1);
			}
			Game1.DrawDialogue(new Dialogue(characterFromName, text, text2)
			{
				overridePortrait = Game1.temporaryContent.Load<Texture2D>("Portraits\\AnsweringMachine")
			});
			Game1.afterDialogues = (Game1.afterFadeFunction)Delegate.Combine(Game1.afterDialogues, (Game1.afterFadeFunction)delegate
			{
				answerDialogueAction("HangUp", LegacyShims.EmptyArray<string>());
			});
			break;
		}
		case "telephone_Carpenter_BuildingCost":
		{
			GameLocation targetLocation = Game1.getFarm();
			if (Game1.currentLocation.IsBuildableLocation())
			{
				targetLocation = Game1.currentLocation;
			}
			Game1.activeClickableMenu = new CarpenterMenu("Robin", targetLocation);
			if (Game1.activeClickableMenu is CarpenterMenu carpenterMenu)
			{
				carpenterMenu.readOnly = true;
				carpenterMenu.behaviorBeforeCleanup = (Action<IClickableMenu>)Delegate.Combine(carpenterMenu.behaviorBeforeCleanup, (Action<IClickableMenu>)delegate
				{
					answerDialogueAction("HangUp", LegacyShims.EmptyArray<string>());
				});
			}
			break;
		}
		case "telephone_Carpenter_ShopStock":
			Utility.TryOpenShopMenu("Carpenter", null, playOpenSound: true);
			if (Game1.activeClickableMenu is ShopMenu shopMenu3)
			{
				shopMenu3.readOnly = true;
				shopMenu3.behaviorBeforeCleanup = (Action<IClickableMenu>)Delegate.Combine(shopMenu3.behaviorBeforeCleanup, (Action<IClickableMenu>)delegate
				{
					answerDialogueAction("HangUp", LegacyShims.EmptyArray<string>());
				});
			}
			break;
		case "telephone_Blacksmith_UpgradeCost":
			answerDialogueAction("Blacksmith_Upgrade", LegacyShims.EmptyArray<string>());
			if (Game1.activeClickableMenu is ShopMenu shopMenu2)
			{
				shopMenu2.readOnly = true;
				shopMenu2.behaviorBeforeCleanup = (Action<IClickableMenu>)Delegate.Combine(shopMenu2.behaviorBeforeCleanup, (Action<IClickableMenu>)delegate
				{
					answerDialogueAction("HangUp", LegacyShims.EmptyArray<string>());
				});
			}
			break;
		case "telephone_SeedShop_CheckSeedStock":
			if (Game1.getLocationFromName("SeedShop") is SeedShop)
			{
				if (Utility.TryOpenShopMenu("SeedShop", null, playOpenSound: true) && Game1.activeClickableMenu is ShopMenu shopMenu)
				{
					shopMenu.readOnly = true;
					shopMenu.behaviorBeforeCleanup = (Action<IClickableMenu>)Delegate.Combine(shopMenu.behaviorBeforeCleanup, (Action<IClickableMenu>)delegate
					{
						answerDialogueAction("HangUp", LegacyShims.EmptyArray<string>());
					});
				}
			}
			else
			{
				answerDialogueAction("HangUp", LegacyShims.EmptyArray<string>());
			}
			break;
		case "telephone_AnimalShop_CheckAnimalPrices":
			Game1.currentLocation.ShowAnimalShopMenu(delegate(PurchaseAnimalsMenu menu)
			{
				menu.readOnly = true;
				menu.behaviorBeforeCleanup = (Action<IClickableMenu>)Delegate.Combine(menu.behaviorBeforeCleanup, (Action<IClickableMenu>)delegate
				{
					answerDialogueAction("HangUp", LegacyShims.EmptyArray<string>());
				});
			});
			break;
		case "ShrineOfSkullChallenge_Yes":
			Game1.player.team.toggleSkullShrineOvernight.Value = true;
			Game1.showGlobalMessage(Game1.content.LoadString("Strings\\Locations:ChallengeShrine_Activated"));
			Game1.multiplayer.globalChatInfoMessage(Game1.player.team.skullShrineActivated.Value ? "HardModeSkullCaveDeactivated" : "HardModeSkullCaveActivated", Game1.player.Name);
			playSound(Game1.player.team.skullShrineActivated.Value ? "skeletonStep" : "serpentDie");
			break;
		case "ShrineOfChallenge_Yes":
			Game1.player.team.toggleMineShrineOvernight.Value = true;
			Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:ChallengeShrine_Activated"));
			Game1.multiplayer.globalChatInfoMessage((!Game1.player.team.mineShrineActivated.Value) ? "HardModeMinesActivated" : "HardModeMinesDeactivated", Game1.player.Name);
			DelayedAction.functionAfterDelay(delegate
			{
				//IL_0044: Unknown result type (might be due to invalid IL or missing references)
				//IL_0053: Unknown result type (might be due to invalid IL or missing references)
				//IL_005d: Unknown result type (might be due to invalid IL or missing references)
				//IL_006c: Unknown result type (might be due to invalid IL or missing references)
				//IL_0071: Unknown result type (might be due to invalid IL or missing references)
				//IL_007c: Unknown result type (might be due to invalid IL or missing references)
				//IL_00db: Unknown result type (might be due to invalid IL or missing references)
				//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
				//IL_0122: Unknown result type (might be due to invalid IL or missing references)
				//IL_0131: Unknown result type (might be due to invalid IL or missing references)
				//IL_013b: Unknown result type (might be due to invalid IL or missing references)
				//IL_014a: Unknown result type (might be due to invalid IL or missing references)
				//IL_014f: Unknown result type (might be due to invalid IL or missing references)
				//IL_015a: Unknown result type (might be due to invalid IL or missing references)
				//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
				//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
				if (!Game1.player.team.mineShrineActivated.Value)
				{
					Game1.playSound("fireball");
					temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(536, 1945, 8, 8), new Vector2(8.75f, 5.8f) * 64f + new Vector2(32f, -32f), flipped: false, 0f, Color.White)
					{
						interval = 50f,
						totalNumberOfLoops = 99999,
						animationLength = 4,
						lightId = "ShrineOfChallenge_Activation_1",
						id = 888,
						lightRadius = 2f,
						scale = 4f,
						yPeriodic = true,
						lightcolor = new Color(100, 0, 0),
						yPeriodicLoopTime = 1000f,
						yPeriodicRange = 4f,
						layerDepth = 0.04544f
					});
					temporarySprites.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(536, 1945, 8, 8), new Vector2(10.75f, 5.8f) * 64f + new Vector2(32f, -32f), flipped: false, 0f, Color.White)
					{
						interval = 50f,
						totalNumberOfLoops = 99999,
						animationLength = 4,
						lightId = "ShrineOfChallenge_Activation_2",
						id = 889,
						lightRadius = 2f,
						scale = 4f,
						lightcolor = new Color(100, 0, 0),
						yPeriodic = true,
						yPeriodicLoopTime = 1100f,
						yPeriodicRange = 4f,
						layerDepth = 0.04544f
					});
				}
				else
				{
					removeTemporarySpritesWithID(888);
					removeTemporarySpritesWithID(889);
					Game1.playSound("fireball");
				}
			}, 500);
			break;
		default:
			if (questionAndAnswer.StartsWith("pagedResponse"))
			{
				string obj = questionAndAnswer.Substring("pagedResponse".Length + 1);
				Action<string> onPagedResponse = _OnPagedResponse;
				_CleanupPagedResponses();
				onPagedResponse?.Invoke(obj);
			}
			break;
		}
		return true;
	}

	public void playShopPhoneNumberSounds(string whichShop)
	{
		Random random = Utility.CreateRandom(whichShop.GetHashCode());
		DelayedAction.playSoundAfterDelay("telephone_dialtone", 495, null, null, 1200);
		DelayedAction.playSoundAfterDelay("telephone_buttonPush", 1200, null, null, 1200 + random.Next(-4, 5) * 100);
		DelayedAction.playSoundAfterDelay("telephone_buttonPush", 1370, null, null, 1200 + random.Next(-4, 5) * 100);
		DelayedAction.playSoundAfterDelay("telephone_buttonPush", 1600, null, null, 1200 + random.Next(-4, 5) * 100);
		DelayedAction.playSoundAfterDelay("telephone_buttonPush", 1850, null, null, 1200 + random.Next(-4, 5) * 100);
		DelayedAction.playSoundAfterDelay("telephone_buttonPush", 2030, null, null, 1200 + random.Next(-4, 5) * 100);
		DelayedAction.playSoundAfterDelay("telephone_buttonPush", 2250, null, null, 1200 + random.Next(-4, 5) * 100);
		DelayedAction.playSoundAfterDelay("telephone_buttonPush", 2410, null, null, 1200 + random.Next(-4, 5) * 100);
		DelayedAction.playSoundAfterDelay("telephone_ringingInEar", 3150);
	}

	public virtual bool answerDialogue(Response answer)
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		string[] array = ((lastQuestionKey != null) ? ArgUtility.SplitBySpace(lastQuestionKey) : null);
		string text = ((array != null) ? (array[0] + "_" + answer.responseKey) : null);
		if (answer.responseKey.Equals("Move"))
		{
			Game1.player.grabObject(actionObjectForQuestionDialogue);
			removeObject(actionObjectForQuestionDialogue.TileLocation, showDestroyedObject: false);
			actionObjectForQuestionDialogue = null;
			return true;
		}
		if (afterQuestion != null)
		{
			afterQuestion(Game1.player, answer.responseKey);
			afterQuestion = null;
			Game1.objectDialoguePortraitPerson = null;
			return true;
		}
		if (text == null)
		{
			return false;
		}
		return answerDialogueAction(text, array);
	}

	public static bool AreStoresClosedForFestival()
	{
		if (Utility.isFestivalDay())
		{
			return Utility.getStartTimeOfFestival() < 1900;
		}
		return false;
	}

	public static void RemoveProfession(int profession)
	{
		if (Game1.player.professions.Remove(profession))
		{
			LevelUpMenu.removeImmediateProfessionPerk(profession);
		}
	}

	public static bool canRespec(int skill_index)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.player.GetUnmodifiedSkillLevel(skill_index) < 5)
		{
			return false;
		}
		if (Game1.player.newLevels.Contains(new Point(skill_index, 5)) || Game1.player.newLevels.Contains(new Point(skill_index, 10)))
		{
			return false;
		}
		return true;
	}

	public void setObject(Vector2 v, Object o)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		objects[v] = o;
	}

	private void houseUpgradeOffer()
	{
		switch (Game1.player.houseUpgradeLevel.Value)
		{
		case 0:
			createQuestionDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:ScienceHouse_Carpenter_UpgradeHouse1")), createYesNoResponses(), "upgrade");
			break;
		case 1:
			createQuestionDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:ScienceHouse_Carpenter_UpgradeHouse2", "65,000", "100")), createYesNoResponses(), "upgrade");
			break;
		case 2:
			createQuestionDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:ScienceHouse_Carpenter_UpgradeHouse3")), createYesNoResponses(), "upgrade");
			break;
		}
	}

	private void communityUpgradeOffer()
	{
		if (!Game1.MasterPlayer.mailReceived.Contains("pamHouseUpgrade"))
		{
			createQuestionDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:ScienceHouse_Carpenter_CommunityUpgrade1")), createYesNoResponses(), "communityUpgrade");
			Game1.player.team.RequestSetMail(PlayerActionTarget.Host, "pamHouseUpgradeAsked", MailType.Received, add: true);
		}
		else if (!Game1.MasterPlayer.mailReceived.Contains("communityUpgradeShortcuts"))
		{
			createQuestionDialogue(Game1.parseText(Game1.content.LoadString("Strings\\Locations:ScienceHouse_Carpenter_CommunityUpgrade2")), createYesNoResponses(), "communityUpgrade");
		}
	}

	public virtual bool catchOceanCrabPotFishFromThisSpot(int x, int y)
	{
		return false;
	}

	private void communityUpgradeAccept()
	{
		if (!Game1.MasterPlayer.mailReceived.Contains("pamHouseUpgrade"))
		{
			if (Game1.player.Money >= 500000 && Game1.player.Items.ContainsId("(O)388", 950))
			{
				Game1.player.Money -= 500000;
				Game1.player.Items.ReduceId("(O)388", 950);
				Game1.RequireCharacter("Robin").setNewDialogue("Data\\ExtraDialogue:Robin_PamUpgrade_Accepted");
				Game1.drawDialogue(Game1.getCharacterFromName("Robin"));
				Game1.RequireLocation<Town>("Town").daysUntilCommunityUpgrade.Value = 3;
				Game1.multiplayer.globalChatInfoMessage("CommunityUpgrade", Game1.player.Name);
			}
			else if (Game1.player.Money < 500000)
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney3"));
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:ScienceHouse_Carpenter_NotEnoughWood", 950));
			}
		}
		else if (!Game1.MasterPlayer.mailReceived.Contains("communityUpgradeShortcuts"))
		{
			if (Game1.player.Money >= 300000)
			{
				Game1.player.Money -= 300000;
				Game1.RequireCharacter("Robin").setNewDialogue("Data\\ExtraDialogue:Robin_HouseUpgrade_Accepted", add: true);
				Game1.drawDialogue(Game1.getCharacterFromName("Robin"));
				Game1.RequireLocation<Town>("Town").daysUntilCommunityUpgrade.Value = 3;
				Game1.multiplayer.globalChatInfoMessage("CommunityUpgrade", Game1.player.Name);
			}
			else if (Game1.player.Money < 300000)
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney3"));
			}
		}
	}

	private void houseUpgradeAccept()
	{
		switch (Game1.player.houseUpgradeLevel.Value)
		{
		case 0:
			if (Game1.player.Money >= 10000 && Game1.player.Items.ContainsId("(O)388", 450))
			{
				Game1.player.daysUntilHouseUpgrade.Value = 3;
				Game1.player.Money -= 10000;
				Game1.player.Items.ReduceId("(O)388", 450);
				Game1.RequireCharacter("Robin").setNewDialogue("Data\\ExtraDialogue:Robin_HouseUpgrade_Accepted", add: true);
				Game1.drawDialogue(Game1.getCharacterFromName("Robin"));
				Game1.multiplayer.globalChatInfoMessage("HouseUpgrade", Game1.player.Name, Lexicon.getTokenizedPossessivePronoun(Game1.player.IsMale));
			}
			else if (Game1.player.Money < 10000)
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney3"));
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:ScienceHouse_Carpenter_NotEnoughWood", 450));
			}
			break;
		case 1:
			if (Game1.player.Money >= 65000 && Game1.player.Items.ContainsId("(O)709", 100))
			{
				Game1.player.daysUntilHouseUpgrade.Value = 3;
				Game1.player.Money -= 65000;
				Game1.player.Items.ReduceId("(O)709", 100);
				Game1.RequireCharacter("Robin").setNewDialogue("Data\\ExtraDialogue:Robin_HouseUpgrade_Accepted", add: true);
				Game1.drawDialogue(Game1.getCharacterFromName("Robin"));
				Game1.multiplayer.globalChatInfoMessage("HouseUpgrade", Game1.player.Name, Lexicon.getTokenizedPossessivePronoun(Game1.player.IsMale));
			}
			else if (Game1.player.Money < 65000)
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney3"));
			}
			else
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\Locations:ScienceHouse_Carpenter_NotEnoughHardwood", 100));
			}
			break;
		case 2:
			if (Game1.player.Money >= 100000)
			{
				Game1.player.daysUntilHouseUpgrade.Value = 3;
				Game1.player.Money -= 100000;
				Game1.RequireCharacter("Robin").setNewDialogue("Data\\ExtraDialogue:Robin_HouseUpgrade_Accepted", add: true);
				Game1.drawDialogue(Game1.getCharacterFromName("Robin"));
				Game1.multiplayer.globalChatInfoMessage("HouseUpgrade", Game1.player.Name, Lexicon.getTokenizedPossessivePronoun(Game1.player.IsMale));
			}
			else if (Game1.player.Money < 100000)
			{
				Game1.drawObjectDialogue(Game1.content.LoadString("Strings\\UI:NotEnoughMoney3"));
			}
			break;
		}
	}

	public void destroyObject(Vector2 tileLocation, Farmer who)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		destroyObject(tileLocation, hardDestroy: false, who);
	}

	public void destroyObject(Vector2 tileLocation, bool hardDestroy, Farmer who)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		if (!objects.TryGetValue(tileLocation, out var value) || value.fragility.Value == 2 || value is Chest || !(value.QualifiedItemId != "(BC)165"))
		{
			return;
		}
		bool flag = false;
		if (value.Type == "Fish" || value.Type == "Cooking" || value.Type == "Crafting")
		{
			if (!(value is BreakableContainer))
			{
				TemporaryAnimatedSprite temporaryAnimatedSprite = new TemporaryAnimatedSprite(0, 150f, 1, 3, new Vector2(tileLocation.X * 64f, tileLocation.Y * 64f), flicker: true, value.bigCraftable.Value, value.flipped.Value);
				temporaryAnimatedSprite.CopyAppearanceFromItemId(value.QualifiedItemId, value.showNextIndex.Value ? 1 : 0);
				temporaryAnimatedSprite.scale = 4f;
				Game1.multiplayer.broadcastSprites(this, temporaryAnimatedSprite);
			}
			flag = true;
		}
		else if (value.CanBeGrabbed || hardDestroy)
		{
			flag = true;
		}
		if (value.IsBreakableStone())
		{
			flag = true;
			OnStoneDestroyed(value.ItemId, (int)tileLocation.X, (int)tileLocation.Y, who);
		}
		if (flag)
		{
			objects.Remove(tileLocation);
		}
	}

	public void addOneTimeGiftBox(Item i, int x, int y, int whichGiftBox = 2)
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		string text = Name + "_giftbox_" + x + "_" + y;
		if (!Game1.player.mailReceived.Contains(text))
		{
			Vector2 val = default(Vector2);
			((Vector2)(ref val))._002Ector((float)x, (float)y);
			if (!(overlayObjects.GetValueOrDefault(val) is Chest chest) || !(chest.mailToAddOnItemDump == text))
			{
				cleanUpTileForMapOverride(new Point(x, y));
			}
			if (!overlayObjects.ContainsKey(val))
			{
				Chest value = new Chest(new List<Item> { i }, val, giftbox: true, whichGiftBox)
				{
					mailToAddOnItemDump = text
				};
				overlayObjects.Add(val, value);
			}
		}
	}

	public virtual string GetLocationContextId()
	{
		if (locationContextId == null)
		{
			if (map == null)
			{
				reloadMap();
			}
			if (map != null && ((Component)map).Properties.TryGetValue("LocationContext", out var value))
			{
				if (Game1.locationContextData.ContainsKey(value))
				{
					locationContextId = value;
				}
				else
				{
					Game1.log.Error($"Location {NameOrUniqueName} has invalid LocationContext map property '{value}', ignoring value.");
				}
			}
			if (locationContextId == null)
			{
				locationContextId = GetParentLocation()?.GetLocationContextId() ?? "Default";
			}
		}
		return locationContextId;
	}

	public virtual LocationContextData GetLocationContext()
	{
		return LocationContexts.Require(GetLocationContextId());
	}

	public bool InDesertContext()
	{
		return GetLocationContextId() == "Desert";
	}

	public bool InIslandContext()
	{
		return GetLocationContextId() == "Island";
	}

	public bool InValleyContext()
	{
		return GetLocationContextId() == "Default";
	}

	public virtual bool sinkDebris(Debris debris, Vector2 chunkTile, Vector2 chunkPosition)
	{
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		if (debris.isEssentialItem())
		{
			return false;
		}
		if (debris.item != null && debris.item.HasContextTag("book_item"))
		{
			return false;
		}
		if (debris.debrisType.Value == Debris.DebrisType.OBJECT && debris.chunkType.Value == 74)
		{
			return false;
		}
		if (debris.floppingFish.Value)
		{
			foreach (Building building in buildings)
			{
				if (building.isTileFishable(chunkTile))
				{
					return false;
				}
			}
		}
		if (!debris.isSinking.Value)
		{
			debris.isSinking.Value = true;
			Debris.DebrisType value = debris.debrisType.Value;
			if (value == Debris.DebrisType.OBJECT || value == Debris.DebrisType.RESOURCE)
			{
				if (Game1.random.NextBool())
				{
					TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 0, 64, 64), 150f, 8, 0, chunkPosition + new Vector2(-8f), flicker: false, Game1.random.NextBool(), 0.001f, 0.02f, Color.White, 1f, 0.003f, 0f, 0f)
					{
						delayBeforeAnimationStart = Game1.random.Next(300),
						startSound = "quickSlosh"
					});
				}
				return false;
			}
		}
		else
		{
			bool flag = false;
			foreach (Chunk chunk in debris.Chunks)
			{
				if (chunk.sinkTimer.Value <= 0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				return false;
			}
		}
		if (debris.debrisType.Value == Debris.DebrisType.CHUNKS)
		{
			localSound("quickSlosh");
			TemporarySprites.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 0, 64, 64), 150f, 8, 0, chunkPosition + new Vector2(-8f), flicker: false, Game1.random.NextBool(), 0.001f, 0.02f, Color.White, 1f, 0.003f, 0f, 0f));
			return true;
		}
		TemporarySprites.Add(new TemporaryAnimatedSprite(28, 300f, 2, 1, chunkPosition + new Vector2(-8f), flicker: false, flipped: false));
		localSound("dropItemInWater");
		return true;
	}

	public virtual bool doesTileSinkDebris(int xTile, int yTile, Debris.DebrisType type)
	{
		if (isTileBuildingFishable(xTile, yTile))
		{
			return true;
		}
		if (type == Debris.DebrisType.CHUNKS)
		{
			if (isWaterTile(xTile, yTile))
			{
				return !hasTileAt(xTile, yTile, "Buildings");
			}
			return false;
		}
		if (isWaterTile(xTile, yTile) && !isTileUpperWaterBorder(getTileIndexAt(xTile, yTile, "Buildings", "untitled tile sheet")))
		{
			return doesTileHaveProperty(xTile, yTile, "Passable", "Buildings") == null;
		}
		return false;
	}

	private bool isTileUpperWaterBorder(int index)
	{
		switch (index)
		{
		case 183:
		case 184:
		case 185:
		case 211:
		case 1182:
		case 1183:
		case 1184:
		case 1210:
			return true;
		default:
			return false;
		}
	}

	public virtual bool doesEitherTileOrTileIndexPropertyEqual(int xTile, int yTile, string propertyName, string layerName, string propertyValue)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		Map obj = map;
		Layer val = ((obj != null) ? obj.GetLayer(layerName) : null);
		if (val != null)
		{
			Tile val2 = val.PickTile(new Location(xTile * 64, yTile * 64), Game1.viewport.Size);
			if (val2 != null && val2.TileIndexProperties.TryGetValue(propertyName, out var value) && value == propertyValue)
			{
				return true;
			}
			if (val2 != null && ((Component)val.PickTile(new Location(xTile * 64, yTile * 64), Game1.viewport.Size)).Properties.TryGetValue(propertyName, out var value2) && value2 == propertyValue)
			{
				return true;
			}
		}
		return propertyValue == null;
	}

	public virtual bool IsNoSpawnTile(Vector2 tile, string type = "All", bool ignoreTileSheetProperties = false)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		int xTile = (int)tile.X;
		int yTile = (int)tile.Y;
		string text = doesTileHaveProperty(xTile, yTile, "NoSpawn", "Back", ignoreTileSheetProperties);
		switch (text)
		{
		case "Grass":
		case "Tree":
			if (type == text)
			{
				return true;
			}
			break;
		default:
		{
			if (!bool.TryParse(text, out var result) || result)
			{
				return true;
			}
			break;
		}
		case null:
			break;
		}
		return getBuildingAt(tile) != null;
	}

	public virtual string doesTileHaveProperty(int xTile, int yTile, string propertyName, string layerName, bool ignoreTileSheetProperties = false)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		Vector2 tile = default(Vector2);
		((Vector2)(ref tile))._002Ector((float)xTile, (float)yTile);
		bool flag = false;
		foreach (Building building in buildings)
		{
			if (!building.isMoving && building.occupiesTile(tile, applyTilePropertyRadius: true))
			{
				string property_value = null;
				if (building.doesTileHaveProperty(xTile, yTile, propertyName, layerName, ref property_value))
				{
					return property_value;
				}
				flag = flag || building.occupiesTile(tile);
			}
		}
		foreach (Furniture item in furniture)
		{
			if ((float)xTile >= item.tileLocation.X - (float)item.GetAdditionalTilePropertyRadius() && (float)xTile < item.tileLocation.X + (float)item.getTilesWide() + (float)item.GetAdditionalTilePropertyRadius() && (float)yTile >= item.tileLocation.Y - (float)item.GetAdditionalTilePropertyRadius() && (float)yTile < item.tileLocation.Y + (float)item.getTilesHigh() + (float)item.GetAdditionalTilePropertyRadius())
			{
				string property_value2 = null;
				if (item.DoesTileHaveProperty(xTile, yTile, propertyName, layerName, ref property_value2))
				{
					return property_value2;
				}
			}
		}
		if (!flag && map != null)
		{
			Layer layer = map.GetLayer(layerName);
			Tile val = ((layer != null) ? layer.Tiles[xTile, yTile] : null);
			if (val != null)
			{
				if (((Component)val).Properties.TryGetValue(propertyName, out var value))
				{
					return value;
				}
				if (!ignoreTileSheetProperties && val.TileIndexProperties.TryGetValue(propertyName, out value))
				{
					return value;
				}
			}
		}
		return null;
	}

	public virtual string doesTileHavePropertyNoNull(int xTile, int yTile, string propertyName, string layerName)
	{
		return doesTileHaveProperty(xTile, yTile, propertyName, layerName) ?? "";
	}

	public string[] GetTilePropertySplitBySpaces(string propertyName, string layerId, int tileX, int tileY)
	{
		string text = doesTileHaveProperty(tileX, tileY, propertyName, layerId);
		if (text == null)
		{
			return LegacyShims.EmptyArray<string>();
		}
		return ArgUtility.SplitBySpace(text);
	}

	public bool isWaterTile(int xTile, int yTile)
	{
		return doesTileHaveProperty(xTile, yTile, "Water", "Back") != null;
	}

	public bool isOpenWater(int xTile, int yTile)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		if (!isWaterTile(xTile, yTile))
		{
			return false;
		}
		int tileIndexAt = getTileIndexAt(xTile, yTile, "Buildings", "outdoors");
		if ((uint)(tileIndexAt - 628) <= 1u || tileIndexAt == 734 || tileIndexAt == 759)
		{
			return false;
		}
		return !objects.ContainsKey(new Vector2((float)xTile, (float)yTile));
	}

	public bool isCropAtTile(int tileX, int tileY)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		Vector2 key = default(Vector2);
		((Vector2)(ref key))._002Ector((float)tileX, (float)tileY);
		if (terrainFeatures.TryGetValue(key, out var value) && value is HoeDirt hoeDirt)
		{
			return hoeDirt.crop != null;
		}
		return false;
	}

	public virtual bool dropObject(Object obj, Vector2 dropLocation, Rectangle viewport, bool initialPlacement, Farmer who = null)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)((int)dropLocation.X / 64), (float)((int)dropLocation.Y / 64));
		obj.Location = this;
		obj.TileLocation = val;
		obj.isSpawnedObject.Value = true;
		if (!isTileOnMap(val) || map.RequireLayer("Back").PickTile(new Location((int)dropLocation.X, (int)dropLocation.Y), Game1.viewport.Size) == null || ((IDictionary<string, PropertyValue>)map.RequireLayer("Back").Tiles[(int)val.X, (int)val.Y].TileIndexProperties).ContainsKey("Unplaceable"))
		{
			return false;
		}
		if (obj.bigCraftable.Value)
		{
			if (!isFarm.Value)
			{
				return false;
			}
			if (!obj.setOutdoors.Value && isOutdoors.Value)
			{
				return false;
			}
			if (!obj.setIndoors.Value && !isOutdoors.Value)
			{
				return false;
			}
			if (obj.performDropDownAction(who))
			{
				return false;
			}
		}
		else if (obj.Type == "Crafting" && obj.performDropDownAction(who))
		{
			obj.CanBeSetDown = false;
		}
		bool flag = this.isTilePassable(new Location((int)val.X, (int)val.Y), viewport) && CanItemBePlacedHere(val);
		if ((obj.CanBeSetDown || initialPlacement) && flag && !isTileHoeDirt(val))
		{
			if (!objects.TryAdd(val, obj))
			{
				return false;
			}
		}
		else if (isWaterTile((int)val.X, (int)val.Y))
		{
			Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(28, 300f, 2, 1, dropLocation, flicker: false, obj.flipped.Value));
			playSound("dropItemInWater");
		}
		else
		{
			if (obj.CanBeSetDown && !flag)
			{
				return false;
			}
			if (obj.ParentSheetIndex >= 0 && obj.Type != null)
			{
				if (obj.Type == "Fish" || obj.Type == "Cooking" || obj.Type == "Crafting")
				{
					TemporaryAnimatedSprite temporaryAnimatedSprite = new TemporaryAnimatedSprite(0, 150f, 1, 3, dropLocation, flicker: true, obj.flipped.Value);
					temporaryAnimatedSprite.CopyAppearanceFromItemId(obj.QualifiedItemId);
					Game1.multiplayer.broadcastSprites(this, temporaryAnimatedSprite);
				}
				else
				{
					TemporaryAnimatedSprite temporaryAnimatedSprite2 = new TemporaryAnimatedSprite(0, 150f, 1, 3, dropLocation, flicker: true, obj.flipped.Value);
					temporaryAnimatedSprite2.CopyAppearanceFromItemId(obj.QualifiedItemId, 1);
					Game1.multiplayer.broadcastSprites(this, temporaryAnimatedSprite2);
				}
			}
		}
		return true;
	}

	private void rumbleAndFade(int milliseconds)
	{
		rumbleAndFadeEvent.Fire(milliseconds);
	}

	private void performRumbleAndFade(int milliseconds)
	{
		if (Game1.currentLocation == this)
		{
			Rumble.rumbleAndFade(1f, milliseconds);
		}
	}

	private void damagePlayers(Rectangle area, int damage, bool isBomb = false)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		damagePlayersEvent.Fire(new DamagePlayersEventArg
		{
			Area = area,
			Damage = damage,
			IsBomb = isBomb
		});
	}

	private void performDamagePlayers(DamagePlayersEventArg arg)
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.player.currentLocation == this && (!arg.IsBomb || !Game1.player.hasBuff("dwarfStatue_3")))
		{
			int num = arg.Damage;
			if (Game1.player.stats.Get("Book_Bombs") != 0)
			{
				num = (int)((float)num * 0.75f);
			}
			Rectangle boundingBox = Game1.player.GetBoundingBox();
			if (((Rectangle)(ref boundingBox)).Intersects(arg.Area) && !Game1.player.onBridge.Value)
			{
				Game1.player.takeDamage(num, overrideParry: true, null);
			}
		}
	}

	public void explode(Vector2 tileLocation, int radius, Farmer who, bool damageFarmers = true, int damage_amount = -1, bool destroyObjects = true)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0651: Unknown result type (might be due to invalid IL or missing references)
		//IL_065c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_060f: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_082c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0573: Unknown result type (might be due to invalid IL or missing references)
		//IL_039e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0502: Unknown result type (might be due to invalid IL or missing references)
		//IL_050e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0513: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Unknown result type (might be due to invalid IL or missing references)
		//IL_03db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0790: Unknown result type (might be due to invalid IL or missing references)
		//IL_0718: Unknown result type (might be due to invalid IL or missing references)
		//IL_0488: Unknown result type (might be due to invalid IL or missing references)
		//IL_0494: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_043c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0448: Unknown result type (might be due to invalid IL or missing references)
		//IL_0454: Unknown result type (might be due to invalid IL or missing references)
		//IL_03eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0736: Unknown result type (might be due to invalid IL or missing references)
		//IL_073f: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0749: Unknown result type (might be due to invalid IL or missing references)
		//IL_0750: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_0348: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fe: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		updateMap();
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(Math.Min(map.Layers[0].LayerWidth - 1, Math.Max(0f, tileLocation.X - (float)radius)), Math.Min(map.Layers[0].LayerHeight - 1, Math.Max(0f, tileLocation.Y - (float)radius)));
		bool[,] circleOutlineGrid = Game1.getCircleOutlineGrid(radius);
		Rectangle val2 = default(Rectangle);
		((Rectangle)(ref val2))._002Ector((int)(tileLocation.X - (float)radius) * 64, (int)(tileLocation.Y - (float)radius) * 64, (radius * 2 + 1) * 64, (radius * 2 + 1) * 64);
		if (damage_amount > 0)
		{
			damageMonster(val2, damage_amount, damage_amount, isBomb: true, who);
		}
		else
		{
			damageMonster(val2, radius * 6, radius * 8, isBomb: true, who);
		}
		TemporaryAnimatedSpriteList temporaryAnimatedSpriteList = new TemporaryAnimatedSpriteList
		{
			new TemporaryAnimatedSprite(23, 9999f, 6, 1, new Vector2(val.X * 64f, val.Y * 64f), flicker: false, Game1.random.NextBool())
			{
				lightId = $"{NameOrUniqueName}_{"explode"}_{tileLocation.X}_{tileLocation.Y}_{Game1.random.Next()}",
				lightRadius = radius,
				lightcolor = Color.Black,
				alphaFade = 0.03f - (float)radius * 0.003f,
				Parent = this
			}
		};
		rumbleAndFade(300 + radius * 100);
		if (damageFarmers)
		{
			int damage = ((damage_amount > 0) ? damage_amount : (radius * 3));
			damagePlayers(val2, damage, isBomb: true);
		}
		for (int i = 0; i < radius * 2 + 1; i++)
		{
			for (int j = 0; j < radius * 2 + 1; j++)
			{
				if (i == 0 || j == 0 || i == radius * 2 || j == radius * 2)
				{
					num = (circleOutlineGrid[i, j] ? 1 : 0);
				}
				else if (circleOutlineGrid[i, j])
				{
					num += ((j <= radius) ? 1 : (-1));
					if (num <= 0)
					{
						if (destroyObjects)
						{
							if (objects.TryGetValue(val, out var value) && value.onExplosion(who))
							{
								destroyObject(val, who);
							}
							if (terrainFeatures.TryGetValue(val, out var value2) && value2.performToolAction(null, radius / 2, val))
							{
								terrainFeatures.Remove(val);
							}
						}
						if (Game1.random.NextDouble() < 0.45)
						{
							if (Game1.random.NextBool())
							{
								temporaryAnimatedSpriteList.Add(new TemporaryAnimatedSprite(362, Game1.random.Next(30, 90), 6, 1, new Vector2(val.X * 64f, val.Y * 64f), flicker: false, Game1.random.NextBool())
								{
									delayBeforeAnimationStart = Game1.random.Next(700)
								});
							}
							else
							{
								temporaryAnimatedSpriteList.Add(new TemporaryAnimatedSprite(5, new Vector2(val.X * 64f, val.Y * 64f), Color.White, 8, flipped: false, 50f)
								{
									delayBeforeAnimationStart = Game1.random.Next(200),
									scale = (float)Game1.random.Next(5, 15) / 10f
								});
							}
						}
					}
				}
				if (num >= 1)
				{
					explosionAt(val.X, val.Y);
					if (destroyObjects)
					{
						if (objects.TryGetValue(val, out var value3) && value3.onExplosion(who))
						{
							destroyObject(val, who);
						}
						if (terrainFeatures.TryGetValue(val, out var value4) && value4.performToolAction(null, radius / 2, val))
						{
							terrainFeatures.Remove(val);
						}
					}
					if (Game1.random.NextDouble() < 0.45)
					{
						if (Game1.random.NextBool())
						{
							temporaryAnimatedSpriteList.Add(new TemporaryAnimatedSprite(362, Game1.random.Next(30, 90), 6, 1, new Vector2(val.X * 64f, val.Y * 64f), flicker: false, Game1.random.NextBool())
							{
								delayBeforeAnimationStart = Game1.random.Next(700)
							});
						}
						else
						{
							temporaryAnimatedSpriteList.Add(new TemporaryAnimatedSprite(5, new Vector2(val.X * 64f, val.Y * 64f), Color.White, 8, flipped: false, 50f)
							{
								delayBeforeAnimationStart = Game1.random.Next(200),
								scale = (float)Game1.random.Next(5, 15) / 10f
							});
						}
					}
					temporaryAnimatedSpriteList.Add(new TemporaryAnimatedSprite(6, new Vector2(val.X * 64f, val.Y * 64f), Color.White, 8, Game1.random.NextBool(), Vector2.Distance(val, tileLocation) * 20f));
				}
				val.Y += 1f;
				val.Y = Math.Min(map.Layers[0].LayerHeight - 1, Math.Max(0f, val.Y));
			}
			val.X += 1f;
			val.Y = Math.Min(map.Layers[0].LayerWidth - 1, Math.Max(0f, val.X));
			val.Y = tileLocation.Y - (float)radius;
			val.Y = Math.Min(map.Layers[0].LayerHeight - 1, Math.Max(0f, val.Y));
		}
		Game1.multiplayer.broadcastSprites(this, temporaryAnimatedSpriteList);
		radius /= 2;
		circleOutlineGrid = Game1.getCircleOutlineGrid(radius);
		((Vector2)(ref val))._002Ector((float)(int)(tileLocation.X - (float)radius), (float)(int)(tileLocation.Y - (float)radius));
		num = 0;
		for (int k = 0; k < radius * 2 + 1; k++)
		{
			for (int l = 0; l < radius * 2 + 1; l++)
			{
				if (k == 0 || l == 0 || k == radius * 2 || l == radius * 2)
				{
					num = (circleOutlineGrid[k, l] ? 1 : 0);
				}
				else if (circleOutlineGrid[k, l])
				{
					num += ((l <= radius) ? 1 : (-1));
					if (num <= 0 && !objects.ContainsKey(val) && Game1.random.NextDouble() < 0.9 && !isTileHoeDirt(val) && makeHoeDirt(val))
					{
						checkForBuriedItem((int)val.X, (int)val.Y, explosion: true, detectOnly: false, who);
					}
				}
				if (num >= 1 && !objects.ContainsKey(val) && Game1.random.NextDouble() < 0.9 && !isTileHoeDirt(val) && makeHoeDirt(val))
				{
					checkForBuriedItem((int)val.X, (int)val.Y, explosion: true, detectOnly: false, who);
				}
				val.Y += 1f;
				val.Y = Math.Min(map.Layers[0].LayerHeight - 1, Math.Max(0f, val.Y));
			}
			val.X += 1f;
			val.Y = Math.Min(map.Layers[0].LayerWidth - 1, Math.Max(0f, val.X));
			val.Y = tileLocation.Y - (float)radius;
			val.Y = Math.Min(map.Layers[0].LayerHeight - 1, Math.Max(0f, val.Y));
		}
	}

	public virtual void explosionAt(float x, float y)
	{
	}

	public void removeTemporarySpritesWithID(int id)
	{
		removeTemporarySpritesWithIDEvent.Fire(id);
	}

	public void removeTemporarySpritesWithIDLocal(int id)
	{
		temporarySprites.RemoveWhere(delegate(TemporaryAnimatedSprite sprite)
		{
			if (sprite.id == id)
			{
				if (sprite.hasLit)
				{
					Utility.removeLightSource(sprite.lightId);
				}
				return true;
			}
			return false;
		});
	}

	public bool makeHoeDirt(Vector2 tileLocation, bool ignoreChecks = false)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if (ignoreChecks || (doesTileHaveProperty((int)tileLocation.X, (int)tileLocation.Y, "Diggable", "Back") != null && !IsTileBlockedBy(tileLocation, ~(CollisionMask.Characters | CollisionMask.Farmers))))
		{
			MineShaft obj = this as MineShaft;
			if (obj == null || obj.getMineArea() != 77377)
			{
				return terrainFeatures.TryAdd(tileLocation, new HoeDirt((IsRainingHere() && isOutdoors.Value) ? 1 : 0, this));
			}
		}
		return false;
	}

	public int numberOfObjectsOfType(string itemId, bool bigCraftable)
	{
		int num = 0;
		string typeId = (bigCraftable ? "(BC)" : "(O)");
		foreach (Object value in Objects.Values)
		{
			if (value.HasTypeId(typeId) && value.ItemId == itemId)
			{
				num++;
			}
		}
		return num;
	}

	public virtual void timeUpdate(int timeElapsed)
	{
		if (Game1.IsMasterGame)
		{
			foreach (FarmAnimal value in animals.Values)
			{
				value.updatePerTenMinutes(Game1.timeOfDay, this);
			}
		}
		foreach (Building building in buildings)
		{
			if (building.daysOfConstructionLeft.Value > 0)
			{
				continue;
			}
			building.performTenMinuteAction(timeElapsed);
			if (building.GetIndoorsType() != IndoorsType.Instanced)
			{
				continue;
			}
			GameLocation indoors = building.GetIndoors();
			if (indoors == null)
			{
				continue;
			}
			foreach (FarmAnimal value2 in indoors.animals.Values)
			{
				value2.updatePerTenMinutes(Game1.timeOfDay, indoors);
			}
			if (timeElapsed >= 10)
			{
				indoors.performTenMinuteUpdate(Game1.timeOfDay);
				if (timeElapsed > 10)
				{
					indoors.passTimeForObjects(timeElapsed - 10);
				}
			}
		}
	}

	public void passTimeForObjects(int timeElapsed)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		objects.Lock();
		foreach (KeyValuePair<Vector2, Object> pair in objects.Pairs)
		{
			if (pair.Value.minutesElapsed(timeElapsed))
			{
				Vector2 key = pair.Key;
				objects.Remove(key);
			}
		}
		objects.Unlock();
	}

	public virtual void performTenMinuteUpdate(int timeOfDay)
	{
		//IL_063e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0648: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < furniture.Count; i++)
		{
			furniture[i].minutesElapsed(10);
		}
		for (int j = 0; j < characters.Count; j++)
		{
			NPC nPC = characters[j];
			if (!nPC.IsInvisible)
			{
				nPC.checkSchedule(timeOfDay);
				nPC.performTenMinuteUpdate(timeOfDay, this);
			}
		}
		passTimeForObjects(10);
		if (isOutdoors.Value)
		{
			Random random = Utility.CreateDaySaveRandom(timeOfDay, Map.Layers[0].LayerWidth);
			if (Equals(Game1.currentLocation))
			{
				tryToAddCritters(onlyIfOnScreen: true);
			}
			if (Game1.IsMasterGame)
			{
				int num = Utility.CalculateMinutesBetweenTimes(fishSplashPointTime, Game1.timeOfDay);
				bool flag = fishFrenzyFish.Value != null && !fishFrenzyFish.Value.Equals("");
				Point value = fishSplashPoint.Value;
				if (((Point)(ref value)).Equals(Point.Zero) && random.NextBool() && (!(this is Farm) || Game1.whichFarm == 1))
				{
					Point val = default(Point);
					for (int k = 0; k < 2; k++)
					{
						((Point)(ref val))._002Ector(random.Next(0, map.RequireLayer("Back").LayerWidth), random.Next(0, map.RequireLayer("Back").LayerHeight));
						if (!isOpenWater(val.X, val.Y) || doesTileHaveProperty(val.X, val.Y, "NoFishing", "Back") != null)
						{
							continue;
						}
						int num2 = FishingRod.distanceToLand(val.X, val.Y, this);
						if (num2 <= 1 || num2 >= 5)
						{
							continue;
						}
						if (Game1.player.currentLocation.Equals(this))
						{
							playSound("waterSlosh");
						}
						if (random.NextDouble() < ((this is Beach) ? 0.008 : 0.01) && Game1.Date.TotalDays > 3 && (this is Town || this is Mountain || this is Forest || this is Beach) && Game1.timeOfDay < 2300 && (Game1.player.fishCaught.Count() > 2 || Game1.Date.TotalDays > 14) && !Utility.isFestivalDay())
						{
							Item fish = getFish(random.Next(500), "", num2, Game1.player, 0.0, Utility.PointToVector2(val));
							if (fish.Category == -4 && !fish.HasContextTag("fish_legendary"))
							{
								fishFrenzyFish.Value = fish.QualifiedItemId;
								string text = ((this is Mountain) ? "mountain" : ((this is Forest) ? "forest" : ((!(this is Town)) ? "beach" : "town")));
								string text2 = TokenStringBuilder.ItemNameFor(fish);
								string text3 = TokenStringBuilder.CapitalizeFirstLetter(TokenStringBuilder.ArticleFor(text2));
								Game1.multiplayer.broadcastGlobalMessage("Strings\\1_6_Strings:FishFrenzy_" + text, false, null, text2, text3);
							}
						}
						fishSplashPointTime = Game1.timeOfDay;
						fishSplashPoint.Value = val;
						break;
					}
				}
				else
				{
					value = fishSplashPoint.Value;
					if (!((Point)(ref value)).Equals(Point.Zero) && random.NextDouble() < 0.1 + (double)((float)num / 1800f) && num > (flag ? 120 : 60))
					{
						fishSplashPointTime = 0;
						fishFrenzyFish.Value = "";
						fishSplashPoint.Value = Point.Zero;
					}
				}
				performOrePanTenMinuteUpdate(random);
			}
		}
		if (Game1.dayOfMonth % 7 == 0 && Game1.timeOfDay >= 1200 && Game1.timeOfDay <= 1500 && name.Equals("Saloon") && NetWorldState.checkAnywhereForWorldStateID("saloonSportsRoom"))
		{
			if (Game1.timeOfDay == 1500)
			{
				removeTemporarySpritesWithID(2400);
			}
			else
			{
				bool flag2 = Game1.random.NextDouble() < 0.25;
				bool flag3 = Game1.random.NextDouble() < 0.25;
				List<NPC> list = new List<NPC>();
				foreach (NPC character in characters)
				{
					if (character.TilePoint.Y < 12 && character.TilePoint.X > 26 && Game1.random.NextDouble() < ((flag2 || flag3) ? 0.66 : 0.25))
					{
						list.Add(character);
					}
				}
				foreach (NPC item in list)
				{
					item.showTextAboveHead(Game1.content.LoadString("Strings\\Characters:Saloon_" + (flag2 ? "goodEvent" : (flag3 ? "badEvent" : "neutralEvent")) + "_" + Game1.random.Next(5)));
					if (flag2 && Game1.random.NextDouble() < 0.55)
					{
						item.jump();
					}
				}
			}
		}
		if (Game1.currentLocation.Equals(this) && name.Equals("BugLand") && Game1.random.NextDouble() <= 0.2)
		{
			characters.Add(new Fly(getRandomTile() * 64f, hard: true));
		}
	}

	public virtual bool performOrePanTenMinuteUpdate(Random r)
	{
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		Point value;
		if (Game1.MasterPlayer.mailReceived.Contains("ccFishTank") && !(this is Beach))
		{
			value = orePanPoint.Value;
			if (((Point)(ref value)).Equals(Point.Zero) && r.NextBool())
			{
				Point val = default(Point);
				for (int i = 0; i < 8; i++)
				{
					((Point)(ref val))._002Ector(r.Next(0, Map.RequireLayer("Back").LayerWidth), r.Next(0, Map.RequireLayer("Back").LayerHeight));
					if (isOpenWater(val.X, val.Y) && FishingRod.distanceToLand(val.X, val.Y, this, landMustBeAdjacentToWalkableTile: true) <= 1 && !hasTileAt(val, "Buildings"))
					{
						if (Game1.player.currentLocation.Equals(this))
						{
							playSound("slosh");
						}
						orePanPoint.Value = val;
						return true;
					}
				}
				goto IL_0152;
			}
		}
		value = orePanPoint.Value;
		if (!((Point)(ref value)).Equals(Point.Zero) && r.NextDouble() < 0.1)
		{
			orePanPoint.Value = Point.Zero;
		}
		goto IL_0152;
		IL_0152:
		return false;
	}

	public virtual IList<string> GetCrabPotFishForTile(Vector2 tile)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if (catchOceanCrabPotFishFromThisSpot((int)tile.X, (int)tile.Y))
		{
			return OceanCrabPotFishTypes;
		}
		if (TryGetFishAreaForTile(tile, out var _, out var data))
		{
			List<string> crabPotFishTypes = data.CrabPotFishTypes;
			if (crabPotFishTypes != null && crabPotFishTypes.Count > 0)
			{
				return data.CrabPotFishTypes;
			}
		}
		return DefaultCrabPotFishTypes;
	}

	public virtual bool TryGetFishAreaForTile(Vector2 tile, out string id, out FishAreaData data)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		LocationData data2 = GetData();
		if (data2?.FishAreas != null)
		{
			string text = null;
			FishAreaData val = null;
			foreach (KeyValuePair<string, FishAreaData> fishArea in data2.FishAreas)
			{
				FishAreaData value = fishArea.Value;
				Rectangle? position = value.Position;
				bool? obj;
				if (!position.HasValue)
				{
					obj = null;
				}
				else
				{
					Rectangle valueOrDefault = position.GetValueOrDefault();
					obj = ((Rectangle)(ref valueOrDefault)).Contains((int)tile.X, (int)tile.Y);
				}
				bool? flag = obj;
				if (flag.HasValue)
				{
					if (flag == true)
					{
						id = fishArea.Key;
						data = value;
						return true;
					}
				}
				else if (text == null)
				{
					text = fishArea.Key;
					val = fishArea.Value;
				}
			}
			if (text != null)
			{
				id = text;
				data = val;
				return true;
			}
		}
		id = null;
		data = null;
		return false;
	}

	public virtual string GetFishingAreaDisplayName(string id)
	{
		LocationData data = GetData();
		if (data?.FishAreas == null || !data.FishAreas.TryGetValue(id, out var value) || value.DisplayName == null)
		{
			return null;
		}
		return TokenParser.ParseText(value.DisplayName);
	}

	public virtual Item getFish(float millisecondsAfterNibble, string bait, int waterDepth, Farmer who, double baitPotency, Vector2 bobberTile, string locationName = null)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		if (locationName != null && locationName != Name && (!(locationName == "UndergroundMine") || !(this is MineShaft)))
		{
			GameLocation locationFromName = Game1.getLocationFromName(locationName);
			if (locationFromName != null && locationFromName != this)
			{
				return locationFromName.getFish(millisecondsAfterNibble, bait, waterDepth, who, baitPotency, bobberTile);
			}
		}
		if (bobberTile != Vector2.Zero && who.currentLocation?.NameOrUniqueName == NameOrUniqueName)
		{
			foreach (Building building in buildings)
			{
				if (building is FishPond fishPond && fishPond.isTileFishable(bobberTile))
				{
					return fishPond.CatchFish();
				}
			}
		}
		if (fishFrenzyFish.Value != null && !fishFrenzyFish.Value.Equals("") && Vector2.Distance(bobberTile, Utility.PointToVector2(fishSplashPoint.Value)) <= 2f)
		{
			return ItemRegistry.Create(fishFrenzyFish.Value);
		}
		bool isTutorialCatch = who.fishCaught.Length == 0;
		return GetFishFromLocationData(Name, bobberTile, waterDepth, who, isTutorialCatch, isInherited: false, this) ?? ItemRegistry.Create("(O)168");
	}

	public static Item GetFishFromLocationData(string locationName, Vector2 bobberTile, int waterDepth, Farmer player, bool isTutorialCatch, bool isInherited, GameLocation location = null)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return GetFishFromLocationData(locationName, bobberTile, waterDepth, player, isTutorialCatch, isInherited, location, null);
	}

	internal static Item GetFishFromLocationData(string locationName, Vector2 bobberTile, int waterDepth, Farmer player, bool isTutorialCatch, bool isInherited, GameLocation location, ItemQueryContext itemQueryContext)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0323: Unknown result type (might be due to invalid IL or missing references)
		if (location == null)
		{
			location = Game1.getLocationFromName(locationName);
		}
		LocationData val = ((location != null) ? location.GetData() : GetData(locationName));
		Dictionary<string, string> allFishData = DataLoader.Fish(Game1.content);
		Season seasonForLocation = Game1.GetSeasonForLocation(location);
		if (location == null || !location.TryGetFishAreaForTile(bobberTile, out var id, out var _))
		{
			id = null;
		}
		bool flag = false;
		bool flag2 = false;
		string text = null;
		bool flag3 = false;
		if (player?.CurrentTool is FishingRod { isFishing: not false } fishingRod)
		{
			flag = fishingRod.HasMagicBait();
			flag2 = fishingRod.HasCuriosityLure();
			Object bait = fishingRod.GetBait();
			if (bait != null)
			{
				if (bait.QualifiedItemId == "(O)SpecificBait" && bait.preservedParentSheetIndex.Value != null)
				{
					text = "(O)" + bait.preservedParentSheetIndex.Value;
				}
				if (bait.QualifiedItemId != "(O)685")
				{
					flag3 = true;
				}
			}
		}
		Point tilePoint = player.TilePoint;
		if (itemQueryContext == null)
		{
			itemQueryContext = new ItemQueryContext(location, null, Game1.random, "location '" + locationName + "' > fish data");
		}
		IEnumerable<SpawnFishData> enumerable = Game1.locationData["Default"].Fish;
		if (val != null && val.Fish?.Count > 0)
		{
			enumerable = enumerable.Concat(val.Fish);
		}
		enumerable = from p in enumerable
			orderby p.Precedence, Game1.random.Next()
			select p;
		int num = 0;
		HashSet<string> ignoreQueryKeys = (flag ? GameStateQuery.MagicBaitIgnoreQueryKeys : null);
		Item item = null;
		for (int num2 = 0; num2 < 2; num2++)
		{
			foreach (SpawnFishData spawn in enumerable)
			{
				if ((isInherited && !spawn.CanBeInherited) || (spawn.FishAreaId != null && id != spawn.FishAreaId) || (spawn.Season.HasValue && !flag && spawn.Season != (Season?)seasonForLocation))
				{
					continue;
				}
				Rectangle? playerPosition = spawn.PlayerPosition;
				Rectangle valueOrDefault;
				if (playerPosition.HasValue)
				{
					valueOrDefault = playerPosition.GetValueOrDefault();
					if (!((Rectangle)(ref valueOrDefault)).Contains(tilePoint.X, tilePoint.Y))
					{
						continue;
					}
				}
				playerPosition = spawn.BobberPosition;
				if (playerPosition.HasValue)
				{
					valueOrDefault = playerPosition.GetValueOrDefault();
					if (!((Rectangle)(ref valueOrDefault)).Contains((int)bobberTile.X, (int)bobberTile.Y))
					{
						continue;
					}
				}
				if (player.FishingLevel < spawn.MinFishingLevel || waterDepth < spawn.MinDistanceFromShore || (spawn.MaxDistanceFromShore > -1 && waterDepth > spawn.MaxDistanceFromShore) || (spawn.RequireMagicBait && !flag))
				{
					continue;
				}
				float chance = spawn.GetChance(flag2, player.DailyLuck, player.LuckLevel, (Func<float, IList<QuantityModifier>, QuantityModifierMode, float>)((float value2, IList<QuantityModifier> modifiers, QuantityModifierMode mode) => Utility.ApplyQuantityModifiers(value2, modifiers, mode, location)), ((GenericSpawnItemData)spawn).ItemId == text);
				if (spawn.UseFishCaughtSeededRandom)
				{
					if (!Utility.CreateRandom(Game1.uniqueIDForThisGame, player.stats.Get("PreciseFishCaught") * 859).NextBool(chance))
					{
						continue;
					}
				}
				else if (!Game1.random.NextBool(chance))
				{
					continue;
				}
				if (((GenericSpawnItemDataWithCondition)spawn).Condition != null && !GameStateQuery.CheckConditions(((GenericSpawnItemDataWithCondition)spawn).Condition, location, null, null, null, null, ignoreQueryKeys))
				{
					continue;
				}
				Item item2 = ItemQueryResolver.TryResolveRandomItem((ISpawnItemData)(object)spawn, itemQueryContext, avoidRepeat: false, null, (string query) => query.Replace("BOBBER_X", ((int)bobberTile.X).ToString()).Replace("BOBBER_Y", ((int)bobberTile.Y).ToString()).Replace("WATER_DEPTH", waterDepth.ToString()), null, delegate(string query, string error)
				{
					Game1.log.Error($"Location '{location.NameOrUniqueName}' failed parsing item query '{query}' for fish '{((GenericSpawnItemData)spawn).Id}': {error}");
				});
				if (item2 == null)
				{
					continue;
				}
				if (!string.IsNullOrWhiteSpace(spawn.SetFlagOnCatch))
				{
					item2.SetFlagOnPickup = spawn.SetFlagOnCatch;
				}
				if (spawn.IsBossFish)
				{
					item2.SetTempData("IsBossFish", value: true);
				}
				Item item3 = item2;
				if ((spawn.CatchLimit <= -1 || !player.fishCaught.TryGetValue(item3.QualifiedItemId, out var value) || value[0] < spawn.CatchLimit) && CheckGenericFishRequirements(item3, allFishData, location, player, spawn, waterDepth, flag, flag2, ((GenericSpawnItemData)spawn).ItemId == text, isTutorialCatch))
				{
					if (text == null || !(item3.QualifiedItemId != text) || num >= 2)
					{
						return item3;
					}
					if (item == null)
					{
						item = item3;
					}
					num++;
				}
			}
			if (!flag3)
			{
				num2++;
			}
		}
		if (item != null)
		{
			return item;
		}
		if (!isTutorialCatch)
		{
			return null;
		}
		return ItemRegistry.Create("(O)145");
	}

	internal static bool CheckGenericFishRequirements(Item fish, Dictionary<string, string> allFishData, GameLocation location, Farmer player, SpawnFishData spawn, int waterDepth, bool usingMagicBait, bool hasCuriosityLure, bool usingTargetBait, bool isTutorialCatch)
	{
		//IL_0338: Unknown result type (might be due to invalid IL or missing references)
		if (!fish.HasTypeObject() || !allFishData.TryGetValue(fish.ItemId, out var value))
		{
			return !isTutorialCatch;
		}
		string[] array = value.Split('/');
		if (ArgUtility.Get(array, 1) == "trap")
		{
			return !isTutorialCatch;
		}
		bool flag = player?.CurrentTool?.QualifiedItemId == "(T)TrainingRod";
		if (flag)
		{
			bool? canUseTrainingRod = spawn.CanUseTrainingRod;
			if (canUseTrainingRod.HasValue)
			{
				if (canUseTrainingRod != true)
				{
					return false;
				}
			}
			else
			{
				if (!ArgUtility.TryGetInt(array, 1, out var value2, out var error, "int difficulty"))
				{
					return LogFormatError(error);
				}
				if (value2 >= 50)
				{
					return false;
				}
			}
		}
		if (isTutorialCatch)
		{
			if (!ArgUtility.TryGetOptionalBool(array, 13, out var value3, out var error2, defaultValue: false, "bool isTutorialFish"))
			{
				return LogFormatError(error2);
			}
			if (!value3)
			{
				return false;
			}
		}
		if (!spawn.IgnoreFishDataRequirements)
		{
			if (!usingMagicBait)
			{
				if (!ArgUtility.TryGet(array, 5, out var value4, out var error3, allowBlank: true, "string rawTimeSpans"))
				{
					return LogFormatError(error3);
				}
				string[] array2 = ArgUtility.SplitBySpace(value4);
				bool flag2 = false;
				for (int i = 0; i < array2.Length; i += 2)
				{
					if (!ArgUtility.TryGetInt(array2, i, out var value5, out error3, "int startTime") || !ArgUtility.TryGetInt(array2, i + 1, out var value6, out error3, "int endTime"))
					{
						return LogFormatError("invalid time spans '" + value4 + "': " + error3);
					}
					if (Game1.timeOfDay >= value5 && Game1.timeOfDay < value6)
					{
						flag2 = true;
						break;
					}
				}
				if (!flag2)
				{
					return false;
				}
			}
			if (!usingMagicBait)
			{
				if (!ArgUtility.TryGet(array, 7, out var value7, out var error4, allowBlank: true, "string weather"))
				{
					return LogFormatError(error4);
				}
				if (!(value7 == "rainy"))
				{
					if (value7 == "sunny" && location.IsRainingHere())
					{
						return false;
					}
				}
				else if (!location.IsRainingHere())
				{
					return false;
				}
			}
			if (!ArgUtility.TryGetInt(array, 12, out var value8, out var error5, "int minFishingLevel"))
			{
				return LogFormatError(error5);
			}
			if (player.FishingLevel < value8)
			{
				return false;
			}
			if (!ArgUtility.TryGetInt(array, 9, out var value9, out var error6, "int maxDepth") || !ArgUtility.TryGetFloat(array, 10, out var value10, out error6, "float chance") || !ArgUtility.TryGetFloat(array, 11, out var value11, out error6, "float depthMultiplier"))
			{
				return LogFormatError(error6);
			}
			float num = value11 * value10;
			value10 -= (float)Math.Max(0, value9 - waterDepth) * num;
			value10 += (float)player.FishingLevel / 50f;
			if (flag)
			{
				value10 *= 1.1f;
			}
			value10 = Math.Min(value10, 0.9f);
			if ((double)value10 < 0.25 && hasCuriosityLure)
			{
				if (spawn.CuriosityLureBuff > -1f)
				{
					value10 += spawn.CuriosityLureBuff;
				}
				else
				{
					float num2 = 0.25f;
					float num3 = 0.08f;
					value10 = (num2 - num3) / num2 * value10 + (num2 - num3) / 2f;
				}
			}
			if (usingTargetBait)
			{
				value10 *= 1.66f;
			}
			if (spawn.ApplyDailyLuck)
			{
				value10 += (float)player.DailyLuck;
			}
			List<QuantityModifier> chanceModifiers = spawn.ChanceModifiers;
			if (chanceModifiers != null && chanceModifiers.Count > 0)
			{
				value10 = Utility.ApplyQuantityModifiers(value10, spawn.ChanceModifiers, spawn.ChanceModifierMode, location);
			}
			if (!Game1.random.NextBool(value10))
			{
				return false;
			}
		}
		return true;
		bool LogFormatError(string text)
		{
			Game1.log.Warn("Skipped fish '" + fish.ItemId + "' due to invalid requirements in Data/Fish: " + text);
			return false;
		}
	}

	public virtual bool isActionableTile(int xTile, int yTile, Farmer who)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		foreach (Building building in buildings)
		{
			if (building.isActionableTile(xTile, yTile, who))
			{
				return true;
			}
		}
		bool flag = false;
		string[] array = ArgUtility.SplitBySpace(doesTileHaveProperty(xTile, yTile, "Action", "Buildings"));
		if (!ShouldIgnoreAction(array, who, new Location(xTile, yTile)))
		{
			switch (array[0])
			{
			case "Dialogue":
			case "Message":
			case "MessageOnce":
			case "NPCMessage":
				flag = true;
				Game1.isInspectionAtCurrentCursorTile = true;
				break;
			case "MessageSpeech":
				flag = true;
				Game1.isSpeechAtCurrentCursorTile = true;
				break;
			default:
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			if (objects.TryGetValue(new Vector2((float)xTile, (float)yTile), out var value) && value.isActionable(who))
			{
				flag = true;
			}
			if (!Game1.isFestival() && terrainFeatures.TryGetValue(new Vector2((float)xTile, (float)yTile), out var value2) && value2.isActionable())
			{
				flag = true;
			}
		}
		if (flag && !Utility.tileWithinRadiusOfPlayer(xTile, yTile, 1, who))
		{
			Game1.mouseCursorTransparency = 0.5f;
		}
		return flag;
	}

	public Item tryGetRandomArtifactFromThisLocation(Farmer who, Random r, double chanceMultipler = 1.0)
	{
		LocationData data = GetData();
		ItemQueryContext context = new ItemQueryContext(this, who, r, "location '" + NameOrUniqueName + "' > artifact spots");
		IEnumerable<ArtifactSpotDropData> enumerable = Game1.locationData["Default"].ArtifactSpots;
		if (data != null && data.ArtifactSpots?.Count > 0)
		{
			enumerable = enumerable.Concat(data.ArtifactSpots);
		}
		enumerable = enumerable.OrderBy((ArtifactSpotDropData p) => p.Precedence);
		foreach (ArtifactSpotDropData drop in enumerable)
		{
			if (r.NextBool(drop.Chance * chanceMultipler) && (((GenericSpawnItemDataWithCondition)drop).Condition == null || GameStateQuery.CheckConditions(((GenericSpawnItemDataWithCondition)drop).Condition, this, who, null, null, r)))
			{
				Item item = ItemQueryResolver.TryResolveRandomItem((ISpawnItemData)(object)drop, context, avoidRepeat: false, null, null, null, delegate(string query, string error)
				{
					Game1.log.Error($"Location '{NameOrUniqueName}' failed parsing item query '{query}' for artifact spot '{((GenericSpawnItemData)drop).Id}': {error}");
				});
				if (item != null)
				{
					return item;
				}
			}
		}
		return null;
	}

	public virtual void digUpArtifactSpot(int xLocation, int yLocation, Farmer who)
	{
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		Random random = Utility.CreateDaySaveRandom(xLocation * 2000, yLocation, Game1.netWorldState.Value.TreasureTotemsUsed * 777);
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)(xLocation * 64), (float)(yLocation * 64));
		bool flag = (who?.CurrentTool as Hoe)?.hasEnchantmentOfType<GenerousEnchantment>() ?? false;
		LocationData data = GetData();
		ItemQueryContext context = new ItemQueryContext(this, who, random, "location '" + NameOrUniqueName + "' > artifact spots");
		IEnumerable<ArtifactSpotDropData> enumerable = Game1.locationData["Default"].ArtifactSpots;
		if (data != null && data.ArtifactSpots?.Count > 0)
		{
			enumerable = enumerable.Concat(data.ArtifactSpots);
		}
		enumerable = enumerable.OrderBy((ArtifactSpotDropData p) => p.Precedence);
		if (Game1.player.mailReceived.Contains("sawQiPlane") && random.NextDouble() < 0.05 + Game1.player.team.AverageDailyLuck() / 2.0)
		{
			Game1.createMultipleItemDebris(ItemRegistry.Create("(O)MysteryBox", random.Next(1, 3)), val, -1, this);
		}
		Utility.trySpawnRareObject(who, val, this, 9.0, 1.0, -1, random);
		foreach (ArtifactSpotDropData drop in enumerable)
		{
			if (!random.NextBool(drop.Chance) || (((GenericSpawnItemDataWithCondition)drop).Condition != null && !GameStateQuery.CheckConditions(((GenericSpawnItemDataWithCondition)drop).Condition, this, who, null, null, random)))
			{
				continue;
			}
			Item item = ItemQueryResolver.TryResolveRandomItem((ISpawnItemData)(object)drop, context, avoidRepeat: false, null, null, null, delegate(string query, string error)
			{
				Game1.log.Error($"Location '{NameOrUniqueName}' failed parsing item query '{query}' for artifact spot '{((GenericSpawnItemData)drop).Id}': {error}");
			});
			if (item == null)
			{
				continue;
			}
			if (drop.OneDebrisPerDrop && item.Stack > 1)
			{
				Game1.createMultipleItemDebris(item, val, -1, this);
			}
			else
			{
				Game1.createItemDebris(item, val, Game1.random.Next(4), this);
			}
			if (flag && drop.ApplyGenerousEnchantment && random.NextBool())
			{
				item = item.getOne();
				item = (Item)ItemQueryResolver.ApplyItemFields(item, (ISpawnItemData)(object)drop, context);
				if (drop.OneDebrisPerDrop && item.Stack > 1)
				{
					Game1.createMultipleItemDebris(item, val, -1, this);
				}
				else
				{
					Game1.createItemDebris(item, val, -1, this);
				}
			}
			if (!drop.ContinueOnDrop)
			{
				break;
			}
		}
	}

	public LocationData GetData()
	{
		string text = Name;
		if (!(this is MineShaft))
		{
			if (this is Cellar && text.StartsWith("Cellar"))
			{
				text = "Cellar";
			}
		}
		else
		{
			text = "UndergroundMine";
		}
		return GetData(text);
	}

	public static LocationData GetData(string name)
	{
		IDictionary<string, LocationData> rawData = Game1.locationData;
		if (name == "Farm")
		{
			return GetImpl("Farm_" + Game1.GetFarmTypeKey()) ?? GetImpl("Farm_Standard");
		}
		return GetImpl(name);
		LocationData GetImpl(string entryName)
		{
			if (rawData.TryGetValue(entryName, out var value))
			{
				return value;
			}
			foreach (string activePassiveFestival in Game1.netWorldState.Value.ActivePassiveFestivals)
			{
				if (Utility.TryGetPassiveFestivalData(activePassiveFestival, out var data) && data.MapReplacements != null)
				{
					foreach (KeyValuePair<string, string> mapReplacement in data.MapReplacements)
					{
						if (mapReplacement.Value == entryName)
						{
							if (!rawData.TryGetValue(mapReplacement.Key, out value))
							{
								break;
							}
							return value;
						}
					}
				}
			}
			return null;
		}
	}

	public virtual bool ShouldExcludeFromNpcPathfinding()
	{
		return GetData()?.ExcludeFromNpcPathfinding ?? false;
	}

	public virtual string checkForBuriedItem(int xLocation, int yLocation, bool explosion, bool detectOnly, Farmer who)
	{
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Invalid comparison between Unknown and I4
		Random random = Utility.CreateDaySaveRandom(xLocation * 2000, yLocation * 77, Game1.stats.DirtHoed);
		string text = HandleTreasureTileProperty(xLocation, yLocation, detectOnly);
		if (text != null)
		{
			return text;
		}
		bool flag = who?.CurrentTool is Hoe && who.CurrentTool.hasEnchantmentOfType<GenerousEnchantment>();
		float num = 0.5f;
		if (!isFarm.Value && isOutdoors.Value && (int)GetSeason() == 3 && random.NextDouble() < 0.08 && !explosion && !detectOnly && !(this is Desert))
		{
			Game1.createObjectDebris(random.Choose("(O)412", "(O)416"), xLocation, yLocation);
			if (flag && random.NextDouble() < (double)num)
			{
				Game1.createObjectDebris(random.Choose("(O)412", "(O)416"), xLocation, yLocation);
			}
			return "";
		}
		LocationData data = GetData();
		if (isOutdoors.Value && random.NextBool(data?.ChanceForClay ?? 0.03) && !explosion)
		{
			if (detectOnly)
			{
				((IDictionary<string, PropertyValue>)((Component)map.RequireLayer("Back").Tiles[xLocation, yLocation]).Properties).Add("Treasure", PropertyValue.op_Implicit("Item (O)330"));
				return "Item";
			}
			Game1.createObjectDebris("(O)330", xLocation, yLocation);
			if (flag && random.NextDouble() < (double)num)
			{
				Game1.createObjectDebris("(O)330", xLocation, yLocation);
			}
			return "";
		}
		return "";
	}

	private string HandleTreasureTileProperty(int xLocation, int yLocation, bool detectOnly)
	{
		//IL_0380: Unknown result type (might be due to invalid IL or missing references)
		string text = doesTileHaveProperty(xLocation, yLocation, "Treasure", "Back");
		if (text == null)
		{
			return null;
		}
		string[] array = ArgUtility.SplitBySpace(text);
		if (!ArgUtility.TryGet(array, 0, out var value, out var error, allowBlank: true, "string type"))
		{
			LogError(text, error);
			return null;
		}
		if (detectOnly)
		{
			return value;
		}
		switch (value)
		{
		case "Arch":
		{
			if (ArgUtility.TryGet(array, 1, out var value3, out error, allowBlank: true, "string itemId"))
			{
				Game1.createObjectDebris(value3, xLocation, yLocation);
			}
			else
			{
				LogError(text, error);
			}
			break;
		}
		case "CaveCarrot":
			Game1.createObjectDebris("(O)78", xLocation, yLocation);
			break;
		case "Coins":
			Game1.createObjectDebris("(O)330", xLocation, yLocation);
			break;
		case "Coal":
		case "Gold":
		case "Iron":
		case "Copper":
		case "Iridium":
		{
			int debrisType = value switch
			{
				"Coal" => 4, 
				"Copper" => 0, 
				"Gold" => 6, 
				"Iridium" => 10, 
				_ => 2, 
			};
			if (ArgUtility.TryGetInt(array, 1, out var value5, out error, "int itemId"))
			{
				Game1.createDebris(debrisType, xLocation, yLocation, value5);
			}
			else
			{
				LogError(text, error);
			}
			break;
		}
		case "Object":
		{
			if (ArgUtility.TryGet(array, 1, out var value4, out error, allowBlank: true, "string itemId"))
			{
				Game1.createObjectDebris(value4, xLocation, yLocation);
				if (value4 == "78" || value4 == "(O)79")
				{
					Game1.stats.CaveCarrotsFound++;
				}
			}
			else
			{
				LogError(text, error);
			}
			break;
		}
		case "Item":
		{
			if (ArgUtility.TryGet(array, 1, out var value2, out error, allowBlank: true, "string itemId"))
			{
				Item item = ItemRegistry.Create(value2);
				Game1.createItemDebris(item, new Vector2((float)xLocation, (float)yLocation), -1, this);
				if (item.QualifiedItemId == "(O)78")
				{
					Game1.stats.CaveCarrotsFound++;
				}
			}
			else
			{
				LogError(text, error);
			}
			break;
		}
		default:
			value = null;
			LogError(text, "invalid treasure type '" + value + "'");
			break;
		}
		((IDictionary<string, PropertyValue>)((Component)map.RequireLayer("Back").Tiles[xLocation, yLocation]).Properties)["Treasure"] = null;
		return value;
		void LogError(string value6, string errorPhrase)
		{
			LogTilePropertyError("Treasure", "Back", xLocation, yLocation, value6, errorPhrase);
		}
	}

	public virtual bool AllowMapModificationsInResetState()
	{
		return false;
	}

	public void removeMapTile(int tileX, int tileY, string layer)
	{
		Layer val = map?.RequireLayer(layer);
		if (((val != null) ? val.Tiles[tileX, tileY] : null) != null)
		{
			val.Tiles[tileX, tileY] = null;
		}
	}

	public StaticTile setMapTile(int tileX, int tileY, int index, string layer, string tileSheetId, string action = null, bool copyProperties = true)
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Expected O, but got Unknown
		//IL_0067: Expected O, but got Unknown
		Layer val = map.RequireLayer(layer);
		Tile val2 = val.Tiles[tileX, tileY];
		StaticTile val3 = (StaticTile)(object)((val2 is StaticTile) ? val2 : null);
		if (val3 != null && ((Component)((Tile)val3).TileSheet).Id == tileSheetId)
		{
			((Tile)val3).TileIndex = index;
		}
		else
		{
			TileArray tiles = val.Tiles;
			StaticTile val4 = new StaticTile(val, map.RequireTileSheet(tileSheetId), (BlendMode)0, index);
			val3 = val4;
			tiles[tileX, tileY] = (Tile)val4;
			if (copyProperties && val2 != null)
			{
				foreach (KeyValuePair<string, PropertyValue> item in (IEnumerable<KeyValuePair<string, PropertyValue>>)((Component)val2).Properties)
				{
					((IDictionary<string, PropertyValue>)((Component)val3).Properties)[item.Key] = item.Value;
				}
			}
		}
		if (action != null && layer == "Buildings")
		{
			((IDictionary<string, PropertyValue>)((Component)val3).Properties)["Action"] = PropertyValue.op_Implicit(action);
		}
		return val3;
	}

	public AnimatedTile setAnimatedMapTile(int tileX, int tileY, int[] animationTileIndexes, long interval, string layer, string tileSheetId, string action = null, bool copyProperties = true)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Expected O, but got Unknown
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		Layer val = map.RequireLayer(layer);
		TileSheet val2 = map.RequireTileSheet(tileSheetId);
		StaticTile[] array = (StaticTile[])(object)new StaticTile[animationTileIndexes.Length];
		for (int i = 0; i < animationTileIndexes.Length; i++)
		{
			array[i] = new StaticTile(val, val2, (BlendMode)0, animationTileIndexes[i]);
		}
		AnimatedTile val3 = new AnimatedTile(val, array, interval);
		if (copyProperties)
		{
			Tile val4 = val.Tiles[tileX, tileY];
			if (val4 != null)
			{
				foreach (KeyValuePair<string, PropertyValue> item in (IEnumerable<KeyValuePair<string, PropertyValue>>)((Component)val4).Properties)
				{
					((IDictionary<string, PropertyValue>)((Component)val3).Properties)[item.Key] = item.Value;
				}
			}
		}
		if (action != null && layer == "Buildings")
		{
			((IDictionary<string, PropertyValue>)((Component)val3).Properties)["Action"] = PropertyValue.op_Implicit(action);
		}
		val.Tiles[tileX, tileY] = (Tile)(object)val3;
		return val3;
	}

	public virtual void shiftContents(int dx, int dy, Func<Vector2, object, bool> where = null)
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)dx, (float)dy);
		List<KeyValuePair<Vector2, Object>> list = new List<KeyValuePair<Vector2, Object>>(objects.Pairs);
		objects.Clear();
		foreach (KeyValuePair<Vector2, Object> item in list)
		{
			if (where == null || where(item.Key, item.Value))
			{
				removeLightSource(item.Value.lightSource?.Id);
				Vector2 val2 = item.Key + val;
				objects.Add(val2, item.Value);
				item.Value.initializeLightSource(val2);
			}
			else
			{
				objects.Add(item.Key, item.Value);
			}
		}
		List<KeyValuePair<Vector2, TerrainFeature>> list2 = new List<KeyValuePair<Vector2, TerrainFeature>>(terrainFeatures.Pairs);
		terrainFeatures.Clear();
		foreach (KeyValuePair<Vector2, TerrainFeature> item2 in list2)
		{
			Vector2 key = ((where == null || where(item2.Key, item2.Value)) ? (item2.Key + val) : item2.Key);
			terrainFeatures.Add(key, item2.Value);
		}
		foreach (LargeTerrainFeature largeTerrainFeature in largeTerrainFeatures)
		{
			if (where == null || where(largeTerrainFeature.Tile, largeTerrainFeature))
			{
				largeTerrainFeature.Tile += val;
			}
		}
		foreach (Furniture item3 in furniture)
		{
			if (where == null || where(item3.TileLocation, item3))
			{
				item3.removeLights();
				item3.TileLocation = new Vector2(item3.TileLocation.X + (float)dx, item3.TileLocation.Y + (float)dy);
				item3.updateDrawPosition();
				if (Game1.isDarkOut(this))
				{
					item3.addLights();
				}
			}
		}
	}

	public void moveFurniture(int oldX, int oldY, int newX, int newY)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector((float)oldX, (float)oldY);
		foreach (Furniture item in furniture)
		{
			if (item.tileLocation.Equals(val))
			{
				item.removeLights();
				item.TileLocation = new Vector2((float)newX, (float)newY);
				if (Game1.isDarkOut(this))
				{
					item.addLights();
				}
				return;
			}
		}
		if (objects.TryGetValue(val, out var value))
		{
			objects.Remove(val);
			objects.Add(new Vector2((float)newX, (float)newY), value);
		}
	}

	public bool hasTileAt(int x, int y, string layer, string tilesheetId = null)
	{
		return map?.HasTileAt(x, y, layer, tilesheetId) ?? false;
	}

	public bool hasTileAt(Location tile, string layer, string tilesheetId = null)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		return map?.HasTileAt(tile.X, tile.Y, layer, tilesheetId) ?? false;
	}

	public bool hasTileAt(Point tile, string layer, string tilesheetId = null)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		return map?.HasTileAt(tile.X, tile.Y, layer, tilesheetId) ?? false;
	}

	public int getTileIndexAt(Location p, string layer, string tilesheetId = null)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		return map?.GetTileIndexAt(p.X, p.Y, layer, tilesheetId) ?? (-1);
	}

	public int getTileIndexAt(Point p, string layer, string tilesheetId = null)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		return map?.GetTileIndexAt(p.X, p.Y, layer, tilesheetId) ?? (-1);
	}

	public int getTileIndexAt(int x, int y, string layer, string tilesheetId = null)
	{
		return map?.GetTileIndexAt(x, y, layer, tilesheetId) ?? (-1);
	}

	public string getTileSheetIDAt(int x, int y, string layer)
	{
		Layer layer2 = map.GetLayer(layer);
		object obj;
		if (layer2 == null)
		{
			obj = null;
		}
		else
		{
			Tile obj2 = layer2.Tiles[x, y];
			obj = ((obj2 != null) ? ((Component)obj2.TileSheet).Id : null);
		}
		if (obj == null)
		{
			obj = "";
		}
		return (string)obj;
	}

	public virtual void OnBuildingConstructed(Building building, Farmer who)
	{
		building.performActionOnConstruction(this, who);
	}

	public virtual void OnBuildingMoved(Building building)
	{
		building.performActionOnBuildingPlacement();
	}

	public virtual void OnBuildingDemolished(string type, Guid id)
	{
		if (type == "Stable")
		{
			Horse mount = Game1.player.mount;
			if (mount != null && mount.HorseId == id)
			{
				Game1.player.mount.dismount(from_demolish: true);
			}
		}
	}

	public virtual void OnDayStarted()
	{
	}

	public void OnStoneDestroyed(string stoneId, int x, int y, Farmer who)
	{
		long whichPlayer = who?.UniqueMultiplayerID ?? 0;
		if (who?.currentLocation is MineShaft { mineLevel: >120 } mineShaft && !mineShaft.isSideBranch())
		{
			int num = mineShaft.mineLevel - 121;
			if (Utility.GetDayOfPassiveFestival("DesertFestival") > 0)
			{
				float num2 = 0.01f;
				num2 += (float)num * 0.0005f;
				if (num2 > 0.5f)
				{
					num2 = 0.5f;
				}
				if (Game1.random.NextBool(num2))
				{
					Game1.createMultipleObjectDebris("CalicoEgg", x, y, Game1.random.Next(1, 4), who.UniqueMultiplayerID, this);
				}
			}
		}
		if (who != null && Game1.random.NextDouble() <= 0.02 && Game1.player.team.SpecialOrderRuleActive("DROP_QI_BEANS"))
		{
			Game1.createMultipleObjectDebris("(O)890", x, y, 1, who.UniqueMultiplayerID, this);
		}
		if (!MineShaft.IsGeneratedLevel(this))
		{
			if (stoneId == "343" || stoneId == "450")
			{
				Random random = Utility.CreateDaySaveRandom(x * 2000, y);
				double num3 = ((who != null && who.hasBuff("dwarfStatue_4")) ? 1.25 : 1.0);
				if (random.NextDouble() < 0.035 * num3 && Game1.stats.DaysPlayed > 1)
				{
					Game1.createObjectDebris("(O)" + (535 + ((Game1.stats.DaysPlayed > 60 && random.NextDouble() < 0.2) ? 1 : ((Game1.stats.DaysPlayed > 120 && random.NextDouble() < 0.2) ? 2 : 0))), x, y, whichPlayer, this);
				}
				int num4 = ((who == null || !who.professions.Contains(21)) ? 1 : 2);
				double num5 = ((who != null && who.hasBuff("dwarfStatue_2")) ? 0.03 : 0.0);
				if (random.NextDouble() < 0.035 * (double)num4 + num5 && Game1.stats.DaysPlayed > 1)
				{
					Game1.createObjectDebris("(O)382", x, y, whichPlayer, this);
				}
				if (random.NextDouble() < 0.01 && Game1.stats.DaysPlayed > 1)
				{
					Game1.createObjectDebris("(O)390", x, y, whichPlayer, this);
				}
			}
			breakStone(stoneId, x, y, who, Utility.CreateDaySaveRandom(x * 4000, y));
		}
		else
		{
			(this as MineShaft).checkStoneForItems(stoneId, x, y, who);
		}
	}

	protected virtual bool breakStone(string stoneId, int x, int y, Farmer who, Random r)
	{
		//IL_08ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a5f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a6f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0951: Unknown result type (might be due to invalid IL or missing references)
		//IL_0957: Unknown result type (might be due to invalid IL or missing references)
		//IL_0961: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af3: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_09de: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b9a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f22: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f9c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fa6: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		int num2 = ((who != null && who.professions.Contains(18)) ? 1 : 0);
		if (who != null && who.hasBuff("dwarfStatue_0"))
		{
			num2++;
		}
		if (stoneId == 44.ToString())
		{
			stoneId = (r.Next(1, 8) * 2).ToString();
		}
		long num3 = who?.UniqueMultiplayerID ?? 0;
		int num4 = who?.LuckLevel ?? 0;
		double num5 = who?.DailyLuck ?? 0.0;
		int num6 = who?.MiningLevel ?? 0;
		switch (stoneId)
		{
		case "95":
			Game1.createMultipleObjectDebris("(O)909", x, y, num2 + r.Next(1, 3) + ((r.NextDouble() < (double)((float)num4 / 100f)) ? 1 : 0) + ((r.NextDouble() < (double)((float)num6 / 200f)) ? 1 : 0), num3, this);
			num = 18;
			break;
		case "843":
		case "844":
			Game1.createMultipleObjectDebris("(O)848", x, y, num2 + r.Next(1, 3) + ((r.NextDouble() < (double)((float)num4 / 100f)) ? 1 : 0) + ((r.NextDouble() < (double)((float)num6 / 200f)) ? 1 : 0), num3, this);
			num = 12;
			break;
		case "25":
			Game1.createMultipleObjectDebris("(O)719", x, y, r.Next(2, 5), num3, this);
			num = 5;
			if (this is IslandLocation && r.NextDouble() < 0.1)
			{
				Game1.player.team.RequestLimitedNutDrops("MusselStone", this, x * 64, y * 64, 5);
			}
			break;
		case "75":
			Game1.createObjectDebris("(O)535", x, y, num3, this);
			num = 8;
			break;
		case "76":
			Game1.createObjectDebris("(O)536", x, y, num3, this);
			num = 16;
			break;
		case "77":
			Game1.createObjectDebris("(O)537", x, y, num3, this);
			num = 32;
			break;
		case "816":
		case "817":
			if (r.NextDouble() < 0.1)
			{
				Game1.createObjectDebris("(O)823", x, y, num3, this);
			}
			else if (r.NextDouble() < 0.015)
			{
				Game1.createObjectDebris("(O)824", x, y, num3, this);
			}
			else if (r.NextDouble() < 0.1)
			{
				Game1.createObjectDebris("(O)" + (579 + r.Next(11)), x, y, num3, this);
			}
			Game1.createMultipleObjectDebris("(O)881", x, y, num2 + r.Next(1, 3) + ((r.NextDouble() < (double)((float)num4 / 100f)) ? 1 : 0) + ((r.NextDouble() < (double)((float)num6 / 100f)) ? 1 : 0), num3, this);
			num = 6;
			break;
		case "818":
			Game1.createMultipleObjectDebris("(O)330", x, y, num2 + r.Next(1, 3) + ((r.NextDouble() < (double)((float)num4 / 100f)) ? 1 : 0) + ((r.NextDouble() < (double)((float)num6 / 100f)) ? 1 : 0), num3, this);
			num = 6;
			break;
		case "819":
			Game1.createObjectDebris("(O)749", x, y, num3, this);
			num = 64;
			break;
		case "8":
			Game1.createMultipleObjectDebris("(O)66", x, y, (who == null || who.stats.Get(StatKeys.Mastery(3)) == 0) ? 1 : 2, num3, this);
			num = 16;
			break;
		case "10":
			Game1.createMultipleObjectDebris("(O)68", x, y, (who == null || who.stats.Get(StatKeys.Mastery(3)) == 0) ? 1 : 2, num3, this);
			num = 16;
			break;
		case "12":
			Game1.createMultipleObjectDebris("(O)60", x, y, (who == null || who.stats.Get(StatKeys.Mastery(3)) == 0) ? 1 : 2, num3, this);
			num = 80;
			break;
		case "14":
			Game1.createMultipleObjectDebris("(O)62", x, y, (who == null || who.stats.Get(StatKeys.Mastery(3)) == 0) ? 1 : 2, num3, this);
			num = 40;
			break;
		case "6":
			Game1.createMultipleObjectDebris("(O)70", x, y, (who == null || who.stats.Get(StatKeys.Mastery(3)) == 0) ? 1 : 2, num3, this);
			num = 40;
			break;
		case "4":
			Game1.createMultipleObjectDebris("(O)64", x, y, (who == null || who.stats.Get(StatKeys.Mastery(3)) == 0) ? 1 : 2, num3, this);
			num = 80;
			break;
		case "2":
			Game1.createMultipleObjectDebris("(O)72", x, y, (who == null || who.stats.Get(StatKeys.Mastery(3)) == 0) ? 1 : 2, num3, this);
			num = 150;
			break;
		case "846":
		case "847":
		case "668":
		case "845":
		case "670":
			Game1.createMultipleObjectDebris("(O)390", x, y, num2 + r.Next(1, 3) + ((r.NextDouble() < (double)((float)num4 / 100f)) ? 1 : 0) + ((r.NextDouble() < (double)((float)num6 / 100f)) ? 1 : 0), num3, this);
			num = 3;
			if (r.NextDouble() < 0.08)
			{
				Game1.createMultipleObjectDebris("(O)382", x, y, 1 + num2, num3, this);
				num = 4;
			}
			break;
		case "849":
		case "751":
			Game1.createMultipleObjectDebris("(O)378", x, y, num2 + r.Next(1, 4) + ((r.NextDouble() < (double)((float)num4 / 100f)) ? 1 : 0) + ((r.NextDouble() < (double)((float)num6 / 100f)) ? 1 : 0), num3, this);
			num = 5;
			Game1.multiplayer.broadcastSprites(this, Utility.sparkleWithinArea(new Rectangle(x * 64, (y - 1) * 64, 32, 96), 3, Color.Orange * 0.5f, 175, 100));
			break;
		case "850":
		case "290":
			Game1.createMultipleObjectDebris("(O)380", x, y, num2 + r.Next(1, 4) + ((r.NextDouble() < (double)((float)num4 / 100f)) ? 1 : 0) + ((r.NextDouble() < (double)((float)num6 / 100f)) ? 1 : 0), num3, this);
			num = 12;
			Game1.multiplayer.broadcastSprites(this, Utility.sparkleWithinArea(new Rectangle(x * 64, (y - 1) * 64, 32, 96), 3, Color.White * 0.5f, 175, 100));
			break;
		case "BasicCoalNode0":
		case "BasicCoalNode1":
		case "VolcanoCoalNode0":
		case "VolcanoCoalNode1":
			Game1.createMultipleObjectDebris("(O)382", x, y, num2 + r.Next(1, 4) + ((r.NextDouble() < (double)((float)num4 / 100f)) ? 1 : 0) + ((r.NextDouble() < (double)((float)num6 / 100f)) ? 1 : 0), num3, this);
			num = 10;
			Game1.multiplayer.broadcastSprites(this, Utility.sparkleWithinArea(new Rectangle(x * 64, (y - 1) * 64, 32, 96), 3, Color.Black * 0.5f, 175, 100));
			break;
		case "764":
		case "VolcanoGoldNode":
			Game1.createMultipleObjectDebris("(O)384", x, y, num2 + r.Next(1, 4) + ((r.NextDouble() < (double)((float)num4 / 100f)) ? 1 : 0) + ((r.NextDouble() < (double)((float)num6 / 100f)) ? 1 : 0), num3, this);
			num = 18;
			Game1.multiplayer.broadcastSprites(this, Utility.sparkleWithinArea(new Rectangle(x * 64, (y - 1) * 64, 32, 96), 3, Color.Yellow * 0.5f, 175, 100));
			break;
		case "765":
			Game1.createMultipleObjectDebris("(O)386", x, y, num2 + r.Next(1, 4) + ((r.NextDouble() < (double)((float)num4 / 100f)) ? 1 : 0) + ((r.NextDouble() < (double)((float)num6 / 100f)) ? 1 : 0), num3, this);
			Game1.multiplayer.broadcastSprites(this, Utility.sparkleWithinArea(new Rectangle(x * 64, (y - 1) * 64, 32, 96), 6, Color.BlueViolet * 0.5f, 175, 100));
			if (r.NextDouble() < 0.035)
			{
				Game1.createMultipleObjectDebris("(O)74", x, y, 1, num3, this);
			}
			num = 50;
			break;
		case "CalicoEggStone_0":
		case "CalicoEggStone_1":
		case "CalicoEggStone_2":
			Game1.createMultipleObjectDebris("CalicoEgg", x, y, r.Next(1, 4) + (r.NextBool((float)num4 / 100f) ? 1 : 0) + (r.NextBool((float)num6 / 100f) ? 1 : 0), num3, this);
			num = 50;
			Game1.multiplayer.broadcastSprites(this, Utility.sparkleWithinArea(new Rectangle(x * 64, (y - 1) * 64, 32, 96), 6, new Color(255, 120, 0) * 0.5f, 175, 100));
			break;
		}
		if (who != null && who.professions.Contains(19) && r.NextBool())
		{
			int number = ((who.stats.Get(StatKeys.Mastery(3)) == 0) ? 1 : 2);
			switch (stoneId)
			{
			case "8":
				Game1.createMultipleObjectDebris("(O)66", x, y, number, who.UniqueMultiplayerID, this);
				num = 8;
				break;
			case "10":
				Game1.createMultipleObjectDebris("(O)68", x, y, number, who.UniqueMultiplayerID, this);
				num = 8;
				break;
			case "12":
				Game1.createMultipleObjectDebris("(O)60", x, y, number, who.UniqueMultiplayerID, this);
				num = 50;
				break;
			case "14":
				Game1.createMultipleObjectDebris("(O)62", x, y, number, who.UniqueMultiplayerID, this);
				num = 20;
				break;
			case "6":
				Game1.createMultipleObjectDebris("(O)70", x, y, number, who.UniqueMultiplayerID, this);
				num = 20;
				break;
			case "4":
				Game1.createMultipleObjectDebris("(O)64", x, y, number, who.UniqueMultiplayerID, this);
				num = 50;
				break;
			case "2":
				Game1.createMultipleObjectDebris("(O)72", x, y, number, who.UniqueMultiplayerID, this);
				num = 100;
				break;
			}
		}
		if (stoneId == 46.ToString())
		{
			Game1.createDebris(10, x, y, r.Next(1, 4), this);
			Game1.createDebris(6, x, y, r.Next(1, 5), this);
			if (r.NextDouble() < 0.25)
			{
				Game1.createMultipleObjectDebris("(O)74", x, y, 1, num3, this);
			}
			num = 150;
			Game1.stats.MysticStonesCrushed++;
		}
		if ((isOutdoors.Value || treatAsOutdoors.Value) && num == 0)
		{
			double num7 = num5 / 2.0 + (double)num6 * 0.005 + (double)num4 * 0.001;
			Random random = Utility.CreateDaySaveRandom(x * 1000, y);
			Game1.createDebris(14, x, y, 1, this);
			if (who != null)
			{
				who.gainExperience(3, 1);
				double num8 = 0.0;
				if (who.professions.Contains(21))
				{
					num8 += 0.05 * (1.0 + num7);
				}
				if (who.hasBuff("dwarfStatue_2"))
				{
					num8 += 0.025;
				}
				if (random.NextDouble() < num8)
				{
					Game1.createObjectDebris("(O)382", x, y, who.UniqueMultiplayerID, this);
				}
			}
			if (random.NextDouble() < 0.05 * (1.0 + num7))
			{
				Game1.createObjectDebris("(O)382", x, y, num3, this);
				Game1.multiplayer.broadcastSprites(this, new TemporaryAnimatedSprite(25, new Vector2((float)(64 * x), (float)(64 * y)), Color.White, 8, Game1.random.NextBool(), 80f, 0, -1, -1f, 128));
				who?.gainExperience(3, 5);
			}
		}
		if (who != null && HasUnlockedAreaSecretNotes(who) && r.NextDouble() < 0.0075)
		{
			Object obj = tryToCreateUnseenSecretNote(who);
			if (obj != null)
			{
				Game1.createItemDebris(obj, new Vector2((float)x + 0.5f, (float)y + 0.75f) * 64f, Game1.player.FacingDirection, this);
			}
		}
		who?.gainExperience(3, num);
		return num > 0;
	}

	public bool isBehindBush(Vector2 Tile)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (largeTerrainFeatures != null)
		{
			Rectangle val = default(Rectangle);
			((Rectangle)(ref val))._002Ector((int)Tile.X * 64, (int)(Tile.Y + 1f) * 64, 64, 128);
			foreach (LargeTerrainFeature largeTerrainFeature in largeTerrainFeatures)
			{
				Rectangle boundingBox = largeTerrainFeature.getBoundingBox();
				if (((Rectangle)(ref boundingBox)).Intersects(val))
				{
					return true;
				}
			}
		}
		return false;
	}

	public bool isBehindTree(Vector2 Tile)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (terrainFeatures != null)
		{
			Rectangle val = default(Rectangle);
			((Rectangle)(ref val))._002Ector((int)(Tile.X - 1f) * 64, (int)Tile.Y * 64, 192, 256);
			foreach (KeyValuePair<Vector2, TerrainFeature> pair in terrainFeatures.Pairs)
			{
				if (pair.Value is Tree)
				{
					Rectangle boundingBox = pair.Value.getBoundingBox();
					if (((Rectangle)(ref boundingBox)).Intersects(val))
					{
						return true;
					}
				}
			}
		}
		return false;
	}

	public virtual void spawnObjects()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_041f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0470: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d1: Invalid comparison between Unknown and I4
		//IL_049b: Unknown result type (might be due to invalid IL or missing references)
		//IL_052c: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_064a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0650: Invalid comparison between Unknown and I4
		//IL_0546: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0584: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ae: Invalid comparison between Unknown and I4
		//IL_0381: Unknown result type (might be due to invalid IL or missing references)
		//IL_0388: Unknown result type (might be due to invalid IL or missing references)
		//IL_038d: Unknown result type (might be due to invalid IL or missing references)
		//IL_060f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_0270: Unknown result type (might be due to invalid IL or missing references)
		Random random = Utility.CreateDaySaveRandom();
		LocationData data = GetData();
		if (data != null && numberOfSpawnedObjectsOnMap < data.MaxSpawnedForageAtOnce)
		{
			Season season = GetSeason();
			List<SpawnForageData> list = new List<SpawnForageData>();
			foreach (SpawnForageData item2 in GetData("Default").Forage.Concat(data.Forage))
			{
				if ((((GenericSpawnItemDataWithCondition)item2).Condition == null || GameStateQuery.CheckConditions(((GenericSpawnItemDataWithCondition)item2).Condition, this, null, null, null, random)) && (!item2.Season.HasValue || item2.Season == (Season?)season))
				{
					list.Add(item2);
				}
			}
			if (list.Any())
			{
				int val = random.Next(data.MinDailyForageSpawn, data.MaxDailyForageSpawn + 1);
				val = Math.Min(val, data.MaxSpawnedForageAtOnce - numberOfSpawnedObjectsOnMap);
				ItemQueryContext context = new ItemQueryContext(this, null, random, "location '" + NameOrUniqueName + "' > forage");
				Vector2 val2 = default(Vector2);
				for (int i = 0; i < val; i++)
				{
					for (int j = 0; j < 11; j++)
					{
						int num = random.Next(map.DisplayWidth / 64);
						int num2 = random.Next(map.DisplayHeight / 64);
						((Vector2)(ref val2))._002Ector((float)num, (float)num2);
						if (objects.ContainsKey(val2) || IsNoSpawnTile(val2) || doesTileHaveProperty(num, num2, "Spawnable", "Back") == null || doesEitherTileOrTileIndexPropertyEqual(num, num2, "Spawnable", "Back", "F") || !CanItemBePlacedHere(val2) || hasTileAt(num, num2, "AlwaysFront") || hasTileAt(num, num2, "AlwaysFront2") || hasTileAt(num, num2, "AlwaysFront3") || hasTileAt(num, num2, "Front") || isBehindBush(val2) || (!random.NextBool(0.1) && isBehindTree(val2)))
						{
							continue;
						}
						SpawnForageData forage = random.ChooseFrom(list);
						if (!random.NextBool(forage.Chance))
						{
							continue;
						}
						Item item = ItemQueryResolver.TryResolveRandomItem((ISpawnItemData)(object)forage, context, avoidRepeat: false, null, null, null, delegate(string query, string error)
						{
							Game1.log.Error($"Location '{NameOrUniqueName}' failed parsing item query '{query}' for forage '{((GenericSpawnItemData)forage).Id}': {error}");
						});
						if (item == null)
						{
							continue;
						}
						if (!(item is Object obj))
						{
							Game1.log.Warn($"Location '{Name}' ignored invalid forage data '{((GenericSpawnItemData)forage).Id}': the resulting item '{item.QualifiedItemId}' isn't an {"Object"}-type item.");
						}
						else
						{
							obj.IsSpawnedObject = true;
							if (dropObject(obj, val2 * 64f, Game1.viewport, initialPlacement: true))
							{
								numberOfSpawnedObjectsOnMap++;
								break;
							}
						}
					}
				}
			}
		}
		List<Vector2> list2 = new List<Vector2>();
		foreach (KeyValuePair<Vector2, Object> pair in objects.Pairs)
		{
			if (pair.Value.QualifiedItemId == "(O)590" || pair.Value.QualifiedItemId == "(O)SeedSpot")
			{
				list2.Add(pair.Key);
			}
		}
		if (!(this is Farm) && !(this is IslandWest))
		{
			spawnWeedsAndStones();
		}
		for (int num3 = list2.Count - 1; num3 >= 0; num3--)
		{
			if ((!(this is IslandNorth) || !(list2[num3].X < 26f)) && random.NextBool(0.15))
			{
				objects.Remove(list2[num3]);
				list2.RemoveAt(num3);
			}
		}
		if (list2.Count > ((!(this is Farm)) ? 1 : 0) && ((int)GetSeason() != 3 || list2.Count > 4))
		{
			return;
		}
		double num4 = 1.0;
		Vector2 val3 = default(Vector2);
		while (random.NextDouble() < num4)
		{
			int num5 = random.Next(map.DisplayWidth / 64);
			int num6 = random.Next(map.DisplayHeight / 64);
			((Vector2)(ref val3))._002Ector((float)num5, (float)num6);
			if (CanItemBePlacedHere(val3) && !IsTileOccupiedBy(val3) && !hasTileAt(num5, num6, "AlwaysFront") && !hasTileAt(num5, num6, "Front") && !isBehindBush(val3) && (doesTileHaveProperty(num5, num6, "Diggable", "Back") != null || ((int)GetSeason() == 3 && doesTileHaveProperty(num5, num6, "Type", "Back") != null && doesTileHaveProperty(num5, num6, "Type", "Back").Equals("Grass"))))
			{
				if (name.Equals("Forest") && num5 >= 93 && num6 <= 22)
				{
					continue;
				}
				objects.Add(val3, ItemRegistry.Create<Object>(random.NextBool(0.166) ? "(O)SeedSpot" : "(O)590"));
			}
			num4 *= 0.75;
			if ((int)GetSeason() == 3)
			{
				num4 += 0.10000000149011612;
			}
		}
	}

	public void spawnWeedsAndStones(int numDebris = -1, bool weedsOnly = false, bool spawnFromOldWeeds = true)
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Invalid comparison between Unknown and I4
		//IL_05f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0656: Unknown result type (might be due to invalid IL or missing references)
		//IL_0658: Unknown result type (might be due to invalid IL or missing references)
		//IL_065a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0501: Unknown result type (might be due to invalid IL or missing references)
		//IL_0503: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_040d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Unknown result type (might be due to invalid IL or missing references)
		//IL_05af: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0366: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_059a: Unknown result type (might be due to invalid IL or missing references)
		//IL_059c: Unknown result type (might be due to invalid IL or missing references)
		//IL_059e: Unknown result type (might be due to invalid IL or missing references)
		if ((this is Farm || this is IslandWest) && Game1.IsBuildingConstructed("Gold Clock") && !Game1.netWorldState.Value.goldenClocksTurnedOff.Value)
		{
			return;
		}
		bool flag = false;
		if (this is Beach || (int)GetSeason() == 3 || this is Desert)
		{
			return;
		}
		int num = ((numDebris != -1) ? numDebris : ((Game1.random.NextDouble() < 0.95) ? ((Game1.random.NextDouble() < 0.25) ? Game1.random.Next(10, 21) : Game1.random.Next(5, 11)) : 0));
		if (IsRainingHere())
		{
			num *= 2;
		}
		if (Game1.dayOfMonth == 1)
		{
			num *= 5;
		}
		if (objects.Length <= 0 && spawnFromOldWeeds)
		{
			return;
		}
		if (!(this is Farm))
		{
			num /= 2;
		}
		bool flag2 = IsGreenRainingHere();
		for (int i = 0; i < num; i++)
		{
			Vector2 val = (spawnFromOldWeeds ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : new Vector2((float)Game1.random.Next(map.Layers[0].LayerWidth), (float)Game1.random.Next(map.Layers[0].LayerHeight)));
			if (!spawnFromOldWeeds && this is IslandWest)
			{
				((Vector2)(ref val))._002Ector((float)Game1.random.Next(57, 97), (float)Game1.random.Next(44, 68));
			}
			while (spawnFromOldWeeds && ((Vector2)(ref val)).Equals(Vector2.Zero))
			{
				((Vector2)(ref val))._002Ector((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2));
			}
			Vector2 key = Vector2.Zero;
			Object value = null;
			if (spawnFromOldWeeds)
			{
				Utility.TryGetRandom(objects, out key, out value);
			}
			Vector2 val2 = (spawnFromOldWeeds ? key : Vector2.Zero);
			if ((this is Mountain && val.X + val2.X > 100f) || this is IslandNorth)
			{
				continue;
			}
			bool num2 = this is Farm || this is IslandWest;
			int num3 = (int)(val.X + val2.X);
			int num4 = (int)(val.Y + val2.Y);
			Vector2 val3 = val + val2;
			int value2 = 1;
			bool flag3 = false;
			bool flag4 = doesTileHaveProperty(num3, num4, "Diggable", "Back") != null;
			if (num2 == flag4 && !IsNoSpawnTile(val3) && doesTileHaveProperty(num3, num4, "Type", "Back") != "Wood")
			{
				bool flag5 = false;
				if (CanItemBePlacedHere(val3) && !terrainFeatures.ContainsKey(val3))
				{
					flag5 = true;
				}
				else if (spawnFromOldWeeds)
				{
					if (objects.TryGetValue(val3, out var value3))
					{
						if (flag2)
						{
							flag5 = false;
						}
						else if (!value3.IsTapper())
						{
							flag5 = true;
						}
					}
					if (!flag5 && terrainFeatures.TryGetValue(val3, out var value4) && (value4 is HoeDirt || value4 is Flooring))
					{
						flag5 = !flag2 && getLargeTerrainFeatureAt(num3, num4) == null;
					}
				}
				if (flag5)
				{
					if (spawnFromOldWeeds)
					{
						flag3 = true;
					}
					else if (!objects.ContainsKey(val3))
					{
						flag3 = true;
					}
				}
			}
			if (!flag3)
			{
				continue;
			}
			string text = null;
			if (this is Desert)
			{
				text = "(O)750";
			}
			else
			{
				if (Game1.random.NextBool() && !weedsOnly && (!spawnFromOldWeeds || value.IsBreakableStone() || value.IsTwig()))
				{
					text = Game1.random.Choose("(O)294", "(O)295", "(O)343", "(O)450");
				}
				else if (!spawnFromOldWeeds || value.IsWeeds())
				{
					text = getWeedForSeason(Game1.random, GetSeason());
					if (IsGreenRainingHere())
					{
						if (doesTileHavePropertyNoNull((int)(val.X + val2.X), (int)(val.Y + val2.Y), "Type", "Back") == (IsFarm ? "Dirt" : "Grass"))
						{
							int num5 = Game1.random.Next(8);
							text = "(O)GreenRainWeeds" + num5;
							if (num5 == 2 || num5 == 3 || num5 == 7)
							{
								value2 = 2;
							}
						}
						else
						{
							text = null;
						}
					}
				}
				if (this is Farm && !spawnFromOldWeeds && Game1.random.NextDouble() < 0.05 && !terrainFeatures.ContainsKey(val3))
				{
					terrainFeatures.Add(val3, new Tree((Game1.random.Next(3) + 1).ToString(), Game1.random.Next(3)));
					continue;
				}
			}
			if (text == null)
			{
				continue;
			}
			bool flag6 = false;
			if (objects.TryGetValue(val + val2, out var value5))
			{
				if (flag2 || value5 is Fence || value5 is Chest || value5.QualifiedItemId == "(O)590" || value5.QualifiedItemId == "(BC)MushroomLog")
				{
					continue;
				}
				if (value5.name.Length > 0 && value5.Category != -999)
				{
					flag6 = true;
					Game1.debugOutput = value5.Name + " was destroyed";
				}
				objects.Remove(val + val2);
			}
			if (terrainFeatures.TryGetValue(val + val2, out var value6))
			{
				try
				{
					flag6 = value6 is HoeDirt || value6 is Flooring;
				}
				catch (Exception)
				{
				}
				if (!flag6 || IsGreenRainingHere())
				{
					break;
				}
				terrainFeatures.Remove(val + val2);
			}
			if (flag6 && this is Farm && Game1.stats.DaysPlayed > 1 && !flag)
			{
				flag = true;
				Game1.multiplayer.broadcastGlobalMessage("Strings\\Locations:Farm_WeedsDestruction", false, null);
			}
			Object obj = ItemRegistry.Create<Object>(text);
			obj.minutesUntilReady.Value = value2;
			objects.TryAdd(val + val2, obj);
		}
	}

	[Obsolete("Use removeObjectsAndSpawned instead.")]
	public virtual void removeEverythingExceptCharactersFromThisTile(int x, int y)
	{
		removeObjectsAndSpawned(x, y, 1, 1);
	}

	public virtual void removeObjectsAndSpawned(int x, int y, int width, int height)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		Rectangle pixelArea = new Rectangle(x * 64, y * 64, width * 64, height * 64);
		int num = x + width - 1;
		int num2 = y + height - 1;
		Vector2 key = default(Vector2);
		for (int i = y; i <= num2; i++)
		{
			for (int j = x; j <= num; j++)
			{
				((Vector2)(ref key))._002Ector((float)j, (float)i);
				terrainFeatures.Remove(key);
				objects.Remove(key);
			}
		}
		largeTerrainFeatures.RemoveWhere(delegate(LargeTerrainFeature feature)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			Rectangle boundingBox = feature.getBoundingBox();
			return ((Rectangle)(ref boundingBox)).Intersects(pixelArea);
		});
		resourceClumps.RemoveWhere(delegate(ResourceClump clump)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			Rectangle boundingBox = clump.getBoundingBox();
			return ((Rectangle)(ref boundingBox)).Intersects(pixelArea);
		});
	}

	public virtual string getFootstepSoundReplacement(string footstep)
	{
		return footstep;
	}

	public virtual void removeEverythingFromThisTile(int x, int y)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		Vector2 tile = new Vector2((float)x, (float)y);
		Point pixel = Utility.Vector2ToPoint(tile * 64f + new Vector2(32f));
		resourceClumps.RemoveWhere((ResourceClump clump) => clump.Tile == tile);
		terrainFeatures.Remove(tile);
		objects.Remove(tile);
		furniture.RemoveWhere(delegate(Furniture f)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000a: Unknown result type (might be due to invalid IL or missing references)
			Rectangle boundingBox = f.GetBoundingBox();
			return ((Rectangle)(ref boundingBox)).Contains(pixel);
		});
		characters.RemoveWhere((NPC npc) => npc.Tile == tile && npc is Monster);
	}

	public virtual bool TryGetLocationEvents(out string assetName, out Dictionary<string, string> events)
	{
		events = null;
		assetName = ((NameOrUniqueName == Game1.player.homeLocation.Value) ? "Data\\Events\\FarmHouse" : ("Data\\Events\\" + name.Value));
		try
		{
			if (Game1.content.DoesAssetExist<Dictionary<string, string>>(assetName))
			{
				events = Game1.content.Load<Dictionary<string, string>>(assetName);
			}
		}
		catch (Exception exception)
		{
			Game1.log.Error($"Failed loading events for location '{NameOrUniqueName}' from asset '{assetName}'.", exception);
		}
		if (events == null)
		{
			events = new Dictionary<string, string>();
		}
		if (assetName != "Data\\Events\\FarmHouse")
		{
			foreach (KeyValuePair<string, string> item in Game1.content.Load<Dictionary<string, string>>("Data\\Events\\FarmHouse"))
			{
				if (item.Key.StartsWith("558291/") || item.Key.StartsWith("558292/"))
				{
					events.TryAdd(item.Key, item.Value);
				}
			}
		}
		if (Name == "Trailer_Big")
		{
			events = new Dictionary<string, string>(events);
			Dictionary<string, string> dictionary = Game1.content.Load<Dictionary<string, string>>("Data\\Events\\Trailer");
			if (dictionary != null)
			{
				foreach (string key in dictionary.Keys)
				{
					string text = dictionary[key];
					if (!(name.Value == "Trailer_Big") || !events.ContainsKey(key))
					{
						if (key.StartsWith("36/"))
						{
							text = text.Replace("/farmer -30 30 0", "/farmer 12 19 0");
							text = text.Replace("/playSound doorClose/warp farmer 12 9", "/move farmer 0 -10 0");
						}
						else if (key.StartsWith("35/"))
						{
							text = text.Replace("/farmer -30 30 0", "/farmer 12 19 0");
							text = text.Replace("/warp farmer 12 9/playSound doorClose", "/move farmer 0 -10 0");
							text = text.Replace("/warp farmer -40 -40/playSound doorClose", "/move farmer 0 10 0/warp farmer -40 -40");
						}
						events[key] = text;
					}
				}
			}
		}
		return events.Count > 0;
	}

	public static bool IsValidLocationEvent(string key, string eventScript)
	{
		if (!key.Contains('/') && !int.TryParse(key, out var _))
		{
			return false;
		}
		string[] array = Event.ParseCommands(eventScript);
		if (array.Length < 3)
		{
			return false;
		}
		string text = array[1];
		if (text.Length == 0 || (text != "follow" && !char.IsDigit(text[0]) && text[0] != '-'))
		{
			return false;
		}
		return true;
	}

	public virtual void checkForEvents()
	{
		if (Game1.killScreen && !Game1.eventUp)
		{
			if (Game1.player.bathingClothes.Value)
			{
				Game1.player.changeOutOfSwimSuit();
			}
			if (name.Equals("Mine"))
			{
				string sub;
				string sub2;
				switch (Game1.random.Next(7))
				{
				case 0:
					sub = "Robin";
					sub2 = "Data\\ExtraDialogue:Mines_PlayerKilled_Robin";
					break;
				case 1:
					sub = "Clint";
					sub2 = "Data\\ExtraDialogue:Mines_PlayerKilled_Clint";
					break;
				case 2:
					sub = "Maru";
					sub2 = ((Game1.player.spouse == "Maru") ? "Data\\ExtraDialogue:Mines_PlayerKilled_Maru_Spouse" : "Data\\ExtraDialogue:Mines_PlayerKilled_Maru_NotSpouse");
					break;
				default:
					sub = "Linus";
					sub2 = "Data\\ExtraDialogue:Mines_PlayerKilled_Linus";
					break;
				}
				if (Game1.random.NextDouble() < 0.1 && Game1.player.spouse != null && !Game1.player.isEngaged() && Game1.player.spouse.Length > 1)
				{
					sub = Game1.player.spouse;
					sub2 = (Game1.player.IsMale ? "Data\\ExtraDialogue:Mines_PlayerKilled_Spouse_PlayerMale" : "Data\\ExtraDialogue:Mines_PlayerKilled_Spouse_PlayerFemale");
				}
				currentEvent = new Event(Game1.content.LoadString("Data\\Events\\Mine:PlayerKilled", sub, sub2, ArgUtility.EscapeQuotes(Game1.player.Name)));
			}
			else if (this is IslandLocation)
			{
				string sub3 = "Willy";
				string sub4 = "Data\\ExtraDialogue:Island_willy_rescue";
				if (Game1.player.friendshipData.ContainsKey("Leo") && Game1.random.NextBool())
				{
					sub3 = "Leo";
					sub4 = "Data\\ExtraDialogue:Island_leo_rescue";
				}
				currentEvent = new Event(Game1.content.LoadString("Data\\Events\\IslandSouth:PlayerKilled", sub3, sub4, ArgUtility.EscapeQuotes(Game1.player.Name)));
			}
			else if (name.Equals("Hospital"))
			{
				currentEvent = new Event(Game1.content.LoadString("Data\\Events\\Hospital:PlayerKilled", ArgUtility.EscapeQuotes(Game1.player.Name)));
			}
			else
			{
				try
				{
					if (TryGetLocationEvents(out var assetName, out var events) && events.TryGetValue("PlayerKilled", out var value))
					{
						currentEvent = new Event(value, assetName, "PlayerKilled");
					}
				}
				catch (Exception)
				{
				}
			}
			if (currentEvent != null)
			{
				Game1.eventUp = true;
			}
			Game1.changeMusicTrack("none", track_interruptable: true, (MusicContext)0);
			Game1.killScreen = false;
			Game1.player.health = 10;
		}
		else if (!Game1.eventUp && Game1.weddingsToday.Count > 0 && (Game1.CurrentEvent == null || Game1.CurrentEvent.id != "-2") && Game1.currentLocation != null && !Game1.currentLocation.IsTemporary)
		{
			currentEvent = Game1.getAvailableWeddingEvent();
			if (currentEvent != null)
			{
				startEvent(currentEvent);
			}
		}
		else
		{
			if (Game1.eventUp || Game1.farmEvent != null)
			{
				return;
			}
			string festival = $"{Game1.currentSeason}{Game1.dayOfMonth}";
			try
			{
				if (Event.tryToLoadFestival(festival, out var ev))
				{
					currentEvent = ev;
				}
			}
			catch (Exception)
			{
			}
			if (!Game1.eventUp && currentEvent == null && Game1.farmEvent == null && !IsGreenRainingHere())
			{
				string assetName2;
				Dictionary<string, string> events2;
				try
				{
					if (!TryGetLocationEvents(out assetName2, out events2))
					{
						return;
					}
				}
				catch
				{
					return;
				}
				if (events2 != null)
				{
					foreach (string key in events2.Keys)
					{
						string text = checkEventPrecondition(key);
						if (!string.IsNullOrEmpty(text) && text != "-1" && IsValidLocationEvent(key, events2[key]))
						{
							currentEvent = new Event(events2[key], assetName2, text);
							break;
						}
					}
					if (currentEvent == null && Game1.IsMasterGame && Game1.stats.DaysPlayed >= 20 && !Game1.player.mailReceived.Contains("rejectedPet") && !Game1.player.hasPet() && Pet.TryGetData(Game1.player.whichPetType, out var data) && Name == data.AdoptionEventLocation && !string.IsNullOrWhiteSpace(data.AdoptionEventId) && !Game1.player.eventsSeen.Contains(data.AdoptionEventId))
					{
						Game1.PlayEvent(data.AdoptionEventId, checkPreconditions: false, checkSeen: false);
					}
				}
			}
			if (currentEvent != null)
			{
				startEvent(currentEvent);
			}
		}
	}

	public Event findEventById(string id, Farmer farmerActor = null)
	{
		if (id == "-2")
		{
			long? spouse = Game1.player.team.GetSpouse(farmerActor.UniqueMultiplayerID);
			if (farmerActor == null || !spouse.HasValue)
			{
				return Utility.getWeddingEvent(farmerActor);
			}
			if (Game1.otherFarmers.ContainsKey(spouse.Value))
			{
				return Utility.getWeddingEvent(farmerActor);
			}
		}
		string assetName;
		Dictionary<string, string> events;
		try
		{
			if (!TryGetLocationEvents(out assetName, out events))
			{
				return null;
			}
		}
		catch
		{
			return null;
		}
		foreach (KeyValuePair<string, string> item in events)
		{
			if (Event.SplitPreconditions(item.Key)[0] == id)
			{
				return new Event(item.Value, assetName, id, farmerActor);
			}
		}
		return null;
	}

	public virtual void startEvent(Event evt)
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.eventUp || Game1.eventOver)
		{
			return;
		}
		currentEvent = evt;
		ResetForEvent(evt);
		if (evt.exitLocation == null)
		{
			evt.exitLocation = Game1.getLocationRequest(NameOrUniqueName, isStructure.Value);
		}
		if (Game1.player.mount != null)
		{
			Horse mount = Game1.player.mount;
			mount.currentLocation = this;
			mount.dismount();
			Rectangle boundingBox = mount.GetBoundingBox();
			Vector2 position = mount.Position;
			if (mount.currentLocation != null && mount.currentLocation.isCollidingPosition(boundingBox, Game1.viewport, isFarmer: false, 0, glider: false, mount, pathfinding: true))
			{
				boundingBox.X -= 64;
				if (!mount.currentLocation.isCollidingPosition(boundingBox, Game1.viewport, isFarmer: false, 0, glider: false, mount, pathfinding: true))
				{
					position.X -= 64f;
					mount.Position = position;
				}
				else
				{
					boundingBox.X += 128;
					if (!mount.currentLocation.isCollidingPosition(boundingBox, Game1.viewport, isFarmer: false, 0, glider: false, mount, pathfinding: true))
					{
						position.X += 64f;
						mount.Position = position;
					}
				}
			}
		}
		foreach (NPC character in characters)
		{
			character.clearTextAboveHead();
		}
		Game1.eventUp = true;
		Game1.displayHUD = false;
		Game1.player.CanMove = false;
		Game1.player.showNotCarrying();
		critters?.Clear();
		if (currentEvent != null)
		{
			Game1.player.autoGenerateActiveDialogueEvent("eventSeen_" + currentEvent.id);
		}
	}

	public virtual void drawBackground(SpriteBatch b)
	{
	}

	public virtual void drawWater(SpriteBatch b)
	{
		currentEvent?.drawUnderWater(b);
		if (waterTiles == null)
		{
			return;
		}
		for (int i = Math.Max(0, ((Rectangle)(ref Game1.viewport)).Y / 64 - 1); i < Math.Min(map.Layers[0].LayerHeight, (((Rectangle)(ref Game1.viewport)).Y + ((Rectangle)(ref Game1.viewport)).Height) / 64 + 2); i++)
		{
			for (int j = Math.Max(0, ((Rectangle)(ref Game1.viewport)).X / 64 - 1); j < Math.Min(map.Layers[0].LayerWidth, (((Rectangle)(ref Game1.viewport)).X + ((Rectangle)(ref Game1.viewport)).Width) / 64 + 1); j++)
			{
				if (waterTiles.waterTiles[j, i].isWater && waterTiles.waterTiles[j, i].isVisible)
				{
					drawWaterTile(b, j, i);
				}
			}
		}
	}

	public virtual void drawWaterTile(SpriteBatch b, int x, int y)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		drawWaterTile(b, x, y, waterColor.Value);
	}

	public void drawWaterTile(SpriteBatch b, int x, int y, Color color)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		bool num = y == map.Layers[0].LayerHeight - 1 || !waterTiles[x, y + 1];
		bool flag = y == 0 || !waterTiles[x, y - 1];
		b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)(y * 64 - (int)((!flag) ? waterPosition : 0f)))), (Rectangle?)new Rectangle(waterAnimationIndex * 64, 2064 + (((x + y) % 2 != 0) ? ((!waterTileFlip) ? 128 : 0) : (waterTileFlip ? 128 : 0)) + (flag ? ((int)waterPosition) : 0), 64, 64 + (flag ? ((int)(0f - waterPosition)) : 0)), color, 0f, Vector2.Zero, 1f, (SpriteEffects)0, 0.56f);
		if (num)
		{
			b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, new Vector2((float)(x * 64), (float)((y + 1) * 64 - (int)waterPosition))), (Rectangle?)new Rectangle(waterAnimationIndex * 64, 2064 + (((x + (y + 1)) % 2 != 0) ? ((!waterTileFlip) ? 128 : 0) : (waterTileFlip ? 128 : 0)), 64, 64 - (int)(64f - waterPosition) - 1), color, 0f, Vector2.Zero, 1f, (SpriteEffects)0, 0.56f);
		}
	}

	public virtual void drawFloorDecorations(SpriteBatch b)
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		int num = 1;
		Rectangle val = default(Rectangle);
		((Rectangle)(ref val))._002Ector(((Rectangle)(ref Game1.viewport)).X / 64 - num, ((Rectangle)(ref Game1.viewport)).Y / 64 - num, (int)Math.Ceiling((float)((Rectangle)(ref Game1.viewport)).Width / 64f) + 2 * num, (int)Math.Ceiling((float)((Rectangle)(ref Game1.viewport)).Height / 64f) + 3 + 2 * num);
		Rectangle val2 = default(Rectangle);
		if (buildings.Count > 0)
		{
			foreach (Building building in buildings)
			{
				int additionalTilePropertyRadius = building.GetAdditionalTilePropertyRadius();
				Rectangle sourceRect = building.getSourceRect();
				val2.X = building.tileX.Value - additionalTilePropertyRadius;
				val2.Width = building.tilesWide.Value + additionalTilePropertyRadius * 2;
				int num2 = building.tileY.Value + building.tilesHigh.Value + additionalTilePropertyRadius;
				val2.Height = num2 - (val2.Y = num2 - (int)Math.Ceiling((float)sourceRect.Height * 4f / 64f) - additionalTilePropertyRadius);
				if (((Rectangle)(ref val2)).Intersects(val))
				{
					building.drawBackground(b);
				}
			}
		}
		if (!Game1.isFestival() && terrainFeatures.Length > 0)
		{
			Vector2 key = default(Vector2);
			for (int i = ((Rectangle)(ref Game1.viewport)).Y / 64 - 1; i < (((Rectangle)(ref Game1.viewport)).Y + ((Rectangle)(ref Game1.viewport)).Height) / 64 + 7; i++)
			{
				for (int j = ((Rectangle)(ref Game1.viewport)).X / 64 - 1; j < (((Rectangle)(ref Game1.viewport)).X + ((Rectangle)(ref Game1.viewport)).Width) / 64 + 3; j++)
				{
					key.X = j;
					key.Y = i;
					if (terrainFeatures.TryGetValue(key, out var value) && value is Flooring)
					{
						value.draw(b);
					}
				}
			}
		}
		if (Game1.eventUp && !(this is Farm) && !(this is FarmHouse))
		{
			return;
		}
		Furniture.isDrawingLocationFurniture = true;
		foreach (Furniture item in furniture)
		{
			if (item.furniture_type.Value == 12)
			{
				item.draw(b, -1, -1);
			}
		}
		Furniture.isDrawingLocationFurniture = false;
	}

	public TemporaryAnimatedSprite getTemporarySpriteByID(int id)
	{
		for (int i = 0; i < temporarySprites.Count; i++)
		{
			if (temporarySprites[i].id == id)
			{
				return temporarySprites[i];
			}
		}
		return null;
	}

	protected void drawDebris(SpriteBatch b)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_030d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0335: Unknown result type (might be due to invalid IL or missing references)
		//IL_034c: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0620: Unknown result type (might be due to invalid IL or missing references)
		//IL_0625: Unknown result type (might be due to invalid IL or missing references)
		//IL_0670: Unknown result type (might be due to invalid IL or missing references)
		//IL_0672: Unknown result type (might be due to invalid IL or missing references)
		//IL_067f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0689: Unknown result type (might be due to invalid IL or missing references)
		//IL_0403: Unknown result type (might be due to invalid IL or missing references)
		//IL_0408: Unknown result type (might be due to invalid IL or missing references)
		//IL_043f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0425: Unknown result type (might be due to invalid IL or missing references)
		//IL_0444: Unknown result type (might be due to invalid IL or missing references)
		//IL_0462: Unknown result type (might be due to invalid IL or missing references)
		//IL_0467: Unknown result type (might be due to invalid IL or missing references)
		//IL_046c: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0473: Unknown result type (might be due to invalid IL or missing references)
		//IL_0478: Unknown result type (might be due to invalid IL or missing references)
		//IL_047f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Unknown result type (might be due to invalid IL or missing references)
		//IL_0490: Unknown result type (might be due to invalid IL or missing references)
		//IL_049c: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04de: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0501: Unknown result type (might be due to invalid IL or missing references)
		//IL_0506: Unknown result type (might be due to invalid IL or missing references)
		//IL_0510: Unknown result type (might be due to invalid IL or missing references)
		//IL_051a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Unknown result type (might be due to invalid IL or missing references)
		//IL_0533: Unknown result type (might be due to invalid IL or missing references)
		//IL_0538: Unknown result type (might be due to invalid IL or missing references)
		//IL_053c: Unknown result type (might be due to invalid IL or missing references)
		//IL_054c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0551: Unknown result type (might be due to invalid IL or missing references)
		//IL_0555: Unknown result type (might be due to invalid IL or missing references)
		//IL_0560: Unknown result type (might be due to invalid IL or missing references)
		//IL_057e: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		foreach (Debris debri in debris)
		{
			num++;
			if (debri.item != null)
			{
				Vector2 visualPosition = debri.Chunks[0].GetVisualPosition();
				if (debri.item is Object obj && obj.bigCraftable.Value)
				{
					obj.drawInMenu(b, Utility.snapDrawPosition(Game1.GlobalToLocal(Game1.viewport, visualPosition + new Vector2(32f, 32f))), 1.6f, 1f, ((float)(debri.chunkFinalYLevel + 64 + 8) + visualPosition.X / 10000f) / 10000f, StackDrawType.Hide, Color.White, drawShadow: true);
				}
				else
				{
					debri.item.drawInMenu(b, Utility.snapDrawPosition(Game1.GlobalToLocal(Game1.viewport, visualPosition + new Vector2(32f, 32f))), 0.8f + (float)debri.itemQuality * 0.1f, 1f, ((float)(debri.chunkFinalYLevel + 64 + 8) + visualPosition.X / 10000f) / 10000f, StackDrawType.Hide, Color.White, drawShadow: true);
				}
				continue;
			}
			switch (debri.debrisType.Value)
			{
			case Debris.DebrisType.LETTERS:
			{
				Chunk chunk = debri.Chunks[0];
				Vector2 visualPosition2 = chunk.GetVisualPosition();
				Game1.drawWithBorder(debri.debrisMessage.Value, Color.Black, debri.nonSpriteChunkColor.Value, Utility.snapDrawPosition(Game1.GlobalToLocal(Game1.viewport, visualPosition2)), chunk.rotation, chunk.scale, (visualPosition2.Y + 64f) / 10000f);
				continue;
			}
			case Debris.DebrisType.NUMBERS:
			{
				Chunk chunk2 = debri.Chunks[0];
				Vector2 visualPosition3 = chunk2.GetVisualPosition();
				NumberSprite.draw(debri.chunkType.Value, b, Game1.GlobalToLocal(Game1.viewport, Utility.snapDrawPosition(new Vector2(visualPosition3.X, (float)debri.chunkFinalYLevel - ((float)debri.chunkFinalYLevel - visualPosition3.Y)))), debri.nonSpriteChunkColor.Value, chunk2.scale * 0.75f, 0.98f + 0.0001f * (float)num, chunk2.alpha, -1 * (int)((float)debri.chunkFinalYLevel - visualPosition3.Y) / 2);
				continue;
			}
			case Debris.DebrisType.SPRITECHUNKS:
			{
				for (int i = 0; i < debri.Chunks.Count; i++)
				{
					Chunk chunk3 = debri.Chunks[0];
					Vector2 visualPosition4 = chunk3.GetVisualPosition();
					b.Draw(debri.spriteChunkSheet, Utility.snapDrawPosition(Game1.GlobalToLocal(Game1.viewport, visualPosition4)), (Rectangle?)new Rectangle(chunk3.xSpriteSheet.Value, chunk3.ySpriteSheet.Value, Math.Min(debri.sizeOfSourceRectSquares.Value, debri.spriteChunkSheet.Bounds.Width), Math.Min(debri.sizeOfSourceRectSquares.Value, debri.spriteChunkSheet.Bounds.Height)), debri.nonSpriteChunkColor.Value * chunk3.alpha, chunk3.rotation, new Vector2((float)(debri.sizeOfSourceRectSquares.Value / 2), (float)(debri.sizeOfSourceRectSquares.Value / 2)), chunk3.scale, (SpriteEffects)0, ((float)(debri.chunkFinalYLevel + 16) + visualPosition4.X / 10000f) / 10000f);
				}
				continue;
			}
			}
			if (debri.itemId.Value != null)
			{
				ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(debri.itemId.Value);
				Texture2D texture = dataOrErrorItem.GetTexture();
				float num2 = ((debri.debrisType.Value == Debris.DebrisType.RESOURCE || debri.floppingFish.Value) ? 4f : (4f * (0.8f + (float)debri.itemQuality * 0.1f)));
				for (int j = 0; j < debri.Chunks.Count; j++)
				{
					Chunk chunk4 = debri.Chunks[j];
					Vector2 visualPosition5 = chunk4.GetVisualPosition();
					Rectangle value = ((debri.debrisType.Value == Debris.DebrisType.RESOURCE) ? dataOrErrorItem.GetSourceRect(chunk4.randomOffset) : dataOrErrorItem.GetSourceRect());
					SpriteEffects val = (SpriteEffects)((debri.floppingFish.Value && chunk4.bounces % 2 == 0) ? 1 : 0);
					b.Draw(texture, Utility.snapDrawPosition(Game1.GlobalToLocal(Game1.viewport, visualPosition5)), (Rectangle?)value, Color.White, 0f, Vector2.Zero, num2, val, ((float)(debri.chunkFinalYLevel + 32) + visualPosition5.X / 10000f) / 10000f);
					Texture2D shadowTexture = Game1.shadowTexture;
					Vector2 val2 = Utility.snapDrawPosition(Game1.GlobalToLocal(Game1.viewport, new Vector2(visualPosition5.X + 25.6f, (debri.chunksMoveTowardPlayer ? (visualPosition5.Y + 8f) : ((float)debri.chunkFinalYLevel)) + 32f + (float)(12 * debri.itemQuality))));
					Rectangle? val3 = Game1.shadowTexture.Bounds;
					Color val4 = Color.White * 0.75f;
					Rectangle bounds = Game1.shadowTexture.Bounds;
					float num3 = ((Rectangle)(ref bounds)).Center.X;
					bounds = Game1.shadowTexture.Bounds;
					b.Draw(shadowTexture, val2, val3, val4, 0f, new Vector2(num3, (float)((Rectangle)(ref bounds)).Center.Y), Math.Min(3f, 3f - (debri.chunksMoveTowardPlayer ? 0f : (((float)debri.chunkFinalYLevel - visualPosition5.Y) / 96f))), (SpriteEffects)0, (float)debri.chunkFinalYLevel / 10000f);
				}
			}
			else
			{
				for (int k = 0; k < debri.Chunks.Count; k++)
				{
					Vector2 val5 = Utility.snapDrawPosition(Game1.GlobalToLocal(Game1.viewport, debri.Chunks[k].position.Value));
					Rectangle sourceRectForStandardTileSheet = Game1.getSourceRectForStandardTileSheet(Game1.debrisSpriteSheet, debri.chunkType.Value + debri.Chunks[k].randomOffset, 16, 16);
					float num4 = (debri.Chunks[k].position.Y + 128f + debri.Chunks[k].position.X / 10000f) / 10000f;
					b.Draw(Game1.debrisSpriteSheet, val5, (Rectangle?)sourceRectForStandardTileSheet, debri.chunksColor.Value, 0f, Vector2.Zero, 4f * debri.scale.Value, (SpriteEffects)0, num4);
				}
			}
		}
	}

	public virtual bool shouldHideCharacters()
	{
		return false;
	}

	protected virtual void drawCharacters(SpriteBatch b)
	{
		if (shouldHideCharacters() || (Game1.eventUp && (Game1.CurrentEvent == null || !Game1.CurrentEvent.showWorldCharacters)))
		{
			return;
		}
		for (int i = 0; i < characters.Count; i++)
		{
			if (characters[i] != null)
			{
				characters[i].draw(b);
			}
		}
	}

	protected virtual void drawFarmers(SpriteBatch b)
	{
		if (shouldHideCharacters() || Game1.currentMinigame != null)
		{
			return;
		}
		if (currentEvent == null || currentEvent.isFestival || currentEvent.farmerActors.Count == 0)
		{
			foreach (Farmer farmer in farmers)
			{
				if (!Game1.multiplayer.isDisconnecting(farmer.UniqueMultiplayerID))
				{
					farmer.draw(b);
				}
			}
			return;
		}
		currentEvent.drawFarmers(b);
	}

	public virtual void DrawFarmerUsernames(SpriteBatch b)
	{
		if (shouldHideCharacters() || Game1.currentMinigame != null || (currentEvent != null && !currentEvent.isFestival && currentEvent.farmerActors.Count != 0))
		{
			return;
		}
		foreach (Farmer farmer in farmers)
		{
			if (!Game1.multiplayer.isDisconnecting(farmer.UniqueMultiplayerID))
			{
				farmer.DrawUsername(b);
			}
		}
	}

	public virtual void draw(SpriteBatch b)
	{
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0327: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_037b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_0473: Unknown result type (might be due to invalid IL or missing references)
		//IL_0478: Unknown result type (might be due to invalid IL or missing references)
		//IL_047c: Unknown result type (might be due to invalid IL or missing references)
		//IL_054a: Unknown result type (might be due to invalid IL or missing references)
		//IL_054f: Unknown result type (might be due to invalid IL or missing references)
		//IL_059f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0714: Unknown result type (might be due to invalid IL or missing references)
		//IL_0719: Unknown result type (might be due to invalid IL or missing references)
		//IL_0725: Unknown result type (might be due to invalid IL or missing references)
		//IL_072f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0743: Unknown result type (might be due to invalid IL or missing references)
		if (animals.Length > 0)
		{
			foreach (FarmAnimal value2 in animals.Values)
			{
				value2.draw(b);
			}
		}
		if (mapSeats.Count > 0)
		{
			foreach (MapSeat mapSeat in mapSeats)
			{
				mapSeat.Draw(b);
			}
		}
		Rectangle val = default(Rectangle);
		((Rectangle)(ref val))._002Ector(((Rectangle)(ref Game1.viewport)).X, ((Rectangle)(ref Game1.viewport)).Y, ((Rectangle)(ref Game1.viewport)).Width, ((Rectangle)(ref Game1.viewport)).Height);
		((Rectangle)(ref val)).Inflate(128, 128);
		if (this is Woods && Game1.eventUp)
		{
			Event obj = currentEvent;
			if (obj == null || !obj.showGroundObjects)
			{
				goto IL_014d;
			}
		}
		Rectangle renderBounds;
		if (resourceClumps.Count > 0)
		{
			foreach (ResourceClump resourceClump in resourceClumps)
			{
				renderBounds = resourceClump.getRenderBounds();
				if (((Rectangle)(ref renderBounds)).Intersects(val))
				{
					resourceClump.draw(b);
				}
			}
		}
		goto IL_014d;
		IL_014d:
		_currentLocationFarmersForDisambiguating.Clear();
		foreach (Farmer farmer3 in farmers)
		{
			farmer3.drawLayerDisambiguator = 0f;
			_currentLocationFarmersForDisambiguating.Add(farmer3);
		}
		if (_currentLocationFarmersForDisambiguating.Contains(Game1.player))
		{
			_currentLocationFarmersForDisambiguating.Remove(Game1.player);
			_currentLocationFarmersForDisambiguating.Insert(0, Game1.player);
		}
		float num = 0.0001f;
		for (int i = 0; i < _currentLocationFarmersForDisambiguating.Count; i++)
		{
			for (int j = i + 1; j < _currentLocationFarmersForDisambiguating.Count; j++)
			{
				Farmer farmer = _currentLocationFarmersForDisambiguating[i];
				Farmer farmer2 = _currentLocationFarmersForDisambiguating[j];
				if (!farmer2.IsSitting() && Math.Abs(farmer.getDrawLayer() - farmer2.getDrawLayer()) < num && Math.Abs(farmer.position.X - farmer2.position.X) < 64f)
				{
					farmer2.drawLayerDisambiguator += farmer.getDrawLayer() - num - farmer2.getDrawLayer();
				}
			}
		}
		drawCharacters(b);
		drawFarmers(b);
		if (critters != null && Game1.farmEvent == null)
		{
			for (int k = 0; k < critters.Count; k++)
			{
				critters[k].draw(b);
			}
		}
		drawDebris(b);
		if ((!Game1.eventUp || (currentEvent != null && currentEvent.showGroundObjects)) && objects.Length > 0)
		{
			Vector2 val2 = default(Vector2);
			for (int l = ((Rectangle)(ref Game1.viewport)).Y / 64 - 1; l < (((Rectangle)(ref Game1.viewport)).Y + ((Rectangle)(ref Game1.viewport)).Height) / 64 + 3; l++)
			{
				for (int m = ((Rectangle)(ref Game1.viewport)).X / 64 - 1; m < (((Rectangle)(ref Game1.viewport)).X + ((Rectangle)(ref Game1.viewport)).Width) / 64 + 1; m++)
				{
					val2.X = m;
					val2.Y = l;
					if (objects.TryGetValue(val2, out var value))
					{
						value.draw(b, (int)val2.X, (int)val2.Y);
					}
				}
			}
		}
		if (TemporarySprites.Count > 0)
		{
			foreach (TemporaryAnimatedSprite temporarySprite in TemporarySprites)
			{
				if (!temporarySprite.drawAboveAlwaysFront)
				{
					temporarySprite.draw(b);
				}
			}
		}
		interiorDoors.Draw(b);
		NetCollection<LargeTerrainFeature> netCollection = largeTerrainFeatures;
		if (netCollection != null && netCollection.Count > 0)
		{
			foreach (LargeTerrainFeature largeTerrainFeature in largeTerrainFeatures)
			{
				renderBounds = largeTerrainFeature.getRenderBounds();
				if (((Rectangle)(ref renderBounds)).Intersects(val))
				{
					largeTerrainFeature.draw(b);
				}
			}
		}
		if (buildings.Count > 0)
		{
			int num2 = 1;
			((Rectangle)(ref val))._002Ector(((Rectangle)(ref Game1.viewport)).X / 64 - num2, ((Rectangle)(ref Game1.viewport)).Y / 64 - num2, (int)Math.Ceiling((float)((Rectangle)(ref Game1.viewport)).Width / 64f) + 2 * num2, (int)Math.Ceiling((float)((Rectangle)(ref Game1.viewport)).Height / 64f) + 3 + 2 * num2);
			Rectangle val3 = default(Rectangle);
			foreach (Building building in buildings)
			{
				int additionalTilePropertyRadius = building.GetAdditionalTilePropertyRadius();
				Rectangle sourceRect = building.getSourceRect();
				val3.X = building.tileX.Value - additionalTilePropertyRadius;
				val3.Width = building.tilesWide.Value + additionalTilePropertyRadius * 2;
				int num3 = building.tileY.Value + building.tilesHigh.Value + additionalTilePropertyRadius;
				val3.Height = num3 - (val3.Y = num3 - (int)Math.Ceiling((float)sourceRect.Height * 4f / 64f) - additionalTilePropertyRadius);
				if (((Rectangle)(ref val3)).Intersects(val))
				{
					building.draw(b);
				}
			}
		}
		fishSplashAnimation?.draw(b);
		orePanAnimation?.draw(b);
		if (!Game1.eventUp || this is Farm || this is FarmHouse)
		{
			Furniture.isDrawingLocationFurniture = true;
			foreach (Furniture item in furniture)
			{
				if (item.furniture_type.Value != 12)
				{
					item.draw(b, -1, -1);
				}
			}
			Furniture.isDrawingLocationFurniture = false;
		}
		if (showDropboxIndicator && !Game1.eventUp)
		{
			float num4 = 4f * (float)Math.Round(Math.Sin(Game1.currentGameTime.TotalGameTime.TotalMilliseconds / 250.0), 2);
			b.Draw(Game1.mouseCursors2, Game1.GlobalToLocal(Game1.viewport, new Vector2(dropBoxIndicatorLocation.X, dropBoxIndicatorLocation.Y + num4)), (Rectangle?)new Rectangle(114, 53, 6, 10), Color.White, 0f, new Vector2(1f, 4f), 4f, (SpriteEffects)0, 1f);
		}
		if (lightGlows.Count > 0)
		{
			drawLightGlows(b);
		}
	}

	public virtual void drawOverlays(SpriteBatch b)
	{
	}

	public virtual void drawAboveFrontLayer(SpriteBatch b)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		Vector2 key = default(Vector2);
		for (int i = ((Rectangle)(ref Game1.viewport)).Y / 64 - 1; i < (((Rectangle)(ref Game1.viewport)).Y + ((Rectangle)(ref Game1.viewport)).Height) / 64 + 7; i++)
		{
			for (int j = ((Rectangle)(ref Game1.viewport)).X / 64 - 1; j < (((Rectangle)(ref Game1.viewport)).X + ((Rectangle)(ref Game1.viewport)).Width) / 64 + 3; j++)
			{
				key.X = j;
				key.Y = i;
				if (terrainFeatures.TryGetValue(key, out var value) && !(value is Flooring))
				{
					value.draw(b);
				}
			}
		}
	}

	public virtual void drawLightGlows(SpriteBatch b)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		foreach (Vector2 lightGlow in lightGlows)
		{
			if (!lightGlowLayerCache.ContainsKey(lightGlow))
			{
				Furniture furnitureAt = GetFurnitureAt(new Vector2((float)(int)(lightGlow.X / 64f), (float)((int)(lightGlow.Y / 64f) + 2)));
				if (furnitureAt != null && furnitureAt.sourceRect.Height / 16 - furnitureAt.getTilesHigh() > 1)
				{
					lightGlowLayerCache.Add(lightGlow, 2.5f);
				}
				else if (this is FarmHouse { upgradeLevel: >0 } farmHouse)
				{
					((Vector2)(ref val))._002Ector((float)(int)(lightGlow.X / 64f), (float)(int)(lightGlow.Y / 64f));
					Vector2 val2 = Utility.PointToVector2(farmHouse.getKitchenStandingSpot()) - val;
					if (val2.Y == 3f && (val2.X == 2f || val2.X == 3f || val2.X == -1f || val2.X == -2f))
					{
						lightGlowLayerCache.Add(lightGlow, 1.5f);
					}
					else
					{
						lightGlowLayerCache.Add(lightGlow, 10f);
					}
				}
				else
				{
					lightGlowLayerCache.Add(lightGlow, 10f);
				}
			}
			b.Draw(Game1.mouseCursors, Game1.GlobalToLocal(Game1.viewport, lightGlow), (Rectangle?)new Rectangle(21, 1695, 41, 67), Color.White, 0f, new Vector2(19f, 22f), 4f, (SpriteEffects)0, (lightGlow.Y + 64f * lightGlowLayerCache[lightGlow]) / 10000f);
		}
	}

	public Object tryToCreateUnseenSecretNote(Farmer who)
	{
		if (currentEvent != null && currentEvent.isFestival)
		{
			return null;
		}
		bool flag = InIslandContext();
		if (!flag && (who == null || !who.hasMagnifyingGlass))
		{
			return null;
		}
		string itemId = (flag ? "(O)842" : "(O)79");
		int totalNotes;
		int num = Utility.GetUnseenSecretNotes(who, flag, out totalNotes).Length - who.Items.CountId(itemId);
		if (num <= 0)
		{
			return null;
		}
		float num2 = (float)(num - 1) / (float)Math.Max(1, totalNotes - 1);
		float chance = LAST_SECRET_NOTE_CHANCE + (FIRST_SECRET_NOTE_CHANCE - LAST_SECRET_NOTE_CHANCE) * num2;
		if (!Game1.random.NextBool(chance))
		{
			return null;
		}
		return ItemRegistry.Create<Object>(itemId);
	}

	public virtual bool performToolAction(Tool t, int tileX, int tileY)
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		Rectangle boundingBox;
		if (t is MeleeWeapon meleeWeapon)
		{
			foreach (FarmAnimal value in animals.Values)
			{
				boundingBox = value.GetBoundingBox();
				if (((Rectangle)(ref boundingBox)).Intersects(meleeWeapon.mostRecentArea))
				{
					value.hitWithWeapon(meleeWeapon);
				}
			}
		}
		foreach (Building building in buildings)
		{
			if (building.occupiesTile(new Vector2((float)tileX, (float)tileY)))
			{
				building.performToolAction(t, tileX, tileY);
			}
		}
		for (int num = resourceClumps.Count - 1; num >= 0; num--)
		{
			if (resourceClumps[num] != null)
			{
				boundingBox = resourceClumps[num].getBoundingBox();
				if (((Rectangle)(ref boundingBox)).Contains(tileX * 64, tileY * 64) && resourceClumps[num].performToolAction(t, 1, resourceClumps[num].Tile))
				{
					resourceClumps.RemoveAt(num);
					return true;
				}
			}
		}
		Rectangle val = default(Rectangle);
		((Rectangle)(ref val))._002Ector(tileX * 64, tileY * 64, 64, 64);
		foreach (LargeTerrainFeature largeTerrainFeature in largeTerrainFeatures)
		{
			boundingBox = largeTerrainFeature.getBoundingBox();
			if (((Rectangle)(ref boundingBox)).Intersects(val))
			{
				largeTerrainFeature.performToolAction(t, 1, new Vector2((float)tileX, (float)tileY));
			}
		}
		return false;
	}

	public virtual void seasonUpdate(bool onLoad = false)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Expected I4, but got Unknown
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		Season season = GetSeason();
		terrainFeatures.RemoveWhere((KeyValuePair<Vector2, TerrainFeature> pair) => pair.Value.seasonUpdate(onLoad));
		largeTerrainFeatures?.RemoveWhere((LargeTerrainFeature feature) => feature.seasonUpdate(onLoad));
		foreach (NPC character in characters)
		{
			if (!character.IsMonster)
			{
				character.resetSeasonalDialogue();
			}
		}
		if (IsOutdoors && !onLoad)
		{
			KeyValuePair<Vector2, Object>[] array = objects.Pairs.ToArray();
			for (int num = 0; num < array.Length; num++)
			{
				KeyValuePair<Vector2, Object> keyValuePair = array[num];
				Vector2 key = keyValuePair.Key;
				Object value = keyValuePair.Value;
				if (value.IsSpawnedObject && !value.IsBreakableStone())
				{
					objects.Remove(key);
				}
				else if (value.QualifiedItemId == "(O)590" && doesTileHavePropertyNoNull((int)key.X, (int)key.Y, "Diggable", "Back") == "")
				{
					objects.Remove(key);
				}
			}
			numberOfSpawnedObjectsOnMap = 0;
		}
		switch ((int)season)
		{
		case 0:
			waterColor.Value = new Color(120, 200, 255) * 0.5f;
			break;
		case 1:
			waterColor.Value = new Color(60, 240, 255) * 0.5f;
			break;
		case 2:
			waterColor.Value = new Color(255, 130, 200) * 0.5f;
			break;
		case 3:
			waterColor.Value = new Color(130, 80, 255) * 0.5f;
			break;
		}
		if (!onLoad && (int)season == 0 && Game1.stats.DaysPlayed > 1 && !(this is Farm))
		{
			loadWeeds();
		}
	}

	public List<FarmAnimal> getAllFarmAnimals()
	{
		List<FarmAnimal> list = animals.Values.ToList();
		foreach (Building building in buildings)
		{
			GameLocation indoors = building.GetIndoors();
			if (indoors != null)
			{
				list.AddRange(indoors.animals.Values);
			}
		}
		return list;
	}

	public virtual int GetHayCapacity()
	{
		int num = 0;
		foreach (Building building in buildings)
		{
			if (building.hayCapacity.Value > 0 && building.daysOfConstructionLeft.Value <= 0)
			{
				num += building.hayCapacity.Value;
			}
		}
		return num;
	}

	public bool CheckPetAnimal(Vector2 position, Farmer who)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		foreach (FarmAnimal value in animals.Values)
		{
			if (!value.wasPet.Value)
			{
				Rectangle cursorPetBoundingBox = value.GetCursorPetBoundingBox();
				if (((Rectangle)(ref cursorPetBoundingBox)).Contains((int)position.X, (int)position.Y))
				{
					value.pet(who);
					return true;
				}
			}
		}
		return false;
	}

	public bool CheckPetAnimal(Rectangle rect, Farmer who)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		foreach (FarmAnimal value in animals.Values)
		{
			if (!value.wasPet.Value)
			{
				Rectangle boundingBox = value.GetBoundingBox();
				if (((Rectangle)(ref boundingBox)).Intersects(rect))
				{
					value.pet(who);
					return true;
				}
			}
		}
		return false;
	}

	public bool CheckInspectAnimal(Vector2 position, Farmer who)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		foreach (FarmAnimal value in animals.Values)
		{
			if (value.wasPet.Value)
			{
				Rectangle cursorPetBoundingBox = value.GetCursorPetBoundingBox();
				if (((Rectangle)(ref cursorPetBoundingBox)).Contains((int)position.X, (int)position.Y))
				{
					value.pet(who);
					return true;
				}
			}
		}
		return false;
	}

	public bool CheckInspectAnimal(Rectangle rect, Farmer who)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		foreach (FarmAnimal value in animals.Values)
		{
			if (value.wasPet.Value)
			{
				Rectangle boundingBox = value.GetBoundingBox();
				if (((Rectangle)(ref boundingBox)).Intersects(rect))
				{
					value.pet(who);
					return true;
				}
			}
		}
		return false;
	}

	public virtual void updateSeasonalTileSheets(Map map = null)
	{
		if (map == null)
		{
			map = Map;
		}
		if (!(this is Summit) && (!IsOutdoors || Name.Equals("Desert")))
		{
			return;
		}
		map.DisposeTileSheets(Game1.mapDisplayDevice);
		foreach (TileSheet tileSheet in map.TileSheets)
		{
			string imageSource = tileSheet.ImageSource;
			try
			{
				tileSheet.ImageSource = GetSeasonalTilesheetName(tileSheet.ImageSource, GetSeasonKey());
				Game1.mapDisplayDevice.LoadTileSheet(tileSheet);
			}
			catch (Exception exception)
			{
				Game1.log.Error($"Location '{NameOrUniqueName}' failed to load seasonal asset name '{tileSheet.ImageSource}' for tilesheet ID '{((Component)tileSheet).Id}'.", exception);
				tileSheet.ImageSource = imageSource;
			}
		}
		map.LoadTileSheets(Game1.mapDisplayDevice);
	}

	public static string GetSeasonalTilesheetName(string sheet_path, string current_season)
	{
		string fileName = Path.GetFileName(sheet_path);
		if (fileName.StartsWith("spring_") || fileName.StartsWith("summer_") || fileName.StartsWith("fall_") || fileName.StartsWith("winter_"))
		{
			sheet_path = Path.Combine(Path.GetDirectoryName(sheet_path), current_season + fileName.Substring(fileName.IndexOf('_')));
		}
		return sheet_path;
	}

	public virtual string checkEventPrecondition(string precondition)
	{
		return checkEventPrecondition(precondition, check_seen: true);
	}

	public virtual string checkEventPrecondition(string precondition, bool check_seen)
	{
		string[] array = Event.SplitPreconditions(precondition);
		string text = array[0];
		if (string.IsNullOrEmpty(text) || text == "-1")
		{
			return "-1";
		}
		if (check_seen && (Game1.player.eventsSeen.Contains(text) || Game1.eventsSeenSinceLastLocationChange.Contains(text)))
		{
			return "-1";
		}
		for (int i = 1; i < array.Length; i++)
		{
			if (!string.IsNullOrEmpty(array[i]) && !Event.CheckPrecondition(this, array[0], array[i]))
			{
				return "-1";
			}
		}
		return text;
	}

	public static Object GetHayFromAnySilo(GameLocation currentLocation)
	{
		if (TryGetHayFrom(currentLocation, out var hay))
		{
			return hay;
		}
		if (currentLocation.Name != "Farm" && TryGetHayFrom(Game1.getFarm(), out hay))
		{
			return hay;
		}
		Utility.ForEachLocation((GameLocation location) => !TryGetHayFrom(location, out hay), includeInteriors: false);
		return hay;
		static bool TryGetHayFrom(GameLocation location, out Object foundHay)
		{
			if (location.piecesOfHay.Value < 1)
			{
				foundHay = null;
				return false;
			}
			foundHay = ItemRegistry.Create<Object>("(O)178");
			location.piecesOfHay.Value--;
			return true;
		}
	}

	public static int StoreHayInAnySilo(int count, GameLocation currentLocation)
	{
		count = currentLocation.tryToAddHay(count);
		if (count > 0 && currentLocation.Name != "Farm")
		{
			count = Game1.getFarm().tryToAddHay(count);
			if (count <= 0)
			{
				return 0;
			}
		}
		if (count > 0)
		{
			Utility.ForEachLocation(delegate(GameLocation location)
			{
				if (location.buildings.Count > 0)
				{
					count = location.tryToAddHay(count);
					return count > 0;
				}
				return true;
			}, includeInteriors: false);
		}
		if (count <= 0)
		{
			return 0;
		}
		return count;
	}

	public int tryToAddHay(int num)
	{
		int num2 = Math.Min(GetHayCapacity() - piecesOfHay.Value, num);
		piecesOfHay.Value += num2;
		return num - num2;
	}

	public Building getBuildingAt(Vector2 tile)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		foreach (Building building in buildings)
		{
			if (building.occupiesTile(tile) || !building.isTilePassable(tile))
			{
				return building;
			}
		}
		return null;
	}

	public Building getBuildingByType(string type)
	{
		if (type != null)
		{
			foreach (Building building in buildings)
			{
				if (string.Equals(building.buildingType.Value, type, StringComparison.Ordinal))
				{
					return building;
				}
			}
		}
		return null;
	}

	public Building getBuildingById(Guid id)
	{
		if (id != Guid.Empty)
		{
			foreach (Building building in buildings)
			{
				if (building.id.Value == id)
				{
					return building;
				}
			}
		}
		return null;
	}

	public Building getBuildingByName(string name)
	{
		if (name != null)
		{
			foreach (Building building in buildings)
			{
				if (building.HasIndoorsName(name))
				{
					return building;
				}
			}
		}
		return null;
	}

	public bool destroyStructure(Vector2 tile)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		Building buildingAt = getBuildingAt(tile);
		if (buildingAt != null)
		{
			return destroyStructure(buildingAt);
		}
		return false;
	}

	public bool destroyStructure(Building building)
	{
		if (buildings.Remove(building))
		{
			building.performActionOnDemolition(this);
			Game1.player.team.SendBuildingDemolishedEvent(this, building);
			return true;
		}
		return false;
	}

	public bool buildStructure(Building building, Vector2 tileLocation, Farmer who, bool skipSafetyChecks = false)
	{
		//IL_0370: Unknown result type (might be due to invalid IL or missing references)
		//IL_0382: Unknown result type (might be due to invalid IL or missing references)
		//IL_039d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0405: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_056b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0575: Unknown result type (might be due to invalid IL or missing references)
		//IL_057f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0314: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_05eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0602: Unknown result type (might be due to invalid IL or missing references)
		//IL_0608: Unknown result type (might be due to invalid IL or missing references)
		//IL_0611: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		if (!skipSafetyChecks)
		{
			for (int i = 0; i < building.tilesHigh.Value; i++)
			{
				for (int j = 0; j < building.tilesWide.Value; j++)
				{
					pokeTileForConstruction(new Vector2(tileLocation.X + (float)j, tileLocation.Y + (float)i));
				}
			}
			foreach (BuildingPlacementTile additionalPlacementTile in building.GetAdditionalPlacementTiles())
			{
				foreach (Point point in additionalPlacementTile.TileArea.GetPoints())
				{
					pokeTileForConstruction(new Vector2(tileLocation.X + (float)point.X, tileLocation.Y + (float)point.Y));
				}
			}
			Vector2 val = default(Vector2);
			Rectangle boundingBox;
			for (int k = 0; k < building.tilesHigh.Value; k++)
			{
				for (int l = 0; l < building.tilesWide.Value; l++)
				{
					((Vector2)(ref val))._002Ector(tileLocation.X + (float)l, tileLocation.Y + (float)k);
					if (buildings.Contains(building) && building.occupiesTile(val))
					{
						continue;
					}
					if (!isBuildable(val))
					{
						return false;
					}
					foreach (Farmer farmer in farmers)
					{
						boundingBox = farmer.GetBoundingBox();
						if (((Rectangle)(ref boundingBox)).Intersects(new Rectangle(l * 64, k * 64, 64, 64)))
						{
							return false;
						}
					}
				}
			}
			Vector2 val2 = default(Vector2);
			foreach (BuildingPlacementTile additionalPlacementTile2 in building.GetAdditionalPlacementTiles())
			{
				bool onlyNeedsToBePassable = additionalPlacementTile2.OnlyNeedsToBePassable;
				foreach (Point point2 in additionalPlacementTile2.TileArea.GetPoints())
				{
					int x = point2.X;
					int y = point2.Y;
					((Vector2)(ref val2))._002Ector(tileLocation.X + (float)x, tileLocation.Y + (float)y);
					if (buildings.Contains(building) && building.occupiesTile(val2))
					{
						continue;
					}
					if (!isBuildable(val2, onlyNeedsToBePassable))
					{
						return false;
					}
					if (onlyNeedsToBePassable)
					{
						continue;
					}
					foreach (Farmer farmer2 in farmers)
					{
						boundingBox = farmer2.GetBoundingBox();
						if (((Rectangle)(ref boundingBox)).Intersects(new Rectangle(x * 64, y * 64, 64, 64)))
						{
							return false;
						}
					}
				}
			}
			if (building.humanDoor.Value != new Point(-1, -1))
			{
				Vector2 val3 = tileLocation + new Vector2((float)building.humanDoor.X, (float)(building.humanDoor.Y + 1));
				if ((!buildings.Contains(building) || !building.occupiesTile(val3)) && !isBuildable(val3) && !isPath(val3))
				{
					return false;
				}
			}
			string text = building.isThereAnythingtoPreventConstruction(this, tileLocation);
			if (text != null)
			{
				Game1.addHUDMessage(new HUDMessage(text, 3));
				return false;
			}
		}
		building.tileX.Value = (int)tileLocation.X;
		building.tileY.Value = (int)tileLocation.Y;
		Vector2 key = default(Vector2);
		for (int m = 0; m < building.tilesHigh.Value; m++)
		{
			for (int n = 0; n < building.tilesWide.Value; n++)
			{
				((Vector2)(ref key))._002Ector(tileLocation.X + (float)n, tileLocation.Y + (float)m);
				if (!(terrainFeatures.GetValueOrDefault(key) is Flooring) || !(building.GetData()?.AllowsFlooringUnderneath ?? false))
				{
					terrainFeatures.Remove(key);
				}
			}
		}
		if (!buildings.Contains(building))
		{
			buildings.Add(building);
			who.team.SendBuildingConstructedEvent(this, building, who);
		}
		GameLocation indoors = building.GetIndoors();
		if (indoors is AnimalHouse animalHouse)
		{
			foreach (long item in animalHouse.animalsThatLiveHere)
			{
				FarmAnimal value = Utility.getAnimal(item);
				if (value != null)
				{
					value.homeInterior = indoors;
				}
				else if (animalHouse.animals.TryGetValue(item, out value))
				{
					value.homeInterior = indoors;
				}
			}
		}
		if (indoors != null)
		{
			foreach (Warp warp in indoors.warps)
			{
				if (warp.TargetName == NameOrUniqueName)
				{
					warp.TargetX = building.humanDoor.X + building.tileX.Value;
					warp.TargetY = building.humanDoor.Y + building.tileY.Value + 1;
				}
			}
		}
		for (int num = 0; num < building.tilesHigh.Value; num++)
		{
			for (int num2 = 0; num2 < building.tilesWide.Value; num2++)
			{
				RemoveArtifactSpots(new Vector2(tileLocation.X + (float)num2, tileLocation.Y + (float)num));
			}
		}
		foreach (BuildingPlacementTile additionalPlacementTile3 in building.GetAdditionalPlacementTiles())
		{
			if (additionalPlacementTile3.OnlyNeedsToBePassable)
			{
				continue;
			}
			foreach (Point point3 in additionalPlacementTile3.TileArea.GetPoints())
			{
				RemoveArtifactSpots(new Vector2(tileLocation.X + (float)point3.X, tileLocation.Y + (float)point3.Y));
			}
		}
		return true;
		void RemoveArtifactSpots(Vector2 tile_location)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			if (getObjectAtTile((int)tile_location.X, (int)tile_location.Y)?.QualifiedItemId == "(O)590")
			{
				removeObject(tile_location, showDestroyedObject: false);
			}
		}
	}

	public bool buildStructure(string typeId, BuildingData data, Vector2 tileLocation, Farmer who, out Building constructed, bool magicalConstruction = false, bool skipSafetyChecks = false)
	{
		//IL_032a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0393: Unknown result type (might be due to invalid IL or missing references)
		//IL_039d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_031a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		if (data == null || (!skipSafetyChecks && !IsBuildableLocation()))
		{
			constructed = null;
			return false;
		}
		int x = data.Size.X;
		int y = data.Size.Y;
		List<BuildingPlacementTile> list = data.AdditionalPlacementTiles ?? new List<BuildingPlacementTile>(0);
		if (!skipSafetyChecks)
		{
			for (int i = 0; i < y; i++)
			{
				for (int j = 0; j < x; j++)
				{
					pokeTileForConstruction(new Vector2(tileLocation.X + (float)j, tileLocation.Y + (float)i));
				}
			}
			foreach (BuildingPlacementTile item in list)
			{
				foreach (Point point in item.TileArea.GetPoints())
				{
					pokeTileForConstruction(new Vector2(tileLocation.X + (float)point.X, tileLocation.Y + (float)point.Y));
				}
			}
			Vector2 tileLocation2 = default(Vector2);
			Rectangle boundingBox;
			for (int k = 0; k < y; k++)
			{
				for (int l = 0; l < x; l++)
				{
					((Vector2)(ref tileLocation2))._002Ector(tileLocation.X + (float)l, tileLocation.Y + (float)k);
					if (!isBuildable(tileLocation2))
					{
						constructed = null;
						return false;
					}
					foreach (Farmer farmer in farmers)
					{
						boundingBox = farmer.GetBoundingBox();
						if (((Rectangle)(ref boundingBox)).Intersects(new Rectangle(l * 64, k * 64, 64, 64)))
						{
							constructed = null;
							return false;
						}
					}
				}
			}
			Vector2 tileLocation3 = default(Vector2);
			foreach (BuildingPlacementTile item2 in list)
			{
				bool onlyNeedsToBePassable = item2.OnlyNeedsToBePassable;
				foreach (Point point2 in item2.TileArea.GetPoints())
				{
					int x2 = point2.X;
					int y2 = point2.Y;
					((Vector2)(ref tileLocation3))._002Ector(tileLocation.X + (float)x2, tileLocation.Y + (float)y2);
					if (!isBuildable(tileLocation3, onlyNeedsToBePassable))
					{
						constructed = null;
						return false;
					}
					if (onlyNeedsToBePassable)
					{
						continue;
					}
					foreach (Farmer farmer2 in farmers)
					{
						boundingBox = farmer2.GetBoundingBox();
						if (((Rectangle)(ref boundingBox)).Intersects(new Rectangle(x2 * 64, y2 * 64, 64, 64)))
						{
							constructed = null;
							return false;
						}
					}
				}
			}
			if (data.HumanDoor != new Point(-1, -1))
			{
				Vector2 tileLocation4 = tileLocation + new Vector2((float)data.HumanDoor.X, (float)(data.HumanDoor.Y + 1));
				if (!isBuildable(tileLocation4, onlyNeedsToBePassable: true) && !isPath(tileLocation4))
				{
					constructed = null;
					return false;
				}
			}
		}
		Building building = Building.CreateInstanceFromId(typeId, tileLocation);
		if (magicalConstruction)
		{
			building.magical.Value = true;
			building.daysOfConstructionLeft.Value = 0;
		}
		building.owner.Value = who.UniqueMultiplayerID;
		if (!skipSafetyChecks)
		{
			string text = building.isThereAnythingtoPreventConstruction(this, tileLocation);
			if (text != null)
			{
				Game1.addHUDMessage(new HUDMessage(text, 3));
				constructed = null;
				return false;
			}
		}
		Vector2 key = default(Vector2);
		for (int m = 0; m < building.tilesHigh.Value; m++)
		{
			for (int n = 0; n < building.tilesWide.Value; n++)
			{
				((Vector2)(ref key))._002Ector(tileLocation.X + (float)n, tileLocation.Y + (float)m);
				if (!(terrainFeatures.GetValueOrDefault(key) is Flooring) || !(building.GetData()?.AllowsFlooringUnderneath ?? false))
				{
					terrainFeatures.Remove(key);
				}
			}
		}
		buildings.Add(building);
		who.team.SendBuildingConstructedEvent(this, building, who);
		string messageKey = (magicalConstruction ? "BuildingMagicBuild" : "BuildingBuild");
		Game1.multiplayer.globalChatInfoMessage(messageKey, Game1.player.Name, "aOrAn:" + data.Name, data.Name, Game1.player.farmName.Value);
		constructed = building;
		return true;
	}

	public bool buildStructure(string typeId, Vector2 tileLocation, Farmer who, out Building constructed, bool magicalConstruction = false, bool skipSafetyChecks = false)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (typeId == null || !Game1.buildingData.TryGetValue(typeId, out var value))
		{
			Game1.log.Error("Can't construct building '" + typeId + "', no data found matching that ID.");
			constructed = null;
			return false;
		}
		return buildStructure(typeId, value, tileLocation, who, out constructed, magicalConstruction, skipSafetyChecks);
	}

	public bool isBuildingConstructed(string name)
	{
		return getNumberBuildingsConstructed(name) > 0;
	}

	public bool HasMinBuildings(string buildingType, int minCount)
	{
		return getNumberBuildingsConstructed(buildingType) >= minCount;
	}

	public bool HasMinBuildings(Func<Building, bool> match, int minCount)
	{
		if (minCount <= 0)
		{
			return true;
		}
		int num = 0;
		foreach (Building building in buildings)
		{
			if (match(building))
			{
				num++;
			}
			if (num >= minCount)
			{
				return true;
			}
		}
		return false;
	}

	public int getNumberBuildingsConstructed(bool includeUnderConstruction = false)
	{
		if (includeUnderConstruction || buildings.Count == 0)
		{
			return buildings.Count;
		}
		int num = 0;
		foreach (Building building in buildings)
		{
			if (!building.isUnderConstruction())
			{
				num++;
			}
		}
		return num;
	}

	public int getNumberBuildingsConstructed(string name, bool includeUnderConstruction = false)
	{
		int num = 0;
		if (buildings.Count > 0)
		{
			foreach (Building building in buildings)
			{
				if (building.buildingType.Value == name && (includeUnderConstruction || !building.isUnderConstruction()))
				{
					num++;
				}
			}
		}
		return num;
	}

	public bool isThereABuildingUnderConstruction()
	{
		if (buildings.Count > 0)
		{
			foreach (Building building in buildings)
			{
				if (building.isUnderConstruction())
				{
					return true;
				}
			}
		}
		return false;
	}

	public IEnumerable<GameLocation> GetInstancedBuildingInteriors()
	{
		List<GameLocation> interiors = null;
		ForEachInstancedInterior(delegate(GameLocation location)
		{
			if (interiors == null)
			{
				interiors = new List<GameLocation>();
			}
			interiors.Add(location);
			return true;
		});
		if (interiors == null)
		{
			return LegacyShims.EmptyArray<GameLocation>();
		}
		return interiors;
	}

	public void ForEachInstancedInterior(Func<GameLocation, bool> action)
	{
		foreach (Building building in buildings)
		{
			if (building.GetIndoorsType() == IndoorsType.Instanced)
			{
				GameLocation indoors = building.GetIndoors();
				if (indoors != null && !action(indoors))
				{
					break;
				}
			}
		}
	}

	public void ForEachDirt(Func<HoeDirt, bool> action, bool includeGardenPots = true)
	{
		foreach (TerrainFeature value in terrainFeatures.Values)
		{
			if (value is HoeDirt arg && !action(arg))
			{
				return;
			}
		}
		if (!includeGardenPots)
		{
			return;
		}
		using Dictionary<Vector2, Object>.ValueCollection.Enumerator enumerator2 = objects.Values.GetEnumerator();
		while (enumerator2.MoveNext() && (!(enumerator2.Current is IndoorPot indoorPot) || indoorPot.bush.Value != null || action(indoorPot.hoeDirt.Value)))
		{
		}
	}

	public bool isPath(Vector2 tileLocation)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		if (terrainFeatures.TryGetValue(tileLocation, out var value) && value != null && value.isPassable())
		{
			if (objects.TryGetValue(tileLocation, out var value2) && value2 != null)
			{
				return value2.isPassable();
			}
			return true;
		}
		return false;
	}

	public bool isBuildable(Vector2 tileLocation, bool onlyNeedsToBePassable = false)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		Rectangle buildableRectangle = GetBuildableRectangle();
		if (buildableRectangle != Rectangle.Empty && !((Rectangle)(ref buildableRectangle)).Contains((int)tileLocation.X, (int)tileLocation.Y))
		{
			return false;
		}
		if (onlyNeedsToBePassable)
		{
			if (isTilePassable(tileLocation))
			{
				return !IsTileOccupiedBy(tileLocation, CollisionMask.All, CollisionMask.All);
			}
			return false;
		}
		Building buildingAt = getBuildingAt(tileLocation);
		if (buildingAt != null && !buildingAt.isMoving)
		{
			return false;
		}
		if (CanItemBePlacedHere(tileLocation, itemIsPassable: false, CollisionMask.All, ~CollisionMask.Objects, useFarmerTile: true) || getObjectAtTile((int)tileLocation.X, (int)tileLocation.Y)?.QualifiedItemId == "(O)590")
		{
			if (_looserBuildRestrictions)
			{
				return !Game1.currentLocation.doesTileHavePropertyNoNull((int)tileLocation.X, (int)tileLocation.Y, "Buildable", "Back").EqualsIgnoreCase("f");
			}
			if (Game1.currentLocation.doesTileHavePropertyNoNull((int)tileLocation.X, (int)tileLocation.Y, "Buildable", "Back").EqualsIgnoreCase("t") || Game1.currentLocation.doesTileHavePropertyNoNull((int)tileLocation.X, (int)tileLocation.Y, "Buildable", "Back").ToLower().Equals("true"))
			{
				return true;
			}
			if (Game1.currentLocation.doesTileHaveProperty((int)tileLocation.X, (int)tileLocation.Y, "Diggable", "Back") != null && !Game1.currentLocation.doesTileHavePropertyNoNull((int)tileLocation.X, (int)tileLocation.Y, "Buildable", "Back").EqualsIgnoreCase("f"))
			{
				return true;
			}
		}
		return false;
	}

	public virtual void pokeTileForConstruction(Vector2 tile)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		foreach (FarmAnimal value in animals.Values)
		{
			if (value.Tile == tile)
			{
				value.Poke();
			}
		}
	}

	public virtual void updateWarps()
	{
		if (Game1.IsClient)
		{
			return;
		}
		warps.Clear();
		string[] array = new string[2] { "NPCWarp", "Warp" };
		foreach (string text in array)
		{
			if (!((Component)map).Properties.TryGetValue(text, out var value) || value == null)
			{
				continue;
			}
			bool flag = text == "NPCWarp";
			string[] array2 = ArgUtility.SplitBySpace(value);
			for (int j = 0; j < array2.Length; j += 5)
			{
				bool flag2 = array2.Length >= j + 5;
				if (!flag2 || !int.TryParse(array2[j], out var result) || !int.TryParse(array2[j + 1], out var result2) || !int.TryParse(array2[j + 3], out var result3) || !int.TryParse(array2[j + 4], out var result4))
				{
					Game1.log.Warn($"Failed parsing {(flag ? "NPC warp" : "warp")} '{string.Join(" ", array2.Skip(j))}' for location '{NameOrUniqueName}'. Warps must have five fields in the form 'fromX fromY toLocationName toX toY', but " + ((!flag2) ? "got insufficient fields." : "got a non-numeric value for one of the X/Y position fields."));
				}
				else
				{
					warps.Add(new Warp(result, result2, array2[j + 2], result3, result4, flipFarmer: false, flag));
				}
			}
		}
		if (warps.Count > 0)
		{
			ParentBuilding?.updateInteriorWarps(this);
		}
	}

	public void loadWeeds()
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		if (!isOutdoors.Value && !treatAsOutdoors.Value)
		{
			return;
		}
		Map obj = map;
		Layer val = ((obj != null) ? obj.GetLayer("Paths") : null);
		if (val == null)
		{
			return;
		}
		Vector2 val2 = default(Vector2);
		for (int i = 0; i < map.Layers[0].LayerWidth; i++)
		{
			for (int j = 0; j < map.Layers[0].LayerHeight; j++)
			{
				int tileIndexAt = val.GetTileIndexAt(i, j);
				if (tileIndexAt == -1)
				{
					continue;
				}
				((Vector2)(ref val2))._002Ector((float)i, (float)j);
				switch (tileIndexAt)
				{
				case 13:
				case 14:
				case 15:
					if (CanLoadPathObjectHere(val2))
					{
						objects.Add(val2, ItemRegistry.Create<Object>(getWeedForSeason(Game1.random, GetSeason())));
					}
					break;
				case 16:
					if (CanLoadPathObjectHere(val2))
					{
						objects.Add(val2, ItemRegistry.Create<Object>(Game1.random.Choose("(O)343", "(O)450")));
					}
					break;
				case 17:
					if (CanLoadPathObjectHere(val2))
					{
						objects.Add(val2, ItemRegistry.Create<Object>(Game1.random.Choose("(O)343", "(O)450")));
					}
					break;
				case 18:
					if (CanLoadPathObjectHere(val2))
					{
						objects.Add(val2, ItemRegistry.Create<Object>(Game1.random.Choose("(O)294", "(O)295")));
					}
					break;
				}
			}
		}
	}

	public bool CanLoadPathObjectHere(Vector2 tile)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		if (IsTileOccupiedBy(tile, CollisionMask.Buildings | CollisionMask.Flooring | CollisionMask.Objects | CollisionMask.TerrainFeatures))
		{
			return false;
		}
		Vector2 val = tile * 64f;
		val.X += 32f;
		val.Y += 32f;
		foreach (Furniture item in furniture)
		{
			if (item.furniture_type.Value != 12 && !item.isPassable())
			{
				Rectangle boundingBox = item.GetBoundingBox();
				if (((Rectangle)(ref boundingBox)).Contains((int)val.X, (int)val.Y) && !item.AllowPlacementOnThisTile((int)tile.X, (int)tile.Y))
				{
					return false;
				}
			}
		}
		return true;
	}

	public void loadObjects()
	{
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		_startingCabinLocations.Clear();
		if (map == null)
		{
			return;
		}
		updateWarps();
		Layer layer = map.GetLayer("Paths");
		string[] mapPropertySplitBySpaces = GetMapPropertySplitBySpaces("Trees");
		for (int i = 0; i < mapPropertySplitBySpaces.Length; i += 3)
		{
			if (!ArgUtility.TryGetVector2(mapPropertySplitBySpaces, i, out var value, out var error, integerOnly: false, "Vector2 position") || !ArgUtility.TryGetInt(mapPropertySplitBySpaces, i + 2, out var value2, out error, "int treeType"))
			{
				LogMapPropertyError("Trees", mapPropertySplitBySpaces, error);
			}
			else
			{
				terrainFeatures.Add(value, new Tree((value2 + 1).ToString(), 5));
			}
		}
		if (layer != null && TryGetMapProperty("LoadTreesFrom", out var propertyValue))
		{
			GameLocation locationFromName = Game1.getLocationFromName(propertyValue);
			if (locationFromName != null)
			{
				Point val = default(Point);
				foreach (KeyValuePair<Vector2, TerrainFeature> pair in locationFromName.terrainFeatures.Pairs)
				{
					if (pair.Value is Tree tree)
					{
						((Point)(ref val))._002Ector((int)pair.Key.X, (int)pair.Key.Y);
						if (layer.HasTileAt(val.X, val.Y) && TryGetTreeIdForTile(layer.Tiles[val.X, val.Y], out var _, out var _, out var _, out var _))
						{
							terrainFeatures.Add(pair.Key, new Tree(tree.treeType.Value, tree.growthStage.Value));
						}
					}
				}
			}
		}
		if ((isOutdoors.Value || name.Equals("BathHouse_Entry") || treatAsOutdoors.Value || ((IDictionary<string, PropertyValue>)((Component)map).Properties).ContainsKey("forceLoadObjects")) && layer != null)
		{
			loadPathsLayerObjectsInArea(0, 0, map.Layers[0].LayerWidth, map.Layers[0].LayerHeight);
			if (!Game1.eventUp && HasMapPropertyWithValue(((object)GetSeason()/*cast due to .constrained prefix*/).ToString() + "_Objects"))
			{
				spawnObjects();
			}
		}
		updateDoors();
	}

	public void loadPathsLayerObjectsInArea(int startingX, int startingY, int width, int height)
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_038b: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_040f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_039d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0421: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_031a: Unknown result type (might be due to invalid IL or missing references)
		Layer layer = map.GetLayer("Paths");
		Vector2 val2 = default(Vector2);
		Rectangle val3 = default(Rectangle);
		for (int i = startingX; i < startingX + width; i++)
		{
			for (int j = startingY; j < startingY + height; j++)
			{
				Tile val = layer.Tiles[i, j];
				if (val == null)
				{
					continue;
				}
				((Vector2)(ref val2))._002Ector((float)i, (float)j);
				if (TryGetTreeIdForTile(val, out var treeId, out var growthStageOnLoad, out var _, out var isFruitTree))
				{
					if (GetFurnitureAt(val2) == null && !terrainFeatures.ContainsKey(val2) && !objects.ContainsKey(val2))
					{
						if (isFruitTree)
						{
							terrainFeatures.Add(val2, new FruitTree(treeId, growthStageOnLoad ?? 4));
						}
						else
						{
							terrainFeatures.Add(val2, new Tree(treeId, growthStageOnLoad ?? 5));
						}
					}
					continue;
				}
				switch (val.TileIndex)
				{
				case 13:
				case 14:
				case 15:
					if (!objects.ContainsKey(val2) && (!IsOutdoors || !Game1.IsWinter))
					{
						objects.Add(val2, ItemRegistry.Create<Object>(getWeedForSeason(Game1.random, GetSeason())));
					}
					break;
				case 16:
					if (!objects.ContainsKey(val2))
					{
						objects.Add(val2, ItemRegistry.Create<Object>(Game1.random.Choose("(O)343", "(O)450")));
					}
					break;
				case 17:
					if (!objects.ContainsKey(val2))
					{
						objects.Add(val2, ItemRegistry.Create<Object>(Game1.random.Choose("(O)343", "(O)450")));
					}
					break;
				case 18:
					if (!objects.ContainsKey(val2))
					{
						objects.Add(val2, ItemRegistry.Create<Object>(Game1.random.Choose("(O)294", "(O)295")));
					}
					break;
				case 19:
					addResourceClumpAndRemoveUnderlyingTerrain(602, 2, 2, val2);
					break;
				case 20:
					addResourceClumpAndRemoveUnderlyingTerrain(672, 2, 2, val2);
					break;
				case 21:
					addResourceClumpAndRemoveUnderlyingTerrain(600, 2, 2, val2);
					break;
				case 22:
				case 36:
				{
					if (terrainFeatures.ContainsKey(val2))
					{
						break;
					}
					((Rectangle)(ref val3))._002Ector((int)val2.X * 64, (int)val2.Y * 64, 64, 64);
					((Rectangle)(ref val3)).Inflate(-1, -1);
					bool flag = false;
					foreach (ResourceClump resourceClump in resourceClumps)
					{
						Rectangle boundingBox = resourceClump.getBoundingBox();
						if (((Rectangle)(ref boundingBox)).Intersects(val3))
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						terrainFeatures.Add(val2, new Grass((val.TileIndex != 36) ? 1 : 7, 3));
					}
					break;
				}
				case 23:
					if (!terrainFeatures.ContainsKey(val2))
					{
						terrainFeatures.Add(val2, new Tree(Game1.random.Next(1, 4).ToString(), Game1.random.Next(2, 4)));
					}
					break;
				case 24:
					if (!terrainFeatures.ContainsKey(val2))
					{
						largeTerrainFeatures.Add(new Bush(val2, 2, this));
					}
					break;
				case 25:
					if (!terrainFeatures.ContainsKey(val2))
					{
						largeTerrainFeatures.Add(new Bush(val2, 1, this));
					}
					break;
				case 26:
					if (!terrainFeatures.ContainsKey(val2))
					{
						largeTerrainFeatures.Add(new Bush(val2, 0, this));
					}
					break;
				case 33:
					if (!terrainFeatures.ContainsKey(val2))
					{
						largeTerrainFeatures.Add(new Bush(val2, 4, this));
					}
					break;
				case 27:
					changeMapProperties("BrookSounds", val2.X + " " + val2.Y + " 0");
					break;
				case 29:
				case 30:
				{
					if (Game1.startingCabins > 0 && ((Component)val).Properties.TryGetValue("Order", out var value) && int.Parse(value) <= Game1.startingCabins && ((val.TileIndex == 29 && !Game1.cabinsSeparate) || (val.TileIndex == 30 && Game1.cabinsSeparate)))
					{
						_startingCabinLocations.Add(val2);
					}
					break;
				}
				}
			}
		}
	}

	public bool TryGetTreeIdForTile(Tile tile, out string treeId, out int? growthStageOnLoad, out int? growthStageOnRegrow, out bool isFruitTree)
	{
		isFruitTree = false;
		growthStageOnLoad = null;
		growthStageOnRegrow = null;
		if (tile == null)
		{
			treeId = null;
			return false;
		}
		switch (tile.TileIndex)
		{
		case 9:
			treeId = (IsWinterHere() ? "4" : "1");
			return true;
		case 10:
			treeId = (IsWinterHere() ? "5" : "2");
			return true;
		case 11:
			treeId = "3";
			return true;
		case 12:
			treeId = "6";
			return true;
		case 31:
			treeId = "9";
			return true;
		case 32:
			treeId = "8";
			return true;
		case 34:
		{
			if (!((Component)tile).Properties.TryGetValue("SpawnTree", out var value))
			{
				Game1.log.Warn($"Location '{NameOrUniqueName}' ignored path tile index 34 (spawn tree) at position {tile} because the tile has no '{"SpawnTree"}' tile property.");
				break;
			}
			string[] array = ArgUtility.SplitBySpace(value);
			if (!ArgUtility.TryGet(array, 0, out var value2, out var error, allowBlank: true, "string rawType") || !ArgUtility.TryGet(array, 1, out var value3, out error, allowBlank: true, "string rawId") || !ArgUtility.TryGetOptionalInt(array, 2, out var value4, out error, -1, "int rawGrowthStageOnLoad") || !ArgUtility.TryGetOptionalInt(array, 3, out var value5, out error, -1, "int rawGrowthStageOnRegrow"))
			{
				Game1.log.Warn($"Location '{NameOrUniqueName}' ignored path tile index 34 (spawn tree) at position {tile} because the '{"SpawnTree"}' tile property is invalid: {error}.");
				break;
			}
			if (value4 > -1)
			{
				growthStageOnLoad = value4;
			}
			if (value5 > -1)
			{
				growthStageOnRegrow = value5;
			}
			if (value2.EqualsIgnoreCase("wild"))
			{
				treeId = value3;
				return true;
			}
			if (value2.EqualsIgnoreCase("fruit"))
			{
				treeId = value3;
				isFruitTree = true;
				return true;
			}
			Game1.log.Warn($"Location '{NameOrUniqueName}' ignored path tile index 34 (spawn tree) at position {tile} because the '{"SpawnTree"}' tile property has invalid type '{value2}' (expected 'fruit' or 'wild').");
			break;
		}
		}
		growthStageOnLoad = null;
		growthStageOnRegrow = null;
		treeId = null;
		return false;
	}

	public void BuildStartingCabins()
	{
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		if (_startingCabinLocations.Count > 0)
		{
			List<string> list = new List<string>();
			switch (Game1.whichFarm)
			{
			case 3:
			case 4:
				list.Add("Stone Cabin");
				list.Add("Log Cabin");
				list.Add("Plank Cabin");
				list.Add("Rustic Cabin");
				list.Add("Trailer Cabin");
				list.Add("Neighbor Cabin");
				list.Add("Beach Cabin");
				break;
			case 1:
				list.Add("Beach Cabin");
				list.Add("Plank Cabin");
				list.Add("Log Cabin");
				list.Add("Neighbor Cabin");
				list.Add("Trailer Cabin");
				list.Add("Stone Cabin");
				list.Add("Rustic Cabin");
				break;
			default:
			{
				bool flag = Game1.random.NextBool();
				list.Add(flag ? "Log Cabin" : "Plank Cabin");
				list.Add("Stone Cabin");
				list.Add(flag ? "Plank Cabin" : "Log Cabin");
				list.Add("Trailer Cabin");
				list.Add("Neighbor Cabin");
				list.Add("Rustic Cabin");
				list.Add("Beach Cabin");
				break;
			}
			}
			List<Vector2> list2 = new List<Vector2>();
			for (int i = 0; i < _startingCabinLocations.Count; i++)
			{
				for (int j = 0; j < _startingCabinLocations.Count; j++)
				{
					if (doesTileHavePropertyNoNull((int)_startingCabinLocations[j].X, (int)_startingCabinLocations[j].Y, "Order", "Paths").Equals((i + 1).ToString() ?? ""))
					{
						list2.Add(_startingCabinLocations[j]);
					}
				}
			}
			for (int k = 0; k < list2.Count; k++)
			{
				removeObjectsAndSpawned((int)list2[k].X, (int)list2[k].Y, 5, 3);
				removeObjectsAndSpawned((int)list2[k].X + 2, (int)list2[k].Y + 3, 1, 1);
				Building building = new Building("Cabin", list2[k]);
				building.magical.Value = true;
				building.skinId.Value = list[k % list.Count];
				building.daysOfConstructionLeft.Value = 0;
				building.load();
				buildStructure(building, list2[k], Game1.player, skipSafetyChecks: true);
				building.removeOverlappingBushes(this);
			}
		}
		_startingCabinLocations.Clear();
	}

	public void updateDoors()
	{
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.IsClient)
		{
			return;
		}
		doors.Clear();
		Layer val = map.RequireLayer("Buildings");
		int i = 0;
		for (int layerHeight = val.LayerHeight; i < layerHeight; i++)
		{
			int j = 0;
			for (int layerWidth = val.LayerWidth; j < layerWidth; j++)
			{
				Tile val2 = val.Tiles[j, i];
				if (val2 == null || !((Component)val2).Properties.TryGetValue("Action", out var value) || !value.Contains("Warp"))
				{
					continue;
				}
				string[] array = ArgUtility.SplitBySpace(value);
				string text = ArgUtility.Get(array, 0);
				switch (text)
				{
				case "WarpBoatTunnel":
					doors.Add(new Point(j, i), new NetString("BoatTunnel"));
					continue;
				case "WarpCommunityCenter":
					doors.Add(new Point(j, i), new NetString("CommunityCenter"));
					continue;
				case "Warp_Sunroom_Door":
					doors.Add(new Point(j, i), new NetString("Sunroom"));
					continue;
				case "WarpMensLocker":
				case "LockedDoorWarp":
				case "Warp":
				case "WarpWomensLocker":
					break;
				default:
					if (!text.Contains("Warp"))
					{
						continue;
					}
					Game1.log.Warn($"{NameOrUniqueName} ({j}, {i}) has unknown warp property '{value}', parsing with legacy logic.");
					break;
				}
				if (!(name.Value == "Mountain") || j != 8 || i != 20)
				{
					string text2 = ArgUtility.Get(array, 3);
					if (text2 != null)
					{
						doors.Add(new Point(j, i), new NetString(text2));
					}
				}
			}
		}
	}

	[Obsolete("Use removeObjectsAndSpawned instead.")]
	private void clearArea(int startingX, int startingY, int width, int height)
	{
		removeObjectsAndSpawned(startingX, startingY, width, height);
	}

	public bool isTerrainFeatureAt(int x, int y)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		Vector2 key = default(Vector2);
		((Vector2)(ref key))._002Ector((float)x, (float)y);
		if (terrainFeatures.TryGetValue(key, out var value) && !value.isPassable())
		{
			return true;
		}
		if (largeTerrainFeatures != null)
		{
			Rectangle val = default(Rectangle);
			((Rectangle)(ref val))._002Ector(x * 64, y * 64, 64, 64);
			foreach (LargeTerrainFeature largeTerrainFeature in largeTerrainFeatures)
			{
				Rectangle boundingBox = largeTerrainFeature.getBoundingBox();
				if (((Rectangle)(ref boundingBox)).Intersects(val))
				{
					return true;
				}
			}
		}
		return false;
	}

	public void loadLights()
	{
		if ((isOutdoors.Value && !Game1.isFestival() && !forceLoadPathLayerLights) || this is FarmHouse || this is IslandFarmHouse)
		{
			return;
		}
		Layer layer = map.GetLayer("Paths");
		Layer layer2 = map.RequireLayer("Front");
		Layer layer3 = map.RequireLayer("Buildings");
		for (int i = 0; i < map.Layers[0].LayerWidth; i++)
		{
			for (int j = 0; j < map.Layers[0].LayerHeight; j++)
			{
				int tileIndexAt;
				if (!isOutdoors.Value && !((IDictionary<string, PropertyValue>)((Component)map).Properties).ContainsKey("IgnoreLightingTiles"))
				{
					tileIndexAt = layer2.GetTileIndexAt(i, j);
					if (tileIndexAt != -1)
					{
						adjustMapLightPropertiesForLamp(tileIndexAt, i, j, "Front");
					}
					tileIndexAt = layer3.GetTileIndexAt(i, j);
					if (tileIndexAt != -1)
					{
						adjustMapLightPropertiesForLamp(tileIndexAt, i, j, "Buildings");
					}
				}
				tileIndexAt = layer?.GetTileIndexAt(i, j) ?? (-1);
				if (tileIndexAt != -1)
				{
					adjustMapLightPropertiesForLamp(tileIndexAt, i, j, "Paths");
				}
			}
		}
	}

	public bool isFarmBuildingInterior()
	{
		return this is AnimalHouse;
	}

	public bool IsActiveLocation()
	{
		if (Game1.IsMasterGame)
		{
			return true;
		}
		if (Root?.Value != null)
		{
			return Game1.multiplayer.isActiveLocation(this);
		}
		return false;
	}

	public virtual bool CanBeRemotedlyViewed()
	{
		return Game1.multiplayer.isAlwaysActiveLocation(this);
	}

	protected void adjustMapLightPropertiesForLamp(int tile, int x, int y, string layer)
	{
		string tileSheetIDAt = getTileSheetIDAt(x, y, layer);
		if (isFarmBuildingInterior())
		{
			if (tileSheetIDAt == "Coop" || tileSheetIDAt == "barn")
			{
				switch (tile)
				{
				case 24:
					changeMapProperties("DayTiles", layer + " " + x + " " + y + " " + tile);
					changeMapProperties("NightTiles", layer + " " + x + " " + y + " " + 26);
					changeMapProperties("WindowLight", x + " " + (y + 1) + " 4");
					changeMapProperties("WindowLight", x + " " + (y + 3) + " 4");
					break;
				case 25:
					changeMapProperties("DayTiles", layer + " " + x + " " + y + " " + tile);
					changeMapProperties("NightTiles", layer + " " + x + " " + y + " " + 12);
					break;
				case 46:
					changeMapProperties("DayTiles", layer + " " + x + " " + y + " " + tile);
					changeMapProperties("NightTiles", layer + " " + x + " " + y + " " + 53);
					break;
				}
			}
		}
		else if (tile == 8 && layer == "Paths")
		{
			changeMapProperties("Light", x + " " + y + " 4");
		}
		else
		{
			if (!(tileSheetIDAt == "indoor"))
			{
				return;
			}
			switch (tile)
			{
			case 1346:
				changeMapProperties("DayTiles", "Front " + x + " " + y + " " + tile);
				changeMapProperties("NightTiles", "Front " + x + " " + y + " " + 1347);
				changeMapProperties("DayTiles", "Buildings " + x + " " + (y + 1) + " " + 452);
				changeMapProperties("NightTiles", "Buildings " + x + " " + (y + 1) + " " + 453);
				changeMapProperties("Light", x + " " + y + " 4");
				break;
			case 480:
				changeMapProperties("DayTiles", layer + " " + x + " " + y + " " + tile);
				changeMapProperties("NightTiles", layer + " " + x + " " + y + " " + 809);
				changeMapProperties("Light", x + " " + y + " 4");
				break;
			case 826:
				changeMapProperties("DayTiles", layer + " " + x + " " + y + " " + tile);
				changeMapProperties("NightTiles", layer + " " + x + " " + y + " " + 827);
				changeMapProperties("Light", x + " " + y + " 4");
				break;
			case 1344:
				changeMapProperties("DayTiles", layer + " " + x + " " + y + " " + tile);
				changeMapProperties("NightTiles", layer + " " + x + " " + y + " " + 1345);
				changeMapProperties("Light", x + " " + y + " 4");
				break;
			case 256:
				changeMapProperties("DayTiles", layer + " " + x + " " + y + " " + tile);
				changeMapProperties("NightTiles", layer + " " + x + " " + y + " " + 1253);
				changeMapProperties("DayTiles", layer + " " + x + " " + (y + 1) + " " + 288);
				changeMapProperties("NightTiles", layer + " " + x + " " + (y + 1) + " " + 1285);
				changeMapProperties("WindowLight", x + " " + y + " 4");
				changeMapProperties("WindowLight", x + " " + (y + 1) + " 4");
				break;
			case 225:
				if (!name.Value.Contains("BathHouse") && !name.Value.Contains("Club") && (!name.Equals("SeedShop") || (x != 36 && x != 37)))
				{
					changeMapProperties("DayTiles", layer + " " + x + " " + y + " " + tile);
					changeMapProperties("NightTiles", layer + " " + x + " " + y + " " + 1222);
					changeMapProperties("DayTiles", layer + " " + x + " " + (y + 1) + " " + 257);
					changeMapProperties("NightTiles", layer + " " + x + " " + (y + 1) + " " + 1254);
					changeMapProperties("WindowLight", x + " " + y + " 4");
					changeMapProperties("WindowLight", x + " " + (y + 1) + " 4");
				}
				break;
			}
		}
	}

	private void changeMapProperties(string propertyName, string toAdd)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Expected O, but got Unknown
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Expected O, but got Unknown
		try
		{
			if (!((Component)map).Properties.TryGetValue(propertyName, out var value))
			{
				((IDictionary<string, PropertyValue>)((Component)map).Properties)[propertyName] = new PropertyValue(toAdd);
			}
			else if (!value.Contains(toAdd))
			{
				string text = value + " " + toAdd;
				((IDictionary<string, PropertyValue>)((Component)map).Properties)[propertyName] = new PropertyValue(text);
			}
		}
		catch
		{
		}
	}

	public void LogMapPropertyError(string name, string value, string error)
	{
		Game1.log.Error($"Can't parse map property '{name}' with value '{value}' in location '{NameOrUniqueName}': {error}.");
	}

	public void LogMapPropertyError(string name, string[] value, string error, char delimiter = ' ')
	{
		LogMapPropertyError(name, string.Join(delimiter, value), error);
	}

	public void LogTilePropertyError(string name, string layerId, int x, int y, string value, string error)
	{
		Game1.log.Error($"Can't parse tile property '{name}' at {layerId}:{x},{y} with value '{value}' in location '{NameOrUniqueName}': {error}.");
	}

	public void LogTilePropertyError(string name, string layerId, int x, int y, string[] value, string error, char delimiter = ' ')
	{
		LogTilePropertyError(name, layerId, x, y, string.Join(delimiter, value), error);
	}

	public void LogTileActionError(string[] action, int x, int y, string error)
	{
		LogTilePropertyError("Action", "Buildings", x, y, action, error);
	}

	public void LogTileTouchActionError(string[] action, Vector2 tile, string error)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		LogTilePropertyError("TouchAction", "Back", (int)tile.X, (int)tile.Y, action, error);
	}

	public override bool Equals(object obj)
	{
		if (obj is GameLocation other)
		{
			return Equals(other);
		}
		return false;
	}

	public bool Equals(GameLocation other)
	{
		if (other != null && isStructure.Get() == other.isStructure.Get())
		{
			return string.Equals(NameOrUniqueName, other.NameOrUniqueName, StringComparison.Ordinal);
		}
		return false;
	}
}
