using Microsoft.Xna.Framework.Input;

namespace StardewValley;

public class Response
{
	public string responseKey;

	public string responseText;

	public Keys hotkey;

	public Response(string responseKey, string responseText)
	{
		this.responseKey = responseKey;
		this.responseText = responseText;
	}

	public Response SetHotKey(Keys key)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		hotkey = key;
		return this;
	}
}
