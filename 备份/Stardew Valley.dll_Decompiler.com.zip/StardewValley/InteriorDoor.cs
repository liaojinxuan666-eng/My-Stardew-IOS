using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using xTile;
using xTile.Dimensions;
using xTile.Layers;
using xTile.ObjectModel;
using xTile.Tiles;

namespace StardewValley;

public class InteriorDoor : NetField<bool, InteriorDoor>
{
	public GameLocation Location;

	public Point Position;

	public TemporaryAnimatedSprite Sprite;

	public Tile Tile;

	public InteriorDoor()
	{
	}

	public InteriorDoor(GameLocation location, Point position)
		: this()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		Location = location;
		Position = position;
	}

	public override void Set(bool newValue)
	{
		if (newValue != value)
		{
			cleanSet(newValue);
			MarkDirty();
		}
	}

	protected override void ReadDelta(BinaryReader reader, NetVersion version)
	{
		bool interpolationTarget = reader.ReadBoolean();
		if (version.IsPriorityOver(ChangeVersion))
		{
			setInterpolationTarget(interpolationTarget);
		}
	}

	protected override void WriteDelta(BinaryWriter writer)
	{
		writer.Write(targetValue);
	}

	public void ResetLocalState()
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		int x = Position.X;
		int y = Position.Y;
		Location val = default(Location);
		((Location)(ref val))._002Ector(x, y);
		Layer val2 = Location.Map.RequireLayer("Buildings");
		Layer val3 = Location.Map.RequireLayer("Back");
		if (Tile == null)
		{
			Tile = val2.Tiles[val];
		}
		if (Tile == null)
		{
			return;
		}
		if (((Component)Tile).Properties.TryGetValue("Action", out var text) && text.Contains("Door"))
		{
			string[] array = ArgUtility.SplitBySpace(text, 2);
			if (array.Length > 1)
			{
				Tile val4 = val3.Tiles[val];
				if (val4 != null && !((IDictionary<string, PropertyValue>)((Component)val4).Properties).ContainsKey("TouchAction"))
				{
					((IDictionary<string, PropertyValue>)((Component)val4).Properties).Add("TouchAction", PropertyValue.op_Implicit("Door " + array[1]));
				}
			}
		}
		Rectangle sourceRect = default(Rectangle);
		bool flipped = false;
		switch (Tile.TileIndex)
		{
		case 824:
			((Rectangle)(ref sourceRect))._002Ector(640, 144, 16, 48);
			break;
		case 825:
			((Rectangle)(ref sourceRect))._002Ector(640, 144, 16, 48);
			flipped = true;
			break;
		case 838:
			((Rectangle)(ref sourceRect))._002Ector(576, 144, 16, 48);
			if (x == 10 && y == 5)
			{
				flipped = true;
			}
			break;
		case 120:
			((Rectangle)(ref sourceRect))._002Ector(512, 144, 16, 48);
			break;
		}
		Sprite = new TemporaryAnimatedSprite("LooseSprites\\Cursors", sourceRect, 100f, 4, 1, new Vector2((float)x, (float)(y - 2)) * 64f, flicker: false, flipped, (float)((y + 1) * 64 - 12) / 10000f, 0f, Color.White, 4f, 0f, 0f, 0f)
		{
			holdLastFrame = true,
			paused = true
		};
		if (base.Value)
		{
			Sprite.paused = false;
			Sprite.resetEnd();
		}
	}

	public virtual void ApplyMapModifications()
	{
		if (base.Value)
		{
			openDoorTiles();
		}
		else
		{
			closeDoorTiles();
		}
	}

	public void CleanUpLocalState()
	{
		closeDoorTiles();
	}

	private void closeDoorSprite()
	{
		Sprite.reset();
		Sprite.paused = true;
	}

	private void openDoorSprite()
	{
		Sprite.paused = false;
	}

	private void openDoorTiles()
	{
		Location.setTileProperty(Position.X, Position.Y, "Back", "TemporaryBarrier", "T");
		Location.removeTile(Position.X, Position.Y, "Buildings");
		DelayedAction.functionAfterDelay(delegate
		{
			Location.removeTileProperty(Position.X, Position.Y, "Back", "TemporaryBarrier");
		}, 400);
		Location.removeTile(Position.X, Position.Y - 1, "Front");
		Location.removeTile(Position.X, Position.Y - 2, "Front");
	}

	private void closeDoorTiles()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Expected O, but got Unknown
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Expected O, but got Unknown
		Location val = default(Location);
		((Location)(ref val))._002Ector(Position.X, Position.Y);
		Map map = Location.Map;
		if (map != null && Tile != null)
		{
			map.RequireLayer("Buildings").Tiles[val] = Tile;
			Location.removeTileProperty(Position.X, Position.Y, "Back", "TemporaryBarrier");
			val.Y--;
			map.RequireLayer("Front").Tiles[val] = (Tile)new StaticTile(map.RequireLayer("Front"), Tile.TileSheet, (BlendMode)0, Tile.TileIndex - Tile.TileSheet.SheetWidth);
			val.Y--;
			map.RequireLayer("Front").Tiles[val] = (Tile)new StaticTile(map.RequireLayer("Front"), Tile.TileSheet, (BlendMode)0, Tile.TileIndex - Tile.TileSheet.SheetWidth * 2);
		}
	}

	public void Update(GameTime time)
	{
		if (Sprite != null)
		{
			if (base.Value && Sprite.paused)
			{
				openDoorSprite();
				openDoorTiles();
			}
			else if (!base.Value && !Sprite.paused)
			{
				closeDoorSprite();
				closeDoorTiles();
			}
			Sprite.update(time);
		}
	}

	public void Draw(SpriteBatch b)
	{
		Sprite?.draw(b);
	}
}
