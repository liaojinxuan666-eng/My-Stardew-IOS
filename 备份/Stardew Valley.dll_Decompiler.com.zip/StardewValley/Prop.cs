using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xTile.Dimensions;

namespace StardewValley;

public class Prop
{
	private Texture2D texture;

	private Rectangle sourceRect;

	private Rectangle drawRect;

	private Rectangle boundingRect;

	private bool solid;

	public Prop(Texture2D texture, int index, int tilesWideSolid, int tilesHighSolid, int tilesHighDraw, int tileX, int tileY, bool solid = true)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		this.texture = texture;
		sourceRect = Game1.getSourceRectForStandardTileSheet(texture, index, 16, 16);
		sourceRect.Width = tilesWideSolid * 16;
		sourceRect.Height = tilesHighDraw * 16;
		drawRect = new Rectangle(tileX * 64, tileY * 64 + (tilesHighSolid - tilesHighDraw) * 64, tilesWideSolid * 64, tilesHighDraw * 64);
		boundingRect = new Rectangle(tileX * 64, tileY * 64, tilesWideSolid * 64, tilesHighSolid * 64);
		this.solid = solid;
	}

	public bool isColliding(Rectangle r)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		if (solid)
		{
			return ((Rectangle)(ref r)).Intersects(boundingRect);
		}
		return false;
	}

	public void draw(SpriteBatch b)
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		drawRect.X = boundingRect.X - ((Rectangle)(ref Game1.viewport)).X;
		drawRect.Y = boundingRect.Y + (boundingRect.Height - drawRect.Height) - ((Rectangle)(ref Game1.viewport)).Y;
		b.Draw(texture, drawRect, (Rectangle?)sourceRect, Color.White, 0f, Vector2.Zero, (SpriteEffects)0, solid ? ((float)boundingRect.Y / 10000f) : 0f);
	}
}
