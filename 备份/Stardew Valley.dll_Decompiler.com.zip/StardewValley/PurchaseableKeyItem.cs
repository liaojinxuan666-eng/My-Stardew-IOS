using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.ItemTypeDefinitions;

namespace StardewValley;

public class PurchaseableKeyItem : ISalable, IHaveItemTypeId
{
	protected string _displayName = "";

	protected string _name = "";

	protected string _description = "";

	protected int _price;

	protected int _id;

	protected List<string> _tags;

	protected Action<Farmer> _onPurchase;

	public string TypeDefinitionId => "(Salable)";

	public string QualifiedItemId => TypeDefinitionId + "PurchaseableKeyItem." + id;

	public string DisplayName => _displayName;

	public int id => _id;

	public List<string> tags => _tags;

	public string Name => _name;

	public bool IsRecipe
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	public int Stack
	{
		get
		{
			return 1;
		}
		set
		{
		}
	}

	public int Quality
	{
		get
		{
			return 0;
		}
		set
		{
		}
	}

	public PurchaseableKeyItem(string display_name, string display_description, int parent_sheet_index, Action<Farmer> on_purchase = null)
	{
		_id = parent_sheet_index;
		_name = display_name;
		_displayName = display_name;
		_description = display_description;
		_onPurchase = on_purchase;
	}

	public string GetItemTypeId()
	{
		return TypeDefinitionId;
	}

	public void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		spriteBatch.Draw(Game1.objectSpriteSheet, location + new Vector2((float)(int)(32f * scaleSize), (float)(int)(32f * scaleSize)), (Rectangle?)Game1.getSourceRectForStandardTileSheet(Game1.objectSpriteSheet, _id, 16, 16), color * transparency, 0f, new Vector2(8f, 8f) * scaleSize, 4f * scaleSize, (SpriteEffects)0, layerDepth);
	}

	public bool ShouldDrawIcon()
	{
		return true;
	}

	public string getDescription()
	{
		return _description;
	}

	public int maximumStackSize()
	{
		return 1;
	}

	public int addToStack(Item stack)
	{
		return 1;
	}

	public bool canStackWith(ISalable other)
	{
		return false;
	}

	public int sellToStorePrice(long specificPlayerID = -1L)
	{
		return -1;
	}

	public int salePrice(bool ignoreProfitMargins = false)
	{
		return _price;
	}

	public bool appliesProfitMargins()
	{
		return false;
	}

	public bool actionWhenPurchased(string shopId)
	{
		_onPurchase?.Invoke(Game1.player);
		return true;
	}

	public bool CanBuyItem(Farmer farmer)
	{
		return true;
	}

	public bool IsInfiniteStock()
	{
		return false;
	}

	public ISalable GetSalableInstance()
	{
		return this;
	}

	public void FixStackSize()
	{
	}

	public void FixQuality()
	{
	}
}
