using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.BellsAndWhistles;
using StardewValley.Extensions;
using StardewValley.GameData;
using StardewValley.ItemTypeDefinitions;
using xTile.Dimensions;

namespace StardewValley;

public class TemporaryAnimatedSprite
{
	public delegate void endBehavior(int extraInfo);

	public const int FireworkType_Heart = 0;

	public const int FireworkType_Star = 1;

	public const int FireworkType_Junimo = 2;

	public static float[] FireworksLifetimeMultiplier = new float[3] { 1f, 1f, 1.3f };

	public static Color[] FireworksColors = (Color[])(object)new Color[3]
	{
		new Color(252, 56, 37),
		new Color(144, 51, 237),
		new Color(92, 237, 213)
	};

	public static Vector2[][] FireworksLights = new Vector2[3][]
	{
		(Vector2[])(object)new Vector2[1]
		{
			new Vector2(0f, 0f)
		},
		(Vector2[])(object)new Vector2[1]
		{
			new Vector2(0f, 0f)
		},
		(Vector2[])(object)new Vector2[2]
		{
			new Vector2(-2.5f, 0f),
			new Vector2(2.5f, 0f)
		}
	};

	public static Vector2[][] FireworksPoints = new Vector2[3][]
	{
		(Vector2[])(object)new Vector2[14]
		{
			new Vector2(0f, -3f),
			new Vector2(2f, -5f),
			new Vector2(4f, -5f),
			new Vector2(6f, -3f),
			new Vector2(6f, -1f),
			new Vector2(4f, 1f),
			new Vector2(2f, 3f),
			new Vector2(0f, 5f),
			new Vector2(-2f, 3f),
			new Vector2(-4f, 1f),
			new Vector2(-6f, -1f),
			new Vector2(-6f, -3f),
			new Vector2(-4f, -5f),
			new Vector2(-2f, -5f)
		},
		(Vector2[])(object)new Vector2[20]
		{
			new Vector2(0f, -6f),
			new Vector2(1f, -4f),
			new Vector2(2f, -2f),
			new Vector2(4f, -2f),
			new Vector2(6f, -2f),
			new Vector2(4f, 0f),
			new Vector2(2f, 1f),
			new Vector2(3f, 3f),
			new Vector2(4f, 5f),
			new Vector2(2f, 4f),
			new Vector2(0f, 3f),
			new Vector2(-2f, 4f),
			new Vector2(-4f, 5f),
			new Vector2(-3f, 3f),
			new Vector2(-2f, 1f),
			new Vector2(-4f, 0f),
			new Vector2(-6f, -2f),
			new Vector2(-4f, -2f),
			new Vector2(-2f, -2f),
			new Vector2(-1f, -4f)
		},
		(Vector2[])(object)new Vector2[31]
		{
			new Vector2(-1f, -8f),
			new Vector2(0f, -6f),
			new Vector2(0f, -4f),
			new Vector2(2f, -4f),
			new Vector2(4f, -4f),
			new Vector2(6f, -2f),
			new Vector2(8f, -1f),
			new Vector2(9f, -3f),
			new Vector2(8f, -5f),
			new Vector2(6f, 0f),
			new Vector2(6f, 2f),
			new Vector2(3f, 2f),
			new Vector2(3f, 1f),
			new Vector2(5f, 4f),
			new Vector2(3f, 5f),
			new Vector2(3f, 7f),
			new Vector2(1f, 5f),
			new Vector2(-1f, 5f),
			new Vector2(-3f, 7f),
			new Vector2(-3f, 5f),
			new Vector2(-5f, 4f),
			new Vector2(-3f, 2f),
			new Vector2(-3f, 1f),
			new Vector2(-6f, 2f),
			new Vector2(-6f, 0f),
			new Vector2(-8f, -5f),
			new Vector2(-9f, -3f),
			new Vector2(-8f, -1f),
			new Vector2(-6f, -2f),
			new Vector2(-4f, -4f),
			new Vector2(-2f, -4f)
		}
	};

	public float timer;

	public float interval = 200f;

	public int currentParentTileIndex;

	public int oldCurrentParentTileIndex;

	public int initialParentTileIndex;

	public int totalNumberOfLoops;

	public int currentNumberOfLoops;

	public int xStopCoordinate = -1;

	public int yStopCoordinate = -1;

	public int animationLength;

	public int bombRadius;

	public int pingPongMotion = 1;

	public int bombDamage = -1;

	public int fireworkType = -1;

	public bool flicker;

	public bool timeBasedMotion;

	public bool overrideLocationDestroy;

	public bool pingPong;

	public bool holdLastFrame;

	public bool pulse;

	public int extraInfoForEndBehavior;

	public string lightId;

	public int id;

	public bool bigCraftable;

	public bool swordswipe;

	public bool flash;

	public bool flipped;

	public bool verticalFlipped;

	public bool local;

	public bool hasLit;

	public bool xPeriodic;

	public bool yPeriodic;

	public bool destroyable = true;

	public bool paused;

	public bool stopAcceleratingWhenVelocityIsZero;

	public bool positionFollowsAttachedCharacter;

	public bool usePreciseTiming;

	public float rotation;

	public float alpha = 1f;

	public float alphaFade;

	public float layerDepth = -1f;

	public float scale = 1f;

	public float scaleChange;

	public float scaleChangeChange;

	public float rotationChange;

	public float lightRadius;

	public float xPeriodicRange;

	public float yPeriodicRange;

	public float xPeriodicLoopTime;

	public float yPeriodicLoopTime;

	public float shakeIntensityChange;

	public float shakeIntensity;

	public float pulseTime;

	public float pulseAmount = 1.1f;

	public float alphaFadeFade;

	public int lightFade = -1;

	public float afterAccelStopMotionX;

	public float afterAccelStopMotionY;

	public float layerDepthOffset;

	public Vector2 position;

	public Vector2 sourceRectStartingPos;

	protected GameLocation parent;

	public string textureName;

	public Texture2D texture;

	public Rectangle sourceRect;

	public Color color = Color.White;

	public Color lightcolor = Color.White;

	public Farmer owner;

	public Vector2 motion = Vector2.Zero;

	public Vector2 acceleration = Vector2.Zero;

	public Vector2 accelerationChange = Vector2.Zero;

	public Vector2 initialPosition;

	public Vector2 vectorScale;

	public int delayBeforeAnimationStart;

	public int ticksBeforeAnimationStart;

	public string startSound;

	public string endSound;

	public string text;

	public endBehavior endFunction;

	public endBehavior reachedStopCoordinate;

	public Action<TemporaryAnimatedSprite> reachedStopCoordinateSprite;

	public TemporaryAnimatedSprite parentSprite;

	public Character attachedCharacter;

	private float pulseTimer;

	private float originalScale;

	public bool drawAboveAlwaysFront;

	public bool dontClearOnAreaEntry;

	private Stopwatch stopWatch;

	private long previousStopwatchTime;

	protected bool _pooled;

	public static List<TemporaryAnimatedSprite> _pool;

	private float totalTimer;

	public bool Pooled => _pooled;

	public Vector2 Position
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return position;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			position = value;
		}
	}

	public Texture2D Texture => texture;

	public GameLocation Parent
	{
		get
		{
			return parent;
		}
		set
		{
			parent = value;
		}
	}

	public static float GetFireworkLifetimeMultiplier(int id)
	{
		return FireworksLifetimeMultiplier[id];
	}

	public static Color GetFireworkColor(int id)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		return FireworksColors[id];
	}

	public static Vector2[] GetFireworkLights(int id)
	{
		return FireworksLights[id];
	}

	public static Vector2[] GetFireworkPoints(int id)
	{
		return FireworksPoints[id];
	}

	public TemporaryAnimatedSprite getClone()
	{
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		TemporaryAnimatedSprite temporaryAnimatedSprite = GetTemporaryAnimatedSprite();
		temporaryAnimatedSprite.texture = texture;
		temporaryAnimatedSprite.interval = interval;
		temporaryAnimatedSprite.currentParentTileIndex = currentParentTileIndex;
		temporaryAnimatedSprite.oldCurrentParentTileIndex = oldCurrentParentTileIndex;
		temporaryAnimatedSprite.initialParentTileIndex = initialParentTileIndex;
		temporaryAnimatedSprite.totalNumberOfLoops = totalNumberOfLoops;
		temporaryAnimatedSprite.currentNumberOfLoops = currentNumberOfLoops;
		temporaryAnimatedSprite.xStopCoordinate = xStopCoordinate;
		temporaryAnimatedSprite.yStopCoordinate = yStopCoordinate;
		temporaryAnimatedSprite.animationLength = animationLength;
		temporaryAnimatedSprite.bombRadius = bombRadius;
		temporaryAnimatedSprite.bombDamage = bombDamage;
		temporaryAnimatedSprite.pingPongMotion = pingPongMotion;
		temporaryAnimatedSprite.fireworkType = fireworkType;
		temporaryAnimatedSprite.flicker = flicker;
		temporaryAnimatedSprite.timeBasedMotion = timeBasedMotion;
		temporaryAnimatedSprite.overrideLocationDestroy = overrideLocationDestroy;
		temporaryAnimatedSprite.pingPong = pingPong;
		temporaryAnimatedSprite.holdLastFrame = holdLastFrame;
		temporaryAnimatedSprite.extraInfoForEndBehavior = extraInfoForEndBehavior;
		temporaryAnimatedSprite.lightId = lightId;
		temporaryAnimatedSprite.acceleration = acceleration;
		temporaryAnimatedSprite.accelerationChange = accelerationChange;
		temporaryAnimatedSprite.alpha = alpha;
		temporaryAnimatedSprite.alphaFade = alphaFade;
		temporaryAnimatedSprite.attachedCharacter = attachedCharacter;
		temporaryAnimatedSprite.bigCraftable = bigCraftable;
		temporaryAnimatedSprite.color = color;
		temporaryAnimatedSprite.delayBeforeAnimationStart = delayBeforeAnimationStart;
		temporaryAnimatedSprite.ticksBeforeAnimationStart = ticksBeforeAnimationStart;
		temporaryAnimatedSprite.destroyable = destroyable;
		temporaryAnimatedSprite.endFunction = endFunction;
		temporaryAnimatedSprite.endSound = endSound;
		temporaryAnimatedSprite.flash = flash;
		temporaryAnimatedSprite.flipped = flipped;
		temporaryAnimatedSprite.hasLit = hasLit;
		temporaryAnimatedSprite.id = id;
		temporaryAnimatedSprite.initialPosition = initialPosition;
		temporaryAnimatedSprite.lightFade = lightFade;
		temporaryAnimatedSprite.local = local;
		temporaryAnimatedSprite.motion = motion;
		temporaryAnimatedSprite.owner = owner;
		temporaryAnimatedSprite.parent = parent;
		temporaryAnimatedSprite.parentSprite = parentSprite;
		temporaryAnimatedSprite.position = position;
		temporaryAnimatedSprite.rotation = rotation;
		temporaryAnimatedSprite.rotationChange = rotationChange;
		temporaryAnimatedSprite.scale = scale;
		temporaryAnimatedSprite.scaleChange = scaleChange;
		temporaryAnimatedSprite.scaleChangeChange = scaleChangeChange;
		temporaryAnimatedSprite.shakeIntensity = shakeIntensity;
		temporaryAnimatedSprite.shakeIntensityChange = shakeIntensityChange;
		temporaryAnimatedSprite.sourceRect = sourceRect;
		temporaryAnimatedSprite.sourceRectStartingPos = sourceRectStartingPos;
		temporaryAnimatedSprite.startSound = startSound;
		temporaryAnimatedSprite.timeBasedMotion = timeBasedMotion;
		temporaryAnimatedSprite.verticalFlipped = verticalFlipped;
		temporaryAnimatedSprite.xPeriodic = xPeriodic;
		temporaryAnimatedSprite.xPeriodicLoopTime = xPeriodicLoopTime;
		temporaryAnimatedSprite.xPeriodicRange = xPeriodicRange;
		temporaryAnimatedSprite.yPeriodic = yPeriodic;
		temporaryAnimatedSprite.yPeriodicLoopTime = yPeriodicLoopTime;
		temporaryAnimatedSprite.yPeriodicRange = yPeriodicRange;
		temporaryAnimatedSprite.yStopCoordinate = yStopCoordinate;
		temporaryAnimatedSprite.totalNumberOfLoops = totalNumberOfLoops;
		temporaryAnimatedSprite.stopAcceleratingWhenVelocityIsZero = stopAcceleratingWhenVelocityIsZero;
		temporaryAnimatedSprite.afterAccelStopMotionX = afterAccelStopMotionX;
		temporaryAnimatedSprite.afterAccelStopMotionY = afterAccelStopMotionY;
		temporaryAnimatedSprite.layerDepthOffset = layerDepthOffset;
		temporaryAnimatedSprite.positionFollowsAttachedCharacter = positionFollowsAttachedCharacter;
		temporaryAnimatedSprite.dontClearOnAreaEntry = dontClearOnAreaEntry;
		return temporaryAnimatedSprite;
	}

	public virtual void Pool()
	{
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		timer = 0f;
		interval = 200f;
		currentParentTileIndex = 0;
		oldCurrentParentTileIndex = 0;
		initialParentTileIndex = 0;
		totalNumberOfLoops = 0;
		currentNumberOfLoops = 0;
		xStopCoordinate = -1;
		yStopCoordinate = -1;
		animationLength = 0;
		bombRadius = 0;
		pingPongMotion = 1;
		bombDamage = -1;
		fireworkType = -1;
		flicker = false;
		timeBasedMotion = false;
		overrideLocationDestroy = false;
		pingPong = false;
		holdLastFrame = false;
		pulse = false;
		extraInfoForEndBehavior = 0;
		lightId = null;
		bigCraftable = false;
		swordswipe = false;
		flash = false;
		flipped = false;
		verticalFlipped = false;
		local = false;
		hasLit = false;
		xPeriodic = false;
		yPeriodic = false;
		destroyable = true;
		paused = false;
		stopAcceleratingWhenVelocityIsZero = false;
		positionFollowsAttachedCharacter = false;
		rotation = 0f;
		alpha = 1f;
		alphaFade = 0f;
		layerDepth = -1f;
		scale = 1f;
		scaleChange = 0f;
		scaleChangeChange = 0f;
		rotationChange = 0f;
		id = 0;
		lightRadius = 0f;
		xPeriodicRange = 0f;
		yPeriodicRange = 0f;
		xPeriodicLoopTime = 0f;
		yPeriodicLoopTime = 0f;
		shakeIntensityChange = 0f;
		shakeIntensity = 0f;
		pulseTime = 0f;
		pulseAmount = 1.1f;
		alphaFadeFade = 0f;
		lightFade = -1;
		layerDepthOffset = 0f;
		afterAccelStopMotionX = 0f;
		afterAccelStopMotionY = 0f;
		position = Vector2.Zero;
		sourceRectStartingPos = Vector2.Zero;
		parent = null;
		textureName = null;
		texture = null;
		sourceRect = Rectangle.Empty;
		color = Color.White;
		lightcolor = Color.White;
		owner = null;
		motion = Vector2.Zero;
		acceleration = Vector2.Zero;
		accelerationChange = Vector2.Zero;
		initialPosition = Vector2.Zero;
		delayBeforeAnimationStart = 0;
		ticksBeforeAnimationStart = 0;
		startSound = null;
		endSound = null;
		text = null;
		endFunction = null;
		reachedStopCoordinate = null;
		reachedStopCoordinateSprite = null;
		parentSprite = null;
		attachedCharacter = null;
		pulseTimer = 0f;
		originalScale = 0f;
		drawAboveAlwaysFront = false;
		dontClearOnAreaEntry = false;
		_pool.Add(this);
	}

	public static TemporaryAnimatedSprite GetTemporaryAnimatedSprite()
	{
		TemporaryAnimatedSprite temporaryAnimatedSprite = null;
		if (_pool == null)
		{
			_pool = new List<TemporaryAnimatedSprite>();
			for (int i = 0; i < 256; i++)
			{
				TemporaryAnimatedSprite item = new TemporaryAnimatedSprite
				{
					_pooled = true
				};
				_pool.Add(item);
			}
		}
		if (_pool.Count > 0)
		{
			temporaryAnimatedSprite = _pool[_pool.Count - 1];
			_pool.RemoveAt(_pool.Count - 1);
		}
		if (temporaryAnimatedSprite == null)
		{
			temporaryAnimatedSprite = new TemporaryAnimatedSprite();
		}
		return temporaryAnimatedSprite;
	}

	public TemporaryAnimatedSprite()
	{
	}//IL_0069: Unknown result type (might be due to invalid IL or missing references)
	//IL_006e: Unknown result type (might be due to invalid IL or missing references)
	//IL_0074: Unknown result type (might be due to invalid IL or missing references)
	//IL_0079: Unknown result type (might be due to invalid IL or missing references)
	//IL_007f: Unknown result type (might be due to invalid IL or missing references)
	//IL_0084: Unknown result type (might be due to invalid IL or missing references)
	//IL_008a: Unknown result type (might be due to invalid IL or missing references)
	//IL_008f: Unknown result type (might be due to invalid IL or missing references)
	//IL_0095: Unknown result type (might be due to invalid IL or missing references)
	//IL_009a: Unknown result type (might be due to invalid IL or missing references)


	public static TemporaryAnimatedSprite GetTemporaryAnimatedSprite(int initialParentTileIndex, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool flipped)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		TemporaryAnimatedSprite temporaryAnimatedSprite = GetTemporaryAnimatedSprite();
		if (temporaryAnimatedSprite.initialParentTileIndex == -1)
		{
			temporaryAnimatedSprite.swordswipe = true;
			temporaryAnimatedSprite.currentParentTileIndex = 0;
		}
		else
		{
			temporaryAnimatedSprite.currentParentTileIndex = initialParentTileIndex;
		}
		temporaryAnimatedSprite.initialParentTileIndex = initialParentTileIndex;
		temporaryAnimatedSprite.interval = animationInterval;
		temporaryAnimatedSprite.totalNumberOfLoops = numberOfLoops;
		temporaryAnimatedSprite.position = position;
		temporaryAnimatedSprite.animationLength = animationLength;
		temporaryAnimatedSprite.flicker = flicker;
		temporaryAnimatedSprite.flipped = flipped;
		return temporaryAnimatedSprite;
	}

	public TemporaryAnimatedSprite(int initialParentTileIndex, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool flipped)
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		if (initialParentTileIndex == -1)
		{
			swordswipe = true;
			currentParentTileIndex = 0;
		}
		else
		{
			currentParentTileIndex = initialParentTileIndex;
		}
		this.initialParentTileIndex = initialParentTileIndex;
		interval = animationInterval;
		totalNumberOfLoops = numberOfLoops;
		this.position = position;
		this.animationLength = animationLength;
		this.flicker = flicker;
		this.flipped = flipped;
	}

	public static TemporaryAnimatedSprite GetTemporaryAnimatedSprite(int rowInAnimationTexture, Vector2 position, Color color, int animationLength = 8, bool flipped = false, float animationInterval = 100f, int numberOfLoops = 0, int sourceRectWidth = -1, float layerDepth = -1f, int sourceRectHeight = -1, int delay = 0)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		TemporaryAnimatedSprite temporaryAnimatedSprite = GetTemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, rowInAnimationTexture * 64, sourceRectWidth, sourceRectHeight), animationInterval, animationLength, numberOfLoops, position, flicker: false, flipped, layerDepth, 0f, color, 1f, 0f, 0f, 0f);
		if (sourceRectWidth == -1)
		{
			sourceRectWidth = 64;
			temporaryAnimatedSprite.sourceRect.Width = 64;
		}
		if (sourceRectHeight == -1)
		{
			sourceRectHeight = 64;
			temporaryAnimatedSprite.sourceRect.Height = 64;
		}
		if (temporaryAnimatedSprite.layerDepth == -1f)
		{
			temporaryAnimatedSprite.layerDepth = (temporaryAnimatedSprite.position.Y + 32f) / 10000f;
		}
		temporaryAnimatedSprite.delayBeforeAnimationStart = delay;
		return temporaryAnimatedSprite;
	}

	public TemporaryAnimatedSprite(int rowInAnimationTexture, Vector2 position, Color color, int animationLength = 8, bool flipped = false, float animationInterval = 100f, int numberOfLoops = 0, int sourceRectWidth = -1, float layerDepth = -1f, int sourceRectHeight = -1, int delay = 0)
		: this("TileSheets\\animations", new Rectangle(0, rowInAnimationTexture * 64, sourceRectWidth, sourceRectHeight), animationInterval, animationLength, numberOfLoops, position, flicker: false, flipped, layerDepth, 0f, color, 1f, 0f, 0f, 0f)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		if (sourceRectWidth == -1)
		{
			sourceRectWidth = 64;
			sourceRect.Width = 64;
		}
		if (sourceRectHeight == -1)
		{
			sourceRectHeight = 64;
			sourceRect.Height = 64;
		}
		if (layerDepth == -1f)
		{
			layerDepth = (position.Y + 32f) / 10000f;
		}
		delayBeforeAnimationStart = delay;
	}

	public static TemporaryAnimatedSprite GetTemporaryAnimatedSprite(int initialParentTileIndex, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool flipped, bool verticalFlipped, float rotation)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		TemporaryAnimatedSprite temporaryAnimatedSprite = GetTemporaryAnimatedSprite(initialParentTileIndex, animationInterval, animationLength, numberOfLoops, position, flicker, flipped);
		temporaryAnimatedSprite.rotation = rotation;
		temporaryAnimatedSprite.verticalFlipped = verticalFlipped;
		return temporaryAnimatedSprite;
	}

	public TemporaryAnimatedSprite(int initialParentTileIndex, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool flipped, bool verticalFlipped, float rotation)
		: this(initialParentTileIndex, animationInterval, animationLength, numberOfLoops, position, flicker, flipped)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		this.rotation = rotation;
		this.verticalFlipped = verticalFlipped;
	}

	public static TemporaryAnimatedSprite GetTemporaryAnimatedSprite(int initialParentTileIndex, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool bigCraftable, bool flipped)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		TemporaryAnimatedSprite temporaryAnimatedSprite = GetTemporaryAnimatedSprite(initialParentTileIndex, animationInterval, animationLength, numberOfLoops, position, flicker, flipped);
		temporaryAnimatedSprite.bigCraftable = bigCraftable;
		if (temporaryAnimatedSprite.bigCraftable)
		{
			temporaryAnimatedSprite.position.Y -= 64f;
		}
		return temporaryAnimatedSprite;
	}

	public TemporaryAnimatedSprite(int initialParentTileIndex, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool bigCraftable, bool flipped)
		: this(initialParentTileIndex, animationInterval, animationLength, numberOfLoops, position, flicker, flipped)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		this.bigCraftable = bigCraftable;
		if (bigCraftable)
		{
			this.position.Y -= 64f;
		}
	}

	public TemporaryAnimatedSprite GetTemporaryAnimatedSprite(string textureName, Rectangle sourceRect, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool flipped)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		TemporaryAnimatedSprite temporaryAnimatedSprite = GetTemporaryAnimatedSprite(0, animationInterval, animationLength, numberOfLoops, position, flicker, flipped);
		temporaryAnimatedSprite.textureName = textureName;
		temporaryAnimatedSprite.loadTexture();
		temporaryAnimatedSprite.sourceRect = sourceRect;
		temporaryAnimatedSprite.sourceRectStartingPos = new Vector2((float)sourceRect.X, (float)sourceRect.Y);
		temporaryAnimatedSprite.initialPosition = position;
		return temporaryAnimatedSprite;
	}

	public TemporaryAnimatedSprite(string textureName, Rectangle sourceRect, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool flipped)
		: this(0, animationInterval, animationLength, numberOfLoops, position, flicker, flipped)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		this.textureName = textureName;
		loadTexture();
		this.sourceRect = sourceRect;
		sourceRectStartingPos = new Vector2((float)sourceRect.X, (float)sourceRect.Y);
		initialPosition = position;
	}

	public static TemporaryAnimatedSprite GetTemporaryAnimatedSprite(string textureName, Rectangle sourceRect, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool flipped, float layerDepth, float alphaFade, Color color, float scale, float scaleChange, float rotation, float rotationChange, bool local = false)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		TemporaryAnimatedSprite temporaryAnimatedSprite = GetTemporaryAnimatedSprite(0, animationInterval, animationLength, numberOfLoops, position, flicker, flipped);
		temporaryAnimatedSprite.textureName = textureName;
		temporaryAnimatedSprite.loadTexture();
		temporaryAnimatedSprite.sourceRect = sourceRect;
		temporaryAnimatedSprite.sourceRectStartingPos = new Vector2((float)sourceRect.X, (float)sourceRect.Y);
		temporaryAnimatedSprite.layerDepth = layerDepth;
		temporaryAnimatedSprite.alphaFade = Math.Max(0f, alphaFade);
		temporaryAnimatedSprite.color = color;
		temporaryAnimatedSprite.scale = scale;
		temporaryAnimatedSprite.scaleChange = scaleChange;
		temporaryAnimatedSprite.rotation = rotation;
		temporaryAnimatedSprite.rotationChange = rotationChange;
		temporaryAnimatedSprite.local = local;
		temporaryAnimatedSprite.initialPosition = position;
		return temporaryAnimatedSprite;
	}

	public TemporaryAnimatedSprite(string textureName, Rectangle sourceRect, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool flipped, float layerDepth, float alphaFade, Color color, float scale, float scaleChange, float rotation, float rotationChange, bool local = false)
		: this(0, animationInterval, animationLength, numberOfLoops, position, flicker, flipped)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		this.textureName = textureName;
		loadTexture();
		this.sourceRect = sourceRect;
		sourceRectStartingPos = new Vector2((float)sourceRect.X, (float)sourceRect.Y);
		this.layerDepth = layerDepth;
		this.alphaFade = Math.Max(0f, alphaFade);
		this.color = color;
		this.scale = scale;
		this.scaleChange = scaleChange;
		this.rotation = rotation;
		this.rotationChange = rotationChange;
		this.local = local;
		initialPosition = position;
	}

	public virtual void CopyAppearanceFromItemId(string itemId, int offset = 0)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		scale = 4f * scale;
		ParsedItemData dataOrErrorItem = ItemRegistry.GetDataOrErrorItem(itemId);
		textureName = dataOrErrorItem.TextureName;
		loadTexture();
		sourceRect = dataOrErrorItem.GetSourceRect(offset);
		sourceRectStartingPos = Utility.PointToVector2(((Rectangle)(ref sourceRect)).Location);
		currentParentTileIndex = 0;
		initialParentTileIndex = 0;
	}

	public static TemporaryAnimatedSprite GetTemporaryAnimatedSprite(string textureName, Rectangle sourceRect, Vector2 position, bool flipped, float alphaFade, Color color)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		TemporaryAnimatedSprite temporaryAnimatedSprite = GetTemporaryAnimatedSprite(0, 999999f, 1, 0, position, flicker: false, flipped);
		temporaryAnimatedSprite.textureName = textureName;
		temporaryAnimatedSprite.loadTexture();
		temporaryAnimatedSprite.sourceRect = sourceRect;
		temporaryAnimatedSprite.sourceRectStartingPos = new Vector2((float)sourceRect.X, (float)sourceRect.Y);
		temporaryAnimatedSprite.initialPosition = position;
		temporaryAnimatedSprite.alphaFade = Math.Max(0f, alphaFade);
		temporaryAnimatedSprite.color = color;
		return temporaryAnimatedSprite;
	}

	public TemporaryAnimatedSprite(string textureName, Rectangle sourceRect, Vector2 position, bool flipped, float alphaFade, Color color)
		: this(0, 999999f, 1, 0, position, flicker: false, flipped)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		this.textureName = textureName;
		loadTexture();
		this.sourceRect = sourceRect;
		sourceRectStartingPos = new Vector2((float)sourceRect.X, (float)sourceRect.Y);
		initialPosition = position;
		this.alphaFade = Math.Max(0f, alphaFade);
		this.color = color;
	}

	public static TemporaryAnimatedSprite GetTemporaryAnimatedSprite(int initialParentTileIndex, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool flipped, GameLocation parent, Farmer owner)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		TemporaryAnimatedSprite temporaryAnimatedSprite = GetTemporaryAnimatedSprite(initialParentTileIndex, animationInterval, animationLength, numberOfLoops, position, flicker, flipped);
		temporaryAnimatedSprite.position.X = (int)temporaryAnimatedSprite.position.X;
		temporaryAnimatedSprite.position.Y = (int)temporaryAnimatedSprite.position.Y;
		temporaryAnimatedSprite.parent = parent;
		switch (temporaryAnimatedSprite.initialParentTileIndex)
		{
		case 286:
			temporaryAnimatedSprite.bombRadius = 3;
			break;
		case 287:
			temporaryAnimatedSprite.bombRadius = 5;
			break;
		case 288:
			temporaryAnimatedSprite.bombRadius = 7;
			break;
		}
		temporaryAnimatedSprite.owner = owner;
		return temporaryAnimatedSprite;
	}

	public TemporaryAnimatedSprite(int initialParentTileIndex, float animationInterval, int animationLength, int numberOfLoops, Vector2 position, bool flicker, bool flipped, GameLocation parent, Farmer owner)
		: this(initialParentTileIndex, animationInterval, animationLength, numberOfLoops, position, flicker, flipped)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		this.position.X = (int)this.position.X;
		this.position.Y = (int)this.position.Y;
		this.parent = parent;
		switch (initialParentTileIndex)
		{
		case 286:
			bombRadius = 3;
			break;
		case 287:
			bombRadius = 5;
			break;
		case 288:
			bombRadius = 7;
			break;
		}
		this.owner = owner;
	}

	private void loadTexture()
	{
		string text = textureName;
		if (text != null)
		{
			if (text == "")
			{
				texture = Game1.staminaRect;
			}
			else
			{
				texture = Game1.content.Load<Texture2D>(textureName);
			}
		}
		else
		{
			texture = null;
		}
	}

	public void Read(BinaryReader reader, GameLocation location)
	{
		//IL_051d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0522: Unknown result type (might be due to invalid IL or missing references)
		//IL_0536: Unknown result type (might be due to invalid IL or missing references)
		//IL_053b: Unknown result type (might be due to invalid IL or missing references)
		//IL_054f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0554: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_056d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0581: Unknown result type (might be due to invalid IL or missing references)
		//IL_0586: Unknown result type (might be due to invalid IL or missing references)
		//IL_059a: Unknown result type (might be due to invalid IL or missing references)
		//IL_059f: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ea: Unknown result type (might be due to invalid IL or missing references)
		timer = 0f;
		BitArray bitArray = reader.ReadBitArray();
		int num = 0;
		if (bitArray[num++])
		{
			interval = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			currentParentTileIndex = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			oldCurrentParentTileIndex = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			initialParentTileIndex = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			totalNumberOfLoops = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			currentNumberOfLoops = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			xStopCoordinate = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			yStopCoordinate = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			animationLength = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			bombRadius = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			bombDamage = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			pingPongMotion = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			fireworkType = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			flicker = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			timeBasedMotion = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			overrideLocationDestroy = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			pingPong = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			holdLastFrame = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			pulse = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			extraInfoForEndBehavior = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			lightId = reader.ReadString();
		}
		if (bitArray[num++])
		{
			bigCraftable = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			swordswipe = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			flash = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			flipped = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			verticalFlipped = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			local = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			lightFade = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			hasLit = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			xPeriodic = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			yPeriodic = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			destroyable = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			paused = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			rotation = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			alpha = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			alphaFade = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			layerDepth = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			scale = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			scaleChange = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			scaleChangeChange = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			rotationChange = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			id = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			lightRadius = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			xPeriodicRange = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			yPeriodicRange = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			xPeriodicLoopTime = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			yPeriodicLoopTime = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			shakeIntensityChange = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			shakeIntensity = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			pulseTime = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			pulseAmount = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			position = reader.ReadVector2();
		}
		if (bitArray[num++])
		{
			sourceRectStartingPos = reader.ReadVector2();
		}
		if (bitArray[num++])
		{
			sourceRect = reader.ReadRectangle();
		}
		if (bitArray[num++])
		{
			color = reader.ReadColor();
		}
		if (bitArray[num++])
		{
			lightcolor = reader.ReadColor();
		}
		if (bitArray[num++])
		{
			motion = reader.ReadVector2();
		}
		if (bitArray[num++])
		{
			acceleration = reader.ReadVector2();
		}
		if (bitArray[num++])
		{
			accelerationChange = reader.ReadVector2();
		}
		if (bitArray[num++])
		{
			initialPosition = reader.ReadVector2();
		}
		if (bitArray[num++])
		{
			delayBeforeAnimationStart = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			ticksBeforeAnimationStart = reader.ReadInt32();
		}
		if (bitArray[num++])
		{
			startSound = reader.ReadString();
		}
		if (bitArray[num++])
		{
			endSound = reader.ReadString();
		}
		if (bitArray[num++])
		{
			text = reader.ReadString();
		}
		if (bitArray[num++])
		{
			textureName = reader.ReadString();
		}
		if (bitArray[num++])
		{
			owner = Game1.GetPlayer(reader.ReadInt64()) ?? Game1.MasterPlayer;
		}
		if (bitArray[num++])
		{
			stopAcceleratingWhenVelocityIsZero = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			layerDepthOffset = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			afterAccelStopMotionX = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			afterAccelStopMotionY = reader.ReadSingle();
		}
		if (bitArray[num++])
		{
			positionFollowsAttachedCharacter = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			dontClearOnAreaEntry = reader.ReadBoolean();
		}
		if (bitArray[num++])
		{
			drawAboveAlwaysFront = reader.ReadBoolean();
		}
		parent = location;
		loadTexture();
		switch (reader.ReadByte())
		{
		case 1:
			attachedCharacter = Game1.GetPlayer(reader.ReadInt64()) ?? Game1.MasterPlayer;
			break;
		case 2:
		{
			Guid guid = reader.ReadGuid();
			if (!location.characters.ContainsGuid(guid))
			{
				Game1.log.Warn($"Failed to find character with GUID {guid} for TemporaryAniamtedSprite.attachedCharacter");
			}
			else
			{
				attachedCharacter = location.characters[guid];
			}
			break;
		}
		}
	}

	private void checkDirty<T>(BitArray dirtyBits, ref int i, T value, T defaultValue = default(T))
	{
		dirtyBits[i++] = !object.Equals(value, defaultValue);
	}

	public void Write(BinaryWriter writer, GameLocation location)
	{
		//IL_03a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0405: Unknown result type (might be due to invalid IL or missing references)
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0419: Unknown result type (might be due to invalid IL or missing references)
		//IL_041e: Unknown result type (might be due to invalid IL or missing references)
		//IL_042d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0432: Unknown result type (might be due to invalid IL or missing references)
		//IL_0441: Unknown result type (might be due to invalid IL or missing references)
		//IL_0446: Unknown result type (might be due to invalid IL or missing references)
		//IL_0455: Unknown result type (might be due to invalid IL or missing references)
		//IL_045c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0462: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a67: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a80: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a99: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0acb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0afd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b16: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b2f: Unknown result type (might be due to invalid IL or missing references)
		if (GetType() != typeof(TemporaryAnimatedSprite))
		{
			throw new InvalidOperationException("TemporaryAnimatedSprite.Write is not implemented for other types");
		}
		BitArray bitArray = new BitArray(80);
		int i = 0;
		checkDirty(bitArray, ref i, interval, 200f);
		checkDirty(bitArray, ref i, currentParentTileIndex, 0);
		checkDirty(bitArray, ref i, oldCurrentParentTileIndex, 0);
		checkDirty(bitArray, ref i, initialParentTileIndex, 0);
		checkDirty(bitArray, ref i, totalNumberOfLoops, 0);
		checkDirty(bitArray, ref i, currentNumberOfLoops, 0);
		checkDirty(bitArray, ref i, xStopCoordinate, -1);
		checkDirty(bitArray, ref i, yStopCoordinate, -1);
		checkDirty(bitArray, ref i, animationLength, 0);
		checkDirty(bitArray, ref i, bombRadius, 0);
		checkDirty(bitArray, ref i, bombDamage, 0);
		checkDirty(bitArray, ref i, pingPongMotion, -1);
		checkDirty(bitArray, ref i, fireworkType, -1);
		checkDirty(bitArray, ref i, flicker, defaultValue: false);
		checkDirty(bitArray, ref i, timeBasedMotion, defaultValue: false);
		checkDirty(bitArray, ref i, overrideLocationDestroy, defaultValue: false);
		checkDirty(bitArray, ref i, pingPong, defaultValue: false);
		checkDirty(bitArray, ref i, holdLastFrame, defaultValue: false);
		checkDirty(bitArray, ref i, pulse, defaultValue: false);
		checkDirty(bitArray, ref i, extraInfoForEndBehavior, 0);
		checkDirty(bitArray, ref i, lightId);
		checkDirty(bitArray, ref i, bigCraftable, defaultValue: false);
		checkDirty(bitArray, ref i, swordswipe, defaultValue: false);
		checkDirty(bitArray, ref i, flash, defaultValue: false);
		checkDirty(bitArray, ref i, flipped, defaultValue: false);
		checkDirty(bitArray, ref i, verticalFlipped, defaultValue: false);
		checkDirty(bitArray, ref i, local, defaultValue: false);
		checkDirty(bitArray, ref i, lightFade, 0);
		checkDirty(bitArray, ref i, hasLit, defaultValue: false);
		checkDirty(bitArray, ref i, xPeriodic, defaultValue: false);
		checkDirty(bitArray, ref i, yPeriodic, defaultValue: false);
		checkDirty(bitArray, ref i, destroyable, defaultValue: true);
		checkDirty(bitArray, ref i, paused, defaultValue: false);
		checkDirty(bitArray, ref i, rotation, 0f);
		checkDirty(bitArray, ref i, alpha, 1f);
		checkDirty(bitArray, ref i, alphaFade, 0f);
		checkDirty(bitArray, ref i, layerDepth, -1f);
		checkDirty(bitArray, ref i, scale, 1f);
		checkDirty(bitArray, ref i, scaleChange, 0f);
		checkDirty(bitArray, ref i, scaleChangeChange, 0f);
		checkDirty(bitArray, ref i, rotationChange, 0f);
		checkDirty(bitArray, ref i, id, 0);
		checkDirty(bitArray, ref i, lightRadius, 0f);
		checkDirty(bitArray, ref i, xPeriodicRange, 0f);
		checkDirty(bitArray, ref i, yPeriodicRange, 0f);
		checkDirty(bitArray, ref i, xPeriodicLoopTime, 0f);
		checkDirty(bitArray, ref i, yPeriodicLoopTime, 0f);
		checkDirty(bitArray, ref i, shakeIntensityChange, 0f);
		checkDirty(bitArray, ref i, shakeIntensity, 0f);
		checkDirty(bitArray, ref i, pulseTime, 0f);
		checkDirty(bitArray, ref i, pulseAmount, 1.1f);
		checkDirty<Vector2>(bitArray, ref i, position);
		checkDirty<Vector2>(bitArray, ref i, sourceRectStartingPos);
		checkDirty<Rectangle>(bitArray, ref i, sourceRect);
		checkDirty<Color>(bitArray, ref i, color, Color.White);
		checkDirty<Color>(bitArray, ref i, lightcolor, Color.White);
		checkDirty<Vector2>(bitArray, ref i, motion, Vector2.Zero);
		checkDirty<Vector2>(bitArray, ref i, acceleration, Vector2.Zero);
		checkDirty<Vector2>(bitArray, ref i, accelerationChange, Vector2.Zero);
		checkDirty<Vector2>(bitArray, ref i, initialPosition);
		checkDirty(bitArray, ref i, delayBeforeAnimationStart, 0);
		checkDirty(bitArray, ref i, ticksBeforeAnimationStart, 0);
		checkDirty(bitArray, ref i, startSound);
		checkDirty(bitArray, ref i, endSound);
		checkDirty(bitArray, ref i, text);
		checkDirty<Texture2D>(bitArray, ref i, texture);
		checkDirty(bitArray, ref i, owner);
		checkDirty(bitArray, ref i, stopAcceleratingWhenVelocityIsZero, defaultValue: false);
		checkDirty(bitArray, ref i, layerDepthOffset, 0f);
		checkDirty(bitArray, ref i, afterAccelStopMotionX, 0f);
		checkDirty(bitArray, ref i, afterAccelStopMotionY, 0f);
		checkDirty(bitArray, ref i, positionFollowsAttachedCharacter, defaultValue: false);
		checkDirty(bitArray, ref i, dontClearOnAreaEntry, defaultValue: false);
		checkDirty(bitArray, ref i, drawAboveAlwaysFront, defaultValue: false);
		writer.WriteBitArray(bitArray);
		i = 0;
		if (bitArray[i++])
		{
			writer.Write(interval);
		}
		if (bitArray[i++])
		{
			writer.Write(currentParentTileIndex);
		}
		if (bitArray[i++])
		{
			writer.Write(oldCurrentParentTileIndex);
		}
		if (bitArray[i++])
		{
			writer.Write(initialParentTileIndex);
		}
		if (bitArray[i++])
		{
			writer.Write(totalNumberOfLoops);
		}
		if (bitArray[i++])
		{
			writer.Write(currentNumberOfLoops);
		}
		if (bitArray[i++])
		{
			writer.Write(xStopCoordinate);
		}
		if (bitArray[i++])
		{
			writer.Write(yStopCoordinate);
		}
		if (bitArray[i++])
		{
			writer.Write(animationLength);
		}
		if (bitArray[i++])
		{
			writer.Write(bombRadius);
		}
		if (bitArray[i++])
		{
			writer.Write(bombDamage);
		}
		if (bitArray[i++])
		{
			writer.Write(pingPongMotion);
		}
		if (bitArray[i++])
		{
			writer.Write(fireworkType);
		}
		if (bitArray[i++])
		{
			writer.Write(flicker);
		}
		if (bitArray[i++])
		{
			writer.Write(timeBasedMotion);
		}
		if (bitArray[i++])
		{
			writer.Write(overrideLocationDestroy);
		}
		if (bitArray[i++])
		{
			writer.Write(pingPong);
		}
		if (bitArray[i++])
		{
			writer.Write(holdLastFrame);
		}
		if (bitArray[i++])
		{
			writer.Write(pulse);
		}
		if (bitArray[i++])
		{
			writer.Write(extraInfoForEndBehavior);
		}
		if (bitArray[i++])
		{
			writer.Write(lightId);
		}
		if (bitArray[i++])
		{
			writer.Write(bigCraftable);
		}
		if (bitArray[i++])
		{
			writer.Write(swordswipe);
		}
		if (bitArray[i++])
		{
			writer.Write(flash);
		}
		if (bitArray[i++])
		{
			writer.Write(flipped);
		}
		if (bitArray[i++])
		{
			writer.Write(verticalFlipped);
		}
		if (bitArray[i++])
		{
			writer.Write(local);
		}
		if (bitArray[i++])
		{
			writer.Write(lightFade);
		}
		if (bitArray[i++])
		{
			writer.Write(hasLit);
		}
		if (bitArray[i++])
		{
			writer.Write(xPeriodic);
		}
		if (bitArray[i++])
		{
			writer.Write(yPeriodic);
		}
		if (bitArray[i++])
		{
			writer.Write(destroyable);
		}
		if (bitArray[i++])
		{
			writer.Write(paused);
		}
		if (bitArray[i++])
		{
			writer.Write(rotation);
		}
		if (bitArray[i++])
		{
			writer.Write(alpha);
		}
		if (bitArray[i++])
		{
			writer.Write(alphaFade);
		}
		if (bitArray[i++])
		{
			writer.Write(layerDepth);
		}
		if (bitArray[i++])
		{
			writer.Write(scale);
		}
		if (bitArray[i++])
		{
			writer.Write(scaleChange);
		}
		if (bitArray[i++])
		{
			writer.Write(scaleChangeChange);
		}
		if (bitArray[i++])
		{
			writer.Write(rotationChange);
		}
		if (bitArray[i++])
		{
			writer.Write(id);
		}
		if (bitArray[i++])
		{
			writer.Write(lightRadius);
		}
		if (bitArray[i++])
		{
			writer.Write(xPeriodicRange);
		}
		if (bitArray[i++])
		{
			writer.Write(yPeriodicRange);
		}
		if (bitArray[i++])
		{
			writer.Write(xPeriodicLoopTime);
		}
		if (bitArray[i++])
		{
			writer.Write(yPeriodicLoopTime);
		}
		if (bitArray[i++])
		{
			writer.Write(shakeIntensityChange);
		}
		if (bitArray[i++])
		{
			writer.Write(shakeIntensity);
		}
		if (bitArray[i++])
		{
			writer.Write(pulseTime);
		}
		if (bitArray[i++])
		{
			writer.Write(pulseAmount);
		}
		if (bitArray[i++])
		{
			writer.WriteVector2(position);
		}
		if (bitArray[i++])
		{
			writer.WriteVector2(sourceRectStartingPos);
		}
		if (bitArray[i++])
		{
			writer.WriteRectangle(sourceRect);
		}
		if (bitArray[i++])
		{
			writer.WriteColor(color);
		}
		if (bitArray[i++])
		{
			writer.WriteColor(lightcolor);
		}
		if (bitArray[i++])
		{
			writer.WriteVector2(motion);
		}
		if (bitArray[i++])
		{
			writer.WriteVector2(acceleration);
		}
		if (bitArray[i++])
		{
			writer.WriteVector2(accelerationChange);
		}
		if (bitArray[i++])
		{
			writer.WriteVector2(initialPosition);
		}
		if (bitArray[i++])
		{
			writer.Write(delayBeforeAnimationStart);
		}
		if (bitArray[i++])
		{
			writer.Write(ticksBeforeAnimationStart);
		}
		if (bitArray[i++])
		{
			writer.Write(startSound);
		}
		if (bitArray[i++])
		{
			writer.Write(endSound);
		}
		if (bitArray[i++])
		{
			writer.Write(text);
		}
		if (bitArray[i++])
		{
			writer.Write(textureName);
		}
		if (bitArray[i++])
		{
			writer.Write(owner.uniqueMultiplayerID.Value);
		}
		if (bitArray[i++])
		{
			writer.Write(stopAcceleratingWhenVelocityIsZero);
		}
		if (bitArray[i++])
		{
			writer.Write(layerDepthOffset);
		}
		if (bitArray[i++])
		{
			writer.Write(afterAccelStopMotionX);
		}
		if (bitArray[i++])
		{
			writer.Write(afterAccelStopMotionY);
		}
		if (bitArray[i++])
		{
			writer.Write(positionFollowsAttachedCharacter);
		}
		if (bitArray[i++])
		{
			writer.Write(dontClearOnAreaEntry);
		}
		if (bitArray[i++])
		{
			writer.Write(drawAboveAlwaysFront);
		}
		Character character = attachedCharacter;
		if (character != null)
		{
			if (!(character is Farmer farmer))
			{
				if (!(character is NPC item))
				{
					throw new ArgumentException();
				}
				writer.Write((byte)2);
				writer.WriteGuid(location.characters.GuidOf(item));
			}
			else
			{
				writer.Write((byte)1);
				writer.Write(farmer.UniqueMultiplayerID);
			}
		}
		else
		{
			writer.Write((byte)0);
		}
	}

	public virtual void draw(SpriteBatch spriteBatch, bool localPosition = false, int xOffset = 0, int yOffset = 0, float extraAlpha = 1f)
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0602: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_060d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0617: Unknown result type (might be due to invalid IL or missing references)
		//IL_061e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0644: Unknown result type (might be due to invalid IL or missing references)
		//IL_0651: Unknown result type (might be due to invalid IL or missing references)
		//IL_0458: Unknown result type (might be due to invalid IL or missing references)
		//IL_0427: Unknown result type (might be due to invalid IL or missing references)
		//IL_042d: Unknown result type (might be due to invalid IL or missing references)
		//IL_043c: Unknown result type (might be due to invalid IL or missing references)
		//IL_044b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0450: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_0797: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_070a: Unknown result type (might be due to invalid IL or missing references)
		//IL_070f: Unknown result type (might be due to invalid IL or missing references)
		//IL_071e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0728: Unknown result type (might be due to invalid IL or missing references)
		//IL_072d: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0479: Unknown result type (might be due to invalid IL or missing references)
		//IL_0484: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_078a: Unknown result type (might be due to invalid IL or missing references)
		//IL_078f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0507: Unknown result type (might be due to invalid IL or missing references)
		//IL_050e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0535: Unknown result type (might be due to invalid IL or missing references)
		//IL_036c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_0377: Unknown result type (might be due to invalid IL or missing references)
		//IL_0382: Unknown result type (might be due to invalid IL or missing references)
		//IL_038d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0818: Unknown result type (might be due to invalid IL or missing references)
		//IL_0565: Unknown result type (might be due to invalid IL or missing references)
		//IL_03eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		if (local)
		{
			localPosition = true;
		}
		if (currentParentTileIndex < 0 || delayBeforeAnimationStart > 0 || ticksBeforeAnimationStart > 0)
		{
			return;
		}
		if (text != null)
		{
			if (extraInfoForEndBehavior == -777)
			{
				Vector2 val = Game1.GlobalToLocal(position);
				SpriteText.drawString(spriteBatch, text, (int)val.X, (int)val.Y, 999999, -1, 999999, alpha, layerDepth, junimoText: false, -1, "", ((Color)(ref color)).Equals(Color.White) ? SpriteText.color_White : SpriteText.color_Black);
			}
			else
			{
				spriteBatch.DrawString(Game1.dialogueFont, text, localPosition ? Position : Game1.GlobalToLocal(Game1.viewport, Position), color * alpha * extraAlpha, rotation, Vector2.Zero, scale, (SpriteEffects)0, layerDepth + layerDepthOffset);
			}
		}
		else if (Texture != null)
		{
			if (positionFollowsAttachedCharacter && attachedCharacter != null)
			{
				spriteBatch.Draw(Texture, (localPosition ? Position : Game1.GlobalToLocal(Game1.viewport, attachedCharacter.Position + new Vector2((float)((int)Position.X + xOffset), (float)((int)Position.Y + yOffset)))) + new Vector2((float)(sourceRect.Width / 2), (float)(sourceRect.Height / 2)) * scale + new Vector2((float)((shakeIntensity > 0f) ? Game1.random.Next(-(int)shakeIntensity, (int)shakeIntensity + 1) : 0), (float)((shakeIntensity > 0f) ? Game1.random.Next(-(int)shakeIntensity, (int)shakeIntensity + 1) : 0)), (Rectangle?)sourceRect, color * alpha * extraAlpha, rotation, new Vector2((float)(sourceRect.Width / 2), (float)(sourceRect.Height / 2)), scale, (SpriteEffects)(flipped ? 1 : (verticalFlipped ? 2 : 0)), ((layerDepth >= 0f) ? layerDepth : ((Position.Y + (float)sourceRect.Height) / 10000f)) + layerDepthOffset);
			}
			else if (!((Vector2)(ref vectorScale)).Equals(Vector2.Zero))
			{
				spriteBatch.Draw(Texture, (localPosition ? Position : Game1.GlobalToLocal(Game1.viewport, new Vector2((float)((int)Position.X + xOffset), (float)((int)Position.Y + yOffset)))) + new Vector2((float)((shakeIntensity > 0f) ? Game1.random.Next(-(int)shakeIntensity, (int)shakeIntensity + 1) : 0), (float)((shakeIntensity > 0f) ? Game1.random.Next(-(int)shakeIntensity, (int)shakeIntensity + 1) : 0)), (Rectangle?)sourceRect, color * alpha * extraAlpha, rotation, new Vector2((float)(sourceRect.Width / 2), (float)(sourceRect.Height / 2)), vectorScale, (SpriteEffects)(flipped ? 1 : (verticalFlipped ? 2 : 0)), ((layerDepth >= 0f) ? layerDepth : ((Position.Y + (float)sourceRect.Height) / 10000f)) + layerDepthOffset);
			}
			else
			{
				spriteBatch.Draw(Texture, (localPosition ? Position : Game1.GlobalToLocal(Game1.viewport, new Vector2((float)((int)Position.X + xOffset), (float)((int)Position.Y + yOffset)))) + new Vector2((float)(sourceRect.Width / 2), (float)(sourceRect.Height / 2)) * scale + new Vector2((float)((shakeIntensity > 0f) ? Game1.random.Next(-(int)shakeIntensity, (int)shakeIntensity + 1) : 0), (float)((shakeIntensity > 0f) ? Game1.random.Next(-(int)shakeIntensity, (int)shakeIntensity + 1) : 0)), (Rectangle?)sourceRect, color * alpha * extraAlpha, rotation, new Vector2((float)(sourceRect.Width / 2), (float)(sourceRect.Height / 2)), scale, (SpriteEffects)(flipped ? 1 : (verticalFlipped ? 2 : 0)), ((layerDepth >= 0f) ? layerDepth : ((Position.Y + (float)sourceRect.Height) / 10000f)) + layerDepthOffset);
			}
		}
		else if (bigCraftable)
		{
			spriteBatch.Draw(Game1.bigCraftableSpriteSheet, localPosition ? Position : (Game1.GlobalToLocal(Game1.viewport, new Vector2((float)((int)Position.X + xOffset), (float)((int)Position.Y + yOffset))) + new Vector2((float)(sourceRect.Width / 2), (float)(sourceRect.Height / 2))), (Rectangle?)Object.getSourceRectForBigCraftable(currentParentTileIndex), Color.White * extraAlpha, 0f, new Vector2((float)(sourceRect.Width / 2), (float)(sourceRect.Height / 2)), scale, (SpriteEffects)0, (Position.Y + 32f) / 10000f + layerDepthOffset);
		}
		else
		{
			if (swordswipe)
			{
				return;
			}
			if (attachedCharacter != null)
			{
				if (local)
				{
					attachedCharacter.Position = new Vector2((float)((Rectangle)(ref Game1.viewport)).X + Position.X, (float)((Rectangle)(ref Game1.viewport)).Y + Position.Y);
				}
				attachedCharacter.draw(spriteBatch);
			}
			else
			{
				spriteBatch.Draw(Game1.objectSpriteSheet, localPosition ? Position : (Game1.GlobalToLocal(Game1.viewport, new Vector2((float)((int)Position.X + xOffset), (float)((int)Position.Y + yOffset))) + new Vector2(8f, 8f) * 4f + new Vector2((float)((shakeIntensity > 0f) ? Game1.random.Next(-(int)shakeIntensity, (int)shakeIntensity + 1) : 0), (float)((shakeIntensity > 0f) ? Game1.random.Next(-(int)shakeIntensity, (int)shakeIntensity + 1) : 0))), (Rectangle?)GameLocation.getSourceRectForObject(currentParentTileIndex), (flash ? (Color.LightBlue * 0.85f) : color) * alpha * extraAlpha, rotation, new Vector2(8f, 8f), 4f * scale, (SpriteEffects)(flipped ? 1 : 0), ((layerDepth >= 0f) ? layerDepth : ((Position.Y + 32f) / 10000f)) + layerDepthOffset);
			}
		}
	}

	public void bounce(int extraInfo)
	{
		if ((float)extraInfo > 1f)
		{
			motion.Y = (float)(-extraInfo) / 2f;
			motion.X /= 2f;
			rotationChange = motion.Y / 50f;
			acceleration.Y = 0.7f;
			yStopCoordinate = (int)initialPosition.Y;
			parent?.playSound("thudStep");
		}
		else
		{
			if (extraInfoForEndBehavior != -777)
			{
				alphaFade = 0.01f;
			}
			motion.X = 0f;
		}
	}

	public void unload()
	{
		PlaySound(endSound);
		endFunction?.Invoke(extraInfoForEndBehavior);
		if (hasLit)
		{
			Utility.removeLightSource(lightId);
		}
	}

	public void reset()
	{
		sourceRect.X = (int)sourceRectStartingPos.X;
		sourceRect.Y = (int)sourceRectStartingPos.Y;
		currentParentTileIndex = 0;
		oldCurrentParentTileIndex = 0;
		timer = 0f;
		totalTimer = 0f;
		currentNumberOfLoops = 0;
		pingPongMotion = 1;
	}

	public void resetEnd()
	{
		reset();
		currentParentTileIndex = initialParentTileIndex + animationLength - 1;
	}

	public virtual bool update(GameTime time)
	{
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0807: Unknown result type (might be due to invalid IL or missing references)
		//IL_080c: Unknown result type (might be due to invalid IL or missing references)
		//IL_078a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0799: Unknown result type (might be due to invalid IL or missing references)
		//IL_079e: Unknown result type (might be due to invalid IL or missing references)
		//IL_07af: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d0f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d6b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d70: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d7d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d8d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dbe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dc0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dc6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dcf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dd7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dde: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0df0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e50: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e6a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ee7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f51: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f57: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f5b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f60: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f66: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f68: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f6f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f74: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff5: Unknown result type (might be due to invalid IL or missing references)
		//IL_100d: Unknown result type (might be due to invalid IL or missing references)
		//IL_101e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1020: Unknown result type (might be due to invalid IL or missing references)
		//IL_1025: Unknown result type (might be due to invalid IL or missing references)
		//IL_105b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1062: Unknown result type (might be due to invalid IL or missing references)
		//IL_1067: Unknown result type (might be due to invalid IL or missing references)
		//IL_106d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1071: Unknown result type (might be due to invalid IL or missing references)
		//IL_1076: Unknown result type (might be due to invalid IL or missing references)
		//IL_107c: Unknown result type (might be due to invalid IL or missing references)
		//IL_107e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1085: Unknown result type (might be due to invalid IL or missing references)
		//IL_108a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1097: Unknown result type (might be due to invalid IL or missing references)
		//IL_111b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1120: Unknown result type (might be due to invalid IL or missing references)
		//IL_1137: Unknown result type (might be due to invalid IL or missing references)
		//IL_1148: Unknown result type (might be due to invalid IL or missing references)
		//IL_1159: Unknown result type (might be due to invalid IL or missing references)
		//IL_115f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1164: Unknown result type (might be due to invalid IL or missing references)
		//IL_1184: Unknown result type (might be due to invalid IL or missing references)
		//IL_118b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1190: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_11b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_11b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_11bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_11bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_11cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_11d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_11e1: Unknown result type (might be due to invalid IL or missing references)
		if (paused)
		{
			return false;
		}
		int num = (int)time.ElapsedGameTime.TotalMilliseconds;
		if (usePreciseTiming)
		{
			if (stopWatch == null)
			{
				stopWatch = new Stopwatch();
				stopWatch.Start();
			}
			num = (int)(stopWatch.ElapsedMilliseconds - previousStopwatchTime);
			previousStopwatchTime = stopWatch.ElapsedMilliseconds;
		}
		if (bombRadius > 0 && !Game1.shouldTimePass())
		{
			return false;
		}
		if (ticksBeforeAnimationStart > 0)
		{
			ticksBeforeAnimationStart--;
			return false;
		}
		if (delayBeforeAnimationStart > 0)
		{
			delayBeforeAnimationStart -= num;
			if (delayBeforeAnimationStart <= 0)
			{
				PlaySound(startSound);
				timer = -delayBeforeAnimationStart;
			}
			if (delayBeforeAnimationStart <= 0 && parentSprite != null)
			{
				position = parentSprite.position + position;
			}
			return false;
		}
		if (float.IsNaN(motion.X))
		{
			motion.X = 0f;
		}
		if (float.IsNaN(motion.Y))
		{
			motion.Y = 0f;
		}
		timer += num;
		totalTimer += num;
		alpha -= alphaFade * (float)((!timeBasedMotion) ? 1 : num);
		alphaFade -= alphaFadeFade * (float)((!timeBasedMotion) ? 1 : num);
		if (alphaFade > 0f && lightId != null && alpha < 1f && alpha >= 0f)
		{
			LightSource lightSource = Utility.getLightSource(lightId);
			if (lightSource != null)
			{
				lightSource.color.A = (byte)(255f * alpha);
			}
		}
		shakeIntensity += shakeIntensityChange * (float)num;
		scale += scaleChange * (float)((!timeBasedMotion) ? 1 : num);
		scaleChange += scaleChangeChange * (float)((!timeBasedMotion) ? 1 : num);
		rotation += rotationChange;
		if (xPeriodic)
		{
			position.X = initialPosition.X + xPeriodicRange * (float)Math.Sin(Math.PI * 2.0 / (double)xPeriodicLoopTime * (double)totalTimer);
		}
		else
		{
			position.X += motion.X * (float)((!timeBasedMotion) ? 1 : num);
		}
		if (yPeriodic)
		{
			position.Y = initialPosition.Y + yPeriodicRange * (float)Math.Sin(Math.PI * 2.0 / (double)yPeriodicLoopTime * (double)(totalTimer + yPeriodicLoopTime / 2f));
		}
		else
		{
			position.Y += motion.Y * (float)((!timeBasedMotion) ? 1 : num);
		}
		if (attachedCharacter != null && !positionFollowsAttachedCharacter)
		{
			if (xPeriodic)
			{
				attachedCharacter.position.X = initialPosition.X + xPeriodicRange * (float)Math.Sin(Math.PI * 2.0 / (double)xPeriodicLoopTime * (double)totalTimer);
			}
			else
			{
				attachedCharacter.position.X += motion.X * (float)((!timeBasedMotion) ? 1 : num);
			}
			if (yPeriodic)
			{
				attachedCharacter.position.Y = initialPosition.Y + yPeriodicRange * (float)Math.Sin(Math.PI * 2.0 / (double)yPeriodicLoopTime * (double)totalTimer);
			}
			else
			{
				attachedCharacter.position.Y += motion.Y * (float)((!timeBasedMotion) ? 1 : num);
			}
		}
		int num2 = Math.Sign(motion.X);
		motion.X += acceleration.X * (float)((!timeBasedMotion) ? 1 : num);
		if (stopAcceleratingWhenVelocityIsZero && Math.Sign(motion.X) != num2)
		{
			motion.X = afterAccelStopMotionX;
			acceleration.X = 0f;
			accelerationChange.X = 0f;
		}
		num2 = Math.Sign(motion.Y);
		motion.Y += acceleration.Y * (float)((!timeBasedMotion) ? 1 : num);
		if (stopAcceleratingWhenVelocityIsZero && Math.Sign(motion.Y) != num2)
		{
			motion.Y = afterAccelStopMotionY;
			acceleration.Y = 0f;
			accelerationChange.Y = 0f;
		}
		acceleration.X += accelerationChange.X;
		acceleration.Y += accelerationChange.Y;
		if (xStopCoordinate != -1 || yStopCoordinate != -1)
		{
			int extraInfo = (int)motion.Y;
			if (xStopCoordinate != -1 && Math.Abs(position.X - (float)xStopCoordinate) <= Math.Abs(motion.X))
			{
				motion.X = 0f;
				acceleration.X = 0f;
				xStopCoordinate = -1;
			}
			if (yStopCoordinate != -1 && Math.Abs(position.Y - (float)yStopCoordinate) <= Math.Abs(motion.Y))
			{
				motion.Y = 0f;
				acceleration.Y = 0f;
				yStopCoordinate = -1;
			}
			if (xStopCoordinate == -1 && yStopCoordinate == -1)
			{
				rotationChange = 0f;
				reachedStopCoordinate?.Invoke(extraInfo);
				reachedStopCoordinateSprite?.Invoke(this);
			}
		}
		if (!pingPong)
		{
			pingPongMotion = 1;
		}
		if (pulse)
		{
			pulseTimer -= num;
			if (originalScale == 0f)
			{
				originalScale = scale;
			}
			if (pulseTimer <= 0f)
			{
				pulseTimer = pulseTime;
				scale = originalScale * pulseAmount;
			}
			if (scale > originalScale)
			{
				scale -= pulseAmount / 100f * (float)num;
			}
		}
		if (lightId != null)
		{
			if (!hasLit)
			{
				hasLit = true;
				if (parent == null || Game1.currentLocation == parent)
				{
					Game1.currentLightSources.Add(new LightSource(lightId, 4, position + new Vector2(32f, 32f), lightRadius, (Color)(((Color)(ref lightcolor)).Equals(Color.White) ? new Color(0, 65, 128) : lightcolor), LightSource.LightContext.None, 0L)
					{
						fadeOut = { lightFade }
					});
				}
			}
			else
			{
				Utility.repositionLightSource(lightId, position + new Vector2(32f, 32f));
			}
		}
		if (alpha <= 0f || (position.X < -2000f && !overrideLocationDestroy) || scale <= 0f)
		{
			unload();
			return destroyable;
		}
		if (timer > interval)
		{
			currentParentTileIndex += pingPongMotion;
			sourceRect.X += sourceRect.Width * pingPongMotion;
			if (Texture != null)
			{
				if (!pingPong && sourceRect.X >= Texture.Width)
				{
					sourceRect.Y += sourceRect.Height;
				}
				if (!pingPong)
				{
					sourceRect.X %= Texture.Width;
				}
				if (pingPong)
				{
					if ((float)sourceRect.X + ((float)sourceRect.Y - sourceRectStartingPos.Y) / (float)sourceRect.Height * (float)Texture.Width >= sourceRectStartingPos.X + (float)(sourceRect.Width * animationLength))
					{
						pingPongMotion = -1;
						sourceRect.X -= sourceRect.Width * 2;
						currentParentTileIndex--;
						if (sourceRect.X < 0)
						{
							sourceRect.X = Texture.Width + sourceRect.X;
						}
					}
					else if ((float)sourceRect.X < sourceRectStartingPos.X && (float)sourceRect.Y == sourceRectStartingPos.Y)
					{
						pingPongMotion = 1;
						sourceRect.X = (int)sourceRectStartingPos.X + sourceRect.Width;
						currentParentTileIndex++;
						currentNumberOfLoops++;
						if (endFunction != null)
						{
							endFunction(extraInfoForEndBehavior);
							endFunction = null;
						}
						if (currentNumberOfLoops >= totalNumberOfLoops)
						{
							unload();
							return destroyable;
						}
					}
				}
				else if (totalNumberOfLoops >= 1 && (float)sourceRect.X + ((float)sourceRect.Y - sourceRectStartingPos.Y) / (float)sourceRect.Height * (float)Texture.Width >= sourceRectStartingPos.X + (float)(sourceRect.Width * animationLength))
				{
					sourceRect.X = (int)sourceRectStartingPos.X;
					sourceRect.Y = (int)sourceRectStartingPos.Y;
				}
			}
			timer -= interval;
			if (flicker)
			{
				if (currentParentTileIndex < 0 || flash)
				{
					currentParentTileIndex = oldCurrentParentTileIndex;
					flash = false;
				}
				else
				{
					oldCurrentParentTileIndex = currentParentTileIndex;
					if (bombRadius > 0)
					{
						flash = true;
					}
					else
					{
						currentParentTileIndex = -100;
					}
				}
			}
			if (currentParentTileIndex - initialParentTileIndex >= animationLength)
			{
				currentNumberOfLoops++;
				if (holdLastFrame)
				{
					currentParentTileIndex = initialParentTileIndex + animationLength - 1;
					if (texture != null)
					{
						setSourceRectToCurrentTileIndex();
					}
					if (endFunction != null)
					{
						endFunction(extraInfoForEndBehavior);
						endFunction = null;
					}
					return false;
				}
				currentParentTileIndex = initialParentTileIndex;
				if (currentNumberOfLoops >= totalNumberOfLoops)
				{
					if (bombRadius > 0)
					{
						if (Game1.currentLocation == parent)
						{
							Game1.flashAlpha = 1f;
						}
						if (Game1.IsMasterGame)
						{
							parent.netAudio.StopPlaying("fuse");
							parent.playSound("explosion");
							parent.explode(new Vector2((float)(int)(position.X / 64f), (float)(int)(position.Y / 64f)), bombRadius, owner, damageFarmers: true, bombDamage);
						}
					}
					if (fireworkType >= 0)
					{
						float fireworkLifetimeMultiplier = GetFireworkLifetimeMultiplier(fireworkType);
						Color fireworkColor = GetFireworkColor(fireworkType);
						if (Game1.currentLocation == parent)
						{
							Game1.screenGlowOnce(fireworkColor * 0.8f, hold: false);
						}
						if (Game1.IsMasterGame)
						{
							float num3 = 0.3f;
							float num4 = id;
							Vector2[] fireworkLights = GetFireworkLights(fireworkType);
							Vector2[] fireworkPoints = GetFireworkPoints(fireworkType);
							List<TemporaryAnimatedSprite> list = new List<TemporaryAnimatedSprite>();
							Vector2[] array = fireworkLights;
							foreach (Vector2 val in array)
							{
								list.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors_1_6", new Rectangle(0, 0, 1, 1), 1800f * fireworkLifetimeMultiplier, 1, 0, position, flicker: false, flipped: false, -1f, 0f, Color.Transparent, 1f, 0f, 0f, 0f)
								{
									motion = val,
									acceleration = val * num3,
									accelerationChange = -val / num4,
									stopAcceleratingWhenVelocityIsZero = true,
									afterAccelStopMotionX = (float)Math.Sign(val.X) * 0.1f,
									afterAccelStopMotionY = 0.33f,
									layerDepthOffset = 320f,
									lightId = $"Firework_{id}_{val.X}_{val.Y}",
									lightRadius = 1.3f,
									drawAboveAlwaysFront = true,
									lightFade = 2
								});
							}
							array = fireworkPoints;
							foreach (Vector2 val2 in array)
							{
								list.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors_1_6", new Rectangle(304, 364 + fireworkType * 11, 11, 11), 75f * fireworkLifetimeMultiplier + (float)Game1.random.Next(-20, 21), 12, 1, position, flicker: false, flipped: false, -1f, 0f, Color.White, 4f, 0f, (float)(Game1.random.NextDouble() * Math.PI) * 0.5f, 0f)
								{
									motion = val2,
									acceleration = val2 * num3,
									accelerationChange = -val2 / num4,
									stopAcceleratingWhenVelocityIsZero = true,
									afterAccelStopMotionX = (float)Math.Sign(val2.X) * 0.1f,
									afterAccelStopMotionY = 0.33f,
									alpha = 1f,
									alphaFade = 0.01f,
									alphaFadeFade = 0.00025f,
									drawAboveAlwaysFront = true
								});
								int num5 = ((Game1.random.Next(3) != 0) ? 1 : 0);
								list.Add(new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 64 * (10 + num5), 64, 64), 100f * fireworkLifetimeMultiplier, (num5 == 0) ? 9 : 6, 2, position, flicker: false, flipped: false, -1f, 0f, Utility.getBlendedColor(fireworkColor, Color.White), 1f, 0f, (float)(Game1.random.NextDouble() * Math.PI) * 0.5f, 0f)
								{
									motion = val2 * 0.75f,
									acceleration = val2 * num3,
									accelerationChange = -val2 / num4,
									stopAcceleratingWhenVelocityIsZero = true,
									afterAccelStopMotionX = (float)Math.Sign(val2.X) * 0.1f,
									afterAccelStopMotionY = 0.33f,
									drawAboveAlwaysFront = true,
									alpha = 0.5f,
									delayBeforeAnimationStart = Game1.random.Next(50, 100)
								});
							}
							if (id == 30)
							{
								for (int j = 0; j < 8; j++)
								{
									Vector2 val3 = fireworkPoints[Game1.random.Next(fireworkPoints.Length)];
									list.Add(new TemporaryAnimatedSprite("LooseSprites\\Cursors_1_6", new Rectangle(304, 397, 11, 11), 75f * fireworkLifetimeMultiplier, 12, 5, position, flicker: false, flipped: false, -1f, 0f, Utility.getBlendedColor(Color.White, Utility.getRandomRainbowColor()), 4f, 0f, 0f, 0f)
									{
										motion = val3 * 1.1f,
										alpha = 1f,
										alphaFade = 0.01f,
										acceleration = val3 * num3,
										accelerationChange = -val3 / ((float)id * 1.25f),
										stopAcceleratingWhenVelocityIsZero = true,
										afterAccelStopMotionX = (float)Math.Sign(val3.X) * 0.1f,
										afterAccelStopMotionY = 0.33f,
										drawAboveAlwaysFront = true,
										lightId = $"Firework_{id}_{j}",
										lightRadius = 0.33f,
										lightFade = 3
									});
								}
							}
							Game1.multiplayer.broadcastSprites(parent, list.ToArray());
							parent.netAudio.StopPlaying("fuse");
						}
					}
					unload();
					return destroyable;
				}
				if (bombRadius > 0 && currentNumberOfLoops == totalNumberOfLoops - 5)
				{
					interval -= interval / 3f;
				}
			}
		}
		return false;
	}

	public bool clearOnAreaEntry()
	{
		if (dontClearOnAreaEntry)
		{
			return false;
		}
		if (bombRadius > 0)
		{
			return false;
		}
		return true;
	}

	private void setSourceRectToCurrentTileIndex()
	{
		sourceRect.X = (int)(sourceRectStartingPos.X + (float)(currentParentTileIndex * sourceRect.Width)) % texture.Width;
		if (sourceRect.X < 0)
		{
			sourceRect.X = 0;
		}
		sourceRect.Y = (int)sourceRectStartingPos.Y;
	}

	private void PlaySound(string sound)
	{
		if (sound != null)
		{
			if (parent == null)
			{
				Game1.playSound(sound);
			}
			else
			{
				parent.localSound(sound);
			}
		}
	}

	public static TemporaryAnimatedSprite CreateFromData(TemporaryAnimatedSpriteDefinition temporarySprite, float x, float y, float sortLayer)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		return new TemporaryAnimatedSprite(temporarySprite.Texture, temporarySprite.SourceRect, temporarySprite.Interval, temporarySprite.Frames, temporarySprite.Loops, new Vector2(x, y) * 64f + temporarySprite.PositionOffset * 4f, temporarySprite.Flicker, temporarySprite.Flip, sortLayer + temporarySprite.SortOffset, temporarySprite.AlphaFade, (Color)(((_003F?)Utility.StringToColor(temporarySprite.Color)) ?? Color.White), temporarySprite.Scale * 4f, temporarySprite.ScaleChange, temporarySprite.Rotation, temporarySprite.RotationChange);
	}
}
