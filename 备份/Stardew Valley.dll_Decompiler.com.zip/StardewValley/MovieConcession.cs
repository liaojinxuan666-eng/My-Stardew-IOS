using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.GameData.Movies;
using StardewValley.ItemTypeDefinitions;
using StardewValley.TokenizableStrings;

namespace StardewValley;

public class MovieConcession : ISalable, IHaveItemTypeId
{
	private readonly ConcessionItemData Data;

	public string TypeDefinitionId => "(Salable)";

	public string QualifiedItemId => TypeDefinitionId + "MovieConcession." + Id;

	public string Id => Data.Id;

	public string Name => Data.Name;

	public string DisplayName => TokenParser.ParseText(Data.DisplayName);

	public bool IsRecipe
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	public int Stack
	{
		get
		{
			return 1;
		}
		set
		{
		}
	}

	public int Quality
	{
		get
		{
			return 0;
		}
		set
		{
		}
	}

	public List<string> Tags { get; }

	public MovieConcession(ConcessionItemData data)
	{
		Data = data;
		Tags = data.ItemTags?.ToList();
	}

	public void drawInMenu(SpriteBatch spriteBatch, Vector2 location, float scaleSize, float transparency, float layerDepth, StackDrawType drawStackNumber, Color color, bool drawShadow)
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (drawShadow)
		{
			Texture2D shadowTexture = Game1.shadowTexture;
			Vector2 val = location + new Vector2(32f, 48f);
			Rectangle? val2 = Game1.shadowTexture.Bounds;
			Color val3 = color * 0.5f;
			Rectangle bounds = Game1.shadowTexture.Bounds;
			float num = ((Rectangle)(ref bounds)).Center.X;
			bounds = Game1.shadowTexture.Bounds;
			spriteBatch.Draw(shadowTexture, val, val2, val3, 0f, new Vector2(num, (float)((Rectangle)(ref bounds)).Center.Y), 3f, (SpriteEffects)0, layerDepth - 0.0001f);
		}
		spriteBatch.Draw(GetTexture(), location + new Vector2((float)(int)(32f * scaleSize), (float)(int)(32f * scaleSize)), (Rectangle?)Game1.getSourceRectForStandardTileSheet(GetTexture(), GetSpriteIndex(), 16, 16), color * transparency, 0f, new Vector2(8f, 8f) * scaleSize, 4f * scaleSize, (SpriteEffects)0, layerDepth);
	}

	public Texture2D GetTexture()
	{
		if (!(Data.Texture == "LooseSprites\\Concessions"))
		{
			return Game1.content.Load<Texture2D>(Data.Texture);
		}
		return Game1.concessionsSpriteSheet;
	}

	public int GetSpriteIndex()
	{
		return Data.SpriteIndex;
	}

	public bool ShouldDrawIcon()
	{
		return true;
	}

	public string getDescription()
	{
		return Game1.parseText(TokenParser.ParseText(Data.Description), Game1.smallFont, 320);
	}

	public int maximumStackSize()
	{
		return 1;
	}

	public int addToStack(Item stack)
	{
		return 1;
	}

	public bool canStackWith(ISalable other)
	{
		return false;
	}

	public int sellToStorePrice(long specificPlayerID = -1L)
	{
		return -1;
	}

	public int salePrice(bool ignoreProfitMargins = false)
	{
		return Data.Price;
	}

	public bool appliesProfitMargins()
	{
		return false;
	}

	public bool actionWhenPurchased(string shopId)
	{
		return true;
	}

	public bool CanBuyItem(Farmer farmer)
	{
		return true;
	}

	public bool IsInfiniteStock()
	{
		return true;
	}

	public ISalable GetSalableInstance()
	{
		return this;
	}

	public void FixStackSize()
	{
	}

	public void FixQuality()
	{
	}

	public string GetItemTypeId()
	{
		return TypeDefinitionId;
	}
}
