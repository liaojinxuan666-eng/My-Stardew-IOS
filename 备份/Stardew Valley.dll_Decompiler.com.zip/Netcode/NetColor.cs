using System.IO;
using Microsoft.Xna.Framework;

namespace Netcode;

public sealed class NetColor : NetField<Color, NetColor>
{
	public byte R
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			Color val = base.Value;
			return ((Color)(ref val)).R;
		}
		set
		{
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			base.Value = new Color(value, G, B, A);
		}
	}

	public byte G
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			Color val = base.Value;
			return ((Color)(ref val)).G;
		}
		set
		{
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			base.Value = new Color(R, value, B, A);
		}
	}

	public byte B
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			Color val = base.Value;
			return ((Color)(ref val)).B;
		}
		set
		{
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			base.Value = new Color(R, G, value, A);
		}
	}

	public byte A
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			Color val = base.Value;
			return ((Color)(ref val)).A;
		}
		set
		{
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			base.Value = new Color(R, G, B, value);
		}
	}

	public NetColor()
	{
	}

	public NetColor(Color value)
		: base(value)
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public override void Set(Color newValue)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		if (canShortcutSet())
		{
			value = newValue;
		}
		else if (newValue != value)
		{
			cleanSet(newValue);
			MarkDirty();
		}
	}

	public new bool Equals(NetColor other)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return value == other.value;
	}

	public bool Equals(Color other)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		return value == other;
	}

	protected override void ReadDelta(BinaryReader reader, NetVersion version)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		Color interpolationTarget = default(Color);
		((Color)(ref interpolationTarget)).PackedValue = reader.ReadUInt32();
		if (version.IsPriorityOver(ChangeVersion))
		{
			setInterpolationTarget(interpolationTarget);
		}
	}

	protected override void WriteDelta(BinaryWriter writer)
	{
		writer.Write(((Color)(ref value)).PackedValue);
	}
}
