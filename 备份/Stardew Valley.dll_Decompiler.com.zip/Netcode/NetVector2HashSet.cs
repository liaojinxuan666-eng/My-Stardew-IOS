using System.IO;
using Microsoft.Xna.Framework;

namespace Netcode;

public class NetVector2HashSet : NetHashSet<Vector2>
{
	public override Vector2 ReadValue(BinaryReader reader)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		float num = reader.ReadSingle();
		float num2 = reader.ReadSingle();
		return new Vector2(num, num2);
	}

	public override void WriteValue(BinaryWriter writer, Vector2 value)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		writer.Write(value.X);
		writer.Write(value.Y);
	}
}
