using System.IO;
using Microsoft.Xna.Framework;

namespace Netcode;

public sealed class NetPoint : NetField<Point, NetPoint>
{
	public int X
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return base.Value.X;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0013: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			Point val = base.value;
			if (val.X != value)
			{
				Point newValue = default(Point);
				((Point)(ref newValue))._002Ector(value, val.Y);
				if (canShortcutSet())
				{
					base.value = newValue;
					return;
				}
				cleanSet(newValue);
				MarkDirty();
			}
		}
	}

	public int Y
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return base.Value.Y;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			Point val = base.value;
			if (val.Y != value)
			{
				Point newValue = default(Point);
				((Point)(ref newValue))._002Ector(val.X, value);
				if (canShortcutSet())
				{
					base.value = newValue;
					return;
				}
				cleanSet(newValue);
				MarkDirty();
			}
		}
	}

	public NetPoint()
	{
	}

	public NetPoint(Point value)
		: base(value)
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public void Set(int x, int y)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		Set(new Point(x, y));
	}

	public override void Set(Point newValue)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		if (canShortcutSet())
		{
			value = newValue;
		}
		else if (newValue != value)
		{
			cleanSet(newValue);
			MarkDirty();
		}
	}

	protected override Point interpolate(Point startValue, Point endValue, float factor)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		Point val = default(Point);
		((Point)(ref val))._002Ector(endValue.X - startValue.X, endValue.Y - startValue.Y);
		val.X = (int)((float)val.X * factor);
		val.Y = (int)((float)val.Y * factor);
		return new Point(startValue.X + val.X, startValue.Y + val.Y);
	}

	protected override void ReadDelta(BinaryReader reader, NetVersion version)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		int num = reader.ReadInt32();
		int num2 = reader.ReadInt32();
		if (version.IsPriorityOver(ChangeVersion))
		{
			setInterpolationTarget(new Point(num, num2));
		}
	}

	protected override void WriteDelta(BinaryWriter writer)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		writer.Write(base.Value.X);
		writer.Write(base.Value.Y);
	}
}
