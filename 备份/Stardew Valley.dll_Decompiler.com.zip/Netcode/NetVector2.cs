using System;
using System.IO;
using Microsoft.Xna.Framework;

namespace Netcode;

public sealed class NetVector2 : NetField<Vector2, NetVector2>
{
	public bool AxisAlignedMovement;

	public float ExtrapolationSpeed;

	public float MinDeltaForDirectionChange = 8f;

	public float MaxInterpolationDistance = 320f;

	private bool interpolateXFirst;

	private bool isExtrapolating;

	private bool isFixingExtrapolation;

	public float X
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return base.Value.X;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0013: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			Vector2 val = base.value;
			if (val.X != value)
			{
				Vector2 newValue = default(Vector2);
				((Vector2)(ref newValue))._002Ector(value, val.Y);
				if (canShortcutSet())
				{
					base.value = newValue;
					return;
				}
				cleanSet(newValue);
				MarkDirty();
			}
		}
	}

	public float Y
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return base.Value.Y;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			Vector2 val = base.value;
			if (val.Y != value)
			{
				Vector2 newValue = default(Vector2);
				((Vector2)(ref newValue))._002Ector(val.X, value);
				if (canShortcutSet())
				{
					base.value = newValue;
					return;
				}
				cleanSet(newValue);
				MarkDirty();
			}
		}
	}

	public NetVector2()
	{
	}

	public NetVector2(Vector2 value)
		: base(value)
	{
	}//IL_0017: Unknown result type (might be due to invalid IL or missing references)


	public void Set(float x, float y)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		Set(new Vector2(x, y));
	}

	public override void Set(Vector2 newValue)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		if (canShortcutSet())
		{
			value = newValue;
		}
		else if (newValue != value)
		{
			cleanSet(newValue);
			MarkDirty();
		}
	}

	public Vector2 InterpolationDelta()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		if (base.NeedsTick)
		{
			return targetValue - previousValue;
		}
		return Vector2.Zero;
	}

	protected override bool setUpInterpolation(Vector2 oldValue, Vector2 newValue)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = newValue - oldValue;
		if (((Vector2)(ref val)).LengthSquared() >= MaxInterpolationDistance * MaxInterpolationDistance)
		{
			return false;
		}
		if (AxisAlignedMovement)
		{
			if (base.NeedsTick)
			{
				Vector2 val2 = targetValue - previousValue;
				Vector2 val3 = default(Vector2);
				((Vector2)(ref val3))._002Ector(Math.Abs(val2.X), Math.Abs(val2.Y));
				if (interpolateXFirst)
				{
					interpolateXFirst = InterpolationFactor() * (val3.X + val3.Y) < val3.X;
				}
				else
				{
					interpolateXFirst = InterpolationFactor() * (val3.X + val3.Y) > val3.Y;
				}
			}
			else
			{
				Vector2 val4 = newValue - oldValue;
				Vector2 val5 = default(Vector2);
				((Vector2)(ref val5))._002Ector(Math.Abs(val4.X), Math.Abs(val4.Y));
				interpolateXFirst = val5.X < val5.Y;
			}
		}
		return true;
	}

	public Vector2 CurrentInterpolationDirection()
	{
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		if (AxisAlignedMovement)
		{
			float num = InterpolationFactor();
			Vector2 val = InterpolationDelta();
			float num2 = (Math.Abs(val.X) + Math.Abs(val.Y)) * num;
			if (Math.Abs(val.X) < MinDeltaForDirectionChange && Math.Abs(val.Y) < MinDeltaForDirectionChange)
			{
				return Vector2.Zero;
			}
			if (Math.Abs(val.X) < MinDeltaForDirectionChange)
			{
				return new Vector2(0f, (float)Math.Sign(val.Y));
			}
			if (Math.Abs(val.Y) < MinDeltaForDirectionChange)
			{
				return new Vector2((float)Math.Sign(val.X), 0f);
			}
			if (interpolateXFirst)
			{
				if (num2 > Math.Abs(val.X))
				{
					return new Vector2(0f, (float)Math.Sign(val.Y));
				}
				return new Vector2((float)Math.Sign(val.X), 0f);
			}
			if (num2 > Math.Abs(val.Y))
			{
				return new Vector2((float)Math.Sign(val.X), 0f);
			}
			return new Vector2(0f, (float)Math.Sign(val.Y));
		}
		Vector2 result = InterpolationDelta();
		((Vector2)(ref result)).Normalize();
		return result;
	}

	public float CurrentInterpolationSpeed()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = InterpolationDelta();
		float num = ((Vector2)(ref val)).Length();
		if (InterpolationTicks() == 0)
		{
			return num;
		}
		if (InterpolationFactor() > 1f)
		{
			return ExtrapolationSpeed;
		}
		return num / (float)InterpolationTicks();
	}

	protected override Vector2 interpolate(Vector2 startValue, Vector2 endValue, float factor)
	{
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		if (AxisAlignedMovement && factor <= 1f && !isFixingExtrapolation)
		{
			isExtrapolating = false;
			Vector2 val = InterpolationDelta();
			Vector2 val2 = default(Vector2);
			((Vector2)(ref val2))._002Ector(Math.Abs(val.X), Math.Abs(val.Y));
			float num = (val2.X + val2.Y) * factor;
			float num2;
			float num3;
			if (interpolateXFirst)
			{
				if (num > val2.X)
				{
					num2 = endValue.X;
					num3 = startValue.Y + (num - val2.X) * (float)Math.Sign(val.Y);
				}
				else
				{
					num2 = startValue.X + num * (float)Math.Sign(val.X);
					num3 = startValue.Y;
				}
			}
			else if (num > val2.Y)
			{
				num3 = endValue.Y;
				num2 = startValue.X + (num - val2.Y) * (float)Math.Sign(val.X);
			}
			else
			{
				num3 = startValue.Y + num * (float)Math.Sign(val.Y);
				num2 = startValue.X;
			}
			return new Vector2(num2, num3);
		}
		if (factor > 1f)
		{
			isExtrapolating = true;
			uint num4 = base.Root.Clock.GetLocalTick() - interpolationStartTick - (uint)InterpolationTicks();
			Vector2 val3 = endValue - startValue;
			if (((Vector2)(ref val3)).LengthSquared() > ExtrapolationSpeed * ExtrapolationSpeed)
			{
				((Vector2)(ref val3)).Normalize();
				return endValue + val3 * (float)num4 * ExtrapolationSpeed;
			}
		}
		isExtrapolating = false;
		return startValue + (endValue - startValue) * factor;
	}

	protected override void ReadDelta(BinaryReader reader, NetVersion version)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		float num = reader.ReadSingle();
		float num2 = reader.ReadSingle();
		if (version.IsPriorityOver(ChangeVersion))
		{
			isFixingExtrapolation = isExtrapolating;
			setInterpolationTarget(new Vector2(num, num2));
			isExtrapolating = false;
		}
	}

	protected override void WriteDelta(BinaryWriter writer)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		writer.Write(base.Value.X);
		writer.Write(base.Value.Y);
	}
}
