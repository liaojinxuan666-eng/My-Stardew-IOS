using System;
using System.Collections;
using System.IO;
using Microsoft.Xna.Framework;

namespace Netcode;

public static class BinaryReaderWriterExtensions
{
	public static void ReadSkippable(this BinaryReader reader, Action readAction)
	{
		uint num = reader.ReadUInt32();
		long position = reader.BaseStream.Position;
		readAction();
		if (reader.BaseStream.Position > position + num)
		{
			throw new InvalidOperationException();
		}
		reader.BaseStream.Position = position + num;
	}

	public static byte[] ReadSkippableBytes(this BinaryReader reader)
	{
		uint count = reader.ReadUInt32();
		return reader.ReadBytes((int)count);
	}

	public static void Skip(this BinaryReader reader)
	{
		reader.ReadSkippable(delegate
		{
		});
	}

	public static void WriteSkippable(this BinaryWriter writer, Action writeAction)
	{
		long position = writer.BaseStream.Position;
		writer.Write(0u);
		long position2 = writer.BaseStream.Position;
		writeAction();
		long position3 = writer.BaseStream.Position;
		long num = position3 - position2;
		writer.BaseStream.Position = position;
		writer.Write((uint)num);
		writer.BaseStream.Position = position3;
	}

	public static BitArray ReadBitArray(this BinaryReader reader)
	{
		int num = (int)reader.Read7BitEncoded();
		return new BitArray(reader.ReadBytes((num + 7) / 8))
		{
			Length = num
		};
	}

	public static void WriteBitArray(this BinaryWriter writer, BitArray bits)
	{
		byte[] array = new byte[(bits.Length + 7) / 8];
		bits.CopyTo(array, 0);
		writer.Write7BitEncoded((uint)bits.Length);
		writer.Write(array);
	}

	public static void Write7BitEncoded(this BinaryWriter writer, uint value)
	{
		do
		{
			byte b = (byte)(value & 0x7F);
			value >>= 7;
			if (value != 0)
			{
				b |= 0x80;
			}
			writer.Write(b);
		}
		while (value != 0);
	}

	public static uint Read7BitEncoded(this BinaryReader reader)
	{
		uint num = 0u;
		byte b = reader.ReadByte();
		int num2 = 0;
		while ((b & 0x80) != 0)
		{
			num |= (uint)((b & 0x7F) << num2);
			num2 += 7;
			b = reader.ReadByte();
		}
		return num | (uint)((b & 0x7F) << num2);
	}

	public static Guid ReadGuid(this BinaryReader reader)
	{
		return new Guid(reader.ReadBytes(16));
	}

	public static void WriteGuid(this BinaryWriter writer, Guid guid)
	{
		writer.Write(guid.ToByteArray());
	}

	public static Vector2 ReadVector2(this BinaryReader reader)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		float num = reader.ReadSingle();
		float num2 = reader.ReadSingle();
		return new Vector2(num, num2);
	}

	public static void WriteVector2(this BinaryWriter writer, Vector2 vec)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		writer.Write(vec.X);
		writer.Write(vec.Y);
	}

	public static Point ReadPoint(this BinaryReader reader)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		int num = reader.ReadInt32();
		int num2 = reader.ReadInt32();
		return new Point(num, num2);
	}

	public static void WritePoint(this BinaryWriter writer, Point p)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		writer.Write(p.X);
		writer.Write(p.Y);
	}

	public static Rectangle ReadRectangle(this BinaryReader reader)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		Point val = reader.ReadPoint();
		Point val2 = reader.ReadPoint();
		return new Rectangle(val.X, val.Y, val2.X, val2.Y);
	}

	public static void WriteRectangle(this BinaryWriter writer, Rectangle rect)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		writer.WritePoint(((Rectangle)(ref rect)).Location);
		writer.WritePoint(new Point(rect.Width, rect.Height));
	}

	public static Color ReadColor(this BinaryReader reader)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		Color result = default(Color);
		((Color)(ref result)).PackedValue = reader.ReadUInt32();
		return result;
	}

	public static void WriteColor(this BinaryWriter writer, Color color)
	{
		writer.Write(((Color)(ref color)).PackedValue);
	}

	public static T ReadEnum<T>(this BinaryReader reader) where T : struct, IConvertible
	{
		return (T)Enum.ToObject(typeof(T), reader.ReadInt16());
	}

	public static void WriteEnum<T>(this BinaryWriter writer, T enumValue) where T : struct, IConvertible
	{
		writer.Write(Convert.ToInt16(enumValue));
	}

	public static void WriteEnum(this BinaryWriter writer, object enumValue)
	{
		writer.Write(Convert.ToInt16(enumValue));
	}

	public static void Push(this BinaryWriter writer, string name)
	{
		if (writer is ILoggingWriter loggingWriter)
		{
			loggingWriter.Push(name);
		}
	}

	public static void Pop(this BinaryWriter writer)
	{
		if (writer is ILoggingWriter loggingWriter)
		{
			loggingWriter.Pop();
		}
	}
}
