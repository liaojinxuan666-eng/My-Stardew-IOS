using System.IO;
using Microsoft.Xna.Framework;

namespace Netcode;

public sealed class NetRectangle : NetField<Rectangle, NetRectangle>
{
	public int X
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return base.Value.X;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0013: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			Rectangle val = base.value;
			if (val.X != value)
			{
				Rectangle newValue = default(Rectangle);
				((Rectangle)(ref newValue))._002Ector(value, val.Y, val.Width, val.Height);
				if (canShortcutSet())
				{
					base.value = newValue;
					return;
				}
				cleanSet(newValue);
				MarkDirty();
			}
		}
	}

	public int Y
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return base.Value.Y;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			Rectangle val = base.value;
			if (val.Y != value)
			{
				Rectangle newValue = default(Rectangle);
				((Rectangle)(ref newValue))._002Ector(val.X, value, val.Width, val.Height);
				if (canShortcutSet())
				{
					base.value = newValue;
					return;
				}
				cleanSet(newValue);
				MarkDirty();
			}
		}
	}

	public int Width
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return base.Value.Width;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			Rectangle val = base.value;
			if (val.Width != value)
			{
				Rectangle newValue = default(Rectangle);
				((Rectangle)(ref newValue))._002Ector(val.X, val.Y, value, val.Height);
				if (canShortcutSet())
				{
					base.value = newValue;
					return;
				}
				cleanSet(newValue);
				MarkDirty();
			}
		}
	}

	public int Height
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return base.Value.Height;
		}
		set
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			Rectangle val = base.value;
			if (val.Height != value)
			{
				Rectangle newValue = default(Rectangle);
				((Rectangle)(ref newValue))._002Ector(val.X, val.Y, val.Width, value);
				if (canShortcutSet())
				{
					base.value = newValue;
					return;
				}
				cleanSet(newValue);
				MarkDirty();
			}
		}
	}

	public Point Center => ((Rectangle)(ref value)).Center;

	public int Top => ((Rectangle)(ref value)).Top;

	public int Bottom => ((Rectangle)(ref value)).Bottom;

	public int Left => ((Rectangle)(ref value)).Left;

	public int Right => ((Rectangle)(ref value)).Right;

	public NetRectangle()
	{
	}

	public NetRectangle(Rectangle value)
		: base(value)
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public void Set(int x, int y, int width, int height)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		Set(new Rectangle(x, y, width, height));
	}

	public override void Set(Rectangle newValue)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		if (canShortcutSet())
		{
			value = newValue;
		}
		else if (newValue != value)
		{
			cleanSet(newValue);
			MarkDirty();
		}
	}

	protected override void ReadDelta(BinaryReader reader, NetVersion version)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		int num = reader.ReadInt32();
		int num2 = reader.ReadInt32();
		int num3 = reader.ReadInt32();
		int num4 = reader.ReadInt32();
		if (version.IsPriorityOver(ChangeVersion))
		{
			setInterpolationTarget(new Rectangle(num, num2, num3, num4));
		}
	}

	protected override void WriteDelta(BinaryWriter writer)
	{
		writer.Write(value.X);
		writer.Write(value.Y);
		writer.Write(value.Width);
		writer.Write(value.Height);
	}
}
