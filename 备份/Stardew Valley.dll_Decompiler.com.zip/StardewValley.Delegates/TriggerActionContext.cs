using System.Collections.Generic;
using StardewValley.GameData;

namespace StardewValley.Delegates;

public readonly struct TriggerActionContext
{
	public readonly string Trigger;

	public readonly object[] TriggerArgs;

	public readonly TriggerActionData Data;

	public readonly Dictionary<string, object> CustomFields;

	public TriggerActionContext(string trigger, object[] triggerArgs, TriggerActionData data, Dictionary<string, object> customFields = null)
	{
		Trigger = trigger;
		TriggerArgs = triggerArgs;
		Data = data;
		CustomFields = customFields;
	}
}
