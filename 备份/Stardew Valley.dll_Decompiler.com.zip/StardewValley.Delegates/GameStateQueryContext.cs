using System;
using System.Collections.Generic;

namespace StardewValley.Delegates;

public readonly struct GameStateQueryContext
{
	public readonly GameLocation Location;

	public readonly GameLocation ExplicitTargetLocation;

	public readonly Farmer Player;

	public readonly Item TargetItem;

	public readonly Item InputItem;

	public readonly Random Random;

	public readonly HashSet<string> IgnoreQueryKeys;

	public readonly Dictionary<string, object> CustomFields;

	public GameStateQueryContext(GameLocation location, Farmer player, Item targetItem, Item inputItem, Random random, HashSet<string> ignoreQueryKeys = null, Dictionary<string, object> customFields = null)
	{
		ExplicitTargetLocation = location;
		Location = location ?? player?.currentLocation ?? Game1.currentLocation;
		Player = player ?? Game1.player;
		TargetItem = targetItem;
		InputItem = inputItem;
		Random = random ?? Game1.random;
		IgnoreQueryKeys = ignoreQueryKeys;
		CustomFields = customFields;
	}
}
