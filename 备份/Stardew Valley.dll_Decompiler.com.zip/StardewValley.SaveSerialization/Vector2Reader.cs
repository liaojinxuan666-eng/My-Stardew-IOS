using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;

namespace StardewValley.SaveSerialization;

public class Vector2Reader : XmlSerializationReader
{
	public Vector2 ReadVector2()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		XmlReader reader = base.Reader;
		reader.ReadStartElement("Vector2");
		reader.ReadStartElement("X");
		float num = reader.ReadContentAsFloat();
		reader.ReadEndElement();
		reader.ReadStartElement("Y");
		float num2 = reader.ReadContentAsFloat();
		reader.ReadEndElement();
		reader.ReadEndElement();
		return new Vector2(num, num2);
	}

	protected override void InitCallbacks()
	{
	}

	protected override void InitIDs()
	{
	}
}
