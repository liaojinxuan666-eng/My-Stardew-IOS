using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;

namespace StardewValley.SaveSerialization;

public class Vector2Writer : XmlSerializationWriter
{
	public void WriteVector2(Vector2 vec)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		XmlWriter writer = base.Writer;
		writer.WriteStartElement("Vector2");
		writer.WriteStartElement("X");
		writer.WriteValue(vec.X);
		writer.WriteEndElement();
		writer.WriteStartElement("Y");
		writer.WriteValue(vec.Y);
		writer.WriteEndElement();
		writer.WriteEndElement();
	}

	protected override void InitCallbacks()
	{
	}
}
