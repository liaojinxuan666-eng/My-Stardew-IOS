using System;
using Microsoft.Xna.Framework;
using StardewValley.Monsters;

namespace StardewValley.Enchantments;

public class VampiricEnchantment : BaseWeaponEnchantment
{
	public override void OnMonsterSlay(Monster monster, GameLocation location, Farmer who, bool slainByBomb)
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		base.OnMonsterSlay(monster, location, who, slainByBomb);
		if (!slainByBomb && Game1.random.NextDouble() < 0.09000000357627869)
		{
			int num = Math.Max(1, (int)((float)(monster.MaxHealth + Game1.random.Next(-monster.MaxHealth / 10, monster.MaxHealth / 15 + 1)) * 0.1f));
			who.health = Math.Min(who.maxHealth, who.health + num);
			location.debris.Add(new Debris(num, who.getStandingPosition(), Color.Lime, 1f, who));
			Game1.playSound("healSound");
		}
	}

	public override string GetName()
	{
		return "Vampiric";
	}
}
