using System;
using Microsoft.Xna.Framework;
using StardewValley.Projectiles;
using StardewValley.Tools;

namespace StardewValley.Enchantments;

public class MagicEnchantment : BaseWeaponEnchantment
{
	protected override void _OnSwing(MeleeWeapon weapon, Farmer farmer)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		base._OnSwing(weapon, farmer);
		Vector2 val = default(Vector2);
		Vector2 startingPosition = farmer.getStandingPosition() - new Vector2(32f, 32f);
		switch (farmer.facingDirection.Value)
		{
		case 0:
			val.Y = -1f;
			break;
		case 1:
			val.X = 1f;
			break;
		case 3:
			val.X = -1f;
			break;
		case 2:
			val.Y = 1f;
			break;
		}
		float num = 32f;
		val *= 10f;
		BasicProjectile basicProjectile = new BasicProjectile((int)Math.Ceiling((float)weapon.minDamage.Value / 4f), 11, 0, 1, num * ((float)Math.PI / 180f), val.X, val.Y, startingPosition, null, null, null, explode: false, damagesMonsters: true, farmer.currentLocation, farmer);
		basicProjectile.ignoreTravelGracePeriod.Value = true;
		basicProjectile.ignoreMeleeAttacks.Value = true;
		basicProjectile.maxTravelDistance.Value = 256;
		basicProjectile.height.Value = 32f;
		farmer.currentLocation.projectiles.Add(basicProjectile);
	}

	public override string GetName()
	{
		return "Starburst";
	}
}
