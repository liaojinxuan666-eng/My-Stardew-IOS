namespace StardewValley.SDKs.Steam;

public class SteamHelper : NullSDKHelper
{
	public override string Name { get; } = "Steam";
}
