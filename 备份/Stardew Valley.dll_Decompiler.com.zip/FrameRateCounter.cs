using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using StardewValley;

public class FrameRateCounter : DrawableGameComponent
{
	private LocalizedContentManager content;

	private SpriteBatch spriteBatch;

	private int frameRate;

	private int frameCounter;

	private TimeSpan elapsedTime = TimeSpan.Zero;

	public FrameRateCounter(Game game)
		: base(game)
	{
		content = new LocalizedContentManager((IServiceProvider)game.Services, ((GameComponent)this).Game.Content.RootDirectory);
	}

	protected override void LoadContent()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected O, but got Unknown
		spriteBatch = new SpriteBatch(((DrawableGameComponent)this).GraphicsDevice);
	}

	protected override void UnloadContent()
	{
		((ContentManager)content).Unload();
	}

	public override void Update(GameTime gameTime)
	{
		elapsedTime += gameTime.ElapsedGameTime;
		if (elapsedTime > TimeSpan.FromSeconds(1.0))
		{
			elapsedTime -= TimeSpan.FromSeconds(1.0);
			frameRate = frameCounter;
			frameCounter = 0;
		}
	}

	public override void Draw(GameTime gameTime)
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		frameCounter++;
		string text = $"fps: {frameRate}";
		spriteBatch.Begin((SpriteSortMode)0, (BlendState)null, (SamplerState)null, (DepthStencilState)null, (RasterizerState)null, (Effect)null, (Matrix?)null);
		spriteBatch.DrawString(Game1.dialogueFont, text, new Vector2(33f, 33f), Color.Black);
		spriteBatch.DrawString(Game1.dialogueFont, text, new Vector2(32f, 32f), Color.White);
		spriteBatch.End();
	}
}
