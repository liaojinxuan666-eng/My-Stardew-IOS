using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xTile.Dimensions;

namespace StardewValley.Util;

public class BoundingBoxGroup
{
	private List<Rectangle> rectangles = new List<Rectangle>();

	public bool Intersects(Rectangle rect)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		foreach (Rectangle rectangle in rectangles)
		{
			Rectangle current = rectangle;
			if (((Rectangle)(ref current)).Intersects(rect))
			{
				return true;
			}
		}
		return false;
	}

	public bool Contains(int x, int y)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		foreach (Rectangle rectangle in rectangles)
		{
			Rectangle current = rectangle;
			if (((Rectangle)(ref current)).Contains(x, y))
			{
				return true;
			}
		}
		return false;
	}

	public void Add(Rectangle rect)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		if (!rectangles.Contains(rect))
		{
			rectangles.Add(rect);
		}
	}

	public void ClearNonIntersecting(Rectangle rect)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		rectangles.RemoveAll((Rectangle r) => !((Rectangle)(ref r)).Intersects(rect));
	}

	public void Clear()
	{
		rectangles.Clear();
	}

	public void Draw(SpriteBatch b)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		foreach (Rectangle rectangle in rectangles)
		{
			Rectangle current = rectangle;
			((Rectangle)(ref current)).Offset(-((Rectangle)(ref Game1.viewport)).X, -((Rectangle)(ref Game1.viewport)).Y);
			b.Draw(Game1.fadeToBlackRect, current, Color.Green * 0.5f);
		}
	}

	public bool IsEmpty()
	{
		return rectangles.Count == 0;
	}
}
