using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Extensions;
using StardewValley.Pathfinding;
using StardewValley.Projectiles;

namespace StardewValley.Monsters;

public class ShadowGuy : Monster
{
	public const int visionDistance = 8;

	public const int spellCooldown = 1500;

	[XmlIgnore]
	public bool spottedPlayer;

	[XmlIgnore]
	public bool casting;

	[XmlIgnore]
	public bool teleporting;

	[XmlIgnore]
	public int coolDown = 1500;

	[XmlIgnore]
	public IEnumerator<Point> teleportationPath;

	[XmlIgnore]
	public float rotationTimer;

	public ShadowGuy()
	{
	}

	public ShadowGuy(Vector2 position)
		: base("Shadow Guy", position)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.MasterPlayer.friendshipData.TryGetValue("???", out var value) && value.Points >= 1250)
		{
			base.DamageToFarmer = 0;
		}
		Halt();
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		Sprite = new AnimatedSprite("Characters\\Monsters\\Shadow " + ((base.Position.X % 4f == 0f) ? "Girl" : "Guy"));
	}

	public override void draw(SpriteBatch b)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		if (!casting)
		{
			base.draw(b);
			return;
		}
		Vector2 standingPosition = getStandingPosition();
		int num = (int)standingPosition.Y;
		b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2((float)(32 + Game1.random.Next(-8, 9)), (float)(64 + Game1.random.Next(-8, 9))), (Rectangle?)Sprite.SourceRect, Color.White * 0.5f, rotation, new Vector2(32f, 64f), Math.Max(0.2f, scale.Value), (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)num / 10000f)));
		b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2((float)(32 + Game1.random.Next(-8, 9)), (float)(64 + Game1.random.Next(-8, 9))), (Rectangle?)Sprite.SourceRect, Color.White * 0.5f, rotation, new Vector2(32f, 64f), Math.Max(0.2f, scale.Value), (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)(num + 1) / 10000f)));
		Vector2 val = Game1.GlobalToLocal(Game1.viewport, standingPosition);
		Rectangle value = default(Rectangle);
		((Rectangle)(ref value))._002Ector(212, 20, 24, 24);
		Color val2 = Color.White * 0.7f;
		Vector2 val3 = default(Vector2);
		((Vector2)(ref val3))._002Ector(32f, 256f);
		for (int i = 0; i < 8; i++)
		{
			b.Draw(Projectile.projectileSheet, val, (Rectangle?)value, val2, rotationTimer + (float)i * (float)Math.PI / 4f, val3, 1.5f, (SpriteEffects)0, 0.95f);
		}
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		int num = Math.Max(1, damage - resilience.Value);
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Health -= num;
			if (casting && Game1.random.NextBool())
			{
				coolDown += 200;
			}
			else if (Game1.random.NextDouble() < 0.4 + 1.0 / (double)base.Health && !base.currentLocation.IsFarm)
			{
				castTeleport();
				if (base.Health <= 10)
				{
					base.speed = Math.Min(3, base.speed + 1);
				}
			}
			else
			{
				setTrajectory(xTrajectory, yTrajectory);
				base.currentLocation.playSound("shadowHit");
			}
			if (base.Health <= 0)
			{
				base.currentLocation.playSound("shadowDie");
				deathAnimation();
			}
		}
		return num;
	}

	protected override void localDeathAnimation()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(45, base.Position, Color.White, 10));
	}

	protected override void sharedDeathAnimation()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		Point standingPixel = base.StandingPixel;
		Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(Sprite.SourceRect.X, Sprite.SourceRect.Y, 64, 21), 64, standingPixel.X, standingPixel.Y - 32, 1, standingPixel.Y / 64, Color.White);
		Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(Sprite.SourceRect.X + 10, Sprite.SourceRect.Y + 21, 64, 21), 42, standingPixel.X, standingPixel.Y - 32, 1, standingPixel.Y / 64, Color.White);
	}

	public void castTeleport()
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		int i = 0;
		Vector2 tile = base.Tile;
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(tile.X + (float)(Game1.random.NextBool() ? Game1.random.Next(-5, -1) : Game1.random.Next(2, 6)), tile.Y + (float)(Game1.random.NextBool() ? Game1.random.Next(-5, -1) : Game1.random.Next(2, 6)));
		for (; i < 6; i++)
		{
			if (base.currentLocation.isTileOnMap(val) && base.currentLocation.isTileLocationOpen(val) && base.currentLocation.CanSpawnCharacterHere(val))
			{
				break;
			}
			((Vector2)(ref val))._002Ector(tile.X + (float)(Game1.random.NextBool() ? Game1.random.Next(-5, -1) : Game1.random.Next(2, 6)), tile.Y + (float)(Game1.random.NextBool() ? Game1.random.Next(-5, -1) : Game1.random.Next(2, 6)));
		}
		if (i < 6)
		{
			teleporting = true;
			teleportationPath = Utility.GetPointsOnLine((int)tile.X, (int)tile.Y, (int)val.X, (int)val.Y, ignoreSwap: true).GetEnumerator();
			coolDown = 20;
		}
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_034a: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0358: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0396: Unknown result type (might be due to invalid IL or missing references)
		//IL_039d: Unknown result type (might be due to invalid IL or missing references)
		//IL_036c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		if (timeBeforeAIMovementAgain <= 0f)
		{
			base.IsInvisible = false;
		}
		if (teleporting)
		{
			coolDown -= time.ElapsedGameTime.Milliseconds;
			if (coolDown <= 0)
			{
				if (teleportationPath.MoveNext())
				{
					Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite(Sprite.textureName.Value, Sprite.SourceRect, base.Position, flipped: false, 0.04f, Color.White));
					base.Position = new Vector2((float)(teleportationPath.Current.X * 64 + 4), (float)(teleportationPath.Current.Y * 64 - 32 - 4));
					coolDown = 20;
				}
				else
				{
					teleporting = false;
					coolDown = 500;
				}
			}
		}
		else if (!spottedPlayer && Utility.couldSeePlayerInPeripheralVision(base.Player, this) && Utility.doesPointHaveLineOfSightInMine(base.currentLocation, base.Tile, base.Player.Tile, 8))
		{
			controller = null;
			spottedPlayer = true;
			Halt();
			facePlayer(base.Player);
			if (Game1.random.NextDouble() < 0.3)
			{
				base.currentLocation.playSound("shadowpeep");
			}
		}
		else if (casting)
		{
			Halt();
			base.IsWalkingTowardPlayer = false;
			rotationTimer = (float)((double)((float)time.TotalGameTime.Milliseconds * ((float)Math.PI / 128f) / 24f) % (Math.PI * 1024.0));
			coolDown -= time.ElapsedGameTime.Milliseconds;
			if (coolDown <= 0)
			{
				Rectangle boundingBox = GetBoundingBox();
				base.Scale = 1f;
				Vector2 velocityTowardPlayer = Utility.getVelocityTowardPlayer(((Rectangle)(ref boundingBox)).Center, 15f, base.Player);
				if (base.Player.Attack >= 0 && Game1.random.NextDouble() < 0.6)
				{
					base.currentLocation.projectiles.Add(new DebuffingProjectile("18", 2, 4, 4, (float)Math.PI / 16f, velocityTowardPlayer.X, velocityTowardPlayer.Y, new Vector2((float)boundingBox.X, (float)boundingBox.Y)));
				}
				else
				{
					base.currentLocation.playSound("fireball");
					base.currentLocation.projectiles.Add(new BasicProjectile(10, 3, 0, 3, 0f, velocityTowardPlayer.X, velocityTowardPlayer.Y, new Vector2((float)boundingBox.X, (float)boundingBox.Y)));
				}
				casting = false;
				coolDown = 1500;
				base.IsWalkingTowardPlayer = true;
			}
		}
		else if (spottedPlayer)
		{
			if (withinPlayerThreshold(8))
			{
				if (base.Health < 30)
				{
					base.IsWalkingTowardPlayer = false;
					Point standingPixel = base.StandingPixel;
					Point standingPixel2 = base.Player.StandingPixel;
					if (Math.Abs(standingPixel2.Y - standingPixel.Y) > 192)
					{
						if (standingPixel2.X - standingPixel.X > 0)
						{
							SetMovingLeft(b: true);
						}
						else
						{
							SetMovingRight(b: true);
						}
					}
					else if (standingPixel2.Y - standingPixel.Y > 0)
					{
						SetMovingUp(b: true);
					}
					else
					{
						SetMovingDown(b: true);
					}
				}
				else if (controller == null && !Utility.doesPointHaveLineOfSightInMine(base.currentLocation, base.Tile, base.Player.Tile, 8))
				{
					controller = new PathFindController(this, base.currentLocation, base.Player.TilePoint, -1, null, 300);
					if (controller?.pathToEndPoint == null || controller.pathToEndPoint.Count == 0)
					{
						spottedPlayer = false;
						Halt();
						controller = null;
						addedSpeed = 0f;
					}
				}
				else if (coolDown <= 0 && Game1.random.NextDouble() < 0.02)
				{
					casting = true;
					Halt();
					coolDown = 500;
				}
				coolDown -= time.ElapsedGameTime.Milliseconds;
			}
			else
			{
				base.IsWalkingTowardPlayer = false;
				spottedPlayer = false;
				controller = null;
				addedSpeed = 0f;
			}
		}
		else
		{
			defaultMovementBehavior(time);
		}
	}
}
