using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.Projectiles;

namespace StardewValley.Monsters;

[XmlInclude(typeof(BreathProjectile))]
public class DinoMonster : Monster
{
	public enum AttackState
	{
		None,
		Fireball,
		Charge
	}

	public class BreathProjectile : INetObject<NetFields>
	{
		public readonly NetBool active = new NetBool();

		public readonly NetVector2 position = new NetVector2();

		public readonly NetVector2 startPosition = new NetVector2();

		public readonly NetVector2 velocity = new NetVector2();

		public float rotation;

		public float alpha;

		public NetFields NetFields { get; } = new NetFields("BreathProjectile");

		public BreathProjectile()
		{
			NetFields.SetOwner(this).AddField(active, "active").AddField(position, "position")
				.AddField(startPosition, "startPosition")
				.AddField(velocity, "velocity");
			active.InterpolationEnabled = (active.InterpolationWait = false);
			position.InterpolationEnabled = (position.InterpolationWait = false);
			startPosition.InterpolationEnabled = (startPosition.InterpolationWait = false);
			velocity.InterpolationEnabled = (velocity.InterpolationWait = false);
		}

		public Rectangle GetBoundingBox()
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0039: Unknown result type (might be due to invalid IL or missing references)
			Vector2 value = position.Value;
			int num = 29;
			float num2 = 1f;
			num = (int)((float)num * num2);
			return new Rectangle((int)value.X + 32 - num / 2, (int)value.Y + 32 - num / 2, num, num);
		}

		public Rectangle GetSourceRect()
		{
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			return Game1.getSourceRectForStandardTileSheet(Projectile.projectileSheet, 10, 16, 16);
		}

		public void ExplosionAnimation(GameLocation location)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			Rectangle sourceRect = GetSourceRect();
			sourceRect.X += 4;
			sourceRect.Y += 4;
			sourceRect.Width = 8;
			sourceRect.Height = 8;
			Game1.createRadialDebris_MoreNatural(location, "TileSheets\\Projectiles", sourceRect, 1, (int)position.X + 32, (int)position.Y + 32, 6, (int)(position.Y / 64f) + 1);
		}

		public void Update(GameTime time, GameLocation location, DinoMonster parent)
		{
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Unknown result type (might be due to invalid IL or missing references)
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
			//IL_010a: Unknown result type (might be due to invalid IL or missing references)
			//IL_010f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0116: Unknown result type (might be due to invalid IL or missing references)
			//IL_015f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0169: Unknown result type (might be due to invalid IL or missing references)
			//IL_0176: Unknown result type (might be due to invalid IL or missing references)
			//IL_0177: Unknown result type (might be due to invalid IL or missing references)
			if (!active.Value)
			{
				return;
			}
			NetVector2 netVector = position;
			netVector.Value += velocity.Value;
			if (!Game1.IsMasterGame)
			{
				position.MarkClean();
				position.ResetNewestReceivedChangeVersion();
			}
			float num = Vector2.Distance(position.Value, startPosition.Value);
			if (num > 128f)
			{
				alpha = (256f - num) / 128f;
			}
			else
			{
				alpha = 1f;
			}
			if (num > 256f)
			{
				active.Value = false;
				return;
			}
			Rectangle boundingBox = GetBoundingBox();
			if (Game1.player.currentLocation == location && Game1.player.CanBeDamaged() && ((Rectangle)(ref boundingBox)).Intersects(Game1.player.GetBoundingBox()))
			{
				Game1.player.takeDamage(25, overrideParry: false, null);
				ExplosionAnimation(location);
				active.Value = false;
				return;
			}
			foreach (Vector2 item in Utility.getListOfTileLocationsForBordersOfNonTileRectangle(boundingBox))
			{
				if (location.terrainFeatures.TryGetValue(item, out var value) && !value.isPassable())
				{
					ExplosionAnimation(location);
					active.Value = false;
					return;
				}
			}
			if (!location.isTileOnMap(position.Value / 64f) || location.isCollidingPosition(boundingBox, Game1.viewport, isFarmer: false, 0, glider: true, parent, pathfinding: false, projectile: true))
			{
				ExplosionAnimation(location);
				active.Value = false;
			}
		}

		public void Draw(SpriteBatch b)
		{
			//IL_001b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			//IL_002c: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0074: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			if (active.Value)
			{
				float num = 4f;
				Texture2D projectileSheet = Projectile.projectileSheet;
				Rectangle sourceRect = GetSourceRect();
				Vector2 value = position.Value;
				b.Draw(projectileSheet, Game1.GlobalToLocal(Game1.viewport, value + new Vector2(32f, 32f)), (Rectangle?)sourceRect, Color.White * alpha, rotation, new Vector2(8f, 8f), num, (SpriteEffects)0, (value.Y + 96f) / 10000f);
			}
		}
	}

	public int timeUntilNextAttack;

	public readonly NetBool firing = new NetBool(value: false);

	public NetInt attackState = new NetInt();

	public int nextFireTime;

	public int totalFireTime;

	public int nextChangeDirectionTime;

	public int nextWanderTime;

	public bool wanderState;

	public readonly NetObjectArray<BreathProjectile> projectiles = new NetObjectArray<BreathProjectile>(15);

	public int lastProjectileSlot;

	public DinoMonster()
	{
	}

	public DinoMonster(Vector2 position)
		: base("Pepper Rex", position)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		Sprite.SpriteWidth = 32;
		Sprite.SpriteHeight = 32;
		Sprite.UpdateSourceRect();
		timeUntilNextAttack = 2000;
		nextChangeDirectionTime = Game1.random.Next(1000, 3000);
		nextWanderTime = Game1.random.Next(1000, 2000);
		for (int i = 0; i < projectiles.Count; i++)
		{
			projectiles[i] = new BreathProjectile();
		}
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(attackState, "attackState").AddField(firing, "firing").AddField(projectiles, "projectiles");
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		base.reloadSprite(onlyAppearance);
		Sprite.SpriteWidth = 32;
		Sprite.SpriteHeight = 32;
		Sprite.UpdateSourceRect();
	}

	public override void draw(SpriteBatch b)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		if (base.Health > 0 && !base.IsInvisible && Utility.isOnScreen(base.Position, 128))
		{
			int y = base.StandingPixel.Y;
			b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(56f, (float)(16 + yJumpOffset)), (Rectangle?)Sprite.SourceRect, Color.White, rotation, new Vector2(16f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f)));
			if (isGlowing)
			{
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(56f, (float)(16 + yJumpOffset)), (Rectangle?)Sprite.SourceRect, glowingColor * glowingTransparency, 0f, new Vector2(16f, 16f), 4f * Math.Max(0.2f, scale.Value), (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f + 0.001f)));
			}
		}
		foreach (BreathProjectile projectile in projectiles)
		{
			if (Utility.isOnScreen(projectile.position.Value, 64))
			{
				projectile.Draw(b);
			}
		}
	}

	public override Rectangle GetBoundingBox()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (base.Health <= 0)
		{
			return new Rectangle(-100, -100, 0, 0);
		}
		Vector2 val = base.Position;
		return new Rectangle((int)val.X + 8, (int)val.Y, Sprite.SpriteWidth * 4 * 3 / 4, 64);
	}

	public override List<Item> getExtraDropItems()
	{
		List<Item> list = new List<Item>();
		if (Game1.random.NextDouble() < 0.10000000149011612)
		{
			list.Add(ItemRegistry.Create("(O)107"));
		}
		else
		{
			Item[] options = new Item[3]
			{
				ItemRegistry.Create("(O)580"),
				ItemRegistry.Create("(O)583"),
				ItemRegistry.Create("(O)584")
			};
			list.Add(Game1.random.ChooseFrom(options));
		}
		return list;
	}

	public override bool ShouldMonsterBeRemoved()
	{
		foreach (BreathProjectile projectile in projectiles)
		{
			if (projectile.active.Value)
			{
				return false;
			}
		}
		return base.ShouldMonsterBeRemoved();
	}

	protected override void sharedDeathAnimation()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.playSound("skeletonDie");
		base.currentLocation.playSound("grunt");
		Rectangle boundingBox = GetBoundingBox();
		for (int i = 0; i < 16; i++)
		{
			Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(64, 128, 16, 16), 16, (int)Utility.Lerp(((Rectangle)(ref boundingBox)).Left, ((Rectangle)(ref boundingBox)).Right, (float)Game1.random.NextDouble()), (int)Utility.Lerp(((Rectangle)(ref boundingBox)).Bottom, ((Rectangle)(ref boundingBox)).Top, (float)Game1.random.NextDouble()), 1, base.TilePoint.Y, Color.White, 4f);
		}
	}

	protected override void localDeathAnimation()
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		Utility.makeTemporarySpriteJuicier(new TemporaryAnimatedSprite(44, base.Position, Color.HotPink, 10)
		{
			holdLastFrame = true,
			alphaFade = 0.01f,
			interval = 70f
		}, base.currentLocation, 8, 96);
	}

	public override void update(GameTime time, GameLocation location)
	{
		if (base.Health > 0)
		{
			base.update(time, location);
		}
		foreach (BreathProjectile projectile in projectiles)
		{
			projectile.Update(time, location, this);
		}
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0405: Unknown result type (might be due to invalid IL or missing references)
		//IL_040c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		//IL_0441: Unknown result type (might be due to invalid IL or missing references)
		//IL_0443: Unknown result type (might be due to invalid IL or missing references)
		//IL_0444: Unknown result type (might be due to invalid IL or missing references)
		//IL_044b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0459: Unknown result type (might be due to invalid IL or missing references)
		if (attackState.Value == 1)
		{
			base.IsWalkingTowardPlayer = false;
			Halt();
		}
		else if (withinPlayerThreshold())
		{
			base.IsWalkingTowardPlayer = true;
		}
		else
		{
			base.IsWalkingTowardPlayer = false;
			nextChangeDirectionTime -= time.ElapsedGameTime.Milliseconds;
			nextWanderTime -= time.ElapsedGameTime.Milliseconds;
			if (nextChangeDirectionTime < 0)
			{
				nextChangeDirectionTime = Game1.random.Next(500, 1000);
				facingDirection.Value = (facingDirection.Value + (Game1.random.Next(0, 3) - 1) + 4) % 4;
			}
			if (nextWanderTime < 0)
			{
				if (wanderState)
				{
					nextWanderTime = Game1.random.Next(1000, 2000);
				}
				else
				{
					nextWanderTime = Game1.random.Next(1000, 3000);
				}
				wanderState = !wanderState;
			}
			if (wanderState)
			{
				moveLeft = (moveUp = (moveRight = (moveDown = false)));
				tryToMoveInDirection(facingDirection.Value, isFarmer: false, base.DamageToFarmer, isGlider.Value);
			}
		}
		timeUntilNextAttack -= time.ElapsedGameTime.Milliseconds;
		if (attackState.Value == 0 && withinPlayerThreshold(2))
		{
			firing.Set(newValue: false);
			if (timeUntilNextAttack < 0)
			{
				timeUntilNextAttack = 0;
				attackState.Set(1);
				nextFireTime = 500;
				totalFireTime = 3000;
				base.currentLocation.playSound("croak");
			}
		}
		else
		{
			if (totalFireTime <= 0)
			{
				return;
			}
			if (!firing.Value)
			{
				Farmer player = base.Player;
				if (player != null)
				{
					faceGeneralDirection(player.Position);
				}
			}
			totalFireTime -= time.ElapsedGameTime.Milliseconds;
			if (nextFireTime > 0)
			{
				nextFireTime -= time.ElapsedGameTime.Milliseconds;
				if (nextFireTime <= 0)
				{
					if (!firing.Value)
					{
						firing.Set(newValue: true);
						base.currentLocation.playSound("furnace");
					}
					float num = 0f;
					Point standingPixel = base.StandingPixel;
					Vector2 val = default(Vector2);
					((Vector2)(ref val))._002Ector((float)standingPixel.X - 32f, (float)standingPixel.Y - 32f);
					switch (facingDirection.Value)
					{
					case 0:
						yVelocity = -1f;
						val.Y -= 64f;
						num = 90f;
						break;
					case 1:
						xVelocity = -1f;
						val.X += 64f;
						num = 0f;
						break;
					case 3:
						xVelocity = 1f;
						val.X -= 64f;
						num = 180f;
						break;
					case 2:
						yVelocity = 1f;
						num = 270f;
						break;
					}
					num += (float)Math.Sin((double)((float)totalFireTime / 1000f * 180f) * Math.PI / 180.0) * 25f;
					Vector2 val2 = default(Vector2);
					((Vector2)(ref val2))._002Ector((float)Math.Cos((double)num * Math.PI / 180.0), 0f - (float)Math.Sin((double)num * Math.PI / 180.0));
					val2 *= 10f;
					BreathProjectile breathProjectile = projectiles[lastProjectileSlot];
					breathProjectile.active.Value = true;
					NetVector2 netVector = breathProjectile.position;
					Vector2 value = (breathProjectile.startPosition.Value = val);
					netVector.Value = value;
					breathProjectile.velocity.Value = val2;
					lastProjectileSlot = (lastProjectileSlot + 1) % projectiles.Count;
					nextFireTime = 70;
				}
			}
			if (totalFireTime <= 0)
			{
				totalFireTime = 0;
				nextFireTime = 0;
				attackState.Set(0);
				timeUntilNextAttack = Game1.random.Next(1000, 2000);
			}
		}
	}

	protected override void updateAnimation(GameTime time)
	{
		int num = 0;
		switch (FacingDirection)
		{
		case 2:
			num = 0;
			break;
		case 1:
			num = 4;
			break;
		case 0:
			num = 8;
			break;
		case 3:
			num = 12;
			break;
		}
		if (attackState.Value == 1)
		{
			if (firing.Value)
			{
				Sprite.CurrentFrame = 16 + num;
			}
			else
			{
				Sprite.CurrentFrame = 17 + num;
			}
			return;
		}
		if (isMoving() || wanderState)
		{
			switch (FacingDirection)
			{
			case 0:
				Sprite.AnimateUp(time);
				break;
			case 3:
				Sprite.AnimateLeft(time);
				break;
			case 1:
				Sprite.AnimateRight(time);
				break;
			case 2:
				Sprite.AnimateDown(time);
				break;
			}
			return;
		}
		switch (FacingDirection)
		{
		case 0:
			Sprite.AnimateUp(time);
			break;
		case 3:
			Sprite.AnimateLeft(time);
			break;
		case 1:
			Sprite.AnimateRight(time);
			break;
		case 2:
			Sprite.AnimateDown(time);
			break;
		}
		Sprite.StopAnimation();
	}

	protected override void updateMonsterSlaveAnimation(GameTime time)
	{
		int num = 0;
		switch (FacingDirection)
		{
		case 2:
			num = 0;
			break;
		case 1:
			num = 4;
			break;
		case 0:
			num = 8;
			break;
		case 3:
			num = 12;
			break;
		}
		if (attackState.Value == 1)
		{
			if (firing.Value)
			{
				Sprite.CurrentFrame = 16 + num;
			}
			else
			{
				Sprite.CurrentFrame = 17 + num;
			}
		}
		else if (isMoving())
		{
			switch (FacingDirection)
			{
			case 0:
				Sprite.AnimateUp(time);
				break;
			case 3:
				Sprite.AnimateLeft(time);
				break;
			case 1:
				Sprite.AnimateRight(time);
				break;
			case 2:
				Sprite.AnimateDown(time);
				break;
			}
		}
		else
		{
			Sprite.StopAnimation();
		}
	}
}
