using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Extensions;

namespace StardewValley.Monsters;

public class Fly : Monster
{
	public const float rotationIncrement = (float)Math.PI / 64f;

	public const int volumeTileRange = 16;

	public const int spawnTime = 1000;

	[XmlIgnore]
	public int spawningCounter = 1000;

	[XmlIgnore]
	public int wasHitCounter;

	[XmlIgnore]
	public float targetRotation;

	public static ICue buzz;

	[XmlIgnore]
	public bool turningRight;

	public bool hard;

	public Fly()
	{
	}

	public Fly(Vector2 position)
		: this(position, hard: false)
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public Fly(Vector2 position, bool hard)
		: base("Fly", position)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		base.Slipperiness = 24 + Game1.random.Next(-10, 10);
		Halt();
		base.IsWalkingTowardPlayer = false;
		this.hard = hard;
		if (hard)
		{
			base.DamageToFarmer *= 2;
			base.MaxHealth *= 3;
			base.Health = base.MaxHealth;
		}
		base.HideShadow = true;
	}

	public void setHard()
	{
		hard = true;
		if (hard)
		{
			base.DamageToFarmer = 12;
			base.MaxHealth = 66;
			base.Health = base.MaxHealth;
		}
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		Sprite = new AnimatedSprite("Characters\\Monsters\\Fly");
		base.HideShadow = true;
		if (!onlyAppearance)
		{
			buzz = Game1.soundBank.GetCue("flybuzzing");
		}
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		int num = Math.Max(1, damage - resilience.Value);
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Health -= num;
			setTrajectory(xTrajectory / 3, yTrajectory / 3);
			wasHitCounter = 500;
			base.currentLocation?.playSound("hitEnemy");
			if (base.Health <= 0)
			{
				if (base.currentLocation != null)
				{
					base.currentLocation.playSound("monsterdead");
					Utility.makeTemporarySpriteJuicier(new TemporaryAnimatedSprite(44, base.Position, Color.HotPink, 10)
					{
						interval = 70f
					}, base.currentLocation);
				}
				buzz?.Stop((AudioStopOptions)0);
			}
		}
		addedSpeed = Game1.random.Next(-1, 1);
		return num;
	}

	public override void drawAboveAllLayers(SpriteBatch b)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		if (Utility.isOnScreen(base.Position, 128))
		{
			int height = GetBoundingBox().Height;
			int y = base.StandingPixel.Y;
			b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(height / 2 - 32)), (Rectangle?)Sprite.SourceRect, hard ? Color.Lime : Color.White, rotation, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)(y + 8) / 10000f)));
			Texture2D shadowTexture = Game1.shadowTexture;
			Vector2 val = getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(height / 2));
			Rectangle? val2 = Game1.shadowTexture.Bounds;
			Color white = Color.White;
			Rectangle bounds = Game1.shadowTexture.Bounds;
			float num = ((Rectangle)(ref bounds)).Center.X;
			bounds = Game1.shadowTexture.Bounds;
			b.Draw(shadowTexture, val, val2, white, 0f, new Vector2(num, (float)((Rectangle)(ref bounds)).Center.Y), 4f, (SpriteEffects)0, (float)(y - 1) / 10000f);
			if (isGlowing)
			{
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(height / 2 - 32)), (Rectangle?)Sprite.SourceRect, glowingColor * glowingTransparency, rotation, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.99f : ((float)y / 10000f + 0.001f)));
			}
		}
	}

	public override void drawAboveAlwaysFrontLayer(SpriteBatch b)
	{
		if (base.currentLocation != null && base.currentLocation.treatAsOutdoors.Value)
		{
			drawAboveAllLayers(b);
		}
	}

	protected override void updateAnimation(GameTime time)
	{
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		if ((buzz == null || !buzz.IsPlaying) && (base.currentLocation == null || base.currentLocation.Equals(Game1.currentLocation)))
		{
			Game1.playSound("flybuzzing", out buzz);
			buzz.SetVariable("Volume", 0f);
		}
		if ((double)Game1.fadeToBlackAlpha > 0.8 && Game1.fadeIn && buzz != null)
		{
			buzz.Stop((AudioStopOptions)0);
		}
		else if (buzz != null)
		{
			buzz.SetVariable("Volume", Math.Max(0f, buzz.GetVariable("Volume") - 1f));
			float num = Math.Max(0f, 100f - Vector2.Distance(base.Position, base.Player.Position) / 64f / 16f * 100f);
			if (num > buzz.GetVariable("Volume"))
			{
				buzz.SetVariable("Volume", num);
			}
		}
		if (wasHitCounter >= 0)
		{
			wasHitCounter -= time.ElapsedGameTime.Milliseconds;
		}
		Sprite.Animate(time, (FacingDirection == 0) ? 8 : ((FacingDirection != 2) ? (FacingDirection * 4) : 0), 4, 75f);
		if (spawningCounter >= 0)
		{
			spawningCounter -= time.ElapsedGameTime.Milliseconds;
			base.Scale = 1f - (float)spawningCounter / 1000f;
		}
		else if ((withinPlayerThreshold() || Utility.isOnScreen(base.Position, 256)) && invincibleCountdown <= 0)
		{
			faceDirection(0);
			Point standingPixel = base.StandingPixel;
			Point standingPixel2 = base.Player.StandingPixel;
			float num2 = -(standingPixel2.X - standingPixel.X);
			float num3 = standingPixel2.Y - standingPixel.Y;
			float num4 = Math.Max(1f, Math.Abs(num2) + Math.Abs(num3));
			if (num4 < 64f)
			{
				xVelocity = Math.Max(-7f, Math.Min(7f, xVelocity * 1.1f));
				yVelocity = Math.Max(-7f, Math.Min(7f, yVelocity * 1.1f));
			}
			num2 /= num4;
			num3 /= num4;
			if (wasHitCounter <= 0)
			{
				targetRotation = (float)Math.Atan2(0f - num3, num2) - (float)Math.PI / 2f;
				if ((double)(Math.Abs(targetRotation) - Math.Abs(rotation)) > Math.PI * 7.0 / 8.0 && Game1.random.NextBool())
				{
					turningRight = true;
				}
				else if ((double)(Math.Abs(targetRotation) - Math.Abs(rotation)) < Math.PI / 8.0)
				{
					turningRight = false;
				}
				if (turningRight)
				{
					rotation -= (float)Math.Sign(targetRotation - rotation) * ((float)Math.PI / 64f);
				}
				else
				{
					rotation += (float)Math.Sign(targetRotation - rotation) * ((float)Math.PI / 64f);
				}
				rotation %= (float)Math.PI * 2f;
				wasHitCounter = 5 + Game1.random.Next(-1, 2);
			}
			float num5 = Math.Min(7f, Math.Max(2f, 7f - num4 / 64f / 2f));
			num2 = (float)Math.Cos((double)rotation + Math.PI / 2.0);
			num3 = 0f - (float)Math.Sin((double)rotation + Math.PI / 2.0);
			xVelocity += (0f - num2) * num5 / 6f + (float)Game1.random.Next(-10, 10) / 100f;
			yVelocity += (0f - num3) * num5 / 6f + (float)Game1.random.Next(-10, 10) / 100f;
			if (Math.Abs(xVelocity) > Math.Abs((0f - num2) * 7f))
			{
				xVelocity -= (0f - num2) * num5 / 6f;
			}
			if (Math.Abs(yVelocity) > Math.Abs((0f - num3) * 7f))
			{
				yVelocity -= (0f - num3) * num5 / 6f;
			}
		}
		resetAnimationSpeed();
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		if (double.IsNaN(xVelocity) || double.IsNaN(yVelocity))
		{
			base.Health = -500;
		}
		if (base.Position.X <= -640f || base.Position.Y <= -640f || base.Position.X >= (float)(base.currentLocation.Map.Layers[0].LayerWidth * 64 + 640) || base.Position.Y >= (float)(base.currentLocation.Map.Layers[0].LayerHeight * 64 + 640))
		{
			base.Health = -500;
		}
	}

	public override void Removed()
	{
		base.Removed();
		buzz?.Stop((AudioStopOptions)0);
	}
}
