using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.Locations;

namespace StardewValley.Monsters;

public class Grub : Monster
{
	public const int healthToRunAway = 8;

	[XmlIgnore]
	public readonly NetBool leftDrift = new NetBool();

	[XmlIgnore]
	public readonly NetBool pupating = new NetBool();

	[XmlElement("hard")]
	public readonly NetBool hard = new NetBool();

	[XmlIgnore]
	public int metamorphCounter = 2000;

	[XmlIgnore]
	public readonly NetFloat targetRotation = new NetFloat();

	public Grub()
	{
	}

	public Grub(Vector2 position)
		: this(position, hard: false)
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public Grub(Vector2 position, bool hard)
		: base("Grub", position)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		if (Game1.random.NextBool())
		{
			leftDrift.Value = true;
		}
		FacingDirection = Game1.random.Next(4);
		targetRotation.Value = (rotation = (float)Game1.random.Next(4) / (float)Math.PI);
		this.hard.Value = hard;
		if (hard)
		{
			base.DamageToFarmer *= 3;
			base.Health *= 5;
			base.MaxHealth = base.Health;
			base.ExperienceGained *= 3;
			if (Game1.random.NextDouble() < 0.1)
			{
				objectsToDrop.Add("456");
			}
		}
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(leftDrift, "leftDrift").AddField(pupating, "pupating").AddField(hard, "hard")
			.AddField(targetRotation, "targetRotation");
		position.Field.AxisAlignedMovement = true;
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		base.reloadSprite(onlyAppearance);
		Sprite.SpriteHeight = 24;
		Sprite.UpdateSourceRect();
	}

	public void setHard()
	{
		hard.Value = true;
		if (hard.Value)
		{
			base.DamageToFarmer = 12;
			base.Health = 100;
			base.MaxHealth = base.Health;
			base.ExperienceGained = 10;
			if (Game1.random.NextDouble() < 0.1)
			{
				objectsToDrop.Add("456");
			}
		}
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		int num = Math.Max(1, damage - resilience.Value);
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.currentLocation.playSound("slimeHit");
			if (pupating.Value)
			{
				base.currentLocation.playSound("crafting");
				setTrajectory(xTrajectory / 2, yTrajectory / 2);
				return 0;
			}
			base.Slipperiness = 4;
			base.Health -= num;
			setTrajectory(xTrajectory, yTrajectory);
			if (base.Health <= 0)
			{
				base.currentLocation.playSound("slimedead");
				Utility.makeTemporarySpriteJuicier(new TemporaryAnimatedSprite(44, base.Position, isHardModeMonster.Value ? Color.LimeGreen : Color.Orange, 10)
				{
					holdLastFrame = true,
					alphaFade = 0.01f,
					interval = 50f
				}, base.currentLocation);
			}
		}
		return num;
	}

	public override void defaultMovementBehavior(GameTime time)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		base.Scale = 1f + (float)(0.125 * Math.Sin(time.TotalGameTime.TotalMilliseconds / (double)(500f + base.Position.X / 100f)));
	}

	public override void BuffForAdditionalDifficulty(int additional_difficulty)
	{
		base.BuffForAdditionalDifficulty(additional_difficulty);
		rotation = 0f;
		targetRotation.Value = 0f;
	}

	public override void update(GameTime time, GameLocation location)
	{
		if ((base.Health > 8 || (hard.Value && base.Health >= base.MaxHealth)) && !pupating.Value)
		{
			base.update(time, location);
			return;
		}
		if (invincibleCountdown > 0)
		{
			invincibleCountdown -= time.ElapsedGameTime.Milliseconds;
			if (invincibleCountdown <= 0)
			{
				stopGlowing();
			}
		}
		if (Game1.IsMasterGame)
		{
			behaviorAtGameTick(time);
		}
		updateAnimation(time);
	}

	public override void draw(SpriteBatch b)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2((float)(Sprite.SpriteWidth * 4 / 2), (float)(GetBoundingBox().Height / 2)) + (Vector2)((shakeTimer > 0) ? new Vector2((float)Game1.random.Next(-1, 2), (float)Game1.random.Next(-1, 2)) : Vector2.Zero), (Rectangle?)Sprite.SourceRect, hard.Value ? Color.Lime : Color.White, rotation, new Vector2((float)(Sprite.SpriteWidth / 2), (float)Sprite.SpriteHeight * 3f / 4f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)((flip || (Sprite.CurrentAnimation != null && Sprite.CurrentAnimation[Sprite.currentAnimationIndex].flip)) ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)base.StandingPixel.Y / 10000f)));
	}

	protected override void updateMonsterSlaveAnimation(GameTime time)
	{
		if (pupating.Value)
		{
			base.Scale = 1f + (float)Math.Sin((float)time.TotalGameTime.Milliseconds * ((float)Math.PI / 8f)) / 12f;
			metamorphCounter -= time.ElapsedGameTime.Milliseconds;
		}
		else if (base.Health <= 8 || (hard.Value && base.Health < base.MaxHealth))
		{
			metamorphCounter -= time.ElapsedGameTime.Milliseconds;
			if (metamorphCounter <= 0)
			{
				Sprite.Animate(time, 16, 4, 125f);
				if (Sprite.currentFrame == 19)
				{
					metamorphCounter = 4500;
				}
			}
		}
		else if (isMoving())
		{
			switch (FacingDirection)
			{
			case 0:
				Sprite.AnimateUp(time);
				break;
			case 3:
				Sprite.AnimateLeft(time);
				break;
			case 1:
				Sprite.AnimateRight(time);
				break;
			case 2:
				Sprite.AnimateDown(time);
				break;
			}
			rotation = 0f;
			base.Scale = 1f;
		}
		else if (!withinPlayerThreshold())
		{
			Halt();
			rotation = targetRotation.Value;
		}
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		if (pupating.Value)
		{
			base.Scale = 1f + (float)Math.Sin((float)time.TotalGameTime.Milliseconds * ((float)Math.PI / 8f)) / 12f;
			metamorphCounter -= time.ElapsedGameTime.Milliseconds;
			if (metamorphCounter <= 0)
			{
				Point standingPixel = base.StandingPixel;
				base.Health = -500;
				Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(208, 424, 32, 40), 4, standingPixel.X, standingPixel.Y, 25, base.TilePoint.Y);
				Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(208, 424, 32, 40), 8, standingPixel.X, standingPixel.Y, 15, base.TilePoint.Y);
				if (base.currentLocation is MineShaft mineShaft)
				{
					base.currentLocation.characters.Add(mineShaft.BuffMonsterIfNecessary(new Fly(base.Position, hard.Value)
					{
						currentLocation = base.currentLocation
					}));
				}
				else
				{
					base.currentLocation.characters.Add(new Fly(base.Position, hard.Value)
					{
						currentLocation = base.currentLocation
					});
				}
			}
		}
		else if (base.Health <= base.MaxHealth / 2 - 2 || (hard.Value && base.Health < base.MaxHealth))
		{
			metamorphCounter -= time.ElapsedGameTime.Milliseconds;
			if (metamorphCounter <= 0)
			{
				Sprite.Animate(time, 16, 4, 125f);
				if (Sprite.currentFrame == 19)
				{
					pupating.Value = true;
					metamorphCounter = 4500;
				}
				return;
			}
			Point standingPixel2 = base.StandingPixel;
			Point standingPixel3 = base.Player.StandingPixel;
			if (Math.Abs(standingPixel3.Y - standingPixel2.Y) > 128)
			{
				if (standingPixel3.X > standingPixel2.X)
				{
					SetMovingLeft(b: true);
				}
				else
				{
					SetMovingRight(b: true);
				}
			}
			else if (Math.Abs(standingPixel3.X - standingPixel2.X) > 128)
			{
				if (standingPixel3.Y > standingPixel2.Y)
				{
					SetMovingUp(b: true);
				}
				else
				{
					SetMovingDown(b: true);
				}
			}
			MovePosition(time, Game1.viewport, base.currentLocation);
		}
		else if (withinPlayerThreshold())
		{
			base.Scale = 1f;
			rotation = 0f;
		}
		else if (isMoving())
		{
			Halt();
			faceDirection(Game1.random.Next(4));
			targetRotation.Value = (rotation = (float)Game1.random.Next(4) / (float)Math.PI);
		}
	}
}
