using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;

namespace StardewValley.Monsters;

public class Spiker : Monster
{
	[XmlIgnore]
	public int targetDirection;

	[XmlIgnore]
	public NetBool moving = new NetBool(value: false);

	protected bool _localMoving;

	[XmlIgnore]
	public float nextMoveCheck;

	public Spiker()
	{
	}

	public Spiker(Vector2 position, int direction)
		: base("Spiker", position)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Sprite.SpriteWidth = 16;
		Sprite.SpriteHeight = 16;
		Sprite.UpdateSourceRect();
		targetDirection = direction;
		base.speed = 14;
		ignoreMovementAnimations = true;
		onCollision = collide;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(moving, "moving");
	}

	public override void update(GameTime time, GameLocation location)
	{
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		base.update(time, location);
		if (moving.Value == _localMoving)
		{
			return;
		}
		_localMoving = moving.Value;
		if (_localMoving)
		{
			if (base.currentLocation == Game1.currentLocation && Utility.isOnScreen(base.Position, 64))
			{
				Game1.playSound("parry");
			}
		}
		else if (base.currentLocation == Game1.currentLocation && Utility.isOnScreen(base.Position, 64))
		{
			Game1.playSound("hammer");
		}
	}

	public override void draw(SpriteBatch b)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		Sprite.draw(b, Game1.GlobalToLocal(Game1.viewport, base.Position), (float)base.StandingPixel.Y / 10000f);
	}

	private void collide(GameLocation location)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		Rectangle val = nextPosition(FacingDirection);
		foreach (Farmer farmer in location.farmers)
		{
			Rectangle boundingBox = farmer.GetBoundingBox();
			if (((Rectangle)(ref boundingBox)).Intersects(val))
			{
				return;
			}
		}
		if (moving.Value)
		{
			moving.Value = false;
			targetDirection = (targetDirection + 2) % 4;
			nextMoveCheck = 0.75f;
		}
	}

	public override void updateMovement(GameLocation location, GameTime time)
	{
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		return -1;
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		if (nextMoveCheck > 0f)
		{
			nextMoveCheck -= (float)time.ElapsedGameTime.TotalSeconds;
		}
		if (nextMoveCheck <= 0f)
		{
			nextMoveCheck = 0.25f;
			foreach (Farmer farmer in base.currentLocation.farmers)
			{
				if ((targetDirection == 0 || targetDirection == 2) && Math.Abs(farmer.TilePoint.X - base.TilePoint.X) <= 1)
				{
					if (targetDirection == 0 && farmer.Position.Y < base.Position.Y)
					{
						moving.Value = true;
						break;
					}
					if (targetDirection == 2 && farmer.Position.Y > base.Position.Y)
					{
						moving.Value = true;
						break;
					}
				}
				if ((targetDirection == 3 || targetDirection == 1) && Math.Abs(farmer.TilePoint.Y - base.TilePoint.Y) <= 1)
				{
					if (targetDirection == 3 && farmer.Position.X < base.Position.X)
					{
						moving.Value = true;
						break;
					}
					if (targetDirection == 1 && farmer.Position.X > base.Position.X)
					{
						moving.Value = true;
						break;
					}
				}
			}
		}
		moveUp = false;
		moveDown = false;
		moveLeft = false;
		moveRight = false;
		if (moving.Value)
		{
			switch (targetDirection)
			{
			case 0:
				moveUp = true;
				break;
			case 2:
				moveDown = true;
				break;
			case 3:
				moveLeft = true;
				break;
			case 1:
				moveRight = true;
				break;
			}
			MovePosition(time, Game1.viewport, base.currentLocation);
		}
		faceDirection(2);
	}
}
