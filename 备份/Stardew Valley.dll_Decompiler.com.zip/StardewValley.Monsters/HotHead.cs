using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.Network;

namespace StardewValley.Monsters;

public class HotHead : MetalHead
{
	[XmlIgnore]
	public NetFarmerRef lastAttacker = new NetFarmerRef();

	[XmlIgnore]
	public NetFloat timeUntilExplode = new NetFloat(-1f);

	[XmlIgnore]
	public NetBool angry = new NetBool();

	public HotHead()
	{
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(lastAttacker.NetFields, "lastAttacker.NetFields").AddField(angry, "angry").AddField(timeUntilExplode, "timeUntilExplode");
	}

	public HotHead(Vector2 position)
		: base("Hot Head", position)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		base.Slipperiness *= 2;
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		lastAttacker.Value = who;
		int result = base.takeDamage(damage, xTrajectory, yTrajectory, isBomb, addedPrecision, who);
		if (timeUntilExplode.Value == -1f && base.Health < 25)
		{
			base.currentLocation.netAudio.StartPlaying("fuse");
			timeUntilExplode.Value = 2.4f;
			base.Speed = 5;
			angry.Value = true;
		}
		return result;
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		if (Game1.IsMasterGame && timeUntilExplode.Value > 0f)
		{
			timeUntilExplode.Value -= (float)time.ElapsedGameTime.TotalSeconds;
			if (timeUntilExplode.Value <= 0f)
			{
				base.currentLocation.netAudio.StopPlaying("fuse");
				timeUntilExplode.Value = 0f;
				DropBomb();
				base.Health = -9999;
				return;
			}
		}
		base.behaviorAtGameTick(time);
	}

	public virtual void DropBomb()
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.netAudio.StopPlaying("fuse");
		if (lastAttacker.Value != null)
		{
			Farmer value = lastAttacker.Value;
			int extraInfoForEndBehavior = Game1.random.Next();
			base.currentLocation.playSound("thudStep");
			Vector2 tile = base.Tile;
			float y = base.Position.Y;
			float num = 2.4f;
			if (timeUntilExplode.Value >= 0f)
			{
				num = timeUntilExplode.Value;
				base.currentLocation.netAudio.StartPlaying("fuse");
			}
			int numberOfLoops = Math.Max(1, (int)(num * 1000f / 100f));
			Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite("Characters\\Monsters\\Hot Head", new Rectangle(16, 64, 16, 16), 25f, 3, numberOfLoops, tile * 64f, flicker: false, Game1.random.NextBool())
			{
				shakeIntensity = 0.5f,
				shakeIntensityChange = 0.002f,
				extraInfoForEndBehavior = extraInfoForEndBehavior,
				endFunction = base.currentLocation.removeTemporarySpritesWithID,
				bombRadius = 2,
				bombDamage = base.DamageToFarmer,
				Parent = base.currentLocation,
				scale = 4f,
				owner = value
			});
			Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(598, 1279, 3, 4), 53f, 5, 9, tile * 64f, flicker: true, flipped: false, (y + 7f) / 10000f, 0f, Color.Yellow, 4f, 0f, 0f, 0f)
			{
				id = extraInfoForEndBehavior
			});
			Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(598, 1279, 3, 4), 53f, 5, 9, tile * 64f, flicker: true, flipped: false, (y + 7f) / 10000f, 0f, Color.Orange, 4f, 0f, 0f, 0f)
			{
				delayBeforeAnimationStart = 100,
				id = extraInfoForEndBehavior
			});
			Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(598, 1279, 3, 4), 53f, 5, 9, tile * 64f, flicker: true, flipped: false, (y + 7f) / 10000f, 0f, Color.White, 3f, 0f, 0f, 0f)
			{
				delayBeforeAnimationStart = 200,
				id = extraInfoForEndBehavior
			});
		}
	}

	protected override void sharedDeathAnimation()
	{
		base.sharedDeathAnimation();
		DropBomb();
	}

	public override void draw(SpriteBatch b)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		if (angry.Value)
		{
			if (!base.IsInvisible && Utility.isOnScreen(base.Position, 128))
			{
				Rectangle sourceRect = Sprite.SourceRect;
				sourceRect.Y += 80;
				int y = base.StandingPixel.Y;
				Texture2D shadowTexture = Game1.shadowTexture;
				Vector2 val = getLocalPosition(Game1.viewport) + new Vector2(32f, 42f + yOffset);
				Rectangle? val2 = Game1.shadowTexture.Bounds;
				Color white = Color.White;
				Rectangle bounds = Game1.shadowTexture.Bounds;
				float num = ((Rectangle)(ref bounds)).Center.X;
				bounds = Game1.shadowTexture.Bounds;
				b.Draw(shadowTexture, val, val2, white, 0f, new Vector2(num, (float)((Rectangle)(ref bounds)).Center.Y), 3.5f + scale.Value + yOffset / 30f, (SpriteEffects)0, (float)(y - 1) / 10000f);
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(48 + yJumpOffset)), (Rectangle?)sourceRect, c.Value, rotation, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f)));
			}
		}
		else
		{
			base.draw(b);
		}
	}
}
