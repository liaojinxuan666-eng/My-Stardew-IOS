using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Enchantments;
using StardewValley.Locations;
using StardewValley.Tools;

namespace StardewValley.Monsters;

public class Bug : Monster
{
	[XmlElement("isArmoredBug")]
	public readonly NetBool isArmoredBug = new NetBool(value: false);

	public Bug()
	{
	}

	public Bug(Vector2 position, int facingDirection, string specialType)
		: this(position, 0)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		faceDirection(facingDirection);
		if (specialType.Contains("Assassin"))
		{
			Sprite.LoadTexture("Characters\\Monsters\\Assassin Bug");
			base.DamageToFarmer = 50;
			base.Health = 500;
			base.speed++;
		}
	}

	public Bug(Vector2 position, int areaType)
		: base("Bug", position)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Sprite.SpriteHeight = 16;
		Sprite.UpdateSourceRect();
		onCollision = collide;
		yOffset = -32f;
		base.IsWalkingTowardPlayer = false;
		setMovingInFacingDirection();
		defaultAnimationInterval.Value = 40;
		collidesWithOtherCharacters.Value = false;
		if (areaType == 121)
		{
			isArmoredBug.Value = true;
			Sprite.LoadTexture("Characters\\Monsters\\Armored Bug");
			base.DamageToFarmer *= 2;
			base.Slipperiness = -1;
			base.Health = 150;
		}
		base.HideShadow = true;
	}

	public Bug(Vector2 position, int facingDirection, MineShaft mine)
		: this(position, mine.getMineArea())
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		faceDirection(facingDirection);
		base.HideShadow = true;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(isArmoredBug, "isArmoredBug");
	}

	protected override void updateMonsterSlaveAnimation(GameTime time)
	{
		Sprite.faceDirection(FacingDirection);
		Sprite.animateOnce(time);
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		base.reloadSprite(onlyAppearance);
		Sprite.SpriteHeight = 16;
		Sprite.UpdateSourceRect();
	}

	private void collide(GameLocation location)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		Rectangle val = nextPosition(FacingDirection);
		foreach (Farmer farmer in location.farmers)
		{
			Rectangle boundingBox = farmer.GetBoundingBox();
			if (((Rectangle)(ref boundingBox)).Intersects(val))
			{
				return;
			}
		}
		FacingDirection = (FacingDirection + 2) % 4;
		setMovingInFacingDirection();
	}

	public override void BuffForAdditionalDifficulty(int additional_difficulty)
	{
		FacingDirection = Math.Abs((FacingDirection + Game1.random.Next(-1, 2)) % 4);
		Halt();
		setMovingInFacingDirection();
		base.BuffForAdditionalDifficulty(additional_difficulty);
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		int num = Math.Max(1, damage - resilience.Value);
		if (isArmoredBug.Value && (isBomb || !(who.CurrentTool is MeleeWeapon meleeWeapon) || !meleeWeapon.hasEnchantmentOfType<BugKillerEnchantment>()))
		{
			base.currentLocation.playSound("crafting");
			return 0;
		}
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Health -= num;
			base.currentLocation.playSound("hitEnemy");
			setTrajectory(xTrajectory / 3, yTrajectory / 3);
			if (isHardModeMonster.Value)
			{
				FacingDirection = Math.Abs((FacingDirection + Game1.random.Next(-1, 2)) % 4);
				Halt();
				setMovingInFacingDirection();
			}
			if (base.Health <= 0)
			{
				deathAnimation();
			}
		}
		return num;
	}

	public override List<Item> getExtraDropItems()
	{
		if (isArmoredBug.Value)
		{
			List<Item> list = new List<Item>();
			if (Game1.random.NextDouble() <= 0.1)
			{
				list.Add(ItemRegistry.Create("(O)874"));
			}
			return list;
		}
		return base.getExtraDropItems();
	}

	public override void draw(SpriteBatch b)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		if (!base.IsInvisible && Utility.isOnScreen(base.Position, 128))
		{
			Vector2 val = default(Vector2);
			if (FacingDirection % 2 == 0)
			{
				val.X = (float)(Math.Sin((double)((float)Game1.currentGameTime.TotalGameTime.Milliseconds / 1000f) * (Math.PI * 2.0)) * 10.0);
			}
			else
			{
				val.Y = (float)(Math.Sin((double)((float)Game1.currentGameTime.TotalGameTime.Milliseconds / 1000f) * (Math.PI * 2.0)) * 10.0);
			}
			int y = base.StandingPixel.Y;
			Texture2D shadowTexture = Game1.shadowTexture;
			Vector2 val2 = getLocalPosition(Game1.viewport) + new Vector2((float)(Sprite.SpriteWidth * 4) / 2f + val.X, (float)(GetBoundingBox().Height * 5 / 2 - 48));
			Rectangle? val3 = Game1.shadowTexture.Bounds;
			Color white = Color.White;
			Rectangle bounds = Game1.shadowTexture.Bounds;
			b.Draw(shadowTexture, val2, val3, white, 0f, Utility.PointToVector2(((Rectangle)(ref bounds)).Center), (4f + (float)yJumpOffset / 40f) * scale.Value, (SpriteEffects)0, Math.Max(0f, (float)y / 10000f) - 1E-06f);
			b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)yJumpOffset) + val, (Rectangle?)Sprite.SourceRect, Color.White, rotation, new Vector2(8f, 16f), 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f)));
		}
	}

	protected override void localDeathAnimation()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		base.localDeathAnimation();
		base.currentLocation.localSound("slimedead");
		Utility.makeTemporarySpriteJuicier(new TemporaryAnimatedSprite(44, base.Position + new Vector2(0f, -32f), Color.Violet, 10)
		{
			holdLastFrame = true,
			alphaFade = 0.01f,
			interval = 70f
		}, base.currentLocation);
	}

	public override void shedChunks(int number, float scale)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		Point standingPixel = base.StandingPixel;
		Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(0, Sprite.getHeight() * 4, 16, 16), 8, standingPixel.X, standingPixel.Y, number, base.TilePoint.Y, Color.White, 4f);
	}
}
