using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Enchantments;
using StardewValley.Extensions;
using StardewValley.Objects;
using StardewValley.Tools;
using xTile.Dimensions;

namespace StardewValley.Monsters;

public class Bat : Monster
{
	public const float rotationIncrement = (float)Math.PI / 64f;

	[XmlIgnore]
	public readonly NetInt wasHitCounter = new NetInt(0);

	[XmlIgnore]
	public float targetRotation;

	[XmlIgnore]
	public readonly NetBool turningRight = new NetBool();

	[XmlIgnore]
	public readonly NetBool seenPlayer = new NetBool();

	public readonly NetBool cursedDoll = new NetBool();

	public readonly NetBool hauntedSkull = new NetBool();

	public readonly NetBool magmaSprite = new NetBool();

	public readonly NetBool canLunge = new NetBool();

	private ICue batFlap;

	private float extraVelocity;

	private float maxSpeed = 5f;

	public int lungeFrequency = 3000;

	public int lungeChargeTime = 500;

	public int lungeSpeed = 30;

	public int lungeDecelerationTicks = 60;

	public int nextLunge = -1;

	public int lungeTimer;

	public Vector2 lungeVelocity = Vector2.Zero;

	private List<Vector2> previousPositions = new List<Vector2>();

	public Bat()
	{
	}//IL_0087: Unknown result type (might be due to invalid IL or missing references)
	//IL_008c: Unknown result type (might be due to invalid IL or missing references)


	public Bat(Vector2 position)
		: base("Bat", position)
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		base.Slipperiness = 24 + Game1.random.Next(-10, 11);
		Halt();
		base.IsWalkingTowardPlayer = false;
		base.HideShadow = true;
	}

	public Bat(Vector2 position, int mineLevel)
		: base("Bat", position)
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		base.Slipperiness = 20 + Game1.random.Next(-5, 6);
		switch (mineLevel)
		{
		case 77377:
			parseMonsterInfo("Lava Bat");
			base.Name = "Haunted Skull";
			reloadSprite();
			extraVelocity = 1f;
			extraVelocity = 3f;
			maxSpeed = 8f;
			shakeTimer = 100;
			cursedDoll.Value = true;
			hauntedSkull.Value = true;
			objectsToDrop.Clear();
			break;
		case -555:
			parseMonsterInfo("Magma Sprite");
			base.Name = "Magma Sprite";
			reloadSprite();
			base.Slipperiness *= 2;
			extraVelocity = 2f;
			maxSpeed = Game1.random.Next(6, 9);
			shakeTimer = 100;
			cursedDoll.Value = true;
			magmaSprite.Value = true;
			break;
		case -556:
			parseMonsterInfo("Magma Sparker");
			base.Name = "Magma Sparker";
			reloadSprite();
			extraVelocity = 2f;
			base.Slipperiness += 3;
			maxSpeed = Game1.random.Next(6, 8);
			shakeTimer = 100;
			cursedDoll.Value = true;
			magmaSprite.Value = true;
			canLunge.Value = true;
			break;
		case -789:
			parseMonsterInfo("Iridium Bat");
			reloadSprite();
			extraVelocity = 1f;
			extraVelocity = 3f;
			maxSpeed = 4f;
			base.Health *= 2;
			shakeTimer = 100;
			cursedDoll.Value = true;
			objectsToDrop.Clear();
			base.Age = 789;
			break;
		case -666:
			parseMonsterInfo("Iridium Bat");
			reloadSprite();
			extraVelocity = 1f;
			extraVelocity = 3f;
			maxSpeed = 8f;
			base.Health *= 2;
			shakeTimer = 100;
			cursedDoll.Value = true;
			objectsToDrop.Clear();
			break;
		default:
			if (mineLevel >= 40 && mineLevel < 80)
			{
				base.Name = "Frost Bat";
				parseMonsterInfo("Frost Bat");
				reloadSprite();
			}
			else if (mineLevel >= 80 && mineLevel < 171)
			{
				base.Name = "Lava Bat";
				parseMonsterInfo("Lava Bat");
				reloadSprite();
			}
			else if (mineLevel >= 171)
			{
				base.Name = "Iridium Bat";
				parseMonsterInfo("Iridium Bat");
				reloadSprite();
				extraVelocity = 1f;
			}
			break;
		}
		if (mineLevel > 999)
		{
			extraVelocity = 3f;
			maxSpeed = 8f;
			base.Health *= 2;
			shakeTimer = 999999;
		}
		if (canLunge.Value)
		{
			nextLunge = lungeFrequency;
		}
		Halt();
		base.IsWalkingTowardPlayer = false;
		base.HideShadow = true;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(wasHitCounter, "wasHitCounter").AddField(turningRight, "turningRight").AddField(seenPlayer, "seenPlayer")
			.AddField(cursedDoll, "cursedDoll")
			.AddField(hauntedSkull, "hauntedSkull")
			.AddField(magmaSprite, "magmaSprite")
			.AddField(canLunge, "canLunge");
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		if (Sprite == null)
		{
			Sprite = new AnimatedSprite("Characters\\Monsters\\" + base.Name);
		}
		else
		{
			Sprite.textureName.Value = "Characters\\Monsters\\" + base.Name;
		}
		base.HideShadow = true;
	}

	public override Debris ModifyMonsterLoot(Debris debris)
	{
		if (debris != null && magmaSprite.Value)
		{
			debris.chunksMoveTowardPlayer = true;
		}
		return debris;
	}

	public override List<Item> getExtraDropItems()
	{
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		List<Item> list = new List<Item>();
		if (cursedDoll.Value && Game1.random.NextDouble() < 0.1429 && hauntedSkull.Value)
		{
			switch (Game1.random.Next(11))
			{
			case 0:
				switch (Game1.random.Next(6))
				{
				case 0:
				{
					Clothing clothing = ItemRegistry.Create<Clothing>("(P)10");
					clothing.clothesColor.Value = Color.DimGray;
					list.Add(clothing);
					break;
				}
				case 1:
					list.Add(ItemRegistry.Create<Clothing>("(S)1004"));
					break;
				case 2:
					list.Add(ItemRegistry.Create<Clothing>("(S)1014"));
					break;
				case 3:
					list.Add(ItemRegistry.Create<Clothing>("(S)1263"));
					break;
				case 4:
					list.Add(ItemRegistry.Create<Clothing>("(S)1262"));
					break;
				case 5:
				{
					Clothing clothing = ItemRegistry.Create<Clothing>("(P)12");
					clothing.clothesColor.Value = Color.DimGray;
					list.Add(clothing);
					break;
				}
				}
				break;
			case 1:
			{
				MeleeWeapon meleeWeapon = ItemRegistry.Create<MeleeWeapon>("(W)2");
				meleeWeapon.AddEnchantment(new VampiricEnchantment());
				list.Add(meleeWeapon);
				break;
			}
			case 2:
				list.Add(ItemRegistry.Create("(O)288"));
				break;
			case 3:
				list.Add(new Ring("534"));
				break;
			case 4:
				list.Add(new Ring("531"));
				break;
			case 5:
				do
				{
					list.Add(ItemRegistry.Create("(O)768"));
					list.Add(ItemRegistry.Create("(O)769"));
				}
				while (Game1.random.NextDouble() < 0.33);
				break;
			case 6:
				list.Add(ItemRegistry.Create("(O)581"));
				break;
			case 7:
				list.Add(ItemRegistry.Create("(O)582"));
				break;
			case 8:
				list.Add(ItemRegistry.Create("(O)725"));
				break;
			case 9:
				list.Add(ItemRegistry.Create("(O)86"));
				break;
			case 10:
				if (Utility.doesMasterPlayerHaveMailReceivedButNotMailForTomorrow("ccVault"))
				{
					list.Add(ItemRegistry.Create("(O)275"));
				}
				else
				{
					list.Add(ItemRegistry.Create("(O)749"));
				}
				break;
			}
			return list;
		}
		if (hauntedSkull.Value && Game1.random.NextDouble() < 0.25 && Game1.IsWinter)
		{
			do
			{
				list.Add(ItemRegistry.Create("(O)273"));
			}
			while (Game1.random.NextDouble() < 0.4);
		}
		if (hauntedSkull.Value && Game1.random.NextDouble() < 0.01)
		{
			list.Add(ItemRegistry.Create("(M)CursedMannequin" + ((Game1.random.NextDouble() < 0.5) ? "Male" : "Female")));
		}
		if (hauntedSkull.Value && Game1.random.NextDouble() < 0.001502)
		{
			list.Add(ItemRegistry.Create("(O)279"));
		}
		if (list.Count > 0)
		{
			return list;
		}
		return base.getExtraDropItems();
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0509: Unknown result type (might be due to invalid IL or missing references)
		//IL_050e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_030b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_037d: Unknown result type (might be due to invalid IL or missing references)
		//IL_039e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_040d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0418: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Unknown result type (might be due to invalid IL or missing references)
		//IL_057d: Unknown result type (might be due to invalid IL or missing references)
		//IL_058d: Unknown result type (might be due to invalid IL or missing references)
		//IL_059a: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d3: Unknown result type (might be due to invalid IL or missing references)
		if (base.Age == 789)
		{
			return -1;
		}
		lungeVelocity = Vector2.Zero;
		if (lungeTimer > 0)
		{
			nextLunge = lungeFrequency;
			lungeTimer = 0;
		}
		else if (nextLunge < 1000)
		{
			nextLunge = 1000;
		}
		int num = Math.Max(1, damage - resilience.Value);
		seenPlayer.Value = true;
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Health -= num;
			setTrajectory(xTrajectory / 3, yTrajectory / 3);
			wasHitCounter.Value = 500;
			if (magmaSprite.Value)
			{
				base.currentLocation.playSound("magma_sprite_hit");
			}
			else
			{
				base.currentLocation.playSound("hitEnemy");
			}
			if (base.Health <= 0)
			{
				deathAnimation();
				if (!magmaSprite.Value)
				{
					Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite(44, base.Position, Color.DarkMagenta, 10));
				}
				if (cursedDoll.Value)
				{
					Vector2 val = base.Position;
					if (magmaSprite.Value)
					{
						base.currentLocation.playSound("magma_sprite_die");
						for (int i = 0; i < 20; i++)
						{
							base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite("Characters\\Monsters\\Magma Sprite", new Rectangle(0, 64, 8, 8), val + new Vector2((float)Game1.random.Next(64), (float)Game1.random.Next(64)), flipped: false, 0f, Color.White)
							{
								scale = 4f,
								scaleChange = 0f,
								motion = new Vector2((float)Game1.random.Next(-30, 31) / 10f, -6f),
								acceleration = new Vector2(0f, 0.25f),
								layerDepth = 0.9f,
								animationLength = 6,
								totalNumberOfLoops = 2,
								interval = 60f,
								delayBeforeAnimationStart = i * 10
							});
						}
						Utility.addSmokePuff(base.currentLocation, val, 0, 4f, 0.01f, 1f, 0.01f);
						Utility.addSmokePuff(base.currentLocation, val + new Vector2(32f, 16f), 400, 4f, 0.01f, 1f, 0.02f);
						Utility.addSmokePuff(base.currentLocation, val + new Vector2(-32f, -16f), 200, 4f, 0.01f, 1f, 0.02f);
						Utility.addSmokePuff(base.currentLocation, val + new Vector2(0f, 32f), 200, 4f, 0.01f, 1f, 0.01f);
						Utility.addSmokePuff(base.currentLocation, val, 0, 3f, 0.01f, 1f, 0.02f);
						Utility.addSmokePuff(base.currentLocation, val + new Vector2(21f, 16f), 500, 3f, 0.01f, 1f, 0.01f);
						Utility.addSmokePuff(base.currentLocation, val + new Vector2(-32f, -21f), 100, 3f, 0.01f, 1f, 0.02f);
						Utility.addSmokePuff(base.currentLocation, val + new Vector2(0f, 32f), 250, 3f, 0.01f, 1f, 0.01f);
					}
					else
					{
						base.currentLocation.playSound("rockGolemHit");
					}
					if (hauntedSkull.Value)
					{
						Game1.multiplayer.broadcastSprites(who.currentLocation, new TemporaryAnimatedSprite(Sprite.textureName.Value, new Rectangle(0, 32, 16, 16), 2000f, 1, 9999, val, flicker: false, flipped: false, 1f, 0.02f, Color.White, 4f, 0f, 0f, 0f)
						{
							motion = new Vector2((float)xTrajectory / 4f, (float)Game1.random.Next(-12, -7)),
							acceleration = new Vector2(0f, 0.4f),
							rotationChange = (float)Game1.random.Next(-200, 200) / 1000f
						});
					}
					else if (who != null && !magmaSprite.Value)
					{
						Game1.multiplayer.broadcastSprites(who.currentLocation, new TemporaryAnimatedSprite("LooseSprites\\Cursors", new Rectangle(388, 1894, 24, 22), 40f, 6, 9999, val, flicker: false, flipped: true, 1f, 0f, Color.Black * 0.67f, 4f, 0f, 0f, 0f)
						{
							motion = new Vector2(8f, -4f)
						});
					}
				}
				else
				{
					base.currentLocation.playSound("batScreech");
				}
			}
		}
		addedSpeed = Game1.random.Next(-1, 1);
		return num;
	}

	public override void shedChunks(int number, float scale)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		Point standingPixel = base.StandingPixel;
		if (cursedDoll.Value && hauntedSkull.Value)
		{
			Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(0, 64, 16, 16), 8, standingPixel.X, standingPixel.Y, number, base.TilePoint.Y, Color.White, 4f);
		}
		else
		{
			Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(0, 384, 64, 64), 32, standingPixel.X, standingPixel.Y, number, base.TilePoint.Y, Color.White, scale);
		}
	}

	public override void onDealContactDamage(Farmer who)
	{
		base.onDealContactDamage(who);
		if (magmaSprite.Value && Game1.random.NextDouble() < 0.5 && name.Equals("Magma Sparker") && Game1.random.Next(11) >= who.Immunity && !who.hasBuff("28") && !who.hasTrinketWithID("BasiliskPaw"))
		{
			who.applyBuff("12");
		}
	}

	public override void drawAboveAllLayers(SpriteBatch b)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e0e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e27: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e3b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e40: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e4b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e79: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b40: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b45: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b63: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b85: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b95: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b9a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b9e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bb3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c04: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c09: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c1b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c25: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c43: Unknown result type (might be due to invalid IL or missing references)
		//IL_0614: Unknown result type (might be due to invalid IL or missing references)
		//IL_0620: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0608: Unknown result type (might be due to invalid IL or missing references)
		//IL_060d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0612: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eb6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ebb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ecf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ed9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ee3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ef2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ef7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0efb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f10: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f14: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f1f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0642: Unknown result type (might be due to invalid IL or missing references)
		//IL_062e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c98: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c9d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cd0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d08: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f66: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f75: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f85: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f90: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0faf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d57: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d5c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d6b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d70: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d75: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0699: Unknown result type (might be due to invalid IL or missing references)
		//IL_069e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06da: Unknown result type (might be due to invalid IL or missing references)
		//IL_06de: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0702: Unknown result type (might be due to invalid IL or missing references)
		//IL_070c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0732: Unknown result type (might be due to invalid IL or missing references)
		//IL_0737: Unknown result type (might be due to invalid IL or missing references)
		//IL_075e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0763: Unknown result type (might be due to invalid IL or missing references)
		//IL_0768: Unknown result type (might be due to invalid IL or missing references)
		//IL_076a: Unknown result type (might be due to invalid IL or missing references)
		//IL_07aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07be: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0daa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dbe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0815: Unknown result type (might be due to invalid IL or missing references)
		//IL_081a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0841: Unknown result type (might be due to invalid IL or missing references)
		//IL_0846: Unknown result type (might be due to invalid IL or missing references)
		//IL_084b: Unknown result type (might be due to invalid IL or missing references)
		//IL_084d: Unknown result type (might be due to invalid IL or missing references)
		//IL_088d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0897: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_0312: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_0913: Unknown result type (might be due to invalid IL or missing references)
		//IL_0931: Unknown result type (might be due to invalid IL or missing references)
		//IL_094f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0955: Unknown result type (might be due to invalid IL or missing references)
		//IL_095a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0969: Unknown result type (might be due to invalid IL or missing references)
		//IL_096e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0973: Unknown result type (might be due to invalid IL or missing references)
		//IL_0975: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a38: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a4c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a51: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a56: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a58: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a98: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_050e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0513: Unknown result type (might be due to invalid IL or missing references)
		//IL_0518: Unknown result type (might be due to invalid IL or missing references)
		//IL_0519: Unknown result type (might be due to invalid IL or missing references)
		//IL_0569: Unknown result type (might be due to invalid IL or missing references)
		//IL_0573: Unknown result type (might be due to invalid IL or missing references)
		//IL_0587: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0410: Unknown result type (might be due to invalid IL or missing references)
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		//IL_0461: Unknown result type (might be due to invalid IL or missing references)
		//IL_046b: Unknown result type (might be due to invalid IL or missing references)
		//IL_047f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0493: Unknown result type (might be due to invalid IL or missing references)
		if (!Utility.isOnScreen(base.Position, 128))
		{
			return;
		}
		Rectangle bounds;
		if (cursedDoll.Value)
		{
			if (hauntedSkull.Value)
			{
				Vector2 val = Vector2.Zero;
				if (previousPositions.Count > 2)
				{
					val = base.Position - previousPositions[1];
				}
				int num = ((!(Math.Abs(val.X) > Math.Abs(val.Y))) ? ((!(val.Y < 0f)) ? 2 : 0) : ((val.X > 0f) ? 1 : 3));
				if (num == -1)
				{
					num = 2;
				}
				Vector2 val2 = default(Vector2);
				((Vector2)(ref val2))._002Ector(0f, 8f * (float)Math.Sin(Game1.currentGameTime.TotalGameTime.TotalMilliseconds / (Math.PI * 60.0)));
				Texture2D shadowTexture = Game1.shadowTexture;
				Vector2 val3 = getLocalPosition(Game1.viewport) + new Vector2(32f, 64f);
				Rectangle? val4 = Game1.shadowTexture.Bounds;
				Color white = Color.White;
				bounds = Game1.shadowTexture.Bounds;
				float num2 = ((Rectangle)(ref bounds)).Center.X;
				bounds = Game1.shadowTexture.Bounds;
				b.Draw(shadowTexture, val3, val4, white, 0f, new Vector2(num2, (float)((Rectangle)(ref bounds)).Center.Y), 3f + val2.Y / 20f, (SpriteEffects)0, 0.0001f);
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2((float)(32 + Game1.random.Next(-6, 7)), (float)(32 + Game1.random.Next(-6, 7))) + val2, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Sprite.Texture, num * 2 + ((seenPlayer.Value && Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 500.0 < 250.0) ? 1 : 0), 16, 16), Color.Red * 0.44f, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), (position.Y + 128f - 1f) / 10000f);
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2((float)(32 + Game1.random.Next(-6, 7)), (float)(32 + Game1.random.Next(-6, 7))) + val2, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Sprite.Texture, num * 2 + ((seenPlayer.Value && Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 500.0 < 250.0) ? 1 : 0), 16, 16), Color.Yellow * 0.44f, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), (position.Y + 128f) / 10000f);
				if (seenPlayer.Value)
				{
					for (int num3 = previousPositions.Count - 1; num3 >= 0; num3 -= 2)
					{
						b.Draw(Sprite.Texture, new Vector2(previousPositions[num3].X - (float)((Rectangle)(ref Game1.viewport)).X, previousPositions[num3].Y - (float)((Rectangle)(ref Game1.viewport)).Y + (float)yJumpOffset) + drawOffset + new Vector2(32f, 32f) + val2, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Sprite.Texture, num * 2 + ((seenPlayer.Value && Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 500.0 < 250.0) ? 1 : 0), 16, 16), Color.White * (0f + 0.125f * (float)num3), 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), (position.Y + 128f - (float)num3) / 10000f);
					}
				}
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, 32f) + val2, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Sprite.Texture, num * 2 + ((seenPlayer.Value && Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 500.0 < 250.0) ? 1 : 0), 16, 16), Color.White, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), (position.Y + 128f + 1f) / 10000f);
			}
			else if (magmaSprite.Value)
			{
				Vector2 val5 = Vector2.Zero;
				if (previousPositions.Count > 2)
				{
					val5 = base.Position - previousPositions[1];
				}
				int num4 = ((!(Math.Abs(val5.X) > Math.Abs(val5.Y))) ? ((!(val5.Y < 0f)) ? 2 : 0) : ((val5.X > 0f) ? 1 : 3));
				if (num4 == -1)
				{
					num4 = 2;
				}
				Vector2 val6 = default(Vector2);
				((Vector2)(ref val6))._002Ector(0f, 8f * (float)Math.Sin(Game1.currentGameTime.TotalGameTime.TotalMilliseconds / (Math.PI * 60.0)));
				Texture2D shadowTexture2 = Game1.shadowTexture;
				Vector2 val7 = getLocalPosition(Game1.viewport) + new Vector2(32f, 64f);
				Rectangle? val8 = Game1.shadowTexture.Bounds;
				Color white2 = Color.White;
				bounds = Game1.shadowTexture.Bounds;
				float num5 = ((Rectangle)(ref bounds)).Center.X;
				bounds = Game1.shadowTexture.Bounds;
				b.Draw(shadowTexture2, val7, val8, white2, 0f, new Vector2(num5, (float)((Rectangle)(ref bounds)).Center.Y), 3f + val6.Y / 20f, (SpriteEffects)0, 0.0001f);
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2((float)(32 + Game1.random.Next(-6, 7)), (float)(32 + Game1.random.Next(-6, 7))) + val6, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Sprite.Texture, num4 * 7 + (int)(Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 490.0 / 70.0), 16, 16), Color.Red * 0.44f, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), 0.9955f);
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2((float)(32 + Game1.random.Next(-6, 7)), (float)(32 + Game1.random.Next(-6, 7))) + val6, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Sprite.Texture, num4 * 7 + (int)(Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 490.0 / 70.0), 16, 16), Color.Yellow * 0.44f, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), 0.9975f);
				for (int num6 = previousPositions.Count - 1; num6 >= 0; num6 -= 2)
				{
					b.Draw(Sprite.Texture, new Vector2(previousPositions[num6].X - (float)((Rectangle)(ref Game1.viewport)).X, previousPositions[num6].Y - (float)((Rectangle)(ref Game1.viewport)).Y + (float)yJumpOffset) + drawOffset + new Vector2(32f, 32f) + val6, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Sprite.Texture, num4 * 7 + (int)(Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 490.0 / 70.0), 16, 16), Color.White * (0f + 0.125f * (float)num6), 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), 0.9985f);
				}
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, 32f) + val6, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Sprite.Texture, num4 * 7 + (int)(Game1.currentGameTime.TotalGameTime.TotalMilliseconds % 490.0 / 70.0), 16, 16), Color.White, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), 1f);
			}
			else
			{
				int num7 = 103;
				if (base.Age == 789)
				{
					num7 = 789;
				}
				Vector2 val9 = default(Vector2);
				((Vector2)(ref val9))._002Ector(0f, 8f * (float)Math.Sin(Game1.currentGameTime.TotalGameTime.TotalMilliseconds / (Math.PI * 60.0)));
				Texture2D shadowTexture3 = Game1.shadowTexture;
				Vector2 val10 = getLocalPosition(Game1.viewport) + new Vector2(32f, 64f);
				Rectangle? val11 = Game1.shadowTexture.Bounds;
				Color white3 = Color.White;
				bounds = Game1.shadowTexture.Bounds;
				float num8 = ((Rectangle)(ref bounds)).Center.X;
				bounds = Game1.shadowTexture.Bounds;
				b.Draw(shadowTexture3, val10, val11, white3, 0f, new Vector2(num8, (float)((Rectangle)(ref bounds)).Center.Y), 3f + val9.Y / 20f, (SpriteEffects)0, 0.0001f);
				b.Draw(Game1.objectSpriteSheet, getLocalPosition(Game1.viewport) + new Vector2((float)(32 + Game1.random.Next(-6, 7)), (float)(32 + Game1.random.Next(-6, 7))) + val9, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Game1.objectSpriteSheet, num7, 16, 16), Color.Violet * 0.44f, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), (position.Y + 128f - 1f) / 10000f);
				b.Draw(Game1.objectSpriteSheet, getLocalPosition(Game1.viewport) + new Vector2((float)(32 + Game1.random.Next(-6, 7)), (float)(32 + Game1.random.Next(-6, 7))) + val9, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Game1.objectSpriteSheet, num7, 16, 16), Color.Lime * 0.44f, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), (position.Y + 128f) / 10000f);
				b.Draw(Game1.objectSpriteSheet, getLocalPosition(Game1.viewport) + new Vector2(32f, 32f) + val9, (Rectangle?)Game1.getSourceRectForStandardTileSheet(Game1.objectSpriteSheet, num7, 16, 16), (Color)((num7 == 789) ? Color.White : new Color(255, 50, 50)), 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), (position.Y + 128f + 1f) / 10000f);
			}
		}
		else
		{
			int y = base.StandingPixel.Y;
			b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, 32f), (Rectangle?)Sprite.SourceRect, (shakeTimer > 0) ? Color.Red : Color.White, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), 0.92f);
			Texture2D shadowTexture4 = Game1.shadowTexture;
			Vector2 val12 = getLocalPosition(Game1.viewport) + new Vector2(32f, 64f);
			Rectangle? val13 = Game1.shadowTexture.Bounds;
			Color white4 = Color.White;
			bounds = Game1.shadowTexture.Bounds;
			float num9 = ((Rectangle)(ref bounds)).Center.X;
			bounds = Game1.shadowTexture.Bounds;
			b.Draw(shadowTexture4, val12, val13, white4, 0f, new Vector2(num9, (float)((Rectangle)(ref bounds)).Center.Y), 4f, (SpriteEffects)0, base.wildernessFarmMonster ? 0.0001f : ((float)(y - 1) / 10000f));
			if (isGlowing)
			{
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, 32f), (Rectangle?)Sprite.SourceRect, glowingColor * glowingTransparency, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.99f : ((float)y / 10000f + 0.001f)));
			}
		}
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0399: Unknown result type (might be due to invalid IL or missing references)
		//IL_039e: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		if (wasHitCounter.Value >= 0)
		{
			wasHitCounter.Value -= time.ElapsedGameTime.Milliseconds;
		}
		if (double.IsNaN(xVelocity) || double.IsNaN(yVelocity) || base.Position.X < -2000f || base.Position.Y < -2000f)
		{
			base.Health = -500;
		}
		if (base.Position.X <= -640f || base.Position.Y <= -640f || base.Position.X >= (float)(base.currentLocation.Map.Layers[0].LayerWidth * 64 + 640) || base.Position.Y >= (float)(base.currentLocation.Map.Layers[0].LayerHeight * 64 + 640))
		{
			base.Health = -500;
		}
		if (canLunge.Value)
		{
			if (nextLunge == -1)
			{
				nextLunge = lungeFrequency;
			}
			if (((Vector2)(ref lungeVelocity)).LengthSquared() > 0f)
			{
				float delta = (float)lungeSpeed / (float)lungeDecelerationTicks;
				lungeVelocity = new Vector2(Utility.MoveTowards(lungeVelocity.X, 0f, delta), Utility.MoveTowards(lungeVelocity.Y, 0f, delta));
				xVelocity = lungeVelocity.X;
				yVelocity = 0f - lungeVelocity.Y;
				if (((Vector2)(ref lungeVelocity)).LengthSquared() == 0f)
				{
					xVelocity = 0f;
					yVelocity = 0f;
				}
				return;
			}
			if (lungeTimer > 0)
			{
				lungeTimer -= (int)time.ElapsedGameTime.TotalMilliseconds;
				Vector2 val = Utility.PointToVector2(base.Player.StandingPixel) - Utility.PointToVector2(base.StandingPixel);
				if (((Vector2)(ref val)).LengthSquared() == 0f)
				{
					((Vector2)(ref val))._002Ector(1f, 0f);
				}
				((Vector2)(ref val)).Normalize();
				if (lungeTimer < 0)
				{
					lungeVelocity = val * 25f;
					lungeTimer = 0;
					nextLunge = lungeFrequency;
				}
				xVelocity = val.X * 0.5f;
				yVelocity = (0f - val.Y) * 0.5f;
			}
			else if (nextLunge > 0 && withinPlayerThreshold(6))
			{
				nextLunge -= (int)time.ElapsedGameTime.TotalMilliseconds;
				if (nextLunge < 0)
				{
					base.currentLocation.playSound("magma_sprite_spot");
					nextLunge = 0;
					lungeTimer = lungeChargeTime;
					return;
				}
			}
		}
		if (!base.focusedOnFarmers && !withinPlayerThreshold(6) && !seenPlayer.Value)
		{
			return;
		}
		if (magmaSprite.Value && !seenPlayer.Value)
		{
			base.currentLocation.playSound("magma_sprite_spot");
		}
		seenPlayer.Value = true;
		if (invincibleCountdown > 0)
		{
			if (base.Name.Equals("Lava Bat"))
			{
				glowingColor = Color.Cyan;
			}
			return;
		}
		Point standingPixel = base.StandingPixel;
		Point standingPixel2 = base.Player.StandingPixel;
		float num = -(standingPixel2.X - standingPixel.X);
		float num2 = standingPixel2.Y - standingPixel.Y;
		float num3 = Math.Max(1f, Math.Abs(num) + Math.Abs(num2));
		if (num3 < (float)((extraVelocity > 0f) ? 192 : 64))
		{
			xVelocity = Math.Max(0f - maxSpeed, Math.Min(maxSpeed, xVelocity * 1.05f));
			yVelocity = Math.Max(0f - maxSpeed, Math.Min(maxSpeed, yVelocity * 1.05f));
		}
		num /= num3;
		num2 /= num3;
		if (wasHitCounter.Value <= 0)
		{
			targetRotation = (float)Math.Atan2(0f - num2, num) - (float)Math.PI / 2f;
			if ((double)(Math.Abs(targetRotation) - Math.Abs(rotation)) > Math.PI * 7.0 / 8.0 && Game1.random.NextBool())
			{
				turningRight.Value = true;
			}
			else if ((double)(Math.Abs(targetRotation) - Math.Abs(rotation)) < Math.PI / 8.0)
			{
				turningRight.Value = false;
			}
			if (turningRight.Value)
			{
				rotation -= (float)Math.Sign(targetRotation - rotation) * ((float)Math.PI / 64f);
			}
			else
			{
				rotation += (float)Math.Sign(targetRotation - rotation) * ((float)Math.PI / 64f);
			}
			rotation %= (float)Math.PI * 2f;
			wasHitCounter.Value = 0;
		}
		float num4 = Math.Min(5f, Math.Max(1f, 5f - num3 / 64f / 2f)) + extraVelocity;
		num = (float)Math.Cos((double)rotation + Math.PI / 2.0);
		num2 = 0f - (float)Math.Sin((double)rotation + Math.PI / 2.0);
		xVelocity += (0f - num) * num4 / 6f + (float)Game1.random.Next(-10, 10) / 100f;
		yVelocity += (0f - num2) * num4 / 6f + (float)Game1.random.Next(-10, 10) / 100f;
		if (Math.Abs(xVelocity) > Math.Abs((0f - num) * maxSpeed))
		{
			xVelocity -= (0f - num) * num4 / 6f;
		}
		if (Math.Abs(yVelocity) > Math.Abs((0f - num2) * maxSpeed))
		{
			yVelocity -= (0f - num2) * num4 / 6f;
		}
	}

	protected override void updateAnimation(GameTime time)
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		if (base.focusedOnFarmers || withinPlayerThreshold(6) || seenPlayer.Value || magmaSprite.Value)
		{
			Sprite.Animate(time, 0, 4, 80f);
			if (Sprite.currentFrame % 3 == 0 && Utility.isOnScreen(base.Position, 512) && (batFlap == null || !batFlap.IsPlaying) && base.currentLocation == Game1.currentLocation && !cursedDoll.Value)
			{
				Game1.playSound("batFlap", out batFlap);
			}
			if (cursedDoll.Value)
			{
				shakeTimer -= time.ElapsedGameTime.Milliseconds;
				if (shakeTimer < 0)
				{
					shakeTimer = 50;
					if (magmaSprite.Value)
					{
						shakeTimer = ((lungeTimer > 0) ? 50 : 100);
						base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite("Characters\\Monsters\\Magma Sprite", new Rectangle(0, 64, 8, 8), base.Position + new Vector2((float)Game1.random.Next(32), (float)(-16 - Game1.random.Next(32))), flipped: false, 0f, Color.White)
						{
							scale = 4f,
							scaleChange = -0.05f,
							motion = new Vector2((lungeTimer > 0) ? ((float)Game1.random.Next(-30, 31) / 10f) : 0f, (0f - maxSpeed) / ((lungeTimer > 0) ? 2f : 8f)),
							layerDepth = 0.9f,
							animationLength = 6,
							totalNumberOfLoops = 1,
							interval = 50f,
							xPeriodic = (lungeTimer <= 0),
							xPeriodicLoopTime = Game1.random.Next(500, 800),
							xPeriodicRange = 4 * ((lungeTimer <= 0) ? 1 : 2)
						});
					}
					else if (!hauntedSkull.Value)
					{
						base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite("Maps\\springobjects", Game1.getSourceRectForStandardTileSheet(Game1.objectSpriteSheet, (base.Age == 789) ? 789 : 103, 16, 16), base.Position + new Vector2(0f, -32f), flipped: false, 0.1f, new Color(255, 50, 255) * 0.8f)
						{
							scale = 4f
						});
					}
				}
				previousPositions.Add(base.Position);
				if (previousPositions.Count > 8)
				{
					previousPositions.RemoveAt(0);
				}
			}
		}
		else
		{
			Sprite.currentFrame = 4;
			Halt();
		}
		resetAnimationSpeed();
	}
}
