using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Netcode;
using StardewValley.Enchantments;
using StardewValley.Tools;

namespace StardewValley.Monsters;

public class Mummy : Monster
{
	public NetInt reviveTimer = new NetInt(0);

	public const int revivalTime = 10000;

	protected int _damageToFarmer;

	private readonly NetEvent1Field<bool, NetBool> crumbleEvent = new NetEvent1Field<bool, NetBool>();

	public Mummy()
	{
	}

	public Mummy(Vector2 position)
		: base("Mummy", position)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		Sprite.SpriteHeight = 32;
		Sprite.ignoreStopAnimation = true;
		Sprite.UpdateSourceRect();
		_damageToFarmer = damageToFarmer.Value;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(crumbleEvent, "crumbleEvent").AddField(reviveTimer, "reviveTimer");
		crumbleEvent.onEvent += performCrumble;
		position.Field.AxisAlignedMovement = true;
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		Sprite = new AnimatedSprite("Characters\\Monsters\\Mummy");
		Sprite.SpriteHeight = 32;
		Sprite.UpdateSourceRect();
		Sprite.ignoreStopAnimation = true;
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		int num = Math.Max(1, damage - resilience.Value);
		if (reviveTimer.Value > 0)
		{
			if (isBomb)
			{
				base.Health = 0;
				Utility.makeTemporarySpriteJuicier(new TemporaryAnimatedSprite(44, base.Position, Color.BlueViolet, 10)
				{
					holdLastFrame = true,
					alphaFade = 0.01f,
					interval = 70f
				}, base.currentLocation);
				base.currentLocation.playSound("ghost");
				return 999;
			}
			return -1;
		}
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Slipperiness = 2;
			base.Health -= num;
			setTrajectory(xTrajectory, yTrajectory);
			base.currentLocation.playSound("shadowHit");
			base.currentLocation.playSound("skeletonStep");
			base.IsWalkingTowardPlayer = true;
			if (base.Health <= 0)
			{
				if (!isBomb && who.CurrentTool is MeleeWeapon meleeWeapon && meleeWeapon.hasEnchantmentOfType<CrusaderEnchantment>())
				{
					Utility.makeTemporarySpriteJuicier(new TemporaryAnimatedSprite(44, base.Position, Color.BlueViolet, 10)
					{
						holdLastFrame = true,
						alphaFade = 0.01f,
						interval = 70f
					}, base.currentLocation);
					base.currentLocation.playSound("ghost");
				}
				else
				{
					reviveTimer.Value = 10000;
					base.Health = base.MaxHealth;
					deathAnimation();
				}
			}
		}
		return num;
	}

	public override void defaultMovementBehavior(GameTime time)
	{
		if (reviveTimer.Value <= 0)
		{
			base.defaultMovementBehavior(time);
		}
	}

	public override List<Item> getExtraDropItems()
	{
		List<Item> list = new List<Item>();
		if (Game1.random.NextDouble() < 0.002)
		{
			list.Add(ItemRegistry.Create("(O)485"));
		}
		return list;
	}

	protected override void sharedDeathAnimation()
	{
		Halt();
		crumble();
		collidesWithOtherCharacters.Value = false;
		base.IsWalkingTowardPlayer = false;
		moveTowardPlayerThreshold.Value = -1;
	}

	protected override void localDeathAnimation()
	{
	}

	public override void update(GameTime time, GameLocation location)
	{
		crumbleEvent.Poll();
		if (reviveTimer.Value > 0 && Sprite.CurrentAnimation == null && Sprite.currentFrame != 19)
		{
			Sprite.currentFrame = 19;
		}
		base.update(time, location);
	}

	private void crumble(bool reverse = false)
	{
		crumbleEvent.Fire(reverse);
	}

	private void performCrumble(bool reverse)
	{
		Sprite.setCurrentAnimation(getCrumbleAnimation(reverse));
		if (!reverse)
		{
			if (Game1.IsMasterGame)
			{
				damageToFarmer.Value = 0;
			}
			reviveTimer.Value = 10000;
			base.currentLocation.localSound("monsterdead");
		}
		else
		{
			if (Game1.IsMasterGame)
			{
				damageToFarmer.Value = _damageToFarmer;
			}
			reviveTimer.Value = 0;
			base.currentLocation.localSound("skeletonDie");
		}
	}

	private List<FarmerSprite.AnimationFrame> getCrumbleAnimation(bool reverse = false)
	{
		List<FarmerSprite.AnimationFrame> list = new List<FarmerSprite.AnimationFrame>();
		if (!reverse)
		{
			list.Add(new FarmerSprite.AnimationFrame(16, 100, 0, secondaryArm: false, flip: false));
		}
		else
		{
			list.Add(new FarmerSprite.AnimationFrame(16, 100, 0, secondaryArm: false, flip: false, behaviorAfterRevival, behaviorAtEndOfFrame: true));
		}
		list.Add(new FarmerSprite.AnimationFrame(17, 100, 0, secondaryArm: false, flip: false));
		list.Add(new FarmerSprite.AnimationFrame(18, 100, 0, secondaryArm: false, flip: false));
		if (!reverse)
		{
			list.Add(new FarmerSprite.AnimationFrame(19, 100, 0, secondaryArm: false, flip: false, behaviorAfterCrumble));
		}
		else
		{
			list.Add(new FarmerSprite.AnimationFrame(19, 100, 0, secondaryArm: false, flip: false));
		}
		if (reverse)
		{
			list.Reverse();
		}
		return list;
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		if (reviveTimer.Value <= 0 && withinPlayerThreshold())
		{
			base.IsWalkingTowardPlayer = true;
		}
		base.behaviorAtGameTick(time);
	}

	protected override void updateAnimation(GameTime time)
	{
		if (Sprite.CurrentAnimation != null)
		{
			if (Sprite.animateOnce(time))
			{
				Sprite.CurrentAnimation = null;
			}
		}
		else if (reviveTimer.Value > 0)
		{
			reviveTimer.Value -= time.ElapsedGameTime.Milliseconds;
			if (reviveTimer.Value < 2000)
			{
				shake(reviveTimer.Value);
			}
			if (reviveTimer.Value <= 0)
			{
				if (Game1.IsMasterGame)
				{
					crumble(reverse: true);
					base.IsWalkingTowardPlayer = true;
				}
				else
				{
					reviveTimer.Value = 1;
				}
			}
		}
		else if (!Game1.IsMasterGame)
		{
			if (isMoving())
			{
				switch (FacingDirection)
				{
				case 0:
					Sprite.AnimateUp(time);
					break;
				case 3:
					Sprite.AnimateLeft(time);
					break;
				case 1:
					Sprite.AnimateRight(time);
					break;
				case 2:
					Sprite.AnimateDown(time);
					break;
				}
			}
			else
			{
				Sprite.StopAnimation();
			}
		}
		resetAnimationSpeed();
	}

	private void behaviorAfterCrumble(Farmer who)
	{
		Halt();
		Sprite.currentFrame = 19;
		Sprite.CurrentAnimation = null;
	}

	private void behaviorAfterRevival(Farmer who)
	{
		base.IsWalkingTowardPlayer = true;
		collidesWithOtherCharacters.Value = true;
		Sprite.currentFrame = 0;
		Sprite.oldFrame = 0;
		moveTowardPlayerThreshold.Value = 8;
		Sprite.CurrentAnimation = null;
	}
}
