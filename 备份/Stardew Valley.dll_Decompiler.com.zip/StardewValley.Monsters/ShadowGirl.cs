using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using StardewValley.Extensions;
using StardewValley.Pathfinding;
using xTile.Layers;

namespace StardewValley.Monsters;

public class ShadowGirl : Monster
{
	public const int blockTimeBeforePathfinding = 500;

	[XmlIgnore]
	public new Vector2 lastPosition = Vector2.Zero;

	[XmlIgnore]
	public int howLongOnThisPosition;

	public ShadowGirl()
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)
	//IL_0006: Unknown result type (might be due to invalid IL or missing references)


	public ShadowGirl(Vector2 position)
		: base("Shadow Girl", position)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		base.IsWalkingTowardPlayer = false;
		moveTowardPlayerThreshold.Value = 8;
		if (Game1.MasterPlayer.friendshipData.TryGetValue("???", out var value) && value.Points >= 1250)
		{
			base.DamageToFarmer = 0;
		}
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		Sprite = new AnimatedSprite("Characters\\Monsters\\Shadow Girl");
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		int num = Math.Max(1, damage - resilience.Value);
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Health -= num;
			setTrajectory(xTrajectory, yTrajectory);
			if (base.Health <= 0)
			{
				deathAnimation();
			}
		}
		return num;
	}

	protected override void localDeathAnimation()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(45, base.Position, Color.White, 10));
	}

	protected override void sharedDeathAnimation()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		Point standingPixel = base.StandingPixel;
		Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(Sprite.SourceRect.X, Sprite.SourceRect.Y, 64, 21), 64, standingPixel.X, standingPixel.Y - 32, 1, standingPixel.Y / 64, Color.White);
		Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(Sprite.SourceRect.X + 10, Sprite.SourceRect.Y + 21, 64, 21), 42, standingPixel.X, standingPixel.Y - 32, 1, standingPixel.Y / 64, Color.White);
	}

	public override void update(GameTime time, GameLocation location)
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		if (!location.farmers.Any())
		{
			return;
		}
		if (!base.Player.isRafting || !withinPlayerThreshold(4))
		{
			updateGlow();
			updateEmote(time);
			if (controller == null)
			{
				updateMovement(location, time);
			}
			if (controller != null && controller.update(time))
			{
				controller = null;
			}
		}
		behaviorAtGameTick(time);
		Layer val = location.map.RequireLayer("Back");
		if (base.Position.X < 0f || base.Position.X > (float)(val.LayerWidth * 64) || base.Position.Y < 0f || base.Position.Y > (float)(val.LayerHeight * 64))
		{
			location.characters.Remove(this);
		}
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		addedSpeed = 0f;
		base.speed = 3;
		if (howLongOnThisPosition > 500 && controller == null)
		{
			base.IsWalkingTowardPlayer = false;
			controller = new PathFindController(this, base.currentLocation, new Point(base.Player.TilePoint.X, base.Player.TilePoint.Y), Game1.random.Next(4), null, 300);
			timeBeforeAIMovementAgain = 2000f;
			howLongOnThisPosition = 0;
		}
		else if (controller == null)
		{
			base.IsWalkingTowardPlayer = true;
		}
		Vector2 val = base.Position;
		if (((Vector2)(ref val)).Equals(lastPosition))
		{
			howLongOnThisPosition += time.ElapsedGameTime.Milliseconds;
		}
		else
		{
			howLongOnThisPosition = 0;
		}
		lastPosition = base.Position;
	}
}
