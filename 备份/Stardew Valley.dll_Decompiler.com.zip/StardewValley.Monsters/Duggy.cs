using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Extensions;
using xTile.Layers;
using xTile.ObjectModel;
using xTile.Tiles;

namespace StardewValley.Monsters;

public class Duggy : Monster
{
	public Duggy()
	{
		base.HideShadow = true;
	}

	public Duggy(Vector2 position)
		: base("Duggy", position)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		base.IsWalkingTowardPlayer = false;
		base.IsInvisible = true;
		base.DamageToFarmer = 0;
		Sprite.currentFrame = 0;
		base.HideShadow = true;
	}

	public Duggy(Vector2 position, bool magmaDuggy)
		: base("Magma Duggy", position)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		base.IsWalkingTowardPlayer = false;
		base.IsInvisible = true;
		base.DamageToFarmer = 0;
		Sprite.currentFrame = 0;
		base.HideShadow = true;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		position.Field.Interpolated(interpolate: false, wait: true);
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		int num = Math.Max(1, damage - resilience.Value);
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Health -= num;
			base.currentLocation.playSound("hitEnemy");
			if (base.Health <= 0)
			{
				deathAnimation();
			}
		}
		return num;
	}

	protected override void localDeathAnimation()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.localSound("monsterdead");
		Utility.makeTemporarySpriteJuicier(new TemporaryAnimatedSprite(44, base.Position, Color.DarkRed, 10)
		{
			holdLastFrame = true,
			alphaFade = 0.01f,
			interval = 70f
		}, base.currentLocation);
	}

	protected override void sharedDeathAnimation()
	{
	}

	public override void update(GameTime time, GameLocation location)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		if (invincibleCountdown > 0)
		{
			glowingColor = Color.Cyan;
			invincibleCountdown -= time.ElapsedGameTime.Milliseconds;
			if (invincibleCountdown <= 0)
			{
				stopGlowing();
			}
		}
		if (location.farmers.Any())
		{
			behaviorAtGameTick(time);
			Layer val = location.map.RequireLayer("Back");
			if (base.Position.X < 0f || base.Position.X > (float)(val.LayerWidth * 64) || base.Position.Y < 0f || base.Position.Y > (float)(val.LayerHeight * 64))
			{
				location.characters.Remove(this);
			}
			updateGlow();
			if (stunTime.Value > 0)
			{
				stunTime.Value -= (int)time.ElapsedGameTime.TotalMilliseconds;
			}
		}
	}

	public override void draw(SpriteBatch b)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		if (!base.IsInvisible && Utility.isOnScreen(base.Position, 128))
		{
			Rectangle boundingBox = GetBoundingBox();
			int y = base.StandingPixel.Y;
			b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(boundingBox.Height / 2 + yJumpOffset)), (Rectangle?)Sprite.SourceRect, Color.White, rotation, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f)));
			if (isGlowing)
			{
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(boundingBox.Height / 2 + yJumpOffset)), (Rectangle?)Sprite.SourceRect, glowingColor * glowingTransparency, rotation, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f + 0.001f)));
			}
		}
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		isEmoting = false;
		Sprite.loop = false;
		if (stunTime.Value > 0)
		{
			return;
		}
		Rectangle boundingBox = GetBoundingBox();
		if (Sprite.currentFrame < 4)
		{
			((Rectangle)(ref boundingBox)).Inflate(128, 128);
			if (!base.IsInvisible || ((Rectangle)(ref boundingBox)).Contains(base.Player.StandingPixel))
			{
				if (base.IsInvisible)
				{
					Tile val = base.currentLocation.map.RequireLayer("Back").Tiles[base.Player.TilePoint.X, base.Player.TilePoint.Y];
					if (((IDictionary<string, PropertyValue>)((Component)val).Properties).ContainsKey("NPCBarrier") || (!((IDictionary<string, PropertyValue>)val.TileIndexProperties).ContainsKey("Diggable") && val.TileIndex != 0))
					{
						return;
					}
					base.Position = new Vector2(base.Player.Position.X, base.Player.Position.Y + (float)base.Player.Sprite.SpriteHeight - (float)Sprite.SpriteHeight);
					base.currentLocation.localSound("Duggy");
					base.Position = base.Player.Tile * 64f;
				}
				base.IsInvisible = false;
				Sprite.interval = 100f;
				Sprite.AnimateDown(time);
			}
		}
		if (Sprite.currentFrame >= 4 && Sprite.currentFrame < 8)
		{
			((Rectangle)(ref boundingBox)).Inflate(-128, -128);
			base.currentLocation.isCollidingPosition(boundingBox, Game1.viewport, isFarmer: false, 8, glider: false, this);
			Sprite.AnimateRight(time);
			Sprite.interval = 220f;
			base.DamageToFarmer = 8;
		}
		if (Sprite.currentFrame >= 8)
		{
			Sprite.AnimateUp(time);
		}
		if (Sprite.currentFrame >= 10)
		{
			base.IsInvisible = true;
			Sprite.currentFrame = 0;
			Point tilePoint = base.TilePoint;
			base.currentLocation.map.RequireLayer("Back").Tiles[tilePoint.X, tilePoint.Y].TileIndex = 0;
			base.currentLocation.removeObjectsAndSpawned(tilePoint.X, tilePoint.Y, 1, 1);
			base.DamageToFarmer = 0;
		}
	}
}
