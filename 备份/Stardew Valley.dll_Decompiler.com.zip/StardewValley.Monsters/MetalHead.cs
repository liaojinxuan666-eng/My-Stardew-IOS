using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Locations;

namespace StardewValley.Monsters;

public class MetalHead : Monster
{
	[XmlElement("c")]
	public readonly NetColor c = new NetColor();

	public MetalHead()
	{
	}

	public MetalHead(Vector2 tileLocation, MineShaft mine)
		: this(tileLocation, mine.getMineArea())
	{
	}//IL_0001: Unknown result type (might be due to invalid IL or missing references)


	public MetalHead(string name, Vector2 tileLocation)
		: base(name, tileLocation)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		Sprite.SpriteHeight = 16;
		Sprite.UpdateSourceRect();
		c.Value = Color.White;
		base.IsWalkingTowardPlayer = true;
	}

	public MetalHead(Vector2 tileLocation, int mineArea)
		: base("Metal Head", tileLocation)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		Sprite.SpriteHeight = 16;
		Sprite.UpdateSourceRect();
		c.Value = Color.White;
		base.IsWalkingTowardPlayer = true;
		switch (mineArea)
		{
		case 0:
			c.Value = Color.White;
			break;
		case 40:
			c.Value = Color.Turquoise;
			base.Health *= 2;
			break;
		case 80:
			c.Value = Color.White;
			base.Health *= 3;
			break;
		}
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(c, "c");
		position.Field.AxisAlignedMovement = true;
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		return takeDamage(damage, xTrajectory, yTrajectory, isBomb, addedPrecision, "clank");
	}

	protected override void localDeathAnimation()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(46, base.Position, Color.DarkGray, 10, flipped: false, 70f));
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(46, base.Position + new Vector2(-32f, 0f), Color.DarkGray, 10, flipped: false, 70f)
		{
			delayBeforeAnimationStart = 300
		});
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(46, base.Position + new Vector2(32f, 0f), Color.DarkGray, 10, flipped: false, 70f)
		{
			delayBeforeAnimationStart = 600
		});
		base.currentLocation.localSound("monsterdead");
		Utility.makeTemporarySpriteJuicier(new TemporaryAnimatedSprite(44, base.Position, Color.MediumPurple, 10)
		{
			holdLastFrame = true,
			alphaFade = 0.01f,
			interval = 70f
		}, base.currentLocation);
		base.localDeathAnimation();
	}

	public override void draw(SpriteBatch b)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		if (!base.IsInvisible && Utility.isOnScreen(base.Position, 128))
		{
			int y = base.StandingPixel.Y;
			Texture2D shadowTexture = Game1.shadowTexture;
			Vector2 val = getLocalPosition(Game1.viewport) + new Vector2(32f, 42f + yOffset);
			Rectangle? val2 = Game1.shadowTexture.Bounds;
			Color white = Color.White;
			Rectangle bounds = Game1.shadowTexture.Bounds;
			float num = ((Rectangle)(ref bounds)).Center.X;
			bounds = Game1.shadowTexture.Bounds;
			b.Draw(shadowTexture, val, val2, white, 0f, new Vector2(num, (float)((Rectangle)(ref bounds)).Center.Y), 3.5f + scale.Value + yOffset / 30f, (SpriteEffects)0, (float)(y - 1) / 10000f);
			b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(48 + yJumpOffset)), (Rectangle?)Sprite.SourceRect, c.Value, rotation, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f)));
		}
	}

	public override void shedChunks(int number, float scale)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		Point standingPixel = base.StandingPixel;
		Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(0, Sprite.getHeight() * 4, 16, 16), 8, standingPixel.X, standingPixel.Y, number, base.TilePoint.Y, Color.White, scale * 4f);
	}

	public override List<Item> getExtraDropItems()
	{
		List<Item> list = new List<Item>();
		if ((Game1.stats.getMonstersKilled(name.Value) + (int)Game1.uniqueIDForThisGame) % 100 == 0)
		{
			list.Add(ItemRegistry.Create("(H)51"));
		}
		return list;
	}

	protected override void updateMonsterSlaveAnimation(GameTime time)
	{
		if (isMoving())
		{
			switch (FacingDirection)
			{
			case 0:
				Sprite.AnimateUp(time);
				break;
			case 3:
				Sprite.AnimateLeft(time);
				break;
			case 1:
				Sprite.AnimateRight(time);
				break;
			case 2:
				Sprite.AnimateDown(time);
				break;
			}
		}
		else
		{
			Sprite.StopAnimation();
		}
	}
}
