using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.Projectiles;

namespace StardewValley.Monsters;

public class BlueSquid : Monster
{
	public float nextFire;

	public int squidYOffset;

	public float canMoveTimer;

	public NetFloat projectileIntroTimer = new NetFloat();

	public NetFloat projectileOutroTimer = new NetFloat();

	public NetBool nearFarmer = new NetBool();

	public NetFloat lastRotation = new NetFloat();

	[XmlIgnore]
	public bool justThrust;

	public BlueSquid()
	{
	}

	public BlueSquid(Vector2 position)
		: base("Blue Squid", position)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		Sprite.SpriteHeight = 24;
		Sprite.SpriteWidth = 24;
		base.IsWalkingTowardPlayer = true;
		reloadSprite();
		Sprite.UpdateSourceRect();
		base.HideShadow = true;
		slipperiness.Value = Game1.random.Next(6, 9);
		canMoveTimer = Game1.random.Next(500);
		isHardModeMonster.Value = true;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(projectileIntroTimer, "projectileIntroTimer").AddField(projectileOutroTimer, "projectileOutroTimer").AddField(lastRotation, "lastRotation")
			.AddField(nearFarmer, "nearFarmer");
		lastRotation.Interpolated(interpolate: false, wait: false);
		projectileIntroTimer.Interpolated(interpolate: false, wait: false);
		projectileOutroTimer.Interpolated(interpolate: false, wait: false);
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		Sprite = new AnimatedSprite("Characters\\Monsters\\Blue Squid", 0, 24, 24);
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		int num = Math.Max(1, damage - resilience.Value);
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Health -= num;
			projectileOutroTimer.Value = 0f;
			projectileIntroTimer.Value = 0f;
			shakeTimer = 250;
			setTrajectory(xTrajectory, yTrajectory);
			lastRotation.Value = (float)Math.Atan2(0f - yVelocity, xVelocity) + (float)Math.PI / 2f;
			DelayedAction.playSoundAfterDelay("squid_hit", 80, base.currentLocation);
			base.currentLocation.playSound("slimeHit");
			if (base.Health <= 0)
			{
				deathAnimation();
			}
		}
		return num;
	}

	protected override void sharedDeathAnimation()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.localSound("slimedead");
		if (Sprite.Texture.Height > Sprite.getHeight() * 4)
		{
			Point standingPixel = base.StandingPixel;
			Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(0, 48, 16, 16), 8, standingPixel.X, standingPixel.Y, 6, base.TilePoint.Y, Color.White, 4f * scale.Value);
		}
	}

	protected override void localDeathAnimation()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite(44, base.Position, Color.HotPink * 0.86f, 10)
		{
			interval = 70f,
			holdLastFrame = true,
			alphaFade = 0.01f
		});
		Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite(44, base.Position + new Vector2(-16f, 0f), Color.HotPink * 0.86f, 10)
		{
			interval = 70f,
			delayBeforeAnimationStart = 0,
			holdLastFrame = true,
			alphaFade = 0.01f
		});
		Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite(44, base.Position + new Vector2(0f, -16f), Color.HotPink * 0.86f, 10)
		{
			interval = 70f,
			delayBeforeAnimationStart = 100,
			holdLastFrame = true,
			alphaFade = 0.01f
		});
		Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite(44, base.Position + new Vector2(16f, 0f), Color.HotPink * 0.86f, 10)
		{
			interval = 70f,
			delayBeforeAnimationStart = 200,
			holdLastFrame = true,
			alphaFade = 0.01f
		});
	}

	public override Rectangle GetBoundingBox()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		if (Sprite == null)
		{
			return Rectangle.Empty;
		}
		Vector2 val = base.Position;
		int num = GetSpriteWidthForPositioning() * 4 * 3 / 4;
		return new Rectangle((int)val.X, (int)val.Y + 16, num, 64);
	}

	public override void drawAboveAllLayers(SpriteBatch b)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		int y = base.StandingPixel.Y;
		Texture2D shadowTexture = Game1.shadowTexture;
		Vector2 val = getLocalPosition(Game1.viewport) + new Vector2(32f, 96f);
		Rectangle? val2 = Game1.shadowTexture.Bounds;
		Color white = Color.White;
		Rectangle bounds = Game1.shadowTexture.Bounds;
		float num = ((Rectangle)(ref bounds)).Center.X;
		bounds = Game1.shadowTexture.Bounds;
		b.Draw(shadowTexture, val, val2, white, 0f, new Vector2(num, (float)((Rectangle)(ref bounds)).Center.Y), Math.Min(4f, 4f + (float)squidYOffset / 20f), (SpriteEffects)0, (float)(y - 32) / 10000f);
		b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(21 + squidYOffset)) + new Vector2((float)((shakeTimer > 0) ? Game1.random.Next(-2, 3) : 0), (float)((shakeTimer > 0) ? Game1.random.Next(-2, 3) : 0)), (Rectangle?)Sprite.SourceRect, Color.White, lastRotation.Value, new Vector2(12f, 12f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f)));
	}

	protected override void updateAnimation(GameTime time)
	{
		if (Sprite.CurrentFrame != 2)
		{
			justThrust = false;
		}
		if (projectileIntroTimer.Value > 0f)
		{
			shakeTimer = 10;
			Sprite.CurrentFrame = 6;
			squidYOffset--;
			if (squidYOffset < 0)
			{
				squidYOffset = 0;
			}
		}
		else if (projectileOutroTimer.Value > 0f)
		{
			Sprite.CurrentFrame = 5;
			squidYOffset += 2;
		}
		else
		{
			squidYOffset = (int)(Math.Sin((double)((float)time.TotalGameTime.TotalMilliseconds / 2000f) * Math.PI * 2.0) * 30.0);
			Sprite.currentFrame = Math.Abs(squidYOffset - 24) / 12;
			if (squidYOffset < 0)
			{
				Sprite.CurrentFrame = 2;
			}
		}
		Sprite.UpdateSourceRect();
	}

	public override void noMovementProgressNearPlayerBehavior()
	{
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03af: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0429: Unknown result type (might be due to invalid IL or missing references)
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0503: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_065f: Unknown result type (might be due to invalid IL or missing references)
		//IL_066a: Unknown result type (might be due to invalid IL or missing references)
		//IL_068b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0696: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bf: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		nearFarmer.Value = withinPlayerThreshold(10) || base.focusedOnFarmers;
		if (projectileIntroTimer.Value <= 0f && projectileOutroTimer.Value <= 0f)
		{
			if (Math.Abs(xVelocity) <= 1f && Math.Abs(yVelocity) <= 1f && nearFarmer.Value)
			{
				Vector2 velocityTowardPoint = Utility.getVelocityTowardPoint(findPlayer().position.Value, position.Value, Game1.random.Next(25, 50));
				velocityTowardPoint.X *= -1f;
				if (canMoveTimer > 0f)
				{
					canMoveTimer -= (float)time.ElapsedGameTime.TotalMilliseconds;
				}
				if (!justThrust && Sprite.CurrentFrame == 2 && canMoveTimer <= 0f)
				{
					justThrust = true;
					Vector2 velocityTowardPoint2 = Utility.getVelocityTowardPoint(findPlayer().position.Value, position.Value + new Vector2((float)Game1.random.Next(-64, 64)), Game1.random.Next(25, 50));
					velocityTowardPoint2.X *= -1f;
					setTrajectory(velocityTowardPoint2);
					lastRotation.Value = (float)Math.Atan2(0f - yVelocity, xVelocity) + (float)Math.PI / 2f;
					base.currentLocation.playSound("squid_move");
					canMoveTimer = 500f;
				}
			}
			else if (!nearFarmer.Value)
			{
				lastRotation.Value = 0f;
			}
		}
		if ((Math.Abs(xVelocity) >= 10f || Math.Abs(yVelocity) >= 10f) && Game1.random.NextDouble() < 0.25)
		{
			Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite("LooseSprites\\Cursors2", new Rectangle(Game1.random.Choose(135, 140), 234, 5, 5), base.Position + new Vector2(32f, (float)(32 + Game1.random.Next(-8, 8))), flipped: false, 0.01f, Color.White)
			{
				interval = 9999f,
				holdLastFrame = true,
				alphaFade = 0.01f,
				motion = new Vector2(0f, -1f),
				xPeriodic = true,
				xPeriodicLoopTime = Game1.random.Next(800, 1200),
				xPeriodicRange = Game1.random.Next(8, 20),
				scale = 4f,
				drawAboveAlwaysFront = true
			});
		}
		if (projectileIntroTimer.Value > 0f)
		{
			projectileIntroTimer.Value -= (float)time.ElapsedGameTime.TotalMilliseconds;
			shakeTimer = 10;
			if (Game1.random.NextDouble() < 0.25)
			{
				Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite("LooseSprites\\Cursors2", new Rectangle(Game1.random.Choose(135, 140), 234, 5, 5), base.Position + new Vector2((float)(21 + Game1.random.Next(-21, 21)), (float)(squidYOffset / 2 + 32 + Game1.random.Next(-32, 32))), flipped: false, 0.01f, Color.White)
				{
					interval = 9999f,
					holdLastFrame = true,
					alphaFade = 0.01f,
					motion = new Vector2(0f, -1f),
					xPeriodic = true,
					xPeriodicLoopTime = Game1.random.Next(800, 1200),
					xPeriodicRange = Game1.random.Next(8, 20),
					scale = 4f,
					drawAboveAlwaysFront = true
				});
			}
			if (projectileIntroTimer.Value < 0f)
			{
				projectileOutroTimer.Value = 500f;
				base.IsWalkingTowardPlayer = false;
				Halt();
				Point standingPixel = base.StandingPixel;
				Vector2 velocityTowardPlayer = Utility.getVelocityTowardPlayer(standingPixel, 8f, base.Player);
				DebuffingProjectile debuffingProjectile = new DebuffingProjectile("27", 8, 3, 4, 0f, velocityTowardPlayer.X, velocityTowardPlayer.Y, Utility.PointToVector2(standingPixel) - new Vector2(32f, (float)(-squidYOffset)), base.currentLocation, this);
				debuffingProjectile.height.Value = 48f;
				base.currentLocation.projectiles.Add(debuffingProjectile);
				base.currentLocation.playSound("debuffSpell");
				nextFire = Game1.random.Next(1200, 3500);
			}
		}
		else if (projectileOutroTimer.Value > 0f)
		{
			projectileOutroTimer.Value -= (float)time.ElapsedGameTime.TotalMilliseconds;
		}
		nextFire = Math.Max(0f, nextFire - (float)time.ElapsedGameTime.Milliseconds);
		if (withinPlayerThreshold(6) && nextFire == 0f && projectileIntroTimer.Value <= 0f && Math.Abs(xVelocity) < 1f && Math.Abs(yVelocity) < 1f && Game1.random.NextDouble() < 0.003 && canMoveTimer <= 0f && base.currentLocation.hasTileAt(base.TilePoint.X, base.TilePoint.Y, "Back") && !base.currentLocation.hasTileAt(base.TilePoint.X, base.TilePoint.Y, "Buildings") && !base.currentLocation.hasTileAt(base.TilePoint.X, base.TilePoint.Y, "Front"))
		{
			projectileIntroTimer.Value = 1000f;
			lastRotation.Value = 0f;
			base.currentLocation.playSound("squid_bubble");
		}
	}
}
