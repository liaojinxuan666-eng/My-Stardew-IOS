using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.Network;

namespace StardewValley.Monsters;

public class Serpent : Monster
{
	public const float rotationIncrement = (float)Math.PI / 64f;

	[XmlIgnore]
	public int wasHitCounter;

	[XmlIgnore]
	public float targetRotation;

	[XmlIgnore]
	public bool turningRight;

	[XmlIgnore]
	public readonly NetFarmerRef killer = new NetFarmerRef().Delayed(interpolationWait: false);

	public List<Vector3> segments = new List<Vector3>();

	public NetInt segmentCount = new NetInt(0);

	public Serpent()
	{
	}

	public Serpent(Vector2 position)
		: base("Serpent", position)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		InitializeAttributes();
	}

	public Serpent(Vector2 position, string name)
		: base(name, position)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		InitializeAttributes();
		if (name == "Royal Serpent")
		{
			segmentCount.Value = Game1.random.Next(3, 7);
			if (Game1.random.NextDouble() < 0.1)
			{
				segmentCount.Value = Game1.random.Next(5, 10);
			}
			else if (Game1.random.NextDouble() < 0.01)
			{
				segmentCount.Value *= 3;
			}
			reloadSprite();
			base.MaxHealth += segmentCount.Value * 50;
			base.Health = base.MaxHealth;
		}
	}

	public virtual void InitializeAttributes()
	{
		base.Slipperiness = 24 + Game1.random.Next(10);
		Halt();
		base.IsWalkingTowardPlayer = false;
		Sprite.SpriteWidth = 32;
		Sprite.SpriteHeight = 32;
		base.Scale = 0.75f;
		base.HideShadow = true;
	}

	public bool IsRoyalSerpent()
	{
		return segmentCount.Value > 1;
	}

	public override bool TakesDamageFromHitbox(Rectangle area_of_effect)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		if (base.TakesDamageFromHitbox(area_of_effect))
		{
			return true;
		}
		if (IsRoyalSerpent())
		{
			Rectangle boundingBox = GetBoundingBox();
			Vector2 val = default(Vector2);
			((Vector2)(ref val))._002Ector((float)boundingBox.X - base.Position.X, (float)boundingBox.Y - base.Position.Y);
			foreach (Vector3 segment in segments)
			{
				boundingBox.X = (int)(segment.X + val.X);
				boundingBox.Y = (int)(segment.Y + val.Y);
				if (((Rectangle)(ref boundingBox)).Intersects(area_of_effect))
				{
					return true;
				}
			}
		}
		return false;
	}

	public override bool OverlapsFarmerForDamage(Farmer who)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		if (base.OverlapsFarmerForDamage(who))
		{
			return true;
		}
		if (IsRoyalSerpent())
		{
			Rectangle boundingBox = GetBoundingBox();
			Rectangle boundingBox2 = who.GetBoundingBox();
			Vector2 val = default(Vector2);
			((Vector2)(ref val))._002Ector((float)boundingBox.X - base.Position.X, (float)boundingBox.Y - base.Position.Y);
			foreach (Vector3 segment in segments)
			{
				boundingBox.X = (int)(segment.X + val.X);
				boundingBox.Y = (int)(segment.Y + val.Y);
				if (((Rectangle)(ref boundingBox)).Intersects(boundingBox2))
				{
					return true;
				}
			}
		}
		return false;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(killer.NetFields, "killer.NetFields").AddField(segmentCount, "segmentCount");
		segmentCount.fieldChangeVisibleEvent += delegate(NetInt field, int old_value, int new_value)
		{
			if (new_value > 0)
			{
				reloadSprite();
			}
		};
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		if (IsRoyalSerpent())
		{
			Sprite = new AnimatedSprite("Characters\\Monsters\\Royal Serpent");
			base.Scale = 1f;
		}
		else
		{
			Sprite = new AnimatedSprite("Characters\\Monsters\\Serpent");
			base.Scale = 0.75f;
		}
		Sprite.SpriteWidth = 32;
		Sprite.SpriteHeight = 32;
		base.HideShadow = true;
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		int num = Math.Max(1, damage - resilience.Value);
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Health -= num;
			setTrajectory(xTrajectory / 3, yTrajectory / 3);
			wasHitCounter = 500;
			base.currentLocation.playSound("serpentHit");
			if (base.Health <= 0)
			{
				killer.Value = who;
				deathAnimation();
			}
		}
		addedSpeed = Game1.random.Next(-1, 1);
		return num;
	}

	protected override void sharedDeathAnimation()
	{
	}

	protected override void localDeathAnimation()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_061d: Unknown result type (might be due to invalid IL or missing references)
		//IL_062a: Unknown result type (might be due to invalid IL or missing references)
		//IL_063b: Unknown result type (might be due to invalid IL or missing references)
		//IL_068f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0694: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0708: Unknown result type (might be due to invalid IL or missing references)
		//IL_070d: Unknown result type (might be due to invalid IL or missing references)
		//IL_072e: Unknown result type (might be due to invalid IL or missing references)
		//IL_073a: Unknown result type (might be due to invalid IL or missing references)
		//IL_073f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0744: Unknown result type (might be due to invalid IL or missing references)
		//IL_074e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0781: Unknown result type (might be due to invalid IL or missing references)
		//IL_078b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0790: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0807: Unknown result type (might be due to invalid IL or missing references)
		//IL_0811: Unknown result type (might be due to invalid IL or missing references)
		//IL_0816: Unknown result type (might be due to invalid IL or missing references)
		//IL_0837: Unknown result type (might be due to invalid IL or missing references)
		//IL_0839: Unknown result type (might be due to invalid IL or missing references)
		//IL_0843: Unknown result type (might be due to invalid IL or missing references)
		//IL_0879: Unknown result type (might be due to invalid IL or missing references)
		//IL_0883: Unknown result type (might be due to invalid IL or missing references)
		//IL_0888: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_08bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0909: Unknown result type (might be due to invalid IL or missing references)
		//IL_090e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_034b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_035f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0392: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03de: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0401: Unknown result type (might be due to invalid IL or missing references)
		//IL_0437: Unknown result type (might be due to invalid IL or missing references)
		//IL_0441: Unknown result type (might be due to invalid IL or missing references)
		//IL_0446: Unknown result type (might be due to invalid IL or missing references)
		//IL_047e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0483: Unknown result type (might be due to invalid IL or missing references)
		//IL_0488: Unknown result type (might be due to invalid IL or missing references)
		//IL_0492: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_050f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0514: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_0528: Unknown result type (might be due to invalid IL or missing references)
		//IL_052d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0537: Unknown result type (might be due to invalid IL or missing references)
		//IL_056d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0577: Unknown result type (might be due to invalid IL or missing references)
		//IL_057c: Unknown result type (might be due to invalid IL or missing references)
		if (killer.Value == null)
		{
			return;
		}
		Rectangle boundingBox = GetBoundingBox();
		((Rectangle)(ref boundingBox)).Inflate(-boundingBox.Width / 2 + 1, -boundingBox.Height / 2 + 1);
		Vector2 velocityTowardPlayer = Utility.getVelocityTowardPlayer(((Rectangle)(ref boundingBox)).Center, 4f, killer.Value);
		int num = -(int)velocityTowardPlayer.X;
		int num2 = -(int)velocityTowardPlayer.Y;
		if (IsRoyalSerpent())
		{
			base.currentLocation.localSound("serpentDie");
			Vector2 val = default(Vector2);
			Rectangle sourceRect = default(Rectangle);
			for (int i = -1; i < segments.Count; i++)
			{
				float z;
				float t;
				if (i == -1)
				{
					val = base.Position;
					((Rectangle)(ref sourceRect))._002Ector(0, 64, 32, 32);
					z = rotation;
					t = 0f;
				}
				else
				{
					if (segments.Count <= 0 || i >= segments.Count)
					{
						break;
					}
					t = (float)(i + 1) / (float)segments.Count;
					((Vector2)(ref val))._002Ector(segments[i].X, segments[i].Y);
					boundingBox.X = (int)(val.X - (float)(boundingBox.Width / 2));
					boundingBox.Y = (int)(val.Y - (float)(boundingBox.Height / 2));
					((Rectangle)(ref sourceRect))._002Ector(32, 64, 32, 32);
					if (i == segments.Count - 1)
					{
						((Rectangle)(ref sourceRect))._002Ector(64, 64, 32, 32);
					}
					z = segments[i].Z;
				}
				Color color = default(Color);
				((Color)(ref color)).R = (byte)Utility.Lerp(255f, 255f, t);
				((Color)(ref color)).G = (byte)Utility.Lerp(0f, 166f, t);
				((Color)(ref color)).B = (byte)Utility.Lerp(0f, 0f, t);
				((Color)(ref color)).A = byte.MaxValue;
				TemporaryAnimatedSprite temporaryAnimatedSprite = new TemporaryAnimatedSprite(Sprite.textureName.Value, sourceRect, 800f, 1, 0, val, flicker: false, flipped: false, 0.9f, 0.001f, color, 4f * scale.Value, 0.01f, z + (float)Math.PI, (float)((double)Game1.random.Next(3, 5) * Math.PI / 64.0))
				{
					motion = new Vector2((float)num, (float)num2),
					layerDepth = 1f
				};
				temporaryAnimatedSprite.alphaFade = 0.025f;
				base.currentLocation.temporarySprites.Add(temporaryAnimatedSprite);
				temporaryAnimatedSprite = new TemporaryAnimatedSprite(5, Utility.PointToVector2(((Rectangle)(ref boundingBox)).Center) + new Vector2(-32f, 0f), Color.LightGreen * 0.9f, 10, flipped: false, 70f)
				{
					delayBeforeAnimationStart = 50,
					motion = new Vector2((float)num, (float)num2),
					layerDepth = 1f
				};
				if (i == -1)
				{
					temporaryAnimatedSprite.startSound = "cowboy_monsterhit";
				}
				base.currentLocation.temporarySprites.Add(temporaryAnimatedSprite);
				temporaryAnimatedSprite = new TemporaryAnimatedSprite(5, Utility.PointToVector2(((Rectangle)(ref boundingBox)).Center) + new Vector2(32f, 0f), Color.LightGreen * 0.8f, 10, flipped: false, 70f)
				{
					delayBeforeAnimationStart = 100,
					startSound = "cowboy_monsterhit",
					motion = new Vector2((float)num, (float)num2) * 0.8f,
					layerDepth = 1f
				};
				if (i == -1)
				{
					temporaryAnimatedSprite.startSound = "cowboy_monsterhit";
				}
				base.currentLocation.temporarySprites.Add(temporaryAnimatedSprite);
				temporaryAnimatedSprite = new TemporaryAnimatedSprite(5, Utility.PointToVector2(((Rectangle)(ref boundingBox)).Center) + new Vector2(0f, -32f), Color.LightGreen * 0.7f, 10)
				{
					delayBeforeAnimationStart = 150,
					startSound = "cowboy_monsterhit",
					motion = new Vector2((float)num, (float)num2) * 0.6f,
					layerDepth = 1f
				};
				if (i == -1)
				{
					temporaryAnimatedSprite.startSound = "cowboy_monsterhit";
				}
				base.currentLocation.temporarySprites.Add(temporaryAnimatedSprite);
				temporaryAnimatedSprite = new TemporaryAnimatedSprite(5, Utility.PointToVector2(((Rectangle)(ref boundingBox)).Center), Color.LightGreen * 0.6f, 10, flipped: false, 70f)
				{
					delayBeforeAnimationStart = 200,
					startSound = "cowboy_monsterhit",
					motion = new Vector2((float)num, (float)num2) * 0.4f,
					layerDepth = 1f
				};
				if (i == -1)
				{
					temporaryAnimatedSprite.startSound = "cowboy_monsterhit";
				}
				base.currentLocation.temporarySprites.Add(temporaryAnimatedSprite);
				temporaryAnimatedSprite = new TemporaryAnimatedSprite(5, Utility.PointToVector2(((Rectangle)(ref boundingBox)).Center) + new Vector2(0f, 32f), Color.LightGreen * 0.5f, 10)
				{
					delayBeforeAnimationStart = 250,
					startSound = "cowboy_monsterhit",
					motion = new Vector2((float)num, (float)num2) * 0.2f,
					layerDepth = 1f
				};
				if (i == -1)
				{
					temporaryAnimatedSprite.startSound = "cowboy_monsterhit";
				}
				base.currentLocation.temporarySprites.Add(temporaryAnimatedSprite);
			}
		}
		else
		{
			Vector2 val2 = Utility.PointToVector2(base.StandingPixel);
			base.currentLocation.localSound("serpentDie");
			base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(Sprite.textureName.Value, new Rectangle(0, 64, 32, 32), 200f, 4, 0, base.Position, flicker: false, flipped: false, 0.9f, 0.001f, Color.White, 4f * scale.Value, 0.01f, rotation + (float)Math.PI, (float)((double)Game1.random.Next(3, 5) * Math.PI / 64.0))
			{
				motion = new Vector2((float)num, (float)num2),
				layerDepth = 1f
			});
			base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(5, val2 + new Vector2(-32f, 0f), Color.LightGreen * 0.9f, 10, flipped: false, 70f)
			{
				delayBeforeAnimationStart = 50,
				startSound = "cowboy_monsterhit",
				motion = new Vector2((float)num, (float)num2),
				layerDepth = 1f
			});
			base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(5, val2 + new Vector2(32f, 0f), Color.LightGreen * 0.8f, 10, flipped: false, 70f)
			{
				delayBeforeAnimationStart = 100,
				startSound = "cowboy_monsterhit",
				motion = new Vector2((float)num, (float)num2) * 0.8f,
				layerDepth = 1f
			});
			base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(5, val2 + new Vector2(0f, -32f), Color.LightGreen * 0.7f, 10)
			{
				delayBeforeAnimationStart = 150,
				startSound = "cowboy_monsterhit",
				motion = new Vector2((float)num, (float)num2) * 0.6f,
				layerDepth = 1f
			});
			base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(5, val2, Color.LightGreen * 0.6f, 10, flipped: false, 70f)
			{
				delayBeforeAnimationStart = 200,
				startSound = "cowboy_monsterhit",
				motion = new Vector2((float)num, (float)num2) * 0.4f,
				layerDepth = 1f
			});
			base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(5, val2 + new Vector2(0f, 32f), Color.LightGreen * 0.5f, 10)
			{
				delayBeforeAnimationStart = 250,
				startSound = "cowboy_monsterhit",
				motion = new Vector2((float)num, (float)num2) * 0.2f,
				layerDepth = 1f
			});
		}
	}

	public override List<Item> getExtraDropItems()
	{
		List<Item> list = new List<Item>();
		if (Game1.random.NextDouble() < 0.002)
		{
			list.Add(ItemRegistry.Create("(O)485"));
		}
		return list;
	}

	public override void drawAboveAllLayers(SpriteBatch b)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_058a: Unknown result type (might be due to invalid IL or missing references)
		//IL_058c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_0312: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_0399: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0457: Unknown result type (might be due to invalid IL or missing references)
		//IL_0463: Unknown result type (might be due to invalid IL or missing references)
		//IL_0468: Unknown result type (might be due to invalid IL or missing references)
		//IL_046d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0474: Unknown result type (might be due to invalid IL or missing references)
		//IL_0485: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03de: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0401: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_041a: Unknown result type (might be due to invalid IL or missing references)
		//IL_041f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0423: Unknown result type (might be due to invalid IL or missing references)
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0504: Unknown result type (might be due to invalid IL or missing references)
		//IL_0509: Unknown result type (might be due to invalid IL or missing references)
		//IL_0511: Unknown result type (might be due to invalid IL or missing references)
		//IL_051c: Unknown result type (might be due to invalid IL or missing references)
		//IL_052d: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = base.Position;
		bool flag = IsRoyalSerpent();
		int y = base.StandingPixel.Y;
		Vector2 val2 = default(Vector2);
		for (int i = -1; i < segmentCount.Value; i++)
		{
			float num = (float)(i + 1) * -0.25f / 10000f;
			float num2 = (float)segmentCount.Value * -0.25f / 10000f - 5E-05f;
			if ((float)(y - 1) / 10000f + num2 < 0f)
			{
				num += 0f - ((float)(y - 1) / 10000f + num2);
			}
			Rectangle sourceRect = Sprite.SourceRect;
			Vector2 globalPosition = base.Position;
			float z;
			if (i == -1)
			{
				if (flag)
				{
					((Rectangle)(ref sourceRect))._002Ector(0, 0, 32, 32);
				}
				val2 = base.Position;
				z = rotation;
			}
			else
			{
				if (i >= segments.Count)
				{
					break;
				}
				Vector3 val3 = segments[i];
				((Vector2)(ref val2))._002Ector(val3.X, val3.Y);
				((Rectangle)(ref sourceRect))._002Ector(32, 0, 32, 32);
				if (i == segments.Count - 1)
				{
					((Rectangle)(ref sourceRect))._002Ector(64, 0, 32, 32);
				}
				z = val3.Z;
				globalPosition = (val + val2) / 2f;
			}
			if (Utility.isOnScreen(val2, 128))
			{
				Vector2 val4 = Game1.GlobalToLocal(Game1.viewport, val2) + drawOffset + new Vector2(0f, (float)yJumpOffset);
				Vector2 val5 = Game1.GlobalToLocal(Game1.viewport, globalPosition) + drawOffset + new Vector2(0f, (float)yJumpOffset);
				int height = GetBoundingBox().Height;
				Texture2D shadowTexture = Game1.shadowTexture;
				Vector2 val6 = val5 + new Vector2(64f, (float)height);
				Rectangle? val7 = Game1.shadowTexture.Bounds;
				Color white = Color.White;
				Rectangle bounds = Game1.shadowTexture.Bounds;
				float num3 = ((Rectangle)(ref bounds)).Center.X;
				bounds = Game1.shadowTexture.Bounds;
				b.Draw(shadowTexture, val6, val7, white, 0f, new Vector2(num3, (float)((Rectangle)(ref bounds)).Center.Y), 4f, (SpriteEffects)0, (float)(y - 1) / 10000f + num);
				b.Draw(Sprite.Texture, val4 + new Vector2(64f, (float)(height / 2)), (Rectangle?)sourceRect, Color.White, z, new Vector2(16f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)(y + 8) / 10000f + num)));
				if (isGlowing)
				{
					b.Draw(Sprite.Texture, val4 + new Vector2(64f, (float)(height / 2)), (Rectangle?)sourceRect, glowingColor * glowingTransparency, z, new Vector2(16f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)(y + 8) / 10000f + 0.0001f + num)));
				}
				if (flag)
				{
					num += -5E-05f;
					z = 0f;
					((Rectangle)(ref sourceRect))._002Ector(96, 0, 32, 32);
					val4 = Game1.GlobalToLocal(Game1.viewport, val) + drawOffset + new Vector2(0f, (float)yJumpOffset);
					if (i > 0)
					{
						Texture2D shadowTexture2 = Game1.shadowTexture;
						Vector2 val8 = val4 + new Vector2(64f, (float)height);
						Rectangle? val9 = Game1.shadowTexture.Bounds;
						Color white2 = Color.White;
						bounds = Game1.shadowTexture.Bounds;
						float num4 = ((Rectangle)(ref bounds)).Center.X;
						bounds = Game1.shadowTexture.Bounds;
						b.Draw(shadowTexture2, val8, val9, white2, 0f, new Vector2(num4, (float)((Rectangle)(ref bounds)).Center.Y), 4f, (SpriteEffects)0, (float)(y - 1) / 10000f + num);
					}
					b.Draw(Sprite.Texture, val4 + new Vector2(64f, (float)(height / 2)), (Rectangle?)sourceRect, Color.White, z, new Vector2(16f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)(y + 8) / 10000f + num)));
					if (isGlowing)
					{
						b.Draw(Sprite.Texture, val4 + new Vector2(64f, (float)(height / 2)), (Rectangle?)sourceRect, glowingColor * glowingTransparency, z, new Vector2(16f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)(y + 8) / 10000f + 0.0001f + num)));
					}
				}
			}
			val = val2;
		}
	}

	public override Rectangle GetBoundingBox()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = base.Position;
		return new Rectangle((int)val.X + 8, (int)val.Y, Sprite.SpriteWidth * 4 * 3 / 4, 96);
	}

	protected override void updateAnimation(GameTime time)
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		if (IsRoyalSerpent())
		{
			if (segments.Count < segmentCount.Value)
			{
				for (int i = 0; i < segmentCount.Value; i++)
				{
					Vector2 val = base.Position;
					segments.Add(new Vector3(val.X, val.Y, 0f));
				}
			}
			Vector2 val2 = base.Position;
			Vector2 val3 = default(Vector2);
			for (int j = 0; j < segments.Count; j++)
			{
				((Vector2)(ref val3))._002Ector(segments[j].X, segments[j].Y);
				Vector2 val4 = val3 - val2;
				int num = 64;
				int num2 = (int)((Vector2)(ref val4)).Length();
				((Vector2)(ref val4)).Normalize();
				if (num2 > num)
				{
					val3 = val4 * (float)num + val2;
				}
				double num3 = Math.Atan2(val4.Y, val4.X) - Math.PI / 2.0;
				segments[j] = new Vector3(val3.X, val3.Y, (float)num3);
				val2 = val3;
			}
		}
		base.updateAnimation(time);
		if (wasHitCounter >= 0)
		{
			wasHitCounter -= time.ElapsedGameTime.Milliseconds;
		}
		if (!IsRoyalSerpent())
		{
			Sprite.Animate(time, 0, 9, 40f);
		}
		if (withinPlayerThreshold() && invincibleCountdown <= 0)
		{
			Point standingPixel = base.StandingPixel;
			Point standingPixel2 = base.Player.StandingPixel;
			float num4 = -(standingPixel2.X - standingPixel.X);
			float num5 = standingPixel2.Y - standingPixel.Y;
			float num6 = Math.Max(1f, Math.Abs(num4) + Math.Abs(num5));
			if (num6 < 64f)
			{
				xVelocity = Math.Max(-7f, Math.Min(7f, xVelocity * 1.1f));
				yVelocity = Math.Max(-7f, Math.Min(7f, yVelocity * 1.1f));
			}
			num4 /= num6;
			num5 /= num6;
			if (wasHitCounter <= 0)
			{
				targetRotation = (float)Math.Atan2(0f - num5, num4) - (float)Math.PI / 2f;
				if ((double)(Math.Abs(targetRotation) - Math.Abs(rotation)) > Math.PI * 7.0 / 8.0 && Game1.random.NextBool())
				{
					turningRight = true;
				}
				else if ((double)(Math.Abs(targetRotation) - Math.Abs(rotation)) < Math.PI / 8.0)
				{
					turningRight = false;
				}
				if (turningRight)
				{
					rotation -= (float)Math.Sign(targetRotation - rotation) * ((float)Math.PI / 64f);
				}
				else
				{
					rotation += (float)Math.Sign(targetRotation - rotation) * ((float)Math.PI / 64f);
				}
				rotation %= (float)Math.PI * 2f;
				wasHitCounter = 5 + Game1.random.Next(-1, 2);
			}
			float num7 = Math.Min(7f, Math.Max(2f, 7f - num6 / 64f / 2f));
			num4 = (float)Math.Cos((double)rotation + Math.PI / 2.0);
			num5 = 0f - (float)Math.Sin((double)rotation + Math.PI / 2.0);
			xVelocity += (0f - num4) * num7 / 6f + (float)Game1.random.Next(-10, 10) / 100f;
			yVelocity += (0f - num5) * num7 / 6f + (float)Game1.random.Next(-10, 10) / 100f;
			if (Math.Abs(xVelocity) > Math.Abs((0f - num4) * 7f))
			{
				xVelocity -= (0f - num4) * num7 / 6f;
			}
			if (Math.Abs(yVelocity) > Math.Abs((0f - num5) * 7f))
			{
				yVelocity -= (0f - num5) * num7 / 6f;
			}
		}
		resetAnimationSpeed();
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		if (double.IsNaN(xVelocity) || double.IsNaN(yVelocity))
		{
			base.Health = -500;
		}
		if (base.Position.X <= -640f || base.Position.Y <= -640f || base.Position.X >= (float)(base.currentLocation.Map.Layers[0].LayerWidth * 64 + 640) || base.Position.Y >= (float)(base.currentLocation.Map.Layers[0].LayerHeight * 64 + 640))
		{
			base.Health = -500;
		}
		if (withinPlayerThreshold() && invincibleCountdown <= 0)
		{
			faceDirection(2);
		}
	}
}
