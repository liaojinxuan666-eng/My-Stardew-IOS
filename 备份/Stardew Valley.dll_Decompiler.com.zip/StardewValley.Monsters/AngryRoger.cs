using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Extensions;
using xTile.Dimensions;
using xTile.Layers;

namespace StardewValley.Monsters;

public class AngryRoger : Monster
{
	public const float rotationIncrement = (float)Math.PI / 64f;

	[XmlIgnore]
	public int wasHitCounter;

	[XmlIgnore]
	public float targetRotation;

	[XmlIgnore]
	public bool turningRight;

	[XmlIgnore]
	public int identifier = Game1.random.Next(-99999, 99999);

	[XmlIgnore]
	public new int yOffset;

	[XmlIgnore]
	public int yOffsetExtra;

	public string lightSourceId;

	public AngryRoger()
	{
		lightSourceId = GenerateLightSourceId(identifier);
	}

	public AngryRoger(Vector2 position)
		: base("Ghost", position)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		base.Slipperiness = 8;
		isGlider.Value = true;
		base.HideShadow = true;
		lightSourceId = GenerateLightSourceId(identifier);
	}

	public AngryRoger(Vector2 position, string name)
		: base(name, position)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		base.Slipperiness = 8;
		isGlider.Value = true;
		base.HideShadow = true;
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		Sprite = new AnimatedSprite("Characters\\Monsters\\" + name.Value);
	}

	public override void drawAboveAllLayers(SpriteBatch b)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		int y = base.StandingPixel.Y;
		b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(21 + yOffset)), (Rectangle?)Sprite.SourceRect, Color.White, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f)));
		Texture2D shadowTexture = Game1.shadowTexture;
		Vector2 val = getLocalPosition(Game1.viewport) + new Vector2(32f, 64f);
		Rectangle? val2 = Game1.shadowTexture.Bounds;
		Color white = Color.White;
		Rectangle bounds = Game1.shadowTexture.Bounds;
		float num = ((Rectangle)(ref bounds)).Center.X;
		bounds = Game1.shadowTexture.Bounds;
		b.Draw(shadowTexture, val, val2, white, 0f, new Vector2(num, (float)((Rectangle)(ref bounds)).Center.Y), 3f + (float)yOffset / 20f, (SpriteEffects)0, (float)(y - 1) / 10000f);
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		int num = Math.Max(1, damage - resilience.Value);
		base.Slipperiness = 8;
		Utility.addSprinklesToLocation(base.currentLocation, base.TilePoint.X, base.TilePoint.Y, 2, 2, 101, 50, Color.LightBlue);
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Health -= num;
			if (base.Health <= 0)
			{
				deathAnimation();
			}
			setTrajectory(xTrajectory, yTrajectory);
		}
		addedSpeed = -1f;
		Utility.removeLightSource(lightSourceId);
		return num;
	}

	protected override void localDeathAnimation()
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.localSound("ghost");
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(Sprite.textureName.Value, new Rectangle(0, 96, 16, 24), 100f, 4, 0, base.Position, flicker: false, flipped: false, 0.9f, 0.001f, Color.White, 4f, 0.01f, 0f, (float)Math.PI / 64f));
	}

	protected override void sharedDeathAnimation()
	{
	}

	protected override void updateAnimation(GameTime time)
	{
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		yOffset = (int)(Math.Sin((double)((float)time.TotalGameTime.Milliseconds / 1000f) * (Math.PI * 2.0)) * 20.0) - yOffsetExtra;
		if (base.currentLocation == Game1.currentLocation)
		{
			if (Game1.currentLightSources.TryGetValue(lightSourceId, out var value))
			{
				value.position.Value = new Vector2(base.Position.X + 32f, base.Position.Y + 64f + (float)yOffset);
			}
			else
			{
				Game1.currentLightSources.Add(new LightSource(lightSourceId, 5, new Vector2(base.Position.X + 8f, base.Position.Y + 64f), 1f, Color.White * 0.7f, LightSource.LightContext.None, 0L, Game1.currentLocation.NameOrUniqueName));
			}
		}
		Point standingPixel = base.StandingPixel;
		Point standingPixel2 = base.Player.StandingPixel;
		float num = -(standingPixel2.X - standingPixel.X);
		float num2 = standingPixel2.Y - standingPixel.Y;
		float num3 = 400f;
		num /= num3;
		num2 /= num3;
		if (wasHitCounter <= 0)
		{
			targetRotation = (float)Math.Atan2(0f - num2, num) - (float)Math.PI / 2f;
			if ((double)(Math.Abs(targetRotation) - Math.Abs(rotation)) > Math.PI * 7.0 / 8.0 && Game1.random.NextBool())
			{
				turningRight = true;
			}
			else if ((double)(Math.Abs(targetRotation) - Math.Abs(rotation)) < Math.PI / 8.0)
			{
				turningRight = false;
			}
			if (turningRight)
			{
				rotation -= (float)Math.Sign(targetRotation - rotation) * ((float)Math.PI / 64f);
			}
			else
			{
				rotation += (float)Math.Sign(targetRotation - rotation) * ((float)Math.PI / 64f);
			}
			rotation %= (float)Math.PI * 2f;
			wasHitCounter = 0;
		}
		float num4 = Math.Min(4f, Math.Max(1f, 5f - num3 / 64f / 2f));
		num = (float)Math.Cos((double)rotation + Math.PI / 2.0);
		num2 = 0f - (float)Math.Sin((double)rotation + Math.PI / 2.0);
		xVelocity += (0f - num) * num4 / 6f + (float)Game1.random.Next(-10, 10) / 100f;
		yVelocity += (0f - num2) * num4 / 6f + (float)Game1.random.Next(-10, 10) / 100f;
		if (Math.Abs(xVelocity) > Math.Abs((0f - num) * 5f))
		{
			xVelocity -= (0f - num) * num4 / 6f;
		}
		if (Math.Abs(yVelocity) > Math.Abs((0f - num2) * 5f))
		{
			yVelocity -= (0f - num2) * num4 / 6f;
		}
		faceGeneralDirection(base.Player.getStandingPosition());
		resetAnimationSpeed();
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		Rectangle boundingBox = GetBoundingBox();
		Rectangle boundingBox2 = base.Player.GetBoundingBox();
		if (!((Rectangle)(ref boundingBox)).Intersects(boundingBox2) || !base.Player.temporarilyInvincible)
		{
			return;
		}
		Layer val = base.currentLocation.map.RequireLayer("Back");
		Point center = ((Rectangle)(ref boundingBox2)).Center;
		int i = 0;
		Vector2 val2 = default(Vector2);
		((Vector2)(ref val2))._002Ector((float)(center.X / 64 + Game1.random.Next(-12, 12)), (float)(center.Y / 64 + Game1.random.Next(-12, 12)));
		for (; i < 3; i++)
		{
			if (!(val2.X >= (float)val.LayerWidth) && !(val2.Y >= (float)val.LayerHeight) && !(val2.X < 0f) && !(val2.Y < 0f) && val.Tiles[(int)val2.X, (int)val2.Y] != null && base.currentLocation.isTilePassable(new Location((int)val2.X, (int)val2.Y), Game1.viewport) && !((Vector2)(ref val2)).Equals(new Vector2((float)(center.X / 64), (float)(center.Y / 64))))
			{
				break;
			}
			((Vector2)(ref val2))._002Ector((float)(center.X / 64 + Game1.random.Next(-12, 12)), (float)(center.Y / 64 + Game1.random.Next(-12, 12)));
		}
		if (i < 3)
		{
			base.Position = new Vector2(val2.X * 64f, val2.Y * 64f - 32f);
			Halt();
		}
	}
}
