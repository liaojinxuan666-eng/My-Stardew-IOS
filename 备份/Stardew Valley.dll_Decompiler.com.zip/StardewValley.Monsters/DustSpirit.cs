using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewValley.Pathfinding;
using StardewValley.TerrainFeatures;

namespace StardewValley.Monsters;

public class DustSpirit : Monster
{
	[XmlIgnore]
	public bool seenFarmer;

	[XmlIgnore]
	public bool runningAwayFromFarmer;

	[XmlIgnore]
	public bool chargingFarmer;

	public byte voice;

	[XmlIgnore]
	public ICue meep;

	public DustSpirit()
	{
	}

	public DustSpirit(Vector2 position)
		: base("Dust Spirit", position)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		base.IsWalkingTowardPlayer = false;
		Sprite.interval = 45f;
		base.Scale = (float)Game1.random.Next(75, 101) / 100f;
		voice = (byte)Game1.random.Next(1, 24);
		base.HideShadow = true;
	}

	public DustSpirit(Vector2 position, bool chargingTowardFarmer)
		: base("Dust Spirit", position)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		base.IsWalkingTowardPlayer = false;
		if (chargingTowardFarmer)
		{
			chargingFarmer = true;
			seenFarmer = true;
		}
		Sprite.interval = 45f;
		base.Scale = (float)Game1.random.Next(75, 101) / 100f;
		base.HideShadow = true;
	}

	public override void draw(SpriteBatch b)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		if (!base.IsInvisible && Utility.isOnScreen(base.Position, 128))
		{
			int y = base.StandingPixel.Y;
			b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2((float)(32 + ((shakeTimer > 0) ? Game1.random.Next(-1, 2) : 0)), (float)(64 + yJumpOffset)), (Rectangle?)Sprite.SourceRect, Color.White, rotation, new Vector2(8f, 16f), new Vector2(scale.Value + (float)Math.Max(-0.1, (double)(yJumpOffset + 32) / 128.0), scale.Value - Math.Max(-0.1f, (float)yJumpOffset / 256f)) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f)));
			if (isGlowing)
			{
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(64 + yJumpOffset)), (Rectangle?)Sprite.SourceRect, glowingColor * glowingTransparency, rotation, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.99f : ((float)y / 10000f + 0.001f)));
			}
			Texture2D shadowTexture = Game1.shadowTexture;
			Vector2 val = getLocalPosition(Game1.viewport) + new Vector2(32f, 80f);
			Rectangle? val2 = Game1.shadowTexture.Bounds;
			Color white = Color.White;
			Rectangle bounds = Game1.shadowTexture.Bounds;
			float num = ((Rectangle)(ref bounds)).Center.X;
			bounds = Game1.shadowTexture.Bounds;
			b.Draw(shadowTexture, val, val2, white, 0f, new Vector2(num, (float)((Rectangle)(ref bounds)).Center.Y), 4f + (float)yJumpOffset / 64f, (SpriteEffects)0, (float)(y - 1) / 10000f);
		}
	}

	protected override void sharedDeathAnimation()
	{
	}

	protected override void localDeathAnimation()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.localSound("dustMeep");
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(44, base.Position, new Color(50, 50, 80), 10));
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(44, base.Position + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-32, 32)), new Color(50, 50, 80), 10)
		{
			delayBeforeAnimationStart = 150,
			scale = 0.5f
		});
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(44, base.Position + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-32, 32)), new Color(50, 50, 80), 10)
		{
			delayBeforeAnimationStart = 300,
			scale = 0.5f
		});
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(44, base.Position + new Vector2((float)Game1.random.Next(-32, 32), (float)Game1.random.Next(-32, 32)), new Color(50, 50, 80), 10)
		{
			delayBeforeAnimationStart = 450,
			scale = 0.5f
		});
	}

	public override void shedChunks(int number, float scale)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		Point standingPixel = base.StandingPixel;
		Game1.createRadialDebris(base.currentLocation, Sprite.textureName.Value, new Rectangle(0, 16, 16, 16), 8, standingPixel.X, standingPixel.Y, number, base.TilePoint.Y, Color.White, (base.Health <= 0) ? 4f : 2f);
	}

	public void offScreenBehavior(Character c, GameLocation l)
	{
	}

	public virtual bool CaughtInWeb()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		if (base.currentLocation != null && base.currentLocation.terrainFeatures.TryGetValue(base.Tile, out var value) && value is Grass grass)
		{
			return grass.grassType.Value == 6;
		}
		return false;
	}

	protected override void updateAnimation(GameTime time)
	{
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		if (yJumpOffset == 0)
		{
			if (isHardModeMonster.Value && CaughtInWeb())
			{
				Sprite.Animate(time, 5, 3, 200f);
				return;
			}
			jumpWithoutSound();
			yJumpVelocity = (float)Game1.random.Next(50, 70) / 10f;
			if (Game1.random.NextDouble() < 0.1 && (meep == null || !meep.IsPlaying) && Utility.isOnScreen(base.Position, 64) && Game1.currentLocation == base.currentLocation)
			{
				Game1.playSound("dustMeep", voice * 100 + Game1.random.Next(-100, 100), out meep);
			}
		}
		Sprite.AnimateDown(time);
		resetAnimationSpeed();
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0304: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0377: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		if (yJumpOffset == 0)
		{
			if (Game1.random.NextDouble() < 0.01)
			{
				Vector2 standingPosition = getStandingPosition();
				Game1.multiplayer.broadcastSprites(base.currentLocation, new TemporaryAnimatedSprite("TileSheets\\animations", new Rectangle(0, 128, 64, 64), 40f, 4, 0, standingPosition + new Vector2(-21f, 0f), flicker: false, flipped: false)
				{
					layerDepth = (standingPosition.Y - 10f) / 10000f
				});
				foreach (Vector2 adjacentTileLocation in Utility.getAdjacentTileLocations(base.Tile))
				{
					if (base.currentLocation.objects.TryGetValue(adjacentTileLocation, out var value) && (value.IsBreakableStone() || value.IsTwig()))
					{
						base.currentLocation.destroyObject(adjacentTileLocation, null);
					}
				}
				yJumpVelocity *= 2f;
			}
			if (!chargingFarmer)
			{
				xVelocity = (float)Game1.random.Next(-20, 21) / 5f;
			}
		}
		if (chargingFarmer)
		{
			base.Slipperiness = 10;
			Vector2 awayFromPlayerTrajectory = Utility.getAwayFromPlayerTrajectory(GetBoundingBox(), base.Player);
			xVelocity += (0f - awayFromPlayerTrajectory.X) / 150f + ((Game1.random.NextDouble() < 0.01) ? ((float)Game1.random.Next(-50, 50) / 10f) : 0f);
			if (Math.Abs(xVelocity) > 5f)
			{
				xVelocity = Math.Sign(xVelocity) * 5;
			}
			yVelocity += (0f - awayFromPlayerTrajectory.Y) / 150f + ((Game1.random.NextDouble() < 0.01) ? ((float)Game1.random.Next(-50, 50) / 10f) : 0f);
			if (Math.Abs(yVelocity) > 5f)
			{
				yVelocity = Math.Sign(yVelocity) * 5;
			}
			if (Game1.random.NextDouble() < 0.0001)
			{
				controller = new PathFindController(this, base.currentLocation, base.Player.TilePoint, Game1.random.Next(4), null, 300);
				chargingFarmer = false;
			}
			if (isHardModeMonster.Value && CaughtInWeb())
			{
				xVelocity = 0f;
				yVelocity = 0f;
				if (shakeTimer <= 0 && Game1.random.NextDouble() < 0.05)
				{
					shakeTimer = 200;
				}
			}
		}
		else if (!seenFarmer && Utility.doesPointHaveLineOfSightInMine(base.currentLocation, getStandingPosition() / 64f, base.Player.getStandingPosition() / 64f, 8))
		{
			seenFarmer = true;
		}
		else if (seenFarmer && controller == null && !runningAwayFromFarmer)
		{
			addedSpeed = 2f;
			controller = new PathFindController(this, base.currentLocation, Utility.isOffScreenEndFunction, -1, offScreenBehavior, 350, Point.Zero);
			runningAwayFromFarmer = true;
		}
		else if (controller == null && runningAwayFromFarmer)
		{
			chargingFarmer = true;
		}
	}
}
