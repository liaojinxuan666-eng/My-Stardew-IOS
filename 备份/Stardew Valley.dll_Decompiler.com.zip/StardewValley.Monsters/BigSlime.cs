using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.Locations;

namespace StardewValley.Monsters;

public class BigSlime : Monster
{
	[XmlElement("c")]
	public readonly NetColor c = new NetColor();

	[XmlElement("heldObject")]
	public readonly NetRef<Item> heldItem = new NetRef<Item>();

	private float heldObjectBobTimer;

	public BigSlime()
	{
	}

	public BigSlime(Vector2 position, MineShaft mine)
		: this(position, mine.getMineArea())
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		Sprite.ignoreStopAnimation = true;
		ignoreMovementAnimations = true;
		base.HideShadow = true;
	}

	public BigSlime(Vector2 position, int mineArea)
		: base("Big Slime", position)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		ignoreMovementAnimations = true;
		Sprite.ignoreStopAnimation = true;
		Sprite.SpriteWidth = 32;
		Sprite.SpriteHeight = 32;
		Sprite.UpdateSourceRect();
		Sprite.framesPerAnimation = 8;
		c.Value = Color.White;
		switch (mineArea)
		{
		case 0:
		case 10:
			c.Value = Color.Lime;
			break;
		case 40:
			c.Value = Color.Turquoise;
			base.Health *= 2;
			base.ExperienceGained *= 2;
			break;
		case 80:
			c.Value = Color.Red;
			base.Health *= 3;
			base.DamageToFarmer *= 2;
			base.ExperienceGained *= 3;
			break;
		case 121:
			c.Value = Color.BlueViolet;
			base.Health *= 4;
			base.DamageToFarmer *= 3;
			base.ExperienceGained *= 3;
			break;
		}
		int r = c.R;
		int g = c.G;
		int b = c.B;
		r += Game1.random.Next(-20, 21);
		g += Game1.random.Next(-20, 21);
		b += Game1.random.Next(-20, 21);
		c.R = (byte)Math.Max(Math.Min(255, r), 0);
		c.G = (byte)Math.Max(Math.Min(255, g), 0);
		c.B = (byte)Math.Max(Math.Min(255, b), 0);
		NetColor netColor = c;
		netColor.Value *= (float)Game1.random.Next(7, 11) / 10f;
		Sprite.interval = 300f;
		base.HideShadow = true;
		if (Game1.random.NextDouble() < 0.01 && mineArea >= 40)
		{
			heldItem.Value = ItemRegistry.Create("(O)221");
		}
		if (Game1.mine != null && Game1.mine.GetAdditionalDifficulty() > 0)
		{
			if (Game1.random.NextDouble() < 0.1)
			{
				heldItem.Value = ItemRegistry.Create("(O)858");
			}
			else if (Game1.random.NextDouble() < 0.005)
			{
				heldItem.Value = ItemRegistry.Create("(O)896");
			}
		}
		if (Game1.random.NextBool() && Game1.player.team.SpecialOrderRuleActive("SC_NO_FOOD"))
		{
			heldItem.Value = ItemRegistry.Create("(O)930");
		}
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(c, "c").AddField(heldItem, "heldItem");
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		base.reloadSprite(onlyAppearance);
		Sprite.SpriteWidth = 32;
		Sprite.SpriteHeight = 32;
		Sprite.interval = 300f;
		Sprite.ignoreStopAnimation = true;
		ignoreMovementAnimations = true;
		base.HideShadow = true;
		Sprite.UpdateSourceRect();
		Sprite.framesPerAnimation = 8;
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		int num = Math.Max(1, damage - resilience.Value);
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Slipperiness = 3;
			base.Health -= num;
			setTrajectory(xTrajectory, yTrajectory);
			base.currentLocation.playSound("hitEnemy");
			base.IsWalkingTowardPlayer = true;
			if (base.Health <= 0)
			{
				deathAnimation();
				Game1.stats.SlimesKilled++;
				if (Game1.gameMode == 3 && Game1.random.NextDouble() < 0.75)
				{
					int num2 = Game1.random.Next(2, 5);
					for (int i = 0; i < num2; i++)
					{
						base.currentLocation.characters.Add(new GreenSlime(base.Position, Game1.CurrentMineLevel));
						base.currentLocation.characters[base.currentLocation.characters.Count - 1].setTrajectory(xTrajectory / 8 + Game1.random.Next(-2, 3), yTrajectory / 8 + Game1.random.Next(-2, 3));
						base.currentLocation.characters[base.currentLocation.characters.Count - 1].willDestroyObjectsUnderfoot = false;
						base.currentLocation.characters[base.currentLocation.characters.Count - 1].moveTowardPlayer(4);
						base.currentLocation.characters[base.currentLocation.characters.Count - 1].Scale = 0.75f + (float)Game1.random.Next(-5, 10) / 100f;
						base.currentLocation.characters[base.currentLocation.characters.Count - 1].currentLocation = base.currentLocation;
					}
				}
			}
		}
		return num;
	}

	protected override void localDeathAnimation()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(44, base.Position, c.Value, 10, flipped: false, 70f));
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(44, base.Position + new Vector2(-32f, 0f), c.Value, 10, flipped: false, 70f)
		{
			delayBeforeAnimationStart = 100
		});
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(44, base.Position + new Vector2(32f, 0f), c.Value, 10, flipped: false, 70f)
		{
			delayBeforeAnimationStart = 200
		});
		base.currentLocation.localSound("slimedead");
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(44, base.Position + new Vector2(0f, -32f), c.Value, 10)
		{
			delayBeforeAnimationStart = 300
		});
	}

	protected override void updateAnimation(GameTime time)
	{
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		int currentFrame = Sprite.currentFrame;
		Sprite.AnimateDown(time);
		if (isMoving())
		{
			Sprite.interval = 100f;
			heldObjectBobTimer += (float)time.ElapsedGameTime.TotalMilliseconds * 0.007853982f;
		}
		else
		{
			Sprite.interval = 200f;
			heldObjectBobTimer += (float)time.ElapsedGameTime.TotalMilliseconds * 0.003926991f;
		}
		if (Utility.isOnScreen(base.Position, 128) && Sprite.currentFrame == 0 && currentFrame == 7)
		{
			base.currentLocation.localSound("slimeHit");
		}
	}

	public override List<Item> getExtraDropItems()
	{
		if (heldItem.Value != null)
		{
			return new List<Item> { heldItem.Value };
		}
		return base.getExtraDropItems();
	}

	public override void draw(SpriteBatch b)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		if (!base.IsInvisible && Utility.isOnScreen(base.Position, 128))
		{
			int y = base.StandingPixel.Y;
			heldItem.Value?.drawInMenu(b, getLocalPosition(Game1.viewport) + new Vector2(28f, -16f + (float)Math.Sin(heldObjectBobTimer + 1f) * 4f), 1f, 1f, (float)(y - 1) / 10000f, StackDrawType.Hide, Color.White, drawShadow: false);
			b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(56f, (float)(16 + yJumpOffset)), (Rectangle?)Sprite.SourceRect, c.Value, rotation, new Vector2(16f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f)));
			if (isGlowing)
			{
				b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(56f, (float)(16 + yJumpOffset)), (Rectangle?)Sprite.SourceRect, glowingColor * glowingTransparency, 0f, new Vector2(16f, 16f), 4f * Math.Max(0.2f, scale.Value), (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f + 0.001f)));
			}
		}
	}

	public override Rectangle GetBoundingBox()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = base.Position;
		return new Rectangle((int)val.X + 8, (int)val.Y, Sprite.SpriteWidth * 4 * 3 / 4, 64);
	}

	public override void shedChunks(int number, float scale)
	{
	}
}
