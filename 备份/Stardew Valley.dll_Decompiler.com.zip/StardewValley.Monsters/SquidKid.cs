using System;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley.Extensions;
using StardewValley.Projectiles;

namespace StardewValley.Monsters;

public class SquidKid : Monster
{
	[XmlIgnore]
	public float lastFireball;

	[XmlIgnore]
	public new int yOffset;

	private readonly NetEvent0 fireballEvent = new NetEvent0();

	private readonly NetEvent0 hurtAnimationEvent = new NetEvent0();

	private int numFireballsLeft;

	private float firingTimer;

	public SquidKid()
	{
	}

	public SquidKid(Vector2 position)
		: base("Squid Kid", position)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		Sprite.SpriteHeight = 16;
		base.IsWalkingTowardPlayer = false;
		Sprite.UpdateSourceRect();
		base.HideShadow = true;
	}

	protected override void initNetFields()
	{
		base.initNetFields();
		base.NetFields.AddField(fireballEvent, "fireballEvent").AddField(hurtAnimationEvent, "hurtAnimationEvent");
		fireballEvent.onEvent += delegate
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			if (!Game1.IsMasterGame)
			{
				fireballFired();
			}
		};
		hurtAnimationEvent.onEvent += delegate
		{
			Sprite.currentFrame = Sprite.currentFrame - Sprite.currentFrame % 4 + 3;
		};
	}

	public override void reloadSprite(bool onlyAppearance = false)
	{
		Sprite = new AnimatedSprite("Characters\\Monsters\\Squid Kid");
	}

	public override int takeDamage(int damage, int xTrajectory, int yTrajectory, bool isBomb, double addedPrecision, Farmer who)
	{
		int num = Math.Max(1, damage - resilience.Value);
		if (Game1.random.NextDouble() < missChance.Value - missChance.Value * addedPrecision)
		{
			num = -1;
		}
		else
		{
			base.Health -= num;
			setTrajectory(xTrajectory, yTrajectory);
			base.currentLocation.playSound("hitEnemy");
			hurtAnimationEvent.Fire();
			if (base.Health <= 0)
			{
				deathAnimation();
			}
		}
		return num;
	}

	protected override void sharedDeathAnimation()
	{
	}

	protected override void localDeathAnimation()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(Sprite.textureName.Value, new Rectangle(0, 64, 16, 16), 70f, 7, 0, base.Position + new Vector2(0f, -32f), flicker: false, flipped: false)
		{
			scale = 4f
		});
		base.currentLocation.localSound("fireball");
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(362, 30f, 6, 1, base.Position + new Vector2((float)(-16 + Game1.random.Next(64)), (float)(Game1.random.Next(64) - 32)), flicker: false, Game1.random.NextBool())
		{
			delayBeforeAnimationStart = 100
		});
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(362, 30f, 6, 1, base.Position + new Vector2((float)(-16 + Game1.random.Next(64)), (float)(Game1.random.Next(64) - 32)), flicker: false, Game1.random.NextBool())
		{
			delayBeforeAnimationStart = 200
		});
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(362, 30f, 6, 1, base.Position + new Vector2((float)(-16 + Game1.random.Next(64)), (float)(Game1.random.Next(64) - 32)), flicker: false, Game1.random.NextBool())
		{
			delayBeforeAnimationStart = 300
		});
		base.currentLocation.temporarySprites.Add(new TemporaryAnimatedSprite(362, 30f, 6, 1, base.Position + new Vector2((float)(-16 + Game1.random.Next(64)), (float)(Game1.random.Next(64) - 32)), flicker: false, Game1.random.NextBool())
		{
			delayBeforeAnimationStart = 400
		});
	}

	public override void drawAboveAllLayers(SpriteBatch b)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		int y = base.StandingPixel.Y;
		b.Draw(Sprite.Texture, getLocalPosition(Game1.viewport) + new Vector2(32f, (float)(21 + yOffset)), (Rectangle?)Sprite.SourceRect, Color.White, 0f, new Vector2(8f, 16f), Math.Max(0.2f, scale.Value) * 4f, (SpriteEffects)(flip ? 1 : 0), Math.Max(0f, drawOnTop ? 0.991f : ((float)y / 10000f)));
		Texture2D shadowTexture = Game1.shadowTexture;
		Vector2 val = getLocalPosition(Game1.viewport) + new Vector2(32f, 64f);
		Rectangle? val2 = Game1.shadowTexture.Bounds;
		Color white = Color.White;
		Rectangle bounds = Game1.shadowTexture.Bounds;
		float num = ((Rectangle)(ref bounds)).Center.X;
		bounds = Game1.shadowTexture.Bounds;
		b.Draw(shadowTexture, val, val2, white, 0f, new Vector2(num, (float)((Rectangle)(ref bounds)).Center.Y), 3f + (float)yOffset / 20f, (SpriteEffects)0, (float)(y - 1) / 10000f);
	}

	protected override void updateAnimation(GameTime time)
	{
		base.updateAnimation(time);
		yOffset = (int)(Math.Sin((double)((float)time.TotalGameTime.Milliseconds / 2000f) * (Math.PI * 2.0)) * 15.0);
		if (Sprite.currentFrame % 4 != 0 && Game1.random.NextDouble() < 0.1)
		{
			Sprite.currentFrame -= Sprite.currentFrame % 4;
		}
		if (Game1.random.NextDouble() < 0.01)
		{
			Sprite.currentFrame++;
		}
		resetAnimationSpeed();
	}

	protected override void updateMonsterSlaveAnimation(GameTime time)
	{
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		if (isMoving())
		{
			switch (FacingDirection)
			{
			case 0:
				Sprite.AnimateUp(time);
				break;
			case 3:
				Sprite.AnimateLeft(time);
				break;
			case 1:
				Sprite.AnimateRight(time);
				break;
			case 2:
				Sprite.AnimateDown(time);
				break;
			}
		}
		faceGeneralDirection(base.Player.Position);
	}

	private Vector2 fireballFired()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		switch (FacingDirection)
		{
		case 0:
			Sprite.currentFrame = 3;
			return Vector2.Zero;
		case 1:
			Sprite.currentFrame = 7;
			return new Vector2(64f, 0f);
		case 2:
			Sprite.currentFrame = 11;
			return new Vector2(0f, 32f);
		case 3:
			Sprite.currentFrame = 15;
			return new Vector2(-32f, 0f);
		default:
			return Vector2.Zero;
		}
	}

	public override void update(GameTime time, GameLocation location)
	{
		base.update(time, location);
		fireballEvent.Poll();
	}

	public override void behaviorAtGameTick(GameTime time)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0274: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_0376: Unknown result type (might be due to invalid IL or missing references)
		//IL_0379: Unknown result type (might be due to invalid IL or missing references)
		//IL_0386: Unknown result type (might be due to invalid IL or missing references)
		//IL_0391: Unknown result type (might be due to invalid IL or missing references)
		//IL_039e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		base.behaviorAtGameTick(time);
		faceGeneralDirection(base.Player.Position);
		lastFireball = Math.Max(0f, lastFireball - (float)time.ElapsedGameTime.Milliseconds);
		if (isHardModeMonster.Value)
		{
			if ((numFireballsLeft <= 0 && !withinPlayerThreshold()) || !(lastFireball <= 0f))
			{
				return;
			}
			if (lastFireball <= 0f && numFireballsLeft <= 0)
			{
				numFireballsLeft = 4;
				firingTimer = 0f;
			}
			firingTimer -= (float)time.ElapsedGameTime.TotalMilliseconds;
			if (firingTimer <= 0f && numFireballsLeft > 0)
			{
				Rectangle boundingBox = base.Player.GetBoundingBox();
				numFireballsLeft--;
				base.IsWalkingTowardPlayer = false;
				Halt();
				fireballEvent.Fire();
				fireballFired();
				Sprite.UpdateSourceRect();
				Vector2 standingPosition = getStandingPosition();
				Vector2 velocityTowardPoint = Utility.getVelocityTowardPoint(standingPosition, new Vector2((float)boundingBox.X, (float)boundingBox.Y) + new Vector2((float)Game1.random.Next(-128, 128)), 8f);
				BasicProjectile basicProjectile = new BasicProjectile(15, 10, 2, 4, 0f, velocityTowardPoint.X, velocityTowardPoint.Y, standingPosition - new Vector2(32f, 0f), null, null, null, explode: true, damagesMonsters: false, base.currentLocation, this);
				basicProjectile.height.Value = 48f;
				base.currentLocation.projectiles.Add(basicProjectile);
				base.currentLocation.playSound("fireball");
				firingTimer = 400f;
				if (numFireballsLeft <= 0)
				{
					lastFireball = Game1.random.Next(3000, 6500);
				}
			}
		}
		else if (withinPlayerThreshold() && lastFireball == 0f && Game1.random.NextDouble() < 0.01)
		{
			base.IsWalkingTowardPlayer = false;
			Halt();
			fireballEvent.Fire();
			fireballFired();
			Sprite.UpdateSourceRect();
			Point standingPixel = base.StandingPixel;
			Vector2 velocityTowardPlayer = Utility.getVelocityTowardPlayer(standingPixel, 8f, base.Player);
			BasicProjectile basicProjectile2 = new BasicProjectile(15, 10, 3, 4, 0f, velocityTowardPlayer.X, velocityTowardPlayer.Y, new Vector2((float)(standingPixel.X - 32), (float)standingPixel.Y), null, null, null, explode: true, damagesMonsters: false, base.currentLocation, this);
			basicProjectile2.height.Value = 48f;
			base.currentLocation.projectiles.Add(basicProjectile2);
			base.currentLocation.playSound("fireball");
			lastFireball = Game1.random.Next(1200, 3500);
		}
		else if (lastFireball != 0f && Game1.random.NextDouble() < 0.02)
		{
			Halt();
			if (withinPlayerThreshold())
			{
				base.Slipperiness = 8;
				Point standingPixel2 = base.StandingPixel;
				setTrajectory((int)Utility.getVelocityTowardPlayer(standingPixel2, 8f, base.Player).X, (int)(0f - Utility.getVelocityTowardPlayer(standingPixel2, 8f, base.Player).Y));
			}
		}
	}
}
